## Packages
date-fns | Date formatting for note timestamps
framer-motion | Smooth animations for sidebar and list transitions
@tiptap/react | Rich text editing experience
@tiptap/starter-kit | Essentials for Tiptap
@tiptap/extension-placeholder | Placeholder text for editor

## Notes
- Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["var(--font-sans)"],
  display: ["var(--font-display)"],
  mono: ["var(--font-mono)"],
}
- Backend API at /api/notes
- Wouter used for routing
