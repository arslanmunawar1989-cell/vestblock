import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Placeholder from '@tiptap/extension-placeholder';
import { useEffect, useState } from 'react';
import { Note } from '@shared/schema';
import { useDebounce } from "@/hooks/use-mobile"; // Reusing mobile hook file for debounce if exists, or creating inline
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Bold, Italic, List, ListOrdered, Quote, Code, Undo, Redo, Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

// Simple debounce hook implementation if not available
function useDebouncedCallback<T extends (...args: any[]) => any>(
  callback: T,
  delay: number
) {
  const [timeoutId, setTimeoutId] = useState<NodeJS.Timeout | null>(null);

  return (...args: Parameters<T>) => {
    if (timeoutId) clearTimeout(timeoutId);
    const id = setTimeout(() => {
      callback(...args);
    }, delay);
    setTimeoutId(id);
  };
}

interface EditorProps {
  note: Note;
  onUpdate: (updates: { title?: string; content?: string }) => void;
  onDelete: () => void;
  isSaving?: boolean;
}

export function Editor({ note, onUpdate, onDelete, isSaving }: EditorProps) {
  const [title, setTitle] = useState(note.title);

  const debouncedUpdate = useDebouncedCallback((updates: { title?: string; content?: string }) => {
    onUpdate(updates);
  }, 1000);

  const editor = useEditor({
    extensions: [
      StarterKit,
      Placeholder.configure({
        placeholder: 'Start typing your thoughts...',
      }),
    ],
    content: note.content,
    editorProps: {
      attributes: {
        class: 'prose prose-sm sm:prose lg:prose-lg xl:prose-2xl mx-auto focus:outline-none min-h-[500px] px-8 py-6',
      },
    },
    onUpdate: ({ editor }) => {
      debouncedUpdate({ content: editor.getHTML() });
    },
  });

  // Sync editor content when switching notes
  useEffect(() => {
    if (editor && note.id) {
      // Check if content is different to avoid cursor jumps/loops
      // This is a naive check but works for basic switching
      if (editor.getHTML() !== note.content) {
        editor.commands.setContent(note.content);
        setTitle(note.title);
      }
    }
  }, [note.id, editor]); 
  
  // Note: We don't depend on note.content/title to avoid overwriting ongoing edits
  // Only sync on ID change (switching notes)

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTitle = e.target.value;
    setTitle(newTitle);
    debouncedUpdate({ title: newTitle });
  };

  if (!editor) {
    return null;
  }

  const ToolbarButton = ({ 
    onClick, 
    active = false, 
    children 
  }: { 
    onClick: () => void; 
    active?: boolean; 
    children: React.ReactNode 
  }) => (
    <Button
      variant="ghost"
      size="sm"
      onClick={onClick}
      className={active ? "bg-muted text-primary" : "text-muted-foreground hover:text-foreground"}
    >
      {children}
    </Button>
  );

  return (
    <div className="flex flex-col h-full bg-background/50 backdrop-blur-sm">
      <div className="border-b border-border/50 px-8 py-4 flex items-center justify-between sticky top-0 bg-background/80 backdrop-blur-md z-10">
        <div className="flex-1 mr-4">
          <Input
            value={title}
            onChange={handleTitleChange}
            placeholder="Note Title"
            className="text-3xl font-display font-bold border-none px-0 shadow-none focus-visible:ring-0 bg-transparent placeholder:text-muted-foreground/50 h-auto py-2"
          />
        </div>
        <div className="flex items-center gap-2">
          {isSaving && (
            <span className="text-xs text-muted-foreground animate-pulse mr-4">
              Saving...
            </span>
          )}
          
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive hover:bg-destructive/10">
                <Trash2 className="w-5 h-5" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete Note?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This note will be permanently deleted.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={onDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      <div className="border-b border-border/50 px-4 py-2 flex items-center gap-1 overflow-x-auto bg-background/30">
        <ToolbarButton
          onClick={() => editor.chain().focus().toggleBold().run()}
          active={editor.isActive('bold')}
        >
          <Bold className="w-4 h-4" />
        </ToolbarButton>
        <ToolbarButton
          onClick={() => editor.chain().focus().toggleItalic().run()}
          active={editor.isActive('italic')}
        >
          <Italic className="w-4 h-4" />
        </ToolbarButton>
        <div className="w-px h-6 bg-border mx-2" />
        <ToolbarButton
          onClick={() => editor.chain().focus().toggleBulletList().run()}
          active={editor.isActive('bulletList')}
        >
          <List className="w-4 h-4" />
        </ToolbarButton>
        <ToolbarButton
          onClick={() => editor.chain().focus().toggleOrderedList().run()}
          active={editor.isActive('orderedList')}
        >
          <ListOrdered className="w-4 h-4" />
        </ToolbarButton>
        <ToolbarButton
          onClick={() => editor.chain().focus().toggleBlockquote().run()}
          active={editor.isActive('blockquote')}
        >
          <Quote className="w-4 h-4" />
        </ToolbarButton>
        <ToolbarButton
          onClick={() => editor.chain().focus().toggleCodeBlock().run()}
          active={editor.isActive('codeBlock')}
        >
          <Code className="w-4 h-4" />
        </ToolbarButton>
        <div className="w-px h-6 bg-border mx-2" />
        <ToolbarButton onClick={() => editor.chain().focus().undo().run()}>
          <Undo className="w-4 h-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().redo().run()}>
          <Redo className="w-4 h-4" />
        </ToolbarButton>
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto py-8">
          <EditorContent editor={editor} />
        </div>
      </div>
    </div>
  );
}
