import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

interface GlassButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "default" | "primary" | "secondary";
  size?: "sm" | "default" | "lg";
}

export function GlassButton({
  children,
  className,
  variant = "default",
  size = "default",
  ...props
}: GlassButtonProps) {
  if (variant === "primary") {
    return (
      <Button
        size={size === "lg" ? "lg" : size === "sm" ? "sm" : "default"}
        className={className}
        {...props}
      >
        {children}
      </Button>
    );
  }

  if (variant === "secondary") {
    return (
      <Button
        variant="secondary"
        size={size === "lg" ? "lg" : size === "sm" ? "sm" : "default"}
        className={className}
        {...props}
      >
        {children}
      </Button>
    );
  }

  return (
    <Button
      variant="outline"
      size={size === "lg" ? "lg" : size === "sm" ? "sm" : "default"}
      className={cn("glass-light glass-noise", className)}
      {...props}
    >
      {children}
    </Button>
  );
}
