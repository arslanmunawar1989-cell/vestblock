import { lazy, Suspense, useState, useEffect, useCallback, memo } from "react";

export const ENABLE_WEBGL_HERO = true;

const LazyCanvas = lazy(() =>
  import("@react-three/fiber").then((mod) => ({
    default: mod.Canvas,
  }))
);

const LazyScene = lazy(() => import("./webgl/Scene"));

function detectWebGLSupport(): boolean {
  try {
    const canvas = document.createElement("canvas");
    const gl =
      canvas.getContext("webgl2") || canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
    return !!gl;
  } catch {
    return false;
  }
}

function detectReducedMotion(): boolean {
  if (typeof window === "undefined") return false;
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function detectLowPower(): boolean {
  if (typeof window === "undefined") return false;
  const isSmall = window.innerWidth <= 768;
  const lowMemory = "deviceMemory" in navigator && (navigator as any).deviceMemory < 4;
  const slowCPU =
    "hardwareConcurrency" in navigator && navigator.hardwareConcurrency <= 2;
  return isSmall || lowMemory || slowCPU;
}

function CSSFallback() {
  return (
    <div
      className="absolute inset-0 overflow-hidden"
      aria-hidden="true"
      data-testid="hero-css-fallback"
    >
      <div className="absolute top-[10%] left-[5%] w-72 h-72 rounded-full bg-vest-g1/20 blur-[100px]" />
      <div className="absolute bottom-[15%] right-[10%] w-96 h-96 rounded-full bg-vest-g2/15 blur-[120px]" />
      <div className="absolute top-[50%] left-[40%] w-48 h-48 rounded-full bg-vest-g0/25 blur-[80px]" />
    </div>
  );
}

function WebGLCanvas({ mobile, onError }: { mobile: boolean; onError: () => void }) {
  const dpr = Math.min(typeof window !== "undefined" ? window.devicePixelRatio : 1, 1.5);

  const handleCreated = useCallback((state: any) => {
    try {
      const canvas = state.gl.domElement as HTMLCanvasElement;
      canvas.addEventListener("webglcontextlost", (e: Event) => {
        e.preventDefault();
        onError();
      });
    } catch {
      onError();
    }
  }, [onError]);

  return (
    <Suspense fallback={<CSSFallback />}>
      <LazyCanvas
        dpr={dpr}
        camera={{ position: [0, 0, 4], fov: 50 }}
        gl={{
          antialias: false,
          alpha: true,
          powerPreference: "low-power",
          stencil: false,
          depth: false,
        }}
        style={{
          position: "absolute",
          inset: 0,
          width: "100%",
          height: "100%",
          pointerEvents: "none",
        }}
        frameloop="always"
        onCreated={handleCreated}
        data-testid="hero-webgl-canvas"
      >
        <Suspense fallback={null}>
          <LazyScene mobile={mobile} />
        </Suspense>
      </LazyCanvas>
    </Suspense>
  );
}

const MemoizedCanvas = memo(WebGLCanvas);

export function WebGLBackdrop() {
  const [shouldRender, setShouldRender] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [webglFailed, setWebglFailed] = useState(false);

  const handleWebGLError = useCallback(() => {
    setWebglFailed(true);
  }, []);

  useEffect(() => {
    if (!ENABLE_WEBGL_HERO) return;
    const reducedMotion = detectReducedMotion();
    const lowPower = detectLowPower();
    const webglOk = detectWebGLSupport();

    if (reducedMotion || lowPower || !webglOk) {
      setShouldRender(false);
    } else {
      setIsMobile(window.innerWidth <= 1024);
      setShouldRender(true);
    }
  }, []);

  if (!ENABLE_WEBGL_HERO || !shouldRender || webglFailed) return <CSSFallback />;

  return (
    <div
      className="absolute inset-0 z-0"
      aria-hidden="true"
      data-testid="hero-webgl-backdrop"
    >
      <MemoizedCanvas mobile={isMobile} onError={handleWebGLError} />
    </div>
  );
}
