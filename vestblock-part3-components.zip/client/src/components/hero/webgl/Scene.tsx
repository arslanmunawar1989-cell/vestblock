import { useRef, useMemo } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { waveVertexShader, waveFragmentShader, VEST_COLORS } from "./Shaders";

function GlassWave({ mobile }: { mobile: boolean }) {
  const meshRef = useRef<THREE.Mesh>(null);
  const segments = mobile ? 32 : 56;

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uAmplitude: { value: 0.14 },
      uFrequency: { value: 1.6 },
      uColorLow: { value: new THREE.Color(...VEST_COLORS.g0) },
      uColorMid: { value: new THREE.Color(...VEST_COLORS.g1) },
      uColorHigh: { value: new THREE.Color(...VEST_COLORS.g2) },
      uOpacity: { value: 0.2 },
    }),
    []
  );

  useFrame((_, delta) => {
    uniforms.uTime.value += delta;
  });

  return (
    <mesh ref={meshRef} rotation={[-Math.PI * 0.32, 0, 0.12]} position={[0, -0.6, -1.2]}>
      <planeGeometry args={[10, 7, segments, segments]} />
      <shaderMaterial
        vertexShader={waveVertexShader}
        fragmentShader={waveFragmentShader}
        uniforms={uniforms}
        transparent
        side={THREE.DoubleSide}
        depthWrite={false}
      />
    </mesh>
  );
}

function Orb({
  position,
  color,
  scale,
  speed,
  offset,
  motionRadius = [0.3, 0.25, 0.15],
  opacityRange = [0.06, 0.12],
}: {
  position: [number, number, number];
  color: [number, number, number];
  scale: number;
  speed: number;
  offset: number;
  motionRadius?: [number, number, number];
  opacityRange?: [number, number];
}) {
  const ref = useRef<THREE.Mesh>(null);
  const matRef = useRef<THREE.MeshBasicMaterial>(null);

  useFrame(({ clock }) => {
    if (!ref.current || !matRef.current) return;
    const t = clock.getElapsedTime() * speed + offset;

    ref.current.position.x = position[0] + Math.sin(t) * motionRadius[0] + Math.sin(t * 0.6 + 1.5) * motionRadius[0] * 0.4;
    ref.current.position.y = position[1] + Math.cos(t * 0.7) * motionRadius[1] + Math.cos(t * 0.4 + 2.0) * motionRadius[1] * 0.3;
    ref.current.position.z = position[2] + Math.sin(t * 0.5 + 0.8) * motionRadius[2];

    const breathScale = scale * (1 + Math.sin(t * 0.3) * 0.06 + Math.cos(t * 0.18) * 0.04);
    ref.current.scale.setScalar(breathScale);

    const opMin = opacityRange[0];
    const opMax = opacityRange[1];
    matRef.current.opacity = opMin + (opMax - opMin) * (0.5 + 0.5 * Math.sin(t * 0.25 + offset));
  });

  return (
    <mesh ref={ref} position={position} scale={scale}>
      <sphereGeometry args={[1, 20, 20]} />
      <meshBasicMaterial
        ref={matRef}
        color={new THREE.Color(...color)}
        transparent
        opacity={opacityRange[0]}
      />
    </mesh>
  );
}

function MouseParallaxRig({ children }: { children: React.ReactNode }) {
  const groupRef = useRef<THREE.Group>(null);
  const { pointer } = useThree();
  const target = useRef({ x: 0, y: 0 });

  useFrame(() => {
    if (!groupRef.current) return;
    target.current.x += (pointer.x * 0.06 - target.current.x) * 0.015;
    target.current.y += (pointer.y * 0.04 - target.current.y) * 0.015;
    groupRef.current.rotation.y = target.current.x;
    groupRef.current.rotation.x = -target.current.y;
  });

  return <group ref={groupRef}>{children}</group>;
}

export default function Scene({ mobile }: { mobile: boolean }) {
  return (
    <>
      <MouseParallaxRig>
        <GlassWave mobile={mobile} />
        <Orb position={[-2.8, 1.4, -2]} color={VEST_COLORS.g1} scale={1.3} speed={0.08} offset={0}
          motionRadius={[0.5, 0.4, 0.2]} opacityRange={[0.05, 0.12]} />
        <Orb position={[2.2, -0.6, -2.5]} color={VEST_COLORS.g2} scale={1.6} speed={0.06} offset={2.5}
          motionRadius={[0.6, 0.35, 0.25]} opacityRange={[0.04, 0.10]} />
        <Orb position={[0.5, 2.0, -1.5]} color={VEST_COLORS.g0} scale={1.0} speed={0.10} offset={4.2}
          motionRadius={[0.35, 0.3, 0.15]} opacityRange={[0.06, 0.14]} />
        <Orb position={[-1.8, -1.2, -3]} color={VEST_COLORS.g3} scale={1.1} speed={0.05} offset={1.3}
          motionRadius={[0.4, 0.5, 0.2]} opacityRange={[0.04, 0.09]} />
        <Orb position={[1.0, 0.8, -2.8]} color={VEST_COLORS.g4} scale={0.8} speed={0.07} offset={3.7}
          motionRadius={[0.3, 0.25, 0.18]} opacityRange={[0.03, 0.08]} />
      </MouseParallaxRig>
      <ambientLight intensity={0.35} />
    </>
  );
}
