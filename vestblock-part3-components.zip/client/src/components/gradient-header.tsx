import { cn } from "@/lib/utils";

interface GradientHeaderProps {
  children: React.ReactNode;
  className?: string;
}

export function GradientHeader({ children, className }: GradientHeaderProps) {
  return (
    <div
      className={cn(
        "gradient-hero text-white px-6 py-8 rounded-md",
        className
      )}
      data-testid="gradient-header"
    >
      {children}
    </div>
  );
}
