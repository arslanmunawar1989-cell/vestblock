import { useState, useRef } from "react";
import { useUpload } from "@/hooks/use-upload";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { GlassCard } from "@/components/glass-card";
import { Upload, FileText, CheckCircle2, X, Loader2, AlertCircle } from "lucide-react";

interface UploadedDoc {
  id: string;
  type: string;
  fileName: string;
  url: string;
  objectPath: string;
}

interface KycDocumentUploadProps {
  docType: string;
  label: string;
  description: string;
  accept?: string;
  kycProfileId?: string;
  onUploaded: (doc: UploadedDoc) => void;
  existingDoc?: UploadedDoc | null;
}

export function KycDocumentUpload({
  docType,
  label,
  description,
  accept = "image/*,application/pdf",
  kycProfileId,
  onUploaded,
  existingDoc,
}: KycDocumentUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadedDoc, setUploadedDoc] = useState<UploadedDoc | null>(existingDoc || null);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const { uploadFile, isUploading, progress } = useUpload({
    onSuccess: async (response) => {
      try {
        const docRes = await apiRequest("POST", "/api/documents", {
          type: docType,
          url: response.objectPath,
          fileName: response.metadata.name,
          fileSize: response.metadata.size,
          mimeType: response.metadata.contentType,
          status: "uploaded",
          kycProfileId: kycProfileId || null,
        });
        const doc = await docRes.json();
        const uploaded = { id: doc.id, type: docType, fileName: response.metadata.name, url: response.objectPath, objectPath: response.objectPath };
        setUploadedDoc(uploaded);
        setUploadError(null);
        onUploaded(uploaded);
      } catch (err: any) {
        setUploadError("File uploaded but failed to save record. Please try again.");
      }
    },
    onError: (err) => {
      setUploadError(err.message || "Upload failed");
    },
  });

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadError(null);
    await uploadFile(file);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleRemove = () => {
    setUploadedDoc(null);
    setUploadError(null);
  };

  return (
    <GlassCard className="relative">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center flex-shrink-0">
          <FileText className="w-5 h-5 text-muted-foreground" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium">{label}</p>
          <p className="text-xs text-muted-foreground">{description}</p>

          {uploadedDoc ? (
            <div className="mt-2 flex items-center gap-2 p-2 bg-emerald-50 dark:bg-emerald-900/20 rounded-md">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 flex-shrink-0" />
              <span className="text-xs text-emerald-700 dark:text-emerald-300 truncate" data-testid={`text-uploaded-${docType}`}>
                {uploadedDoc.fileName}
              </span>
              <Button
                type="button"
                size="icon"
                variant="ghost"
                className="ml-auto flex-shrink-0"
                onClick={handleRemove}
                data-testid={`button-remove-${docType}`}
              >
                <X className="w-3 h-3" />
              </Button>
            </div>
          ) : isUploading ? (
            <div className="mt-2 space-y-1">
              <div className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-primary" />
                <span className="text-xs text-muted-foreground">Uploading... {progress}%</span>
              </div>
              <div className="w-full bg-muted rounded-sm h-1">
                <div className="bg-primary h-1 rounded-sm transition-all" style={{ width: `${progress}%` }} />
              </div>
            </div>
          ) : (
            <div className="mt-2">
              <input
                ref={fileInputRef}
                type="file"
                accept={accept}
                onChange={handleFileSelect}
                className="hidden"
                data-testid={`input-file-${docType}`}
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
                data-testid={`button-upload-${docType}`}
              >
                <Upload className="w-3 h-3 mr-1" />
                Choose File
              </Button>
            </div>
          )}

          {uploadError && (
            <div className="mt-1 flex items-center gap-1 text-xs text-destructive">
              <AlertCircle className="w-3 h-3" />
              {uploadError}
            </div>
          )}
        </div>
      </div>
    </GlassCard>
  );
}
