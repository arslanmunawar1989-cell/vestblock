import { useState, useEffect } from "react";
import { onSwUpdate, skipWaiting } from "@/lib/sw-register";

export function SwUpdateToast() {
  const [registration, setRegistration] = useState<ServiceWorkerRegistration | null>(null);

  useEffect(() => {
    onSwUpdate((reg) => setRegistration(reg));
  }, []);

  if (!registration) return null;

  return (
    <div
      data-testid="sw-update-toast"
      style={{
        position: "fixed",
        bottom: "1rem",
        right: "1rem",
        zIndex: 99999,
        background: "#1E2BFF",
        color: "#fff",
        borderRadius: "0.75rem",
        padding: "0.875rem 1.25rem",
        display: "flex",
        alignItems: "center",
        gap: "0.75rem",
        boxShadow: "0 8px 30px rgba(30,43,255,0.25)",
        fontFamily: "'Plus Jakarta Sans', sans-serif",
        fontSize: "0.875rem",
        maxWidth: "360px",
      }}
    >
      <span style={{ flex: 1 }}>A new version is available.</span>
      <button
        data-testid="button-sw-update"
        onClick={() => skipWaiting(registration)}
        style={{
          background: "rgba(255,255,255,0.2)",
          color: "#fff",
          border: "none",
          borderRadius: "0.5rem",
          padding: "0.375rem 0.875rem",
          cursor: "pointer",
          fontWeight: 600,
          fontSize: "0.8125rem",
          whiteSpace: "nowrap",
        }}
      >
        Update
      </button>
      <button
        data-testid="button-sw-dismiss"
        onClick={() => setRegistration(null)}
        style={{
          background: "none",
          color: "rgba(255,255,255,0.7)",
          border: "none",
          cursor: "pointer",
          fontSize: "1.125rem",
          lineHeight: 1,
          padding: "0 0.25rem",
        }}
        aria-label="Dismiss"
      >
        &times;
      </button>
    </div>
  );
}
