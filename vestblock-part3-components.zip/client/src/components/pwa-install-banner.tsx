import { useState, useEffect } from "react";
import { X, Share, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";

function isIos(): boolean {
  return /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
}

function isInStandaloneMode(): boolean {
  return (
    ("standalone" in window.navigator && (window.navigator as any).standalone) ||
    window.matchMedia("(display-mode: standalone)").matches
  );
}

export function PwaInstallBanner() {
  const [show, setShow] = useState(false);
  const [platform, setPlatform] = useState<"ios" | "android" | null>(null);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    if (isInStandaloneMode()) return;

    const dismissed = sessionStorage.getItem("pwa-banner-dismissed");
    if (dismissed) return;

    if (isIos()) {
      setPlatform("ios");
      setShow(true);
      return;
    }

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setPlatform("android");
      setShow(true);
    };

    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const dismiss = () => {
    setShow(false);
    sessionStorage.setItem("pwa-banner-dismissed", "1");
  };

  const installAndroid = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    setDeferredPrompt(null);
    dismiss();
  };

  if (!show) return null;

  return (
    <div
      className="fixed bottom-0 left-0 right-0 z-50 border-t bg-card p-4 shadow-lg"
      data-testid="pwa-install-banner"
    >
      <div className="mx-auto flex max-w-lg items-start gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-primary/10">
          <Plus className="h-5 w-5 text-primary" />
        </div>
        <div className="flex-1">
          <p className="text-sm font-medium" data-testid="text-install-title">
            Install VestBlock
          </p>
          {platform === "ios" ? (
            <p className="mt-1 text-xs text-muted-foreground" data-testid="text-install-instructions">
              Tap the <Share className="inline h-3.5 w-3.5 -mt-0.5" /> share button in Safari, then select
              &quot;Add to Home Screen&quot; to install this app.
            </p>
          ) : (
            <div className="mt-2">
              <Button
                size="sm"
                onClick={installAndroid}
                data-testid="button-install-pwa"
              >
                Install App
              </Button>
            </div>
          )}
        </div>
        <Button
          size="icon"
          variant="ghost"
          onClick={dismiss}
          data-testid="button-dismiss-install"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
