import { useLocation, Link } from "wouter";
import { cn } from "@/lib/utils";
import type { Role } from "@shared/schema";
import { roleNavItems, roleLabels, getFilteredNavItems } from "@/lib/rbac";
import { PLATFORM_ROLE_LABELS } from "@shared/constants";
import { useAuth } from "@/lib/auth";
import { ThemeToggle } from "./theme-toggle";
import { NotificationBell } from "./notification-bell";
import { MobileBottomNav } from "./mobile-bottom-nav";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import {
  LayoutDashboard,
  PieChart,
  Wallet,
  Store,
  ShieldCheck,
  Banknote,
  Users,
  Blocks,
  Shield,
  DollarSign,
  Target,
  FileText,
  Handshake,
  LogOut,
  ChevronDown,
  Database,
  Settings,
  Calculator,
  ArrowDownLeft,
  CreditCard,
  Building2,
  AlertTriangle,
  ArrowLeftRight,
  Globe,
  RefreshCcw,
  FileSpreadsheet,
  Link2,
  MessageSquare,
  Activity,
  Award,
  Coins,
  ScanLine,
  Landmark,
  TrendingUp,
  TrendingDown,
  LineChart,
  FolderOpen,
  FolderKanban,
  Home,
  Receipt,
  Gavel,
  BarChart3,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const iconMap: Record<string, any> = {
  LayoutDashboard,
  PieChart,
  Wallet,
  Store,
  ShieldCheck,
  Banknote,
  Users,
  Blocks,
  Shield,
  DollarSign,
  Target,
  FileText,
  Handshake,
  Database,
  Settings,
  Calculator,
  ArrowDownLeft,
  CreditCard,
  Building2,
  AlertTriangle,
  ArrowLeftRight,
  Globe,
  RefreshCcw,
  FileSpreadsheet,
  Link2,
  MessageSquare,
  Activity,
  Award,
  Coins,
  ScanLine,
  Landmark,
  TrendingUp,
  TrendingDown,
  LineChart,
  FolderOpen,
  FolderKanban,
  Home,
  Receipt,
  Gavel,
  BarChart3,
};

interface RoleLayoutProps {
  role: Role;
  children: React.ReactNode;
}

export function RoleLayout({ role, children }: RoleLayoutProps) {
  const [location] = useLocation();
  const { user, logout, impersonating, tenantRole } = useAuth();
  const rawNavItems = roleNavItems[role];
  const navItems = role === "admin"
    ? getFilteredNavItems(rawNavItems, user?.platformRole || null, tenantRole)
    : rawNavItems;

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3.5rem",
  };

  const displayName = user?.fullName || `Demo ${roleLabels[role]}`;
  const displayEmail = user?.email || "demo@vestblock.io";
  const initials = displayName
    .split(" ")
    .map((n) => n[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <Sidebar>
          <SidebarHeader className="p-4">
            <Link href="/">
              <div className="flex items-center gap-2 cursor-pointer" data-testid="link-home">
                <div className="w-8 h-8 rounded-md gradient-hero flex items-center justify-center">
                  <span className="text-white font-bold text-sm">V</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-sm font-bold tracking-tight">VestBlock</span>
                  <span className="text-xs text-muted-foreground">Investment Platform</span>
                </div>
              </div>
            </Link>
          </SidebarHeader>

          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel>{roleLabels[role]} Menu</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navItems.map((item) => {
                    const Icon = iconMap[item.icon] || LayoutDashboard;
                    const isActive = location === item.path;
                    return (
                      <SidebarMenuItem key={item.path}>
                        <SidebarMenuButton
                          asChild
                          isActive={isActive}
                        >
                          <Link href={item.path}>
                            <Icon className="w-4 h-4" />
                            <span>{item.label}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    );
                  })}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="p-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 w-full p-2 rounded-md text-left hover-elevate" data-testid="button-user-menu">
                  <Avatar className="w-8 h-8">
                    <AvatarFallback className="bg-primary/10 text-primary text-xs font-semibold">
                      {initials}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate" data-testid="text-user-name">{displayName}</p>
                    <p className="text-xs text-muted-foreground truncate">{displayEmail}</p>
                  </div>
                  <ChevronDown className="w-4 h-4 text-muted-foreground" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => logout()}
                  data-testid="menu-item-logout"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarFooter>
        </Sidebar>

        <div className="flex flex-col flex-1 min-w-0">
          {impersonating && (
            <div className="bg-amber-500 text-white text-center py-1 px-3 text-sm font-medium sticky top-0 z-[60]" data-testid="banner-impersonation">
              Viewing as tenant admin (impersonating) — Logged in as {impersonating.impersonatorUsername}
              <Button
                size="sm"
                variant="outline"
                className="ml-3 border-white text-white"
                onClick={async () => {
                  const res = await fetch("/api/tenants/stop-impersonation", { method: "POST", credentials: "include" });
                  if (res.ok) {
                    window.location.href = "/admin/tenants";
                  }
                }}
                data-testid="button-stop-impersonation"
              >
                Exit
              </Button>
            </div>
          )}
          <header className="flex items-center justify-between gap-4 p-3 border-b sticky top-0 z-50 bg-background/80 backdrop-blur-sm">
            <div className="flex items-center gap-2">
              <SidebarTrigger data-testid="button-sidebar-toggle" />
              <Badge variant="secondary" className="text-xs hidden sm:inline-flex" data-testid="badge-role">
                {user?.platformRole ? (PLATFORM_ROLE_LABELS[user.platformRole] || roleLabels[role]) : roleLabels[role]}
              </Badge>
            </div>
            <div className="flex items-center gap-1">
              <NotificationBell />
              <ThemeToggle />
            </div>
          </header>
          <main className="flex-1 overflow-auto">
            <div className="p-4 sm:p-6 max-w-7xl mx-auto gradient-bg min-h-full pb-20 md:pb-6">
              {children}
            </div>
          </main>
        </div>
      </div>
      <MobileBottomNav />
    </SidebarProvider>
  );
}
