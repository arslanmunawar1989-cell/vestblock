import { Plus, Search, FileText, Trash2, Moon, Sun } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { useCreateNote, useNotes } from "@/hooks/use-notes";
import { formatDistanceToNow } from "date-fns";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";

export function Sidebar() {
  const [location, setLocation] = useLocation();
  const { data: notes, isLoading } = useNotes();
  const { mutate: createNote, isPending: isCreating } = useCreateNote();
  const [search, setSearch] = useState("");
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    // Check system preference on mount
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setIsDark(true);
      document.documentElement.classList.add("dark");
    }
  }, []);

  const toggleTheme = () => {
    setIsDark(!isDark);
    document.documentElement.classList.toggle("dark");
  };

  const handleCreate = () => {
    createNote(
      { title: "Untitled Note", content: "" },
      {
        onSuccess: (note) => {
          setLocation(`/note/${note.id}`);
        },
      }
    );
  };

  const filteredNotes = notes?.filter((note) =>
    note.title.toLowerCase().includes(search.toLowerCase()) ||
    note.content.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="w-80 h-screen border-r border-border bg-muted/30 flex flex-col backdrop-blur-xl">
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center shadow-lg shadow-primary/20">
              <FileText className="w-5 h-5 text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-display font-bold text-foreground tracking-tight">
              Scribe
            </h1>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            className="rounded-full hover:bg-muted"
          >
            {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </Button>
        </div>

        <Button 
          onClick={handleCreate} 
          disabled={isCreating}
          className="w-full h-11 rounded-xl bg-primary text-primary-foreground shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5 transition-all duration-200"
        >
          {isCreating ? "Creating..." : (
            <>
              <Plus className="w-4 h-4 mr-2" /> New Note
            </>
          )}
        </Button>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search notes..." 
            className="pl-9 h-10 rounded-xl bg-background/50 border-border/50 focus:bg-background transition-all"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <ScrollArea className="flex-1 px-4">
        {isLoading ? (
          <div className="space-y-3 px-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-24 rounded-xl border border-border/40 p-4 space-y-3">
                <Skeleton className="h-4 w-2/3" />
                <Skeleton className="h-3 w-full" />
                <Skeleton className="h-3 w-1/3" />
              </div>
            ))}
          </div>
        ) : filteredNotes?.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-40 text-muted-foreground px-4 text-center">
            <p className="text-sm">No notes found.</p>
            {search && <p className="text-xs mt-1 opacity-70">Try a different search term.</p>}
          </div>
        ) : (
          <div className="space-y-2 pb-6 px-2">
            {filteredNotes?.map((note) => {
              const isActive = location === `/note/${note.id}`;
              return (
                <Link key={note.id} href={`/note/${note.id}`}>
                  <div
                    className={cn(
                      "group p-4 rounded-xl border transition-all duration-200 cursor-pointer relative overflow-hidden",
                      isActive
                        ? "bg-background border-primary/50 shadow-md shadow-black/5"
                        : "bg-transparent border-transparent hover:bg-background/60 hover:border-border/50"
                    )}
                  >
                    {isActive && (
                      <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary" />
                    )}
                    <h3 className={cn(
                      "font-semibold mb-1 truncate pr-4",
                      isActive ? "text-primary" : "text-foreground group-hover:text-primary transition-colors"
                    )}>
                      {note.title || "Untitled Note"}
                    </h3>
                    <p className="text-sm text-muted-foreground truncate mb-3 h-5">
                      {note.content.replace(/<[^>]*>?/gm, '') || "No additional text"}
                    </p>
                    <div className="flex items-center justify-between text-xs text-muted-foreground/70">
                      <span>
                        {note.createdAt && formatDistanceToNow(new Date(note.createdAt), { addSuffix: true })}
                      </span>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}
