import { cn } from "@/lib/utils";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export interface Column<T> {
  header: string;
  accessor: keyof T | ((row: T) => React.ReactNode);
  className?: string;
}

interface DataTableProps<T> {
  columns: Column<T>[];
  data: T[];
  className?: string;
  emptyMessage?: string;
  onRowClick?: (row: T) => void;
}

export function DataTable<T extends Record<string, any>>({
  columns,
  data,
  className,
  emptyMessage = "No data available",
  onRowClick,
}: DataTableProps<T>) {
  return (
    <div className={cn("glass-card rounded-md overflow-hidden", className)} data-testid="data-table">
      <Table>
        <TableHeader>
          <TableRow className="border-b border-border/50">
            {columns.map((col, i) => (
              <TableHead
                key={i}
                className={cn("text-xs font-semibold uppercase tracking-wider text-muted-foreground", col.className)}
              >
                {col.header}
              </TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.length === 0 ? (
            <TableRow>
              <TableCell colSpan={columns.length} className="text-center py-8 text-muted-foreground">
                {emptyMessage}
              </TableCell>
            </TableRow>
          ) : (
            data.map((row, rowIndex) => (
              <TableRow
                key={rowIndex}
                className={cn(
                  "border-b border-border/30",
                  onRowClick && "cursor-pointer hover-elevate"
                )}
                onClick={() => onRowClick?.(row)}
                data-testid={`table-row-${rowIndex}`}
              >
                {columns.map((col, colIndex) => (
                  <TableCell key={colIndex} className={cn("text-sm", col.className)}>
                    {typeof col.accessor === "function"
                      ? col.accessor(row)
                      : row[col.accessor as string]}
                  </TableCell>
                ))}
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}
