import { cn } from "@/lib/utils";
import { Card } from "@/components/ui/card";

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  padding?: "sm" | "md" | "lg";
}

export function GlassCard({ children, className, padding = "md", ...props }: GlassCardProps & React.HTMLAttributes<HTMLDivElement>) {
  const paddingClass = {
    sm: "p-3",
    md: "p-5",
    lg: "p-7",
  }[padding];

  return (
    <Card
      className={cn(
        "glass-light glass-noise",
        paddingClass,
        className
      )}
      data-testid="glass-card"
      {...props}
    >
      {children}
    </Card>
  );
}
