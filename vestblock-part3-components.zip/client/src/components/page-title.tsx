import { cn } from "@/lib/utils";

interface PageTitleProps {
  title: string;
  description?: string;
  action?: React.ReactNode;
  className?: string;
}

export function PageTitle({ title, description, action, className }: PageTitleProps) {
  return (
    <div className={cn("flex items-start justify-between gap-4 flex-wrap", className)}>
      <div>
        <h1 className="text-2xl font-bold tracking-tight" data-testid="page-title">
          {title}
        </h1>
        {description && (
          <p className="text-sm text-muted-foreground mt-1" data-testid="page-description">
            {description}
          </p>
        )}
      </div>
      {action}
    </div>
  );
}
