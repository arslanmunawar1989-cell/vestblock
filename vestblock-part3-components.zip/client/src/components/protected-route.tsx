import { useAuth } from "@/lib/auth";
import { Redirect } from "wouter";
import type { Role } from "@shared/schema";
import type { PlatformRole } from "@shared/constants";

const PLATFORM_ADMIN_ROLES: PlatformRole[] = ["SUPER_ADMIN", "PLATFORM_ADMIN", "PLATFORM_FINANCE", "PLATFORM_COMPLIANCE"];

interface ProtectedRouteProps {
  children: React.ReactNode;
  role?: Role;
  requirePlatformRole?: PlatformRole[];
}

export function ProtectedRoute({ children, role, requirePlatformRole }: ProtectedRouteProps) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-3 border-primary/30 border-t-primary rounded-full animate-spin" />
          <p className="text-sm text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Redirect to="/login" />;
  }

  if (requirePlatformRole && requirePlatformRole.length > 0) {
    if (!user.platformRole || !requirePlatformRole.includes(user.platformRole)) {
      return <Redirect to={`/${user.role}`} />;
    }
    return <>{children}</>;
  }

  if (role === "admin") {
    if (user.role === "admin") return <>{children}</>;
    if (user.platformRole && PLATFORM_ADMIN_ROLES.includes(user.platformRole)) return <>{children}</>;
    return <Redirect to={`/${user.role}`} />;
  }

  if (role && user.role !== role && user.role !== "admin") {
    return <Redirect to={`/${user.role}`} />;
  }

  return <>{children}</>;
}
