import { cn } from "@/lib/utils";
import { GlassCard } from "./glass-card";
import {
  TrendingUp,
  TrendingDown,
  Minus,
} from "lucide-react";

interface StatTileProps {
  label: string;
  value: string;
  change?: string;
  trend?: "up" | "down" | "neutral";
  icon?: React.ReactNode;
  className?: string;
}

export function StatTile({
  label,
  value,
  change,
  trend = "neutral",
  icon,
  className,
}: StatTileProps) {
  const trendColor = {
    up: "text-emerald-600 dark:text-emerald-400",
    down: "text-red-500 dark:text-red-400",
    neutral: "text-muted-foreground",
  }[trend];

  const TrendIcon = {
    up: TrendingUp,
    down: TrendingDown,
    neutral: Minus,
  }[trend];

  return (
    <GlassCard className={cn("flex flex-col gap-3", className)} padding="md">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <span className="text-sm text-muted-foreground font-medium" data-testid={`stat-label-${label.toLowerCase().replace(/\s/g, '-')}`}>
          {label}
        </span>
        {icon && (
          <div className="flex items-center justify-center w-9 h-9 rounded-md bg-primary/10 text-primary">
            {icon}
          </div>
        )}
      </div>
      <div className="flex items-end justify-between gap-2 flex-wrap">
        <span className="text-2xl font-bold tracking-tight" data-testid={`stat-value-${label.toLowerCase().replace(/\s/g, '-')}`}>
          {value}
        </span>
        {change && (
          <div className={cn("flex items-center gap-1 text-xs font-medium", trendColor)}>
            <TrendIcon className="w-3 h-3" />
            <span>{change}</span>
          </div>
        )}
      </div>
    </GlassCard>
  );
}
