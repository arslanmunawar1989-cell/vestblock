import { useLocation, Link } from "wouter";
import { cn } from "@/lib/utils";
import { useAuth } from "@/lib/auth";
import type { Role } from "@shared/schema";
import {
  LayoutDashboard,
  PieChart,
  Wallet,
  Store,
  Users,
  Shield,
  DollarSign,
  Blocks,
  Handshake,
  Globe,
  Settings,
  Menu,
} from "lucide-react";
import { useState } from "react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { roleNavItems, roleLabels } from "@/lib/rbac";
import { ScrollArea } from "@/components/ui/scroll-area";

interface MobileNavItem {
  label: string;
  path: string;
  icon: any;
}

const mobileNavConfig: Record<Role, MobileNavItem[]> = {
  investor: [
    { label: "Home", path: "/investor", icon: LayoutDashboard },
    { label: "Portfolio", path: "/investor/portfolio", icon: PieChart },
    { label: "Wallet", path: "/investor/wallet", icon: Wallet },
    { label: "Market", path: "/investor/marketplace", icon: Store },
  ],
  admin: [
    { label: "Home", path: "/admin", icon: LayoutDashboard },
    { label: "Users", path: "/admin/users", icon: Users },
    { label: "Compliance", path: "/admin/compliance", icon: Shield },
    { label: "Finance", path: "/admin/finance", icon: DollarSign },
  ],
  issuer: [
    { label: "Home", path: "/issuer", icon: LayoutDashboard },
    { label: "Assets", path: "/issuer/assets", icon: Blocks },
    { label: "Rounds", path: "/issuer/rounds", icon: DollarSign },
    { label: "Docs", path: "/issuer/docs", icon: Settings },
  ],
  agent: [
    { label: "Home", path: "/agent", icon: LayoutDashboard },
    { label: "Offers", path: "/agent/offers", icon: Handshake },
    { label: "Clients", path: "/agent/clients", icon: Users },
    { label: "Market", path: "/agent/marketplace", icon: Globe },
  ],
};

const iconMap: Record<string, any> = {
  LayoutDashboard, PieChart, Wallet, Store, Users, Shield, DollarSign, Blocks,
  Handshake, Globe, Settings, Menu,
};

export function MobileBottomNav() {
  const [location] = useLocation();
  const { user } = useAuth();
  const [sheetOpen, setSheetOpen] = useState(false);

  if (!user) return null;

  const role = user.role as Role;
  const items = mobileNavConfig[role] || mobileNavConfig.investor;
  const allItems = roleNavItems[role] || [];

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-50 border-t bg-background/95 backdrop-blur-md md:hidden"
      data-testid="mobile-bottom-nav"
    >
      <div className="flex items-stretch justify-around">
        {items.map((item) => {
          const isActive = location === item.path;
          const Icon = item.icon;
          return (
            <Link key={item.path} href={item.path}>
              <button
                className={cn(
                  "flex flex-col items-center justify-center gap-0.5 py-2 px-3 min-w-0 flex-1 transition-colors",
                  isActive
                    ? "text-primary"
                    : "text-muted-foreground"
                )}
                data-testid={`mobile-nav-${item.label.toLowerCase()}`}
              >
                <Icon className="h-5 w-5" />
                <span className="text-[10px] font-medium leading-tight truncate">
                  {item.label}
                </span>
              </button>
            </Link>
          );
        })}

        <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
          <SheetTrigger asChild>
            <button
              className="flex flex-col items-center justify-center gap-0.5 py-2 px-3 min-w-0 flex-1 text-muted-foreground transition-colors"
              data-testid="mobile-nav-more"
            >
              <Menu className="h-5 w-5" />
              <span className="text-[10px] font-medium leading-tight">More</span>
            </button>
          </SheetTrigger>
          <SheetContent side="bottom" className="h-[70vh] rounded-t-xl">
            <SheetHeader className="pb-2">
              <SheetTitle>{roleLabels[role]} Menu</SheetTitle>
            </SheetHeader>
            <ScrollArea className="h-full pb-8">
              <div className="grid grid-cols-3 gap-2 p-1">
                {allItems.map((item) => {
                  const Icon = iconMap[item.icon] || LayoutDashboard;
                  const isActive = location === item.path;
                  return (
                    <Link key={item.path} href={item.path}>
                      <button
                        onClick={() => setSheetOpen(false)}
                        className={cn(
                          "flex flex-col items-center gap-1.5 p-3 rounded-md w-full transition-colors",
                          isActive
                            ? "bg-primary/10 text-primary"
                            : "text-muted-foreground hover-elevate"
                        )}
                        data-testid={`mobile-menu-${item.label.toLowerCase().replace(/[^a-z0-9]/g, "-")}`}
                      >
                        <Icon className="h-5 w-5" />
                        <span className="text-[11px] font-medium text-center leading-tight">
                          {item.label}
                        </span>
                      </button>
                    </Link>
                  );
                })}
              </div>
            </ScrollArea>
          </SheetContent>
        </Sheet>
      </div>
    </nav>
  );
}
