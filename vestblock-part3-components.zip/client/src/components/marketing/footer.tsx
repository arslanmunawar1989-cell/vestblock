import { Link } from "wouter";
import { useState } from "react";
import { useRegion } from "@/lib/region";
import { ArrowRight, Mail } from "lucide-react";

const footerSections = [
  {
    title: "Platform",
    links: [
      { label: "How It Works", href: "/how-it-works" },
      { label: "Properties", href: "/properties" },
      { label: "Tokenization", href: "/tokenization" },
      { label: "ROI Calculator", href: "/roi-calculator" },
      { label: "Fees & Pricing", href: "/fees" },
      { label: "Exit Windows", href: "/exit-windows" },
      { label: "Mobile App", href: "/mobile-app" },
    ],
  },
  {
    title: "Solutions",
    links: [
      { label: "For Agencies", href: "/for-agencies" },
      { label: "For Sellers", href: "/for-sellers" },
      { label: "For Developers", href: "/for-developers" },
      { label: "Institutions", href: "/institutions" },
      { label: "API / Developers", href: "/developers" },
    ],
  },
  {
    title: "Resources",
    links: [
      { label: "Blog & Insights", href: "/blog" },
      { label: "Investor Guides", href: "/guides" },
      { label: "FAQ", href: "/faq" },
      { label: "Glossary", href: "/glossary" },
      { label: "Media & Press", href: "/media" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About", href: "/about" },
      { label: "Careers", href: "/careers" },
      { label: "Partners", href: "/partners" },
      { label: "Contact", href: "/contact" },
      { label: "Market Overview", href: "/market" },
    ],
  },
];

const legalLinks = [
  { label: "Terms of Service", href: "/terms" },
  { label: "Privacy Policy", href: "/privacy" },
  { label: "Cookie Policy", href: "/legal/cookies" },
  { label: "Risk Disclosure", href: "/risk-disclosure" },
  { label: "Risk Warnings", href: "/risk-warnings" },
  { label: "Security", href: "/security" },
  { label: "Compliance", href: "/compliance" },
  { label: "Legal", href: "/legal" },
];

export function MarketingFooter() {
  const { region } = useRegion();
  const [email, setEmail] = useState("");

  const isPK = region.code === "pk";
  const companyName = isPK
    ? "VestBlock Technologies (Pvt.) Ltd."
    : "VestBlock Technologies DMCC.";
  const regBody = isPK
    ? "Securities and Exchange Commission of Pakistan (SECP)"
    : "Dubai Financial Services Authority (DFSA)";

  return (
    <footer className="border-t border-vest-g5/[0.08] bg-vest-g1/30" data-testid="marketing-footer">
      <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-16">
        <div className="py-16 border-b border-vest-g5/[0.08]">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            <div>
              <h3 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight">
                Stay Updated on New{" "}
                <span className="text-vest-g5">Opportunities</span>
              </h3>
              <p className="text-sm text-ink-muted mt-3 max-w-md">
                Get notified about new property listings, platform updates, and investment insights.
              </p>
            </div>
            <form
              onSubmit={(e) => { e.preventDefault(); setEmail(""); }}
              className="flex items-center gap-3"
            >
              <div className="relative flex-1">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-muted/50" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  required
                  className="w-full pl-11 pr-4 py-3.5 text-sm rounded-md bg-white/50 border border-vest-g5/15 text-ink-dark placeholder:text-ink-muted/50 focus:outline-none focus:border-vest-g5/40 backdrop-blur-sm"
                  data-testid="footer-newsletter-email"
                />
              </div>
              <button
                type="submit"
                className="glass-btn-primary inline-flex items-center gap-2 rounded-md px-6 py-3.5 text-sm font-medium shrink-0"
                data-testid="footer-newsletter-submit"
              >
                Subscribe <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>

        <div className="py-16 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
          <div className="col-span-2 md:col-span-4 lg:col-span-1 mb-4 lg:mb-0">
            <Link href="/" className="flex items-center gap-2.5 mb-4">
              <div className="w-8 h-8 rounded-md flex items-center justify-center bg-vest-g5">
                <span className="font-bold text-sm text-white">V</span>
              </div>
              <span className="text-ink-dark font-semibold text-base tracking-tight">VestBlock</span>
            </Link>
            <p className="text-sm text-ink-muted leading-relaxed max-w-xs">
              {isPK
                ? "Pakistan's premier tokenized real estate platform. Invest from PKR 50,000."
                : "UAE's upcoming real estate tokenization platform. Invest from AED 1,000."}
            </p>
          </div>

          {footerSections.map((section) => (
            <div key={section.title}>
              <h4 className="text-xs font-semibold text-ink-dark/60 mb-4 uppercase tracking-wider">{section.title}</h4>
              <ul className="space-y-2.5">
                {section.links.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="text-sm text-ink-muted/70 hover:text-ink-dark transition-colors"
                      data-testid={`footer-link-${link.label.toLowerCase().replace(/[\s\/&]+/g, "-")}`}
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-vest-g5/[0.08] py-6">
          <div className="flex flex-wrap gap-x-6 gap-y-2">
            {legalLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-xs text-ink-muted/50 hover:text-ink-dark/60 transition-colors"
                data-testid={`footer-legal-${link.label.toLowerCase().replace(/[\s\/&]+/g, "-")}`}
              >
                {link.label}
              </Link>
            ))}
          </div>
        </div>

        <div className="border-t border-vest-g5/[0.08] py-8">
          <div className="text-xs text-ink-muted/60 leading-relaxed space-y-3 mb-6">
            <p>
              {companyName} is registered in {isPK ? "Pakistan" : "UAE"} and operates under the regulatory oversight of the {regBody}. Property tokens issued on this platform are classified as digital securities under applicable regulations.
            </p>
            <p>
              Investing in tokenized real estate involves substantial risk, including the possible loss of your entire investment. Past performance is not indicative of future results. Please read our{" "}
              <Link href="/risk-disclosure" className="text-vest-g5/80 hover:underline" data-testid="footer-inline-risk-disclosure">Risk Disclosure</Link>
              {" "}and{" "}
              <Link href="/terms" className="text-vest-g5/80 hover:underline" data-testid="footer-inline-terms">Terms of Service</Link>
              {" "}before investing.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-xs text-ink-muted/50">
              {new Date().getFullYear()} {companyName} All rights reserved.
            </p>
            <div className="flex items-center gap-4 flex-wrap">
              <span className="text-xs text-ink-muted/50">{isPK ? "SECP Regulated" : "DFSA Regulated"}</span>
              <span className="text-xs text-ink-muted/50">ISO 27001</span>
              <span className="text-xs text-ink-muted/50">PCI DSS</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
