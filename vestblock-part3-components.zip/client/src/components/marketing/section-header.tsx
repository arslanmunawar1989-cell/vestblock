import { cn } from "@/lib/utils";

interface SectionHeaderProps {
  badge?: string;
  title: string;
  highlight?: string;
  description?: string;
  align?: "left" | "center";
  className?: string;
}

export function SectionHeader({ badge, title, highlight, description, align = "center", className }: SectionHeaderProps) {
  return (
    <div className={cn(align === "center" ? "text-center" : "text-left", "mb-12", className)}>
      {badge && (
        <div className={cn("inline-flex items-center px-3 py-1 rounded-full text-xs font-medium mb-4 text-vest-g5 border border-vest-g5/20", align === "center" && "mx-auto")} data-testid="section-badge">
          {badge}
        </div>
      )}
      <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-4" data-testid="section-title">
        {title}{" "}
        {highlight && <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">{highlight}</span>}
      </h2>
      {description && (
        <p className={cn("text-base text-ink-muted leading-relaxed", align === "center" ? "max-w-2xl mx-auto" : "max-w-xl")} data-testid="section-description">
          {description}
        </p>
      )}
    </div>
  );
}
