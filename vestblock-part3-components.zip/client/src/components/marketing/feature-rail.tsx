import { motion, useTransform, type MotionValue } from "framer-motion";
import { Banknote, DoorOpen, FolderOpen, Wallet } from "lucide-react";

const features = [
  {
    title: "Monthly Distributions",
    desc: "Receive net rental income directly to your wallet every month with full transparency.",
    icon: Banknote,
  },
  {
    title: "Exit Windows",
    desc: "Structured bi-annual liquidity windows with NAV-based pricing and clear settlement terms.",
    icon: DoorOpen,
  },
  {
    title: "Property Data Room",
    desc: "Access title deeds, valuations, legal opinions, and inspection reports before you invest.",
    icon: FolderOpen,
  },
  {
    title: "Multi-currency Wallet",
    desc: "Hold and invest in PKR, AED, GBP, USD, QAR, USDT, and USDC from a single dashboard.",
    icon: Wallet,
  },
];

interface FeatureCardProps {
  feat: typeof features[0];
  index: number;
  scrollProgress: MotionValue<number>;
}

function FeatureCard({ feat, index, scrollProgress }: FeatureCardProps) {
  const offset = index * 0.04;
  const opacity = useTransform(scrollProgress, [0.32 + offset, 0.48 + offset], [0, 1]);
  const y = useTransform(scrollProgress, [0.32 + offset, 0.48 + offset], [24, 0]);

  return (
    <motion.div
      style={{ opacity, y }}
      className="glass rounded-md p-4 sm:p-5"
      data-testid={`feature-card-${index}`}
    >
      <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-md bg-vest-g5/10 flex items-center justify-center mb-3">
        <feat.icon className="w-4 h-4 sm:w-[18px] sm:h-[18px] text-vest-g5" />
      </div>
      <h4 className="text-xs sm:text-sm font-semibold text-ink-dark mb-1">{feat.title}</h4>
      <p className="text-[10px] sm:text-xs text-ink-muted/70 leading-relaxed">{feat.desc}</p>
    </motion.div>
  );
}

interface FeatureRailProps {
  scrollProgress: MotionValue<number>;
}

export function FeatureRail({ scrollProgress }: FeatureRailProps) {
  const opacity = useTransform(scrollProgress, [0.3, 0.5], [0, 1]);
  const y = useTransform(scrollProgress, [0.3, 0.5], [50, 0]);

  return (
    <motion.div
      className="absolute bottom-[8%] left-0 right-0 px-6 sm:px-10 lg:px-16 pointer-events-none"
      style={{ opacity, y }}
      data-testid="feature-rail"
    >
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 pointer-events-auto">
          {features.map((feat, i) => (
            <FeatureCard key={feat.title} feat={feat} index={i} scrollProgress={scrollProgress} />
          ))}
        </div>
      </div>
    </motion.div>
  );
}

export const featureItems = features;
