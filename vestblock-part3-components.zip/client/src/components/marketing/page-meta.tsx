import { useEffect } from "react";

interface PageMetaProps {
  title: string;
  description: string;
  path?: string;
  ogImage?: string;
  ogType?: string;
}

const SITE_NAME = "VestBlock";
const BASE_URL = "https://vestblock.pk";
const DEFAULT_OG_IMAGE = "/og-default.png";

export function PageMeta({ title, description, path, ogImage, ogType = "website" }: PageMetaProps) {
  useEffect(() => {
    const fullTitle = `${title} | ${SITE_NAME}`;
    document.title = fullTitle;

    const setMeta = (name: string, content: string, attr = "name") => {
      let el = document.querySelector(`meta[${attr}="${name}"]`) as HTMLMetaElement | null;
      if (!el) {
        el = document.createElement("meta");
        el.setAttribute(attr, name);
        document.head.appendChild(el);
      }
      el.setAttribute("content", content);
    };

    setMeta("description", description);
    setMeta("og:title", fullTitle, "property");
    setMeta("og:description", description, "property");
    setMeta("og:type", ogType, "property");
    setMeta("og:site_name", SITE_NAME, "property");
    setMeta("og:image", ogImage || DEFAULT_OG_IMAGE, "property");
    if (path) setMeta("og:url", `${BASE_URL}${path}`, "property");
    setMeta("twitter:card", "summary_large_image");
    setMeta("twitter:title", fullTitle);
    setMeta("twitter:description", description);

    return () => {
      document.title = SITE_NAME;
    };
  }, [title, description, path, ogImage, ogType]);

  return null;
}
