import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  TrendingUp, Wallet, Clock, Building2, ChevronRight,
  ArrowUpRight, Banknote, Calendar, Shield,
} from "lucide-react";
import {
  AreaChart, Area, ResponsiveContainer,
} from "recharts";

const chartData = [
  { m: "J", v: 100 }, { m: "F", v: 112 }, { m: "M", v: 108 },
  { m: "A", v: 125 }, { m: "M", v: 130 }, { m: "J", v: 145 },
  { m: "J", v: 140 }, { m: "A", v: 155 }, { m: "S", v: 162 },
  { m: "O", v: 170 }, { m: "N", v: 178 }, { m: "D", v: 190 },
];

function PortfolioScreen() {
  return (
    <div className="flex flex-col h-full" data-testid="screen-portfolio">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="text-[9px] text-ink-muted/60 uppercase tracking-wider">Total Portfolio</div>
          <div className="text-xl font-bold text-ink-dark" data-testid="portfolio-total">PKR 2,450,000</div>
        </div>
        <div className="flex items-center gap-1 text-[10px] font-medium text-vest-g5 bg-vest-g0 px-2 py-0.5 rounded" data-testid="portfolio-change">
          <ArrowUpRight className="w-3 h-3" /> +12.4%
        </div>
      </div>

      <div className="h-20 mb-4 -mx-1" data-testid="portfolio-chart">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="phoneGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#1E2BFF" stopOpacity={0.3} />
                <stop offset="100%" stopColor="#1E2BFF" stopOpacity={0.02} />
              </linearGradient>
            </defs>
            <Area type="monotone" dataKey="v" stroke="#1E2BFF" strokeWidth={1.5} fill="url(#phoneGrad)" dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="text-[9px] text-ink-muted/60 uppercase tracking-wider mb-2">Holdings</div>
      {[
        { name: "DHA Phase 6 Commercial", units: "250 tokens", val: "PKR 1,250,000", change: "+8.2%" },
        { name: "Clifton Block 5 Apts", units: "180 tokens", val: "PKR 720,000", change: "+15.1%" },
        { name: "F-8 Markaz Office", units: "120 tokens", val: "PKR 480,000", change: "+9.7%" },
      ].map((h, i) => (
        <div key={i} className="flex items-center justify-between py-2 border-b border-vest-g5/[0.06] last:border-0" data-testid={`holding-row-${i}`}>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded bg-vest-g0/80 flex items-center justify-center">
              <Building2 className="w-3.5 h-3.5 text-vest-g5" />
            </div>
            <div>
              <div className="text-[10px] font-medium text-ink-dark leading-tight">{h.name}</div>
              <div className="text-[8px] text-ink-muted/60">{h.units}</div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-[10px] font-medium text-ink-dark">{h.val}</div>
            <div className="text-[8px] text-vest-g5">{h.change}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function PayoutsScreen() {
  return (
    <div className="flex flex-col h-full" data-testid="screen-payouts">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="text-[9px] text-ink-muted/60 uppercase tracking-wider">Monthly Payout</div>
          <div className="text-xl font-bold text-ink-dark" data-testid="payout-amount">PKR 18,375</div>
        </div>
        <div className="w-8 h-8 rounded bg-vest-g5/10 flex items-center justify-center">
          <Banknote className="w-4 h-4 text-vest-g5" />
        </div>
      </div>

      <div className="glass rounded-md p-3 mb-4" data-testid="distribution-summary">
        <div className="text-[9px] text-ink-muted/60 uppercase tracking-wider mb-2">Distribution Summary</div>
        <div className="grid grid-cols-3 gap-2">
          {[
            { label: "Gross Rent", value: "22,050" },
            { label: "Mgmt Fee", value: "-2,205" },
            { label: "Net Payout", value: "18,375" },
          ].map((d, i) => (
            <div key={i} className="text-center" data-testid={`dist-${d.label.toLowerCase().replace(/\s+/g, "-")}`}>
              <div className="text-[10px] font-semibold text-ink-dark">{d.value}</div>
              <div className="text-[7px] text-ink-muted/60">{d.label}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="text-[9px] text-ink-muted/60 uppercase tracking-wider mb-2">Recent Payouts</div>
      {[
        { month: "Jan 2026", amount: "PKR 18,375", status: "Paid" },
        { month: "Dec 2025", amount: "PKR 17,890", status: "Paid" },
        { month: "Nov 2025", amount: "PKR 18,102", status: "Paid" },
        { month: "Oct 2025", amount: "PKR 17,650", status: "Paid" },
      ].map((p, i) => (
        <div key={i} className="flex items-center justify-between py-2 border-b border-vest-g5/[0.06] last:border-0" data-testid={`payout-row-${i}`}>
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-vest-g0/80 flex items-center justify-center">
              <Calendar className="w-3 h-3 text-vest-g4" />
            </div>
            <div className="text-[10px] text-ink-dark">{p.month}</div>
          </div>
          <div className="flex items-center gap-2">
            <div className="text-[10px] font-medium text-ink-dark">{p.amount}</div>
            <div className="text-[7px] bg-vest-g0 text-vest-g5 px-1.5 py-0.5 rounded font-medium">{p.status}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function ExitWindowScreen() {
  return (
    <div className="flex flex-col h-full" data-testid="screen-exit">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="text-[9px] text-ink-muted/60 uppercase tracking-wider">Next Exit Window</div>
          <div className="text-xl font-bold text-ink-dark" data-testid="exit-date">June 2026</div>
        </div>
        <div className="w-8 h-8 rounded bg-vest-g2/30 flex items-center justify-center">
          <Clock className="w-4 h-4 text-vest-g4" />
        </div>
      </div>

      <div className="glass rounded-md p-3 mb-4" data-testid="exit-countdown">
        <div className="flex items-center justify-between mb-2">
          <div className="text-[9px] text-ink-muted/60 uppercase tracking-wider">Countdown</div>
          <div className="text-[9px] font-medium text-vest-g5">131 days left</div>
        </div>
        <div className="w-full h-2 bg-vest-g0 rounded-full overflow-hidden">
          <div className="h-full bg-vest-g5 rounded-full" style={{ width: "28%" }} />
        </div>
        <div className="flex justify-between mt-1">
          <span className="text-[7px] text-ink-muted/50">Dec 2025</span>
          <span className="text-[7px] text-ink-muted/50">Jun 2026</span>
        </div>
      </div>

      <div className="glass rounded-md p-3 mb-4" data-testid="withdrawal-rules">
        <div className="text-[9px] text-ink-muted/60 uppercase tracking-wider mb-2">Withdrawal Rules</div>
        <div className="space-y-1.5">
          {[
            { rule: "Profit withdrawal after 30 days", icon: TrendingUp },
            { rule: "Capital withdrawal after 90 days", icon: Wallet },
            { rule: "NAV-based pricing at exit", icon: Shield },
          ].map((r, i) => (
            <div key={i} className="flex items-center gap-2" data-testid={`rule-${i}`}>
              <r.icon className="w-3 h-3 text-vest-g4 shrink-0" />
              <span className="text-[9px] text-ink-dark">{r.rule}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="text-[9px] text-ink-muted/60 uppercase tracking-wider mb-2">Your Listings</div>
      <div className="flex items-center justify-between py-2 border-b border-vest-g5/[0.06]" data-testid="listing-0">
        <div className="flex items-center gap-2">
          <Building2 className="w-3.5 h-3.5 text-vest-g5" />
          <div className="text-[10px] text-ink-dark">DHA Phase 6 - 50 tokens</div>
        </div>
        <div className="text-[8px] bg-vest-g2/30 text-vest-g4 px-1.5 py-0.5 rounded font-medium">Pending</div>
      </div>
      <div className="flex items-center justify-between py-2" data-testid="listing-1">
        <div className="flex items-center gap-2">
          <Building2 className="w-3.5 h-3.5 text-vest-g5" />
          <div className="text-[10px] text-ink-dark">F-8 Markaz - 30 tokens</div>
        </div>
        <div className="flex items-center gap-1 text-[10px] text-vest-g5 font-medium cursor-pointer">
          List <ChevronRight className="w-3 h-3" />
        </div>
      </div>
    </div>
  );
}

const screens = [
  { id: "portfolio", label: "Portfolio", component: PortfolioScreen },
  { id: "payouts", label: "Payouts", component: PayoutsScreen },
  { id: "exit", label: "Exit Windows", component: ExitWindowScreen },
];

interface PhoneMockupProps {
  autoPlay?: boolean;
  className?: string;
}

export function PhoneMockup({ autoPlay = false, className = "" }: PhoneMockupProps) {
  const [active, setActive] = useState(0);

  useEffect(() => {
    if (!autoPlay) return;
    const timer = setInterval(() => {
      setActive((prev) => (prev + 1) % screens.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [autoPlay]);

  const ActiveScreen = screens[active].component;

  return (
    <div className={`flex flex-col items-center ${className}`}>
      <div className="flex items-center gap-1 mb-4" data-testid="phone-tabs">
        {screens.map((s, i) => (
          <button
            key={s.id}
            onClick={() => setActive(i)}
            className={`px-3 py-1.5 text-xs rounded-md transition-all ${
              active === i
                ? "glass-btn-primary font-medium"
                : "text-ink-muted hover:text-ink-dark"
            }`}
            data-testid={`phone-tab-${s.id}`}
          >
            {s.label}
          </button>
        ))}
      </div>

      <motion.div
        animate={{ y: [0, -6, 0] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        className="relative"
      >
        <div
          className="relative w-[260px] h-[520px] rounded-[32px] bg-gradient-to-b from-[#0B1220] to-[#070D1A] p-[10px] shadow-2xl"
          data-testid="phone-device"
        >
          <div className="absolute top-3 left-1/2 -translate-x-1/2 w-20 h-5 bg-black rounded-full z-20" />
          <div className="relative w-full h-full rounded-[24px] bg-white overflow-hidden">
            <div className="h-8 bg-vest-g0/60 flex items-center justify-between px-4 pt-1">
              <span className="text-[8px] font-medium text-ink-dark">9:41</span>
              <div className="flex items-center gap-1">
                <div className="w-3 h-2 border border-ink-dark/40 rounded-sm relative">
                  <div className="absolute inset-[1px] bg-ink-dark/40 rounded-[1px]" style={{ width: "60%" }} />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between px-4 py-2 border-b border-vest-g5/[0.06]" data-testid="phone-header">
              <div className="flex items-center gap-1.5">
                <div className="w-5 h-5 rounded bg-vest-g5 flex items-center justify-center">
                  <span className="text-[7px] font-bold text-white">V</span>
                </div>
                <span className="text-[10px] font-semibold text-ink-dark">VestBlock</span>
              </div>
              <div className="w-5 h-5 rounded-full bg-vest-g0 flex items-center justify-center">
                <span className="text-[7px] font-medium text-vest-g5">HM</span>
              </div>
            </div>

            <div className="px-4 py-3 h-[calc(100%-76px)] overflow-hidden">
              <AnimatePresence mode="wait">
                <motion.div
                  key={active}
                  initial={{ opacity: 0, x: 40 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -40 }}
                  transition={{ duration: 0.35, ease: "easeOut" }}
                  className="h-full"
                >
                  <ActiveScreen />
                </motion.div>
              </AnimatePresence>
            </div>

            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-28 h-1 bg-ink-dark/20 rounded-full" />
          </div>
        </div>

        <div className="absolute -inset-4 rounded-[40px] bg-vest-g3/10 blur-2xl -z-10" />
      </motion.div>
    </div>
  );
}
