import { GlassCard } from "./glass-card";
import { AlertTriangle, Shield } from "lucide-react";

interface ComplianceDisclaimerProps {
  variant?: "warning" | "regulatory";
  title: string;
  text: string;
  testId?: string;
}

export function ComplianceDisclaimer({ variant = "regulatory", title, text, testId }: ComplianceDisclaimerProps) {
  const isWarning = variant === "warning";
  return (
    <GlassCard className={isWarning ? "ring-1 ring-yellow-500/20" : ""} data-testid={testId}>
      <div className="flex items-start gap-4">
        <div
          className="w-10 h-10 rounded-md flex items-center justify-center shrink-0"
          style={{ background: isWarning ? "rgba(255,200,0,0.08)" : "rgba(30,43,255,0.08)" }}
        >
          {isWarning ? (
            <AlertTriangle className="w-5 h-5 text-yellow-500" />
          ) : (
            <Shield className="w-5 h-5 text-vest-g5" />
          )}
        </div>
        <div>
          <h3 className="text-ink-dark font-semibold mb-2">{title}</h3>
          <p className="text-ink-muted text-sm leading-relaxed">{text}</p>
        </div>
      </div>
    </GlassCard>
  );
}
