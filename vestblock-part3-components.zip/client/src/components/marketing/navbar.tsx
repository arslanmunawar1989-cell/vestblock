import { Link, useLocation } from "wouter";
import { useState, useRef, useEffect, useCallback } from "react";
import { Menu, X, ChevronDown, ArrowUpRight } from "lucide-react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";
import { useRegion } from "@/lib/region";

const navLinks = [
  { label: "Properties", href: "/properties" },
  { label: "How It Works", href: "/how-it-works" },
  { label: "Pricing", href: "/pricing" },
];

const moreLinks = [
  { label: "ROI Calculator", href: "/roi-calculator" },
  { label: "Exit Windows", href: "/exit-windows" },
  { label: "Mobile App", href: "/mobile-app" },
  { label: "FAQ", href: "/faq" },
  { label: "Blog", href: "/blog" },
];

function useScrollDirection() {
  const [scrollState, setScrollState] = useState({
    direction: "up" as "up" | "down",
    y: 0,
    isTop: true,
  });
  const lastY = useRef(0);
  const ticking = useRef(false);

  useEffect(() => {
    const onScroll = () => {
      if (ticking.current) return;
      ticking.current = true;
      requestAnimationFrame(() => {
        const y = window.scrollY;
        const direction = y > lastY.current + 5 ? "down" : y < lastY.current - 5 ? "up" : scrollState.direction;
        lastY.current = y;
        setScrollState({ direction, y, isTop: y < 20 });
        ticking.current = false;
      });
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [scrollState.direction]);

  return scrollState;
}

function RegionSwitch() {
  const { region, switchRegion } = useRegion();
  const isPK = region.code === "pk";

  return (
    <div className="flex items-center gap-1 rounded-md border border-vest-g5/15 bg-white/40 p-0.5" data-testid="region-switch">
      <button
        onClick={() => { if (!isPK) switchRegion(); }}
        className={cn(
          "px-2.5 py-1.5 text-xs rounded transition-colors",
          isPK ? "bg-vest-g5/15 text-ink-dark font-medium" : "text-ink-muted"
        )}
        data-testid="region-pk"
      >
        PK
      </button>
      <button
        onClick={() => { if (isPK) switchRegion(); }}
        className={cn(
          "px-2.5 py-1.5 text-xs rounded transition-colors",
          !isPK ? "bg-vest-g5/15 text-ink-dark font-medium" : "text-ink-muted"
        )}
        data-testid="region-ae"
      >
        UAE
      </button>
    </div>
  );
}

function MoreDropdown() {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const [location] = useLocation();

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const isActive = moreLinks.some((l) => location === l.href);

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen(!open)}
        onKeyDown={(e) => { if (e.key === "Escape") setOpen(false); }}
        className={cn(
          "text-sm transition-colors flex items-center gap-1 whitespace-nowrap relative py-1",
          isActive ? "text-ink-dark font-medium" : "text-ink-muted hover:text-ink-dark"
        )}
        aria-expanded={open}
        aria-haspopup="true"
        data-testid="nav-more"
      >
        More
        <ChevronDown className={cn("w-3 h-3 transition-transform", open && "rotate-180")} />
      </button>
      {open && (
        <div className="absolute top-full mt-3 right-0 w-44 rounded-md glass-surface glass-noise p-1.5 z-50" role="menu" data-testid="more-dropdown">
          {moreLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={cn(
                "block px-3 py-2 rounded-md text-sm transition-colors",
                location === link.href ? "text-ink-dark bg-vest-g0/50" : "text-ink-muted hover:text-ink-dark hover:bg-vest-g0/30"
              )}
              onClick={() => setOpen(false)}
              data-testid={`nav-more-${link.label.toLowerCase().replace(/[\s\/&]+/g, "-")}`}
            >
              {link.label}
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

function NavLink({ href, label, location }: { href: string; label: string; location: string }) {
  const isActive = location === href;
  return (
    <Link
      href={href}
      className={cn(
        "text-sm transition-colors whitespace-nowrap relative py-1",
        isActive ? "text-ink-dark font-medium" : "text-ink-muted hover:text-ink-dark"
      )}
      data-testid={`nav-link-${label.toLowerCase().replace(/[\s\/]+/g, "-")}`}
    >
      {label}
      {isActive && (
        <motion.div
          layoutId="nav-underline"
          className="absolute -bottom-0.5 left-0 right-0 h-[2px] rounded-full bg-vest-g5"
          transition={{ type: "spring", stiffness: 380, damping: 30 }}
        />
      )}
    </Link>
  );
}

export function MarketingNavbar() {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const prefersReducedMotion = useReducedMotion();
  const { direction, y, isTop } = useScrollDirection();

  const isScrolled = !isTop;
  const shouldHide = !prefersReducedMotion && direction === "down" && y > 80;

  return (
    <motion.header
      className={cn(
        "fixed top-0 left-0 right-0 z-[999] will-change-transform",
        "transition-[background,border-color,box-shadow,padding] duration-300 ease-out",
        isScrolled
          ? "glass-surface border-b border-vest-g5/[0.08]"
          : "bg-transparent border-b border-transparent"
      )}
      style={{
        paddingTop: isScrolled ? "0px" : "2px",
        paddingBottom: isScrolled ? "0px" : "2px",
        boxShadow: isScrolled ? "0 4px 24px rgba(2,6,23,0.06)" : "none",
      }}
      initial={false}
      animate={{
        y: shouldHide ? -80 : 0,
        opacity: shouldHide ? 0 : 1,
      }}
      transition={
        prefersReducedMotion
          ? { duration: 0 }
          : { type: "spring", stiffness: 300, damping: 30 }
      }
      data-testid="marketing-navbar"
    >
      <div className={cn(
        "mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 sm:px-8 lg:px-12 transition-[height] duration-300",
        isScrolled ? "h-[52px]" : "h-14"
      )}>
        <Link href="/" className="flex items-center gap-2 shrink-0" data-testid="nav-logo">
          <div className="h-7 w-7 rounded-md bg-vest-g5 flex items-center justify-center">
            <span className="text-xs font-bold text-white">V</span>
          </div>
          <span className="text-sm font-semibold text-ink-dark tracking-tight">VestBlock</span>
        </Link>

        <nav className="hidden items-center gap-6 md:flex">
          {navLinks.map((link) => (
            <NavLink key={link.href} href={link.href} label={link.label} location={location} />
          ))}
          <MoreDropdown />
        </nav>

        <div className="flex items-center gap-3">
          <div className="hidden lg:flex">
            <RegionSwitch />
          </div>

          <Link
            href="~/login"
            className="hidden md:block text-sm text-ink-muted hover:text-ink-dark transition-colors whitespace-nowrap"
            data-testid="nav-signin"
          >
            Sign In
          </Link>

          <Link href="~/register">
            <button
              className="glass-btn-primary hidden md:inline-flex items-center gap-1.5 rounded-md px-4 py-2 text-sm font-medium whitespace-nowrap"
              data-testid="nav-getstarted"
            >
              Get Started
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </Link>

          <button
            className="md:hidden text-ink-muted hover:text-ink-dark p-1.5"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle mobile menu"
            aria-expanded={mobileOpen}
            data-testid="nav-mobile-toggle"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            className="md:hidden border-t border-vest-g5/[0.06] glass-surface"
            initial={prefersReducedMotion ? false : { height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={prefersReducedMotion ? undefined : { height: 0, opacity: 0 }}
            transition={prefersReducedMotion ? { duration: 0 } : { duration: 0.25, ease: "easeInOut" }}
          >
            <div className="px-5 py-4 space-y-1 max-h-[70vh] overflow-y-auto">
              <div className="flex items-center gap-2 mb-3">
                <RegionSwitch />
              </div>

              {[...navLinks, ...moreLinks].map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={cn(
                    "block px-3 py-2 text-sm rounded-md transition-colors",
                    location === link.href ? "text-ink-dark bg-vest-g0/50" : "text-ink-muted hover:text-ink-dark"
                  )}
                  onClick={() => setMobileOpen(false)}
                  data-testid={`nav-mobile-${link.label.toLowerCase().replace(/[\s\/]+/g, "-")}`}
                >
                  {link.label}
                </Link>
              ))}

              <div className="pt-3 flex flex-col gap-2.5">
                <Link
                  href="~/login"
                  className="glass-btn-outline block text-center px-4 py-2 text-sm rounded-md"
                  data-testid="nav-mobile-signin"
                >
                  Sign In
                </Link>
                <Link href="~/register" className="block" data-testid="nav-mobile-getstarted">
                  <button className="glass-btn-primary w-full flex items-center justify-center gap-1.5 rounded-md px-4 py-2 text-sm font-medium">
                    Get Started
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
