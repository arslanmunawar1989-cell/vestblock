import { Link } from "wouter";
import { motion, useScroll, useTransform, useReducedMotion, AnimatePresence } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { useState, useEffect, useRef, useCallback } from "react";
import { useInView } from "framer-motion";
import { LaptopMockup } from "./laptop-mockup";
import { FloatingKpi } from "./floating-kpi";
import { FeatureRail } from "./feature-rail";
import { featureItems } from "./feature-rail";
import { WebGLBackdrop } from "../hero/WebGLBackdrop";

const fadeUp = { hidden: { opacity: 0, y: 40 }, visible: { opacity: 1, y: 0 } };
const stagger = { visible: { transition: { staggerChildren: 0.12 } } };

const MORPH_WORDS = ["Fractional", "Tokenized", "Accessible", "Transparent", "Structured"];

function MorphingWord() {
  const [index, setIndex] = useState(0);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) return;
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % MORPH_WORDS.length);
    }, 3000);
    return () => clearInterval(interval);
  }, [prefersReducedMotion]);

  return (
    <span className="inline-block relative" data-testid="hero-morph-word">
      <AnimatePresence mode="wait">
        <motion.span
          key={MORPH_WORDS[index]}
          initial={{ opacity: 0, y: 20, filter: "blur(8px)" }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          exit={{ opacity: 0, y: -20, filter: "blur(8px)" }}
          transition={{ duration: 0.5, ease: "easeInOut" }}
          className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent"
        >
          {MORPH_WORDS[index]}
        </motion.span>
      </AnimatePresence>
    </span>
  );
}

function AnimatedCounter({ end, prefix = "", suffix = "", decimals = 0 }: { end: number; prefix?: string; suffix?: string; decimals?: number }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-50px" });

  useEffect(() => {
    if (!inView) return;
    let start = 0;
    const duration = 2000;
    const step = 16;
    const steps = duration / step;
    const increment = end / steps;
    const timer = setInterval(() => {
      start += increment;
      if (start >= end) { setCount(end); clearInterval(timer); }
      else setCount(start);
    }, step);
    return () => clearInterval(timer);
  }, [inView, end]);

  return <span ref={ref}>{prefix}{decimals > 0 ? count.toFixed(decimals) : Math.round(count).toLocaleString()}{suffix}</span>;
}

function SectionLabel({ label }: { label: string }) {
  return (
    <div className="flex items-center gap-2.5 mb-6" data-testid={`section-label-${label.toLowerCase().replace(/\s+/g, "-")}`}>
      <div className="w-2 h-2 rounded-full bg-vest-g5" />
      <span className="text-xs uppercase tracking-[0.2em] text-ink-muted font-medium">{label}</span>
    </div>
  );
}

export function Hero() {
  const containerRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"],
  });

  const active = !prefersReducedMotion;

  const headlineScale = useTransform(scrollYProgress, [0, 0.5], active ? [1, 0.92] : [1, 1]);
  const headlineY = useTransform(scrollYProgress, [0, 0.5], active ? [0, -24] : [0, 0]);
  const headlineOpacity = useTransform(scrollYProgress, [0.35, 0.6], active ? [1, 0.15] : [1, 1]);

  const statsOpacity = useTransform(scrollYProgress, [0.2, 0.45], active ? [1, 0] : [1, 1]);
  const statsY = useTransform(scrollYProgress, [0.2, 0.45], active ? [0, -16] : [0, 0]);

  const laptopScale = useTransform(scrollYProgress, [0, 0.5], active ? [1, 0.72] : [1, 1]);
  const laptopX = useTransform(scrollYProgress, [0, 0.5], active ? [0, 120] : [0, 0]);
  const laptopY = useTransform(scrollYProgress, [0, 0.5], active ? [0, 60] : [0, 0]);
  const laptopRotate = useTransform(scrollYProgress, [0, 0.5], active ? [0, -2] : [0, 0]);

  const floatingOpacity = useTransform(scrollYProgress, [0.15, 0.35], active ? [1, 0] : [1, 1]);

  const blob1X = useTransform(scrollYProgress, [0, 0.6], active ? [0, -30] : [0, 0]);
  const blob1Opacity = useTransform(scrollYProgress, [0, 0.6], active ? [0.22, 0.08] : [0.22, 0.22]);
  const blob2X = useTransform(scrollYProgress, [0, 0.6], active ? [0, 25] : [0, 0]);
  const blob2Opacity = useTransform(scrollYProgress, [0, 0.6], active ? [0.18, 0.06] : [0.18, 0.18]);
  const blob3Y = useTransform(scrollYProgress, [0, 0.6], active ? [0, 20] : [0, 0]);

  return (
    <section
      ref={containerRef}
      className="relative hero-scroll-container"
      style={{ position: "relative" }}
      data-testid="hero-section"
    >
      <div className="hero-sticky-inner">
        <WebGLBackdrop />
        <div className="absolute inset-0 hero-animated-bg" />
        <div className="absolute inset-0 bg-gradient-to-b from-vest-g0/50 via-transparent to-transparent" />

        <motion.div
          className="absolute top-[10%] left-[4%] w-64 h-64 rounded-full bg-vest-g3 blur-[100px] pointer-events-none"
          style={{ x: blob1X, opacity: blob1Opacity }}
          animate={active ? {
            y: [0, 30, 8, 36, 0],
            x: [0, 15, -10, 20, 0],
            scale: [1, 1.08, 0.96, 1.04, 1],
          } : undefined}
          transition={active ? { duration: 28, repeat: Infinity, ease: [0.45, 0.05, 0.55, 0.95] } : undefined}
        />
        <motion.div
          className="absolute bottom-[6%] right-[8%] w-80 h-80 rounded-full bg-vest-g4 blur-[110px] pointer-events-none"
          style={{ x: blob2X, opacity: blob2Opacity }}
          animate={active ? {
            y: [0, -24, -8, -30, 0],
            x: [0, -20, 10, -15, 0],
            scale: [1, 1.05, 1.12, 0.97, 1],
          } : undefined}
          transition={active ? { duration: 34, repeat: Infinity, ease: [0.45, 0.05, 0.55, 0.95] } : undefined}
        />
        <motion.div
          className="absolute top-[35%] right-[35%] w-48 h-48 rounded-full bg-vest-g2/[0.18] blur-[80px] pointer-events-none"
          style={{ y: blob3Y }}
          animate={active ? {
            y: [0, 16, -6, 20, 0],
            x: [0, -12, 8, -5, 0],
            scale: [1, 1.06, 0.94, 1.02, 1],
          } : undefined}
          transition={active ? { duration: 22, repeat: Infinity, ease: [0.45, 0.05, 0.55, 0.95] } : undefined}
        />
        <motion.div
          className="absolute top-[55%] left-[25%] w-36 h-36 rounded-full bg-vest-g5/[0.08] blur-[70px] pointer-events-none"
          animate={active ? {
            y: [0, -18, 10, -22, 0],
            x: [0, 22, -8, 16, 0],
            opacity: [0.08, 0.14, 0.06, 0.12, 0.08],
          } : undefined}
          transition={active ? { duration: 26, repeat: Infinity, ease: [0.45, 0.05, 0.55, 0.95] } : undefined}
        />
        <motion.div
          className="absolute top-[18%] right-[15%] w-44 h-44 rounded-full bg-vest-g1/[0.15] blur-[90px] pointer-events-none"
          animate={active ? {
            y: [0, 20, -14, 10, 0],
            x: [0, -18, 12, -24, 0],
            scale: [1, 0.92, 1.1, 0.98, 1],
          } : undefined}
          transition={active ? { duration: 38, repeat: Infinity, ease: [0.45, 0.05, 0.55, 0.95] } : undefined}
        />

        <div className="relative h-full flex flex-col justify-center px-6 sm:px-10 lg:px-16 pt-8 pb-24 md:pt-14 md:pb-36">
          <div className="max-w-7xl mx-auto w-full">
            <div className="grid grid-cols-1 lg:grid-cols-[5fr_7fr] gap-12 lg:gap-8 items-stretch">
              <motion.div
                style={{ scale: headlineScale, y: headlineY }}
                className="origin-top-left hero-text-col flex flex-col justify-center"
              >
                <motion.div initial="hidden" animate="visible" variants={stagger}>
                  <motion.div variants={fadeUp} transition={{ duration: 0.6 }}>
                    <SectionLabel label="Tokenized Real Estate" />
                  </motion.div>

                  <motion.h1 variants={fadeUp} transition={{ duration: 0.7, delay: 0.1 }}
                    className="text-3xl sm:text-4xl lg:text-[40px] font-bold text-ink-dark leading-[1.12] tracking-tight"
                    data-testid="hero-headline"
                  >
                    Invest in Pakistan Real Estate —{" "}
                    <MorphingWord />
                    , Secure, Digital
                  </motion.h1>

                  <motion.p variants={fadeUp} transition={{ duration: 0.6, delay: 0.2 }}
                    className="mt-5 text-base text-ink-muted max-w-md leading-relaxed"
                    style={{ opacity: headlineOpacity }}
                    data-testid="hero-subtext"
                  >
                    Access income-generating properties across Pakistan through digital fractional ownership. Earn monthly rental distributions and exit through structured liquidity windows.
                  </motion.p>

                  <motion.div variants={fadeUp} transition={{ duration: 0.5, delay: 0.3 }}
                    className="mt-8 flex flex-wrap gap-3 items-center"
                    style={{ opacity: headlineOpacity }}
                  >
                    <Link href="/properties">
                      <button className="glass-btn-primary glow-pulse inline-flex items-center gap-2 rounded-md px-6 py-3 text-sm font-medium" data-testid="hero-cta-start">
                        Explore Properties
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </Link>
                    <Link href="/how-it-works">
                      <button className="glass-btn-outline inline-flex items-center gap-2 rounded-md px-6 py-3 text-sm font-medium" data-testid="hero-cta-learn">
                        How It Works
                      </button>
                    </Link>
                  </motion.div>

                  <motion.div variants={fadeUp} transition={{ duration: 0.5, delay: 0.4 }}
                    className="mt-8 flex items-center gap-6 flex-wrap"
                    style={{ opacity: statsOpacity, y: statsY }}
                  >
                    <div data-testid="hero-stat-raised">
                      <div className="text-2xl font-bold text-ink-dark"><AnimatedCounter end={2.8} prefix="" suffix="B+" decimals={1} /></div>
                      <div className="text-[11px] text-ink-muted/70 mt-0.5">PKR Capital Raised</div>
                    </div>
                    <div className="h-8 w-px bg-vest-g5/15" />
                    <div data-testid="hero-stat-investors">
                      <div className="text-2xl font-bold text-ink-dark"><AnimatedCounter end={12400} suffix="+" /></div>
                      <div className="text-[11px] text-ink-muted/70 mt-0.5">Active Investors</div>
                    </div>
                    <div className="h-8 w-px bg-vest-g5/15 hidden sm:block" />
                    <div className="hidden sm:block" data-testid="hero-stat-yield">
                      <div className="text-2xl font-bold text-vest-g5"><AnimatedCounter end={9.1} suffix="%" decimals={1} /></div>
                      <div className="text-[11px] text-ink-muted/70 mt-0.5">Avg. Annual Yield</div>
                    </div>
                  </motion.div>
                </motion.div>
              </motion.div>

              <motion.div
                className="relative hidden lg:flex lg:items-center lg:justify-center hero-laptop-col"
                style={{ scale: laptopScale, x: laptopX, y: laptopY, rotate: laptopRotate }}
              >
                <LaptopMockup />
                <motion.div
                  className="absolute inset-0"
                  style={{ opacity: floatingOpacity }}
                >
                  <FloatingKpi className="absolute inset-0" />
                </motion.div>
              </motion.div>

              <div className="lg:hidden space-y-6">
                <LaptopMockup className="mt-4" />
                <FloatingKpi mobile />
              </div>
            </div>
          </div>

          <div className="hidden lg:block">
            <FeatureRail scrollProgress={scrollYProgress} />
          </div>
        </div>
      </div>

      <div className="lg:hidden px-6 sm:px-10 pb-12 pt-4">
        <div className="max-w-7xl mx-auto grid grid-cols-2 gap-3">
          {featureItems.map((feat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08, duration: 0.4 }}
              className="glass rounded-md p-4"
              data-testid={`feature-card-mobile-${i}`}
            >
              <div className="w-7 h-7 rounded-md bg-vest-g5/10 flex items-center justify-center mb-2">
                <feat.icon className="w-3.5 h-3.5 text-vest-g5" />
              </div>
              <h4 className="text-xs font-semibold text-ink-dark mb-1">{feat.title}</h4>
              <p className="text-[10px] text-ink-muted/70 leading-relaxed">{feat.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

export { AnimatedCounter, SectionLabel, fadeUp, stagger };
