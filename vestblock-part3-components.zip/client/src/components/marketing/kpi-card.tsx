import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";

interface KpiCardProps {
  icon: LucideIcon;
  label: string;
  value: string;
  suffix?: string;
  className?: string;
}

export function KpiCard({ icon: Icon, label, value, suffix, className }: KpiCardProps) {
  return (
    <div className={cn("glass rounded-md p-5 transition-all duration-300", className)} data-testid={`kpi-${label.toLowerCase().replace(/\s+/g, "-")}`}>
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-md flex items-center justify-center shrink-0 bg-vest-g5/10">
          <Icon className="w-5 h-5 text-vest-g5" />
        </div>
        <div>
          <div className="text-2xl font-bold text-ink-dark leading-none mb-1">
            {value}
            {suffix && <span className="text-lg text-ink-muted ml-0.5">{suffix}</span>}
          </div>
          <div className="text-sm text-ink-muted">{label}</div>
        </div>
      </div>
    </div>
  );
}
