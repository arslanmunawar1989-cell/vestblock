import { motion } from "framer-motion";
import { TrendingUp, Banknote, Percent } from "lucide-react";

const chips = [
  { label: "9.2% Yield", icon: Percent, delay: 0.8, x: -20, y: -40 },
  { label: "PKR 50,000 Min", icon: Banknote, delay: 1.1, x: 30, y: 10 },
  { label: "Monthly Payouts", icon: TrendingUp, delay: 1.4, x: -10, y: 60 },
];

interface FloatingKpiProps {
  className?: string;
  mobile?: boolean;
}

export function FloatingKpi({ className = "", mobile = false }: FloatingKpiProps) {
  if (mobile) {
    return (
      <div className={`flex flex-wrap justify-center gap-3 ${className}`} data-testid="floating-kpis-mobile">
        {chips.map((chip, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 + i * 0.15, duration: 0.4, ease: "easeOut" }}
            data-testid={`floating-kpi-mobile-${i}`}
          >
            <div className="glass rounded-md px-3 py-2 flex items-center gap-2 shadow-glassSoft whitespace-nowrap">
              <div className="w-5 h-5 rounded bg-vest-g5/10 flex items-center justify-center shrink-0">
                <chip.icon className="w-3 h-3 text-vest-g5" />
              </div>
              <span className="text-xs font-semibold text-ink-dark">{chip.label}</span>
            </div>
          </motion.div>
        ))}
      </div>
    );
  }

  return (
    <div className={`pointer-events-none ${className}`} data-testid="floating-kpis">
      {chips.map((chip, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 20, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ delay: chip.delay, duration: 0.5, ease: "easeOut" }}
          className="absolute pointer-events-auto"
          style={{ left: `${50 + chip.x}%`, top: `${50 + chip.y}%` }}
          data-testid={`floating-kpi-${i}`}
        >
          <motion.div
            animate={{ y: [0, -4, 0] }}
            transition={{ duration: 3 + i * 0.5, repeat: Infinity, ease: "easeInOut" }}
            whileHover={{ scale: 1.05, transition: { duration: 0.2 } }}
            className="glass rounded-md px-3 py-2 flex items-center gap-2 shadow-glassSoft cursor-default whitespace-nowrap"
          >
            <div className="w-5 h-5 rounded bg-vest-g5/10 flex items-center justify-center shrink-0">
              <chip.icon className="w-3 h-3 text-vest-g5" />
            </div>
            <span className="text-xs font-semibold text-ink-dark">{chip.label}</span>
          </motion.div>
        </motion.div>
      ))}
    </div>
  );
}
