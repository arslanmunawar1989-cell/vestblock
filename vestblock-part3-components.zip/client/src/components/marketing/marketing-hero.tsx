import { motion } from "framer-motion";

interface MarketingHeroProps {
  badge: string;
  title: string;
  highlight: string;
  subtitle: string;
  testIdPrefix: string;
  children?: React.ReactNode;
}

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

export function MarketingHero({ badge, title, highlight, subtitle, testIdPrefix, children }: MarketingHeroProps) {
  return (
    <section className="relative py-24 sm:py-32 px-4 overflow-hidden gradient-section-blue">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_60%_40%_at_50%_100%,rgba(30,43,255,.06)_0%,transparent_70%)]" />
      <motion.div
        className="relative max-w-4xl mx-auto text-center"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        transition={{ staggerChildren: 0.1 }}
      >
        <motion.div variants={fadeUp} transition={{ duration: 0.5 }}>
          <span className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide uppercase text-vest-g5 ring-1 ring-vest-g5/30 bg-vest-g5/5 mb-6" data-testid={`${testIdPrefix}-badge`}>
            {badge}
          </span>
        </motion.div>
        <motion.h1
          variants={fadeUp}
          transition={{ duration: 0.5 }}
          className="text-4xl sm:text-5xl lg:text-6xl font-bold text-ink-dark leading-tight mb-6"
          data-testid={`${testIdPrefix}-headline`}
        >
          {title}{" "}
          <span className="text-vest-g5">{highlight}</span>
        </motion.h1>
        <motion.p
          variants={fadeUp}
          transition={{ duration: 0.5 }}
          className="text-lg text-ink-muted max-w-2xl mx-auto leading-relaxed mb-8"
          data-testid={`${testIdPrefix}-subtext`}
        >
          {subtitle}
        </motion.p>
        {children && (
          <motion.div variants={fadeUp} transition={{ duration: 0.5 }}>
            {children}
          </motion.div>
        )}
      </motion.div>
    </section>
  );
}
