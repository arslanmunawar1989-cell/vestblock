import { MarketingNavbar } from "./navbar";
import { MarketingFooter } from "./footer";
import { AskWidget } from "@/components/ask-widget";
import { useRegion } from "@/lib/region";
import { Info } from "lucide-react";
import { Link } from "wouter";

interface MarketingLayoutProps {
  children: React.ReactNode;
}

function UaeBanner() {
  return (
    <div className="py-3 px-4 text-center" style={{ background: "rgba(30,43,255,0.06)", borderBottom: "1px solid rgba(30,43,255,0.1)" }}>
      <div className="max-w-7xl mx-auto flex items-center justify-center gap-2 flex-wrap">
        <Info className="w-4 h-4 text-vest-g5 shrink-0" />
        <span className="text-sm text-ink-muted">
          VestBlock UAE is launching soon. Content shown reflects our Pakistan operations.
        </span>
        <Link href="/contact" className="text-sm text-vest-g5 font-medium" data-testid="uae-banner-notify">
          Get notified
        </Link>
      </div>
    </div>
  );
}

export function MarketingLayout({ children }: MarketingLayoutProps) {
  const { region } = useRegion();
  const isUae = region.code === "ae";

  return (
    <div className="min-h-screen bg-vest-gradient">
      <MarketingNavbar />
      <main className="relative pt-14">
        {isUae && <UaeBanner />}
        {children}
      </main>
      <MarketingFooter />
      <AskWidget />
    </div>
  );
}
