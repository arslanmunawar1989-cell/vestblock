import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

interface AccordionItem {
  question: string;
  answer: string;
}

interface MarketingAccordionProps {
  items: AccordionItem[];
  className?: string;
}

export function MarketingAccordion({ items, className }: MarketingAccordionProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <div className={cn("space-y-3", className)}>
      {items.map((item, index) => (
        <div
          key={index}
          className={cn(
            "glass rounded-md overflow-hidden transition-all duration-300",
            openIndex === index && "border-vest-g5/20"
          )}
          data-testid={`accordion-item-${index}`}
        >
          <button
            className="w-full flex items-center justify-between gap-4 p-5 text-left"
            onClick={() => setOpenIndex(openIndex === index ? null : index)}
            data-testid={`accordion-trigger-${index}`}
          >
            <span className="text-sm font-medium text-ink-dark">{item.question}</span>
            <ChevronDown className={cn("w-4 h-4 text-vest-g5 shrink-0 transition-transform duration-200", openIndex === index && "rotate-180")} />
          </button>
          <div
            className={cn(
              "overflow-hidden transition-all duration-300",
              openIndex === index ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
            )}
          >
            <div className="px-5 pb-5 text-sm text-ink-muted leading-relaxed">
              {item.answer}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
