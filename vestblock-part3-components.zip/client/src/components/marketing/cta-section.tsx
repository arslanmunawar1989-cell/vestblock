import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import type { LucideIcon } from "lucide-react";

interface CtaAction {
  label: string;
  href: string;
  variant?: "primary" | "secondary";
}

interface CtaSectionProps {
  icon?: LucideIcon;
  title: string;
  highlight: string;
  subtitle: string;
  actions: CtaAction[];
  testId?: string;
}

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

export function CtaSection({ icon: Icon, title, highlight, subtitle, actions, testId }: CtaSectionProps) {
  return (
    <section className="py-20 px-4 gradient-section-bold relative overflow-hidden" data-testid={testId}>
      <div className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(ellipse 80% 60% at 50% 50%, rgba(255,255,255,0.08) 0%, transparent 70%)" }} />
      <motion.div
        className="relative max-w-3xl mx-auto text-center"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        transition={{ staggerChildren: 0.1 }}
      >
        {Icon && (
          <motion.div variants={fadeUp} transition={{ duration: 0.5 }}>
            <div className="w-14 h-14 rounded-md flex items-center justify-center mx-auto mb-6 bg-white/15">
              <Icon className="w-7 h-7 text-white" />
            </div>
          </motion.div>
        )}
        <motion.h2
          variants={fadeUp}
          transition={{ duration: 0.5 }}
          className="text-3xl sm:text-4xl font-bold text-white mb-4"
        >
          {title}{" "}
          <span className="text-white/90">{highlight}</span>
        </motion.h2>
        <motion.p
          variants={fadeUp}
          transition={{ duration: 0.5 }}
          className="text-white/75 text-base mb-8 leading-relaxed max-w-xl mx-auto"
        >
          {subtitle}
        </motion.p>
        <motion.div variants={fadeUp} transition={{ duration: 0.5 }} className="flex items-center justify-center gap-4 flex-wrap">
          {actions.map((a) => (
            <Link key={a.href} href={a.href}>
              <Button
                variant={a.variant === "secondary" ? "outline" : "default"}
                size="lg"
                className={
                  a.variant === "secondary"
                    ? "text-white border-white/30 bg-transparent"
                    : "bg-white text-[#1E2BFF] border-white shadow-lg shadow-black/10"
                }
                data-testid={`cta-${a.label.toLowerCase().replace(/\s+/g, "-")}`}
              >
                {a.label} {a.variant !== "secondary" && <ArrowRight className="w-4 h-4" />}
              </Button>
            </Link>
          ))}
        </motion.div>
      </motion.div>
    </section>
  );
}
