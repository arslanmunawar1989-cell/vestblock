import * as React from "react";

type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary";
};

export function GlassButton({ variant = "primary", className = "", ...props }: Props) {
  const base =
    "relative inline-flex items-center justify-center gap-2 rounded-md px-5 py-3 font-semibold transition-all duration-200 glass-noise";
  const primary = "glass-btn-primary";
  const secondary = "glass-btn-outline";

  return (
    <button
      {...props}
      className={`${base} ${variant === "primary" ? primary : secondary} ${className}`}
    >
      <span className="relative z-10">{props.children}</span>
    </button>
  );
}
