import { motion, AnimatePresence } from "framer-motion";
import { TrendingUp, ArrowUpRight, Building2, Users, Bell, ChevronRight, Wallet, BarChart3, PieChart, ArrowDownLeft, ArrowUpRight as ArrowUR, Check } from "lucide-react";
import { useState, useEffect, useCallback } from "react";

const tabs = ["Dashboard", "Portfolio", "Wallet"] as const;
type Tab = typeof tabs[number];

const transactions = [
  { type: "credit" as const, label: "Rental Income", property: "DHA Phase 6", amount: "+PKR 12,400", time: "2m ago" },
  { type: "credit" as const, label: "Distribution", property: "Clifton Block 5", amount: "+PKR 8,750", time: "1h ago" },
  { type: "debit" as const, label: "Investment", property: "F-8 Markaz", amount: "-PKR 50,000", time: "3h ago" },
  { type: "credit" as const, label: "Exit Proceeds", property: "Bahria Town", amount: "+PKR 125,000", time: "1d ago" },
  { type: "credit" as const, label: "Rental Income", property: "Gulberg III", amount: "+PKR 9,200", time: "2d ago" },
];

const notifications = [
  { title: "New Distribution", desc: "PKR 12,400 credited to wallet", color: "bg-green-500" },
  { title: "Exit Window Open", desc: "DHA Phase 6 — 3 days left", color: "bg-amber-500" },
  { title: "KYC Approved", desc: "Your identity has been verified", color: "bg-blue-500" },
];

const portfolioItems = [
  { name: "DHA Phase 6", tokens: 24, value: "PKR 840K", yield: "9.2%", progress: 72 },
  { name: "Clifton Block 5", tokens: 15, value: "PKR 525K", yield: "8.8%", progress: 89 },
  { name: "F-8 Markaz", tokens: 10, value: "PKR 350K", yield: "10.1%", progress: 45 },
  { name: "Bahria Town Ph 4", tokens: 20, value: "PKR 700K", yield: "7.5%", progress: 95 },
];

const walletBalances = [
  { currency: "PKR", balance: "2,450,000", flag: "🇵🇰" },
  { currency: "USD", balance: "8,240", flag: "🇺🇸" },
  { currency: "AED", balance: "12,100", flag: "🇦🇪" },
];

const chartPoints = [100, 115, 108, 128, 135, 148, 142, 160, 168, 175, 182, 195];

function useAnimatedValue(target: number, duration: number = 1500, delay: number = 0) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    const timeout = setTimeout(() => {
      let start = 0;
      const step = 16;
      const steps = duration / step;
      const inc = target / steps;
      const timer = setInterval(() => {
        start += inc;
        if (start >= target) { setValue(target); clearInterval(timer); }
        else setValue(start);
      }, step);
      return () => clearInterval(timer);
    }, delay);
    return () => clearTimeout(timeout);
  }, [target, duration, delay]);
  return value;
}

function MiniChart({ animate }: { animate: boolean }) {
  const [visiblePoints, setVisiblePoints] = useState(0);

  useEffect(() => {
    if (!animate) return;
    let i = 0;
    const timer = setInterval(() => {
      i++;
      setVisiblePoints(i);
      if (i >= chartPoints.length) clearInterval(timer);
    }, 180);
    return () => clearInterval(timer);
  }, [animate]);

  const points = chartPoints.slice(0, visiblePoints);
  if (points.length < 2) return <div className="w-full h-full" />;

  const max = Math.max(...chartPoints);
  const min = Math.min(...chartPoints);
  const range = max - min || 1;
  const w = 240;
  const h = 56;
  const pad = 2;

  const pathPoints = points.map((v, i) => {
    const x = pad + (i / (chartPoints.length - 1)) * (w - pad * 2);
    const y = h - pad - ((v - min) / range) * (h - pad * 2);
    return { x, y };
  });

  let d = `M ${pathPoints[0].x} ${pathPoints[0].y}`;
  for (let i = 1; i < pathPoints.length; i++) {
    const prev = pathPoints[i - 1];
    const curr = pathPoints[i];
    const cpx1 = prev.x + (curr.x - prev.x) * 0.4;
    const cpx2 = prev.x + (curr.x - prev.x) * 0.6;
    d += ` C ${cpx1} ${prev.y} ${cpx2} ${curr.y} ${curr.x} ${curr.y}`;
  }

  const last = pathPoints[pathPoints.length - 1];
  const areaD = d + ` L ${last.x} ${h} L ${pathPoints[0].x} ${h} Z`;

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-full" preserveAspectRatio="none">
      <defs>
        <linearGradient id="lcGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#1E2BFF" stopOpacity={0.25} />
          <stop offset="100%" stopColor="#1E2BFF" stopOpacity={0.02} />
        </linearGradient>
      </defs>
      <path d={areaD} fill="url(#lcGrad)" />
      <path d={d} fill="none" stroke="#1E2BFF" strokeWidth="1.5" strokeLinecap="round" />
      <circle cx={last.x} cy={last.y} r="2.5" fill="#1E2BFF" opacity={0.8}>
        <animate attributeName="r" values="2.5;4;2.5" dur="2s" repeatCount="indefinite" />
        <animate attributeName="opacity" values="0.8;0.4;0.8" dur="2s" repeatCount="indefinite" />
      </circle>
    </svg>
  );
}

function DashboardScreen() {
  const portfolioValue = useAnimatedValue(2450000, 2000, 400);
  const monthlyYield = useAnimatedValue(9.1, 1500, 600);
  const properties = useAnimatedValue(8, 800, 800);
  const investors = useAnimatedValue(12400, 2000, 1000);

  const [txIndex, setTxIndex] = useState(0);
  const [notifVisible, setNotifVisible] = useState(false);
  const [notifIndex, setNotifIndex] = useState(0);
  const [chartAnimate, setChartAnimate] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setChartAnimate(true), 1200);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTxIndex((prev) => (prev + 1) % transactions.length);
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const show = setTimeout(() => setNotifVisible(true), 2500);
    const cycle = setInterval(() => {
      setNotifVisible(false);
      setTimeout(() => {
        setNotifIndex((prev) => (prev + 1) % notifications.length);
        setNotifVisible(true);
      }, 400);
    }, 5000);
    return () => { clearTimeout(show); clearInterval(cycle); };
  }, []);

  const kpis = [
    { label: "Portfolio Value", value: `PKR ${(portfolioValue / 1000000).toFixed(2)}M`, change: "+12.4%", icon: TrendingUp },
    { label: "Monthly Yield", value: `${monthlyYield.toFixed(1)}%`, change: "+0.3%", icon: ArrowUpRight },
    { label: "Properties", value: `${Math.round(properties)}`, change: "+2", icon: Building2 },
    { label: "Investors", value: Math.round(investors).toLocaleString(), change: "+340", icon: Users },
  ];

  const visibleTx = [
    transactions[txIndex % transactions.length],
    transactions[(txIndex + 1) % transactions.length],
    transactions[(txIndex + 2) % transactions.length],
  ];

  return (
    <>
      <AnimatePresence>
        {notifVisible && (
          <motion.div
            initial={{ opacity: 0, y: -8, x: 0 }}
            animate={{ opacity: 1, y: 0, x: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.3 }}
            className="absolute top-8 right-2 z-20 flex items-start gap-1.5 bg-white rounded-md shadow-lg shadow-black/5 border border-vest-g5/10 px-2 py-1.5 max-w-[140px]"
          >
            <div className={`w-1.5 h-1.5 rounded-full mt-1 shrink-0 ${notifications[notifIndex].color}`} />
            <div className="min-w-0">
              <div className="text-[7px] font-semibold text-ink-dark truncate">{notifications[notifIndex].title}</div>
              <div className="text-[6px] text-ink-muted/60 truncate">{notifications[notifIndex].desc}</div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-4 gap-1.5">
        {kpis.map((kpi, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 + i * 0.1, duration: 0.4 }}
            className="glass-light rounded-md p-1.5"
          >
            <div className="flex items-center gap-1 mb-0.5">
              <kpi.icon className="w-2 h-2 text-vest-g4" />
              <span className="text-[5.5px] text-ink-muted/60 truncate">{kpi.label}</span>
            </div>
            <div className="text-[9px] font-bold text-ink-dark leading-none">{kpi.value}</div>
            <div className="text-[6px] text-vest-g5 font-medium mt-0.5">{kpi.change}</div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-[1fr_100px] gap-1.5 mt-2">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.4 }}
          className="glass-light rounded-md p-1.5"
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-[6px] text-ink-muted/60 uppercase tracking-wider">Portfolio Growth</span>
            <span className="text-[6px] text-vest-g5 font-semibold">+95%</span>
          </div>
          <div className="h-14">
            <MiniChart animate={chartAnimate} />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.4 }}
          className="glass-light rounded-md p-1.5"
        >
          <div className="text-[6px] text-ink-muted/60 uppercase tracking-wider mb-1">Activity</div>
          <div className="space-y-1 overflow-hidden">
            <AnimatePresence mode="popLayout">
              {visibleTx.map((tx, i) => (
                <motion.div
                  key={`${tx.label}-${tx.property}-${txIndex + i}`}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.3, delay: i * 0.05 }}
                  className="flex items-center gap-1"
                >
                  <div className={`w-3 h-3 rounded-full flex items-center justify-center shrink-0 ${tx.type === "credit" ? "bg-green-50" : "bg-red-50"}`}>
                    {tx.type === "credit"
                      ? <ArrowDownLeft className="w-1.5 h-1.5 text-green-600" />
                      : <ArrowUR className="w-1.5 h-1.5 text-red-500" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-[6px] text-ink-dark truncate font-medium">{tx.property}</div>
                    <div className={`text-[5.5px] font-semibold ${tx.type === "credit" ? "text-green-600" : "text-red-500"}`}>{tx.amount}</div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </>
  );
}

function PortfolioScreen() {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <span className="text-[7px] font-semibold text-ink-dark">Your Holdings</span>
        <span className="text-[6px] text-vest-g5 font-medium">4 Properties</span>
      </div>
      {portfolioItems.map((item, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, x: -12 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 + i * 0.12, duration: 0.35 }}
          className="glass-light rounded-md p-1.5"
        >
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-1">
              <div className="w-3.5 h-3.5 rounded bg-vest-g5/10 flex items-center justify-center">
                <Building2 className="w-2 h-2 text-vest-g5" />
              </div>
              <span className="text-[7px] font-medium text-ink-dark">{item.name}</span>
            </div>
            <span className="text-[7px] font-bold text-ink-dark">{item.value}</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex-1 h-1 bg-vest-g0 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-vest-g5 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${item.progress}%` }}
                transition={{ delay: 0.6 + i * 0.15, duration: 0.7, ease: "easeOut" }}
              />
            </div>
            <span className="text-[5.5px] text-vest-g5 font-medium shrink-0">{item.yield} yield</span>
            <span className="text-[5.5px] text-ink-muted/50 shrink-0">{item.tokens} tokens</span>
          </div>
        </motion.div>
      ))}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="flex items-center justify-center gap-1 py-1"
      >
        <span className="text-[6px] text-vest-g5 font-medium">View All Holdings</span>
        <ChevronRight className="w-2 h-2 text-vest-g5" />
      </motion.div>
    </div>
  );
}

function WalletScreen() {
  const [activeWallet, setActiveWallet] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveWallet((prev) => (prev + 1) % walletBalances.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-[7px] font-semibold text-ink-dark">Multi-Currency Wallet</span>
        <div className="flex items-center gap-0.5">
          {walletBalances.map((_, i) => (
            <div key={i} className={`w-1 h-1 rounded-full transition-colors ${i === activeWallet ? "bg-vest-g5" : "bg-vest-g2"}`} />
          ))}
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={activeWallet}
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.96 }}
          transition={{ duration: 0.3 }}
          className="rounded-md p-2.5 bg-gradient-to-br from-vest-g4 to-vest-g5"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-[7px] text-white/60">{walletBalances[activeWallet].currency} Balance</span>
            <Wallet className="w-3 h-3 text-white/40" />
          </div>
          <div className="text-[14px] font-bold text-white leading-none">{walletBalances[activeWallet].balance}</div>
          <div className="text-[7px] text-white/50 mt-1">{walletBalances[activeWallet].currency}</div>
        </motion.div>
      </AnimatePresence>

      <div className="grid grid-cols-3 gap-1">
        {["Deposit", "Withdraw", "Convert"].map((action, i) => (
          <motion.div
            key={action}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 + i * 0.1 }}
            className="glass-light rounded-md p-1.5 text-center"
          >
            <div className="w-3 h-3 rounded-full bg-vest-g5/10 flex items-center justify-center mx-auto mb-0.5">
              {i === 0 && <ArrowDownLeft className="w-1.5 h-1.5 text-vest-g5" />}
              {i === 1 && <ArrowUR className="w-1.5 h-1.5 text-vest-g5" />}
              {i === 2 && <BarChart3 className="w-1.5 h-1.5 text-vest-g5" />}
            </div>
            <span className="text-[6px] text-ink-muted">{action}</span>
          </motion.div>
        ))}
      </div>

      <div className="space-y-1">
        <span className="text-[6px] text-ink-muted/60 uppercase tracking-wider">Recent</span>
        {transactions.slice(0, 3).map((tx, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 + i * 0.12 }}
            className="flex items-center justify-between"
          >
            <div className="flex items-center gap-1">
              <div className={`w-1 h-1 rounded-full ${tx.type === "credit" ? "bg-green-500" : "bg-red-400"}`} />
              <span className="text-[6px] text-ink-dark">{tx.label}</span>
            </div>
            <span className={`text-[6px] font-medium ${tx.type === "credit" ? "text-green-600" : "text-red-500"}`}>{tx.amount}</span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

interface LaptopMockupProps {
  className?: string;
}

export function LaptopMockup({ className = "" }: LaptopMockupProps) {
  const [activeTab, setActiveTab] = useState<Tab>("Dashboard");
  const [autoSwitch, setAutoSwitch] = useState(true);

  useEffect(() => {
    if (!autoSwitch) return;
    const timer = setInterval(() => {
      setActiveTab((prev) => {
        const idx = tabs.indexOf(prev);
        return tabs[(idx + 1) % tabs.length];
      });
    }, 8000);
    return () => clearInterval(timer);
  }, [autoSwitch]);

  const handleTabClick = useCallback((tab: Tab) => {
    setActiveTab(tab);
    setAutoSwitch(false);
    setTimeout(() => setAutoSwitch(true), 20000);
  }, []);

  return (
    <motion.div
      className={`relative ${className}`}
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }}
      data-testid="laptop-mockup"
    >
      <motion.div
        animate={{ y: [0, -6, 0] }}
        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
        className="relative"
        whileHover={{ rotateY: 3, transition: { duration: 0.4 } }}
        style={{ perspective: 800 }}
      >
        <div className="relative w-full max-w-[540px] mx-auto">
          <div className="rounded-t-xl bg-gradient-to-b from-vest-g4 to-ink-dark p-[6px] pb-0">
            <div className="flex items-center gap-1.5 px-3 py-1.5">
              <div className="w-2 h-2 rounded-full bg-vest-g2/60" />
              <div className="w-2 h-2 rounded-full bg-vest-g1/60" />
              <div className="w-2 h-2 rounded-full bg-vest-g0/60" />
              <div className="ml-4 flex-1 h-4 rounded-sm bg-white/10 flex items-center justify-center">
                <span className="text-[7px] text-white/40 tracking-wider">vestblock.pk/investor/{activeTab.toLowerCase()}</span>
              </div>
              <motion.div
                className="relative"
                animate={{ scale: [1, 1.15, 1] }}
                transition={{ duration: 3, repeat: Infinity, repeatDelay: 4 }}
              >
                <Bell className="w-3 h-3 text-white/40" />
                <div className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-red-400" />
              </motion.div>
            </div>

            <div className="bg-white rounded-t-md overflow-hidden relative" data-testid="laptop-screen">
              <div className="h-6 bg-vest-g0/50 border-b border-vest-g5/[0.06] flex items-center px-2 gap-2">
                <div className="flex items-center gap-1">
                  <div className="w-3.5 h-3.5 rounded bg-vest-g5 flex items-center justify-center">
                    <span className="text-[5px] font-bold text-white">V</span>
                  </div>
                  <span className="text-[7px] font-semibold text-ink-dark">VestBlock</span>
                </div>
                <div className="flex gap-1 ml-auto">
                  {tabs.map((tab) => (
                    <button
                      key={tab}
                      onClick={() => handleTabClick(tab)}
                      className={`text-[6.5px] px-1.5 py-0.5 rounded transition-all duration-300 cursor-pointer ${
                        tab === activeTab
                          ? "bg-vest-g5/10 text-vest-g5 font-medium"
                          : "text-ink-muted/50 hover:text-ink-muted"
                      }`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>
                <div className="w-3 h-3 rounded-full bg-vest-g2/30 flex items-center justify-center ml-1">
                  <span className="text-[5px] font-bold text-vest-g5">U</span>
                </div>
              </div>

              <div className="p-2.5 min-h-[160px] relative">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeTab}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                  >
                    {activeTab === "Dashboard" && <DashboardScreen />}
                    {activeTab === "Portfolio" && <PortfolioScreen />}
                    {activeTab === "Wallet" && <WalletScreen />}
                  </motion.div>
                </AnimatePresence>
              </div>

              <div className="h-5 border-t border-vest-g5/[0.04] bg-vest-g0/20 flex items-center justify-between px-2.5">
                <div className="flex items-center gap-1">
                  <Check className="w-2 h-2 text-green-500" />
                  <span className="text-[5.5px] text-ink-muted/40">Connected</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[5.5px] text-ink-muted/40">SECP Regulated</span>
                  <span className="text-[5.5px] text-vest-g5/40">v2.4.1</span>
                </div>
              </div>
            </div>
          </div>

          <div className="h-[6px] bg-gradient-to-b from-vest-g4 to-vest-g3 rounded-b-sm mx-1" />
          <div className="relative mx-[-4%]">
            <div className="h-[10px] bg-gradient-to-b from-vest-g3 to-vest-g4 rounded-b-xl" style={{ clipPath: "polygon(4% 0%, 96% 0%, 100% 100%, 0% 100%)" }}>
              <div className="absolute top-[2px] left-1/2 -translate-x-1/2 w-16 h-[3px] rounded-full bg-white/[0.06]" />
            </div>
          </div>
        </div>

        <div className="absolute -inset-8 rounded-3xl bg-vest-g3/8 blur-3xl -z-10" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-vest-g2/10 rounded-full blur-[60px] -z-10" />
      </motion.div>
    </motion.div>
  );
}
