import * as React from "react";

export function GlassCard({ className = "", ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      {...props}
      className={`glass glass-noise rounded-md p-6 ${className}`}
    />
  );
}
