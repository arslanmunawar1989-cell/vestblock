import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { FileText, Shield, AlertTriangle, Loader2, ExternalLink, Globe, Building2 } from "lucide-react";
import { Link } from "wouter";
import { COUNTRY_DETAILS } from "@shared/constants";

interface PendingDoc {
  id: string;
  type: string;
  title: string;
  version: number;
  country?: string | null;
  productType?: string;
  jurisdictionCode?: string | null;
}

interface AcceptanceStatus {
  allAccepted: boolean;
  pending: PendingDoc[];
  accepted: { id: string; type: string; title: string; version: number; acceptedAt?: string }[];
}

interface InvestmentCheckStatus {
  allAccepted: boolean;
  country: string;
  vehicleType: string;
  totalRequired: number;
  pending: PendingDoc[];
}

const typeIcons: Record<string, typeof FileText> = {
  terms_of_service: FileText,
  privacy_policy: Shield,
  risk_disclosure: AlertTriangle,
  subscription_agreement: FileText,
  offering_memorandum: FileText,
  fund_prospectus: FileText,
  spv_disclosure: Building2,
};

const productTypeLabels: Record<string, string> = {
  FUND: "Fund",
  SPV: "SPV",
  TRUST: "Trust",
  GENERAL: "General",
};

interface LegalAcceptanceModalProps {
  open: boolean;
  onClose: () => void;
  onAccepted: () => void;
  country?: string;
  vehicleType?: string;
}

export function LegalAcceptanceModal({ open, onClose, onAccepted, country, vehicleType }: LegalAcceptanceModalProps) {
  const { toast } = useToast();
  const [checkedDocs, setCheckedDocs] = useState<Set<string>>(new Set());

  const isInvestmentMode = !!(country && vehicleType);

  const { data: generalStatus, isLoading: generalLoading } = useQuery<AcceptanceStatus>({
    queryKey: ["/api/legal/acceptance/status"],
    enabled: open && !isInvestmentMode,
  });

  const { data: investStatus, isLoading: investLoading } = useQuery<InvestmentCheckStatus>({
    queryKey: ["/api/legal/acceptance/investment-check", country, vehicleType],
    queryFn: async () => {
      const res = await fetch(`/api/legal/acceptance/investment-check?country=${country}&vehicleType=${vehicleType}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to check");
      return res.json();
    },
    enabled: open && isInvestmentMode,
  });

  const isLoading = isInvestmentMode ? investLoading : generalLoading;
  const pendingDocs: PendingDoc[] = isInvestmentMode
    ? (investStatus?.pending || [])
    : (generalStatus?.pending || []);

  const acceptMutation = useMutation({
    mutationFn: async (documentIds: string[]) => {
      const res = await apiRequest("POST", "/api/legal/accept", { documentIds });
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Legal agreements accepted", description: "You can now proceed with your action." });
      queryClient.invalidateQueries({ queryKey: ["/api/legal/acceptance/status"] });
      if (isInvestmentMode) {
        queryClient.invalidateQueries({ queryKey: ["/api/legal/acceptance/investment-check", country, vehicleType] });
      }
      setCheckedDocs(new Set());
      onAccepted();
    },
    onError: () => {
      toast({ title: "Failed to accept", description: "Please try again.", variant: "destructive" });
    },
  });

  const allChecked = pendingDocs.length > 0 && pendingDocs.every(d => checkedDocs.has(d.id));

  const toggleDoc = (docId: string) => {
    setCheckedDocs(prev => {
      const next = new Set(prev);
      if (next.has(docId)) next.delete(docId);
      else next.add(docId);
      return next;
    });
  };

  const handleAccept = () => {
    if (!allChecked) return;
    acceptMutation.mutate(pendingDocs.map(d => d.id));
  };

  const countryName = country
    ? (COUNTRY_DETAILS as any)[country]?.name || country
    : null;

  const description = isInvestmentMode
    ? `You must review and accept the following legal documents for ${countryName || country} ${productTypeLabels[vehicleType || ""] || vehicleType} investments before proceeding.`
    : "You must review and accept the following legal documents before proceeding with investment or financial actions on the platform.";

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle data-testid="legal-modal-title">Legal Agreements Required</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>

        {isInvestmentMode && (
          <div className="flex items-center gap-2 flex-wrap text-xs text-muted-foreground">
            <Globe className="w-3.5 h-3.5" />
            <span data-testid="text-legal-jurisdiction">{countryName || country}</span>
            <Building2 className="w-3.5 h-3.5 ml-2" />
            <span data-testid="text-legal-product-type">{productTypeLabels[vehicleType || ""] || vehicleType}</span>
          </div>
        )}

        {isLoading && (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
          </div>
        )}

        {!isLoading && pendingDocs.length === 0 && (
          <div className="py-6 text-center text-sm text-muted-foreground" data-testid="text-all-accepted">
            All required legal documents have been accepted.
          </div>
        )}

        {!isLoading && pendingDocs.length > 0 && (
          <ScrollArea className="max-h-[400px]">
            <div className="space-y-3 pr-2">
              {pendingDocs.map((doc) => {
                const Icon = typeIcons[doc.type] || FileText;
                const isChecked = checkedDocs.has(doc.id);
                return (
                  <div
                    key={doc.id}
                    className="flex items-start gap-3 p-3 rounded-md border bg-card"
                    data-testid={`legal-doc-item-${doc.id}`}
                  >
                    <Checkbox
                      checked={isChecked}
                      onCheckedChange={() => toggleDoc(doc.id)}
                      className="mt-1"
                      data-testid={`checkbox-accept-${doc.id}`}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Icon className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                        <span className="font-medium text-sm">{doc.title}</span>
                        <Badge variant="outline" className="text-xs">v{doc.version}</Badge>
                      </div>
                      {doc.productType && doc.productType !== "GENERAL" && (
                        <div className="mt-1">
                          <Badge variant="secondary" className="text-xs">
                            {productTypeLabels[doc.productType] || doc.productType}
                          </Badge>
                        </div>
                      )}
                      <div className="mt-1">
                        <Link href={`/legal/${doc.type}`} target="_blank">
                          <span className="text-xs text-primary flex items-center gap-1 cursor-pointer hover:underline" data-testid={`link-view-${doc.id}`}>
                            Read full document <ExternalLink className="w-3 h-3" />
                          </span>
                        </Link>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        )}

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose} data-testid="button-cancel-legal">
            Cancel
          </Button>
          <Button
            onClick={handleAccept}
            disabled={!allChecked || acceptMutation.isPending}
            data-testid="button-accept-legal"
          >
            {acceptMutation.isPending && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
            Accept & Continue
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function useLegalAcceptance() {
  const { data: status, isLoading } = useQuery<AcceptanceStatus>({
    queryKey: ["/api/legal/acceptance/status"],
  });

  return {
    allAccepted: status?.allAccepted ?? false,
    pendingCount: status?.pending?.length ?? 0,
    isLoading,
    status,
  };
}

export function useInvestmentLegalCheck(country?: string, vehicleType?: string) {
  const enabled = !!(country && vehicleType);
  const { data, isLoading } = useQuery<InvestmentCheckStatus>({
    queryKey: ["/api/legal/acceptance/investment-check", country, vehicleType],
    queryFn: async () => {
      const res = await fetch(`/api/legal/acceptance/investment-check?country=${country}&vehicleType=${vehicleType}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to check");
      return res.json();
    },
    enabled,
  });

  return {
    allAccepted: data?.allAccepted ?? !enabled,
    pendingCount: data?.pending?.length ?? 0,
    isLoading,
    data,
  };
}
