import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle, X, Send, Bot, User, Sparkles, Shield, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useRegion } from "@/lib/region";

interface Citation {
  title: string;
  slug: string;
  type: string;
}

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  citations?: Citation[];
}

const QUICK_QUESTIONS = [
  "What is the minimum investment?",
  "How do exit windows work?",
  "What fees apply?",
];

export function AskWidget() {
  const { region } = useRegion();
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  async function send(query?: string) {
    const text = query || input.trim();
    if (!text || loading) return;
    const userMsg: Message = { id: Date.now().toString(), role: "user", content: text };
    setMessages((p) => [...p, userMsg]);
    setInput("");
    setLoading(true);
    try {
      const res = await fetch("/api/ai/rag/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: text, region: region.code.toUpperCase() }),
      });
      const data = await res.json();
      const content = data.answer || "Sorry, I couldn't process that.";
      setMessages((p) => [
        ...p,
        {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content,
          citations: data.citations,
        },
      ]);
    } catch {
      setMessages((p) => [
        ...p,
        { id: (Date.now() + 1).toString(), role: "assistant", content: "Something went wrong." },
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-20 right-4 sm:right-6 z-50 w-[360px] max-w-[calc(100vw-32px)] bg-white rounded-2xl shadow-2xl shadow-black/15 border border-vest-g5/15 flex flex-col overflow-hidden"
            style={{ maxHeight: "min(520px, calc(100vh - 120px))" }}
            data-testid="ask-widget-panel"
          >
            <div className="px-4 py-3 flex items-center justify-between border-b border-vest-g5/10" style={{ background: "linear-gradient(135deg, #EEF0FF 0%, #D6DBFF 100%)" }}>
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-[#1E2BFF] to-[#3B4FFF] flex items-center justify-center">
                  <Sparkles className="w-3.5 h-3.5 text-white" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-ink-dark">Ask VestBlock</p>
                  <p className="text-[10px] text-ink-muted/60 flex items-center gap-1">
                    <Shield className="w-2.5 h-2.5" /> Informational only
                  </p>
                </div>
              </div>
              <button onClick={() => setOpen(false)} className="w-7 h-7 rounded-lg hover:bg-ink-dark/5 flex items-center justify-center" data-testid="close-widget">
                <X className="w-4 h-4 text-ink-muted" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-3 py-3 space-y-3" style={{ minHeight: 200 }}>
              {messages.length === 0 && (
                <div className="text-center py-4">
                  <Bot className="w-8 h-8 mx-auto text-[#1E2BFF]/25 mb-2" />
                  <p className="text-xs text-ink-muted mb-3">Ask me anything</p>
                  <div className="flex flex-col gap-1.5">
                    {QUICK_QUESTIONS.map((q) => (
                      <button
                        key={q}
                        onClick={() => send(q)}
                        className="text-xs px-3 py-1.5 rounded-lg border border-vest-g5/15 text-ink-muted hover:border-[#1E2BFF]/30 hover:text-[#1E2BFF] transition-colors text-left bg-white/80"
                        data-testid={`widget-q-${q.slice(0, 15).replace(/\s/g, "-").toLowerCase()}`}
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              {messages.map((m) => (
                <div key={m.id} className={`flex gap-2 items-start ${m.role === "user" ? "flex-row-reverse" : ""}`} data-testid={`widget-msg-${m.role}-${m.id}`}>
                  <div className={`w-6 h-6 rounded-md flex items-center justify-center shrink-0 ${m.role === "user" ? "bg-ink-dark/8" : "bg-gradient-to-br from-[#1E2BFF] to-[#3B4FFF]"}`}>
                    {m.role === "user" ? <User className="w-3 h-3 text-ink-dark/50" /> : <Bot className="w-3 h-3 text-white" />}
                  </div>
                  <div className={`max-w-[80%] rounded-xl px-3 py-2 text-xs leading-relaxed ${m.role === "user" ? "bg-gradient-to-r from-[#1E2BFF] to-[#3B4FFF] text-white" : "bg-gray-50 border border-vest-g5/10 text-ink-dark"}`}>
                    {(() => {
                      const disclaimerIdx = m.content.indexOf("\n\n---\n*");
                      const body = disclaimerIdx > -1 ? m.content.substring(0, disclaimerIdx) : m.content;
                      const disclaimer = disclaimerIdx > -1 ? m.content.substring(disclaimerIdx + 5).replace(/^\*|\*$/g, "").trim() : null;
                      return (
                        <>
                          <div className="whitespace-pre-wrap">{body}</div>
                          {disclaimer && (
                            <div className="mt-2 pt-1.5 border-t border-vest-g5/10 flex gap-1 items-start">
                              <AlertTriangle className="w-2.5 h-2.5 text-amber-500 shrink-0 mt-0.5" />
                              <p className="text-[10px] text-ink-muted/50 leading-relaxed italic">{disclaimer}</p>
                            </div>
                          )}
                        </>
                      );
                    })()}
                    {m.citations && m.citations.length > 0 && (
                      <div className="mt-1.5 pt-1.5 border-t border-vest-g5/10">
                        <p className="text-[10px] text-ink-muted/50 mb-0.5">{m.citations.length} source{m.citations.length > 1 ? "s" : ""}</p>
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex gap-2 items-start">
                  <div className="w-6 h-6 rounded-md bg-gradient-to-br from-[#1E2BFF] to-[#3B4FFF] flex items-center justify-center shrink-0">
                    <Bot className="w-3 h-3 text-white" />
                  </div>
                  <div className="bg-gray-50 border border-vest-g5/10 rounded-xl px-3 py-2">
                    <div className="flex gap-1" data-testid="widget-typing">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#1E2BFF]/30 animate-bounce" style={{ animationDelay: "0ms" }} />
                      <span className="w-1.5 h-1.5 rounded-full bg-[#1E2BFF]/30 animate-bounce" style={{ animationDelay: "150ms" }} />
                      <span className="w-1.5 h-1.5 rounded-full bg-[#1E2BFF]/30 animate-bounce" style={{ animationDelay: "300ms" }} />
                    </div>
                  </div>
                </div>
              )}
              <div ref={endRef} />
            </div>

            <div className="border-t border-vest-g5/10 px-3 py-2.5">
              <div className="flex gap-2 items-end">
                <input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); send(); } }}
                  placeholder="Type a question..."
                  className="flex-1 rounded-lg border border-vest-g5/15 bg-white px-3 py-2 text-xs text-ink-dark placeholder:text-ink-muted/40 focus:outline-none focus:ring-1 focus:ring-[#1E2BFF]/20"
                  data-testid="widget-input"
                />
                <Button
                  onClick={() => send()}
                  disabled={!input.trim() || loading}
                  className="bg-gradient-to-r from-[#1E2BFF] to-[#3B4FFF] text-white rounded-lg h-[34px] w-[34px] p-0 shrink-0"
                  data-testid="widget-send"
                >
                  <Send className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        onClick={() => setOpen(!open)}
        className="fixed bottom-4 right-4 sm:right-6 z-50 w-14 h-14 rounded-full bg-gradient-to-br from-[#1E2BFF] to-[#3B4FFF] text-white shadow-lg shadow-[#1E2BFF]/25 flex items-center justify-center hover:scale-105 active:scale-95 transition-transform"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        data-testid="ask-widget-fab"
      >
        <AnimatePresence mode="wait">
          {open ? (
            <motion.div key="close" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}>
              <X className="w-6 h-6" />
            </motion.div>
          ) : (
            <motion.div key="chat" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }}>
              <MessageCircle className="w-6 h-6" />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>
    </>
  );
}
