import { cn } from "@/lib/utils";

interface SectionProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
  description?: string;
  action?: React.ReactNode;
}

export function Section({ children, className, title, description, action }: SectionProps) {
  return (
    <section className={cn("space-y-4", className)}>
      {(title || description || action) && (
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            {title && (
              <h2 className="text-lg font-semibold tracking-tight" data-testid={`section-title-${title.toLowerCase().replace(/\s/g, '-')}`}>
                {title}
              </h2>
            )}
            {description && (
              <p className="text-sm text-muted-foreground mt-0.5">
                {description}
              </p>
            )}
          </div>
          {action}
        </div>
      )}
      {children}
    </section>
  );
}
