import { Button } from "@/components/ui/button";
import { SiWhatsapp } from "react-icons/si";
import { CURRENCY_DETAILS, type CurrencyCode } from "@shared/constants";
import { formatCurrency } from "@/lib/format";

interface WhatsAppShareProps {
  assetName: string;
  assetSymbol: string;
  pricePerToken: string;
  baseCurrency: string;
  annualYield?: string | null;
  assetType?: string;
  location?: string | null;
  assetId: string;
  variant?: "default" | "outline" | "ghost";
  size?: "default" | "sm" | "icon";
  className?: string;
}

function buildShareText(props: WhatsAppShareProps): string {
  const { assetName, assetSymbol, pricePerToken, baseCurrency, annualYield, assetType, location } = props;
  const price = formatCurrency(pricePerToken, baseCurrency);
  const currencyInfo = CURRENCY_DETAILS[baseCurrency as CurrencyCode];
  const currencyName = currencyInfo?.name || baseCurrency;

  let text = `Check out ${assetName} (${assetSymbol}) on VestBlock!\n\n`;
  text += `Token Price: ${price}\n`;
  if (assetType) text += `Type: ${assetType}\n`;
  if (location) text += `Location: ${location}\n`;
  if (annualYield) text += `Annual Yield: ${annualYield}%\n`;
  text += `Currency: ${currencyName} (${baseCurrency})\n\n`;
  text += `Invest now on VestBlock`;

  return text;
}

export function WhatsAppShareButton({
  variant = "outline",
  size = "sm",
  className = "",
  ...props
}: WhatsAppShareProps) {
  const handleShare = () => {
    const text = buildShareText(props);
    const url = `${window.location.origin}/investor/marketplace/${props.assetId}`;
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(`${text}\n${url}`)}`;
    window.open(whatsappUrl, "_blank", "noopener,noreferrer");
  };

  return (
    <Button
      variant={variant}
      size={size}
      onClick={handleShare}
      className={className}
      data-testid={`button-whatsapp-share-${props.assetId}`}
    >
      <SiWhatsapp className="w-4 h-4 mr-1" />
      Share
    </Button>
  );
}

export function WhatsAppShareIcon({ ...props }: Omit<WhatsAppShareProps, "variant" | "size" | "className">) {
  const handleShare = () => {
    const text = buildShareText(props);
    const url = `${window.location.origin}/investor/marketplace/${props.assetId}`;
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(`${text}\n${url}`)}`;
    window.open(whatsappUrl, "_blank", "noopener,noreferrer");
  };

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={handleShare}
      data-testid={`button-whatsapp-icon-${props.assetId}`}
    >
      <SiWhatsapp className="w-4 h-4" />
    </Button>
  );
}
