import { useQuery } from "@tanstack/react-query";

export function useCmsProperties(region: string = "PK") {
  return useQuery<any[]>({
    queryKey: ["/api/public/cms/properties", region],
    queryFn: async () => {
      const res = await fetch(`/api/public/cms/properties?region=${region}`);
      if (!res.ok) throw new Error("Failed to fetch CMS properties");
      return res.json();
    },
    staleTime: 5 * 60 * 1000,
  });
}

export function useCmsBlogPosts(region: string = "PK") {
  return useQuery<any[]>({
    queryKey: ["/api/public/cms/blog", region],
    queryFn: async () => {
      const res = await fetch(`/api/public/cms/blog?region=${region}`);
      if (!res.ok) throw new Error("Failed to fetch CMS blog posts");
      return res.json();
    },
    staleTime: 5 * 60 * 1000,
  });
}

export function useCmsBlogPost(slug: string) {
  return useQuery<any>({
    queryKey: ["/api/public/cms/blog", slug],
    queryFn: async () => {
      const res = await fetch(`/api/public/cms/blog/${slug}`);
      if (!res.ok) throw new Error("Failed to fetch blog post");
      return res.json();
    },
    staleTime: 5 * 60 * 1000,
    enabled: !!slug,
  });
}

export function useCmsFaqs(region: string = "PK") {
  return useQuery<any[]>({
    queryKey: ["/api/public/cms/faq", region],
    queryFn: async () => {
      const res = await fetch(`/api/public/cms/faq?region=${region}`);
      if (!res.ok) throw new Error("Failed to fetch FAQs");
      return res.json();
    },
    staleTime: 5 * 60 * 1000,
  });
}

export function useCmsFees(region: string = "PK") {
  return useQuery<any[]>({
    queryKey: ["/api/public/cms/fees", region],
    queryFn: async () => {
      const res = await fetch(`/api/public/cms/fees?region=${region}`);
      if (!res.ok) throw new Error("Failed to fetch fees");
      return res.json();
    },
    staleTime: 5 * 60 * 1000,
  });
}
