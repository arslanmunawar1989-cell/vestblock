import { Switch, Route, Router, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { AuthProvider } from "@/lib/auth";
import { ProtectedRoute } from "@/components/protected-route";
import { ErrorBoundary } from "@/components/error-boundary";
import { RoleLayout } from "@/components/role-layout";
import { useAuth } from "@/lib/auth";
import type { Role } from "@shared/schema";
import NotFound from "@/pages/not-found";
import { RegionProvider, getStoredRegion } from "@/lib/region";
import type { RegionCode } from "@/lib/region";

import Login from "@/pages/login";
import Register from "@/pages/register";
import SignIn from "@/pages/auth/sign-in";

import CmsDashboard from "@/pages/cms/dashboard";
import CmsPages from "@/pages/cms/pages";
import CmsProperties from "@/pages/cms/properties";
import CmsBlog from "@/pages/cms/blog";
import CmsFaq from "@/pages/cms/faq";
import CmsGuides from "@/pages/cms/guides";
import CmsGlossary from "@/pages/cms/glossary";
import CmsFees from "@/pages/cms/fees";
import CmsExitWindows from "@/pages/cms/exit-windows";
import CmsGlobals from "@/pages/cms/globals";
import CmsAudit from "@/pages/cms/audit";

import MarketingHome from "@/pages/marketing/home";
import AboutPage from "@/pages/marketing/about";
import HowItWorksPage from "@/pages/marketing/how-it-works";
import PropertiesPage from "@/pages/marketing/properties";
import TokenizationPage from "@/pages/marketing/tokenization";
import InvestPage from "@/pages/marketing/invest";
import PricingPage from "@/pages/marketing/pricing";
import InstitutionsPage from "@/pages/marketing/institutions";
import PakistanPage from "@/pages/marketing/pakistan";
import CompliancePage from "@/pages/marketing/compliance";
import FaqPage from "@/pages/marketing/faq";
import BlogPage from "@/pages/marketing/blog";
import ContactPage from "@/pages/marketing/contact";
import CareersPage from "@/pages/marketing/careers";
import PartnersPage from "@/pages/marketing/partners";
import PressPage from "@/pages/marketing/press";
import PrivacyPage from "@/pages/marketing/privacy";
import TermsPage from "@/pages/marketing/terms";
import RiskDisclosurePage from "@/pages/marketing/risk-disclosure";
import DevelopersPage from "@/pages/marketing/developers";
import PropertyDetailPage from "@/pages/marketing/property-detail";
import FeesPage from "@/pages/marketing/fees";
import ROICalculatorPage from "@/pages/marketing/roi-calculator";
import ExitWindowsPage from "@/pages/marketing/exit-windows";
import PropertyMatchPage from "@/pages/marketing/property-match";
import MarketPulsePage from "@/pages/marketing/market-pulse";
import OwnershipPage from "@/pages/marketing/ownership";
import MortgageCalculatorPage from "@/pages/marketing/mortgage-calculator";
import BlogPostPage from "@/pages/marketing/blog-post";
import GuidesPage from "@/pages/marketing/guides";
import GlossaryPage from "@/pages/marketing/glossary";
import SecurityPage from "@/pages/marketing/security";
import RiskWarningsPage from "@/pages/marketing/risk-warnings";
import LegalHubPage from "@/pages/marketing/legal-hub";
import CookiesPage from "@/pages/marketing/cookies";
import MediaPage from "@/pages/marketing/media";
import ForAgenciesPage from "@/pages/marketing/for-agencies";
import ForSellersPage from "@/pages/marketing/for-sellers";
import ForDevelopersPage from "@/pages/marketing/for-developers";
import MobileAppPage from "@/pages/marketing/mobile-app";
import AskPage from "@/pages/marketing/ask";

import ClientAppointments from "@/pages/app/appointments";
import AgentAppointments from "@/pages/app/agent/appointments";
import ManagerAppointments from "@/pages/app/manager/appointments";
import AdminEmailOutbox from "@/pages/app/admin/email-outbox";
import AdminTestConsole from "@/pages/app/admin/test-console";
import ManagerMarketing from "@/pages/app/manager/marketing";
import WalletConfirm from "@/pages/app/wallet/confirm";

import InvestorDashboard from "@/pages/investor/dashboard";
import InvestorPortfolio from "@/pages/investor/portfolio";
import InvestorWallet from "@/pages/investor/wallet";
import InvestorMarketplace from "@/pages/investor/marketplace";
import InvestorKyc from "@/pages/investor/kyc";
import InvestorDistributions from "@/pages/investor/distributions";
import InvestorBankAccounts from "@/pages/investor/bank-accounts";

import AdminDashboard from "@/pages/admin/dashboard";
import AdminUsers from "@/pages/admin/users";
import AdminAssets from "@/pages/admin/assets";
import AdminCompliance from "@/pages/admin/compliance";
import AdminFinance from "@/pages/admin/finance";
import AdminRounds from "@/pages/admin/rounds";
import AdminDbHealth from "@/pages/admin/db-health";
import AdminAml from "@/pages/admin/aml";
import AdminFees from "@/pages/admin/fees";
import AdminRevenue from "@/pages/admin/revenue";
import AdminPayments from "@/pages/admin/payments";
import AdminFxRates from "@/pages/admin/fx-rates";
import AdminReceivingBanks from "@/pages/admin/receiving-banks";
import AdminExitWindows from "@/pages/admin/exit-windows";
import AdminMarketplaceSettings from "@/pages/admin/marketplace-settings";
import AdminDistributions from "@/pages/admin/distributions";
import AdminFxTransactions from "@/pages/admin/fx-transactions";
import AdminFxConfig from "@/pages/admin/fx-config";
import AdminFxApprovals from "@/pages/admin/fx-approvals";
import AdminReconciliation from "@/pages/admin/reconciliation";
import AdminCryptoWallets from "@/pages/admin/crypto-wallets";
import AdminCryptoDeposits from "@/pages/admin/crypto-deposits";
import AdminSupportTickets from "@/pages/admin/support-tickets";
import AdminRolePermissions from "@/pages/admin/role-permissions";
import AdminSystemStatus from "@/pages/admin/system-status";
import AdminAuditLogs from "@/pages/admin/audit-logs";
import AdminTokenConsole from "@/pages/admin/token-console";
import AdminCapTable from "@/pages/admin/cap-table";
import AdminDocumentReview from "@/pages/admin/document-review";
import AdminVehicles from "@/pages/admin/vehicles";
import AdminOfferings from "@/pages/admin/offerings";
import AdminValuations from "@/pages/admin/valuations";
import AdminSettlement from "@/pages/admin/settlement";
import AdminDataRoom from "@/pages/admin/data-room";
import AdminAdt from "@/pages/admin/adt";
import AdminMarketPulse from "@/pages/admin/market-pulse";
import AdminProperties from "@/pages/admin/properties";
import AdminPropertyAcquisition from "@/pages/admin/property-acquisition";
import AdminRentalOperations from "@/pages/admin/rental-operations";
import AdminWaterfallDistribution from "@/pages/admin/waterfall-distribution";
import AdminPropertySales from "@/pages/admin/property-sales";
import AdminTenants from "@/pages/admin/tenants";
import AdminProjects from "@/pages/admin/projects";
import AdminSuperConsole from "@/pages/admin/super-console";
import InvestorAddFunds from "@/pages/investor/add-funds";
import InvestorTrading from "@/pages/investor/trading";
import InvestorAdt from "@/pages/investor/adt";
import InvestorAssetDetail from "@/pages/investor/asset-detail";
import InvestorCryptoWallets from "@/pages/investor/crypto-wallets";
import InvestorCryptoDeposits from "@/pages/investor/crypto-deposits";
import InvestorSupportTickets from "@/pages/investor/support-tickets";
import InvestorTaxReports from "@/pages/investor/tax-reports";
import InvestorCertificates from "@/pages/investor/certificates";
import InvestorMyTokens from "@/pages/investor/my-tokens";
import InvestorOwnership from "@/pages/investor/ownership";
import InvestorOfferings from "@/pages/investor/offerings";
import InvestorReturns from "@/pages/investor/returns";
import InvestorSettlements from "@/pages/investor/settlements";
import InvestorDataRoom from "@/pages/investor/data-room";
import InvestorFeeDisclosure from "@/pages/investor/fee-disclosure";

import IssuerDashboard from "@/pages/issuer/dashboard";
import IssuerAssets from "@/pages/issuer/assets";
import IssuerRounds from "@/pages/issuer/rounds";
import IssuerDocs from "@/pages/issuer/docs";
import IssuerDistributions from "@/pages/issuer/distributions";

import AgentDashboard from "@/pages/agent/dashboard";
import AgentOffers from "@/pages/agent/offers";
import AgentClients from "@/pages/agent/clients";
import AgentMarketplace from "@/pages/agent/marketplace";
import AgentMicrosite from "@/pages/agent/microsite";

import AgencyUsers from "@/pages/agency/users";
import AgencyDashboard from "@/pages/agency/dashboard";

import Marketplace from "@/pages/marketplace";
import Settings from "@/pages/settings";
import { LegalIndex, LegalDocPage } from "@/pages/legal";
import { PwaInstallBanner } from "@/components/pwa-install-banner";

function SettingsWithLayout() {
  const { user } = useAuth();
  const role = (user?.role || "investor") as Role;
  return (
    <RoleLayout role={role}>
      <Settings />
    </RoleLayout>
  );
}

function MarketingPages() {
  return (
    <Switch>
      <Route path="/" component={MarketingHome} />
      <Route path="/about" component={AboutPage} />
      <Route path="/how-it-works" component={HowItWorksPage} />
      <Route path="/properties" component={PropertiesPage} />
      <Route path="/properties/:slug" component={PropertyDetailPage} />
      <Route path="/tokenization" component={TokenizationPage} />
      <Route path="/invest" component={InvestPage} />
      <Route path="/pricing" component={PricingPage} />
      <Route path="/fees" component={FeesPage} />
      <Route path="/roi-calculator" component={ROICalculatorPage} />
      <Route path="/mortgage-calculator" component={MortgageCalculatorPage} />
      <Route path="/exit-windows" component={ExitWindowsPage} />
      <Route path="/match" component={PropertyMatchPage} />
      <Route path="/market-pulse" component={MarketPulsePage} />
      <Route path="/ownership" component={OwnershipPage} />
      <Route path="/institutions" component={InstitutionsPage} />
      <Route path="/market" component={PakistanPage} />
      <Route path="/compliance" component={CompliancePage} />
      <Route path="/faq" component={FaqPage} />
      <Route path="/glossary" component={GlossaryPage} />
      <Route path="/guides" component={GuidesPage} />
      <Route path="/blog" component={BlogPage} />
      <Route path="/blog/:slug" component={BlogPostPage} />
      <Route path="/contact" component={ContactPage} />
      <Route path="/careers" component={CareersPage} />
      <Route path="/partners" component={PartnersPage} />
      <Route path="/press" component={PressPage} />
      <Route path="/privacy" component={PrivacyPage} />
      <Route path="/terms" component={TermsPage} />
      <Route path="/risk-disclosure" component={RiskDisclosurePage} />
      <Route path="/developers" component={DevelopersPage} />
      <Route path="/security" component={SecurityPage} />
      <Route path="/risk-warnings" component={RiskWarningsPage} />
      <Route path="/legal" component={LegalHubPage} />
      <Route path="/legal/cookies" component={CookiesPage} />
      <Route path="/media" component={MediaPage} />
      <Route path="/for-agencies" component={ForAgenciesPage} />
      <Route path="/for-sellers" component={ForSellersPage} />
      <Route path="/for-developers" component={ForDevelopersPage} />
      <Route path="/mobile-app" component={MobileAppPage} />
      <Route path="/ask" component={AskPage} />
      <Route path="/download">{() => { window.location.href = "/api/download/vestblock-project.zip"; return null; }}</Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function MarketingRegion({ region }: { region: RegionCode }) {
  return (
    <RegionProvider region={region}>
      <MarketingPages />
    </RegionProvider>
  );
}

function RootRedirect() {
  const stored = getStoredRegion();
  return <Redirect to={`/${stored}`} />;
}

function BarePathRedirect({ path }: { path: string }) {
  const stored = getStoredRegion();
  return <Redirect to={`/${stored}${path}`} />;
}

function AppRouter() {
  return (
    <Switch>
      <Route path="/" component={RootRedirect} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/auth/sign-in" component={SignIn} />

      <Route path="/pk" nest>
        <MarketingRegion region="pk" />
      </Route>
      <Route path="/ae" nest>
        <MarketingRegion region="ae" />
      </Route>

      <Route path="/about">{() => <BarePathRedirect path="/about" />}</Route>
      <Route path="/how-it-works">{() => <BarePathRedirect path="/how-it-works" />}</Route>
      <Route path="/properties">{() => <BarePathRedirect path="/properties" />}</Route>
      <Route path="/properties/:slug">{(params: { slug: string }) => <BarePathRedirect path={`/properties/${params.slug}`} />}</Route>
      <Route path="/tokenization">{() => <BarePathRedirect path="/tokenization" />}</Route>
      <Route path="/invest">{() => <BarePathRedirect path="/invest" />}</Route>
      <Route path="/pricing">{() => <BarePathRedirect path="/pricing" />}</Route>
      <Route path="/fees">{() => <BarePathRedirect path="/fees" />}</Route>
      <Route path="/roi-calculator">{() => <BarePathRedirect path="/roi-calculator" />}</Route>
      <Route path="/mortgage-calculator">{() => <BarePathRedirect path="/mortgage-calculator" />}</Route>
      <Route path="/exit-windows">{() => <BarePathRedirect path="/exit-windows" />}</Route>
      <Route path="/market-pulse">{() => <BarePathRedirect path="/market-pulse" />}</Route>
      <Route path="/ownership">{() => <BarePathRedirect path="/ownership" />}</Route>
      <Route path="/institutions">{() => <BarePathRedirect path="/institutions" />}</Route>
      <Route path="/pakistan">{() => <BarePathRedirect path="/market" />}</Route>
      <Route path="/compliance">{() => <BarePathRedirect path="/compliance" />}</Route>
      <Route path="/faq">{() => <BarePathRedirect path="/faq" />}</Route>
      <Route path="/glossary">{() => <BarePathRedirect path="/glossary" />}</Route>
      <Route path="/guides">{() => <BarePathRedirect path="/guides" />}</Route>
      <Route path="/blog">{() => <BarePathRedirect path="/blog" />}</Route>
      <Route path="/blog/:slug">{(params: { slug: string }) => <BarePathRedirect path={`/blog/${params.slug}`} />}</Route>
      <Route path="/contact">{() => <BarePathRedirect path="/contact" />}</Route>
      <Route path="/careers">{() => <BarePathRedirect path="/careers" />}</Route>
      <Route path="/partners">{() => <BarePathRedirect path="/partners" />}</Route>
      <Route path="/press">{() => <BarePathRedirect path="/press" />}</Route>
      <Route path="/privacy">{() => <BarePathRedirect path="/privacy" />}</Route>
      <Route path="/terms">{() => <BarePathRedirect path="/terms" />}</Route>
      <Route path="/risk-disclosure">{() => <BarePathRedirect path="/risk-disclosure" />}</Route>
      <Route path="/developers">{() => <BarePathRedirect path="/developers" />}</Route>
      <Route path="/security">{() => <BarePathRedirect path="/security" />}</Route>
      <Route path="/risk-warnings">{() => <BarePathRedirect path="/risk-warnings" />}</Route>
      <Route path="/legal">{() => <BarePathRedirect path="/legal" />}</Route>
      <Route path="/legal/cookies">{() => <BarePathRedirect path="/legal/cookies" />}</Route>
      <Route path="/media">{() => <BarePathRedirect path="/media" />}</Route>
      <Route path="/for-agencies">{() => <BarePathRedirect path="/for-agencies" />}</Route>
      <Route path="/for-sellers">{() => <BarePathRedirect path="/for-sellers" />}</Route>
      <Route path="/for-developers">{() => <BarePathRedirect path="/for-developers" />}</Route>
      <Route path="/mobile-app">{() => <BarePathRedirect path="/mobile-app" />}</Route>
      <Route path="/ask">{() => <BarePathRedirect path="/ask" />}</Route>

      <Route path="/app/appointments">
        <ProtectedRoute><ClientAppointments /></ProtectedRoute>
      </Route>
      <Route path="/app/agent/appointments">
        <ProtectedRoute role="agent"><AgentAppointments /></ProtectedRoute>
      </Route>
      <Route path="/app/manager/appointments">
        <ProtectedRoute role="admin"><ManagerAppointments /></ProtectedRoute>
      </Route>
      <Route path="/app/admin/email-outbox">
        <ProtectedRoute role="admin"><AdminEmailOutbox /></ProtectedRoute>
      </Route>
      <Route path="/app/admin/test-console">
        <ProtectedRoute role="admin"><AdminTestConsole /></ProtectedRoute>
      </Route>
      <Route path="/app/manager/marketing">
        <ProtectedRoute role="admin"><ManagerMarketing /></ProtectedRoute>
      </Route>
      <Route path="/app/wallet/confirm">
        <ProtectedRoute><WalletConfirm /></ProtectedRoute>
      </Route>

      <Route path="/investor">
        <ProtectedRoute role="investor"><InvestorDashboard /></ProtectedRoute>
      </Route>
      <Route path="/investor/dashboard">
        <ProtectedRoute role="investor"><InvestorDashboard /></ProtectedRoute>
      </Route>
      <Route path="/investor/portfolio">
        <ProtectedRoute role="investor"><InvestorPortfolio /></ProtectedRoute>
      </Route>
      <Route path="/investor/returns">
        <ProtectedRoute role="investor"><InvestorReturns /></ProtectedRoute>
      </Route>
      <Route path="/investor/settlements">
        <ProtectedRoute role="investor"><InvestorSettlements /></ProtectedRoute>
      </Route>
      <Route path="/investor/data-room">
        <ProtectedRoute role="investor"><InvestorDataRoom /></ProtectedRoute>
      </Route>
      <Route path="/investor/wallet">
        <ProtectedRoute role="investor"><InvestorWallet /></ProtectedRoute>
      </Route>
      <Route path="/investor/marketplace/:id">
        <ProtectedRoute role="investor"><InvestorAssetDetail /></ProtectedRoute>
      </Route>
      <Route path="/investor/marketplace">
        <ProtectedRoute role="investor"><InvestorMarketplace /></ProtectedRoute>
      </Route>
      <Route path="/investor/kyc">
        <ProtectedRoute role="investor"><InvestorKyc /></ProtectedRoute>
      </Route>
      <Route path="/investor/distributions">
        <ProtectedRoute role="investor"><InvestorDistributions /></ProtectedRoute>
      </Route>
      <Route path="/investor/bank-accounts">
        <ProtectedRoute role="investor"><InvestorBankAccounts /></ProtectedRoute>
      </Route>
      <Route path="/investor/add-funds">
        <ProtectedRoute role="investor"><InvestorAddFunds /></ProtectedRoute>
      </Route>
      <Route path="/investor/trading">
        <ProtectedRoute role="investor"><InvestorTrading /></ProtectedRoute>
      </Route>
      <Route path="/investor/adt">
        <ProtectedRoute role="investor"><InvestorAdt /></ProtectedRoute>
      </Route>
      <Route path="/investor/crypto-wallets">
        <ProtectedRoute role="investor"><InvestorCryptoWallets /></ProtectedRoute>
      </Route>
      <Route path="/investor/crypto-deposits">
        <ProtectedRoute role="investor"><InvestorCryptoDeposits /></ProtectedRoute>
      </Route>
      <Route path="/investor/support">
        <ProtectedRoute role="investor"><InvestorSupportTickets /></ProtectedRoute>
      </Route>
      <Route path="/investor/tax-reports">
        <ProtectedRoute role="investor"><InvestorTaxReports /></ProtectedRoute>
      </Route>
      <Route path="/investor/certificates">
        <ProtectedRoute role="investor"><InvestorCertificates /></ProtectedRoute>
      </Route>
      <Route path="/investor/my-tokens">
        <ProtectedRoute role="investor"><InvestorMyTokens /></ProtectedRoute>
      </Route>
      <Route path="/investor/ownership">
        <ProtectedRoute role="investor"><InvestorOwnership /></ProtectedRoute>
      </Route>
      <Route path="/investor/offerings">
        <ProtectedRoute role="investor"><InvestorOfferings /></ProtectedRoute>
      </Route>
      <Route path="/investor/fee-disclosure">
        <ProtectedRoute role="investor"><InvestorFeeDisclosure /></ProtectedRoute>
      </Route>

      <Route path="/admin">
        <ProtectedRoute role="admin"><AdminDashboard /></ProtectedRoute>
      </Route>
      <Route path="/admin/dashboard">
        <ProtectedRoute role="admin"><AdminDashboard /></ProtectedRoute>
      </Route>
      <Route path="/admin/super-console">
        <ProtectedRoute role="admin"><AdminSuperConsole /></ProtectedRoute>
      </Route>
      <Route path="/admin/users">
        <ProtectedRoute role="admin"><AdminUsers /></ProtectedRoute>
      </Route>
      <Route path="/admin/assets">
        <ProtectedRoute role="admin"><AdminAssets /></ProtectedRoute>
      </Route>
      <Route path="/admin/compliance">
        <ProtectedRoute role="admin"><AdminCompliance /></ProtectedRoute>
      </Route>
      <Route path="/admin/aml">
        <ProtectedRoute role="admin"><AdminAml /></ProtectedRoute>
      </Route>
      <Route path="/admin/finance">
        <ProtectedRoute role="admin"><AdminFinance /></ProtectedRoute>
      </Route>
      <Route path="/admin/rounds">
        <ProtectedRoute role="admin"><AdminRounds /></ProtectedRoute>
      </Route>
      <Route path="/admin/db-health">
        <ProtectedRoute role="admin"><AdminDbHealth /></ProtectedRoute>
      </Route>
      <Route path="/admin/fees">
        <ProtectedRoute role="admin"><AdminFees /></ProtectedRoute>
      </Route>
      <Route path="/admin/revenue">
        <ProtectedRoute role="admin"><AdminRevenue /></ProtectedRoute>
      </Route>
      <Route path="/admin/payments">
        <ProtectedRoute role="admin"><AdminPayments /></ProtectedRoute>
      </Route>
      <Route path="/admin/fx-rates">
        <ProtectedRoute role="admin"><AdminFxRates /></ProtectedRoute>
      </Route>
      <Route path="/admin/receiving-banks">
        <ProtectedRoute role="admin"><AdminReceivingBanks /></ProtectedRoute>
      </Route>
      <Route path="/admin/exit-windows">
        <ProtectedRoute role="admin"><AdminExitWindows /></ProtectedRoute>
      </Route>
      <Route path="/admin/marketplace-settings">
        <ProtectedRoute role="admin"><AdminMarketplaceSettings /></ProtectedRoute>
      </Route>
      <Route path="/admin/distributions">
        <ProtectedRoute role="admin"><AdminDistributions /></ProtectedRoute>
      </Route>
      <Route path="/admin/fx-transactions">
        <ProtectedRoute role="admin"><AdminFxTransactions /></ProtectedRoute>
      </Route>
      <Route path="/admin/fx-config">
        <ProtectedRoute role="admin"><AdminFxConfig /></ProtectedRoute>
      </Route>
      <Route path="/admin/fx-approvals">
        <ProtectedRoute role="admin"><AdminFxApprovals /></ProtectedRoute>
      </Route>
      <Route path="/admin/reconciliation">
        <ProtectedRoute role="admin"><AdminReconciliation /></ProtectedRoute>
      </Route>
      <Route path="/admin/crypto-wallets">
        <ProtectedRoute role="admin"><AdminCryptoWallets /></ProtectedRoute>
      </Route>
      <Route path="/admin/crypto-deposits">
        <ProtectedRoute role="admin"><AdminCryptoDeposits /></ProtectedRoute>
      </Route>
      <Route path="/admin/support-tickets">
        <ProtectedRoute role="admin"><AdminSupportTickets /></ProtectedRoute>
      </Route>
      <Route path="/admin/role-permissions">
        <ProtectedRoute role="admin"><AdminRolePermissions /></ProtectedRoute>
      </Route>
      <Route path="/admin/system-status">
        <ProtectedRoute role="admin"><AdminSystemStatus /></ProtectedRoute>
      </Route>
      <Route path="/admin/token-console">
        <ProtectedRoute role="admin"><AdminTokenConsole /></ProtectedRoute>
      </Route>
      <Route path="/admin/cap-table">
        <ProtectedRoute role="admin"><AdminCapTable /></ProtectedRoute>
      </Route>
      <Route path="/admin/vehicles">
        <ProtectedRoute role="admin"><AdminVehicles /></ProtectedRoute>
      </Route>
      <Route path="/admin/document-review">
        <ProtectedRoute role="admin"><AdminDocumentReview /></ProtectedRoute>
      </Route>
      <Route path="/admin/offerings">
        <ProtectedRoute role="admin"><AdminOfferings /></ProtectedRoute>
      </Route>
      <Route path="/admin/valuations">
        <ProtectedRoute role="admin"><AdminValuations /></ProtectedRoute>
      </Route>
      <Route path="/admin/settlement">
        <ProtectedRoute role="admin"><AdminSettlement /></ProtectedRoute>
      </Route>
      <Route path="/admin/data-room">
        <ProtectedRoute role="admin"><AdminDataRoom /></ProtectedRoute>
      </Route>
      <Route path="/admin/adt">
        <ProtectedRoute role="admin"><AdminAdt /></ProtectedRoute>
      </Route>
      <Route path="/admin/market-pulse">
        <ProtectedRoute role="admin"><AdminMarketPulse /></ProtectedRoute>
      </Route>
      <Route path="/admin/properties">
        <ProtectedRoute role="admin"><AdminProperties /></ProtectedRoute>
      </Route>
      <Route path="/admin/property-acquisition">
        <ProtectedRoute role="admin"><AdminPropertyAcquisition /></ProtectedRoute>
      </Route>
      <Route path="/admin/rental-operations">
        <ProtectedRoute role="admin"><AdminRentalOperations /></ProtectedRoute>
      </Route>
      <Route path="/admin/waterfall-distribution">
        <ProtectedRoute role="admin"><AdminWaterfallDistribution /></ProtectedRoute>
      </Route>
      <Route path="/admin/property-sales">
        <ProtectedRoute role="admin"><AdminPropertySales /></ProtectedRoute>
      </Route>
      <Route path="/admin/tenants">
        <ProtectedRoute role="admin"><AdminTenants /></ProtectedRoute>
      </Route>
      <Route path="/admin/projects">
        <ProtectedRoute role="admin"><AdminProjects /></ProtectedRoute>
      </Route>
      <Route path="/agency">
        <ProtectedRoute role="admin"><AgencyDashboard /></ProtectedRoute>
      </Route>
      <Route path="/agency/dashboard">
        <ProtectedRoute role="admin"><AgencyDashboard /></ProtectedRoute>
      </Route>
      <Route path="/agency/users">
        <ProtectedRoute role="admin"><AgencyUsers /></ProtectedRoute>
      </Route>
      <Route path="/admin/agency-users">
        <ProtectedRoute role="admin"><AgencyUsers /></ProtectedRoute>
      </Route>
      <Route path="/admin/audit-logs">
        <ProtectedRoute role="admin"><AdminAuditLogs /></ProtectedRoute>
      </Route>

      <Route path="/issuer">
        <ProtectedRoute role="issuer"><IssuerDashboard /></ProtectedRoute>
      </Route>
      <Route path="/issuer/dashboard">
        <ProtectedRoute role="issuer"><IssuerDashboard /></ProtectedRoute>
      </Route>
      <Route path="/issuer/assets">
        <ProtectedRoute role="issuer"><IssuerAssets /></ProtectedRoute>
      </Route>
      <Route path="/issuer/rounds">
        <ProtectedRoute role="issuer"><IssuerRounds /></ProtectedRoute>
      </Route>
      <Route path="/issuer/docs">
        <ProtectedRoute role="issuer"><IssuerDocs /></ProtectedRoute>
      </Route>
      <Route path="/issuer/distributions">
        <ProtectedRoute role="issuer"><IssuerDistributions /></ProtectedRoute>
      </Route>

      <Route path="/agent">
        <ProtectedRoute role="agent"><AgentDashboard /></ProtectedRoute>
      </Route>
      <Route path="/agent/dashboard">
        <ProtectedRoute role="agent"><AgentDashboard /></ProtectedRoute>
      </Route>
      <Route path="/agent/offers">
        <ProtectedRoute role="agent"><AgentOffers /></ProtectedRoute>
      </Route>
      <Route path="/agent/clients">
        <ProtectedRoute role="agent"><AgentClients /></ProtectedRoute>
      </Route>
      <Route path="/agent/marketplace">
        <ProtectedRoute role="agent"><AgentMarketplace /></ProtectedRoute>
      </Route>
      <Route path="/agent/microsites">
        <ProtectedRoute role="agent"><AgentMicrosite /></ProtectedRoute>
      </Route>

      <Route path="/cms">
        <ProtectedRoute role="cms"><CmsDashboard /></ProtectedRoute>
      </Route>
      <Route path="/cms/dashboard">
        <ProtectedRoute role="cms"><CmsDashboard /></ProtectedRoute>
      </Route>
      <Route path="/cms/pages">
        <ProtectedRoute role="cms"><CmsPages /></ProtectedRoute>
      </Route>
      <Route path="/cms/properties">
        <ProtectedRoute role="cms"><CmsProperties /></ProtectedRoute>
      </Route>
      <Route path="/cms/blog">
        <ProtectedRoute role="cms"><CmsBlog /></ProtectedRoute>
      </Route>
      <Route path="/cms/faq">
        <ProtectedRoute role="cms"><CmsFaq /></ProtectedRoute>
      </Route>
      <Route path="/cms/guides">
        <ProtectedRoute role="cms"><CmsGuides /></ProtectedRoute>
      </Route>
      <Route path="/cms/glossary">
        <ProtectedRoute role="cms"><CmsGlossary /></ProtectedRoute>
      </Route>
      <Route path="/cms/fees">
        <ProtectedRoute role="cms"><CmsFees /></ProtectedRoute>
      </Route>
      <Route path="/cms/exit-windows">
        <ProtectedRoute role="cms"><CmsExitWindows /></ProtectedRoute>
      </Route>
      <Route path="/cms/globals">
        <ProtectedRoute role="cms"><CmsGlobals /></ProtectedRoute>
      </Route>
      <Route path="/cms/audit">
        <ProtectedRoute role="cms"><CmsAudit /></ProtectedRoute>
      </Route>

      <Route path="/settings">
        <ProtectedRoute><SettingsWithLayout /></ProtectedRoute>
      </Route>

      <Route path="/marketplace/:id" component={Marketplace} />
      <Route path="/marketplace" component={Marketplace} />
      <Route path="/legal" component={LegalIndex} />
      <Route path="/legal/:type" component={LegalDocPage} />

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <ThemeProvider>
          <TooltipProvider>
            <Router>
              <AuthProvider>
                <Toaster />
                <AppRouter />
                <PwaInstallBanner />
              </AuthProvider>
            </Router>
          </TooltipProvider>
        </ThemeProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default App;
