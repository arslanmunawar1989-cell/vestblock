import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { registerServiceWorker } from "@/lib/sw-register";
import { SwUpdateToast } from "@/components/sw-update-toast";

registerServiceWorker();

createRoot(document.getElementById("root")!).render(
  <>
    <App />
    <SwUpdateToast />
  </>
);
