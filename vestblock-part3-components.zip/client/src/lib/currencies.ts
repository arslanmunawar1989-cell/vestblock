import type { CurrencyCode as _CurrencyCode } from "@shared/constants";
export {
  SUPPORTED_CURRENCIES,
  type CurrencyCode,
  currencyCodeSchema,
  WALLET_CURRENCIES,
  type WalletCurrency,
  walletCurrencySchema,
  CURRENCY_DETAILS,
  CURRENCY_TO_COUNTRY,
} from "@shared/constants";

export const DEFAULT_CURRENCY: _CurrencyCode = "AED";
