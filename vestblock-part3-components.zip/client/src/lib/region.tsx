import { createContext, useContext, useCallback } from "react";

export type RegionCode = "pk" | "ae";

export interface RegionData {
  code: RegionCode;
  name: string;
  flag: string;
  currency: string;
  currencySymbol: string;
  cities: string[];
  tagline: string;
  launchStatus: "live" | "coming_soon";
}

const REGIONS: Record<RegionCode, RegionData> = {
  pk: {
    code: "pk",
    name: "Pakistan",
    flag: "PK",
    currency: "PKR",
    currencySymbol: "PKR",
    cities: ["Karachi", "Lahore", "Islamabad", "Faisalabad", "Multan", "Peshawar"],
    tagline: "Pakistan's premier real estate tokenization platform",
    launchStatus: "live",
  },
  ae: {
    code: "ae",
    name: "UAE",
    flag: "AE",
    currency: "AED",
    currencySymbol: "AED",
    cities: ["Dubai", "Abu Dhabi", "Sharjah", "Ajman", "Ras Al Khaimah", "Fujairah"],
    tagline: "Launching soon in the UAE",
    launchStatus: "coming_soon",
  },
};

interface RegionContextValue {
  region: RegionData;
  regionCode: RegionCode;
  otherRegion: RegionData;
  switchRegion: () => void;
  regionPath: (path: string) => string;
}

const RegionContext = createContext<RegionContextValue | null>(null);

function persistRegion(code: RegionCode) {
  try {
    localStorage.setItem("vb_region", code);
    document.cookie = `vb_region=${code};path=/;max-age=${60 * 60 * 24 * 365};SameSite=Lax`;
  } catch {}
}

export function getStoredRegion(): RegionCode {
  try {
    const stored = localStorage.getItem("vb_region");
    if (stored === "pk" || stored === "ae") return stored;
  } catch {}
  try {
    const match = document.cookie.match(/vb_region=(pk|ae)/);
    if (match) return match[1] as RegionCode;
  } catch {}
  return "pk";
}

interface RegionProviderProps {
  region: RegionCode;
  children: React.ReactNode;
}

export function RegionProvider({ region, children }: RegionProviderProps) {
  const regionData = REGIONS[region];
  const otherCode: RegionCode = region === "pk" ? "ae" : "pk";
  const otherRegion = REGIONS[otherCode];

  const switchRegion = useCallback(() => {
    persistRegion(otherCode);
    const currentPath = window.location.pathname;
    const pathWithoutRegion = currentPath.replace(/^\/(pk|ae)/, "") || "";
    const newPath = `/${otherCode}${pathWithoutRegion}`;
    window.history.pushState(null, "", newPath);
    window.dispatchEvent(new PopStateEvent("popstate"));
  }, [otherCode]);

  const regionPath = useCallback(
    (path: string) => `/${region}${path}`,
    [region]
  );

  return (
    <RegionContext.Provider value={{ region: regionData, regionCode: region, otherRegion, switchRegion, regionPath }}>
      {children}
    </RegionContext.Provider>
  );
}

export function useRegion(): RegionContextValue {
  const ctx = useContext(RegionContext);
  if (!ctx) {
    return {
      region: REGIONS.pk,
      regionCode: "pk",
      otherRegion: REGIONS.ae,
      switchRegion: () => {},
      regionPath: (path: string) => `/pk${path}`,
    };
  }
  return ctx;
}

export { REGIONS };
