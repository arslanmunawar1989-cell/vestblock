import { CURRENCY_DETAILS, type CurrencyCode, type CountryCode } from "@shared/constants";

const CURRENCY_LOCALE: Record<string, string> = {
  PKR: "ur-PK",
  AED: "ar-AE",
  GBP: "en-GB",
  USD: "en-US",
  QAR: "ar-QA",
};

export const COUNTRY_LOCALE: Record<CountryCode, string> = {
  PK: "en-PK",
  AE: "en-AE",
  GB: "en-GB",
  US: "en-US",
  QA: "en-QA",
};

function getLocale(currency?: string): string {
  if (currency && currency in CURRENCY_LOCALE) {
    return CURRENCY_LOCALE[currency];
  }
  return navigator.language || "en-US";
}

export function formatCurrency(
  amount: string | number,
  currency: string,
  options?: { compact?: boolean; showSign?: boolean }
): string {
  const num = typeof amount === "string" ? parseFloat(amount) : amount;
  if (isNaN(num)) return `${currency} 0.00`;

  const details = CURRENCY_DETAILS[currency as CurrencyCode];
  const symbol = details?.symbol || currency;
  const locale = getLocale(currency);

  try {
    const formatted = new Intl.NumberFormat(locale, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
      notation: options?.compact ? "compact" : "standard",
    }).format(Math.abs(num));

    const sign = options?.showSign ? (num >= 0 ? "+" : "-") : (num < 0 ? "-" : "");
    return `${sign}${symbol} ${formatted}`;
  } catch {
    const fallback = Math.abs(num).toLocaleString("en-US", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    return `${symbol} ${fallback}`;
  }
}

export function formatDate(
  date: string | Date,
  style: "short" | "medium" | "long" | "relative" = "medium"
): string {
  const d = typeof date === "string" ? new Date(date) : date;
  if (isNaN(d.getTime())) return "—";

  const locale = navigator.language || "en-US";

  if (style === "relative") {
    const now = new Date();
    const diffMs = now.getTime() - d.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffDays === 0) return "Today";
    if (diffDays === 1) return "Yesterday";
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
  }

  const options: Intl.DateTimeFormatOptions =
    style === "short"
      ? { month: "short", day: "numeric" }
      : style === "long"
        ? { year: "numeric", month: "long", day: "numeric", hour: "2-digit", minute: "2-digit" }
        : { year: "numeric", month: "short", day: "numeric" };

  try {
    return new Intl.DateTimeFormat(locale, options).format(d);
  } catch {
    return d.toLocaleDateString("en-US", options);
  }
}

export function formatNumber(
  value: number,
  options?: { decimals?: number; compact?: boolean }
): string {
  const locale = navigator.language || "en-US";
  const decimals = options?.decimals ?? 0;

  try {
    return new Intl.NumberFormat(locale, {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
      notation: options?.compact ? "compact" : "standard",
    }).format(value);
  } catch {
    return value.toFixed(decimals);
  }
}

export function formatRate(value: number | string, decimals: number = 4): string {
  const num = typeof value === "string" ? parseFloat(value) : value;
  if (isNaN(num)) return "—";
  return num.toFixed(decimals);
}

export function formatPercent(value: number | string, decimals: number = 2): string {
  const num = typeof value === "string" ? parseFloat(value) : value;
  if (isNaN(num)) return "—";
  const locale = navigator.language || "en-US";
  try {
    return new Intl.NumberFormat(locale, {
      style: "percent",
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }).format(num);
  } catch {
    return `${(num * 100).toFixed(decimals)}%`;
  }
}

export function formatDateForCountry(
  date: string | Date,
  country: CountryCode,
  style: "short" | "medium" | "long" = "medium"
): string {
  const d = typeof date === "string" ? new Date(date) : date;
  if (isNaN(d.getTime())) return "—";

  const locale = COUNTRY_LOCALE[country] || "en-US";
  const options: Intl.DateTimeFormatOptions =
    style === "short"
      ? { month: "short", day: "numeric" }
      : style === "long"
        ? { year: "numeric", month: "long", day: "numeric", hour: "2-digit", minute: "2-digit" }
        : { year: "numeric", month: "short", day: "numeric" };

  try {
    return new Intl.DateTimeFormat(locale, options).format(d);
  } catch {
    return d.toLocaleDateString("en-US", options);
  }
}

export function formatCurrencyForCountry(
  amount: string | number,
  currency: string,
  country: CountryCode,
  options?: { compact?: boolean }
): string {
  const num = typeof amount === "string" ? parseFloat(amount) : amount;
  if (isNaN(num)) return `${currency} 0.00`;

  const details = CURRENCY_DETAILS[currency as CurrencyCode];
  const symbol = details?.symbol || currency;
  const locale = COUNTRY_LOCALE[country] || "en-US";

  try {
    const formatted = new Intl.NumberFormat(locale, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
      notation: options?.compact ? "compact" : "standard",
    }).format(Math.abs(num));

    return `${symbol} ${formatted}`;
  } catch {
    return `${symbol} ${Math.abs(num).toFixed(2)}`;
  }
}

export function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    active: "bg-emerald-500/10 text-emerald-500",
    ACTIVE: "bg-emerald-500/10 text-emerald-500",
    completed: "bg-blue-500/10 text-blue-500",
    pending: "bg-amber-500/10 text-amber-500",
    DRAFT: "bg-slate-500/10 text-slate-500",
    FUNDED: "bg-emerald-500/10 text-emerald-500",
    CLOSED: "bg-red-500/10 text-red-500",
    open: "bg-amber-500/10 text-amber-500",
    resolved: "bg-emerald-500/10 text-emerald-500",
    failed: "bg-red-500/10 text-red-500",
    sold: "bg-blue-500/10 text-blue-500",
  };
  return colors[status] || "bg-muted text-muted-foreground";
}
