import { createContext, useContext } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "./queryClient";
import { useLocation } from "wouter";
import type { PlatformRole, TenantRole, RbacAction, RbacContext } from "@shared/constants";
import { can as canCheck } from "@shared/constants";

interface AuthUser {
  id: string;
  username: string;
  email: string;
  fullName: string;
  role: string;
  platformRole: PlatformRole | null;
  avatarUrl: string | null;
  kycStatus: string;
  isActive: boolean;
  phone: string | null;
  nationality: string | null;
  address: string | null;
  timezone: string | null;
  notificationPreferences: {
    email: boolean;
    sms: boolean;
    push: boolean;
    marketing: boolean;
    security: boolean;
    transactions: boolean;
    distributions: boolean;
  } | null;
}

interface AuthContextType {
  user: AuthUser | null;
  isLoading: boolean;
  primaryCountry: string | null;
  defaultCurrency: string | null;
  countryName: string | null;
  tenantRole: TenantRole | null;
  impersonating: { impersonatorId: string; impersonatorUsername: string } | null;
  login: (username: string, password: string) => Promise<void>;
  register: (data: RegisterData) => Promise<void>;
  logout: () => Promise<void>;
  can: (action: RbacAction) => boolean;
  isSuperAdmin: () => boolean;
  isPlatformUser: () => boolean;
}

interface RegisterData {
  username: string;
  password: string;
  email: string;
  fullName: string;
  role: string;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [, setLocation] = useLocation();

  const { data: authData, isLoading } = useQuery<{
    user: AuthUser;
    primaryCountry: string;
    defaultCurrency: string;
    countryName: string;
    tenantRole: TenantRole | null;
    impersonating: { impersonatorId: string; impersonatorUsername: string } | null;
  } | null>({
    queryKey: ["/api/auth/me"],
    queryFn: async () => {
      const res = await fetch("/api/auth/me", { credentials: "include" });
      if (res.status === 401) return null;
      if (!res.ok) return null;
      return res.json();
    },
    staleTime: 1000 * 60 * 5,
    retry: false,
  });

  const user = authData?.user ?? null;
  const tenantRole = authData?.tenantRole ?? null;
  const impersonating = authData?.impersonating ?? null;

  const loginMutation = useMutation({
    mutationFn: async ({
      username,
      password,
    }: {
      username: string;
      password: string;
    }) => {
      const res = await apiRequest("POST", "/api/auth/login", {
        username,
        password,
      });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(["/api/auth/me"], data);
      const role = data.user.role;
      const platformRole = data.user.platformRole;
      if (platformRole === "SUPER_ADMIN" || platformRole === "PLATFORM_ADMIN") {
        setLocation("/admin");
      } else {
        setLocation(`/${role === "admin" ? "admin" : role}`);
      }
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (data: RegisterData) => {
      const res = await apiRequest("POST", "/api/auth/register", data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(["/api/auth/me"], data);
      const role = data.user.role;
      setLocation(`/${role}`);
    },
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/auth/logout");
    },
    onSuccess: () => {
      queryClient.setQueryData(["/api/auth/me"], null);
      setLocation("/");
    },
  });

  const canFn = (action: RbacAction): boolean => {
    if (!user) return false;
    const context: RbacContext = {
      platformRole: user.platformRole,
      tenantRole,
    };
    return canCheck(action, context);
  };

  const isSuperAdmin = (): boolean => {
    return user?.platformRole === "SUPER_ADMIN";
  };

  const isPlatformUser = (): boolean => {
    return !!user?.platformRole;
  };

  return (
    <AuthContext.Provider
      value={{
        user: user ?? null,
        isLoading,
        primaryCountry: authData?.primaryCountry ?? null,
        defaultCurrency: authData?.defaultCurrency ?? null,
        countryName: authData?.countryName ?? null,
        tenantRole,
        impersonating,
        login: async (username, password) => {
          await loginMutation.mutateAsync({ username, password });
        },
        register: async (data) => {
          await registerMutation.mutateAsync(data);
        },
        logout: async () => {
          await logoutMutation.mutateAsync();
        },
        can: canFn,
        isSuperAdmin,
        isPlatformUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
