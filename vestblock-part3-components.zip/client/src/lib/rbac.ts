import type { Role } from "@shared/schema";
import type { PlatformRole, TenantRole } from "@shared/constants";

export const ROLES = {
  investor: "investor",
  admin: "admin",
  issuer: "issuer",
  agent: "agent",
  cms: "cms",
} as const;

export interface NavItem {
  label: string;
  path: string;
  icon: string;
  platformRolesRequired?: PlatformRole[];
  tenantRolesRequired?: TenantRole[];
}

export const platformNavItems: NavItem[] = [
  { label: "Dashboard", path: "/admin", icon: "LayoutDashboard" },
  { label: "Super Admin", path: "/admin/super-console", icon: "ShieldCheck", platformRolesRequired: ["SUPER_ADMIN"] },
  { label: "Agency Dashboard", path: "/agency", icon: "BarChart3" },
  { label: "Agency Management", path: "/admin/tenants", icon: "Building2", platformRolesRequired: ["SUPER_ADMIN", "PLATFORM_ADMIN"] },
  { label: "Users", path: "/admin/users", icon: "Users" },
  { label: "Assets", path: "/admin/assets", icon: "Blocks" },
  { label: "Compliance", path: "/admin/compliance", icon: "Shield" },
  { label: "AML / EDD", path: "/admin/aml", icon: "AlertTriangle" },
  { label: "Finance", path: "/admin/finance", icon: "DollarSign" },
  { label: "Fee Engine", path: "/admin/fees", icon: "Calculator" },
  { label: "Revenue", path: "/admin/revenue", icon: "TrendingUp" },
  { label: "Payments", path: "/admin/payments", icon: "CreditCard" },
  { label: "FX Rates", path: "/admin/fx-rates", icon: "ArrowLeftRight" },
  { label: "Distributions", path: "/admin/distributions", icon: "Banknote" },
  { label: "FX Transactions", path: "/admin/fx-transactions", icon: "RefreshCcw" },
  { label: "FX Config", path: "/admin/fx-config", icon: "Settings" },
  { label: "FX Approvals", path: "/admin/fx-approvals", icon: "ShieldCheck" },
  { label: "Reconciliation", path: "/admin/reconciliation", icon: "FileSpreadsheet" },
  { label: "Receiving Banks", path: "/admin/receiving-banks", icon: "Building2" },
  { label: "Rounds", path: "/admin/rounds", icon: "Target" },
  { label: "Exit Windows", path: "/admin/exit-windows", icon: "ArrowLeftRight" },
  { label: "Marketplace", path: "/admin/marketplace-settings", icon: "Globe" },
  { label: "Crypto Wallets", path: "/admin/crypto-wallets", icon: "Link2" },
  { label: "Crypto Deposits", path: "/admin/crypto-deposits", icon: "ArrowDownLeft" },
  { label: "Support Tickets", path: "/admin/support-tickets", icon: "MessageSquare" },
  { label: "Role Permissions", path: "/admin/role-permissions", icon: "Shield" },
  { label: "Funds & SPVs", path: "/admin/vehicles", icon: "Landmark" },
  { label: "Offerings", path: "/admin/offerings", icon: "TrendingUp" },
  { label: "Valuations", path: "/admin/valuations", icon: "LineChart" },
  { label: "Settlement", path: "/admin/settlement", icon: "Landmark" },
  { label: "Token Console", path: "/admin/token-console", icon: "Coins" },
  { label: "Cap Table", path: "/admin/cap-table", icon: "PieChart" },
  { label: "Properties", path: "/admin/properties", icon: "Building2" },
  { label: "Acquisition", path: "/admin/property-acquisition", icon: "Receipt" },
  { label: "Rental Ops", path: "/admin/rental-operations", icon: "Home" },
  { label: "Waterfall", path: "/admin/waterfall-distribution", icon: "TrendingDown" },
  { label: "Property Sales", path: "/admin/property-sales", icon: "Gavel" },
  { label: "Projects", path: "/admin/projects", icon: "FolderKanban" },
  { label: "Data Room", path: "/admin/data-room", icon: "FolderOpen" },
  { label: "Doc Review", path: "/admin/document-review", icon: "ScanLine" },
  { label: "Audit Logs", path: "/admin/audit-logs", icon: "Shield", platformRolesRequired: ["SUPER_ADMIN", "PLATFORM_ADMIN"] },
  { label: "System Status", path: "/admin/system-status", icon: "Activity", platformRolesRequired: ["SUPER_ADMIN", "PLATFORM_ADMIN"] },
  { label: "DB Health", path: "/admin/db-health", icon: "Database", platformRolesRequired: ["SUPER_ADMIN"] },
  { label: "Settings", path: "/settings", icon: "Settings" },
];

export const tenantAdminNavItems: NavItem[] = [
  { label: "Dashboard", path: "/agency", icon: "LayoutDashboard" },
  { label: "Team Members", path: "/agency/users", icon: "Users", tenantRolesRequired: ["TENANT_OWNER", "TENANT_ADMIN"] },
  { label: "Settings", path: "/agency/settings", icon: "Settings", tenantRolesRequired: ["TENANT_OWNER", "TENANT_ADMIN"] },
];

export const roleNavItems: Record<Role, NavItem[]> = {
  investor: [
    { label: "Dashboard", path: "/investor", icon: "LayoutDashboard" },
    { label: "Portfolio", path: "/investor/portfolio", icon: "PieChart" },
    { label: "Returns", path: "/investor/returns", icon: "TrendingUp" },
    { label: "Wallet", path: "/investor/wallet", icon: "Wallet" },
    { label: "Marketplace", path: "/investor/marketplace", icon: "Store" },
    { label: "Add Funds", path: "/investor/add-funds", icon: "ArrowDownLeft" },
    { label: "Bank Accounts", path: "/investor/bank-accounts", icon: "Building2" },
    { label: "Trading", path: "/investor/trading", icon: "ArrowLeftRight" },
    { label: "Offerings", path: "/investor/offerings", icon: "TrendingUp" },
    { label: "KYC", path: "/investor/kyc", icon: "ShieldCheck" },
    { label: "Distributions", path: "/investor/distributions", icon: "Banknote" },
    { label: "Crypto Wallets", path: "/investor/crypto-wallets", icon: "Link2" },
    { label: "Crypto Deposits", path: "/investor/crypto-deposits", icon: "ArrowDownLeft" },
    { label: "Support", path: "/investor/support", icon: "MessageSquare" },
    { label: "Tax & Reports", path: "/investor/tax-reports", icon: "FileSpreadsheet" },
    { label: "My Properties", path: "/investor/ownership", icon: "Building2" },
    { label: "Settlements", path: "/investor/settlements", icon: "Receipt" },
    { label: "Data Room", path: "/investor/data-room", icon: "FolderOpen" },
    { label: "Fee Schedule", path: "/investor/fee-disclosure", icon: "Calculator" },
    { label: "My Tokens", path: "/investor/my-tokens", icon: "Coins" },
    { label: "Certificates", path: "/investor/certificates", icon: "Award" },
    { label: "Settings", path: "/settings", icon: "Settings" },
  ],
  admin: platformNavItems,
  issuer: [
    { label: "Dashboard", path: "/issuer", icon: "LayoutDashboard" },
    { label: "My Assets", path: "/issuer/assets", icon: "Blocks" },
    { label: "Rounds", path: "/issuer/rounds", icon: "Target" },
    { label: "Documents", path: "/issuer/docs", icon: "FileText" },
    { label: "Distributions", path: "/issuer/distributions", icon: "Banknote" },
    { label: "Settings", path: "/settings", icon: "Settings" },
  ],
  agent: [
    { label: "Dashboard", path: "/agent", icon: "LayoutDashboard" },
    { label: "Offers", path: "/agent/offers", icon: "Handshake" },
    { label: "Clients", path: "/agent/clients", icon: "Users" },
    { label: "Marketplace", path: "/agent/marketplace", icon: "Store" },
    { label: "Microsites", path: "/agent/microsites", icon: "Globe" },
    { label: "Settings", path: "/settings", icon: "Settings" },
  ],
  cms: [
    { label: "Dashboard", path: "/cms", icon: "LayoutDashboard" },
    { label: "Pages", path: "/cms/pages", icon: "FileText" },
    { label: "Properties", path: "/cms/properties", icon: "Building2" },
    { label: "Blog Posts", path: "/cms/blog", icon: "FileText" },
    { label: "FAQs", path: "/cms/faq", icon: "MessageSquare" },
    { label: "Guides", path: "/cms/guides", icon: "FileText" },
    { label: "Glossary", path: "/cms/glossary", icon: "Blocks" },
    { label: "Fees", path: "/cms/fees", icon: "Calculator" },
    { label: "Exit Windows", path: "/cms/exit-windows", icon: "ArrowLeftRight" },
    { label: "Global Content", path: "/cms/globals", icon: "Globe" },
    { label: "Audit Log", path: "/cms/audit", icon: "Shield" },
    { label: "Settings", path: "/settings", icon: "Settings" },
  ],
};

export const roleLabels: Record<Role, string> = {
  investor: "Investor",
  admin: "Administrator",
  issuer: "Issuer",
  agent: "Agent",
  cms: "Website Manager",
};

export function hasAccess(userRole: Role, requiredRole: Role): boolean {
  if (userRole === "admin") return true;
  return userRole === requiredRole;
}

export function getRoleColor(role: Role | string): string {
  switch (role) {
    case "admin":
      return "text-red-500";
    case "investor":
      return "text-emerald-500";
    case "issuer":
      return "text-blue-500";
    case "agent":
      return "text-amber-500";
    case "cms":
      return "text-violet-500";
    default:
      return "text-muted-foreground";
  }
}

export function getPlatformRoleColor(role: PlatformRole | string): string {
  switch (role) {
    case "SUPER_ADMIN":
      return "text-red-500";
    case "PLATFORM_ADMIN":
      return "text-orange-500";
    case "PLATFORM_FINANCE":
      return "text-blue-500";
    case "PLATFORM_COMPLIANCE":
      return "text-purple-500";
    default:
      return "text-muted-foreground";
  }
}

export function getTenantRoleColor(role: TenantRole | string): string {
  switch (role) {
    case "TENANT_OWNER":
      return "text-red-500";
    case "TENANT_ADMIN":
      return "text-orange-500";
    case "TENANT_MANAGER":
      return "text-blue-500";
    case "TENANT_MODERATOR":
      return "text-cyan-500";
    case "TENANT_USER":
      return "text-emerald-500";
    default:
      return "text-muted-foreground";
  }
}

export function getFilteredNavItems(
  items: NavItem[],
  platformRole: PlatformRole | null,
  tenantRole: TenantRole | null
): NavItem[] {
  return items.filter((item) => {
    if (item.platformRolesRequired && item.platformRolesRequired.length > 0) {
      if (!platformRole) return false;
      if (platformRole === "SUPER_ADMIN") return true;
      return item.platformRolesRequired.includes(platformRole);
    }
    if (item.tenantRolesRequired && item.tenantRolesRequired.length > 0) {
      if (!tenantRole) return false;
      if (tenantRole === "TENANT_OWNER") return true;
      return item.tenantRolesRequired.includes(tenantRole);
    }
    return true;
  });
}
