import type { CountryCode } from "./constants";
import type { DataRoomDocCategory } from "./schema";

export type ChecklistItem = {
  key: string;
  label: string;
  description: string;
  category: DataRoomDocCategory;
  required: boolean;
};

export type JurisdictionChecklist = {
  countryCode: CountryCode;
  countryName: string;
  assetChecklist: ChecklistItem[];
  offeringChecklist: ChecklistItem[];
};

const PK_CHECKLIST: JurisdictionChecklist = {
  countryCode: "PK",
  countryName: "Pakistan",
  assetChecklist: [
    { key: "pk_title_deed", label: "Title Deed / Fard", description: "Registered property title deed or fard from relevant land authority", category: "legal", required: true },
    { key: "pk_noc", label: "NOC from Development Authority", description: "No Objection Certificate from CDA/LDA/KDA or relevant authority", category: "compliance", required: true },
    { key: "pk_valuation", label: "Independent Valuation Report", description: "Valuation from SECP-approved valuer", category: "valuation", required: true },
    { key: "pk_spv_docs", label: "SPV Incorporation Documents", description: "Certificate of incorporation and memorandum of association", category: "corporate", required: true },
    { key: "pk_secp_approval", label: "SECP Regulatory Approval", description: "Securities & Exchange Commission of Pakistan approval for tokenization", category: "compliance", required: true },
    { key: "pk_tax_certificate", label: "Tax Registration Certificate", description: "NTN and sales tax registration", category: "compliance", required: false },
    { key: "pk_financial_model", label: "Financial Model / Projections", description: "Revenue projections and financial feasibility study", category: "financial", required: true },
    { key: "pk_building_plan", label: "Approved Building Plan", description: "Approved layout and building plan from relevant authority", category: "technical", required: false },
  ],
  offeringChecklist: [
    { key: "pk_ppm", label: "Private Placement Memorandum", description: "PPM compliant with SECP regulations", category: "legal", required: true },
    { key: "pk_subscription", label: "Subscription Agreement", description: "Token subscription agreement template", category: "legal", required: true },
    { key: "pk_risk_disclosure", label: "Risk Disclosure Document", description: "Risk factors and investor warnings per SECP guidelines", category: "compliance", required: true },
    { key: "pk_shariah_cert", label: "Shariah Compliance Certificate", description: "Shariah board certification (if Islamic structure)", category: "compliance", required: false },
  ],
};

const AE_CHECKLIST: JurisdictionChecklist = {
  countryCode: "AE",
  countryName: "United Arab Emirates",
  assetChecklist: [
    { key: "ae_title_deed", label: "Title Deed", description: "DLD / Abu Dhabi Municipality registered title deed", category: "legal", required: true },
    { key: "ae_noc", label: "Developer NOC", description: "No Objection Certificate from master developer", category: "legal", required: true },
    { key: "ae_valuation", label: "RICS Valuation Report", description: "Valuation by RICS-certified appraiser", category: "valuation", required: true },
    { key: "ae_spv_license", label: "SPV Trade License", description: "DIFC/ADGM or mainland trade license for SPV entity", category: "corporate", required: true },
    { key: "ae_escrow", label: "Escrow Account Registration", description: "RERA-registered escrow account details", category: "financial", required: true },
    { key: "ae_dfsa_approval", label: "DFSA / SCA Approval", description: "Regulatory approval from DFSA (DIFC) or SCA for security tokens", category: "compliance", required: true },
    { key: "ae_insurance", label: "Property Insurance Certificate", description: "Building and third-party liability insurance", category: "legal", required: false },
    { key: "ae_tenancy_contracts", label: "Tenancy Contracts / Ejari", description: "Existing lease agreements registered with Ejari", category: "financial", required: false },
  ],
  offeringChecklist: [
    { key: "ae_prospectus", label: "Offering Prospectus", description: "DFSA/SCA-compliant prospectus or information memorandum", category: "legal", required: true },
    { key: "ae_subscription", label: "Subscription Agreement", description: "Token subscription agreement for investors", category: "legal", required: true },
    { key: "ae_kyc_aml_policy", label: "KYC/AML Policy Document", description: "AML compliance framework and KYC procedures", category: "compliance", required: true },
    { key: "ae_risk_factors", label: "Risk Factors Statement", description: "Comprehensive risk disclosure per DFSA guidelines", category: "compliance", required: true },
  ],
};

const GB_CHECKLIST: JurisdictionChecklist = {
  countryCode: "GB",
  countryName: "United Kingdom",
  assetChecklist: [
    { key: "gb_land_registry", label: "Land Registry Title", description: "HM Land Registry official title register and plan", category: "legal", required: true },
    { key: "gb_valuation", label: "RICS Red Book Valuation", description: "Valuation compliant with RICS Red Book standards", category: "valuation", required: true },
    { key: "gb_spv_docs", label: "Companies House Registration", description: "SPV certificate of incorporation and articles of association", category: "corporate", required: true },
    { key: "gb_epc", label: "Energy Performance Certificate", description: "Valid EPC rating for the property", category: "technical", required: true },
    { key: "gb_fca_approval", label: "FCA Regulatory Status", description: "Financial Conduct Authority approval or exemption documentation", category: "compliance", required: true },
    { key: "gb_financial_statements", label: "Audited Financial Statements", description: "Most recent audited accounts for the SPV", category: "financial", required: true },
    { key: "gb_building_survey", label: "Building Survey Report", description: "Full structural survey by chartered surveyor", category: "technical", required: false },
  ],
  offeringChecklist: [
    { key: "gb_information_memo", label: "Information Memorandum", description: "FCA-compliant investment memorandum", category: "legal", required: true },
    { key: "gb_subscription", label: "Subscription Agreement", description: "Token subscription with FCA-required disclosures", category: "legal", required: true },
    { key: "gb_risk_warnings", label: "Risk Warnings", description: "FCA risk warnings including illiquidity and capital at risk", category: "compliance", required: true },
    { key: "gb_aml_verification", label: "AML Verification Records", description: "Anti-money laundering verification procedures documentation", category: "compliance", required: true },
  ],
};

const US_CHECKLIST: JurisdictionChecklist = {
  countryCode: "US",
  countryName: "United States",
  assetChecklist: [
    { key: "us_property_deed", label: "Property Deed", description: "County-recorded warranty deed or grant deed", category: "legal", required: true },
    { key: "us_title_insurance", label: "Title Insurance Policy", description: "Owner's title insurance policy from licensed provider", category: "legal", required: true },
    { key: "us_appraisal", label: "Independent Appraisal", description: "USPAP-compliant appraisal from licensed appraiser", category: "valuation", required: true },
    { key: "us_llc_docs", label: "LLC Operating Agreement", description: "SPV LLC formation documents and operating agreement", category: "corporate", required: true },
    { key: "us_sec_filing", label: "SEC Filing (Reg D/S)", description: "Form D filing or Regulation S compliance documentation", category: "compliance", required: true },
    { key: "us_environmental", label: "Environmental Assessment", description: "Phase I environmental site assessment", category: "technical", required: false },
    { key: "us_financial_projections", label: "Financial Projections", description: "Pro forma financials and cash flow projections", category: "financial", required: true },
  ],
  offeringChecklist: [
    { key: "us_ppm", label: "Private Placement Memorandum", description: "SEC-compliant PPM for Reg D/S offering", category: "legal", required: true },
    { key: "us_subscription", label: "Subscription Agreement", description: "Accredited investor subscription agreement", category: "legal", required: true },
    { key: "us_accreditation", label: "Accreditation Verification", description: "Procedures for verifying accredited investor status", category: "compliance", required: true },
    { key: "us_blue_sky", label: "Blue Sky Compliance", description: "State securities law compliance documentation", category: "compliance", required: false },
  ],
};

const QA_CHECKLIST: JurisdictionChecklist = {
  countryCode: "QA",
  countryName: "Qatar",
  assetChecklist: [
    { key: "qa_title_deed", label: "Property Title Deed", description: "Ministry of Justice registered title deed", category: "legal", required: true },
    { key: "qa_valuation", label: "Valuation Report", description: "Independent property valuation by licensed appraiser", category: "valuation", required: true },
    { key: "qa_spv_docs", label: "QFC Entity Registration", description: "Qatar Financial Centre entity registration or mainland CR", category: "corporate", required: true },
    { key: "qa_qfcra_approval", label: "QFCRA Approval", description: "QFC Regulatory Authority approval for security token offering", category: "compliance", required: true },
    { key: "qa_municipality_noc", label: "Municipality NOC", description: "Municipality clearance for the property", category: "compliance", required: false },
    { key: "qa_financial_model", label: "Financial Model", description: "Financial feasibility and return projections", category: "financial", required: true },
  ],
  offeringChecklist: [
    { key: "qa_offering_doc", label: "Offering Document", description: "QFCRA-compliant offering document", category: "legal", required: true },
    { key: "qa_subscription", label: "Subscription Agreement", description: "Token subscription agreement per QFC rules", category: "legal", required: true },
    { key: "qa_risk_disclosure", label: "Risk Disclosure", description: "Investor risk disclosure per QFCRA guidelines", category: "compliance", required: true },
  ],
};

export const JURISDICTION_CHECKLISTS: Record<CountryCode, JurisdictionChecklist> = {
  PK: PK_CHECKLIST,
  AE: AE_CHECKLIST,
  GB: GB_CHECKLIST,
  US: US_CHECKLIST,
  QA: QA_CHECKLIST,
};

export const PROPERTY_LIFECYCLE_CHECKLIST: ChecklistItem[] = [
  { key: "lc_title_deed", label: "Title Deed / Ownership Document", description: "Registered property title deed or equivalent ownership document", category: "legal", required: true },
  { key: "lc_valuation_report", label: "Valuation Report", description: "Current independent property valuation report", category: "valuation", required: true },
  { key: "lc_building_permit", label: "Building Permit / Approval", description: "Government-issued building or construction permit", category: "compliance", required: false },
  { key: "lc_construction_contract", label: "Construction Contract", description: "Main construction contract with the developer/contractor", category: "legal", required: false },
  { key: "lc_progress_report", label: "Construction Progress Report", description: "Latest construction milestone and progress update report", category: "technical", required: false },
  { key: "lc_completion_certificate", label: "Completion Certificate", description: "Building completion or occupancy certificate", category: "compliance", required: false },
  { key: "lc_handover_report", label: "Handover / Snagging Report", description: "Property handover inspection and snagging list", category: "technical", required: false },
  { key: "lc_tenancy_contract", label: "Tenancy Contract Template", description: "Standard lease agreement template used for rental onboarding", category: "legal", required: false },
  { key: "lc_ejari_registration", label: "Lease Registration (Ejari / Equivalent)", description: "Government-registered lease agreement", category: "compliance", required: false },
  { key: "lc_property_mgmt_agreement", label: "Property Management Agreement", description: "Agreement with the appointed property management company", category: "legal", required: false },
  { key: "lc_insurance_policy", label: "Property Insurance Policy", description: "Building and liability insurance certificate", category: "legal", required: true },
  { key: "lc_fire_safety", label: "Fire Safety Certificate", description: "Fire safety and civil defense clearance", category: "compliance", required: false },
  { key: "lc_service_charge_budget", label: "Service Charge Budget", description: "Annual service charge budget and breakdown", category: "financial", required: false },
  { key: "lc_rental_income_statement", label: "Rental Income Statement", description: "Historical rental income and collection records", category: "financial", required: false },
  { key: "lc_expense_report", label: "Operating Expense Report", description: "Operating expenses breakdown by category", category: "financial", required: false },
  { key: "lc_tax_assessment", label: "Property Tax Assessment", description: "Property tax valuation and payment records", category: "financial", required: false },
];

export function getAssetChecklist(countryCode: string): ChecklistItem[] {
  const policy = JURISDICTION_CHECKLISTS[countryCode as CountryCode];
  return policy?.assetChecklist ?? [];
}

export function getOfferingChecklist(countryCode: string): ChecklistItem[] {
  const policy = JURISDICTION_CHECKLISTS[countryCode as CountryCode];
  return policy?.offeringChecklist ?? [];
}

export function getPropertyLifecycleChecklist(): ChecklistItem[] {
  return PROPERTY_LIFECYCLE_CHECKLIST;
}
