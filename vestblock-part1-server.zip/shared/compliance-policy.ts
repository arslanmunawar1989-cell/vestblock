import type { CountryCode, CurrencyCode } from "./constants";
import type { DocumentType } from "./schema";
import type { PaymentMethod } from "./schema";

export type KycDocRequirement = {
  docType: DocumentType;
  label: string;
  description: string;
  required: boolean;
};

export type RiskThresholds = {
  pepAutoEscalate: boolean;
  largeDepositAmount: number;
  largeDepositCurrency: string;
  eddTriggerScore: number;
  maxOpenFlags: number;
};

export type PaymentRailStatus = "active" | "coming_soon" | "placeholder";

export type PaymentRail = {
  method: PaymentMethod;
  label: string;
  description: string;
  currencies: CurrencyCode[];
  status: PaymentRailStatus;
  provider: string;
  processingTime: string;
  minAmount?: number;
  maxAmount?: number;
};

export type CompliancePolicy = {
  countryCode: CountryCode;
  countryName: string;
  requiredKycDocs: KycDocRequirement[];
  allowedIdTypes: string[];
  allowedFundingRails: PaymentMethod[];
  paymentRails: PaymentRail[];
  blockedActions: string[];
  riskThresholds: RiskThresholds;
  requiresEmiratesId: boolean;
  requiresBankStatement: boolean;
  allowsFxConversion: boolean;
  notes: string[];
  ssnNotice?: string;
};

const POLICIES: Record<CountryCode, CompliancePolicy> = {
  AE: {
    countryCode: "AE",
    countryName: "United Arab Emirates",
    requiredKycDocs: [
      { docType: "id_front", label: "Emirates ID (Front)", description: "Front of your Emirates ID card (or passport photo page for non-residents)", required: true },
      { docType: "id_back", label: "Emirates ID (Back)", description: "Back of your Emirates ID card", required: true },
      { docType: "proof_of_address", label: "Proof of Address", description: "Utility bill or tenancy contract (last 3 months)", required: true },
      { docType: "source_of_funds", label: "Source of Funds Declaration", description: "Bank statement or salary certificate showing source of funds (last 3 months)", required: true },
    ],
    allowedIdTypes: ["emirates_id", "passport"],
    allowedFundingRails: ["bank_transfer", "card"],
    paymentRails: [
      {
        method: "bank_transfer",
        label: "UAE Bank Transfer",
        description: "Transfer AED from your UAE bank account via Emirates NBD",
        currencies: ["AED"],
        status: "active",
        provider: "manual",
        processingTime: "1-2 business days",
        minAmount: 100,
        maxAmount: 500000,
      },
      {
        method: "card",
        label: "Card Payment (Stripe)",
        description: "Pay with Visa, Mastercard, or AMEX via Stripe",
        currencies: ["AED", "USD"],
        status: "active",
        provider: "stripe",
        processingTime: "Instant",
        minAmount: 50,
        maxAmount: 100000,
      },
    ],
    blockedActions: [],
    riskThresholds: {
      pepAutoEscalate: true,
      largeDepositAmount: 50000,
      largeDepositCurrency: "AED",
      eddTriggerScore: 70,
      maxOpenFlags: 3,
    },
    requiresEmiratesId: true,
    requiresBankStatement: false,
    allowsFxConversion: true,
    notes: ["UAE Central Bank compliance required", "FATF member jurisdiction"],
  },
  PK: {
    countryCode: "PK",
    countryName: "Pakistan",
    requiredKycDocs: [
      { docType: "id_front", label: "CNIC / NICOP (Front)", description: "Front of your national identity card", required: true },
      { docType: "id_back", label: "CNIC / NICOP (Back)", description: "Back of your national identity card", required: true },
      { docType: "proof_of_address", label: "Proof of Address", description: "Utility bill or bank statement (last 3 months)", required: true },
      { docType: "bank_statement", label: "Bank Statement", description: "Recent bank statement showing source of funds (last 3 months)", required: true },
    ],
    allowedIdTypes: ["national_id", "passport"],
    allowedFundingRails: ["bank_transfer", "mobile_wallet", "instant_transfer", "remittance", "international_wire"],
    paymentRails: [
      {
        method: "bank_transfer",
        label: "Pakistan Bank Transfer (IBFT/RTGS)",
        description: "Transfer PKR from your Pakistani bank account via HBL inter-bank transfer",
        currencies: ["PKR"],
        status: "active",
        provider: "manual",
        processingTime: "Same day (IBFT) / 1-2 days (RTGS)",
        minAmount: 5000,
        maxAmount: 50000000,
      },
      {
        method: "mobile_wallet",
        label: "JazzCash",
        description: "Send PKR from your JazzCash mobile wallet",
        currencies: ["PKR"],
        status: "active",
        provider: "jazzcash",
        processingTime: "Instant - 1 hour",
        minAmount: 1000,
        maxAmount: 500000,
      },
      {
        method: "mobile_wallet",
        label: "Easypaisa",
        description: "Send PKR from your Easypaisa mobile wallet",
        currencies: ["PKR"],
        status: "active",
        provider: "easypaisa",
        processingTime: "Instant - 1 hour",
        minAmount: 1000,
        maxAmount: 500000,
      },
      {
        method: "instant_transfer",
        label: "Raast (Instant Payment)",
        description: "Send PKR instantly via Pakistan's Raast real-time payment system",
        currencies: ["PKR"],
        status: "active",
        provider: "raast",
        processingTime: "Instant",
        minAmount: 500,
        maxAmount: 5000000,
      },
      {
        method: "remittance",
        label: "TapTap Send",
        description: "Send funds internationally to Pakistan via TapTap Send (converted to PKR)",
        currencies: ["PKR"],
        status: "active",
        provider: "taptap_send",
        processingTime: "1-2 business days",
        minAmount: 5000,
        maxAmount: 2000000,
      },
      {
        method: "international_wire",
        label: "International Wire Transfer",
        description: "Send funds from any international bank to Pakistan via SWIFT wire transfer",
        currencies: ["PKR"],
        status: "active",
        provider: "pk_international_wire",
        processingTime: "2-5 business days",
        minAmount: 10000,
        maxAmount: 50000000,
      },
    ],
    blockedActions: ["crypto_deposit"],
    riskThresholds: {
      pepAutoEscalate: true,
      largeDepositAmount: 5000000,
      largeDepositCurrency: "PKR",
      eddTriggerScore: 60,
      maxOpenFlags: 2,
    },
    requiresEmiratesId: false,
    requiresBankStatement: true,
    allowsFxConversion: true,
    notes: ["SECP regulated", "State Bank of Pakistan FX controls apply", "FATF grey list considerations"],
  },
  GB: {
    countryCode: "GB",
    countryName: "United Kingdom",
    requiredKycDocs: [
      { docType: "id_front", label: "Passport or Driving Licence", description: "Photo page of passport or front of driving licence", required: true },
      { docType: "proof_of_address", label: "Proof of Address", description: "Utility bill, council tax bill, or bank statement (last 3 months)", required: true },
      { docType: "source_of_funds", label: "Source of Funds Declaration", description: "Bank statement, payslip, or tax return showing source of funds (last 3 months)", required: true },
    ],
    allowedIdTypes: ["passport", "drivers_license"],
    allowedFundingRails: ["bank_transfer", "card"],
    paymentRails: [
      {
        method: "card",
        label: "Card Payment (Stripe)",
        description: "Pay with Visa, Mastercard, or AMEX via Stripe",
        currencies: ["GBP", "USD"],
        status: "coming_soon",
        provider: "stripe",
        processingTime: "Instant",
        minAmount: 10,
        maxAmount: 50000,
      },
      {
        method: "bank_transfer",
        label: "UK Bank Transfer",
        description: "Transfer GBP from your UK bank account via Faster Payments",
        currencies: ["GBP"],
        status: "coming_soon",
        provider: "manual",
        processingTime: "Same day (Faster Payments)",
        minAmount: 50,
        maxAmount: 250000,
      },
    ],
    blockedActions: [],
    riskThresholds: {
      pepAutoEscalate: true,
      largeDepositAmount: 10000,
      largeDepositCurrency: "GBP",
      eddTriggerScore: 75,
      maxOpenFlags: 3,
    },
    requiresEmiratesId: false,
    requiresBankStatement: false,
    allowsFxConversion: true,
    notes: ["FCA regulated jurisdiction", "FATF member"],
  },
  US: {
    countryCode: "US",
    countryName: "United States",
    requiredKycDocs: [
      { docType: "id_front", label: "Government-Issued Photo ID (Front)", description: "Front of passport, state ID, or driving licence", required: true },
      { docType: "id_back", label: "Government-Issued Photo ID (Back)", description: "Back of state ID or driving licence (if applicable)", required: false },
      { docType: "proof_of_address", label: "Proof of Address", description: "Utility bill or bank statement (last 3 months)", required: true },
    ],
    ssnNotice: "SSN collection is not supported in this version. Full US compliance (SSN/ITIN verification) will be available in a future release. Proceed with photo ID and proof of address for now.",
    allowedIdTypes: ["passport", "drivers_license", "national_id"],
    allowedFundingRails: ["bank_transfer", "card"],
    paymentRails: [
      {
        method: "card",
        label: "Card Payment (Stripe)",
        description: "Pay with Visa, Mastercard, or AMEX via Stripe",
        currencies: ["USD"],
        status: "coming_soon",
        provider: "stripe",
        processingTime: "Instant",
        minAmount: 25,
        maxAmount: 100000,
      },
      {
        method: "bank_transfer",
        label: "ACH Bank Transfer",
        description: "Transfer USD from your US bank account via ACH",
        currencies: ["USD"],
        status: "active",
        provider: "ach",
        processingTime: "2-3 business days",
        minAmount: 100,
        maxAmount: 250000,
      },
    ],
    blockedActions: ["crypto_deposit", "fx_conversion"],
    riskThresholds: {
      pepAutoEscalate: true,
      largeDepositAmount: 10000,
      largeDepositCurrency: "USD",
      eddTriggerScore: 65,
      maxOpenFlags: 2,
    },
    requiresEmiratesId: false,
    requiresBankStatement: false,
    allowsFxConversion: false,
    notes: ["SEC/FinCEN compliance required", "Accredited investor verification may apply", "OFAC screening mandatory"],
  },
  QA: {
    countryCode: "QA",
    countryName: "Qatar",
    requiredKycDocs: [
      { docType: "id_front", label: "Qatar ID or Passport (Front)", description: "Front of your Qatar ID card or passport photo page", required: true },
      { docType: "id_back", label: "Qatar ID or Passport (Back)", description: "Back of your Qatar ID card", required: true },
      { docType: "proof_of_address", label: "Proof of Address", description: "Utility bill, tenancy contract, or bank statement (last 3 months)", required: true },
    ],
    allowedIdTypes: ["national_id", "passport"],
    allowedFundingRails: ["bank_transfer", "card"],
    paymentRails: [
      {
        method: "bank_transfer",
        label: "Qatar Bank Transfer",
        description: "Transfer QAR from your Qatari bank account via QNB",
        currencies: ["QAR"],
        status: "coming_soon",
        provider: "manual",
        processingTime: "1-2 business days",
        minAmount: 500,
        maxAmount: 500000,
      },
      {
        method: "card",
        label: "Card Payment",
        description: "Pay with Visa or Mastercard",
        currencies: ["QAR", "USD"],
        status: "coming_soon",
        provider: "card_provider",
        processingTime: "Instant",
        minAmount: 100,
        maxAmount: 100000,
      },
    ],
    blockedActions: [],
    riskThresholds: {
      pepAutoEscalate: true,
      largeDepositAmount: 50000,
      largeDepositCurrency: "QAR",
      eddTriggerScore: 70,
      maxOpenFlags: 3,
    },
    requiresEmiratesId: false,
    requiresBankStatement: false,
    allowsFxConversion: true,
    notes: ["Qatar Financial Centre Authority regulated", "FATF member"],
  },
};

const DEFAULT_POLICY: CompliancePolicy = POLICIES.AE;

export function getPolicy(countryCode: CountryCode | string): CompliancePolicy {
  return POLICIES[countryCode as CountryCode] || DEFAULT_POLICY;
}

export function getRequiredDocs(countryCode: CountryCode | string): KycDocRequirement[] {
  return getPolicy(countryCode).requiredKycDocs;
}

export function getAllowedFundingRails(countryCode: CountryCode | string): PaymentMethod[] {
  return getPolicy(countryCode).allowedFundingRails;
}

export function getPaymentRails(countryCode: CountryCode | string): PaymentRail[] {
  return getPolicy(countryCode).paymentRails;
}

export function getActivePaymentRails(countryCode: CountryCode | string): PaymentRail[] {
  return getPolicy(countryCode).paymentRails.filter(r => r.status === "active");
}

export function isActionBlocked(countryCode: CountryCode | string, action: string): boolean {
  return getPolicy(countryCode).blockedActions.includes(action);
}

export function isIdTypeAllowed(countryCode: CountryCode | string, idType: string): boolean {
  return getPolicy(countryCode).allowedIdTypes.includes(idType);
}

export function isFxAllowed(countryCode: CountryCode | string): boolean {
  return getPolicy(countryCode).allowsFxConversion;
}

export function isLargeDeposit(countryCode: CountryCode | string, amount: number): boolean {
  const thresholds = getPolicy(countryCode).riskThresholds;
  return amount >= thresholds.largeDepositAmount;
}

export function shouldAutoEscalatePep(countryCode: CountryCode | string): boolean {
  return getPolicy(countryCode).riskThresholds.pepAutoEscalate;
}

export function getEddTriggerScore(countryCode: CountryCode | string): number {
  return getPolicy(countryCode).riskThresholds.eddTriggerScore;
}

export function getMaxOpenFlags(countryCode: CountryCode | string): number {
  return getPolicy(countryCode).riskThresholds.maxOpenFlags;
}

export function getAllPolicies(): CompliancePolicy[] {
  return Object.values(POLICIES);
}

export type RiskReviewTemplate = {
  id: string;
  label: string;
  notes: string;
};

export function getRiskReviewTemplates(countryCode: CountryCode | string): RiskReviewTemplate[] {
  const policy = getPolicy(countryCode);
  const templates: RiskReviewTemplate[] = [
    {
      id: "pep_review",
      label: "PEP Review",
      notes: `Politically Exposed Person review for ${policy.countryName}. PEP auto-escalate: ${policy.riskThresholds.pepAutoEscalate ? "Enabled" : "Disabled"}. EDD trigger score: ${policy.riskThresholds.eddTriggerScore}. Max open flags: ${policy.riskThresholds.maxOpenFlags}.`,
    },
    {
      id: "large_deposit",
      label: "Large Deposit Flag",
      notes: `Large deposit threshold for ${policy.countryName}: ${policy.riskThresholds.largeDepositCurrency} ${policy.riskThresholds.largeDepositAmount.toLocaleString()}. Verify source of funds documentation.`,
    },
    {
      id: "doc_deficiency",
      label: "Document Deficiency",
      notes: `Required documents for ${policy.countryName}: ${policy.requiredKycDocs.filter(d => d.required).map(d => d.label).join(", ")}. Please verify all required documents are submitted and valid.`,
    },
    {
      id: "country_risk",
      label: "Country Risk Assessment",
      notes: `Country: ${policy.countryName} (${policy.countryCode}). Regulatory notes: ${policy.notes.join("; ")}. FX conversion: ${policy.allowsFxConversion ? "Allowed" : "Restricted"}.`,
    },
    {
      id: "edd_required",
      label: "Enhanced Due Diligence",
      notes: `Enhanced Due Diligence required for ${policy.countryName} applicant. Risk score exceeds EDD trigger threshold (${policy.riskThresholds.eddTriggerScore}). Review all financial disclosures and source of funds.`,
    },
  ];
  return templates;
}
