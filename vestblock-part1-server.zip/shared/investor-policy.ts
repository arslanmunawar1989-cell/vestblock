import type { CountryCode } from "./constants";
import type { InvestorType } from "./schema";

export type PaymentRailId =
  | "stripe"
  | "jazzcash"
  | "easypaisa"
  | "raast"
  | "ach"
  | "wire"
  | "crypto"
  | "manual";

export interface InvestorTypePolicy {
  minInvestAmount: number;
  maxInvestAmount: number | null;
  maxHoldings: number | null;
  allowedRails: PaymentRailId[];
  canTrade: boolean;
  requiresKyc: boolean;
  requiresEdd: boolean;
  coolOffPeriodDays: number;
  fxAllowed: boolean;
  cryptoAllowed: boolean;
  label: string;
  description: string;
}

export interface CountryInvestorPolicy {
  countryCode: CountryCode;
  countryName: string;
  sanctioned: boolean;
  blocked: boolean;
  blockReason?: string;
  investorPolicies: Record<InvestorType, InvestorTypePolicy>;
}

export const SANCTIONED_COUNTRIES: string[] = [
  "KP", "IR", "SY", "CU", "RU", "BY", "VE", "MM", "SD", "SO",
  "YE", "LY", "CF", "CD", "SS", "ZW",
];

export const BLOCKED_NATIONALITIES: string[] = [
  "KP", "IR", "SY", "CU",
];

export function isSanctionedCountry(code: string): boolean {
  return SANCTIONED_COUNTRIES.includes(code.toUpperCase());
}

export function isBlockedNationality(code: string): boolean {
  return BLOCKED_NATIONALITIES.includes(code.toUpperCase());
}

const DEFAULT_RETAIL: InvestorTypePolicy = {
  minInvestAmount: 100,
  maxInvestAmount: 50_000,
  maxHoldings: 10,
  allowedRails: ["stripe", "manual"],
  canTrade: false,
  requiresKyc: true,
  requiresEdd: false,
  coolOffPeriodDays: 14,
  fxAllowed: true,
  cryptoAllowed: false,
  label: "Retail Investor",
  description: "Standard individual investor with basic protections",
};

const DEFAULT_SOPHISTICATED: InvestorTypePolicy = {
  minInvestAmount: 50,
  maxInvestAmount: 250_000,
  maxHoldings: 25,
  allowedRails: ["stripe", "wire", "manual"],
  canTrade: true,
  requiresKyc: true,
  requiresEdd: false,
  coolOffPeriodDays: 7,
  fxAllowed: true,
  cryptoAllowed: true,
  label: "Sophisticated Investor",
  description: "Experienced investor with self-certified qualification",
};

const DEFAULT_ACCREDITED: InvestorTypePolicy = {
  minInvestAmount: 10,
  maxInvestAmount: 1_000_000,
  maxHoldings: null,
  allowedRails: ["stripe", "wire", "ach", "crypto", "manual"],
  canTrade: true,
  requiresKyc: true,
  requiresEdd: true,
  coolOffPeriodDays: 3,
  fxAllowed: true,
  cryptoAllowed: true,
  label: "Accredited Investor",
  description: "Verified high-net-worth or qualified purchaser",
};

const DEFAULT_INSTITUTIONAL: InvestorTypePolicy = {
  minInvestAmount: 1,
  maxInvestAmount: null,
  maxHoldings: null,
  allowedRails: ["stripe", "wire", "ach", "crypto", "manual"],
  canTrade: true,
  requiresKyc: true,
  requiresEdd: true,
  coolOffPeriodDays: 0,
  fxAllowed: true,
  cryptoAllowed: true,
  label: "Institutional Investor",
  description: "Regulated entity such as fund, bank, or family office",
};

export const COUNTRY_INVESTOR_POLICIES: Record<CountryCode, CountryInvestorPolicy> = {
  PK: {
    countryCode: "PK",
    countryName: "Pakistan",
    sanctioned: false,
    blocked: false,
    investorPolicies: {
      retail: {
        ...DEFAULT_RETAIL,
        allowedRails: ["jazzcash", "easypaisa", "raast", "manual"],
        maxInvestAmount: 5_000_000,
        minInvestAmount: 1_000,
        cryptoAllowed: false,
      },
      sophisticated: {
        ...DEFAULT_SOPHISTICATED,
        allowedRails: ["jazzcash", "easypaisa", "raast", "wire", "manual"],
        maxInvestAmount: 25_000_000,
        cryptoAllowed: false,
      },
      accredited: {
        ...DEFAULT_ACCREDITED,
        allowedRails: ["raast", "wire", "manual"],
        maxInvestAmount: 100_000_000,
        cryptoAllowed: false,
      },
      institutional: {
        ...DEFAULT_INSTITUTIONAL,
        allowedRails: ["raast", "wire", "manual"],
        cryptoAllowed: false,
      },
    },
  },
  AE: {
    countryCode: "AE",
    countryName: "United Arab Emirates",
    sanctioned: false,
    blocked: false,
    investorPolicies: {
      retail: {
        ...DEFAULT_RETAIL,
        allowedRails: ["stripe", "wire", "manual"],
        maxInvestAmount: 100_000,
      },
      sophisticated: {
        ...DEFAULT_SOPHISTICATED,
        allowedRails: ["stripe", "wire", "crypto", "manual"],
        maxInvestAmount: 500_000,
      },
      accredited: {
        ...DEFAULT_ACCREDITED,
        allowedRails: ["stripe", "wire", "crypto", "manual"],
      },
      institutional: {
        ...DEFAULT_INSTITUTIONAL,
        allowedRails: ["wire", "crypto", "manual"],
      },
    },
  },
  GB: {
    countryCode: "GB",
    countryName: "United Kingdom",
    sanctioned: false,
    blocked: false,
    investorPolicies: {
      retail: {
        ...DEFAULT_RETAIL,
        allowedRails: ["stripe", "manual"],
        maxInvestAmount: 10_000,
        canTrade: false,
        coolOffPeriodDays: 14,
      },
      sophisticated: {
        ...DEFAULT_SOPHISTICATED,
        allowedRails: ["stripe", "wire", "manual"],
        coolOffPeriodDays: 7,
      },
      accredited: {
        ...DEFAULT_ACCREDITED,
        allowedRails: ["stripe", "wire", "manual"],
      },
      institutional: {
        ...DEFAULT_INSTITUTIONAL,
        allowedRails: ["wire", "manual"],
      },
    },
  },
  US: {
    countryCode: "US",
    countryName: "United States",
    sanctioned: false,
    blocked: false,
    investorPolicies: {
      retail: {
        ...DEFAULT_RETAIL,
        allowedRails: ["stripe", "ach", "manual"],
        canTrade: false,
        maxInvestAmount: 2_200,
        coolOffPeriodDays: 14,
        cryptoAllowed: false,
      },
      sophisticated: {
        ...DEFAULT_SOPHISTICATED,
        allowedRails: ["stripe", "ach", "wire", "manual"],
        cryptoAllowed: false,
      },
      accredited: {
        ...DEFAULT_ACCREDITED,
        allowedRails: ["stripe", "ach", "wire", "manual"],
        cryptoAllowed: false,
      },
      institutional: {
        ...DEFAULT_INSTITUTIONAL,
        allowedRails: ["ach", "wire", "manual"],
        cryptoAllowed: false,
      },
    },
  },
  QA: {
    countryCode: "QA",
    countryName: "Qatar",
    sanctioned: false,
    blocked: false,
    investorPolicies: {
      retail: {
        ...DEFAULT_RETAIL,
        allowedRails: ["stripe", "wire", "manual"],
        maxInvestAmount: 50_000,
      },
      sophisticated: {
        ...DEFAULT_SOPHISTICATED,
        allowedRails: ["stripe", "wire", "manual"],
      },
      accredited: {
        ...DEFAULT_ACCREDITED,
        allowedRails: ["wire", "manual"],
      },
      institutional: {
        ...DEFAULT_INSTITUTIONAL,
        allowedRails: ["wire", "manual"],
      },
    },
  },
};

export function getCountryPolicy(countryCode: string): CountryInvestorPolicy | null {
  const code = countryCode.toUpperCase() as CountryCode;
  return COUNTRY_INVESTOR_POLICIES[code] ?? null;
}

export function getInvestorPolicy(
  countryCode: string,
  investorType: InvestorType
): InvestorTypePolicy | null {
  const countryPolicy = getCountryPolicy(countryCode);
  if (!countryPolicy) return null;
  return countryPolicy.investorPolicies[investorType] ?? null;
}

export function meetsInvestorTypeRequirement(
  userType: InvestorType,
  requiredType: InvestorType
): boolean {
  const RANK: Record<InvestorType, number> = {
    retail: 0,
    sophisticated: 1,
    accredited: 2,
    institutional: 3,
  };
  return (RANK[userType] ?? 0) >= (RANK[requiredType] ?? 0);
}
