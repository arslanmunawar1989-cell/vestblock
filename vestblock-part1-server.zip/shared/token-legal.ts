export function tokenLegalDescription(vehicleName: string, vehicleType?: string): string {
  const typeLabel = vehicleType === "FUND" ? "Fund" : "SPV";
  return `Digital representation of beneficial ownership units in ${vehicleName} (${typeLabel}), recorded on the platform ledger.`;
}

export const TOKEN_LEGAL_CLASSIFICATION = {
  positiveDescriptor: "Digital Beneficial Ownership Unit",
  shortLabel: "Ownership Unit",
  description: "Each token represents a digital beneficial ownership unit in a regulated Special Purpose Vehicle (SPV) or Fund structure. All ownership records are maintained on the platform's immutable internal ledger.",
  prohibitedTerms: [
    "cryptocurrency",
    "utility token",
    "public tradable coin",
    "crypto coin",
    "digital currency",
  ],
  secondaryMarketNotice: "Secondary trading is restricted to verified investors only, conducted exclusively during scheduled exit windows, and subject to KYC/AML compliance, jurisdiction eligibility, and transfer restriction checks.",
  regulatoryNotice: "Tokens issued on this platform are not cryptocurrencies, utility tokens, or publicly tradable coins. They represent regulated beneficial ownership interests and are subject to applicable securities laws in each jurisdiction.",
} as const;

export const TOKEN_LEGAL_DISCLAIMERS = {
  investorFacing: `The ownership units displayed represent your beneficial interest in the underlying property vehicle (SPV/Fund). These are not cryptocurrencies, utility tokens, or publicly tradable digital assets. All holdings are recorded on the platform's internal ledger and are subject to applicable securities regulations.`,
  tradingDisclaimer: `Secondary market trading is available only during scheduled exit windows and is restricted to KYC-verified investors who meet jurisdiction eligibility requirements. All trades are subject to transfer restriction checks, cooldown periods, and applicable exit fees. This is not a public exchange.`,
  assetDetailDisclaimer: `Investment tokens represent digital beneficial ownership units in the property's Special Purpose Vehicle (SPV) or Fund. They are recorded on the platform ledger and do not constitute cryptocurrency or any form of publicly tradable digital asset. Trading is exit-window controlled and restricted to verified investors.`,
  certificateDisclaimer: `This certificate confirms your beneficial ownership of units in the referenced vehicle. These units are digital representations of ownership interests recorded on the platform ledger and are not cryptocurrencies, utility tokens, or publicly tradable coins.`,
} as const;
