import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, decimal, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import {
  ROLES, type Role as ConstRole,
  WALLET_CURRENCIES, type WalletCurrency as ConstWalletCurrency, walletCurrencySchema,
  BANK_ACCOUNT_COUNTRIES, type BankAccountCountry as ConstBankAccountCountry, bankAccountCountrySchema,
  SUPPORTED_COUNTRIES, type CountryCode, countryCodeSchema,
} from "./constants";

export const roleEnum = ROLES;
export type Role = ConstRole;

export const tenants = pgTable("tenants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  status: text("status").notNull().default("ACTIVE"),
  brandingJson: jsonb("branding_json"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertTenantSchema = createInsertSchema(tenants).omit({ id: true, createdAt: true });
export type InsertTenant = z.infer<typeof insertTenantSchema>;
export type Tenant = typeof tenants.$inferSelect;

export const tenantUsers = pgTable("tenant_users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id").notNull(),
  userId: varchar("user_id").notNull(),
  role: text("role").notNull().default("TENANT_USER"),
  status: text("status").notNull().default("ACTIVE"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertTenantUserSchema = createInsertSchema(tenantUsers).omit({ id: true, createdAt: true });
export type InsertTenantUser = z.infer<typeof insertTenantUserSchema>;
export type TenantUser = typeof tenantUsers.$inferSelect;

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull().default("investor"),
  platformRole: text("platform_role"),
  avatarUrl: text("avatar_url"),
  googleId: text("google_id"),
  authProvider: text("auth_provider").notNull().default("local"),
  kycStatus: text("kyc_status").notNull().default("pending"),
  isActive: boolean("is_active").notNull().default(true),
  accountStatus: text("account_status").notNull().default("ACTIVE"),
  tokenVersion: integer("token_version").notNull().default(0),
  disabledAt: text("disabled_at"),
  archivedAt: text("archived_at"),
  statusChangedBy: varchar("status_changed_by"),
  phone: text("phone"),
  nationality: text("nationality"),
  address: text("address"),
  timezone: text("timezone"),
  notificationPreferences: jsonb("notification_preferences").default(sql`'{"email":true,"sms":false,"push":true,"marketing":false,"security":true,"transactions":true,"distributions":true,"autoConvertDistributions":false}'::jsonb`),
  eddStatus: text("edd_status").notNull().default("none"),
  tier: text("tier").notNull().default("standard"),
  investorType: text("investor_type").notNull().default("retail"),
  countryOfResidence: text("country_of_residence"),
  taxResidency: text("tax_residency"),
  primaryCurrency: text("primary_currency"),
});

export const impersonationLogs = pgTable("impersonation_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  actorId: varchar("actor_id").notNull(),
  actorUsername: text("actor_username").notNull(),
  targetTenantId: varchar("target_tenant_id").notNull(),
  targetTenantName: text("target_tenant_name"),
  reason: text("reason"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  startedAt: text("started_at").notNull().default(sql`now()`),
  endedAt: text("ended_at"),
});

export const vehicleTypeEnum = ["FUND", "SPV", "TRUST"] as const;
export type VehicleType = (typeof vehicleTypeEnum)[number];

export const vehicleStatusEnum = ["DRAFT", "REVIEW", "ACTIVE", "SUSPENDED", "CLOSED"] as const;
export type VehicleStatus = (typeof vehicleStatusEnum)[number];

export const investmentVehicles = pgTable("investment_vehicles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  name: text("name").notNull(),
  type: text("type").notNull(),
  jurisdictionCountry: text("jurisdiction_country").notNull(),
  baseCurrency: text("base_currency").notNull().default("AED"),
  bankAccountConfigId: varchar("bank_account_config_id"),
  status: text("status").notNull().default("DRAFT"),
  platformFee: decimal("platform_fee", { precision: 5, scale: 2 }),
  trusteeFee: decimal("trustee_fee", { precision: 5, scale: 2 }),
  propertyMgmtFee: decimal("property_mgmt_fee", { precision: 5, scale: 2 }),
  legalFee: decimal("legal_fee", { precision: 5, scale: 2 }),
  reservePercent: decimal("reserve_percent", { precision: 5, scale: 2 }),
  description: text("description"),
  targetAum: decimal("target_aum", { precision: 18, scale: 2 }),
  currentNav: decimal("current_nav", { precision: 18, scale: 2 }),
  strategy: text("strategy"),
  fundManager: text("fund_manager"),
  inceptionDate: text("inception_date"),
  openEnded: boolean("open_ended").default(false),
  regNumber: text("reg_number"),
  registeredAgent: text("registered_agent"),
  incorporationDate: text("incorporation_date"),
  createdBy: varchar("created_by").notNull(),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const assets = pgTable("assets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  name: text("name").notNull(),
  symbol: text("symbol").notNull(),
  assetType: text("asset_type").notNull(),
  description: text("description"),
  totalSupply: decimal("total_supply", { precision: 18, scale: 2 }).notNull(),
  pricePerToken: decimal("price_per_token", { precision: 18, scale: 6 }).notNull(),
  baseCurrency: text("base_currency").notNull().default("AED"),
  country: text("country").notNull().default("AE"),
  status: text("status").notNull().default("active"),
  issuerId: varchar("issuer_id").notNull(),
  vehicleId: varchar("vehicle_id"),
  imageUrl: text("image_url"),
  propertyType: text("property_type"),
  location: text("location"),
  annualYield: decimal("annual_yield", { precision: 8, scale: 4 }),
  occupancyRate: decimal("occupancy_rate", { precision: 5, scale: 2 }),
  totalPropertyValue: decimal("total_property_value", { precision: 18, scale: 2 }),
  managementFee: decimal("management_fee", { precision: 5, scale: 2 }),
  distributionFrequency: text("distribution_frequency"),
  minInvestment: decimal("min_investment", { precision: 18, scale: 2 }),
  maxInvestment: decimal("max_investment", { precision: 18, scale: 2 }),
  maxOwnershipPercent: decimal("max_ownership_percent", { precision: 5, scale: 2 }),
  riskRating: text("risk_rating"),
  maturityDate: text("maturity_date"),
  legalStructure: text("legal_structure"),
  regulatoryBody: text("regulatory_body"),
  propertyClass: text("property_class"),
  tenantProfile: text("tenant_profile"),
  leverageRatio: decimal("leverage_ratio", { precision: 5, scale: 2 }),
  appraisedValue: decimal("appraised_value", { precision: 18, scale: 2 }),
  tokenizationStructure: text("tokenization_structure"),
  highlights: text("highlights"),
  documentUrls: text("document_urls"),
  navPerToken: decimal("nav_per_token", { precision: 18, scale: 6 }),
  irr: decimal("irr", { precision: 8, scale: 4 }),
  constructionStatus: text("construction_status"),
  yearBuilt: text("year_built"),
  totalArea: text("total_area"),
  tokenDecimals: integer("token_decimals").notNull().default(2),
  numberOfUnits: integer("number_of_units"),
  parkingSpaces: integer("parking_spaces"),
  amenities: text("amenities"),
  nearbyLandmarks: text("nearby_landmarks"),
  expectedCompletionDate: text("expected_completion_date"),
  issuerName: text("issuer_name"),
  jurisdictionChecklist: jsonb("jurisdiction_checklist"),
  minInvestorType: text("min_investor_type").notNull().default("retail"),
  submissionStatus: text("submission_status").notNull().default("draft"),
  adminReviewNotes: text("admin_review_notes"),
  submittedAt: text("submitted_at"),
  reviewedAt: text("reviewed_at"),
  expectedRentalYield: decimal("expected_rental_yield", { precision: 8, scale: 4 }),
  projectedCapitalAppreciation: decimal("projected_capital_appreciation", { precision: 8, scale: 4 }),
  holdingPeriodYears: integer("holding_period_years"),
  projectedTotalReturn: decimal("projected_total_return", { precision: 8, scale: 4 }),
  eligibleCountries: text("eligible_countries").array().default(sql`'{}'::text[]`),
  restrictedCountries: text("restricted_countries").array().default(sql`'{}'::text[]`),
  dataRoomTierThresholds: jsonb("data_room_tier_thresholds"),
});

export const rounds = pgTable("rounds", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id").notNull(),
  name: text("name").notNull(),
  targetAmount: decimal("target_amount", { precision: 18, scale: 2 }).notNull(),
  raisedAmount: decimal("raised_amount", { precision: 18, scale: 2 }).notNull().default("0"),
  status: text("status").notNull().default("open"),
  startDate: text("start_date").notNull(),
  endDate: text("end_date"),
});

export const portfolioItems = pgTable("portfolio_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  userId: varchar("user_id").notNull(),
  assetId: varchar("asset_id").notNull(),
  quantity: decimal("quantity", { precision: 18, scale: 6 }).notNull(),
  averageCost: decimal("average_cost", { precision: 18, scale: 6 }).notNull(),
});

export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  userId: varchar("user_id").notNull(),
  assetId: varchar("asset_id"),
  type: text("type").notNull(),
  amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
  currency: text("currency").default("PKR"),
  status: text("status").notNull().default("pending"),
  description: text("description"),
  metadataJson: jsonb("metadata_json"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const kycStatusEnum = ["NOT_STARTED", "IN_REVIEW", "APPROVED", "REJECTED", "INFO_REQUESTED", "EXPIRED"] as const;
export type KycStatus = (typeof kycStatusEnum)[number];

export const idTypeEnum = ["passport", "national_id", "drivers_license", "emirates_id"] as const;
export type IdType = (typeof idTypeEnum)[number];

export const kycProfiles = pgTable("kyc_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  userId: varchar("user_id").notNull(),
  status: text("status").notNull().default("NOT_STARTED"),
  legalName: text("legal_name").notNull(),
  dob: text("dob").notNull(),
  address: text("address").notNull(),
  idType: text("id_type").notNull(),
  idNumber: text("id_number").notNull(),
  emiratesIdFlag: boolean("emirates_id_flag").notNull().default(false),
  sourceOfWealth: text("source_of_wealth").notNull(),
  sourceOfFunds: text("source_of_funds").notNull(),
  pepFlag: boolean("pep_flag").notNull().default(false),
  riskScore: integer("risk_score"),
  submittedAt: text("submitted_at"),
  reviewedAt: text("reviewed_at"),
  reviewNotes: text("review_notes"),
});

export const documentTypeEnum = ["id_front", "id_back", "proof_of_address", "bank_statement", "source_of_funds", "other"] as const;
export type DocumentType = (typeof documentTypeEnum)[number];

export const documents = pgTable("documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  ownerId: varchar("owner_id").notNull(),
  assetId: varchar("asset_id"),
  type: text("type").notNull(),
  url: text("url").notNull(),
  fileName: text("file_name").notNull(),
  fileSize: integer("file_size"),
  mimeType: text("mime_type"),
  checksum: text("checksum"),
  status: text("status").notNull().default("uploaded"),
  kycProfileId: varchar("kyc_profile_id"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  userId: varchar("user_id").notNull(),
  type: text("type").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  read: boolean("read").notNull().default(false),
  relatedEntityId: varchar("related_entity_id"),
  relatedEntityType: text("related_entity_type"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const amlFlagTypeEnum = ["high_risk_country", "pep_flag", "large_deposit", "name_mismatch"] as const;
export type AmlFlagType = (typeof amlFlagTypeEnum)[number];

export const amlFlagStatusEnum = ["active", "cleared", "escalated"] as const;
export type AmlFlagStatus = (typeof amlFlagStatusEnum)[number];

export const eddStatusEnum = ["none", "EDD_REQUIRED", "EDD_IN_PROGRESS", "EDD_COMPLETE"] as const;
export type EddStatus = (typeof eddStatusEnum)[number];

export const amlFlags = pgTable("aml_flags", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  userId: varchar("user_id").notNull(),
  flagType: text("flag_type").notNull(),
  severity: text("severity").notNull().default("medium"),
  description: text("description").notNull(),
  details: jsonb("details"),
  status: text("status").notNull().default("active"),
  resolvedBy: varchar("resolved_by"),
  resolvedAt: text("resolved_at"),
  resolutionNotes: text("resolution_notes"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const legalDocumentTypeEnum = ["terms_of_service", "privacy_policy", "risk_disclosure"] as const;
export type LegalDocumentType = (typeof legalDocumentTypeEnum)[number];

export const legalDocProductTypeEnum = ["FUND", "SPV", "TRUST", "GENERAL"] as const;
export type LegalDocProductType = (typeof legalDocProductTypeEnum)[number];

export const legalDocuments = pgTable("legal_documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  version: integer("version").notNull().default(1),
  effectiveDate: text("effective_date").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  country: text("country"),
  productType: text("product_type").notNull().default("GENERAL"),
  jurisdictionCode: text("jurisdiction_code"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const legalAcceptances = pgTable("legal_acceptances", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  legalDocumentId: varchar("legal_document_id").notNull(),
  acceptedAt: text("accepted_at").notNull().default(sql`now()`),
  ipAddress: text("ip_address"),
});

export const walletTransactionTypeEnum = [
  "DEPOSIT", "WITHDRAW", "INVEST_RESERVE", "INVEST_CAPTURE", "REFUND",
  "DIVIDEND", "FEE", "FX_CONVERT", "TRADE_BUY", "TRADE_SELL", "CRYPTO_DEPOSIT", "EXIT_FEE",
  "CAPITAL_RETURN", "CAPITAL_GAIN"
] as const;
export type WalletTransactionType = (typeof walletTransactionTypeEnum)[number];

export const walletTransactionStatusEnum = ["PENDING", "COMPLETED", "FAILED", "CANCELLED"] as const;
export type WalletTransactionStatus = (typeof walletTransactionStatusEnum)[number];

export const walletCurrencyEnum = WALLET_CURRENCIES;
export type WalletCurrency = ConstWalletCurrency;

export const walletAccounts = pgTable("wallet_accounts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  userId: varchar("user_id").notNull(),
  currency: text("currency").notNull(),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const walletTransactions = pgTable("wallet_transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  walletAccountId: varchar("wallet_account_id").notNull(),
  type: text("type").notNull(),
  amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
  currency: text("currency").notNull(),
  status: text("status").notNull().default("PENDING"),
  referenceId: varchar("reference_id"),
  description: text("description"),
  metadata: jsonb("metadata"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const ledgerEntryDirectionEnum = ["DEBIT", "CREDIT"] as const;
export type LedgerEntryDirection = (typeof ledgerEntryDirectionEnum)[number];

export const ledgerEntryStatusEnum = ["POSTED", "PENDING", "REVERSED"] as const;
export type LedgerEntryStatus = (typeof ledgerEntryStatusEnum)[number];

export const ledgerEntryTypeEnum = [
  "DEPOSIT", "WITHDRAW", "INVEST_RESERVE", "INVEST_CAPTURE", "REFUND",
  "DIVIDEND", "FEE", "FX_DEBIT", "FX_CREDIT", "FX_SPREAD", "TRADE_BUY", "TRADE_SELL",
  "CRYPTO_DEPOSIT", "REVERSAL", "EXIT_FEE", "CAPITAL_RETURN", "CAPITAL_GAIN"
] as const;
export type LedgerEntryType = (typeof ledgerEntryTypeEnum)[number];

export const ledgerEntries = pgTable("ledger_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  ledgerTxId: varchar("ledger_tx_id").notNull(),
  walletAccountId: varchar("wallet_account_id").notNull(),
  currency: text("currency").notNull(),
  amount: decimal("amount", { precision: 18, scale: 6 }).notNull(),
  direction: text("direction").notNull(),
  status: text("status").notNull().default("POSTED"),
  entryType: text("entry_type").notNull(),
  referenceId: varchar("reference_id"),
  reversalOfEntryId: varchar("reversal_of_entry_id"),
  description: text("description"),
  metadata: jsonb("metadata"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertLedgerEntrySchema = createInsertSchema(ledgerEntries).omit({ id: true, createdAt: true });
export type InsertLedgerEntry = z.infer<typeof insertLedgerEntrySchema>;
export type LedgerEntry = typeof ledgerEntries.$inferSelect;

export const bankAccountStatusEnum = ["pending", "verified", "rejected"] as const;
export type BankAccountStatus = (typeof bankAccountStatusEnum)[number];

export const bankAccountCountryEnum = BANK_ACCOUNT_COUNTRIES;
export type BankAccountCountry = ConstBankAccountCountry;

export const bankAccounts = pgTable("bank_accounts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  userId: varchar("user_id").notNull(),
  country: text("country").notNull(),
  label: text("label").notNull(),
  accountHolderName: text("account_holder_name").notNull(),
  iban: text("iban"),
  bankName: text("bank_name").notNull(),
  branchCode: text("branch_code"),
  accountNumber: text("account_number"),
  swiftCode: text("swift_code"),
  currency: text("currency").notNull(),
  status: text("status").notNull().default("pending"),
  verifiedBy: varchar("verified_by"),
  verifiedAt: text("verified_at"),
  verificationNotes: text("verification_notes"),
  isDefault: boolean("is_default").notNull().default(false),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const withdrawalRequestStatusEnum = ["REQUESTED", "APPROVED", "DECLINED", "PAID"] as const;
export type WithdrawalRequestStatus = (typeof withdrawalRequestStatusEnum)[number];

export const withdrawalReasonEnum = ["PROFIT", "CAPITAL"] as const;
export type WithdrawalReason = (typeof withdrawalReasonEnum)[number];

export const withdrawalRequests = pgTable("withdrawal_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  userId: varchar("user_id").notNull(),
  walletAccountId: varchar("wallet_account_id").notNull(),
  bankAccountId: varchar("bank_account_id").notNull(),
  amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
  currency: text("currency").notNull(),
  reason: text("reason").notNull().default("PROFIT"),
  fee: decimal("fee", { precision: 18, scale: 2 }).notNull().default("0"),
  netAmount: decimal("net_amount", { precision: 18, scale: 2 }).notNull(),
  status: text("status").notNull().default("REQUESTED"),
  requestedAt: text("requested_at").notNull().default(sql`now()`),
  reviewedBy: varchar("reviewed_by"),
  reviewedAt: text("reviewed_at"),
  reviewNotes: text("review_notes"),
  payoutReference: text("payout_reference"),
  paidAt: text("paid_at"),
  paidBy: varchar("paid_by"),
});

export const distributionSnapshots = pgTable("distribution_snapshots", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id").notNull(),
  tokenId: varchar("token_id").notNull(),
  recordDate: text("record_date").notNull(),
  totalSupply: decimal("total_supply", { precision: 18, scale: 6 }).notNull(),
  holderCount: integer("holder_count").notNull(),
  holdings: jsonb("holdings").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  createdBy: varchar("created_by").notNull(),
});

export const insertDistributionSnapshotSchema = createInsertSchema(distributionSnapshots).omit({ id: true, createdAt: true });
export type InsertDistributionSnapshot = z.infer<typeof insertDistributionSnapshotSchema>;
export type DistributionSnapshot = typeof distributionSnapshots.$inferSelect;

export const distributions = pgTable("distributions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id").notNull(),
  month: text("month"),
  amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
  netAmount: decimal("net_amount", { precision: 18, scale: 2 }),
  currency: text("currency").notNull().default("AED"),
  distributionDate: text("distribution_date").notNull(),
  recordDate: text("record_date"),
  snapshotId: varchar("snapshot_id"),
  status: text("status").notNull().default("scheduled"),
  perTokenAmount: decimal("per_token_amount", { precision: 18, scale: 6 }),
  recipientCount: integer("recipient_count"),
  waterfallCalculationId: varchar("waterfall_calculation_id"),
  breakdown: jsonb("breakdown"),
  createdBy: varchar("created_by"),
});

export const payoutStatusEnum = ["PENDING", "PAID", "FAILED"] as const;
export type PayoutStatus = (typeof payoutStatusEnum)[number];

export const distributionPayouts = pgTable("distribution_payouts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  distributionId: varchar("distribution_id").notNull(),
  userId: varchar("user_id").notNull(),
  tokenId: varchar("token_id").notNull(),
  holdingBalance: decimal("holding_balance", { precision: 18, scale: 6 }).notNull(),
  holdingPercent: decimal("holding_percent", { precision: 18, scale: 6 }).notNull(),
  payoutAmount: decimal("payout_amount", { precision: 18, scale: 2 }).notNull(),
  payoutCurrency: text("payout_currency").notNull(),
  status: text("status").notNull().default("PENDING"),
  walletAccountId: varchar("wallet_account_id").notNull(),
  walletTransactionId: varchar("wallet_transaction_id"),
  autoConverted: boolean("auto_converted").notNull().default(false),
  convertedAmount: decimal("converted_amount", { precision: 18, scale: 2 }),
  convertedCurrency: text("converted_currency"),
  conversionRate: decimal("conversion_rate", { precision: 18, scale: 6 }),
  convertedWalletAccountId: varchar("converted_wallet_account_id"),
  convertedWalletTransactionId: varchar("converted_wallet_transaction_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertDistributionPayoutSchema = createInsertSchema(distributionPayouts).omit({ id: true, createdAt: true });
export type InsertDistributionPayout = z.infer<typeof insertDistributionPayoutSchema>;
export type DistributionPayout = typeof distributionPayouts.$inferSelect;

export const RENTAL_EXPENSE_CATEGORIES = [
  "vacancy_adjustment",
  "late_payment",
  "maintenance",
  "management_fee",
  "insurance",
  "property_tax",
  "utility_reserve",
  "other",
] as const;
export type RentalExpenseCategory = typeof RENTAL_EXPENSE_CATEGORIES[number];

export const rentCollections = pgTable("rent_collections", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id").notNull(),
  period: text("period").notNull(),
  grossRent: decimal("gross_rent", { precision: 18, scale: 2 }).notNull(),
  occupancyRate: decimal("occupancy_rate", { precision: 5, scale: 2 }).default("100.00"),
  latePaymentPenalty: decimal("late_payment_penalty", { precision: 18, scale: 2 }).default("0"),
  vacancyAdjustment: decimal("vacancy_adjustment", { precision: 18, scale: 2 }).default("0"),
  effectiveRent: decimal("effective_rent", { precision: 18, scale: 2 }),
  currency: text("currency").notNull(),
  baseCurrencyAmount: decimal("base_currency_amount", { precision: 18, scale: 2 }),
  baseCurrency: text("base_currency"),
  fxRate: decimal("fx_rate", { precision: 18, scale: 6 }),
  receivedDate: text("received_date").notNull(),
  notes: text("notes"),
  postedBy: varchar("posted_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertRentCollectionSchema = createInsertSchema(rentCollections).omit({ id: true, createdAt: true });
export type InsertRentCollection = z.infer<typeof insertRentCollectionSchema>;
export type RentCollection = typeof rentCollections.$inferSelect;

export const operatingExpenses = pgTable("operating_expenses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id").notNull(),
  period: text("period").notNull(),
  category: text("category").notNull(),
  description: text("description"),
  amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
  currency: text("currency").notNull(),
  baseCurrencyAmount: decimal("base_currency_amount", { precision: 18, scale: 2 }),
  baseCurrency: text("base_currency"),
  fxRate: decimal("fx_rate", { precision: 18, scale: 6 }),
  postedBy: varchar("posted_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertOperatingExpenseSchema = createInsertSchema(operatingExpenses).omit({ id: true, createdAt: true });
export type InsertOperatingExpense = z.infer<typeof insertOperatingExpenseSchema>;
export type OperatingExpense = typeof operatingExpenses.$inferSelect;

export const milestoneStatusEnum = ["planned", "in_progress", "completed", "delayed", "cancelled"] as const;
export type MilestoneStatus = typeof milestoneStatusEnum[number];

export const propertyMilestones = pgTable("property_milestones", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  status: text("status").notNull().default("planned"),
  targetDate: text("target_date"),
  completionDate: text("completion_date"),
  progressPercent: integer("progress_percent").notNull().default(0),
  sortOrder: integer("sort_order").notNull().default(0),
  notes: text("notes"),
  createdBy: varchar("created_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertPropertyMilestoneSchema = createInsertSchema(propertyMilestones).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertPropertyMilestone = z.infer<typeof insertPropertyMilestoneSchema>;
export type PropertyMilestone = typeof propertyMilestones.$inferSelect;

export const contractStatusEnum = ["draft", "active", "expired", "terminated", "renewed"] as const;
export type ContractStatus = typeof contractStatusEnum[number];

export const rentalContracts = pgTable("rental_contracts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id").notNull(),
  tenantName: text("tenant_name").notNull(),
  tenantEmail: text("tenant_email"),
  tenantPhone: text("tenant_phone"),
  unitIdentifier: text("unit_identifier"),
  startDate: text("start_date").notNull(),
  endDate: text("end_date").notNull(),
  monthlyRent: decimal("monthly_rent", { precision: 18, scale: 2 }).notNull(),
  currency: text("currency").notNull().default("AED"),
  securityDeposit: decimal("security_deposit", { precision: 18, scale: 2 }),
  status: text("status").notNull().default("draft"),
  contractRef: text("contract_ref"),
  notes: text("notes"),
  createdBy: varchar("created_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertRentalContractSchema = createInsertSchema(rentalContracts).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertRentalContract = z.infer<typeof insertRentalContractSchema>;
export type RentalContract = typeof rentalContracts.$inferSelect;

export const propertyManagers = pgTable("property_managers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  name: text("name").notNull(),
  company: text("company"),
  email: text("email"),
  phone: text("phone"),
  licenseNumber: text("license_number"),
  country: text("country").notNull().default("AE"),
  isActive: boolean("is_active").notNull().default(true),
  assignedAssetIds: text("assigned_asset_ids").array().default(sql`'{}'::text[]`),
  notes: text("notes"),
  createdBy: varchar("created_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertPropertyManagerSchema = createInsertSchema(propertyManagers).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertPropertyManager = z.infer<typeof insertPropertyManagerSchema>;
export type PropertyManager = typeof propertyManagers.$inferSelect;

export const propertyExpenseCategories = pgTable("property_expense_categories", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  name: text("name").notNull(),
  description: text("description"),
  isDefault: boolean("is_default").notNull().default(false),
  createdBy: varchar("created_by"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPropertyExpenseCategorySchema = createInsertSchema(propertyExpenseCategories).omit({ id: true, createdAt: true });
export type InsertPropertyExpenseCategory = z.infer<typeof insertPropertyExpenseCategorySchema>;
export type PropertyExpenseCategory = typeof propertyExpenseCategories.$inferSelect;

export const waterfallCalculations = pgTable("waterfall_calculations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id").notNull(),
  period: text("period").notNull(),
  baseCurrency: text("base_currency").notNull(),
  grossRent: decimal("gross_rent", { precision: 18, scale: 2 }).notNull(),
  totalExpenses: decimal("total_expenses", { precision: 18, scale: 2 }).notNull(),
  netOperatingIncome: decimal("net_operating_income", { precision: 18, scale: 2 }).notNull(),
  reservePercent: decimal("reserve_percent", { precision: 8, scale: 4 }).notNull(),
  reserveAmount: decimal("reserve_amount", { precision: 18, scale: 2 }).notNull(),
  propertyMgmtFeePercent: decimal("property_mgmt_fee_percent", { precision: 8, scale: 4 }).notNull(),
  propertyMgmtFeeAmount: decimal("property_mgmt_fee_amount", { precision: 18, scale: 2 }).notNull(),
  platformFeePercent: decimal("platform_fee_percent", { precision: 8, scale: 4 }).notNull(),
  platformFeeAmount: decimal("platform_fee_amount", { precision: 18, scale: 2 }).notNull(),
  trusteeFeePercent: decimal("trustee_fee_percent", { precision: 8, scale: 4 }).notNull(),
  trusteeFeeAmount: decimal("trustee_fee_amount", { precision: 18, scale: 2 }).notNull(),
  totalFees: decimal("total_fees", { precision: 18, scale: 2 }).notNull(),
  netDistributable: decimal("net_distributable", { precision: 18, scale: 2 }).notNull(),
  breakdown: jsonb("breakdown").notNull(),
  calculatedBy: varchar("calculated_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertWaterfallCalculationSchema = createInsertSchema(waterfallCalculations).omit({ id: true, createdAt: true });
export type InsertWaterfallCalculation = z.infer<typeof insertWaterfallCalculationSchema>;
export type WaterfallCalculation = typeof waterfallCalculations.$inferSelect;

export const reserveFundEntries = pgTable("reserve_fund_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id").notNull(),
  period: text("period").notNull(),
  entryType: text("entry_type").notNull(),
  amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
  currency: text("currency").notNull(),
  waterfallCalculationId: varchar("waterfall_calculation_id"),
  description: text("description"),
  postedBy: varchar("posted_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertReserveFundEntrySchema = createInsertSchema(reserveFundEntries).omit({ id: true, createdAt: true });
export type InsertReserveFundEntry = z.infer<typeof insertReserveFundEntrySchema>;
export type ReserveFundEntry = typeof reserveFundEntries.$inferSelect;

export const feeTypeEnum = [
  "withdrawal", "investment", "trade", "fx", "transfer", "redemption",
  "acquisition", "management", "rental_processing",
  "exit_trade_buyer", "exit_trade_seller",
  "crypto_deposit", "issuer_onboarding", "property_sale",
  "performance_fee", "valuation_uplift",
  "premium_membership",
] as const;

export const FEE_CATEGORY_MAP: Record<string, { category: string; label: string; legalLabel: string; description: string }> = {
  acquisition: { category: "asset_lifecycle", label: "Acquisition / Structuring", legalLabel: "Transaction Structuring Fee", description: "One-time fee charged when a property raise closes, covering legal structuring, SPV setup, and platform facilitation." },
  management: { category: "asset_lifecycle", label: "Annual Management", legalLabel: "Annual Asset Management Fee", description: "Recurring annual fee on assets under management covering property oversight, compliance reporting, and platform maintenance." },
  rental_processing: { category: "asset_lifecycle", label: "Rental Processing", legalLabel: "Distribution Processing Fee", description: "Fee applied to rental income distributions covering calculation, multi-currency conversion, and disbursement processing." },
  property_sale: { category: "asset_lifecycle", label: "Property Sale / Disposal", legalLabel: "Disposal Administration Fee", description: "Fee applied on property sale proceeds covering settlement, capital gain calculation, and investor payout administration." },
  performance_fee: { category: "asset_lifecycle", label: "Performance Fee", legalLabel: "Performance Incentive Fee", description: "Charged on excess yield above the target hurdle rate. Aligns platform incentives with investor returns — only earned when performance exceeds expectations." },
  valuation_uplift: { category: "asset_lifecycle", label: "Valuation Uplift Success Fee", legalLabel: "Capital Appreciation Success Fee", description: "Success fee on capital gains at property sale. Charged as a percentage of the gain (sale price minus original cost), rewarding value creation." },
  exit_trade_buyer: { category: "secondary_market", label: "Exit Trade (Buyer)", legalLabel: "Secondary Market Purchase Fee", description: "Fee charged to the buyer on secondary market token trades during quarterly exit windows." },
  exit_trade_seller: { category: "secondary_market", label: "Exit Trade (Seller)", legalLabel: "Secondary Market Redemption Fee", description: "Fee charged to the seller on secondary market token trades, deducted from sale proceeds." },
  fx: { category: "fx_payment", label: "FX Conversion", legalLabel: "Currency Conversion Spread", description: "Spread applied on foreign exchange conversions between supported currencies (PKR, AED, GBP, USD, QAR, USDT, USDC)." },
  crypto_deposit: { category: "fx_payment", label: "Crypto Deposit", legalLabel: "Digital Asset Deposit Fee", description: "Optional fee on stablecoin deposits (USDT/USDC) covering blockchain verification and AML screening." },
  withdrawal: { category: "fx_payment", label: "Withdrawal", legalLabel: "Withdrawal Processing Fee", description: "Fee applied to fiat or crypto withdrawals covering bank transfer processing and compliance checks." },
  investment: { category: "core", label: "Investment", legalLabel: "Investment Processing Fee", description: "Fee applied when committing capital to a property offering, covering allocation and compliance processing." },
  trade: { category: "core", label: "Trade", legalLabel: "Trade Execution Fee", description: "General trading fee applied to token buy/sell transactions outside of exit windows." },
  transfer: { category: "core", label: "Transfer", legalLabel: "Token Transfer Fee", description: "Fee for peer-to-peer token transfers between investors, covering transfer restriction checks and ledger updates." },
  redemption: { category: "core", label: "Redemption", legalLabel: "Redemption Processing Fee", description: "Fee charged when tokens are redeemed for underlying value, covering settlement and payout processing." },
  issuer_onboarding: { category: "core", label: "Institutional Onboarding", legalLabel: "Institutional Onboarding Fee", description: "Fixed fee charged to asset issuers covering due diligence, tokenization setup, legal onboarding, and platform listing." },
  premium_membership: { category: "core", label: "Premium Membership", legalLabel: "Premium Investor Membership Fee", description: "Annual subscription fee for premium investor tier offering early access, lower exit fees, higher investment caps, detailed analytics, and dedicated relationship management." },
};

export const FEE_CATEGORIES = [
  { key: "asset_lifecycle", label: "Asset Lifecycle", description: "Fees across the property lifecycle: acquisition, management, rental, and sale" },
  { key: "secondary_market", label: "Secondary Market", description: "Trading fees on quarterly exit windows" },
  { key: "fx_payment", label: "FX & Payments", description: "Currency conversion spreads, deposit and withdrawal fees" },
  { key: "core", label: "Core Platform", description: "Investment, trading, transfer, redemption, and onboarding fees" },
] as const;
export type FeeType = (typeof feeTypeEnum)[number];

export const feeMethodEnum = ["percentage", "flat", "tiered"] as const;
export type FeeMethod = (typeof feeMethodEnum)[number];

export const feeSchedules = pgTable("fee_schedules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  vehicleId: varchar("vehicle_id"),
  feeType: text("fee_type").notNull(),
  currency: text("currency").notNull().default("*"),
  method: text("method").notNull().default("percentage"),
  rate: decimal("rate", { precision: 10, scale: 6 }).notNull().default("0"),
  flatAmount: decimal("flat_amount", { precision: 18, scale: 2 }).notNull().default("0"),
  tiers: jsonb("tiers"),
  minFee: decimal("min_fee", { precision: 18, scale: 2 }),
  maxFee: decimal("max_fee", { precision: 18, scale: 2 }),
  version: integer("version").notNull().default(1),
  isActive: boolean("is_active").notNull().default(true),
  effectiveFrom: timestamp("effective_from").notNull().default(sql`now()`),
  effectiveTo: timestamp("effective_to"),
  createdBy: varchar("created_by"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  notes: text("notes"),
});

export const appliedFees = pgTable("applied_fees", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  feeScheduleId: varchar("fee_schedule_id").notNull(),
  feeScheduleVersion: integer("fee_schedule_version").notNull(),
  feeType: text("fee_type").notNull(),
  vehicleId: varchar("vehicle_id"),
  userId: varchar("user_id"),
  currency: text("currency").notNull(),
  grossAmount: decimal("gross_amount", { precision: 18, scale: 2 }).notNull(),
  feeAmount: decimal("fee_amount", { precision: 18, scale: 2 }).notNull(),
  netAmount: decimal("net_amount", { precision: 18, scale: 2 }).notNull(),
  method: text("method").notNull(),
  rate: decimal("rate", { precision: 10, scale: 6 }).notNull(),
  referenceEntityType: text("reference_entity_type"),
  referenceEntityId: varchar("reference_entity_id"),
  description: text("description"),
  metadata: jsonb("metadata"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertAppliedFeeSchema = createInsertSchema(appliedFees).omit({ id: true, createdAt: true });
export type InsertAppliedFee = z.infer<typeof insertAppliedFeeSchema>;
export type AppliedFee = typeof appliedFees.$inferSelect;

export const paymentIntentStatusEnum = ["CREATED", "PENDING", "CONFIRMED", "FAILED", "REVERSED"] as const;
export type PaymentIntentStatus = (typeof paymentIntentStatusEnum)[number];

export const paymentMethodEnum = ["bank_transfer", "card", "crypto", "manual", "mobile_wallet", "remittance", "instant_transfer", "international_wire"] as const;
export type PaymentMethod = (typeof paymentMethodEnum)[number];

export const paymentIntents = pgTable("payment_intents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  userId: varchar("user_id").notNull(),
  walletAccountId: varchar("wallet_account_id"),
  amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
  currency: text("currency").notNull(),
  countryCode: text("country_code"),
  referenceCode: text("reference_code"),
  status: text("status").notNull().default("CREATED"),
  paymentMethod: text("payment_method").notNull().default("bank_transfer"),
  provider: text("provider").notNull().default("manual"),
  providerIntentId: text("provider_intent_id"),
  providerSessionUrl: text("provider_session_url"),
  providerResponse: jsonb("provider_response"),
  fee: decimal("fee", { precision: 18, scale: 2 }).notNull().default("0"),
  netAmount: decimal("net_amount", { precision: 18, scale: 2 }).notNull(),
  reference: text("reference"),
  reconciliationId: text("reconciliation_id"),
  reconciledAt: text("reconciled_at"),
  reconciledBy: varchar("reconciled_by"),
  metadata: jsonb("metadata"),
  proofDocumentUrl: text("proof_document_url"),
  failureReason: text("failure_reason"),
  ledgerTxId: varchar("ledger_tx_id"),
  reversalLedgerTxId: varchar("reversal_ledger_tx_id"),
  reversedAt: text("reversed_at"),
  reversalReason: text("reversal_reason"),
  expiresAt: text("expires_at"),
  confirmedAt: text("confirmed_at"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertPaymentIntentSchema = createInsertSchema(paymentIntents).omit({
  id: true, status: true, providerIntentId: true, providerSessionUrl: true, providerResponse: true,
  reconciliationId: true, reconciledAt: true, reconciledBy: true, failureReason: true, confirmedAt: true, createdAt: true, referenceCode: true,
  ledgerTxId: true, reversalLedgerTxId: true, reversedAt: true, reversalReason: true,
});

export const createPaymentIntentSchema = z.object({
  amount: z.number().positive("Amount must be positive"),
  currency: walletCurrencySchema,
  paymentMethod: z.enum(paymentMethodEnum).default("bank_transfer"),
  provider: z.string().optional(),
  reference: z.string().optional().nullable(),
  metadata: z.record(z.any()).optional().nullable(),
});
export type CreatePaymentIntent = z.infer<typeof createPaymentIntentSchema>;

export type PaymentIntent = typeof paymentIntents.$inferSelect;
export type InsertPaymentIntent = z.infer<typeof insertPaymentIntentSchema>;

export const insertFeeScheduleSchema = createInsertSchema(feeSchedules).omit({ id: true, version: true, isActive: true, createdAt: true });

export const createFeeScheduleSchema = z.object({
  vehicleId: z.string().optional().nullable(),
  feeType: z.enum(feeTypeEnum),
  currency: z.string().default("*"),
  method: z.enum(feeMethodEnum),
  rate: z.string().optional().default("0"),
  flatAmount: z.string().optional().default("0"),
  tiers: z.array(z.object({
    minAmount: z.number(),
    maxAmount: z.number().nullable(),
    rate: z.number(),
  })).optional().nullable(),
  minFee: z.string().optional().nullable(),
  maxFee: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
});
export type CreateFeeSchedule = z.infer<typeof createFeeScheduleSchema>;

export type FeeSchedule = typeof feeSchedules.$inferSelect;
export type InsertFeeSchedule = z.infer<typeof insertFeeScheduleSchema>;

export const insertUserSchema = createInsertSchema(users).omit({ id: true });

export const insertImpersonationLogSchema = createInsertSchema(impersonationLogs).omit({ id: true, startedAt: true, endedAt: true });
export type InsertImpersonationLog = z.infer<typeof insertImpersonationLogSchema>;
export type ImpersonationLog = typeof impersonationLogs.$inferSelect;

export const updateProfileSchema = z.object({
  fullName: z.string().min(1).max(100).optional(),
  phone: z.string().max(20).nullable().optional(),
  nationality: z.string().max(100).nullable().optional(),
  address: z.string().max(500).nullable().optional(),
  timezone: z.string().max(100).nullable().optional(),
});
export type UpdateProfile = z.infer<typeof updateProfileSchema>;

export const notificationPreferencesSchema = z.object({
  email: z.boolean(),
  sms: z.boolean(),
  push: z.boolean(),
  marketing: z.boolean(),
  security: z.boolean(),
  transactions: z.boolean(),
  distributions: z.boolean(),
  autoConvertDistributions: z.boolean().optional().default(false),
});
export type NotificationPreferences = z.infer<typeof notificationPreferencesSchema>;

export const insertKycProfileSchema = createInsertSchema(kycProfiles).omit({ id: true, status: true, riskScore: true, submittedAt: true, reviewedAt: true, reviewNotes: true });
export const submitKycSchema = z.object({
  legalName: z.string().min(2, "Legal name is required").max(200),
  dob: z.string().min(1, "Date of birth is required"),
  address: z.string().min(5, "Address is required").max(500),
  idType: z.enum(["passport", "national_id", "drivers_license", "emirates_id"]),
  idNumber: z.string().min(3, "ID number is required").max(50),
  emiratesIdFlag: z.boolean().default(false),
  sourceOfWealth: z.string().min(3, "Source of wealth is required").max(500),
  sourceOfFunds: z.string().min(3, "Source of funds is required").max(500),
  pepFlag: z.boolean().default(false),
});
export type SubmitKyc = z.infer<typeof submitKycSchema>;

export const insertDocumentSchema = createInsertSchema(documents).omit({ id: true, createdAt: true });
export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, read: true, createdAt: true });

export const insertAmlFlagSchema = createInsertSchema(amlFlags).omit({ id: true, resolvedBy: true, resolvedAt: true, resolutionNotes: true, createdAt: true });
export const insertLegalDocumentSchema = createInsertSchema(legalDocuments).omit({ id: true, createdAt: true });
export const insertLegalAcceptanceSchema = createInsertSchema(legalAcceptances).omit({ id: true, acceptedAt: true });
export const insertWalletAccountSchema = createInsertSchema(walletAccounts).omit({ id: true, createdAt: true });
export const insertWalletTransactionSchema = createInsertSchema(walletTransactions).omit({ id: true, createdAt: true });
export const insertBankAccountSchema = createInsertSchema(bankAccounts).omit({ id: true, status: true, verifiedBy: true, verifiedAt: true, verificationNotes: true, createdAt: true });
export const insertWithdrawalRequestSchema = createInsertSchema(withdrawalRequests).omit({ id: true, status: true, requestedAt: true, reviewedBy: true, reviewedAt: true, reviewNotes: true, payoutReference: true, paidAt: true, paidBy: true });

export const addBankAccountSchema = z.object({
  country: bankAccountCountrySchema,
  label: z.string().min(1, "Label is required").max(100),
  accountHolderName: z.string().min(2, "Account holder name is required").max(200),
  iban: z.string().max(34).nullable().optional(),
  bankName: z.string().min(1, "Bank name is required").max(200),
  branchCode: z.string().max(20).nullable().optional(),
  accountNumber: z.string().max(30).nullable().optional(),
  swiftCode: z.string().max(11).nullable().optional(),
  currency: walletCurrencySchema,
  isDefault: z.boolean().default(false),
});
export type AddBankAccount = z.infer<typeof addBankAccountSchema>;

export const insertInvestmentVehicleSchema = createInsertSchema(investmentVehicles).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertInvestmentVehicle = z.infer<typeof insertInvestmentVehicleSchema>;
export type InvestmentVehicle = typeof investmentVehicles.$inferSelect;

export const createVehicleSchema = z.object({
  name: z.string().min(2, "Name is required"),
  type: z.enum(vehicleTypeEnum, { required_error: "Type is required" }),
  jurisdictionCountry: z.string().min(2, "Jurisdiction country is required"),
  baseCurrency: z.string().min(1, "Base currency is required"),
  bankAccountConfigId: z.string().optional(),
  platformFee: z.string().optional(),
  trusteeFee: z.string().optional(),
  propertyMgmtFee: z.string().optional(),
  legalFee: z.string().optional(),
  reservePercent: z.string().optional(),
  description: z.string().optional(),
  targetAum: z.string().optional(),
  currentNav: z.string().optional(),
  strategy: z.string().optional(),
  fundManager: z.string().optional(),
  inceptionDate: z.string().optional(),
  openEnded: z.boolean().optional(),
  regNumber: z.string().optional(),
  registeredAgent: z.string().optional(),
  incorporationDate: z.string().optional(),
});
export type CreateVehicle = z.infer<typeof createVehicleSchema>;

export const updateVehicleSchema = createVehicleSchema.partial();
export type UpdateVehicle = z.infer<typeof updateVehicleSchema>;

export const vehicleStatusTransitionSchema = z.object({
  status: z.enum(vehicleStatusEnum),
});
export type VehicleStatusTransition = z.infer<typeof vehicleStatusTransitionSchema>;

export const attachAssetToVehicleSchema = z.object({
  assetId: z.string().min(1, "Asset ID is required"),
});
export type AttachAssetToVehicle = z.infer<typeof attachAssetToVehicleSchema>;

export const insertAssetSchema = createInsertSchema(assets).omit({ id: true });

export const issuerSubmitAssetSchema = z.object({
  name: z.string().min(2, "Asset name is required"),
  symbol: z.string().min(1, "Symbol is required").max(10),
  assetType: z.string().min(1, "Asset type is required"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  totalSupply: z.string().min(1, "Total supply is required"),
  pricePerToken: z.string().min(1, "Price per token is required"),
  baseCurrency: z.string().min(1, "Base currency is required"),
  country: z.string().min(1, "Country is required"),
  location: z.string().optional(),
  propertyType: z.string().optional(),
  annualYield: z.string().optional(),
  legalStructure: z.string().optional(),
  regulatoryBody: z.string().optional(),
  tokenDecimals: z.number().int().min(0).max(8).optional().default(2),
  minInvestment: z.string().optional(),
  maxOwnershipPercent: z.string().optional().refine(
    (val) => !val || (parseFloat(val) > 0 && parseFloat(val) <= 100),
    { message: "Max ownership must be between 0.01 and 100" }
  ),
  jurisdictionChecklist: z.record(z.string(), z.boolean()).optional(),
  eligibleCountries: z.array(z.string()).optional(),
  restrictedCountries: z.array(z.string()).optional(),
});
export type IssuerSubmitAsset = z.infer<typeof issuerSubmitAssetSchema>;

export const adminReviewAssetSchema = z.object({
  submissionStatus: z.enum(["approved", "rejected", "changes_requested"]),
  adminReviewNotes: z.string().optional(),
});
export type AdminReviewAsset = z.infer<typeof adminReviewAssetSchema>;

export const insertRoundSchema = createInsertSchema(rounds).omit({ id: true });
export const insertPortfolioItemSchema = createInsertSchema(portfolioItems).omit({ id: true });
export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true });
export const insertDistributionSchema = createInsertSchema(distributions).omit({ id: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Asset = typeof assets.$inferSelect;
export type InsertAsset = z.infer<typeof insertAssetSchema>;
export type Round = typeof rounds.$inferSelect;
export type InsertRound = z.infer<typeof insertRoundSchema>;
export type PortfolioItem = typeof portfolioItems.$inferSelect;
export type InsertPortfolioItem = z.infer<typeof insertPortfolioItemSchema>;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Distribution = typeof distributions.$inferSelect;
export type InsertDistribution = z.infer<typeof insertDistributionSchema>;
export type KycProfile = typeof kycProfiles.$inferSelect;
export type InsertKycProfile = z.infer<typeof insertKycProfileSchema>;
export type Document = typeof documents.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type AmlFlag = typeof amlFlags.$inferSelect;
export type InsertAmlFlag = z.infer<typeof insertAmlFlagSchema>;
export type LegalDocument = typeof legalDocuments.$inferSelect;
export type InsertLegalDocument = z.infer<typeof insertLegalDocumentSchema>;
export type LegalAcceptance = typeof legalAcceptances.$inferSelect;
export type InsertLegalAcceptance = z.infer<typeof insertLegalAcceptanceSchema>;
export type WalletAccount = typeof walletAccounts.$inferSelect;
export type InsertWalletAccount = z.infer<typeof insertWalletAccountSchema>;
export type WalletTransaction = typeof walletTransactions.$inferSelect;
export type InsertWalletTransaction = z.infer<typeof insertWalletTransactionSchema>;
export type BankAccount = typeof bankAccounts.$inferSelect;
export type InsertBankAccount = z.infer<typeof insertBankAccountSchema>;
export type WithdrawalRequest = typeof withdrawalRequests.$inferSelect;
export type InsertWithdrawalRequest = z.infer<typeof insertWithdrawalRequestSchema>;

export const LIQUIDITY_RULES = {
  profitLockDays: 30,
  capitalLockDays: 90,
} as const;

export const requestWithdrawalSchema = z.object({
  bankAccountId: z.string().min(1, "Bank account is required"),
  amount: z.number().positive("Amount must be positive"),
  currency: walletCurrencySchema,
  reason: z.enum(withdrawalReasonEnum, { required_error: "Withdrawal reason is required" }),
});

export const fxRates = pgTable("fx_rates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fromCurrency: text("from_currency").notNull(),
  toCurrency: text("to_currency").notNull(),
  rate: decimal("rate", { precision: 18, scale: 8 }).notNull(),
  spread: decimal("spread", { precision: 10, scale: 6 }).notNull().default("0"),
  provider: text("provider").notNull().default("manual"),
  sourceLabel: text("source_label").notNull().default("manual"),
  fetchedAt: timestamp("fetched_at").notNull().default(sql`now()`),
  isActive: boolean("is_active").notNull().default(true),
  effectiveFrom: timestamp("effective_from").notNull().default(sql`now()`),
  effectiveTo: timestamp("effective_to"),
  createdBy: varchar("created_by"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

export const insertFxRateSchema = createInsertSchema(fxRates).omit({ id: true, createdAt: true, updatedAt: true });
export type FxRate = typeof fxRates.$inferSelect;
export type InsertFxRate = z.infer<typeof insertFxRateSchema>;

export const createFxRateSchema = z.object({
  fromCurrency: walletCurrencySchema,
  toCurrency: walletCurrencySchema,
  rate: z.string().refine(v => parseFloat(v) > 0, "Rate must be positive"),
  spread: z.string().optional().default("0"),
  provider: z.string().optional().default("manual"),
  sourceLabel: z.string().optional().default("manual"),
});

export const fxQuotes = pgTable("fx_quotes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fromCurrency: text("from_currency").notNull(),
  toCurrency: text("to_currency").notNull(),
  amountFrom: decimal("amount_from", { precision: 18, scale: 2 }).notNull(),
  rate: decimal("rate", { precision: 18, scale: 8 }).notNull(),
  spread: decimal("spread", { precision: 10, scale: 6 }).notNull().default("0"),
  fees: decimal("fees", { precision: 18, scale: 2 }).notNull().default("0"),
  feeRate: decimal("fee_rate", { precision: 10, scale: 6 }).notNull().default("0"),
  amountTo: decimal("amount_to", { precision: 18, scale: 2 }).notNull(),
  provider: text("provider").notNull().default("manual"),
  rateId: varchar("rate_id"),
  userId: varchar("user_id"),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  expiresAt: timestamp("expires_at").notNull(),
});

export const insertFxQuoteSchema = createInsertSchema(fxQuotes).omit({ id: true, createdAt: true });
export type FxQuote = typeof fxQuotes.$inferSelect;
export type InsertFxQuote = z.infer<typeof insertFxQuoteSchema>;

export const fxTransactions = pgTable("fx_transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  quoteId: varchar("quote_id"),
  fromCurrency: text("from_currency").notNull(),
  toCurrency: text("to_currency").notNull(),
  amountFrom: decimal("amount_from", { precision: 18, scale: 2 }).notNull(),
  amountTo: decimal("amount_to", { precision: 18, scale: 2 }).notNull(),
  rateUsed: decimal("rate_used", { precision: 18, scale: 8 }).notNull(),
  fees: decimal("fees", { precision: 18, scale: 2 }).notNull().default("0"),
  spread: decimal("spread", { precision: 10, scale: 6 }).notNull().default("0"),
  spreadAmount: decimal("spread_amount", { precision: 18, scale: 6 }).notNull().default("0"),
  status: text("status").notNull().default("pending"),
  referenceId: text("reference_id"),
  ledgerTxId: varchar("ledger_tx_id"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const insertFxTransactionSchema = createInsertSchema(fxTransactions).omit({ id: true, createdAt: true });
export type FxTransaction = typeof fxTransactions.$inferSelect;
export type InsertFxTransaction = z.infer<typeof insertFxTransactionSchema>;

export const residencyStatusEnum = ["citizen", "permanent_resident", "temporary_resident", "non_resident", "visa_holder"] as const;
export type ResidencyStatus = (typeof residencyStatusEnum)[number];

export const userCountryProfiles = pgTable("user_country_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  countryCode: text("country_code").notNull(),
  isPrimary: boolean("is_primary").notNull().default(false),
  residencyStatus: text("residency_status"),
  taxResidency: boolean("tax_residency").notNull().default(false),
  addressLine1: text("address_line1"),
  addressLine2: text("address_line2"),
  city: text("city"),
  stateProvince: text("state_province"),
  postalCode: text("postal_code"),
  phoneCountryCode: text("phone_country_code"),
  phoneNumber: text("phone_number"),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertUserCountryProfileSchema = createInsertSchema(userCountryProfiles).omit({ id: true, createdAt: true, updatedAt: true });
export type UserCountryProfile = typeof userCountryProfiles.$inferSelect;
export type InsertUserCountryProfile = z.infer<typeof insertUserCountryProfileSchema>;

export const upsertCountryProfileSchema = z.object({
  countryCode: countryCodeSchema,
  isPrimary: z.boolean().default(false),
  residencyStatus: z.enum(residencyStatusEnum).nullable().optional(),
  taxResidency: z.boolean().default(false),
  addressLine1: z.string().max(200).nullable().optional(),
  addressLine2: z.string().max(200).nullable().optional(),
  city: z.string().max(100).nullable().optional(),
  stateProvince: z.string().max(100).nullable().optional(),
  postalCode: z.string().max(20).nullable().optional(),
  phoneCountryCode: z.string().max(10).nullable().optional(),
  phoneNumber: z.string().max(20).nullable().optional(),
});
export type UpsertCountryProfile = z.infer<typeof upsertCountryProfileSchema>;

export const receivingBankAccounts = pgTable("receiving_bank_accounts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  countryCode: text("country_code").notNull(),
  currency: text("currency").notNull(),
  bankName: text("bank_name").notNull(),
  accountName: text("account_name").notNull(),
  iban: text("iban"),
  swiftCode: text("swift_code"),
  sortCode: text("sort_code"),
  routingNumber: text("routing_number"),
  branch: text("branch"),
  accountNumber: text("account_number"),
  isActive: boolean("is_active").notNull().default(true),
  notes: text("notes"),
  updatedBy: varchar("updated_by"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertReceivingBankAccountSchema = createInsertSchema(receivingBankAccounts).omit({
  id: true, isActive: true, createdAt: true,
});
export type InsertReceivingBankAccount = z.infer<typeof insertReceivingBankAccountSchema>;
export type ReceivingBankAccount = typeof receivingBankAccounts.$inferSelect;

export const createReceivingBankAccountSchema = z.object({
  countryCode: z.string().min(2).max(5),
  currency: z.string().min(3).max(3),
  bankName: z.string().min(1).max(200),
  accountName: z.string().min(1).max(200),
  iban: z.string().max(50).nullable().optional(),
  swiftCode: z.string().max(20).nullable().optional(),
  sortCode: z.string().max(20).nullable().optional(),
  routingNumber: z.string().max(20).nullable().optional(),
  branch: z.string().max(200).nullable().optional(),
  accountNumber: z.string().max(50).nullable().optional(),
  notes: z.string().max(500).nullable().optional(),
});
export type CreateReceivingBankAccount = z.infer<typeof createReceivingBankAccountSchema>;

export const marketplaceCountrySettings = pgTable("marketplace_country_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  countryCode: text("country_code").notNull().unique(),
  isVisible: boolean("is_visible").notNull().default(true),
  displayOrder: integer("display_order").notNull().default(0),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertMarketplaceCountrySettingSchema = createInsertSchema(marketplaceCountrySettings).omit({ id: true, updatedAt: true });
export type MarketplaceCountrySetting = typeof marketplaceCountrySettings.$inferSelect;
export type InsertMarketplaceCountrySetting = z.infer<typeof insertMarketplaceCountrySettingSchema>;

export const exitWindowStatusEnum = ["scheduled", "open", "closed", "cancelled"] as const;
export type ExitWindowStatus = (typeof exitWindowStatusEnum)[number];

export const exitWindows = pgTable("exit_windows", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id").notNull(),
  name: text("name").notNull(),
  opensAt: text("opens_at").notNull(),
  closesAt: text("closes_at").notNull(),
  status: text("status").notNull().default("scheduled"),
  exitFeePercent: decimal("exit_fee_percent", { precision: 5, scale: 2 }).notNull().default("1.50"),
  quarter: text("quarter"),
  eligibleJurisdictions: text("eligible_jurisdictions").array().default(sql`'{}'::text[]`),
  lockupDays: integer("lockup_days").default(0),
  cooldownHours: integer("cooldown_hours").default(0),
  maxParticipants: integer("max_participants"),
  minTradeAmount: decimal("min_trade_amount", { precision: 18, scale: 6 }),
  maxTradeAmount: decimal("max_trade_amount", { precision: 18, scale: 6 }),
  createdBy: varchar("created_by"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const exitWindowScheduleFrequencyEnum = ["quarterly", "monthly", "semi_annual", "annual", "custom"] as const;
export type ExitWindowScheduleFrequency = (typeof exitWindowScheduleFrequencyEnum)[number];

export const exitWindowSchedules = pgTable("exit_window_schedules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id").notNull(),
  frequency: text("frequency").notNull().default("quarterly"),
  windowDurationDays: integer("window_duration_days").notNull().default(14),
  exitFeePercent: decimal("exit_fee_percent", { precision: 5, scale: 2 }).notNull().default("1.50"),
  lockupDays: integer("lockup_days").default(0),
  cooldownHours: integer("cooldown_hours").default(0),
  maxParticipants: integer("max_participants"),
  minTradeAmount: decimal("min_trade_amount", { precision: 18, scale: 6 }),
  maxTradeAmount: decimal("max_trade_amount", { precision: 18, scale: 6 }),
  eligibleJurisdictions: text("eligible_jurisdictions").array().default(sql`'{}'::text[]`),
  customIntervalDays: integer("custom_interval_days"),
  autoGenerate: boolean("auto_generate").notNull().default(true),
  isActive: boolean("is_active").notNull().default(true),
  createdBy: varchar("created_by"),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertExitWindowScheduleSchema = createInsertSchema(exitWindowSchedules).omit({ id: true, createdAt: true, updatedAt: true });
export type ExitWindowSchedule = typeof exitWindowSchedules.$inferSelect;
export type InsertExitWindowSchedule = z.infer<typeof insertExitWindowScheduleSchema>;

export const createExitWindowScheduleSchema = z.object({
  assetId: z.string().min(1, "Asset is required"),
  frequency: z.enum(exitWindowScheduleFrequencyEnum).default("quarterly"),
  windowDurationDays: z.number().int().min(1).max(90).default(14),
  exitFeePercent: z.number().min(0).max(100).default(1.5),
  lockupDays: z.number().int().min(0).optional().default(0),
  cooldownHours: z.number().int().min(0).optional().default(0),
  maxParticipants: z.number().int().min(1).optional(),
  minTradeAmount: z.number().positive().optional(),
  maxTradeAmount: z.number().positive().optional(),
  eligibleJurisdictions: z.array(z.string()).optional(),
  customIntervalDays: z.number().int().min(1).optional(),
  autoGenerate: z.boolean().optional().default(true),
});
export type CreateExitWindowSchedule = z.infer<typeof createExitWindowScheduleSchema>;

export const insertExitWindowSchema = createInsertSchema(exitWindows).omit({ id: true, createdAt: true });
export type ExitWindow = typeof exitWindows.$inferSelect;
export type InsertExitWindow = z.infer<typeof insertExitWindowSchema>;

export const createExitWindowSchema = z.object({
  assetId: z.string().min(1, "Asset is required"),
  name: z.string().min(1, "Name is required").max(200),
  opensAt: z.string().min(1, "Open date is required"),
  closesAt: z.string().min(1, "Close date is required"),
  exitFeePercent: z.number().min(0).max(100).optional().default(1.5),
  quarter: z.string().optional(),
  eligibleJurisdictions: z.array(z.string()).optional(),
  lockupDays: z.number().int().min(0).optional(),
  cooldownHours: z.number().int().min(0).optional(),
  maxParticipants: z.number().int().min(1).optional(),
  minTradeAmount: z.number().positive().optional(),
  maxTradeAmount: z.number().positive().optional(),
});
export type CreateExitWindow = z.infer<typeof createExitWindowSchema>;

export const updateExitWindowRulesSchema = z.object({
  eligibleJurisdictions: z.array(z.string()).optional(),
  lockupDays: z.number().int().min(0).optional(),
  cooldownHours: z.number().int().min(0).optional(),
  maxParticipants: z.number().int().min(1).optional(),
  minTradeAmount: z.number().positive().optional(),
  maxTradeAmount: z.number().positive().optional(),
});
export type UpdateExitWindowRules = z.infer<typeof updateExitWindowRulesSchema>;

export const tradeListingStatusEnum = ["active", "filled", "cancelled", "expired"] as const;
export type TradeListingStatus = (typeof tradeListingStatusEnum)[number];

export const tradeListings = pgTable("trade_listings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  exitWindowId: varchar("exit_window_id").notNull(),
  assetId: varchar("asset_id").notNull(),
  sellerId: varchar("seller_id").notNull(),
  quantity: decimal("quantity", { precision: 18, scale: 6 }).notNull(),
  pricePerToken: decimal("price_per_token", { precision: 18, scale: 6 }).notNull(),
  currency: text("currency").notNull(),
  remainingQuantity: decimal("remaining_quantity", { precision: 18, scale: 6 }).notNull(),
  status: text("status").notNull().default("active"),
  buyerId: varchar("buyer_id"),
  filledAt: text("filled_at"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertTradeListingSchema = createInsertSchema(tradeListings).omit({ id: true, status: true, buyerId: true, filledAt: true, createdAt: true });
export type TradeListing = typeof tradeListings.$inferSelect;
export type InsertTradeListing = z.infer<typeof insertTradeListingSchema>;

export const createTradeListingSchema = z.object({
  exitWindowId: z.string().min(1),
  assetId: z.string().min(1),
  quantity: z.number().positive("Quantity must be positive"),
  pricePerToken: z.number().positive("Price must be positive"),
});
export type CreateTradeListing = z.infer<typeof createTradeListingSchema>;

export const executeBuySchema = z.object({
  listingId: z.string().min(1),
  quantity: z.number().positive("Quantity must be positive"),
});
export type ExecuteBuy = z.infer<typeof executeBuySchema>;

export const USER_TIERS = ["standard", "premium", "institutional"] as const;
export type UserTier = (typeof USER_TIERS)[number];

export const INVESTOR_TYPES = ["retail", "sophisticated", "accredited", "institutional"] as const;
export type InvestorType = (typeof INVESTOR_TYPES)[number];

export const INVESTOR_TYPE_RANK: Record<InvestorType, number> = {
  retail: 0,
  sophisticated: 1,
  accredited: 2,
  institutional: 3,
};

export const fxSpreadConfigs = pgTable("fx_spread_configs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fromCurrency: text("from_currency").notNull(),
  toCurrency: text("to_currency").notNull(),
  spreadOverride: decimal("spread_override", { precision: 10, scale: 6 }).notNull().default("0"),
  tierLimits: jsonb("tier_limits").notNull().default(sql`'{}'::jsonb`),
  approvalThreshold: decimal("approval_threshold", { precision: 18, scale: 2 }),
  approvalRequired: boolean("approval_required").notNull().default(false),
  isActive: boolean("is_active").notNull().default(true),
  createdBy: varchar("created_by"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

export const insertFxSpreadConfigSchema = createInsertSchema(fxSpreadConfigs).omit({ id: true, createdAt: true, updatedAt: true });
export type FxSpreadConfig = typeof fxSpreadConfigs.$inferSelect;
export type InsertFxSpreadConfig = z.infer<typeof insertFxSpreadConfigSchema>;

export interface TierLimits {
  [tier: string]: {
    minAmount: number;
    maxAmount: number;
  };
}

export const createFxSpreadConfigSchema = z.object({
  fromCurrency: walletCurrencySchema,
  toCurrency: walletCurrencySchema,
  spreadOverride: z.string().refine(v => parseFloat(v) >= 0, "Spread must be non-negative"),
  tierLimits: z.record(z.string(), z.object({
    minAmount: z.number().min(0),
    maxAmount: z.number().positive(),
  })).optional().default({}),
  approvalThreshold: z.string().optional().nullable(),
  approvalRequired: z.boolean().optional().default(false),
});
export type CreateFxSpreadConfig = z.infer<typeof createFxSpreadConfigSchema>;

export const fxConversionRequests = pgTable("fx_conversion_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  quoteId: varchar("quote_id").notNull(),
  fromCurrency: text("from_currency").notNull(),
  toCurrency: text("to_currency").notNull(),
  amountFrom: decimal("amount_from", { precision: 18, scale: 2 }).notNull(),
  amountTo: decimal("amount_to", { precision: 18, scale: 2 }).notNull(),
  thresholdAmount: decimal("threshold_amount", { precision: 18, scale: 2 }),
  status: text("status").notNull().default("pending"),
  reviewedBy: varchar("reviewed_by"),
  reviewedAt: timestamp("reviewed_at"),
  reviewNotes: text("review_notes"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const insertFxConversionRequestSchema = createInsertSchema(fxConversionRequests).omit({ id: true, createdAt: true });
export type FxConversionRequest = typeof fxConversionRequests.$inferSelect;
export type InsertFxConversionRequest = z.infer<typeof insertFxConversionRequestSchema>;

export const SUPPORTED_CHAINS = [
  { id: "ETH", name: "Ethereum", symbol: "ETH", networkType: "evm", explorerUrl: "https://etherscan.io", addressPattern: "^0x[a-fA-F0-9]{40}$" },
  { id: "TRON", name: "Tron", symbol: "TRX", networkType: "tron", explorerUrl: "https://tronscan.org", addressPattern: "^T[a-zA-Z0-9]{33}$" },
  { id: "BSC", name: "BNB Smart Chain", symbol: "BNB", networkType: "evm", explorerUrl: "https://bscscan.com", addressPattern: "^0x[a-fA-F0-9]{40}$" },
  { id: "POLYGON", name: "Polygon", symbol: "MATIC", networkType: "evm", explorerUrl: "https://polygonscan.com", addressPattern: "^0x[a-fA-F0-9]{40}$" },
  { id: "ARBITRUM", name: "Arbitrum One", symbol: "ETH", networkType: "evm", explorerUrl: "https://arbiscan.io", addressPattern: "^0x[a-fA-F0-9]{40}$" },
  { id: "SOLANA", name: "Solana", symbol: "SOL", networkType: "solana", explorerUrl: "https://solscan.io", addressPattern: "^[1-9A-HJ-NP-Za-km-z]{32,44}$" },
  { id: "AVAX", name: "Avalanche C-Chain", symbol: "AVAX", networkType: "evm", explorerUrl: "https://snowtrace.io", addressPattern: "^0x[a-fA-F0-9]{40}$" },
] as const;

export const SUPPORTED_TOKENS = [
  { symbol: "USDT", name: "Tether USD", chains: ["ETH", "TRON", "BSC", "POLYGON", "ARBITRUM", "SOLANA", "AVAX"] },
  { symbol: "USDC", name: "USD Coin", chains: ["ETH", "BSC", "POLYGON", "ARBITRUM", "SOLANA", "AVAX"] },
] as const;

export const chainIdEnum = SUPPORTED_CHAINS.map(c => c.id);
export type ChainId = (typeof SUPPORTED_CHAINS)[number]["id"];

export const cryptoWallets = pgTable("crypto_wallets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  userId: varchar("user_id").notNull(),
  chainId: text("chain_id").notNull(),
  address: text("address").notNull(),
  label: text("label"),
  isBlacklisted: boolean("is_blacklisted").notNull().default(false),
  blacklistReason: text("blacklist_reason"),
  blacklistedBy: varchar("blacklisted_by"),
  blacklistedAt: timestamp("blacklisted_at"),
  adminNotes: text("admin_notes"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

export const insertCryptoWalletSchema = createInsertSchema(cryptoWallets).omit({ id: true, isBlacklisted: true, blacklistReason: true, blacklistedBy: true, blacklistedAt: true, adminNotes: true, createdAt: true, updatedAt: true });
export type CryptoWallet = typeof cryptoWallets.$inferSelect;
export type InsertCryptoWallet = z.infer<typeof insertCryptoWalletSchema>;

export const attachCryptoWalletSchema = z.object({
  chainId: z.string().min(1, "Chain is required"),
  address: z.string().min(1, "Address is required"),
  label: z.string().max(100).optional(),
});
export type AttachCryptoWallet = z.infer<typeof attachCryptoWalletSchema>;

export const blacklistCryptoWalletSchema = z.object({
  reason: z.string().min(1, "Reason is required"),
});
export type BlacklistCryptoWallet = z.infer<typeof blacklistCryptoWalletSchema>;

export const adminNotesCryptoWalletSchema = z.object({
  notes: z.string(),
});
export type AdminNotesCryptoWallet = z.infer<typeof adminNotesCryptoWalletSchema>;

export const CHAIN_CONFIRMATIONS: Record<string, number> = {
  ETH: 12,
  TRON: 20,
  BSC: 15,
  POLYGON: 30,
  ARBITRUM: 12,
  SOLANA: 32,
  AVAX: 12,
};

export const PLATFORM_RECEIVING_ADDRESSES: Record<string, Record<string, { address: string; memo?: string }>> = {
  ETH: {
    USDT: { address: "0x4838B106FCe9647Bdf1E7877BF73cE8B0BAD5f97" },
    USDC: { address: "0x4838B106FCe9647Bdf1E7877BF73cE8B0BAD5f97" },
  },
  TRON: {
    USDT: { address: "TJYtVBZvEkMvQ1NjF2DKsYoVaRnLitkSm4", memo: "vestblock" },
  },
  BSC: {
    USDT: { address: "0x4838B106FCe9647Bdf1E7877BF73cE8B0BAD5f97" },
    USDC: { address: "0x4838B106FCe9647Bdf1E7877BF73cE8B0BAD5f97" },
  },
  POLYGON: {
    USDT: { address: "0x4838B106FCe9647Bdf1E7877BF73cE8B0BAD5f97" },
    USDC: { address: "0x4838B106FCe9647Bdf1E7877BF73cE8B0BAD5f97" },
  },
  ARBITRUM: {
    USDT: { address: "0x4838B106FCe9647Bdf1E7877BF73cE8B0BAD5f97" },
    USDC: { address: "0x4838B106FCe9647Bdf1E7877BF73cE8B0BAD5f97" },
  },
  SOLANA: {
    USDT: { address: "5ZWj7a1f8tWkjBESHKgrLmXshuXxqeY9SYcfbshpAqPG" },
    USDC: { address: "5ZWj7a1f8tWkjBESHKgrLmXshuXxqeY9SYcfbshpAqPG" },
  },
  AVAX: {
    USDT: { address: "0x4838B106FCe9647Bdf1E7877BF73cE8B0BAD5f97" },
    USDC: { address: "0x4838B106FCe9647Bdf1E7877BF73cE8B0BAD5f97" },
  },
};

export const cryptoDepositStatusEnum = ["CREATED", "PENDING", "CONFIRMED", "REJECTED", "EXPIRED", "AML_HOLD"] as const;
export type CryptoDepositStatus = (typeof cryptoDepositStatusEnum)[number];

export const cryptoAmlStatusEnum = ["CLEAR", "FLAGGED", "HOLD", "CLEARED"] as const;
export type CryptoAmlStatus = (typeof cryptoAmlStatusEnum)[number];

export const CRYPTO_AML_POLICY = {
  largeDepositThreshold: 10000,
  structuringWindowHours: 24,
  structuringMaxCount: 5,
  structuringSmallAmountThreshold: 2000,
} as const;

export const cryptoDepositIntents = pgTable("crypto_deposit_intents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  userId: varchar("user_id").notNull(),
  chainId: text("chain_id").notNull(),
  tokenSymbol: text("token_symbol").notNull(),
  amount: decimal("amount", { precision: 18, scale: 6 }).notNull(),
  invoiceAddress: text("invoice_address").notNull(),
  memo: text("memo"),
  qrPayload: text("qr_payload").notNull(),
  requiredConfirmations: integer("required_confirmations").notNull(),
  confirmations: integer("confirmations").notNull().default(0),
  txHash: text("tx_hash"),
  status: text("status").notNull().default("CREATED"),
  confirmedAt: text("confirmed_at"),
  confirmedBy: varchar("confirmed_by"),
  adminNotes: text("admin_notes"),
  convertToAed: boolean("convert_to_aed").notNull().default(false),
  fxQuoteId: varchar("fx_quote_id"),
  amlStatus: text("aml_status").notNull().default("CLEAR"),
  amlFlags: jsonb("aml_flags").default(sql`'[]'::jsonb`),
  holdReason: text("hold_reason"),
  heldBy: varchar("held_by"),
  heldAt: text("held_at"),
  clearedBy: varchar("cleared_by"),
  clearedAt: text("cleared_at"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

export const insertCryptoDepositIntentSchema = createInsertSchema(cryptoDepositIntents).omit({
  id: true, confirmations: true, txHash: true, status: true,
  confirmedAt: true, confirmedBy: true, adminNotes: true,
  convertToAed: true, fxQuoteId: true,
  amlStatus: true, amlFlags: true, holdReason: true,
  heldBy: true, heldAt: true, clearedBy: true, clearedAt: true,
  createdAt: true, updatedAt: true,
});
export type CryptoDepositIntent = typeof cryptoDepositIntents.$inferSelect;
export type InsertCryptoDepositIntent = z.infer<typeof insertCryptoDepositIntentSchema>;

export const createCryptoDepositSchema = z.object({
  chainId: z.string().min(1, "Chain is required"),
  tokenSymbol: z.enum(["USDT", "USDC"]),
  amount: z.number().positive("Amount must be positive").max(1000000, "Maximum deposit is 1,000,000"),
});
export type CreateCryptoDeposit = z.infer<typeof createCryptoDepositSchema>;

export const confirmCryptoDepositSchema = z.object({
  txHash: z.string().min(1, "Transaction hash is required"),
  confirmations: z.number().int().min(0, "Confirmations must be non-negative"),
  convertToAed: z.boolean().optional().default(false),
});
export type ConfirmCryptoDeposit = z.infer<typeof confirmCryptoDepositSchema>;

export const TICKET_CATEGORIES = ["account", "kyc", "deposit", "withdrawal", "trading", "technical", "other"] as const;
export type TicketCategory = (typeof TICKET_CATEGORIES)[number];

export const TICKET_PRIORITIES = ["low", "medium", "high", "urgent"] as const;
export type TicketPriority = (typeof TICKET_PRIORITIES)[number];

export const TICKET_STATUSES = ["open", "in_progress", "resolved", "closed"] as const;
export type TicketStatus = (typeof TICKET_STATUSES)[number];

export const supportTickets = pgTable("support_tickets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  userId: varchar("user_id").notNull(),
  subject: text("subject").notNull(),
  description: text("description").notNull(),
  countryCode: text("country_code").notNull(),
  currency: text("currency").notNull(),
  category: text("category").notNull().default("other"),
  priority: text("priority").notNull().default("medium"),
  status: text("status").notNull().default("open"),
  adminNotes: text("admin_notes"),
  resolvedBy: varchar("resolved_by"),
  resolvedAt: text("resolved_at"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

export const insertSupportTicketSchema = createInsertSchema(supportTickets).omit({
  id: true, status: true, adminNotes: true, resolvedBy: true, resolvedAt: true,
  createdAt: true, updatedAt: true,
});
export type SupportTicket = typeof supportTickets.$inferSelect;
export type InsertSupportTicket = z.infer<typeof insertSupportTicketSchema>;

export const rolePermissions = pgTable("role_permissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  role: text("role").notNull(),
  permission: text("permission").notNull(),
  grantedBy: varchar("granted_by"),
  grantedAt: timestamp("granted_at").defaultNow(),
});

export const insertRolePermissionSchema = createInsertSchema(rolePermissions).omit({ id: true, grantedAt: true });
export type InsertRolePermission = z.infer<typeof insertRolePermissionSchema>;
export type RolePermission = typeof rolePermissions.$inferSelect;

export const createTicketSchema = z.object({
  subject: z.string().min(3, "Subject must be at least 3 characters").max(200),
  description: z.string().min(10, "Description must be at least 10 characters").max(5000),
  countryCode: z.string().min(2).max(2),
  currency: z.string().min(3).max(3),
  category: z.enum(TICKET_CATEGORIES),
  priority: z.enum(TICKET_PRIORITIES),
});
export type CreateTicket = z.infer<typeof createTicketSchema>;

export const updateTicketSchema = z.object({
  status: z.enum(TICKET_STATUSES).optional(),
  adminNotes: z.string().optional(),
  priority: z.enum(TICKET_PRIORITIES).optional(),
});
export type UpdateTicket = z.infer<typeof updateTicketSchema>;

export const TRANSFER_STATUSES = ["pending", "completed", "rejected", "cancelled"] as const;
export type TransferStatus = (typeof TRANSFER_STATUSES)[number];

export const spvEntities = pgTable("spv_entities", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id").notNull(),
  jurisdiction: text("jurisdiction").notNull(),
  legalName: text("legal_name").notNull(),
  regNumber: text("reg_number"),
  bankAccountRef: text("bank_account_ref"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const shareClasses = pgTable("share_classes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  spvId: varchar("spv_id").notNull(),
  name: text("name").notNull(),
  rightsSummary: text("rights_summary"),
  currency: text("currency").notNull(),
  totalSupply: decimal("total_supply", { precision: 18, scale: 6 }).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const tokens = pgTable("tokens", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id"),
  shareClassId: varchar("share_class_id"),
  vehicleId: varchar("vehicle_id"),
  tokenSymbol: text("token_symbol").notNull(),
  decimals: integer("decimals").notNull().default(6),
  totalSupply: decimal("total_supply", { precision: 18, scale: 6 }).notNull().default("0"),
  transferRestrictions: jsonb("transfer_restrictions").default(sql`'{}'::jsonb`),
  frozen: boolean("frozen").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const tokenHoldings = pgTable("token_holdings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  userId: varchar("user_id").notNull(),
  tokenId: varchar("token_id").notNull(),
  balance: decimal("balance", { precision: 18, scale: 6 }).notNull().default("0"),
  lockupUntil: text("lockup_until"),
  acquiredAt: text("acquired_at"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const tokenTransfers = pgTable("token_transfers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  fromUserId: varchar("from_user_id").notNull(),
  toUserId: varchar("to_user_id").notNull(),
  tokenId: varchar("token_id").notNull(),
  amount: decimal("amount", { precision: 18, scale: 6 }).notNull(),
  status: text("status").notNull().default("pending"),
  reason: text("reason"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const tokenLedgerEntries = pgTable("token_ledger_entries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  tokenId: varchar("token_id").notNull(),
  fromUserId: varchar("from_user_id"),
  toUserId: varchar("to_user_id"),
  amount: decimal("amount", { precision: 18, scale: 6 }).notNull(),
  reason: text("reason").notNull(),
  refId: varchar("ref_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTokenLedgerEntrySchema = createInsertSchema(tokenLedgerEntries).omit({ id: true, createdAt: true });
export type InsertTokenLedgerEntry = z.infer<typeof insertTokenLedgerEntrySchema>;
export type TokenLedgerEntry = typeof tokenLedgerEntries.$inferSelect;

export const tokenIssuances = pgTable("token_issuances", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  roundId: varchar("round_id").notNull(),
  assetId: varchar("asset_id").notNull(),
  tokenId: varchar("token_id").notNull(),
  spvId: varchar("spv_id").notNull(),
  shareClassId: varchar("share_class_id").notNull(),
  totalSupplyMinted: decimal("total_supply_minted", { precision: 18, scale: 6 }).notNull(),
  holdersAllocated: integer("holders_allocated").notNull(),
  totalAmountRaised: decimal("total_amount_raised", { precision: 18, scale: 2 }).notNull(),
  currency: text("currency").notNull(),
  issuedBy: varchar("issued_by").notNull(),
  issuanceReport: jsonb("issuance_report").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTokenIssuanceSchema = createInsertSchema(tokenIssuances).omit({ id: true, createdAt: true });
export type InsertTokenIssuance = z.infer<typeof insertTokenIssuanceSchema>;
export type TokenIssuance = typeof tokenIssuances.$inferSelect;

export const tokenCorporateActions = pgTable("token_corporate_actions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  tokenId: varchar("token_id").notNull(),
  actionType: text("action_type").notNull(),
  ratioNumerator: integer("ratio_numerator").notNull(),
  ratioDenominator: integer("ratio_denominator").notNull(),
  previousTotalSupply: decimal("previous_total_supply", { precision: 18, scale: 6 }).notNull(),
  newTotalSupply: decimal("new_total_supply", { precision: 18, scale: 6 }).notNull(),
  holdersAffected: integer("holders_affected").notNull(),
  reason: text("reason"),
  executedBy: varchar("executed_by").notNull(),
  actionReport: jsonb("action_report").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTokenCorporateActionSchema = createInsertSchema(tokenCorporateActions).omit({ id: true, createdAt: true });
export type InsertTokenCorporateAction = z.infer<typeof insertTokenCorporateActionSchema>;
export type TokenCorporateAction = typeof tokenCorporateActions.$inferSelect;

export const insertSpvEntitySchema = createInsertSchema(spvEntities).omit({ id: true, createdAt: true });
export type InsertSpvEntity = z.infer<typeof insertSpvEntitySchema>;
export type SpvEntity = typeof spvEntities.$inferSelect;

export const insertShareClassSchema = createInsertSchema(shareClasses).omit({ id: true, createdAt: true });
export type InsertShareClass = z.infer<typeof insertShareClassSchema>;
export type ShareClass = typeof shareClasses.$inferSelect;

export const insertTokenSchema = createInsertSchema(tokens).omit({ id: true, createdAt: true });
export type InsertToken = z.infer<typeof insertTokenSchema>;
export type Token = typeof tokens.$inferSelect;

export const insertTokenHoldingSchema = createInsertSchema(tokenHoldings).omit({ id: true, updatedAt: true });
export type InsertTokenHolding = z.infer<typeof insertTokenHoldingSchema>;
export type TokenHolding = typeof tokenHoldings.$inferSelect;

export const insertTokenTransferSchema = createInsertSchema(tokenTransfers).omit({ id: true, createdAt: true });
export type InsertTokenTransfer = z.infer<typeof insertTokenTransferSchema>;
export type TokenTransfer = typeof tokenTransfers.$inferSelect;

export const tokenCertificates = pgTable("token_certificates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  userId: varchar("user_id").notNull(),
  tokenId: varchar("token_id").notNull(),
  tokenSymbol: text("token_symbol").notNull(),
  investorName: text("investor_name").notNull(),
  balance: decimal("balance", { precision: 18, scale: 6 }).notNull(),
  snapshotDate: text("snapshot_date").notNull(),
  verificationHash: text("verification_hash").notNull(),
  propertyTitle: text("property_title"),
  propertyLocation: text("property_location"),
  spvName: text("spv_name"),
  spvJurisdiction: text("spv_jurisdiction"),
  ownershipPercentage: decimal("ownership_percentage", { precision: 8, scale: 4 }),
  totalTokenSupply: decimal("total_token_supply", { precision: 18, scale: 6 }),
  propertyValue: decimal("property_value", { precision: 18, scale: 2 }),
  currency: text("currency"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTokenCertificateSchema = createInsertSchema(tokenCertificates).omit({ id: true, createdAt: true });
export type InsertTokenCertificate = z.infer<typeof insertTokenCertificateSchema>;
export type TokenCertificate = typeof tokenCertificates.$inferSelect;

export const docIngestionTypeEnum = ["passport", "national_id", "bank_statement", "title_deed", "lease_agreement", "utility_bill", "tax_return"] as const;
export type DocIngestionType = (typeof docIngestionTypeEnum)[number];

export const docIngestionStatusEnum = ["uploaded", "extracting", "extracted", "review", "approved", "rejected", "failed"] as const;
export type DocIngestionStatus = (typeof docIngestionStatusEnum)[number];

export const documentIngestions = pgTable("document_ingestions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  documentId: varchar("document_id").notNull(),
  userId: varchar("user_id").notNull(),
  docType: text("doc_type").notNull(),
  status: text("status").notNull().default("uploaded"),
  extractedFields: jsonb("extracted_fields"),
  reviewedFields: jsonb("reviewed_fields"),
  confidence: decimal("confidence", { precision: 5, scale: 2 }),
  ocrProvider: text("ocr_provider"),
  reviewedBy: varchar("reviewed_by"),
  reviewNotes: text("review_notes"),
  kycAutoFilled: boolean("kyc_auto_filled").notNull().default(false),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertDocumentIngestionSchema = createInsertSchema(documentIngestions).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertDocumentIngestion = z.infer<typeof insertDocumentIngestionSchema>;
export type DocumentIngestion = typeof documentIngestions.$inferSelect;

export const offeringStatusEnum = ["DRAFT", "OPEN", "FUNDED", "CLOSED", "CANCELLED"] as const;
export type OfferingStatus = (typeof offeringStatusEnum)[number];

export const offerings = pgTable("offerings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id"),
  vehicleId: varchar("vehicle_id").notNull(),
  name: text("name").notNull(),
  targetAmount: decimal("target_amount", { precision: 18, scale: 2 }).notNull(),
  baseCurrency: text("base_currency").notNull().default("AED"),
  minInvest: decimal("min_invest", { precision: 18, scale: 2 }).notNull(),
  maxInvest: decimal("max_invest", { precision: 18, scale: 2 }),
  startDate: text("start_date").notNull(),
  endDate: text("end_date").notNull(),
  status: text("status").notNull().default("DRAFT"),
  totalCommitted: decimal("total_committed", { precision: 18, scale: 2 }).notNull().default("0"),
  createdBy: varchar("created_by").notNull(),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertOfferingSchema = createInsertSchema(offerings).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertOffering = z.infer<typeof insertOfferingSchema>;
export type Offering = typeof offerings.$inferSelect;

export const createOfferingSchema = z.object({
  vehicleId: z.string().min(1, "Vehicle is required"),
  name: z.string().min(2, "Offering name is required"),
  targetAmount: z.string().min(1, "Target amount is required"),
  minInvest: z.string().min(1, "Minimum investment is required"),
  maxInvest: z.string().optional(),
  startDate: z.string().min(1, "Start date is required"),
  endDate: z.string().min(1, "End date is required"),
});
export type CreateOffering = z.infer<typeof createOfferingSchema>;

export const updateOfferingSchema = createOfferingSchema.partial();
export type UpdateOffering = z.infer<typeof updateOfferingSchema>;

export const offeringStatusTransitionSchema = z.object({
  status: z.enum(offeringStatusEnum),
});

export const commitmentStatusEnum = ["PENDING", "CONFIRMED", "COOLING_OFF", "CANCELLED", "SETTLED"] as const;
export type CommitmentStatus = (typeof commitmentStatusEnum)[number];

export const commitments = pgTable("commitments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  userId: varchar("user_id").notNull(),
  offeringId: varchar("offering_id").notNull(),
  amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
  currency: text("currency").notNull(),
  convertedAmount: decimal("converted_amount", { precision: 18, scale: 2 }),
  baseCurrency: text("base_currency"),
  fxRate: decimal("fx_rate", { precision: 18, scale: 8 }),
  status: text("status").notNull().default("PENDING"),
  coolingOffEndsAt: text("cooling_off_ends_at"),
  reserveLedgerTxId: varchar("reserve_ledger_tx_id"),
  walletAccountId: varchar("wallet_account_id"),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertCommitmentSchema = createInsertSchema(commitments).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertCommitment = z.infer<typeof insertCommitmentSchema>;
export type Commitment = typeof commitments.$inferSelect;

export const createCommitmentSchema = z.object({
  offeringId: z.string().min(1, "Offering is required"),
  amount: z.string().min(1, "Amount is required"),
  currency: z.string().min(1, "Currency is required"),
});

export const valuationUpdates = pgTable("valuation_updates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id").notNull(),
  date: text("date").notNull(),
  valuationAmount: decimal("valuation_amount", { precision: 18, scale: 2 }).notNull(),
  currency: text("currency").notNull(),
  method: text("method").notNull(),
  notes: text("notes"),
  docs: text("docs"),
  impliedTokenPrice: decimal("implied_token_price", { precision: 18, scale: 6 }),
  createdBy: varchar("created_by"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertValuationUpdateSchema = createInsertSchema(valuationUpdates).omit({ id: true, createdAt: true });
export type InsertValuationUpdate = z.infer<typeof insertValuationUpdateSchema>;
export type ValuationUpdate = typeof valuationUpdates.$inferSelect;

export const createValuationUpdateSchema = z.object({
  assetId: z.string().min(1, "Asset ID is required"),
  date: z.string().min(1, "Valuation date is required"),
  valuationAmount: z.string().refine(v => parseFloat(v) > 0, "Valuation must be positive"),
  currency: z.string().min(1, "Currency is required"),
  method: z.string().min(1, "Valuation method is required"),
  notes: z.string().optional(),
  docs: z.string().optional(),
});
export type CreateValuationUpdate = z.infer<typeof createValuationUpdateSchema>;

export const settlementStateEnum = [
  "CLIENT_MONEY_HELD",
  "SETTLEMENT_INITIATED",
  "ACQUISITION_PAID",
  "SETTLED",
  "FAILED",
] as const;
export type SettlementState = (typeof settlementStateEnum)[number];

export const settlementJournal = pgTable("settlement_journal", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id").notNull(),
  roundId: varchar("round_id"),
  userId: varchar("user_id").notNull(),
  walletTransactionId: varchar("wallet_transaction_id"),
  paymentIntentId: varchar("payment_intent_id"),
  referenceId: varchar("reference_id").notNull(),
  state: text("state").notNull().default("CLIENT_MONEY_HELD"),
  amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
  currency: text("currency").notNull(),
  previousState: text("previous_state"),
  notes: text("notes"),
  proofDocumentUrl: text("proof_document_url"),
  advancedBy: varchar("advanced_by"),
  advancedAt: text("advanced_at"),
  metadata: jsonb("metadata"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertSettlementJournalSchema = createInsertSchema(settlementJournal).omit({ id: true });
export type InsertSettlementJournal = z.infer<typeof insertSettlementJournalSchema>;
export type SettlementJournal = typeof settlementJournal.$inferSelect;

export const settlementDocuments = pgTable("settlement_documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  settlementJournalId: varchar("settlement_journal_id").notNull(),
  documentType: text("document_type").notNull(),
  documentUrl: text("document_url"),
  fileName: text("file_name"),
  description: text("description"),
  uploadedBy: varchar("uploaded_by").notNull(),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertSettlementDocumentSchema = createInsertSchema(settlementDocuments).omit({ id: true });
export type InsertSettlementDocument = z.infer<typeof insertSettlementDocumentSchema>;
export type SettlementDocument = typeof settlementDocuments.$inferSelect;

export const advanceSettlementSchema = z.object({
  state: z.enum(settlementStateEnum),
  notes: z.string().optional(),
  proofDocumentUrl: z.string().optional(),
});
export type AdvanceSettlement = z.infer<typeof advanceSettlementSchema>;

export const settlementDocumentTypeEnum = [
  "payment_proof",
  "bank_receipt",
  "acquisition_agreement",
  "transfer_confirmation",
  "compliance_clearance",
  "other",
] as const;

export const dataRoomDocCategoryEnum = [
  "legal",
  "financial",
  "valuation",
  "compliance",
  "corporate",
  "technical",
  "marketing",
  "other",
] as const;
export type DataRoomDocCategory = (typeof dataRoomDocCategoryEnum)[number];

export const dataRoomDocTypeEnum = [
  "title_deed",
  "valuation_report",
  "lease_agreement",
  "insurance_policy",
  "rental_contract",
  "construction_update",
  "expense_invoice",
  "annual_financial_statement",
  "other",
] as const;
export type DataRoomDocType = (typeof dataRoomDocTypeEnum)[number];

export const DATA_ROOM_DOC_TYPE_LABELS: Record<DataRoomDocType, string> = {
  title_deed: "Title Deed",
  valuation_report: "Valuation Report",
  lease_agreement: "Lease Agreement",
  insurance_policy: "Insurance Policy",
  rental_contract: "Rental Contract",
  construction_update: "Construction Update",
  expense_invoice: "Expense Invoice",
  annual_financial_statement: "Annual Financial Statement",
  other: "Other",
};

export const dataRoomDocStatusEnum = ["draft", "live", "archived"] as const;
export type DataRoomDocStatus = (typeof dataRoomDocStatusEnum)[number];

export const dataRoomScopeEnum = ["asset", "offering"] as const;
export type DataRoomScope = (typeof dataRoomScopeEnum)[number];

export const dataRoomAccessTierEnum = ["public", "standard", "qualified", "confidential"] as const;
export type DataRoomAccessTier = (typeof dataRoomAccessTierEnum)[number];

export const DATA_ROOM_ACCESS_TIER_LABELS: Record<DataRoomAccessTier, string> = {
  public: "Public",
  standard: "Standard",
  qualified: "Qualified",
  confidential: "Confidential",
};

export const DATA_ROOM_ACCESS_TIER_ORDER: Record<DataRoomAccessTier, number> = {
  public: 0,
  standard: 1,
  qualified: 2,
  confidential: 3,
};

export const DEFAULT_TIER_THRESHOLDS: Record<DataRoomAccessTier, number> = {
  public: 0,
  standard: 0,
  qualified: 10000,
  confidential: 50000,
};

export const dataRoomDocuments = pgTable("data_room_documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  scope: text("scope").notNull().default("asset"),
  assetId: varchar("asset_id"),
  offeringId: varchar("offering_id"),
  category: text("category").notNull().default("other"),
  docType: text("doc_type").default("other"),
  checklistKey: text("checklist_key"),
  title: text("title").notNull(),
  description: text("description"),
  fileName: text("file_name").notNull(),
  fileSize: integer("file_size"),
  mimeType: text("mime_type"),
  url: text("url").notNull(),
  status: text("status").notNull().default("draft"),
  accessTier: text("access_tier").notNull().default("public"),
  jurisdiction: text("jurisdiction"),
  uploadedBy: varchar("uploaded_by").notNull(),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertDataRoomDocumentSchema = createInsertSchema(dataRoomDocuments).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertDataRoomDocument = z.infer<typeof insertDataRoomDocumentSchema>;
export type DataRoomDocument = typeof dataRoomDocuments.$inferSelect;

export const createDataRoomDocSchema = z.object({
  scope: z.enum(dataRoomScopeEnum),
  assetId: z.string().optional(),
  offeringId: z.string().optional(),
  category: z.enum(dataRoomDocCategoryEnum),
  docType: z.enum(dataRoomDocTypeEnum).optional().default("other"),
  checklistKey: z.string().optional(),
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  fileName: z.string().min(1, "File name is required"),
  fileSize: z.number().optional(),
  mimeType: z.string().optional(),
  url: z.string().min(1, "File URL is required"),
  status: z.enum(dataRoomDocStatusEnum).default("draft"),
  accessTier: z.enum(dataRoomAccessTierEnum).default("public"),
  jurisdiction: z.string().optional(),
});
export type CreateDataRoomDoc = z.infer<typeof createDataRoomDocSchema>;

export const updateDataRoomDocSchema = z.object({
  title: z.string().min(1).optional(),
  description: z.string().optional(),
  category: z.enum(dataRoomDocCategoryEnum).optional(),
  docType: z.enum(dataRoomDocTypeEnum).optional(),
  status: z.enum(dataRoomDocStatusEnum).optional(),
  accessTier: z.enum(dataRoomAccessTierEnum).optional(),
  checklistKey: z.string().optional(),
});
export type UpdateDataRoomDoc = z.infer<typeof updateDataRoomDocSchema>;

export const auditLogs = pgTable("audit_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  actorId: varchar("actor_id").notNull(),
  actorRole: text("actor_role"),
  actionType: text("action_type").notNull(),
  entityType: text("entity_type").notNull(),
  entityId: varchar("entity_id"),
  reason: text("reason"),
  beforeState: jsonb("before_state"),
  afterState: jsonb("after_state"),
  metadata: jsonb("metadata"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({ id: true, createdAt: true });
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
export type AuditLog = typeof auditLogs.$inferSelect;

export const pushSubscriptions = pgTable("push_subscriptions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  endpoint: text("endpoint").notNull(),
  p256dh: text("p256dh").notNull(),
  auth: text("auth").notNull(),
  userAgent: text("user_agent"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertPushSubscriptionSchema = createInsertSchema(pushSubscriptions).omit({ id: true, createdAt: true });
export type InsertPushSubscription = z.infer<typeof insertPushSubscriptionSchema>;
export type PushSubscription = typeof pushSubscriptions.$inferSelect;

export const propertyAcquisitions = pgTable("property_acquisitions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id").notNull().unique(),
  currency: text("currency").notNull().default("AED"),
  purchasePrice: decimal("purchase_price", { precision: 18, scale: 2 }).notNull().default("0"),
  stampDuty: decimal("stamp_duty", { precision: 18, scale: 2 }).notNull().default("0"),
  registrationFee: decimal("registration_fee", { precision: 18, scale: 2 }).notNull().default("0"),
  legalCost: decimal("legal_cost", { precision: 18, scale: 2 }).notNull().default("0"),
  renovationCost: decimal("renovation_cost", { precision: 18, scale: 2 }).notNull().default("0"),
  furnitureCost: decimal("furniture_cost", { precision: 18, scale: 2 }).notNull().default("0"),
  brokerage: decimal("brokerage", { precision: 18, scale: 2 }).notNull().default("0"),
  contingencyPercent: decimal("contingency_percent", { precision: 5, scale: 2 }).notNull().default("5"),
  contingencyAmount: decimal("contingency_amount", { precision: 18, scale: 2 }).notNull().default("0"),
  otherCosts: decimal("other_costs", { precision: 18, scale: 2 }).notNull().default("0"),
  otherCostsDescription: text("other_costs_description"),
  totalAcquisitionCost: decimal("total_acquisition_cost", { precision: 18, scale: 2 }).notNull().default("0"),
  costPerToken: decimal("cost_per_token", { precision: 18, scale: 6 }),
  notes: text("notes"),
  status: text("status").notNull().default("draft"),
  createdBy: varchar("created_by"),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertPropertyAcquisitionSchema = createInsertSchema(propertyAcquisitions).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertPropertyAcquisition = z.infer<typeof insertPropertyAcquisitionSchema>;
export type PropertyAcquisition = typeof propertyAcquisitions.$inferSelect;

export const createPropertyAcquisitionSchema = z.object({
  assetId: z.string().min(1, "Asset is required"),
  currency: z.string().default("AED"),
  purchasePrice: z.string().min(1, "Purchase price is required"),
  stampDuty: z.string().default("0"),
  registrationFee: z.string().default("0"),
  legalCost: z.string().default("0"),
  renovationCost: z.string().default("0"),
  furnitureCost: z.string().default("0"),
  brokerage: z.string().default("0"),
  contingencyPercent: z.string().default("5"),
  otherCosts: z.string().default("0"),
  otherCostsDescription: z.string().optional(),
  notes: z.string().optional(),
});
export type CreatePropertyAcquisition = z.infer<typeof createPropertyAcquisitionSchema>;

export const updatePropertyAcquisitionSchema = createPropertyAcquisitionSchema.omit({ assetId: true }).partial();
export type UpdatePropertyAcquisition = z.infer<typeof updatePropertyAcquisitionSchema>;

export const propertyUnits = pgTable("property_units", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id").notNull().unique(),
  totalUnits: decimal("total_units", { precision: 18, scale: 6 }).notNull(),
  unitPrice: decimal("unit_price", { precision: 18, scale: 6 }).notNull(),
  unitDecimals: integer("unit_decimals").notNull().default(2),
  currency: text("currency").notNull().default("AED"),
  totalCapitalRequired: decimal("total_capital_required", { precision: 18, scale: 2 }).notNull(),
  unitsIssued: decimal("units_issued", { precision: 18, scale: 6 }).notNull().default("0"),
  status: text("status").notNull().default("draft"),
  createdBy: varchar("created_by"),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertPropertyUnitSchema = createInsertSchema(propertyUnits).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertPropertyUnit = z.infer<typeof insertPropertyUnitSchema>;
export type PropertyUnit = typeof propertyUnits.$inferSelect;

export const propertyUnitLedger = pgTable("property_unit_ledger", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  propertyUnitId: varchar("property_unit_id").notNull(),
  assetId: varchar("asset_id").notNull(),
  userId: varchar("user_id"),
  direction: text("direction").notNull(),
  units: decimal("units", { precision: 18, scale: 6 }).notNull(),
  unitPriceAtTime: decimal("unit_price_at_time", { precision: 18, scale: 6 }).notNull(),
  totalValue: decimal("total_value", { precision: 18, scale: 2 }).notNull(),
  reason: text("reason").notNull(),
  refId: varchar("ref_id"),
  notes: text("notes"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertPropertyUnitLedgerSchema = createInsertSchema(propertyUnitLedger).omit({ id: true, createdAt: true });
export type InsertPropertyUnitLedger = z.infer<typeof insertPropertyUnitLedgerSchema>;
export type PropertyUnitLedger = typeof propertyUnitLedger.$inferSelect;

export const developerPaymentStatusEnum = ["planned", "paid", "overdue", "cancelled"] as const;
export type DeveloperPaymentStatus = typeof developerPaymentStatusEnum[number];

export const developerPaymentSchedule = pgTable("developer_payment_schedule", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id").notNull(),
  milestoneId: varchar("milestone_id"),
  label: text("label").notNull(),
  dueDate: text("due_date").notNull(),
  amount: decimal("amount", { precision: 18, scale: 2 }).notNull(),
  currency: text("currency").notNull().default("AED"),
  status: text("status").notNull().default("planned"),
  paidDate: text("paid_date"),
  notes: text("notes"),
  sortOrder: integer("sort_order").notNull().default(0),
  createdBy: varchar("created_by"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertDeveloperPaymentSchema = createInsertSchema(developerPaymentSchedule).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertDeveloperPayment = z.infer<typeof insertDeveloperPaymentSchema>;
export type DeveloperPayment = typeof developerPaymentSchedule.$inferSelect;

export const createPropertyUnitSchema = z.object({
  assetId: z.string().min(1),
  totalUnits: z.string().min(1, "Total units required"),
  unitDecimals: z.number().int().min(0).max(6).default(2),
  currency: z.string().default("AED"),
});
export type CreatePropertyUnitInput = z.infer<typeof createPropertyUnitSchema>;

export const updatePropertyUnitSchema = z.object({
  totalUnits: z.string().optional(),
  unitDecimals: z.number().int().min(0).max(6).optional(),
  status: z.enum(["draft", "active", "frozen"]).optional(),
});
export type UpdatePropertyUnitInput = z.infer<typeof updatePropertyUnitSchema>;

export const propertySaleStatusEnum = ["draft", "preview", "executed", "cancelled"] as const;
export type PropertySaleStatus = (typeof propertySaleStatusEnum)[number];

export const propertySaleEvents = pgTable("property_sale_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id").notNull(),
  saleAmount: decimal("sale_amount", { precision: 18, scale: 2 }).notNull(),
  currency: text("currency").notNull().default("AED"),
  agentCommission: decimal("agent_commission", { precision: 18, scale: 2 }).notNull().default("0"),
  legalFees: decimal("legal_fees", { precision: 18, scale: 2 }).notNull().default("0"),
  transferTax: decimal("transfer_tax", { precision: 18, scale: 2 }).notNull().default("0"),
  otherCosts: decimal("other_costs", { precision: 18, scale: 2 }).notNull().default("0"),
  otherCostsDescription: text("other_costs_description"),
  totalSellingCosts: decimal("total_selling_costs", { precision: 18, scale: 2 }).notNull().default("0"),
  netSaleProceeds: decimal("net_sale_proceeds", { precision: 18, scale: 2 }).notNull().default("0"),
  totalCapitalInvested: decimal("total_capital_invested", { precision: 18, scale: 2 }).notNull().default("0"),
  capitalGain: decimal("capital_gain", { precision: 18, scale: 2 }).notNull().default("0"),
  totalUnitsAtSale: decimal("total_units_at_sale", { precision: 18, scale: 6 }).notNull().default("0"),
  returnPerUnit: decimal("return_per_unit", { precision: 18, scale: 6 }).notNull().default("0"),
  gainPerUnit: decimal("gain_per_unit", { precision: 18, scale: 6 }).notNull().default("0"),
  totalPayoutPerUnit: decimal("total_payout_per_unit", { precision: 18, scale: 6 }).notNull().default("0"),
  holdingsSnapshot: jsonb("holdings_snapshot"),
  status: text("status").notNull().default("draft"),
  notes: text("notes"),
  executedAt: text("executed_at"),
  createdBy: varchar("created_by").notNull(),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertPropertySaleEventSchema = createInsertSchema(propertySaleEvents).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertPropertySaleEvent = z.infer<typeof insertPropertySaleEventSchema>;
export type PropertySaleEvent = typeof propertySaleEvents.$inferSelect;

export const propertySalePayouts = pgTable("property_sale_payouts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  saleEventId: varchar("sale_event_id").notNull(),
  userId: varchar("user_id").notNull(),
  units: decimal("units", { precision: 18, scale: 6 }).notNull(),
  capitalReturnAmount: decimal("capital_return_amount", { precision: 18, scale: 2 }).notNull(),
  capitalGainAmount: decimal("capital_gain_amount", { precision: 18, scale: 2 }).notNull(),
  totalPayout: decimal("total_payout", { precision: 18, scale: 2 }).notNull(),
  currency: text("currency").notNull(),
  walletTransactionIds: jsonb("wallet_transaction_ids"),
  status: text("status").notNull().default("completed"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertPropertySalePayoutSchema = createInsertSchema(propertySalePayouts).omit({ id: true, createdAt: true });
export type InsertPropertySalePayout = z.infer<typeof insertPropertySalePayoutSchema>;
export type PropertySalePayout = typeof propertySalePayouts.$inferSelect;

export const createPropertySaleSchema = z.object({
  assetId: z.string().min(1),
  saleAmount: z.string().min(1, "Sale amount is required"),
  agentCommission: z.string().default("0"),
  legalFees: z.string().default("0"),
  transferTax: z.string().default("0"),
  otherCosts: z.string().default("0"),
  otherCostsDescription: z.string().optional(),
  notes: z.string().optional(),
});
export type CreatePropertySaleInput = z.infer<typeof createPropertySaleSchema>;

export const PROJECT_STATUSES = ["PLANNING", "IN_PROGRESS", "ON_HOLD", "COMPLETED", "CANCELLED"] as const;
export type ProjectStatus = (typeof PROJECT_STATUSES)[number];

export const PROJECT_TYPES = ["DEVELOPMENT", "ACQUISITION", "RENOVATION", "MARKETING", "COMPLIANCE", "OTHER"] as const;
export type ProjectType = (typeof PROJECT_TYPES)[number];

export const PROJECT_MEMBER_ROLES = ["DEV", "PM", "VIEWER"] as const;
export type ProjectMemberRole = (typeof PROJECT_MEMBER_ROLES)[number];

export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  type: text("type").notNull().default("DEVELOPMENT"),
  status: text("status").notNull().default("PLANNING"),
  startDate: text("start_date"),
  dueDate: text("due_date"),
  healthScore: integer("health_score").default(100),
  marketScore: integer("market_score").default(0),
  createdBy: varchar("created_by").notNull(),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertProjectSchema = createInsertSchema(projects).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

export const projectMembers = pgTable("project_members", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull(),
  userId: varchar("user_id").notNull(),
  role: text("role").notNull().default("DEV"),
  assignedAt: text("assigned_at").notNull().default(sql`now()`),
});

export const insertProjectMemberSchema = createInsertSchema(projectMembers).omit({ id: true, assignedAt: true });
export type InsertProjectMember = z.infer<typeof insertProjectMemberSchema>;
export type ProjectMember = typeof projectMembers.$inferSelect;

export const projectActivityLogs = pgTable("project_activity_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull(),
  userId: varchar("user_id").notNull(),
  action: text("action").notNull(),
  details: text("details"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertProjectActivityLogSchema = createInsertSchema(projectActivityLogs).omit({ id: true, createdAt: true });
export type InsertProjectActivityLog = z.infer<typeof insertProjectActivityLogSchema>;
export type ProjectActivityLog = typeof projectActivityLogs.$inferSelect;

export const lockupRules = pgTable("lockup_rules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  assetId: varchar("asset_id").notNull(),
  profitLockDays: integer("profit_lock_days").notNull().default(30),
  capitalLockDays: integer("capital_lock_days").notNull().default(90),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertLockupRuleSchema = createInsertSchema(lockupRules).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertLockupRule = z.infer<typeof insertLockupRuleSchema>;
export type LockupRule = typeof lockupRules.$inferSelect;

export const cmsPages = pgTable("cms_pages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  region: text("region").notNull().default("AE"),
  slug: text("slug").notNull(),
  title: text("title").notNull(),
  status: text("status").notNull().default("DRAFT"),
  seoTitle: text("seo_title"),
  seoDescription: text("seo_description"),
  ogImage: text("og_image"),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
  updatedBy: varchar("updated_by"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertCmsPageSchema = createInsertSchema(cmsPages).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertCmsPage = z.infer<typeof insertCmsPageSchema>;
export type CmsPage = typeof cmsPages.$inferSelect;

export const cmsPageSections = pgTable("cms_page_sections", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  pageId: varchar("page_id").notNull(),
  sectionKey: text("section_key").notNull(),
  orderIndex: integer("order_index").notNull().default(0),
  sectionType: text("section_type").notNull(),
  contentJson: jsonb("content_json").notNull(),
  isEnabled: boolean("is_enabled").notNull().default(true),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertCmsPageSectionSchema = createInsertSchema(cmsPageSections).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertCmsPageSection = z.infer<typeof insertCmsPageSectionSchema>;
export type CmsPageSection = typeof cmsPageSections.$inferSelect;

export const cmsGlobalContent = pgTable("cms_global_content", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  region: text("region").notNull().default("AE"),
  contentKey: text("content_key").notNull(),
  contentJson: jsonb("content_json").notNull(),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
  updatedBy: varchar("updated_by"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertCmsGlobalContentSchema = createInsertSchema(cmsGlobalContent).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertCmsGlobalContent = z.infer<typeof insertCmsGlobalContentSchema>;
export type CmsGlobalContent = typeof cmsGlobalContent.$inferSelect;

export const cmsPropertyListings = pgTable("cms_property_listings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  region: text("region").notNull().default("AE"),
  slug: text("slug").notNull(),
  name: text("name").notNull(),
  city: text("city").notNull(),
  country: text("country").notNull(),
  propertyType: text("property_type").notNull(),
  strategy: text("strategy"),
  minInvestment: decimal("min_investment", { precision: 18, scale: 2 }).notNull(),
  currency: text("currency").notNull().default("AED"),
  expectedYield: decimal("expected_yield", { precision: 8, scale: 4 }),
  payoutFrequency: text("payout_frequency"),
  fundingTarget: decimal("funding_target", { precision: 18, scale: 2 }),
  fundingProgressPercent: integer("funding_progress_percent").notNull().default(0),
  status: text("status").notNull().default("DRAFT"),
  shortDescription: text("short_description"),
  longDescription: text("long_description"),
  imagesJson: jsonb("images_json"),
  dataRoomDocsJson: jsonb("data_room_docs_json"),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertCmsPropertyListingSchema = createInsertSchema(cmsPropertyListings).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertCmsPropertyListing = z.infer<typeof insertCmsPropertyListingSchema>;
export type CmsPropertyListing = typeof cmsPropertyListings.$inferSelect;

export const cmsBlogPosts = pgTable("cms_blog_posts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  region: text("region").notNull().default("AE"),
  slug: text("slug").notNull(),
  title: text("title").notNull(),
  excerpt: text("excerpt"),
  contentHtml: text("content_html"),
  category: text("category"),
  tagsJson: jsonb("tags_json"),
  coverImage: text("cover_image"),
  status: text("status").notNull().default("DRAFT"),
  publishedAt: text("published_at"),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertCmsBlogPostSchema = createInsertSchema(cmsBlogPosts).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertCmsBlogPost = z.infer<typeof insertCmsBlogPostSchema>;
export type CmsBlogPost = typeof cmsBlogPosts.$inferSelect;

export const cmsFaqItems = pgTable("cms_faq_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  region: text("region").notNull().default("AE"),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  category: text("category"),
  orderIndex: integer("order_index").notNull().default(0),
  isEnabled: boolean("is_enabled").notNull().default(true),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertCmsFaqItemSchema = createInsertSchema(cmsFaqItems).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertCmsFaqItem = z.infer<typeof insertCmsFaqItemSchema>;
export type CmsFaqItem = typeof cmsFaqItems.$inferSelect;

export const cmsGuides = pgTable("cms_guides", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  region: text("region").notNull().default("AE"),
  slug: text("slug").notNull(),
  title: text("title").notNull(),
  excerpt: text("excerpt"),
  contentHtml: text("content_html"),
  status: text("status").notNull().default("DRAFT"),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertCmsGuideSchema = createInsertSchema(cmsGuides).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertCmsGuide = z.infer<typeof insertCmsGuideSchema>;
export type CmsGuide = typeof cmsGuides.$inferSelect;

export const cmsGlossaryTerms = pgTable("cms_glossary_terms", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  region: text("region").notNull().default("AE"),
  term: text("term").notNull(),
  definition: text("definition").notNull(),
  category: text("category"),
  orderIndex: integer("order_index").notNull().default(0),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertCmsGlossaryTermSchema = createInsertSchema(cmsGlossaryTerms).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertCmsGlossaryTerm = z.infer<typeof insertCmsGlossaryTermSchema>;
export type CmsGlossaryTerm = typeof cmsGlossaryTerms.$inferSelect;

export const cmsFeeConfigs = pgTable("cms_fee_configs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  region: text("region").notNull().default("AE"),
  name: text("name").notNull(),
  valueType: text("value_type").notNull().default("PERCENT"),
  value: decimal("value", { precision: 18, scale: 6 }).notNull(),
  currency: text("currency"),
  description: text("description"),
  isEnabled: boolean("is_enabled").notNull().default(true),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertCmsFeeConfigSchema = createInsertSchema(cmsFeeConfigs).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertCmsFeeConfig = z.infer<typeof insertCmsFeeConfigSchema>;
export type CmsFeeConfig = typeof cmsFeeConfigs.$inferSelect;

export const cmsExitWindowSchedules = pgTable("cms_exit_window_schedules", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  region: text("region").notNull().default("AE"),
  name: text("name").notNull(),
  opensAt: text("opens_at").notNull(),
  closesAt: text("closes_at").notNull(),
  settlementDays: integer("settlement_days").notNull().default(5),
  notes: text("notes"),
  isEnabled: boolean("is_enabled").notNull().default(true),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertCmsExitWindowScheduleSchema = createInsertSchema(cmsExitWindowSchedules).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertCmsExitWindowSchedule = z.infer<typeof insertCmsExitWindowScheduleSchema>;
export type CmsExitWindowSchedule = typeof cmsExitWindowSchedules.$inferSelect;

export const cmsAuditLog = pgTable("cms_audit_log", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  entityType: text("entity_type").notNull(),
  entityId: varchar("entity_id").notNull(),
  action: text("action").notNull(),
  diffJson: jsonb("diff_json"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertCmsAuditLogSchema = createInsertSchema(cmsAuditLog).omit({ id: true, createdAt: true });
export type InsertCmsAuditLog = z.infer<typeof insertCmsAuditLogSchema>;
export type CmsAuditLog = typeof cmsAuditLog.$inferSelect;

export const aiInteractionLogs = pgTable("ai_interaction_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  feature: text("feature").notNull(),
  prompt: text("prompt").notNull(),
  response: text("response").notNull(),
  sourcesJson: jsonb("sources_json"),
  tokensEstimated: integer("tokens_estimated"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertAiInteractionLogSchema = createInsertSchema(aiInteractionLogs).omit({ id: true, createdAt: true });
export type InsertAiInteractionLog = z.infer<typeof insertAiInteractionLogSchema>;
export type AiInteractionLog = typeof aiInteractionLogs.$inferSelect;

export const contentSources = pgTable("content_sources", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  region: text("region").notNull().default("PK"),
  type: text("type").notNull(),
  title: text("title").notNull(),
  slug: text("slug").notNull(),
  rawText: text("raw_text").notNull(),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertContentSourceSchema = createInsertSchema(contentSources).omit({ id: true, updatedAt: true });
export type InsertContentSource = z.infer<typeof insertContentSourceSchema>;
export type ContentSource = typeof contentSources.$inferSelect;

export const contentChunks = pgTable("content_chunks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sourceId: varchar("source_id").notNull(),
  chunkText: text("chunk_text").notNull(),
  embeddingVector: jsonb("embedding_vector"),
  chunkIndex: integer("chunk_index").notNull().default(0),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertContentChunkSchema = createInsertSchema(contentChunks).omit({ id: true, createdAt: true });
export type InsertContentChunk = z.infer<typeof insertContentChunkSchema>;
export type ContentChunk = typeof contentChunks.$inferSelect;

export const adtDocuments = pgTable("adt_documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  region: text("region").notNull().default("PK"),
  propertyId: varchar("property_id"),
  filename: text("filename").notNull(),
  fileUrl: text("file_url"),
  extractedText: text("extracted_text").notNull(),
  uploadedByUserId: varchar("uploaded_by_user_id"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertAdtDocumentSchema = createInsertSchema(adtDocuments).omit({ id: true, createdAt: true });
export type InsertAdtDocument = z.infer<typeof insertAdtDocumentSchema>;
export type AdtDocument = typeof adtDocuments.$inferSelect;

export const docSummaries = pgTable("doc_summaries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  documentId: varchar("document_id").notNull(),
  summaryJson: jsonb("summary_json").notNull(),
  riskFlagsJson: jsonb("risk_flags_json"),
  questionsJson: jsonb("questions_json"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertDocSummarySchema = createInsertSchema(docSummaries).omit({ id: true, createdAt: true });
export type InsertDocSummary = z.infer<typeof insertDocSummarySchema>;
export type DocSummary = typeof docSummaries.$inferSelect;

export const investorGoalEnum = ["INCOME", "GROWTH", "BALANCED"] as const;
export type InvestorGoal = (typeof investorGoalEnum)[number];

export const liquidityNeedEnum = ["LOW", "MED", "HIGH"] as const;
export type LiquidityNeed = (typeof liquidityNeedEnum)[number];

export const investorPreferenceProfiles = pgTable("investor_preference_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  region: text("region").notNull().default("PK"),
  budgetMin: decimal("budget_min", { precision: 18, scale: 2 }).notNull(),
  budgetMax: decimal("budget_max", { precision: 18, scale: 2 }).notNull(),
  goal: text("goal").notNull(),
  citiesJson: jsonb("cities_json").notNull().default(sql`'[]'::jsonb`),
  riskTolerance: integer("risk_tolerance").notNull().default(3),
  horizonMonths: integer("horizon_months").notNull().default(24),
  liquidityNeed: text("liquidity_need").notNull().default("MED"),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at").notNull().default(sql`now()`),
});

export const insertInvestorPreferenceProfileSchema = createInsertSchema(investorPreferenceProfiles).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertInvestorPreferenceProfile = z.infer<typeof insertInvestorPreferenceProfileSchema>;
export type InvestorPreferenceProfile = typeof investorPreferenceProfiles.$inferSelect;

export const createPreferenceProfileSchema = z.object({
  region: z.string().default("PK"),
  budgetMin: z.number().positive("Minimum budget must be positive"),
  budgetMax: z.number().positive("Maximum budget must be positive"),
  goal: z.enum(investorGoalEnum),
  cities: z.array(z.string()).min(1, "Select at least one city"),
  riskTolerance: z.number().int().min(1).max(5),
  horizonMonths: z.number().int().min(1).max(360),
  liquidityNeed: z.enum(liquidityNeedEnum),
});
export type CreatePreferenceProfile = z.infer<typeof createPreferenceProfileSchema>;

export const marketPulseMetricSnapshots = pgTable("market_pulse_metric_snapshots", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  weekStart: text("week_start").notNull(),
  weekEnd: text("week_end").notNull(),
  region: text("region").notNull().default("PK"),
  metricsJson: jsonb("metrics_json").notNull(),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertMarketPulseMetricSnapshotSchema = createInsertSchema(marketPulseMetricSnapshots).omit({ id: true, createdAt: true });
export type InsertMarketPulseMetricSnapshot = z.infer<typeof insertMarketPulseMetricSnapshotSchema>;
export type MarketPulseMetricSnapshot = typeof marketPulseMetricSnapshots.$inferSelect;

export const marketPulseReports = pgTable("market_pulse_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  weekStart: text("week_start").notNull(),
  weekEnd: text("week_end").notNull(),
  region: text("region").notNull().default("PK"),
  status: text("status").notNull().default("draft"),
  narrativeMd: text("narrative_md"),
  highlightsJson: jsonb("highlights_json"),
  metricsSnapshotId: varchar("metrics_snapshot_id"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertMarketPulseReportSchema = createInsertSchema(marketPulseReports).omit({ id: true, createdAt: true });
export type InsertMarketPulseReport = z.infer<typeof insertMarketPulseReportSchema>;
export type MarketPulseReport = typeof marketPulseReports.$inferSelect;

export const appointmentModeEnum = ["virtual", "in_person", "phone"] as const;
export type AppointmentMode = (typeof appointmentModeEnum)[number];

export const appointmentStatusEnum = ["REQUESTED", "CONFIRMED", "RESCHEDULED", "CANCELLED", "COMPLETED"] as const;
export type AppointmentStatus = (typeof appointmentStatusEnum)[number];

export const appointments = pgTable("appointments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  userId: varchar("user_id").notNull(),
  assignedToUserId: varchar("assigned_to_user_id"),
  datetime: text("datetime").notNull(),
  mode: text("mode").notNull().default("virtual"),
  status: text("status").notNull().default("REQUESTED"),
  notes: text("notes"),
  createdAt: text("created_at").notNull().default(sql`now()`),
  updatedAt: text("updated_at"),
});

export const insertAppointmentSchema = createInsertSchema(appointments).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;
export type Appointment = typeof appointments.$inferSelect;

export const createAppointmentSchema = z.object({
  datetime: z.string().min(1),
  mode: z.enum(appointmentModeEnum).default("virtual"),
  notes: z.string().optional(),
  assignedToUserId: z.string().optional(),
});

export const updateAppointmentSchema = z.object({
  id: z.string().min(1),
  datetime: z.string().optional(),
  mode: z.enum(appointmentModeEnum).optional(),
  status: z.enum(appointmentStatusEnum).optional(),
  notes: z.string().optional(),
  assignedToUserId: z.string().nullable().optional(),
});

export const assignAppointmentSchema = z.object({
  id: z.string().min(1),
  assignedToUserId: z.string().min(1),
});

export const agentRespondAppointmentSchema = z.object({
  id: z.string().min(1),
  action: z.enum(["accept", "reschedule", "cancel"]),
  datetime: z.string().optional(),
  notes: z.string().optional(),
});

export const emailLogStatusEnum = ["queued", "sent", "failed", "bounced"] as const;
export type EmailLogStatus = (typeof emailLogStatusEnum)[number];

export const emailLogs = pgTable("email_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  toAddress: text("to_address").notNull(),
  subject: text("subject").notNull(),
  body: text("body").notNull(),
  status: text("status").notNull().default("queued"),
  relatedEntityType: text("related_entity_type"),
  relatedEntityId: varchar("related_entity_id"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertEmailLogSchema = createInsertSchema(emailLogs).omit({ id: true, createdAt: true });
export type InsertEmailLog = z.infer<typeof insertEmailLogSchema>;
export type EmailLog = typeof emailLogs.$inferSelect;

export const createTransactionSchema = z.object({
  type: z.string().min(1),
  amount: z.string().min(1),
  currency: z.string().optional(),
  description: z.string().optional(),
  assetId: z.string().optional(),
  metadataJson: z.record(z.unknown()).optional(),
});

export const updateTransactionStatusSchema = z.object({
  id: z.string().min(1),
  status: z.enum(["pending", "processing", "completed", "failed", "cancelled", "pending_confirmation", "confirmed"]),
});

export const subscribers = pgTable("subscribers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  region: text("region"),
  source: text("source").default("website"),
  isActive: boolean("is_active").default(true),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertSubscriberSchema = createInsertSchema(subscribers).omit({ id: true, createdAt: true });
export type InsertSubscriber = z.infer<typeof insertSubscriberSchema>;
export type Subscriber = typeof subscribers.$inferSelect;

export const subscribeSchema = z.object({
  email: z.string().email(),
  region: z.string().optional(),
  source: z.string().optional(),
});

export const campaigns = pgTable("campaigns", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tenantId: varchar("tenant_id"),
  subject: text("subject").notNull(),
  body: text("body").notNull(),
  segment: text("segment"),
  recipientCount: integer("recipient_count").default(0),
  sentBy: varchar("sent_by"),
  status: text("status").notNull().default("draft"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertCampaignSchema = createInsertSchema(campaigns).omit({ id: true, createdAt: true });
export type InsertCampaign = z.infer<typeof insertCampaignSchema>;
export type Campaign = typeof campaigns.$inferSelect;

export const createCampaignSchema = z.object({
  subject: z.string().min(1),
  body: z.string().min(1),
  segment: z.string().optional(),
});

export const otpCodes = pgTable("otp_codes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  transactionId: varchar("transaction_id").notNull(),
  code: text("code").notNull(),
  expiresAt: text("expires_at").notNull(),
  attempts: integer("attempts").default(0),
  maxAttempts: integer("max_attempts").default(5),
  verified: boolean("verified").default(false),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertOtpCodeSchema = createInsertSchema(otpCodes).omit({ id: true, createdAt: true });
export type InsertOtpCode = z.infer<typeof insertOtpCodeSchema>;
export type OtpCode = typeof otpCodes.$inferSelect;

export const verifyOtpSchema = z.object({
  transactionId: z.string().min(1),
  code: z.string().length(6),
});

export const sessions = pgTable("sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  token: text("token").notNull(),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  provider: text("provider").notNull().default("credentials"),
  expiresAt: text("expires_at").notNull(),
  revokedAt: text("revoked_at"),
  createdAt: text("created_at").notNull().default(sql`now()`),
});

export const insertSessionSchema = createInsertSchema(sessions).omit({ id: true, createdAt: true });
export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessions.$inferSelect;

export * from "./models/chat";
