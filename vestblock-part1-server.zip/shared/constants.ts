import { z } from "zod";

export const PLATFORM_TENANT_ID = "00000000-0000-0000-0000-000000000001";
export const PLATFORM_TENANT_SLUG = "platform";

export const TENANT_STATUSES = ["ACTIVE", "SUSPENDED", "DELETED"] as const;
export type TenantStatus = (typeof TENANT_STATUSES)[number];
export const tenantStatusSchema = z.enum(TENANT_STATUSES);

export const TENANT_USER_STATUSES = ["ACTIVE", "SUSPENDED", "INVITED", "DISABLED"] as const;
export type TenantUserStatus = (typeof TENANT_USER_STATUSES)[number];

export const PLATFORM_ROLES = ["SUPER_ADMIN", "PLATFORM_ADMIN", "PLATFORM_FINANCE", "PLATFORM_COMPLIANCE"] as const;
export type PlatformRole = (typeof PLATFORM_ROLES)[number];
export const platformRoleSchema = z.enum(PLATFORM_ROLES);

export const TENANT_ROLES = ["TENANT_OWNER", "TENANT_ADMIN", "TENANT_MANAGER", "TENANT_MODERATOR", "TENANT_USER"] as const;
export type TenantRole = (typeof TENANT_ROLES)[number];
export const tenantRoleSchema = z.enum(TENANT_ROLES);

export const PLATFORM_ROLE_LABELS: Record<PlatformRole, string> = {
  SUPER_ADMIN: "Super Admin",
  PLATFORM_ADMIN: "Platform Admin",
  PLATFORM_FINANCE: "Platform Finance",
  PLATFORM_COMPLIANCE: "Platform Compliance",
};

export const TENANT_ROLE_LABELS: Record<TenantRole, string> = {
  TENANT_OWNER: "Owner",
  TENANT_ADMIN: "Admin",
  TENANT_MANAGER: "Manager",
  TENANT_MODERATOR: "Moderator",
  TENANT_USER: "User",
};

export const PLATFORM_ACTIONS = [
  "platform.access",
  "tenants.view",
  "tenants.create",
  "tenants.manage",
  "tenants.delete",
  "tenants.impersonate",
  "platform_users.view",
  "platform_users.manage",
  "platform_finance.view",
  "platform_finance.manage",
  "platform_compliance.view",
  "platform_compliance.manage",
  "platform_settings.view",
  "platform_settings.manage",
  "audit_logs.view",
  "system_health.view",
] as const;
export type PlatformAction = (typeof PLATFORM_ACTIONS)[number];

export const TENANT_ACTIONS = [
  "tenant.access",
  "tenant_users.view",
  "tenant_users.invite",
  "tenant_users.manage",
  "tenant_users.remove",
  "tenant_users.force_logout",
  "tenant_settings.view",
  "tenant_settings.manage",
  "tenant_assets.view",
  "tenant_assets.manage",
  "tenant_finance.view",
  "tenant_finance.manage",
  "tenant_compliance.view",
  "tenant_compliance.manage",
  "tenant_marketplace.view",
  "tenant_marketplace.manage",
  "tenant_support.view",
  "tenant_support.manage",
  "tenant_projects.view",
  "tenant_projects.manage",
] as const;
export type TenantAction = (typeof TENANT_ACTIONS)[number];

export const PLATFORM_ROLE_PERMISSIONS: Record<PlatformRole, readonly PlatformAction[]> = {
  SUPER_ADMIN: [...PLATFORM_ACTIONS],
  PLATFORM_ADMIN: [
    "platform.access", "tenants.view", "tenants.create", "tenants.manage",
    "platform_users.view", "platform_users.manage",
    "platform_finance.view", "platform_compliance.view",
    "audit_logs.view", "system_health.view",
  ],
  PLATFORM_FINANCE: [
    "platform.access", "tenants.view",
    "platform_finance.view", "platform_finance.manage",
    "platform_users.view",
  ],
  PLATFORM_COMPLIANCE: [
    "platform.access", "tenants.view",
    "platform_compliance.view", "platform_compliance.manage",
    "platform_users.view",
  ],
};

export const TENANT_ROLE_PERMISSIONS: Record<TenantRole, readonly TenantAction[]> = {
  TENANT_OWNER: [...TENANT_ACTIONS],
  TENANT_ADMIN: [
    "tenant.access", "tenant_users.view", "tenant_users.invite", "tenant_users.manage", "tenant_users.remove", "tenant_users.force_logout",
    "tenant_settings.view", "tenant_settings.manage",
    "tenant_assets.view", "tenant_assets.manage",
    "tenant_finance.view", "tenant_finance.manage",
    "tenant_compliance.view", "tenant_compliance.manage",
    "tenant_marketplace.view", "tenant_marketplace.manage",
    "tenant_support.view", "tenant_support.manage",
    "tenant_projects.view", "tenant_projects.manage",
  ],
  TENANT_MANAGER: [
    "tenant.access", "tenant_users.view", "tenant_users.invite",
    "tenant_settings.view",
    "tenant_assets.view", "tenant_assets.manage",
    "tenant_finance.view",
    "tenant_marketplace.view", "tenant_marketplace.manage",
    "tenant_support.view", "tenant_support.manage",
    "tenant_projects.view", "tenant_projects.manage",
  ],
  TENANT_MODERATOR: [
    "tenant.access", "tenant_users.view",
    "tenant_assets.view",
    "tenant_marketplace.view",
    "tenant_support.view", "tenant_support.manage",
    "tenant_projects.view",
  ],
  TENANT_USER: [
    "tenant.access",
    "tenant_assets.view",
    "tenant_marketplace.view",
    "tenant_projects.view",
  ],
};

export type RbacAction = PlatformAction | TenantAction;

export interface RbacContext {
  platformRole?: PlatformRole | null;
  tenantRole?: TenantRole | null;
}

export function can(action: RbacAction, context: RbacContext): boolean {
  if (context.platformRole) {
    if (context.platformRole === "SUPER_ADMIN") return true;
    const platformPerms = PLATFORM_ROLE_PERMISSIONS[context.platformRole];
    if (platformPerms && (platformPerms as readonly string[]).includes(action)) return true;
  }

  if (context.tenantRole) {
    const tenantPerms = TENANT_ROLE_PERMISSIONS[context.tenantRole];
    if (tenantPerms && (tenantPerms as readonly string[]).includes(action)) return true;
  }

  return false;
}

export function isPlatformRole(role: string): role is PlatformRole {
  return PLATFORM_ROLES.includes(role as PlatformRole);
}

export function isTenantRole(role: string): role is TenantRole {
  return TENANT_ROLES.includes(role as TenantRole);
}

export function legacyRoleToPlatformRole(role: string): PlatformRole | null {
  if (role === "admin") return "PLATFORM_ADMIN";
  return null;
}

export function legacyRoleToTenantRole(role: string): TenantRole {
  switch (role) {
    case "admin": return "TENANT_ADMIN";
    case "issuer": return "TENANT_MANAGER";
    case "agent": return "TENANT_MODERATOR";
    case "investor": return "TENANT_USER";
    default: return "TENANT_USER";
  }
}

export const SUPPORTED_COUNTRIES = ["PK", "AE", "GB", "US", "QA"] as const;
export type CountryCode = (typeof SUPPORTED_COUNTRIES)[number];
export const countryCodeSchema = z.enum(SUPPORTED_COUNTRIES);

export const LAUNCH_COUNTRIES: CountryCode[] = ["PK", "AE"];
export const FUTURE_COUNTRIES: CountryCode[] = ["GB"];
export const DEPRIORITIZED_COUNTRIES: CountryCode[] = ["US", "QA"];

export function isLaunchCountry(code: string): boolean {
  return LAUNCH_COUNTRIES.includes(code as CountryCode);
}

export function isFutureCountry(code: string): boolean {
  return FUTURE_COUNTRIES.includes(code as CountryCode);
}

export function isDeprioritizedCountry(code: string): boolean {
  return DEPRIORITIZED_COUNTRIES.includes(code as CountryCode);
}

export function isActiveCountry(code: string): boolean {
  return isLaunchCountry(code) || isFutureCountry(code);
}

export const COUNTRY_DETAILS: Record<CountryCode, { name: string; iso2: string; phonePrefix: string }> = {
  PK: { name: "Pakistan", iso2: "PK", phonePrefix: "+92" },
  AE: { name: "United Arab Emirates", iso2: "AE", phonePrefix: "+971" },
  GB: { name: "United Kingdom", iso2: "GB", phonePrefix: "+44" },
  US: { name: "United States", iso2: "US", phonePrefix: "+1" },
  QA: { name: "Qatar", iso2: "QA", phonePrefix: "+974" },
};

export const SUPPORTED_CURRENCIES = ["PKR", "AED", "GBP", "USD", "QAR"] as const;
export type CurrencyCode = (typeof SUPPORTED_CURRENCIES)[number];
export const currencyCodeSchema = z.enum(SUPPORTED_CURRENCIES);

export const STABLECOIN_CURRENCIES = ["USDT", "USDC"] as const;
export type StablecoinCurrency = (typeof STABLECOIN_CURRENCIES)[number];

export const WALLET_CURRENCIES = ["AED", "PKR", "GBP", "USD", "QAR", "USDT", "USDC"] as const;
export type WalletCurrency = (typeof WALLET_CURRENCIES)[number];
export const walletCurrencySchema = z.enum(WALLET_CURRENCIES);

export function isStablecoin(currency: string): currency is StablecoinCurrency {
  return STABLECOIN_CURRENCIES.includes(currency as StablecoinCurrency);
}

export interface CurrencyDetail {
  name: string;
  symbol: string;
  decimals: number;
  country?: CountryCode;
  isStablecoin?: boolean;
  peggedTo?: string;
}

export const CURRENCY_DETAILS: Record<string, CurrencyDetail> = {
  PKR: { name: "Pakistani Rupee", symbol: "₨", decimals: 2, country: "PK" },
  AED: { name: "UAE Dirham", symbol: "د.إ", decimals: 2, country: "AE" },
  GBP: { name: "British Pound", symbol: "£", decimals: 2, country: "GB" },
  USD: { name: "US Dollar", symbol: "$", decimals: 2, country: "US" },
  QAR: { name: "Qatari Riyal", symbol: "﷼", decimals: 2, country: "QA" },
  USDT: { name: "Tether USD", symbol: "₮", decimals: 6, isStablecoin: true, peggedTo: "USD" },
  USDC: { name: "USD Coin", symbol: "◎", decimals: 6, isStablecoin: true, peggedTo: "USD" },
};

export const ROLES = ["investor", "admin", "issuer", "agent", "cms"] as const;
export type Role = (typeof ROLES)[number];
export const roleSchema = z.enum(ROLES);

export const PERMISSIONS = [
  "users.view",
  "users.manage",
  "assets.view",
  "assets.manage",
  "compliance.view",
  "compliance.manage",
  "finance.view",
  "finance.manage",
  "fees.view",
  "fees.manage",
  "payments.view",
  "payments.manage",
  "fx.view",
  "fx.manage",
  "distributions.view",
  "distributions.manage",
  "marketplace.view",
  "marketplace.manage",
  "crypto.view",
  "crypto.manage",
  "support.view",
  "support.manage",
  "reconciliation.view",
  "roles.view",
  "roles.manage",
  "portfolio.view",
  "wallet.view",
  "wallet.manage",
  "kyc.submit",
  "trading.view",
  "trading.execute",
  "offers.view",
  "offers.manage",
  "microsites.view",
  "cms.view",
  "cms.manage",
  "cms.publish",
] as const;
export type Permission = (typeof PERMISSIONS)[number];
export const permissionSchema = z.enum(PERMISSIONS);

export const PERMISSION_CATEGORIES: Record<string, { label: string; permissions: Permission[] }> = {
  users: { label: "User Management", permissions: ["users.view", "users.manage"] },
  assets: { label: "Asset Management", permissions: ["assets.view", "assets.manage"] },
  compliance: { label: "Compliance & KYC", permissions: ["compliance.view", "compliance.manage", "kyc.submit"] },
  finance: { label: "Finance", permissions: ["finance.view", "finance.manage"] },
  fees: { label: "Fee Engine", permissions: ["fees.view", "fees.manage"] },
  payments: { label: "Payments", permissions: ["payments.view", "payments.manage"] },
  fx: { label: "FX & Currency", permissions: ["fx.view", "fx.manage"] },
  distributions: { label: "Distributions", permissions: ["distributions.view", "distributions.manage"] },
  marketplace: { label: "Marketplace", permissions: ["marketplace.view", "marketplace.manage"] },
  crypto: { label: "Crypto", permissions: ["crypto.view", "crypto.manage"] },
  support: { label: "Support", permissions: ["support.view", "support.manage"] },
  reconciliation: { label: "Reconciliation", permissions: ["reconciliation.view"] },
  roles: { label: "Roles & Permissions", permissions: ["roles.view", "roles.manage"] },
  portfolio: { label: "Portfolio", permissions: ["portfolio.view"] },
  wallet: { label: "Wallet", permissions: ["wallet.view", "wallet.manage"] },
  trading: { label: "Trading", permissions: ["trading.view", "trading.execute"] },
  offers: { label: "Offers", permissions: ["offers.view", "offers.manage"] },
  microsites: { label: "Microsites", permissions: ["microsites.view"] },
  cms: { label: "CMS", permissions: ["cms.view", "cms.manage", "cms.publish"] },
};

export const DEFAULT_ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  admin: [...PERMISSIONS],
  investor: [
    "portfolio.view", "wallet.view", "wallet.manage", "marketplace.view",
    "kyc.submit", "trading.view", "trading.execute", "distributions.view",
    "crypto.view", "support.view",
  ],
  issuer: [
    "assets.view", "assets.manage", "distributions.view", "distributions.manage",
  ],
  agent: [
    "offers.view", "offers.manage", "marketplace.view", "microsites.view",
  ],
  cms: [
    "cms.view", "cms.manage", "cms.publish",
  ],
};

export const BANK_ACCOUNT_COUNTRIES = ["UAE", "PK"] as const;
export type BankAccountCountry = (typeof BANK_ACCOUNT_COUNTRIES)[number];
export const bankAccountCountrySchema = z.enum(BANK_ACCOUNT_COUNTRIES);

export const COUNTRY_TO_BANK_COUNTRY: Partial<Record<CountryCode, BankAccountCountry>> = {
  AE: "UAE",
  PK: "PK",
};

export const COUNTRY_TO_CURRENCY: Record<CountryCode, CurrencyCode> = {
  PK: "PKR",
  AE: "AED",
  GB: "GBP",
  US: "USD",
  QA: "QAR",
};

export const CURRENCY_TO_COUNTRY: Record<CurrencyCode, CountryCode> = {
  PKR: "PK",
  AED: "AE",
  GBP: "GB",
  USD: "US",
  QAR: "QA",
};

export const ASSET_TYPES = ["real_estate", "equity", "debt", "fund", "commodity", "infrastructure"] as const;
export type AssetType = (typeof ASSET_TYPES)[number];
export const assetTypeSchema = z.enum(ASSET_TYPES);

export const ASSET_TYPE_LABELS: Record<AssetType, string> = {
  real_estate: "Real Estate",
  equity: "Equity",
  debt: "Debt / Sukuk",
  fund: "Fund",
  commodity: "Commodity",
  infrastructure: "Infrastructure",
};

export interface JurisdictionDoc {
  key: string;
  label: string;
  description: string;
  required: boolean;
}

export const JURISDICTION_DOCS: Record<CountryCode, JurisdictionDoc[]> = {
  PK: [
    { key: "secp_approval", label: "SECP Approval", description: "Securities and Exchange Commission of Pakistan approval letter", required: true },
    { key: "land_title", label: "Land Title Deed", description: "Verified property ownership deed registered with provincial authority", required: true },
    { key: "tax_clearance", label: "FBR Tax Clearance", description: "Federal Board of Revenue tax clearance certificate", required: true },
    { key: "valuation_report", label: "Valuation Report", description: "Independent property valuation by PBA-certified valuator", required: true },
    { key: "shariah_compliance", label: "Shariah Compliance Certificate", description: "Shariah board certification for Islamic finance compliance", required: false },
    { key: "environmental_noc", label: "Environmental NOC", description: "Environmental no-objection certificate from EPA", required: false },
  ],
  AE: [
    { key: "rera_registration", label: "RERA Registration", description: "Real Estate Regulatory Agency registration certificate", required: true },
    { key: "dfsa_approval", label: "DFSA/SCA Approval", description: "Dubai Financial Services Authority or Securities and Commodities Authority approval", required: true },
    { key: "title_deed", label: "Title Deed", description: "Dubai Land Department or relevant emirate title deed", required: true },
    { key: "valuation_report", label: "RICS Valuation", description: "Royal Institution of Chartered Surveyors valuation report", required: true },
    { key: "escrow_agreement", label: "Escrow Agreement", description: "Escrow account agreement with licensed bank", required: true },
    { key: "aml_compliance", label: "AML Compliance Report", description: "Anti-money laundering compliance assessment", required: false },
  ],
  GB: [
    { key: "fca_authorization", label: "FCA Authorization", description: "Financial Conduct Authority authorization or exemption letter", required: true },
    { key: "land_registry", label: "Land Registry Title", description: "HM Land Registry title register and plan", required: true },
    { key: "prospectus", label: "Offering Prospectus", description: "FCA-approved prospectus or exemption documentation", required: true },
    { key: "valuation_report", label: "RICS Valuation", description: "Royal Institution of Chartered Surveyors red book valuation", required: true },
    { key: "aml_kyc_policy", label: "AML/KYC Policy", description: "Firm AML and KYC policy documentation", required: true },
    { key: "epc_certificate", label: "EPC Certificate", description: "Energy Performance Certificate for the property", required: false },
    { key: "building_insurance", label: "Building Insurance", description: "Comprehensive building insurance policy", required: false },
  ],
  US: [
    { key: "sec_registration", label: "SEC Registration", description: "Securities and Exchange Commission registration or Regulation D exemption", required: true },
    { key: "title_insurance", label: "Title Insurance", description: "American Land Title Association title insurance policy", required: true },
    { key: "appraisal_report", label: "Appraisal Report", description: "USPAP-compliant independent appraisal report", required: true },
    { key: "ppm", label: "Private Placement Memorandum", description: "Regulation D private placement memorandum", required: true },
    { key: "operating_agreement", label: "Operating Agreement", description: "SPV/LLC operating agreement", required: true },
    { key: "environmental_assessment", label: "Environmental Assessment", description: "Phase I environmental site assessment", required: false },
  ],
  QA: [
    { key: "qfcra_approval", label: "QFCRA Approval", description: "Qatar Financial Centre Regulatory Authority approval", required: true },
    { key: "property_registration", label: "Property Registration", description: "Ministry of Justice property registration certificate", required: true },
    { key: "valuation_report", label: "Valuation Report", description: "Certified property valuation report", required: true },
    { key: "offering_document", label: "Offering Document", description: "QFCRA-approved offering document", required: true },
    { key: "shariah_compliance", label: "Shariah Compliance", description: "Shariah advisory board certification", required: false },
  ],
};
