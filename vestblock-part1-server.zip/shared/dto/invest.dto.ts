import { z } from "zod";

export const investRequestSchema = z.object({
  assetId: z.string().min(1),
  roundId: z.string().min(1),
  quantity: z.number().positive("Quantity must be positive"),
  sourceCurrency: z.string().optional(),
  fxQuoteId: z.string().optional(),
});

export type InvestRequest = z.infer<typeof investRequestSchema>;

export const investCheckResponseSchema = z.object({
  baseCurrency: z.string(),
  availableBalance: z.number(),
  hasWallet: z.boolean(),
  pricePerToken: z.number(),
  tokenDecimals: z.number(),
  totalSupply: z.number(),
  totalPropertyValue: z.number().nullable(),
  otherBalances: z.array(z.object({
    currency: z.string(),
    available: z.number(),
    fxRate: z.number().optional(),
    fxSpread: z.number().optional(),
    fxProvider: z.string().optional(),
  })).optional(),
});

export type InvestCheckResponse = z.infer<typeof investCheckResponseSchema>;

export const investResponseSchema = z.object({
  message: z.string(),
  investment: z.object({
    assetName: z.string(),
    assetSymbol: z.string(),
    quantity: z.number(),
    pricePerToken: z.string(),
    totalCost: z.string(),
    currency: z.string(),
  }),
});

export type InvestResponse = z.infer<typeof investResponseSchema>;
