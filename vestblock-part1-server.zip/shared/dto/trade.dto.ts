import { z } from "zod";

export const createExitWindowRequestSchema = z.object({
  assetId: z.string().min(1),
  name: z.string().min(1).max(200).optional(),
  opensAt: z.string(),
  closesAt: z.string(),
  exitFeePercent: z.number().min(0).max(100).optional(),
  quarter: z.string().optional(),
  eligibleJurisdictions: z.array(z.string()).optional(),
  lockupDays: z.number().int().min(0).optional(),
  cooldownHours: z.number().int().min(0).optional(),
  maxParticipants: z.number().int().min(1).optional(),
  minTradeAmount: z.number().positive().optional(),
  maxTradeAmount: z.number().positive().optional(),
});

export type CreateExitWindowRequest = z.infer<typeof createExitWindowRequestSchema>;

export const updateExitWindowRulesRequestSchema = z.object({
  eligibleJurisdictions: z.array(z.string()).optional(),
  lockupDays: z.number().int().min(0).optional(),
  cooldownHours: z.number().int().min(0).optional(),
  maxParticipants: z.number().int().min(1).optional(),
  minTradeAmount: z.number().positive().optional(),
  maxTradeAmount: z.number().positive().optional(),
});

export type UpdateExitWindowRulesRequest = z.infer<typeof updateExitWindowRulesRequestSchema>;

export const createTradeListingRequestSchema = z.object({
  exitWindowId: z.string().min(1),
  assetId: z.string().min(1),
  quantity: z.number().positive(),
  pricePerToken: z.string(),
  currency: z.string(),
});

export type CreateTradeListingRequest = z.infer<typeof createTradeListingRequestSchema>;

export const executeBuyRequestSchema = z.object({
  listingId: z.string().min(1),
  quantity: z.number().positive(),
});

export type ExecuteBuyRequest = z.infer<typeof executeBuyRequestSchema>;

export const tradeResponseSchema = z.object({
  message: z.string(),
  trade: z.object({
    assetName: z.string().optional(),
    assetSymbol: z.string().optional(),
    quantity: z.number(),
    pricePerToken: z.string(),
    totalCost: z.string(),
    currency: z.string(),
  }),
});

export type TradeResponse = z.infer<typeof tradeResponseSchema>;
