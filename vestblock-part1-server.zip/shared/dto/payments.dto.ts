import { z } from "zod";
import { walletCurrencySchema } from "../constants";

export const createPaymentIntentRequestSchema = z.object({
  amount: z.number().positive(),
  currency: walletCurrencySchema,
  paymentMethod: z.string().min(1),
  provider: z.string().optional(),
});

export type CreatePaymentIntentRequest = z.infer<typeof createPaymentIntentRequestSchema>;

export const paymentIntentResponseSchema = z.object({
  id: z.string(),
  userId: z.string(),
  amount: z.string(),
  currency: z.string(),
  countryCode: z.string().nullable().optional(),
  fee: z.string(),
  netAmount: z.string(),
  paymentMethod: z.string(),
  provider: z.string(),
  status: z.string(),
  ledgerTxId: z.string().nullable().optional(),
  reversalLedgerTxId: z.string().nullable().optional(),
  reversedAt: z.string().nullable().optional(),
  reversalReason: z.string().nullable().optional(),
  confirmedAt: z.string().nullable().optional(),
  createdAt: z.union([z.string(), z.date()]),
});

export type PaymentIntentResponse = z.infer<typeof paymentIntentResponseSchema>;

export const confirmPaymentRequestSchema = z.object({
  paymentIntentId: z.string().min(1),
  reference: z.string().optional(),
  proofUrl: z.string().optional(),
});

export type ConfirmPaymentRequest = z.infer<typeof confirmPaymentRequestSchema>;

export const reversePaymentRequestSchema = z.object({
  reason: z.string().min(1, "Reversal reason is required"),
});

export type ReversePaymentRequest = z.infer<typeof reversePaymentRequestSchema>;
