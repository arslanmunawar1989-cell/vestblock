import { z } from "zod";
import { roleSchema } from "../constants";

const USERNAME_REGEX = /^[a-zA-Z0-9_.-]+$/;
const PASSWORD_REGEX = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;

export const registerRequestSchema = z.object({
  username: z.string()
    .min(3, "Username must be at least 3 characters")
    .max(50, "Username must be at most 50 characters")
    .regex(USERNAME_REGEX, "Username can only contain letters, numbers, dots, hyphens, and underscores")
    .transform(v => v.trim()),
  password: z.string()
    .min(8, "Password must be at least 8 characters")
    .max(128, "Password must be at most 128 characters"),
  email: z.string()
    .email("Invalid email address")
    .max(254, "Email must be at most 254 characters")
    .transform(v => v.trim().toLowerCase()),
  fullName: z.string()
    .min(1, "Full name is required")
    .max(100, "Full name must be at most 100 characters")
    .transform(v => v.trim()),
  role: roleSchema.default("investor"),
});

export type RegisterRequest = z.infer<typeof registerRequestSchema>;

export const loginRequestSchema = z.object({
  username: z.string()
    .min(1, "Username is required")
    .max(50)
    .transform(v => v.trim()),
  password: z.string()
    .min(1, "Password is required")
    .max(128),
});

export type LoginRequest = z.infer<typeof loginRequestSchema>;

export const authUserSchema = z.object({
  id: z.string(),
  username: z.string(),
  email: z.string(),
  fullName: z.string(),
  role: roleSchema,
  isActive: z.boolean(),
  defaultCurrency: z.string().nullable().optional(),
  avatarUrl: z.string().nullable().optional(),
  bio: z.string().nullable().optional(),
  phone: z.string().nullable().optional(),
  notificationPreferences: z.any().nullable().optional(),
});

export type AuthUser = z.infer<typeof authUserSchema>;

export const authResponseSchema = z.object({
  user: authUserSchema,
  token: z.string(),
  primaryCountry: z.string(),
  defaultCurrency: z.string(),
  countryName: z.string(),
});

export type AuthResponse = z.infer<typeof authResponseSchema>;
