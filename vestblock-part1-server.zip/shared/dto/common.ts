import { z } from "zod";

export const errorResponseSchema = z.object({
  message: z.string(),
  errors: z.array(z.object({
    code: z.string().optional(),
    message: z.string(),
    path: z.array(z.union([z.string(), z.number()])).optional(),
  })).optional(),
  code: z.string().optional(),
});

export type ErrorResponse = z.infer<typeof errorResponseSchema>;

export const paginationQuerySchema = z.object({
  page: z.coerce.number().int().positive().default(1),
  limit: z.coerce.number().int().positive().max(100).default(20),
});

export type PaginationQuery = z.infer<typeof paginationQuerySchema>;

export const idParamSchema = z.object({
  id: z.string().min(1),
});

export type IdParam = z.infer<typeof idParamSchema>;

export const successResponseSchema = z.object({
  message: z.string(),
});

export type SuccessResponse = z.infer<typeof successResponseSchema>;
