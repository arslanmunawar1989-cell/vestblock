import { z } from "zod";

export const creditDistributionRequestSchema = z.object({
  assetId: z.string().min(1),
  perTokenAmount: z.number().positive("Per-token amount must be positive"),
  distributionDate: z.string().optional(),
});

export type CreditDistributionRequest = z.infer<typeof creditDistributionRequestSchema>;

export const creditDistributionResponseSchema = z.object({
  message: z.string(),
  summary: z.object({
    assetName: z.string(),
    baseCurrency: z.string(),
    perTokenAmount: z.number(),
    totalDistributed: z.number(),
    recipientCount: z.number(),
    autoConvertedCount: z.number(),
  }),
  results: z.array(z.object({
    userId: z.string(),
    amount: z.number(),
    currency: z.string(),
    autoConverted: z.boolean(),
    convertedTo: z.string().optional(),
    convertedAmount: z.number().optional(),
  })),
});

export type CreditDistributionResponse = z.infer<typeof creditDistributionResponseSchema>;
