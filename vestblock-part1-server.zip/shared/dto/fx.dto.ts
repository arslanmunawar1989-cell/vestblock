import { z } from "zod";
import { walletCurrencySchema } from "../constants";

export const fxRateQuerySchema = z.object({
  from: z.string().min(1),
  to: z.string().min(1),
});

export type FxRateQuery = z.infer<typeof fxRateQuerySchema>;

export const fxRateResponseSchema = z.object({
  from: z.string(),
  to: z.string(),
  rate: z.string(),
  spread: z.string(),
  provider: z.string(),
  sourceLabel: z.string().optional(),
  fetchedAt: z.string().optional(),
});

export type FxRateResponse = z.infer<typeof fxRateResponseSchema>;

export const fxQuoteRequestSchema = z.object({
  fromCurrency: walletCurrencySchema,
  toCurrency: walletCurrencySchema,
  amount: z.number().positive(),
});

export type FxQuoteRequest = z.infer<typeof fxQuoteRequestSchema>;

export const fxConvertRequestSchema = z.object({
  quoteId: z.string().min(1, "quoteId is required"),
});

export type FxConvertRequest = z.infer<typeof fxConvertRequestSchema>;
