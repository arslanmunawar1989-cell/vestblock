import { z } from "zod";

export const assetResponseSchema = z.object({
  id: z.string(),
  name: z.string(),
  symbol: z.string(),
  assetType: z.string(),
  status: z.string(),
  pricePerToken: z.string(),
  totalTokens: z.string(),
  tokensAvailable: z.string().nullable().optional(),
  description: z.string().nullable().optional(),
  imageUrl: z.string().nullable().optional(),
  baseCurrency: z.string(),
  country: z.string().nullable().optional(),
  issuer: z.string().nullable().optional(),
});

export type AssetResponse = z.infer<typeof assetResponseSchema>;

export const marketplaceAssetsResponseSchema = z.array(assetResponseSchema);

export type MarketplaceAssetsResponse = z.infer<typeof marketplaceAssetsResponseSchema>;

export const countrySettingResponseSchema = z.object({
  code: z.string(),
  name: z.string(),
  isVisible: z.boolean(),
});

export type CountrySettingResponse = z.infer<typeof countrySettingResponseSchema>;

export const toggleCountryRequestSchema = z.object({
  countryCode: z.string().min(2).max(2),
  isVisible: z.boolean(),
});

export type ToggleCountryRequest = z.infer<typeof toggleCountryRequestSchema>;
