import { z } from "zod";
import { walletCurrencySchema } from "../constants";

export const walletBalanceSchema = z.object({
  id: z.string(),
  userId: z.string(),
  currency: z.string(),
  available: z.string(),
  pending: z.string(),
  total: z.string(),
});

export type WalletBalance = z.infer<typeof walletBalanceSchema>;

export const walletSummaryResponseSchema = z.object({
  accounts: z.array(walletBalanceSchema),
});

export type WalletSummaryResponse = z.infer<typeof walletSummaryResponseSchema>;

export const walletTransactionSchema = z.object({
  id: z.string(),
  walletAccountId: z.string(),
  type: z.string(),
  amount: z.string(),
  currency: z.string(),
  status: z.string(),
  referenceId: z.string().nullable().optional(),
  description: z.string().nullable().optional(),
  metadata: z.any().nullable().optional(),
  createdAt: z.union([z.string(), z.date()]),
});

export type WalletTransactionDTO = z.infer<typeof walletTransactionSchema>;

export const withdrawalRequestSchema = z.object({
  bankAccountId: z.string().min(1),
  amount: z.number().positive(),
  currency: walletCurrencySchema,
});

export type WithdrawalRequest = z.infer<typeof withdrawalRequestSchema>;

export const withdrawalResponseSchema = z.object({
  withdrawal: z.object({
    id: z.string(),
    amount: z.string(),
    currency: z.string(),
    fee: z.string(),
    netAmount: z.string(),
    status: z.string(),
  }),
  message: z.string(),
});

export type WithdrawalResponse = z.infer<typeof withdrawalResponseSchema>;
