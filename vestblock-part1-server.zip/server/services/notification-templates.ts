import { CURRENCY_DETAILS, COUNTRY_TO_CURRENCY, type CurrencyCode, type CountryCode } from "@shared/constants";

function fmtCurrency(amount: number | string, currency: string): string {
  const num = typeof amount === "string" ? parseFloat(amount) : amount;
  if (isNaN(num)) return `${currency} 0.00`;
  const details = CURRENCY_DETAILS[currency as CurrencyCode];
  const symbol = details?.symbol || currency;
  const formatted = Math.abs(num).toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  return `${symbol} ${formatted}`;
}

export const NotificationTemplates = {
  deposit: {
    confirmed(currency: string, netAmount: string | number) {
      return {
        type: "payment" as const,
        title: "Funds Added",
        message: `${fmtCurrency(netAmount, currency)} has been added to your wallet.`,
      };
    },
    failed(currency: string, amount: string | number, reason?: string) {
      return {
        type: "payment" as const,
        title: "Deposit Failed",
        message: `Your deposit of ${fmtCurrency(amount, currency)} was not approved.${reason ? ` ${reason}` : ""}`,
      };
    },
    cardConfirmed(currency: string, netAmount: string | number) {
      return {
        type: "payment" as const,
        title: "Card Deposit Confirmed",
        message: `${fmtCurrency(netAmount, currency)} has been added to your wallet via Stripe.`,
      };
    },
    achReturned(currency: string, amount: string | number, returnCode: string, returnReason: string) {
      return {
        type: "payment" as const,
        title: "ACH Transfer Returned",
        message: `Your ACH deposit of ${fmtCurrency(amount, currency)} was returned (${returnCode}: ${returnReason}).`,
      };
    },
  },

  crypto: {
    rejected(tokenSymbol: string, reason?: string) {
      return {
        type: "payment" as const,
        title: "Crypto Deposit Rejected",
        message: `Your deposit request was automatically rejected: ${reason || "AML policy violation"}`,
      };
    },
    underReview(tokenSymbol: string, amount: number | string) {
      return {
        type: "payment" as const,
        title: "Crypto Deposit Under Review",
        message: `Your ${tokenSymbol} deposit of ${fmtCurrency(amount, "USD")} is under compliance review. You will be notified once cleared.`,
      };
    },
    holdPlaced(tokenSymbol: string, amount: number | string) {
      return {
        type: "payment" as const,
        title: "Crypto Deposit Under Review",
        message: `Your ${tokenSymbol} deposit of ${fmtCurrency(amount, "USD")} has been placed under compliance review.`,
      };
    },
    cleared(tokenSymbol: string, amount: number | string) {
      return {
        type: "payment" as const,
        title: "Crypto Deposit Cleared",
        message: `Your ${tokenSymbol} deposit of ${fmtCurrency(amount, "USD")} has been cleared by compliance and is awaiting confirmation.`,
      };
    },
    confirmed(tokenSymbol: string, amount: number | string, chainId: string) {
      return {
        type: "payment" as const,
        title: "Crypto Deposit Confirmed",
        message: `Your ${tokenSymbol} deposit of ${fmtCurrency(amount, "USD")} on ${chainId} has been confirmed and credited to your USD wallet.`,
      };
    },
    depositRejected(tokenSymbol: string, amount: number | string, chainId: string, reason?: string) {
      return {
        type: "payment" as const,
        title: "Crypto Deposit Rejected",
        message: `Your ${tokenSymbol} deposit of ${fmtCurrency(amount, "USD")} on ${chainId} has been rejected.${reason ? ` ${reason}` : ""}`,
      };
    },
  },

  withdrawal: {
    requested(amount: number | string, currency: string, bankName: string, label: string) {
      return {
        type: "withdrawal_requested" as const,
        title: "Withdrawal Requested",
        message: `Your withdrawal request for ${fmtCurrency(amount, currency)} has been submitted for review.`,
      };
    },
    approved(amount: string | number, currency: string, netAmount: string | number) {
      return {
        type: "withdrawal_approved" as const,
        title: "Withdrawal Approved",
        message: `Your withdrawal of ${fmtCurrency(amount, currency)} has been approved. Net payout: ${fmtCurrency(netAmount, currency)}.`,
      };
    },
    declined(amount: string | number, currency: string, notes?: string) {
      return {
        type: "withdrawal_declined" as const,
        title: "Withdrawal Declined",
        message: `Your withdrawal of ${fmtCurrency(amount, currency)} was declined.${notes ? ` Reason: ${notes}` : ""}`,
      };
    },
    paid(netAmount: string | number, currency: string, payoutReference: string) {
      return {
        type: "withdrawal_paid" as const,
        title: "Withdrawal Paid",
        message: `Your withdrawal of ${fmtCurrency(netAmount, currency)} has been paid. Reference: ${payoutReference}`,
      };
    },
  },

  distribution: {
    received(
      assetName: string,
      amount: number | string,
      currency: string,
      autoConverted?: boolean,
      convertedTo?: string,
      convertedAmount?: number
    ) {
      const base = `You received a distribution of ${fmtCurrency(amount, currency)} from ${assetName}`;
      if (autoConverted && convertedTo && convertedAmount != null) {
        return {
          type: "distribution" as const,
          title: "Distribution Received",
          message: `${base}, auto-converted to ${fmtCurrency(convertedAmount, convertedTo)}`,
        };
      }
      return {
        type: "distribution" as const,
        title: "Distribution Received",
        message: base,
      };
    },
  },

  bankAccount: {
    verified(label: string, bankName: string) {
      return {
        type: "bank_account_verification" as const,
        title: "Bank Account Verified",
        message: `Your bank account "${label}" (${bankName}) has been verified and can now be used for withdrawals.`,
      };
    },
    rejected(label: string, bankName: string, notes?: string) {
      return {
        type: "bank_account_verification" as const,
        title: "Bank Account Rejected",
        message: `Your bank account "${label}" (${bankName}) was rejected.${notes ? ` Reason: ${notes}` : " Please check the details and resubmit."}`,
      };
    },
  },

  kyc: {
    approved() {
      return {
        type: "kyc" as const,
        title: "KYC Approved",
        message: "Your identity verification has been approved. You can now access all platform features.",
      };
    },
    rejected(reason?: string) {
      return {
        type: "kyc" as const,
        title: "KYC Rejected",
        message: `Your identity verification was rejected.${reason ? ` Reason: ${reason}` : " Please review and resubmit your documents."}`,
      };
    },
  },

  investment: {
    confirmed(assetName: string, quantity: number, totalCost: number | string, currency: string) {
      return {
        type: "investment" as const,
        title: "Investment Confirmed",
        message: `You have successfully invested in ${quantity} token(s) of ${assetName} for ${fmtCurrency(totalCost, currency)}.`,
      };
    },
  },
};
