import webPush from "web-push";
import { storage } from "../storage";
import type { NotificationPreferences } from "@shared/schema";

let vapidConfigured = false;

function ensureVapidConfigured() {
  if (vapidConfigured) return true;
  const publicKey = process.env.VAPID_PUBLIC_KEY;
  const privateKey = process.env.VAPID_PRIVATE_KEY;
  if (!publicKey || !privateKey) return false;
  webPush.setVapidDetails(
    "mailto:noreply@vestblock.io",
    publicKey,
    privateKey
  );
  vapidConfigured = true;
  return true;
}

export function getVapidPublicKey(): string | null {
  return process.env.VAPID_PUBLIC_KEY || null;
}

export async function sendPushToUser(
  userId: string,
  payload: { title: string; body: string; url?: string; tag?: string }
): Promise<number> {
  if (!ensureVapidConfigured()) return 0;

  const subscriptions = await storage.getPushSubscriptionsByUser(userId);
  if (!subscriptions.length) return 0;

  let sent = 0;
  for (const sub of subscriptions) {
    try {
      await webPush.sendNotification(
        {
          endpoint: sub.endpoint,
          keys: { p256dh: sub.p256dh, auth: sub.auth },
        },
        JSON.stringify(payload)
      );
      sent++;
    } catch (err: any) {
      if (err.statusCode === 410 || err.statusCode === 404) {
        await storage.deletePushSubscription(sub.endpoint);
      }
    }
  }
  return sent;
}

async function sendEmailFallback(userId: string, title: string, message: string): Promise<boolean> {
  try {
    const user = await storage.getUser(userId);
    if (!user?.email) return false;

    const smtpHost = process.env.SMTP_HOST;
    const smtpUser = process.env.SMTP_USER;
    const smtpPass = process.env.SMTP_PASS;

    if (!smtpHost || !smtpUser || !smtpPass) {
      return false;
    }

    const nodemailer = await import("nodemailer");
    const transporter = nodemailer.createTransport({
      host: smtpHost,
      port: parseInt(process.env.SMTP_PORT || "587"),
      secure: process.env.SMTP_SECURE === "true",
      auth: { user: smtpUser, pass: smtpPass },
    });

    await transporter.sendMail({
      from: process.env.SMTP_FROM || `"VestBlock" <noreply@vestblock.io>`,
      to: user.email,
      subject: title,
      text: message,
      html: `
        <div style="font-family: sans-serif; max-width: 480px; margin: 0 auto; padding: 24px;">
          <div style="background: linear-gradient(135deg, #10b981, #0ea5e9); padding: 16px; border-radius: 8px; margin-bottom: 24px;">
            <h2 style="color: white; margin: 0; font-size: 18px;">VestBlock</h2>
          </div>
          <h3 style="margin: 0 0 12px;">${title}</h3>
          <p style="color: #64748b; line-height: 1.6;">${message}</p>
          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 24px 0;" />
          <p style="font-size: 12px; color: #94a3b8;">
            This notification was sent because push notifications could not be delivered to your device.
          </p>
        </div>
      `,
    });
    return true;
  } catch (err) {
    console.warn(`[email-fallback] Failed to send email to user ${userId}:`, (err as Error).message);
    return false;
  }
}

export async function sendNotificationWithFallback(
  userId: string,
  notification: { type: string; title: string; message: string; relatedEntityId?: string; relatedEntityType?: string }
): Promise<void> {
  await storage.createNotification({
    userId,
    type: notification.type,
    title: notification.title,
    message: notification.message,
    relatedEntityId: notification.relatedEntityId || null,
    relatedEntityType: notification.relatedEntityType || null,
  });

  const user = await storage.getUser(userId);
  if (!user) return;

  const prefs = (user.notificationPreferences as NotificationPreferences) || { push: true, email: true };

  let pushSent = 0;
  if (prefs.push !== false) {
    pushSent = await sendPushToUser(userId, {
      title: notification.title,
      body: notification.message,
      url: "/investor",
      tag: notification.type,
    });
  }

  if (pushSent === 0 && prefs.email !== false) {
    await sendEmailFallback(userId, notification.title, notification.message);
  }
}

export function generateVapidKeys(): { publicKey: string; privateKey: string } {
  return webPush.generateVAPIDKeys();
}
