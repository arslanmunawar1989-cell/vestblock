import { storage } from "../storage";
import { db } from "../db";
import {
  tokens, tokenHoldings, tokenLedgerEntries, tokenCorporateActions,
  walletAccounts, walletTransactions, ledgerEntries,
} from "@shared/schema";
import { eq, and, sql } from "drizzle-orm";
import type { Token, TokenHolding, TokenCorporateAction } from "@shared/schema";

interface CorporateActionResult {
  action: TokenCorporateAction;
  holdersAffected: number;
  previousTotalSupply: string;
  newTotalSupply: string;
  holderDetails: Array<{
    userId: string;
    previousBalance: string;
    newBalance: string;
  }>;
}

interface BuybackTarget {
  userId: string;
  amount: string;
}

interface BuybackResult extends CorporateActionResult {
  pricePerToken: string;
  totalPayout: string;
  payoutCurrency: string;
  walletCredits: Array<{
    userId: string;
    tokensBurned: string;
    payoutAmount: string;
    walletAccountId: string;
  }>;
}

export async function executeSplit(
  tokenId: string,
  ratioNumerator: number,
  ratioDenominator: number,
  executedBy: string,
  reason?: string
): Promise<CorporateActionResult> {
  if (ratioNumerator <= 0 || ratioDenominator <= 0) {
    throw new Error("Ratio numerator and denominator must be positive integers");
  }
  if (ratioNumerator <= ratioDenominator) {
    throw new Error("For a split, numerator must be greater than denominator (e.g., 10:1 means each token becomes 10)");
  }

  return executeRatioAction(tokenId, "SPLIT", ratioNumerator, ratioDenominator, executedBy, reason);
}

export async function executeMerge(
  tokenId: string,
  ratioNumerator: number,
  ratioDenominator: number,
  executedBy: string,
  reason?: string
): Promise<CorporateActionResult> {
  if (ratioNumerator <= 0 || ratioDenominator <= 0) {
    throw new Error("Ratio numerator and denominator must be positive integers");
  }
  if (ratioNumerator >= ratioDenominator) {
    throw new Error("For a merge, numerator must be less than denominator (e.g., 1:10 means 10 tokens become 1)");
  }

  return executeRatioAction(tokenId, "MERGE", ratioNumerator, ratioDenominator, executedBy, reason);
}

export async function executeBuyback(
  tokenId: string,
  targets: BuybackTarget[],
  pricePerToken: string,
  currency: string,
  executedBy: string,
  reason?: string
): Promise<BuybackResult> {
  const token = await storage.getToken(tokenId);
  if (!token) throw new Error(`Token ${tokenId} not found`);
  if (token.frozen) throw new Error(`Token ${tokenId} is frozen, cannot execute buyback`);

  if (parseFloat(pricePerToken) <= 0) {
    throw new Error("Price per token must be positive");
  }

  const holdings = await storage.getTokenHoldingsByToken(tokenId);
  const holdingMap = new Map(holdings.map(h => [h.userId, h]));

  for (const target of targets) {
    const holding = holdingMap.get(target.userId);
    if (!holding) throw new Error(`User ${target.userId} does not hold token ${tokenId}`);
    const burnAmount = parseFloat(target.amount);
    if (burnAmount <= 0) throw new Error(`Burn amount must be positive for user ${target.userId}`);
    if (burnAmount > parseFloat(holding.balance)) {
      throw new Error(`User ${target.userId} holds ${holding.balance} tokens, cannot buy back ${target.amount}`);
    }
  }

  return db.transaction(async (tx) => {
    const previousTotalSupply = token.totalSupply;
    let totalBurned = 0;
    let totalPayout = 0;
    const holderDetails: CorporateActionResult["holderDetails"] = [];
    const walletCredits: BuybackResult["walletCredits"] = [];

    for (const target of targets) {
      const holding = holdingMap.get(target.userId)!;
      const burnAmount = parseFloat(target.amount);
      const currentBalance = parseFloat(holding.balance);
      const newBalance = (currentBalance - burnAmount).toFixed(6);
      const payoutAmount = Math.round(burnAmount * parseFloat(pricePerToken) * 100) / 100;

      const [existingHolding] = await tx.select().from(tokenHoldings)
        .where(and(eq(tokenHoldings.userId, target.userId), eq(tokenHoldings.tokenId, tokenId)));
      if (existingHolding) {
        await tx.update(tokenHoldings).set({ balance: newBalance })
          .where(eq(tokenHoldings.id, existingHolding.id));
      } else {
        await tx.insert(tokenHoldings).values({ userId: target.userId, tokenId, balance: newBalance });
      }

      await tx.insert(tokenLedgerEntries).values({

        tokenId,
        fromUserId: target.userId,
        toUserId: null,
        amount: burnAmount.toFixed(6),
        reason: "corporate_action_buyback",
        refId: null,
      });

      const [wallet] = await tx.select().from(walletAccounts)
        .where(and(eq(walletAccounts.userId, target.userId), eq(walletAccounts.currency, currency)));
      let walletId: string;
      if (wallet) {
        walletId = wallet.id;
      } else {
        const [newWallet] = await tx.insert(walletAccounts).values({ userId: target.userId, currency }).returning();
        walletId = newWallet.id;
      }

      await tx.insert(walletTransactions).values({
        walletAccountId: walletId,
        type: "BUYBACK",
        amount: payoutAmount.toFixed(2),
        currency,
        status: "COMPLETED",
        referenceId: `buyback_${tokenId}_${Date.now()}_${target.userId}`,
        description: `Buyback of ${burnAmount.toFixed(6)} ${token.tokenSymbol} at ${pricePerToken} ${currency}/token`,
        metadata: { tokenId, tokenSymbol: token.tokenSymbol, burnAmount: burnAmount.toFixed(6), pricePerToken },
      });

      await tx.insert(ledgerEntries).values({

        walletAccountId: walletId,
        ledgerTxId: `buyback_${tokenId}_${Date.now()}_${target.userId}`,
        direction: "CREDIT",
        amount: payoutAmount.toFixed(2),
        currency,
        status: "POSTED",
        entryType: "BUYBACK",
        description: `Buyback of ${burnAmount.toFixed(6)} ${token.tokenSymbol}`,
      });

      totalBurned += burnAmount;
      totalPayout += payoutAmount;
      holderDetails.push({ userId: target.userId, previousBalance: holding.balance, newBalance });
      walletCredits.push({
        userId: target.userId,
        tokensBurned: burnAmount.toFixed(6),
        payoutAmount: payoutAmount.toFixed(2),
        walletAccountId: walletId,
      });
    }

    const newTotalSupply = (parseFloat(previousTotalSupply) - totalBurned).toFixed(6);
    await tx.update(tokens).set({ totalSupply: newTotalSupply }).where(eq(tokens.id, tokenId));

    const actionReport = {
      tokenId,
      tokenSymbol: token.tokenSymbol,
      actionType: "BUYBACK",
      pricePerToken,
      currency,
      totalBurned: totalBurned.toFixed(6),
      totalPayout: totalPayout.toFixed(2),
      previousTotalSupply,
      newTotalSupply,
      holdersAffected: holderDetails.length,
      holderDetails,
      walletCredits,
      executedAt: new Date().toISOString(),
      executedBy,
      reason: reason || null,
    };

    const [action] = await tx.insert(tokenCorporateActions).values({

      tokenId,
      actionType: "BUYBACK",
      ratioNumerator: 0,
      ratioDenominator: 1,
      previousTotalSupply,
      newTotalSupply,
      holdersAffected: holderDetails.length,
      reason: reason || null,
      executedBy,
      actionReport,
    }).returning();

    return {
      action,
      holdersAffected: holderDetails.length,
      previousTotalSupply,
      newTotalSupply,
      holderDetails,
      pricePerToken,
      totalPayout: totalPayout.toFixed(2),
      payoutCurrency: currency,
      walletCredits,
    };
  });
}

export async function executeRedemption(
  tokenId: string,
  userId: string,
  amount: string,
  pricePerToken: string,
  currency: string,
  executedBy: string,
  reason?: string
): Promise<BuybackResult> {
  const token = await storage.getToken(tokenId);
  if (!token) throw new Error(`Token ${tokenId} not found`);
  if (token.frozen) throw new Error(`Token ${tokenId} is frozen, cannot execute redemption`);

  const redeemAmount = parseFloat(amount);
  if (redeemAmount <= 0) throw new Error("Redemption amount must be positive");
  if (parseFloat(pricePerToken) <= 0) throw new Error("Price per token must be positive");

  const holdings = await storage.getTokenHoldingsByToken(tokenId);
  const holding = holdings.find(h => h.userId === userId);
  if (!holding) throw new Error(`User ${userId} does not hold token ${tokenId}`);

  const currentBalance = parseFloat(holding.balance);
  if (redeemAmount > currentBalance) {
    throw new Error(`User holds ${holding.balance} tokens, cannot redeem ${amount}`);
  }

  const previousTotalSupply = token.totalSupply;

  return db.transaction(async (tx) => {
    const newBalance = (currentBalance - redeemAmount).toFixed(6);
    const payoutAmount = Math.round(redeemAmount * parseFloat(pricePerToken) * 100) / 100;

    await tx.update(tokenHoldings).set({ balance: newBalance })
      .where(and(eq(tokenHoldings.userId, userId), eq(tokenHoldings.tokenId, tokenId)));

    await tx.insert(tokenLedgerEntries).values({

      tokenId,
      fromUserId: userId,
      toUserId: null,
      amount: redeemAmount.toFixed(6),
      reason: "corporate_action_redemption",
      refId: null,
    });

    const [wallet] = await tx.select().from(walletAccounts)
      .where(and(eq(walletAccounts.userId, userId), eq(walletAccounts.currency, currency)));
    let walletId: string;
    if (wallet) {
      walletId = wallet.id;
    } else {
      const [newWallet] = await tx.insert(walletAccounts).values({ userId, currency }).returning();
      walletId = newWallet.id;
    }

    await tx.insert(walletTransactions).values({
      walletAccountId: walletId,
      type: "REDEMPTION",
      amount: payoutAmount.toFixed(2),
      currency,
      status: "COMPLETED",
      referenceId: `redemption_${tokenId}_${Date.now()}`,
      description: `Redemption of ${redeemAmount.toFixed(6)} ${token.tokenSymbol} at ${pricePerToken} ${currency}/token`,
      metadata: { tokenId, tokenSymbol: token.tokenSymbol, redeemAmount: redeemAmount.toFixed(6), pricePerToken },
    });

    await tx.insert(ledgerEntries).values({

      walletAccountId: walletId,
      ledgerTxId: `redemption_${tokenId}_${Date.now()}`,
      direction: "CREDIT",
      amount: payoutAmount.toFixed(2),
      currency,
      status: "POSTED",
      entryType: "REDEMPTION",
      description: `Redemption of ${redeemAmount.toFixed(6)} ${token.tokenSymbol}`,
    });

    const newTotalSupply = (parseFloat(previousTotalSupply) - redeemAmount).toFixed(6);
    await tx.update(tokens).set({ totalSupply: newTotalSupply }).where(eq(tokens.id, tokenId));

    const holderDetails = [{ userId, previousBalance: holding.balance, newBalance }];

    const actionReport = {
      tokenId,
      tokenSymbol: token.tokenSymbol,
      actionType: "REDEMPTION",
      pricePerToken,
      currency,
      redeemAmount: redeemAmount.toFixed(6),
      payoutAmount: payoutAmount.toFixed(2),
      previousTotalSupply,
      newTotalSupply,
      holdersAffected: 1,
      holderDetails,
      executedAt: new Date().toISOString(),
      executedBy,
      reason: reason || null,
    };

    const [action] = await tx.insert(tokenCorporateActions).values({

      tokenId,
      actionType: "REDEMPTION",
      ratioNumerator: 0,
      ratioDenominator: 1,
      previousTotalSupply,
      newTotalSupply,
      holdersAffected: 1,
      reason: reason || null,
      executedBy,
      actionReport,
    }).returning();

    return {
      action,
      holdersAffected: 1,
      previousTotalSupply,
      newTotalSupply,
      holderDetails,
      pricePerToken,
      totalPayout: payoutAmount.toFixed(2),
      payoutCurrency: currency,
      walletCredits: [{
        userId,
        tokensBurned: redeemAmount.toFixed(6),
        payoutAmount: payoutAmount.toFixed(2),
        walletAccountId: walletId,
      }],
    };
  });
}

export async function executeBurnOnClosure(
  tokenId: string,
  executedBy: string,
  reason?: string
): Promise<CorporateActionResult> {
  const token = await storage.getToken(tokenId);
  if (!token) throw new Error(`Token ${tokenId} not found`);
  if (token.frozen) throw new Error(`Token ${tokenId} is already frozen — cannot execute burn-on-closure on a closed token`);

  const holdings = await storage.getTokenHoldingsByToken(tokenId);
  const activeHoldings = holdings.filter(h => parseFloat(h.balance) > 0);

  if (activeHoldings.length === 0) {
    throw new Error("No active holdings to burn");
  }

  const previousTotalSupply = token.totalSupply;

  return db.transaction(async (tx) => {
    const holderDetails: CorporateActionResult["holderDetails"] = [];

    for (const holding of activeHoldings) {
      const burnAmount = parseFloat(holding.balance);

      await tx.update(tokenHoldings).set({ balance: "0" })
        .where(eq(tokenHoldings.id, holding.id));

      await tx.insert(tokenLedgerEntries).values({

        tokenId,
        fromUserId: holding.userId,
        toUserId: null,
        amount: burnAmount.toFixed(6),
        reason: "corporate_action_burn_closure",
        refId: null,
      });

      holderDetails.push({ userId: holding.userId, previousBalance: holding.balance, newBalance: "0" });
    }

    await tx.update(tokens).set({ totalSupply: "0", frozen: true }).where(eq(tokens.id, tokenId));

    const actionReport = {
      tokenId,
      tokenSymbol: token.tokenSymbol,
      actionType: "BURN_CLOSURE",
      previousTotalSupply,
      newTotalSupply: "0",
      holdersAffected: holderDetails.length,
      holderDetails,
      executedAt: new Date().toISOString(),
      executedBy,
      reason: reason || "Fund/SPV closure — all tokens burned",
    };

    const [action] = await tx.insert(tokenCorporateActions).values({

      tokenId,
      actionType: "BURN_CLOSURE",
      ratioNumerator: 0,
      ratioDenominator: 1,
      previousTotalSupply,
      newTotalSupply: "0",
      holdersAffected: holderDetails.length,
      reason: reason || "Fund/SPV closure — all tokens burned",
      executedBy,
      actionReport,
    }).returning();

    return {
      action,
      holdersAffected: holderDetails.length,
      previousTotalSupply,
      newTotalSupply: "0",
      holderDetails,
    };
  });
}

async function executeRatioAction(
  tokenId: string,
  actionType: "SPLIT" | "MERGE",
  ratioNumerator: number,
  ratioDenominator: number,
  executedBy: string,
  reason?: string
): Promise<CorporateActionResult> {
  const token = await storage.getToken(tokenId);
  if (!token) throw new Error(`Token ${tokenId} not found`);
  if (token.frozen) throw new Error(`Token ${tokenId} is frozen, cannot execute corporate action`);

  const ratio = ratioNumerator / ratioDenominator;
  const previousTotalSupply = token.totalSupply;
  const newTotalSupply = (parseFloat(previousTotalSupply) * ratio).toFixed(6);

  const holdings = await storage.getTokenHoldingsByToken(tokenId);

  return db.transaction(async (tx) => {
    const holderDetails: CorporateActionResult["holderDetails"] = [];

    for (const holding of holdings) {
      const previousBalance = holding.balance;
      const newBalance = (parseFloat(previousBalance) * ratio).toFixed(6);

      await tx.update(tokenHoldings).set({ balance: newBalance })
        .where(eq(tokenHoldings.id, holding.id));

      const adjustmentAmount = (parseFloat(newBalance) - parseFloat(previousBalance)).toFixed(6);

      if (parseFloat(adjustmentAmount) > 0) {
        await tx.insert(tokenLedgerEntries).values({
  
          tokenId,
          fromUserId: null,
          toUserId: holding.userId,
          amount: adjustmentAmount,
          reason: `corporate_action_${actionType.toLowerCase()}`,
          refId: null,
        });
      } else if (parseFloat(adjustmentAmount) < 0) {
        await tx.insert(tokenLedgerEntries).values({
  
          tokenId,
          fromUserId: holding.userId,
          toUserId: null,
          amount: Math.abs(parseFloat(adjustmentAmount)).toFixed(6),
          reason: `corporate_action_${actionType.toLowerCase()}`,
          refId: null,
        });
      }

      holderDetails.push({ userId: holding.userId, previousBalance, newBalance });
    }

    await tx.update(tokens).set({ totalSupply: newTotalSupply }).where(eq(tokens.id, tokenId));

    const actionReport = {
      tokenId,
      tokenSymbol: token.tokenSymbol,
      actionType,
      ratio: `${ratioNumerator}:${ratioDenominator}`,
      previousTotalSupply,
      newTotalSupply,
      holdersAffected: holderDetails.length,
      holderDetails,
      executedAt: new Date().toISOString(),
      executedBy,
      reason: reason || null,
    };

    const [action] = await tx.insert(tokenCorporateActions).values({

      tokenId,
      actionType,
      ratioNumerator,
      ratioDenominator,
      previousTotalSupply,
      newTotalSupply,
      holdersAffected: holderDetails.length,
      reason: reason || null,
      executedBy,
      actionReport,
    }).returning();

    return {
      action,
      holdersAffected: holderDetails.length,
      previousTotalSupply,
      newTotalSupply,
      holderDetails,
    };
  });
}
