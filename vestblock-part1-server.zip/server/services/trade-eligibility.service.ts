import { storage } from "../storage";
import { buildPolicyContext, canTrade as canTradePolicy } from "./policy.service";
import { canTransfer } from "./transfer-restrictions.service";
import type { ExitWindow, User } from "@shared/schema";

export interface EligibilityCheck {
  check: string;
  passed: boolean;
  reason?: string;
  code?: string;
  details?: Record<string, unknown>;
}

export interface TradeEligibilityResult {
  eligible: boolean;
  checks: EligibilityCheck[];
}

function pass(check: string): EligibilityCheck {
  return { check, passed: true };
}

function fail(check: string, reason: string, code: string, details?: Record<string, unknown>): EligibilityCheck {
  return { check, passed: false, reason, code, details };
}

function getUserJurisdiction(user: User): string | null {
  return (user as any).countryOfResidence || user.nationality || (user as any).taxResidency || null;
}

export async function checkTradeEligibility(opts: {
  userId: string;
  exitWindowId: string;
  assetId: string;
  side: "sell" | "buy";
  quantity?: number;
  pricePerToken?: number;
  tokenId?: string;
  counterpartyId?: string;
}): Promise<TradeEligibilityResult> {
  const checks: EligibilityCheck[] = [];

  const user = await storage.getUser(opts.userId);
  if (!user) {
    checks.push(fail("user_exists", "User not found", "USER_NOT_FOUND"));
    return { eligible: false, checks };
  }

  if (!user.isActive) {
    checks.push(fail("account_active", "Your account is not active", "ACCOUNT_INACTIVE"));
    return { eligible: false, checks };
  }

  const accountStatus = (user as any).accountStatus || "ACTIVE";
  if (accountStatus !== "ACTIVE") {
    const statusLabel = accountStatus.toLowerCase();
    checks.push(fail("account_status", `Your account is ${statusLabel}. Trading is not permitted.`, "ACCOUNT_SUSPENDED", { accountStatus }));
    return { eligible: false, checks };
  }

  const policyCtx = await buildPolicyContext(opts.userId);
  const tradePolicy = canTradePolicy(policyCtx);
  if (!tradePolicy.allowed) {
    checks.push(fail("policy_check", tradePolicy.reason || "Policy denied", tradePolicy.code, tradePolicy.details));
  } else {
    checks.push(pass("policy_check"));
  }

  const kycApproved = ["approved", "APPROVED"].includes(user.kycStatus);
  if (!kycApproved) {
    checks.push(fail("kyc_approved", `KYC status is '${user.kycStatus}' — must be approved before trading`, "KYC_NOT_APPROVED"));
  } else {
    checks.push(pass("kyc_approved"));
  }

  const exitWindow = await storage.getExitWindowById(opts.exitWindowId);
  if (!exitWindow) {
    checks.push(fail("exit_window_exists", "Exit window not found", "EXIT_WINDOW_NOT_FOUND"));
    return { eligible: false, checks };
  }

  const now = new Date();
  const opensAt = new Date(exitWindow.opensAt);
  const closesAt = new Date(exitWindow.closesAt);
  if (exitWindow.status !== "open" || now < opensAt || now > closesAt) {
    checks.push(fail("exit_window_open", "Exit window is not currently open for trading", "EXIT_WINDOW_NOT_OPEN", {
      status: exitWindow.status,
      opensAt: exitWindow.opensAt,
      closesAt: exitWindow.closesAt,
    }));
  } else {
    checks.push(pass("exit_window_open"));
  }

  if (exitWindow.assetId !== opts.assetId) {
    checks.push(fail("asset_match", "Asset does not match exit window", "ASSET_MISMATCH"));
  } else {
    checks.push(pass("asset_match"));
  }

  const jurisdictionCheck = checkJurisdictionEligibility(user, exitWindow);
  checks.push(jurisdictionCheck);

  if (exitWindow.cooldownHours && exitWindow.cooldownHours > 0) {
    const lastTrade = await storage.getLastTradeTimestamp(opts.userId, opts.exitWindowId);
    if (lastTrade) {
      const lastTradeTime = new Date(lastTrade).getTime();
      const cooldownMs = exitWindow.cooldownHours * 60 * 60 * 1000;
      const nextAllowed = lastTradeTime + cooldownMs;
      if (now.getTime() < nextAllowed) {
        const remaining = Math.ceil((nextAllowed - now.getTime()) / (60 * 60 * 1000));
        checks.push(fail("cooldown", `Cooldown active. Next trade allowed in ~${remaining} hour(s)`, "COOLDOWN_ACTIVE", {
          cooldownHours: exitWindow.cooldownHours,
          lastTradeAt: lastTrade,
          nextAllowedAt: new Date(nextAllowed).toISOString(),
        }));
      } else {
        checks.push(pass("cooldown"));
      }
    } else {
      checks.push(pass("cooldown"));
    }
  }

  if (exitWindow.maxParticipants) {
    const currentTraders = await storage.getUniqueTraderCount(opts.exitWindowId);
    const lastTrade = await storage.getLastTradeTimestamp(opts.userId, opts.exitWindowId);
    const isExistingTrader = !!lastTrade;
    if (!isExistingTrader && currentTraders >= exitWindow.maxParticipants) {
      checks.push(fail("max_participants", `Maximum participants (${exitWindow.maxParticipants}) reached for this exit window`, "MAX_PARTICIPANTS_REACHED", {
        maxParticipants: exitWindow.maxParticipants,
        currentTraders,
      }));
    } else {
      checks.push(pass("max_participants"));
    }
  }

  if (opts.quantity !== undefined && opts.pricePerToken !== undefined) {
    const tradeValue = opts.quantity * opts.pricePerToken;

    if (exitWindow.minTradeAmount) {
      const minAmount = parseFloat(exitWindow.minTradeAmount);
      if (tradeValue < minAmount) {
        checks.push(fail("min_trade_amount", `Trade value (${tradeValue.toFixed(2)}) below minimum (${minAmount.toFixed(2)})`, "BELOW_MIN_TRADE", {
          tradeValue, minAmount,
        }));
      } else {
        checks.push(pass("min_trade_amount"));
      }
    }

    if (exitWindow.maxTradeAmount) {
      const maxAmount = parseFloat(exitWindow.maxTradeAmount);
      if (tradeValue > maxAmount) {
        checks.push(fail("max_trade_amount", `Trade value (${tradeValue.toFixed(2)}) exceeds maximum (${maxAmount.toFixed(2)})`, "ABOVE_MAX_TRADE", {
          tradeValue, maxAmount,
        }));
      } else {
        checks.push(pass("max_trade_amount"));
      }
    }
  }

  if (opts.side === "sell" && opts.tokenId) {
    const holding = await storage.getTokenHolding(opts.userId, opts.tokenId);
    if (holding) {
      const lockupUntil = (holding as any).lockupUntil;
      if (lockupUntil) {
        const lockupDate = new Date(lockupUntil);
        if (now < lockupDate) {
          checks.push(fail("lockup_period", `Tokens locked until ${lockupDate.toISOString().split("T")[0]}`, "LOCKUP_ACTIVE", {
            lockupUntil,
          }));
        } else {
          checks.push(pass("lockup_period"));
        }
      } else {
        checks.push(pass("lockup_period"));
      }
    }
  }

  if (opts.tokenId && opts.counterpartyId && opts.quantity) {
    const transferResult = await canTransfer(opts.userId, opts.counterpartyId, opts.tokenId, opts.quantity);
    if (!transferResult.allowed) {
      for (const v of transferResult.violations) {
        checks.push(fail("transfer_restriction", v, "TRANSFER_RESTRICTION_VIOLATED"));
      }
    } else {
      checks.push(pass("transfer_restrictions"));
    }
  }

  const eligible = checks.every(c => c.passed);
  return { eligible, checks };
}

function checkJurisdictionEligibility(user: User, exitWindow: ExitWindow): EligibilityCheck {
  const jurisdictions = exitWindow.eligibleJurisdictions;
  if (!jurisdictions || jurisdictions.length === 0) {
    return pass("jurisdiction_eligible");
  }

  const userJurisdiction = getUserJurisdiction(user);
  if (!userJurisdiction) {
    return fail("jurisdiction_eligible", "Country of residence must be set to verify trading eligibility", "NO_JURISDICTION", {
      eligibleJurisdictions: jurisdictions,
    });
  }

  if (!jurisdictions.includes(userJurisdiction)) {
    return fail("jurisdiction_eligible", `Your jurisdiction (${userJurisdiction}) is not eligible for this exit window`, "JURISDICTION_NOT_ELIGIBLE", {
      userJurisdiction,
      eligibleJurisdictions: jurisdictions,
    });
  }

  return pass("jurisdiction_eligible");
}
