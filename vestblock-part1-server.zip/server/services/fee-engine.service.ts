import { storage } from "../storage";
import type { FeeSchedule, FeeType, AppliedFee, InsertAppliedFee } from "@shared/schema";

export interface FeeCalculation {
  grossAmount: number;
  fee: number;
  netAmount: number;
  feeRate: number;
  method: string;
  feeScheduleId: string;
  feeScheduleVersion: number;
  vehicleId: string | null;
  feeType: FeeType;
}

interface Tier {
  minAmount: number;
  maxAmount: number | null;
  rate: number;
}

interface ApplyFeeOptions {
  feeType: FeeType;
  amount: number;
  currency?: string;
  vehicleId?: string;
  userId?: string;
  referenceEntityType?: string;
  referenceEntityId?: string;
  description?: string;
  metadata?: Record<string, any>;
}

function computeFee(schedule: FeeSchedule, amount: number): { fee: number; rate: number } {
  let fee = 0;
  const rate = parseFloat(schedule.rate || "0");
  const flatAmount = parseFloat(schedule.flatAmount || "0");

  switch (schedule.method) {
    case "percentage":
      fee = amount * rate;
      break;
    case "flat":
      fee = flatAmount;
      break;
    case "tiered": {
      const tiers = (schedule.tiers as Tier[] | null) || [];
      const matchingTier = tiers.find(
        (t) => amount >= t.minAmount && (t.maxAmount === null || amount <= t.maxAmount)
      );
      if (matchingTier) {
        fee = amount * matchingTier.rate;
      }
      break;
    }
    default:
      fee = amount * rate;
  }

  const minFee = schedule.minFee ? parseFloat(schedule.minFee) : null;
  const maxFee = schedule.maxFee ? parseFloat(schedule.maxFee) : null;

  if (minFee !== null && fee < minFee) fee = minFee;
  if (maxFee !== null && fee > maxFee) fee = maxFee;

  fee = parseFloat(fee.toFixed(2));
  if (fee > amount) fee = amount;

  return { fee, rate };
}

export async function previewFee(
  feeType: FeeType,
  amount: number,
  currency?: string,
  vehicleId?: string
): Promise<FeeCalculation> {
  const schedule = await storage.getActiveFeeSchedule(feeType, currency, vehicleId);

  if (!schedule) {
    return {
      grossAmount: amount,
      fee: 0,
      netAmount: amount,
      feeRate: 0,
      method: "none",
      feeScheduleId: "",
      feeScheduleVersion: 0,
      vehicleId: vehicleId || null,
      feeType,
    };
  }

  const { fee, rate } = computeFee(schedule, amount);
  const netAmount = parseFloat((amount - fee).toFixed(2));

  return {
    grossAmount: amount,
    fee,
    netAmount,
    feeRate: rate,
    method: schedule.method,
    feeScheduleId: schedule.id,
    feeScheduleVersion: schedule.version,
    vehicleId: schedule.vehicleId || vehicleId || null,
    feeType,
  };
}

export async function applyFee(opts: ApplyFeeOptions): Promise<{ calculation: FeeCalculation; appliedFee: AppliedFee | null }> {
  const calculation = await previewFee(opts.feeType, opts.amount, opts.currency, opts.vehicleId);

  if (calculation.fee === 0 || !calculation.feeScheduleId) {
    return { calculation, appliedFee: null };
  }

  const appliedFee = await storage.createAppliedFee({
    feeScheduleId: calculation.feeScheduleId,
    feeScheduleVersion: calculation.feeScheduleVersion,
    feeType: opts.feeType,
    vehicleId: opts.vehicleId || null,
    userId: opts.userId || null,
    currency: opts.currency || "*",
    grossAmount: calculation.grossAmount.toString(),
    feeAmount: calculation.fee.toString(),
    netAmount: calculation.netAmount.toString(),
    method: calculation.method,
    rate: calculation.feeRate.toString(),
    referenceEntityType: opts.referenceEntityType || null,
    referenceEntityId: opts.referenceEntityId || null,
    description: opts.description || null,
    metadata: opts.metadata || null,
  } as InsertAppliedFee);

  return { calculation, appliedFee };
}

export async function getVehicleFeeConfig(vehicleId: string): Promise<Record<string, FeeCalculation | null>> {
  const feeTypes: FeeType[] = [
    "acquisition", "management", "rental_processing",
    "exit_trade_buyer", "exit_trade_seller",
    "crypto_deposit", "issuer_onboarding",
    "withdrawal", "investment", "trade", "fx", "transfer", "redemption",
    "performance_fee", "valuation_uplift", "premium_membership",
  ];

  const config: Record<string, FeeCalculation | null> = {};
  for (const ft of feeTypes) {
    const schedule = await storage.getActiveFeeSchedule(ft, undefined, vehicleId);
    if (schedule) {
      const { fee, rate } = computeFee(schedule, 100);
      config[ft] = {
        grossAmount: 100,
        fee,
        netAmount: parseFloat((100 - fee).toFixed(2)),
        feeRate: rate,
        method: schedule.method,
        feeScheduleId: schedule.id,
        feeScheduleVersion: schedule.version,
        vehicleId: schedule.vehicleId || null,
        feeType: ft,
      };
    } else {
      config[ft] = null;
    }
  }
  return config;
}

export const FEE_TYPE_LABELS: Record<string, string> = {
  withdrawal: "Withdrawal Fee",
  investment: "Investment Fee",
  trade: "Trade Fee",
  fx: "FX Conversion Fee",
  transfer: "Transfer Fee",
  redemption: "Redemption Fee",
  acquisition: "Acquisition / Structuring Fee",
  management: "Annual Management Fee",
  rental_processing: "Rental Processing Fee",
  exit_trade_buyer: "Exit Trading Fee (Buyer)",
  exit_trade_seller: "Exit Trading Fee (Seller)",
  crypto_deposit: "Crypto Deposit Fee",
  issuer_onboarding: "Institutional Onboarding Fee",
  property_sale: "Property Sale / Disposal Fee",
  performance_fee: "Performance Incentive Fee",
  valuation_uplift: "Valuation Uplift Success Fee",
  premium_membership: "Premium Investor Membership Fee",
};

export const FEE_TYPE_DEFAULTS: Record<string, { minRate: string; maxRate: string; description: string }> = {
  acquisition: { minRate: "0.01", maxRate: "0.03", description: "Charged at raise close, 1-3% of committed capital" },
  management: { minRate: "0.01", maxRate: "0.02", description: "Annual fee on AUM or property value, 1-2%" },
  rental_processing: { minRate: "0.005", maxRate: "0.01", description: "Applied to rental distribution payouts, 0.5-1%" },
  exit_trade_buyer: { minRate: "0.005", maxRate: "0.01", description: "Charged to buyer on secondary market trades, 0.5-1%" },
  exit_trade_seller: { minRate: "0.01", maxRate: "0.02", description: "Charged to seller on secondary market trades, 1-2%" },
  fx: { minRate: "0.005", maxRate: "0.015", description: "FX conversion spread, 0.5-1.5% per conversion" },
  crypto_deposit: { minRate: "0", maxRate: "0.01", description: "Optional fee on crypto deposits, fixed or percentage" },
  issuer_onboarding: { minRate: "0", maxRate: "0", description: "Fixed institutional onboarding fee: due diligence, tokenization, legal setup. 2-5 lakh PKR per property" },
  property_sale: { minRate: "0.01", maxRate: "0.02", description: "Fee on property sale/disposal proceeds, 1-2%" },
  performance_fee: { minRate: "0.10", maxRate: "0.25", description: "Charged on excess yield above hurdle rate, 10-25% of outperformance" },
  valuation_uplift: { minRate: "0.01", maxRate: "0.05", description: "Success fee on capital gains at property sale, 1-5% of gain" },
  premium_membership: { minRate: "0", maxRate: "0", description: "Annual premium membership subscription, 50K PKR/year standard" },
};
