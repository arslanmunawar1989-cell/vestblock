import { storage } from "../storage";
import type { PropertySaleEvent, PropertySalePayout } from "@shared/schema";

export interface PropertySaleInput {
  assetId: string;
  saleAmount: number;
  agentCommission: number;
  legalFees: number;
  transferTax: number;
  otherCosts: number;
  otherCostsDescription?: string;
  notes?: string;
  createdBy: string;
}

export interface PropertySalePreview {
  assetId: string;
  assetName: string;
  currency: string;
  saleAmount: number;
  agentCommission: number;
  legalFees: number;
  transferTax: number;
  otherCosts: number;
  totalSellingCosts: number;
  netSaleProceeds: number;
  totalCapitalInvested: number;
  capitalGain: number;
  totalUnits: number;
  returnPerUnit: number;
  gainPerUnit: number;
  totalPayoutPerUnit: number;
  holders: HolderPreview[];
}

export interface HolderPreview {
  userId: string;
  username: string;
  fullName: string;
  units: number;
  capitalReturn: number;
  capitalGainShare: number;
  totalPayout: number;
}

export interface PropertySaleResult {
  saleEvent: PropertySaleEvent;
  payouts: PropertySalePayout[];
  summary: {
    totalDistributed: string;
    recipientCount: number;
    currency: string;
    capitalGain: string;
    returnPerUnit: string;
    gainPerUnit: string;
  };
}

async function getUnitHolders(assetId: string): Promise<{ userId: string; units: number }[]> {
  const ledger = await storage.getPropertyUnitLedger(assetId);
  const balances: Record<string, number> = {};

  for (const entry of ledger) {
    if (!entry.userId) continue;
    const units = parseFloat(entry.units);
    if (entry.direction === "CREDIT") {
      balances[entry.userId] = (balances[entry.userId] || 0) + units;
    } else {
      balances[entry.userId] = (balances[entry.userId] || 0) - units;
    }
  }

  return Object.entries(balances)
    .filter(([_, units]) => units > 0.000001)
    .map(([userId, units]) => ({ userId, units }));
}

export async function previewPropertySale(input: PropertySaleInput): Promise<PropertySalePreview> {
  const asset = await storage.getAsset(input.assetId);
  if (!asset) throw new Error("Asset not found");
  if (asset.status === "sold") throw new Error("Property is already sold");

  const acquisition = await storage.getPropertyAcquisition(input.assetId);
  const propertyUnit = await storage.getPropertyUnit(input.assetId);

  const totalCapitalInvested = acquisition ? parseFloat(acquisition.totalAcquisitionCost) : 0;
  const totalUnits = propertyUnit ? parseFloat(propertyUnit.totalUnits) : parseFloat(asset.totalSupply);
  const currency = propertyUnit?.currency || asset.baseCurrency || "AED";

  const totalSellingCosts = input.agentCommission + input.legalFees + input.transferTax + input.otherCosts;
  const netSaleProceeds = input.saleAmount - totalSellingCosts;
  const capitalGain = netSaleProceeds - totalCapitalInvested;

  const returnPerUnit = totalUnits > 0 ? totalCapitalInvested / totalUnits : 0;
  const gainPerUnit = totalUnits > 0 ? capitalGain / totalUnits : 0;
  const totalPayoutPerUnit = returnPerUnit + gainPerUnit;

  const holders = await getUnitHolders(input.assetId);

  const holderPreviews: HolderPreview[] = [];
  for (const holder of holders) {
    const user = await storage.getUser(holder.userId);
    if (!user) continue;

    const capitalReturn = Math.round(holder.units * returnPerUnit * 100) / 100;
    const capitalGainShare = Math.round(holder.units * gainPerUnit * 100) / 100;
    const totalPayout = Math.round((capitalReturn + capitalGainShare) * 100) / 100;

    holderPreviews.push({
      userId: holder.userId,
      username: user.username,
      fullName: `${user.firstName || ""} ${user.lastName || ""}`.trim() || user.username,
      units: holder.units,
      capitalReturn,
      capitalGainShare,
      totalPayout,
    });
  }

  return {
    assetId: input.assetId,
    assetName: asset.name,
    currency,
    saleAmount: input.saleAmount,
    agentCommission: input.agentCommission,
    legalFees: input.legalFees,
    transferTax: input.transferTax,
    otherCosts: input.otherCosts,
    totalSellingCosts,
    netSaleProceeds,
    totalCapitalInvested,
    capitalGain,
    totalUnits,
    returnPerUnit,
    gainPerUnit,
    totalPayoutPerUnit,
    holders: holderPreviews,
  };
}

export async function executePropertySale(input: PropertySaleInput): Promise<PropertySaleResult> {
  const asset = await storage.getAsset(input.assetId);
  if (!asset) throw new Error("Asset not found");
  if (asset.status === "sold") throw new Error("Property is already sold");

  const existingSale = await storage.getPropertySaleEventByAsset(input.assetId);
  if (existingSale && existingSale.status === "executed") {
    throw new Error("A sale has already been executed for this property");
  }

  const acquisition = await storage.getPropertyAcquisition(input.assetId);
  const propertyUnit = await storage.getPropertyUnit(input.assetId);

  const totalCapitalInvested = acquisition ? parseFloat(acquisition.totalAcquisitionCost) : 0;
  const totalUnits = propertyUnit ? parseFloat(propertyUnit.totalUnits) : parseFloat(asset.totalSupply);
  const currency = propertyUnit?.currency || asset.baseCurrency || "AED";

  const totalSellingCosts = input.agentCommission + input.legalFees + input.transferTax + input.otherCosts;
  const netSaleProceeds = input.saleAmount - totalSellingCosts;
  const capitalGain = netSaleProceeds - totalCapitalInvested;

  const returnPerUnit = totalUnits > 0 ? totalCapitalInvested / totalUnits : 0;
  const gainPerUnit = totalUnits > 0 ? capitalGain / totalUnits : 0;
  const totalPayoutPerUnit = returnPerUnit + gainPerUnit;

  const holders = await getUnitHolders(input.assetId);

  const holdingsSnapshot = holders.map(h => ({
    userId: h.userId,
    units: h.units.toFixed(6),
    returnAmount: (Math.round(h.units * returnPerUnit * 100) / 100).toFixed(2),
    gainAmount: (Math.round(h.units * gainPerUnit * 100) / 100).toFixed(2),
  }));

  const saleEvent = await storage.createPropertySaleEvent({
    assetId: input.assetId,
    saleAmount: input.saleAmount.toFixed(2),
    currency,
    agentCommission: input.agentCommission.toFixed(2),
    legalFees: input.legalFees.toFixed(2),
    transferTax: input.transferTax.toFixed(2),
    otherCosts: input.otherCosts.toFixed(2),
    otherCostsDescription: input.otherCostsDescription || null,
    totalSellingCosts: totalSellingCosts.toFixed(2),
    netSaleProceeds: netSaleProceeds.toFixed(2),
    totalCapitalInvested: totalCapitalInvested.toFixed(2),
    capitalGain: capitalGain.toFixed(2),
    totalUnitsAtSale: totalUnits.toFixed(6),
    returnPerUnit: returnPerUnit.toFixed(6),
    gainPerUnit: gainPerUnit.toFixed(6),
    totalPayoutPerUnit: totalPayoutPerUnit.toFixed(6),
    holdingsSnapshot,
    status: "executed",
    notes: input.notes || null,
    executedAt: new Date().toISOString(),
    createdBy: input.createdBy,
  });

  const payouts: PropertySalePayout[] = [];

  const holderPayoutCalcs = holders.map(h => {
    const capitalReturnAmount = Math.round(h.units * returnPerUnit * 100) / 100;
    const capitalGainAmount = Math.round(h.units * gainPerUnit * 100) / 100;
    const totalPayout = Math.round((capitalReturnAmount + capitalGainAmount) * 100) / 100;
    return { ...h, capitalReturnAmount, capitalGainAmount, totalPayout };
  }).filter(h => h.totalPayout > 0);

  const totalPayoutsSum = holderPayoutCalcs.reduce((s, h) => s + h.totalPayout, 0);
  const residual = Math.round((netSaleProceeds - totalPayoutsSum) * 100) / 100;
  if (residual !== 0 && holderPayoutCalcs.length > 0) {
    const largest = holderPayoutCalcs.reduce((a, b) => a.units > b.units ? a : b);
    if (residual > 0) {
      largest.capitalGainAmount = Math.round((largest.capitalGainAmount + residual) * 100) / 100;
    } else {
      largest.capitalReturnAmount = Math.round((largest.capitalReturnAmount + residual) * 100) / 100;
    }
    largest.totalPayout = Math.round((largest.capitalReturnAmount + largest.capitalGainAmount) * 100) / 100;
  }

  for (const holder of holderPayoutCalcs) {
    const user = await storage.getUser(holder.userId);
    if (!user) continue;

    const { capitalReturnAmount, capitalGainAmount, totalPayout } = holder;

    if (totalPayout <= 0) continue;

    const wallet = await storage.getOrCreateWallet(holder.userId, currency);
    const txIds: string[] = [];

    if (capitalReturnAmount > 0) {
      const returnTx = await storage.createWalletTransaction({
        walletAccountId: wallet.id,
        type: "CAPITAL_RETURN",
        amount: capitalReturnAmount.toFixed(2),
        currency,
        status: "COMPLETED",
        referenceId: saleEvent.id,
        description: `Return of capital - ${asset.name} property sale`,
        metadata: {
          saleEventId: saleEvent.id,
          assetId: input.assetId,
          assetName: asset.name,
          units: holder.units.toFixed(6),
          returnPerUnit: returnPerUnit.toFixed(6),
        },
      });
      txIds.push(returnTx.id);
    }

    if (capitalGainAmount > 0) {
      const gainTx = await storage.createWalletTransaction({
        walletAccountId: wallet.id,
        type: "CAPITAL_GAIN",
        amount: capitalGainAmount.toFixed(2),
        currency,
        status: "COMPLETED",
        referenceId: saleEvent.id,
        description: `Capital gain - ${asset.name} property sale`,
        metadata: {
          saleEventId: saleEvent.id,
          assetId: input.assetId,
          assetName: asset.name,
          units: holder.units.toFixed(6),
          gainPerUnit: gainPerUnit.toFixed(6),
        },
      });
      txIds.push(gainTx.id);
    } else if (capitalGainAmount < 0) {
      const lossTx = await storage.createWalletTransaction({
        walletAccountId: wallet.id,
        type: "CAPITAL_GAIN",
        amount: capitalGainAmount.toFixed(2),
        currency,
        status: "COMPLETED",
        referenceId: saleEvent.id,
        description: `Capital loss - ${asset.name} property sale`,
        metadata: {
          saleEventId: saleEvent.id,
          assetId: input.assetId,
          assetName: asset.name,
          units: holder.units.toFixed(6),
          gainPerUnit: gainPerUnit.toFixed(6),
        },
      });
      txIds.push(lossTx.id);
    }

    if (propertyUnit) {
      await storage.createPropertyUnitLedgerEntry({
        propertyUnitId: propertyUnit.id,
        assetId: input.assetId,
        userId: holder.userId,
        direction: "DEBIT",
        units: holder.units.toFixed(6),
        unitPriceAtTime: totalPayoutPerUnit.toFixed(6),
        totalValue: totalPayout.toFixed(2),
        reason: "REDEEM",
        refId: saleEvent.id,
        notes: `Property sale - units redeemed`,
      });
    }

    const payout = await storage.createPropertySalePayout({
      saleEventId: saleEvent.id,
      userId: holder.userId,
      units: holder.units.toFixed(6),
      capitalReturnAmount: capitalReturnAmount.toFixed(2),
      capitalGainAmount: capitalGainAmount.toFixed(2),
      totalPayout: totalPayout.toFixed(2),
      currency,
      walletTransactionIds: txIds,
      status: "completed",
    });
    payouts.push(payout);
  }

  if (propertyUnit) {
    await storage.updatePropertyUnit(input.assetId, {
      unitsIssued: "0",
      status: "frozen",
    });
  }

  await storage.updateAsset(input.assetId, { status: "sold" } as any);

  return {
    saleEvent,
    payouts,
    summary: {
      totalDistributed: netSaleProceeds.toFixed(2),
      recipientCount: payouts.length,
      currency,
      capitalGain: capitalGain.toFixed(2),
      returnPerUnit: returnPerUnit.toFixed(6),
      gainPerUnit: gainPerUnit.toFixed(6),
    },
  };
}
