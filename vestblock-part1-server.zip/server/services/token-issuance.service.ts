import { storage } from "../storage";
import { getOnChainProvider } from "./on-chain-provider";
import { logAudit } from "../lib/audit-logger";

export interface IssuanceResult {
  success: boolean;
  issuanceId?: string;
  error?: string;
  report?: IssuanceReport;
}

export interface IssuanceReport {
  roundId: string;
  roundName: string;
  assetId: string;
  assetName: string;
  spvId: string;
  spvLegalName: string;
  shareClassId: string;
  shareClassName: string;
  tokenId: string;
  tokenSymbol: string;
  totalSupplyMinted: string;
  totalAmountRaised: string;
  currency: string;
  holdersAllocated: number;
  allocations: Array<{
    userId: string;
    username: string;
    quantity: string;
    balanceBefore: string;
    balanceAfter: string;
  }>;
  issuedAt: string;
  issuedBy: string;
}

export async function executeTokenIssuancePipeline(
  roundId: string,
  issuedByUserId: string
): Promise<IssuanceResult> {
  const allRounds = await storage.getRounds();
  const round2 = allRounds.find(r => r.id === roundId);
  if (!round2) {
    return { success: false, error: "Round not found" };
  }

  const existingIssuances = await storage.getTokenIssuancesByRound(roundId);
  if (existingIssuances.length > 0) {
    return { success: false, error: "Token issuance already completed for this round" };
  }

  const raised = parseFloat(round2.raisedAmount);
  const target = parseFloat(round2.targetAmount);
  if (raised < target && round2.status === "open") {
    return { success: false, error: `Round is not fully funded yet. Raised ${round2.raisedAmount} of ${round2.targetAmount} target.` };
  }

  const asset = await storage.getAsset(round2.assetId);
  if (!asset) {
    return { success: false, error: "Asset not found for this round" };
  }

  const spvs = await storage.getSpvEntitiesByAsset(asset.id);
  if (spvs.length === 0) {
    return { success: false, error: `No SPV entity found for asset ${asset.name}. Create an SPV first.` };
  }
  const spv = spvs[0];

  const existingShareClasses = await storage.getShareClassesBySpv(spv.id);
  let shareClass;
  if (existingShareClasses.length > 0) {
    shareClass = existingShareClasses[0];
  } else {
    shareClass = await storage.createShareClass({
      spvId: spv.id,
      name: `${asset.name} - Class A`,
      rightsSummary: "Standard equity participation rights",
      currency: asset.baseCurrency,
      totalSupply: "0",
    });
  }

  const totalTokensFromRound = (parseFloat(round2.raisedAmount) / parseFloat(asset.pricePerToken)).toFixed(6);
  const newTotalSupply = (parseFloat(shareClass.totalSupply) + parseFloat(totalTokensFromRound)).toFixed(6);
  await storage.updateShareClassTotalSupply(shareClass.id, newTotalSupply);

  const existingTokens = await storage.getTokensByShareClass(shareClass.id);
  let token;
  if (existingTokens.length > 0) {
    token = existingTokens[0];
  } else {
    token = await storage.createToken({
      shareClassId: shareClass.id,
      tokenSymbol: asset.symbol,
      decimals: 6,
      transferRestrictions: { roundId, jurisdiction: spv.jurisdiction },
    });
  }

  const users = await storage.getUsers();
  const allocations: IssuanceReport["allocations"] = [];
  let holdersAllocated = 0;
  let totalActualMinted = 0;

  for (const user of users) {
    const portfolioItem = await storage.getPortfolioItem(user.id, asset.id);
    if (!portfolioItem || parseFloat(portfolioItem.quantity) <= 0) continue;

    const existingHolding = await storage.getTokenHolding(user.id, token.id);
    const balanceBefore = existingHolding?.balance || "0";
    await storage.upsertTokenHolding(user.id, token.id, portfolioItem.quantity);
    const balanceAfter = portfolioItem.quantity;

    const mintDelta = parseFloat(balanceAfter) - parseFloat(balanceBefore);
    if (mintDelta > 0) {
      const mintAmount = mintDelta.toFixed(6);
      totalActualMinted += mintDelta;
      await storage.createTokenLedgerEntry({
        tokenId: token.id,
        fromUserId: null,
        toUserId: user.id,
        amount: mintAmount,
        reason: "mint",
        refId: roundId,
      });

      const onChain = getOnChainProvider();
      if (onChain.enabled) {
        await onChain.mint({
          tokenSymbol: token.tokenSymbol,
          recipientAddress: user.id,
          amount: mintAmount,
          tokenId: token.id,
          metadata: { roundId, assetId: asset.id },
        });
      }
    } else if (mintDelta < 0) {
      const burnAmount = Math.abs(mintDelta).toFixed(6);
      totalActualMinted += mintDelta;
      await storage.createTokenLedgerEntry({
        tokenId: token.id,
        fromUserId: user.id,
        toUserId: null,
        amount: burnAmount,
        reason: "adjustment",
        refId: roundId,
      });
    }

    allocations.push({
      userId: user.id,
      username: user.username,
      quantity: portfolioItem.quantity,
      balanceBefore,
      balanceAfter,
    });
    holdersAllocated++;
  }

  if (totalActualMinted > 0) {
    const currentTokenSupply = parseFloat(token.totalSupply || "0");
    const newTokenSupply = (currentTokenSupply + totalActualMinted).toFixed(6);
    await storage.updateTokenTotalSupply(token.id, newTokenSupply);
  }

  await storage.updateRoundStatus(roundId, "funded");

  const issuedBy = await storage.getUser(issuedByUserId);
  const report: IssuanceReport = {
    roundId,
    roundName: round2.name,
    assetId: asset.id,
    assetName: asset.name,
    spvId: spv.id,
    spvLegalName: spv.legalName,
    shareClassId: shareClass.id,
    shareClassName: shareClass.name,
    tokenId: token.id,
    tokenSymbol: token.tokenSymbol,
    totalSupplyMinted: totalActualMinted.toFixed(6),
    totalAmountRaised: round2.raisedAmount,
    currency: asset.baseCurrency,
    holdersAllocated,
    allocations,
    issuedAt: new Date().toISOString(),
    issuedBy: issuedBy?.username || issuedByUserId,
  };

  const issuance = await storage.createTokenIssuance({
    roundId,
    assetId: asset.id,
    tokenId: token.id,
    spvId: spv.id,
    shareClassId: shareClass.id,
    totalSupplyMinted: totalActualMinted.toFixed(6),
    holdersAllocated,
    totalAmountRaised: round2.raisedAmount,
    currency: asset.baseCurrency,
    issuedBy: issuedByUserId,
    issuanceReport: report,
  });

  await logAudit({
    actorId: issuedByUserId,
    actionType: "TOKEN_ISSUANCE",
    entityType: "round",
    entityId: roundId,
    reason: `Token issuance completed for round "${round2.name}" on asset "${asset.name}". Minted ${totalActualMinted.toFixed(6)} ${token.tokenSymbol} tokens, allocated to ${holdersAllocated} holders. Total raised: ${asset.baseCurrency} ${round2.raisedAmount}.`,
    metadata: { tokenSymbol: token.tokenSymbol, totalMinted: totalActualMinted.toFixed(6), holdersAllocated, totalRaised: round2.raisedAmount },
  });

  return {
    success: true,
    issuanceId: issuance.id,
    report,
  };
}

export async function checkAndTriggerAutoIssuance(
  roundId: string,
  issuedByUserId: string
): Promise<IssuanceResult | null> {
  const allRounds = await storage.getRounds();
  const round = allRounds.find(r => r.id === roundId);
  if (!round) return null;

  const raised = parseFloat(round.raisedAmount);
  const target = parseFloat(round.targetAmount);

  if (raised >= target && round.status === "open") {
    const spvs = await storage.getSpvEntitiesByAsset(round.assetId);
    if (spvs.length === 0) return null;

    return executeTokenIssuancePipeline(roundId, issuedByUserId);
  }

  return null;
}
