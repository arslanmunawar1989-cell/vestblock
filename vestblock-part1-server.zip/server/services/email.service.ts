import { storage } from "../storage";
import type { InsertEmailLog } from "@shared/schema";

interface EmailPayload {
  to: string;
  subject: string;
  body: string;
  tenantId?: string | null;
  relatedEntityType?: string;
  relatedEntityId?: string;
}

interface EmailProvider {
  send(payload: EmailPayload): Promise<{ success: boolean; error?: string }>;
}

class DevEmailProvider implements EmailProvider {
  async send(_payload: EmailPayload): Promise<{ success: boolean }> {
    return { success: true };
  }
}

class ResendEmailProvider implements EmailProvider {
  private apiKey: string;
  private from: string;

  constructor(apiKey: string, from: string) {
    this.apiKey = apiKey;
    this.from = from;
  }

  async send(payload: EmailPayload): Promise<{ success: boolean; error?: string }> {
    try {
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${this.apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          from: this.from,
          to: [payload.to],
          subject: payload.subject,
          html: payload.body,
        }),
      });

      if (!res.ok) {
        const err = await res.text();
        return { success: false, error: err };
      }

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }
}

class EmailService {
  private provider: EmailProvider;
  private mode: "dev" | "production";

  constructor() {
    const resendKey = process.env.RESEND_API_KEY;
    const emailFrom = process.env.EMAIL_FROM;

    if (resendKey && emailFrom) {
      this.provider = new ResendEmailProvider(resendKey, emailFrom);
      this.mode = "production";
      console.log("[EmailService] Production mode (Resend)");
    } else {
      this.provider = new DevEmailProvider();
      this.mode = "dev";
      console.log("[EmailService] Dev mode (log only)");
    }
  }

  async send(payload: EmailPayload): Promise<void> {
    const logData: InsertEmailLog = {
      tenantId: payload.tenantId || null,
      toAddress: payload.to,
      subject: payload.subject,
      body: payload.body,
      status: "queued",
      relatedEntityType: payload.relatedEntityType || null,
      relatedEntityId: payload.relatedEntityId || null,
    };

    const log = await storage.createEmailLog(logData);

    const result = await this.provider.send(payload);

    if (result.success) {
      await storage.updateEmailLogStatus(log.id, "sent");
    } else {
      await storage.updateEmailLogStatus(log.id, "failed");
      console.error(`[EmailService] Failed to send email to ${payload.to}:`, result.error);
    }
  }

  async sendBulk(payloads: EmailPayload[]): Promise<{ sent: number; failed: number }> {
    let sent = 0;
    let failed = 0;

    for (const payload of payloads) {
      try {
        await this.send(payload);
        sent++;
      } catch {
        failed++;
      }
    }

    return { sent, failed };
  }

  getMode(): string {
    return this.mode;
  }
}

export const emailService = new EmailService();

export function appointmentEmail(
  to: string,
  event: "requested" | "confirmed" | "rescheduled" | "cancelled",
  details: { datetime: string; mode: string; agentName?: string; clientName?: string },
  opts?: { tenantId?: string; appointmentId?: string }
): EmailPayload {
  const titles: Record<string, string> = {
    requested: "Appointment Requested",
    confirmed: "Appointment Confirmed",
    rescheduled: "Appointment Rescheduled",
    cancelled: "Appointment Cancelled",
  };

  const dt = new Date(details.datetime).toLocaleString("en-US", {
    dateStyle: "long",
    timeStyle: "short",
  });

  const body = `
    <div style="font-family: 'Plus Jakarta Sans', sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #1E2BFF;">${titles[event]}</h2>
      <p>Your appointment has been <strong>${event}</strong>.</p>
      <table style="width: 100%; border-collapse: collapse; margin: 16px 0;">
        <tr><td style="padding: 8px; color: #666;">Date & Time</td><td style="padding: 8px; font-weight: 600;">${dt}</td></tr>
        <tr><td style="padding: 8px; color: #666;">Mode</td><td style="padding: 8px;">${details.mode.replace("_", " ")}</td></tr>
        ${details.agentName ? `<tr><td style="padding: 8px; color: #666;">Agent</td><td style="padding: 8px;">${details.agentName}</td></tr>` : ""}
        ${details.clientName ? `<tr><td style="padding: 8px; color: #666;">Client</td><td style="padding: 8px;">${details.clientName}</td></tr>` : ""}
      </table>
      <p style="color: #888; font-size: 12px;">This is an automated message from VestBlock.</p>
    </div>
  `;

  return {
    to,
    subject: `VestBlock — ${titles[event]}`,
    body,
    tenantId: opts?.tenantId,
    relatedEntityType: "appointment",
    relatedEntityId: opts?.appointmentId,
  };
}

export function transactionEmail(
  to: string,
  event: "created" | "settled" | "failed" | "pending_confirmation",
  details: { amount: string; currency: string; type: string; description?: string },
  opts?: { tenantId?: string; transactionId?: string }
): EmailPayload {
  const titles: Record<string, string> = {
    created: "Transaction Created",
    settled: "Transaction Settled",
    failed: "Transaction Failed",
    pending_confirmation: "Transaction Pending Confirmation",
  };

  const body = `
    <div style="font-family: 'Plus Jakarta Sans', sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #1E2BFF;">${titles[event]}</h2>
      <p>Your transaction has been <strong>${event.replace("_", " ")}</strong>.</p>
      <table style="width: 100%; border-collapse: collapse; margin: 16px 0;">
        <tr><td style="padding: 8px; color: #666;">Type</td><td style="padding: 8px; font-weight: 600;">${details.type}</td></tr>
        <tr><td style="padding: 8px; color: #666;">Amount</td><td style="padding: 8px;">${details.currency} ${details.amount}</td></tr>
        ${details.description ? `<tr><td style="padding: 8px; color: #666;">Description</td><td style="padding: 8px;">${details.description}</td></tr>` : ""}
      </table>
      <p style="color: #888; font-size: 12px;">This is an automated message from VestBlock.</p>
    </div>
  `;

  return {
    to,
    subject: `VestBlock — ${titles[event]}`,
    body,
    tenantId: opts?.tenantId,
    relatedEntityType: "transaction",
    relatedEntityId: opts?.transactionId,
  };
}

export function otpEmail(
  to: string,
  code: string,
  opts?: { tenantId?: string; transactionId?: string }
): EmailPayload {
  const body = `
    <div style="font-family: 'Plus Jakarta Sans', sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #1E2BFF;">Transaction Verification Code</h2>
      <p>Use the following code to confirm your transaction:</p>
      <div style="background: #EEF0FF; border-radius: 12px; padding: 24px; text-align: center; margin: 24px 0;">
        <span style="font-size: 32px; font-weight: 700; letter-spacing: 8px; color: #1E2BFF;">${code}</span>
      </div>
      <p style="color: #666;">This code expires in <strong>5 minutes</strong>. Do not share this code with anyone.</p>
      <p style="color: #888; font-size: 12px;">If you did not initiate this transaction, please contact support immediately.</p>
    </div>
  `;

  return {
    to,
    subject: "VestBlock — Transaction Verification Code",
    body,
    tenantId: opts?.tenantId,
    relatedEntityType: "transaction",
    relatedEntityId: opts?.transactionId,
  };
}

export function kycDocumentRequestEmail(
  to: string,
  documentType: string,
  opts?: { tenantId?: string; kycProfileId?: string }
): EmailPayload {
  const body = `
    <div style="font-family: 'Plus Jakarta Sans', sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #1E2BFF;">Document Request</h2>
      <p>We need the following document to continue your KYC verification:</p>
      <div style="background: #FFF3E0; border-left: 4px solid #FF9800; padding: 16px; margin: 16px 0;">
        <strong>${documentType}</strong>
      </div>
      <p>Please upload the requested document through your VestBlock dashboard.</p>
      <p style="color: #888; font-size: 12px;">This is an automated message from VestBlock.</p>
    </div>
  `;

  return {
    to,
    subject: "VestBlock — Document Required for KYC",
    body,
    tenantId: opts?.tenantId,
    relatedEntityType: "kyc_profile",
    relatedEntityId: opts?.kycProfileId,
  };
}
