import { storage } from "../storage";

export interface OfferingIssuanceResult {
  success: boolean;
  issuanceId?: string;
  error?: string;
  report?: OfferingIssuanceReport;
}

export interface OfferingIssuanceReport {
  offeringId: string;
  offeringName: string;
  vehicleId: string;
  vehicleName: string;
  spvId: string | null;
  spvLegalName: string | null;
  shareClassId: string | null;
  shareClassName: string | null;
  tokenId: string;
  tokenSymbol: string;
  totalSupplyMinted: string;
  totalAmountRaised: string;
  currency: string;
  holdersAllocated: number;
  allocations: Array<{
    userId: string;
    username: string;
    committedAmount: string;
    tokensAllocated: string;
    balanceBefore: string;
    balanceAfter: string;
  }>;
  capTableSnapshot: Array<{
    userId: string;
    investorName: string;
    balance: string;
    percentage: string;
  }>;
  propertyUnitAllocations?: Array<{
    userId: string;
    username: string;
    unitsAllocated: string;
    percentageOwned: string;
  }>;
  issuedAt: string;
  issuedBy: string;
}

export async function executeOfferingIssuance(
  offeringId: string,
  issuedByUserId: string
): Promise<OfferingIssuanceResult> {
  const offering = await storage.getOffering(offeringId);
  if (!offering) {
    return { success: false, error: "Offering not found" };
  }

  const existingIssuances = await storage.getTokenIssuancesByOffering(offeringId);
  if (existingIssuances.length > 0) {
    return { success: false, error: "Token issuance already completed for this offering" };
  }

  const totalCommitted = parseFloat(offering.totalCommitted || "0");
  const targetAmount = parseFloat(offering.targetAmount);
  if (totalCommitted < targetAmount) {
    return {
      success: false,
      error: `Offering is not fully funded. Committed ${offering.totalCommitted} of ${offering.targetAmount} target.`,
    };
  }

  const vehicle = await storage.getInvestmentVehicle(offering.vehicleId);
  if (!vehicle) {
    return { success: false, error: "Investment vehicle not found for this offering" };
  }

  let asset: any = null;
  let spv: any = null;
  let shareClass: any = null;

  const assets = await storage.getAssetsByVehicle(vehicle.id);
  if (assets.length > 0) {
    asset = assets[0];
    const spvs = await storage.getSpvEntitiesByAsset(asset.id);
    if (spvs.length > 0) {
      spv = spvs[0];
    } else {
      spv = await storage.createSpvEntity({
        assetId: asset.id,
        legalName: `${vehicle.name} SPV`,
        jurisdiction: "AE",
        regNumber: `SPV-${Date.now()}`,
        incorporationDate: new Date().toISOString().split("T")[0],
        status: "active",
      });
    }

    const existingShareClasses = await storage.getShareClassesBySpv(spv.id);
    if (existingShareClasses.length > 0) {
      shareClass = existingShareClasses[0];
    } else {
      shareClass = await storage.createShareClass({
        spvId: spv.id,
        name: `${vehicle.name} - Class A`,
        rightsSummary: "Standard equity participation rights",
        currency: vehicle.baseCurrency,
        totalSupply: "0",
      });
    }
  }

  const pricePerToken = asset ? parseFloat(asset.pricePerToken) : 1;
  if (pricePerToken <= 0) {
    return { success: false, error: "Asset price per token must be positive" };
  }

  const totalTokensToMint = (totalCommitted / pricePerToken).toFixed(6);
  const tokenSymbol = asset?.symbol || vehicle.name.replace(/\s/g, "").toUpperCase().slice(0, 8);

  const existingTokens = shareClass
    ? await storage.getTokensByShareClass(shareClass.id)
    : await storage.getTokensByVehicle(vehicle.id);
  let token;
  if (existingTokens.length > 0) {
    token = existingTokens[0];
  } else {
    token = await storage.createToken({
      shareClassId: shareClass?.id || null,
      vehicleId: vehicle.id,
      tokenSymbol,
      decimals: 6,
      totalSupply: "0",
      transferRestrictions: {
        offeringId,
        ...(spv ? { jurisdiction: spv.jurisdiction } : {}),
      },
    });
  }

  const offeringCommitments = await storage.getCommitmentsByOffering(offeringId);
  const eligibleCommitments = offeringCommitments.filter(
    (c) => c.status === "CONFIRMED" || c.status === "COOLING_OFF" || c.status === "SETTLED"
  );

  if (eligibleCommitments.length === 0) {
    return { success: false, error: "No confirmed or settled commitments found for this offering" };
  }

  const allocations: OfferingIssuanceReport["allocations"] = [];
  let holdersAllocated = 0;
  let totalActualMinted = 0;

  for (const commitment of eligibleCommitments) {
    const committedAmount = parseFloat(commitment.convertedAmount || commitment.amount);
    const tokensForInvestor = (committedAmount / pricePerToken).toFixed(6);
    const tokensNum = parseFloat(tokensForInvestor);

    if (tokensNum <= 0) continue;

    const existingHolding = await storage.getTokenHolding(commitment.userId, token.id);
    const balanceBefore = existingHolding?.balance || "0";
    const newBalance = (parseFloat(balanceBefore) + tokensNum).toFixed(6);

    await storage.upsertTokenHolding(commitment.userId, token.id, newBalance);

    await storage.createTokenLedgerEntry({
      tokenId: token.id,
      fromUserId: null,
      toUserId: commitment.userId,
      amount: tokensForInvestor,
      reason: "mint",
      refId: offeringId,
    });

    totalActualMinted += tokensNum;

    const investor = await storage.getUser(commitment.userId);
    allocations.push({
      userId: commitment.userId,
      username: investor?.username || commitment.userId,
      committedAmount: committedAmount.toFixed(2),
      tokensAllocated: tokensForInvestor,
      balanceBefore,
      balanceAfter: newBalance,
    });
    holdersAllocated++;

    if (commitment.status !== "SETTLED") {
      await storage.updateCommitmentStatus(commitment.id, "SETTLED");
    }
  }

  const currentTokenSupply = parseFloat(token.totalSupply || "0");
  const newTokenSupply = (currentTokenSupply + totalActualMinted).toFixed(6);
  await storage.updateTokenTotalSupply(token.id, newTokenSupply);

  if (shareClass) {
    const newShareClassSupply = (parseFloat(shareClass.totalSupply) + totalActualMinted).toFixed(6);
    await storage.updateShareClassTotalSupply(shareClass.id, newShareClassSupply);
  }

  let propertyUnitAllocations: Array<{
    userId: string;
    username: string;
    unitsAllocated: string;
    percentageOwned: string;
  }> = [];

  if (asset) {
    const propertyUnit = await storage.getPropertyUnit(asset.id);
    if (propertyUnit && propertyUnit.status === "active") {
      const totalPropertyUnits = parseFloat(propertyUnit.totalUnits);
      const alreadyIssued = parseFloat(propertyUnit.unitsIssued || "0");
      const remainingUnits = totalPropertyUnits - alreadyIssued;
      const unitsToAllocate = Math.min(totalPropertyUnits, remainingUnits);

      if (unitsToAllocate <= 0) {
        console.warn(`Property ${asset.id} has no remaining units to allocate (${alreadyIssued}/${totalPropertyUnits} issued)`);
      }

      const totalRaised = totalCommitted;
      let totalUnitsAllocated = 0;

      for (const alloc of allocations) {
        const contributionPercent = parseFloat(alloc.committedAmount) / totalRaised;
        const unitsForInvestor = parseFloat((contributionPercent * unitsToAllocate).toFixed(6));
        if (unitsForInvestor <= 0) continue;

        await storage.createPropertyUnitLedgerEntry({
          propertyUnitId: propertyUnit.id,
          assetId: asset.id,
          userId: alloc.userId,
          direction: "CREDIT",
          units: unitsForInvestor.toFixed(6),
          unitPriceAtTime: propertyUnit.unitPrice,
          totalValue: (unitsForInvestor * parseFloat(propertyUnit.unitPrice)).toFixed(2),
          reason: "ALLOCATE",
          refId: offeringId,
          notes: `Ownership allocation from offering ${offering.name} — ${(contributionPercent * 100).toFixed(2)}% contribution`,
        });

        totalUnitsAllocated += unitsForInvestor;

        propertyUnitAllocations.push({
          userId: alloc.userId,
          username: alloc.username,
          unitsAllocated: unitsForInvestor.toFixed(6),
          percentageOwned: (contributionPercent * 100).toFixed(4),
        });
      }

      const currentIssued = parseFloat(propertyUnit.unitsIssued || "0");
      await storage.updatePropertyUnit(asset.id, {
        unitsIssued: (currentIssued + totalUnitsAllocated).toFixed(6),
      } as any);
    }
  }

  const allHoldings = await storage.getTokenHoldingsByToken(token.id);
  const capTableSnapshot: OfferingIssuanceReport["capTableSnapshot"] = [];
  for (const h of allHoldings) {
    if (parseFloat(h.balance) <= 0) continue;
    const holder = await storage.getUser(h.userId);
    capTableSnapshot.push({
      userId: h.userId,
      investorName: holder?.fullName || "Unknown",
      balance: h.balance,
      percentage: ((parseFloat(h.balance) / parseFloat(newTokenSupply)) * 100).toFixed(4),
    });
  }

  const issuedBy = await storage.getUser(issuedByUserId);
  const report: OfferingIssuanceReport = {
    offeringId,
    offeringName: offering.name,
    vehicleId: vehicle.id,
    vehicleName: vehicle.name,
    spvId: spv?.id || null,
    spvLegalName: spv?.legalName || null,
    shareClassId: shareClass?.id || null,
    shareClassName: shareClass?.name || null,
    tokenId: token.id,
    tokenSymbol: token.tokenSymbol,
    totalSupplyMinted: totalActualMinted.toFixed(6),
    totalAmountRaised: totalCommitted.toFixed(2),
    currency: vehicle.baseCurrency,
    holdersAllocated,
    allocations,
    capTableSnapshot,
    ...(propertyUnitAllocations.length > 0 ? { propertyUnitAllocations } : {}),
    issuedAt: new Date().toISOString(),
    issuedBy: issuedBy?.username || issuedByUserId,
  };

  const issuanceData: any = {
    roundId: offeringId,
    assetId: asset?.id || vehicle.id,
    tokenId: token.id,
    spvId: spv?.id || vehicle.id,
    shareClassId: shareClass?.id || vehicle.id,
    totalSupplyMinted: totalActualMinted.toFixed(6),
    holdersAllocated,
    totalAmountRaised: totalCommitted.toFixed(2),
    currency: vehicle.baseCurrency,
    issuedBy: issuedByUserId,
    issuanceReport: report,
  };

  const issuance = await storage.createTokenIssuance(issuanceData);

  return {
    success: true,
    issuanceId: issuance.id,
    report,
  };
}
