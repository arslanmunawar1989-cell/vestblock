export interface RentSource {
  id: string;
  grossRent: string;
  currency: string;
  baseCurrencyAmount: string;
  baseCurrency: string;
  fxRate: string;
  receivedDate: string;
  occupancyRate?: string;
  vacancyAdjustment?: string;
  latePaymentPenalty?: string;
  effectiveRent?: string;
}

export interface ExpenseSource {
  id: string;
  category: string;
  description: string | null;
  amount: string;
  currency: string;
  baseCurrencyAmount: string;
  baseCurrency: string;
  fxRate: string;
}

export interface ExpenseCategoryDetail {
  category: string;
  count: number;
  totalAmount: string;
  expenseIds: string[];
}

export interface WaterfallInput {
  grossRent: number;
  vacancyImpact: number;
  expensesByCategory: Record<string, number>;
  platformFeePercent: number;
  reservePercent: number;
  totalUnits?: number;
}

export interface WaterfallStep {
  label: string;
  amount: string;
  runningTotal: string;
  tier: "income" | "vacancy" | "effective" | "expense" | "noi" | "reserve" | "distributable" | "per_unit";
  percentOfGross?: string;
}

export interface UnitDistribution {
  totalUnits: string;
  incomePerUnit: string;
  currency: string;
}

export interface InvestorPayout {
  userId: string;
  username?: string;
  units: string;
  incomePerUnit: string;
  totalPayout: string;
}

export interface WaterfallProofs {
  assetId: string;
  period: string;
  baseCurrency: string;
  calculatedAt: string;
  rentSources: RentSource[];
  expenseSources: ExpenseSource[];
  expensesByCategory: ExpenseCategoryDetail[];
  feeRates: {
    reservePercent: string;
    platformFeePercent: string;
  };
  crossCheck: {
    grossRentFromSources: string;
    totalExpensesFromSources: string;
    noiCheck: string;
    reservePlusDistributable: string;
  };
}

export interface WaterfallOutput {
  grossRent: string;
  vacancyImpact: string;
  effectiveRent: string;
  maintenanceExpense: string;
  managementFeeExpense: string;
  insuranceExpense: string;
  propertyTaxExpense: string;
  utilityExpense: string;
  platformFeePercent: string;
  platformFeeAmount: string;
  otherExpense: string;
  totalExpenses: string;
  netOperatingIncome: string;
  reservePercent: string;
  reserveAmount: string;
  distributableIncome: string;
  unitDistribution: UnitDistribution | null;
  breakdown: WaterfallStep[];
  totalFees: string;
  netDistributable: string;
  propertyMgmtFeePercent: string;
  propertyMgmtFeeAmount: string;
  trusteeFeePercent: string;
  trusteeFeeAmount: string;
}

export interface WaterfallWithProofs extends WaterfallOutput {
  proofs: WaterfallProofs;
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

function round6(n: number): number {
  return Math.round(n * 1000000) / 1000000;
}

export function calculateWaterfall(input: WaterfallInput): WaterfallOutput {
  const { grossRent, vacancyImpact, expensesByCategory, platformFeePercent, reservePercent, totalUnits } = input;

  if (grossRent < 0) throw new Error("Gross rent cannot be negative");

  const effectiveRent = round2(grossRent - vacancyImpact);

  const maintenance = round2(expensesByCategory["maintenance"] || 0);
  const managementFee = round2(expensesByCategory["management_fee"] || 0);
  const insurance = round2(expensesByCategory["insurance"] || 0);
  const propertyTax = round2(expensesByCategory["property_tax"] || 0);
  const utility = round2(expensesByCategory["utility_reserve"] || 0);
  const other = round2(expensesByCategory["other"] || 0);

  const platformFeeAmount = round2(effectiveRent * (platformFeePercent / 100));

  const totalOpEx = round2(maintenance + managementFee + insurance + propertyTax + utility + platformFeeAmount + other);

  const noi = round2(effectiveRent - totalOpEx);

  const reserveAmount = round2(noi > 0 ? noi * (reservePercent / 100) : 0);
  const distributableIncome = round2(noi - reserveAmount);

  let unitDist: UnitDistribution | null = null;
  if (totalUnits && totalUnits > 0) {
    const incomePerUnit = round6(distributableIncome / totalUnits);
    unitDist = {
      totalUnits: totalUnits.toString(),
      incomePerUnit: incomePerUnit.toFixed(6),
      currency: "",
    };
  }

  const pctOfGross = (amount: number) => grossRent > 0 ? ((amount / grossRent) * 100).toFixed(2) : "0.00";

  let running = grossRent;
  const breakdown: WaterfallStep[] = [];

  breakdown.push({ label: "Gross Rent", amount: grossRent.toFixed(2), runningTotal: running.toFixed(2), tier: "income" });

  running = round2(running - vacancyImpact);
  breakdown.push({ label: "Less: Vacancy Impact", amount: `-${vacancyImpact.toFixed(2)}`, runningTotal: running.toFixed(2), tier: "vacancy", percentOfGross: pctOfGross(vacancyImpact) });

  breakdown.push({ label: "Effective Rent", amount: effectiveRent.toFixed(2), runningTotal: running.toFixed(2), tier: "effective" });

  running = round2(running - maintenance);
  breakdown.push({ label: "Less: Maintenance", amount: `-${maintenance.toFixed(2)}`, runningTotal: running.toFixed(2), tier: "expense", percentOfGross: pctOfGross(maintenance) });

  running = round2(running - managementFee);
  breakdown.push({ label: "Less: Property Management Fee", amount: `-${managementFee.toFixed(2)}`, runningTotal: running.toFixed(2), tier: "expense", percentOfGross: pctOfGross(managementFee) });

  running = round2(running - insurance);
  breakdown.push({ label: "Less: Insurance", amount: `-${insurance.toFixed(2)}`, runningTotal: running.toFixed(2), tier: "expense", percentOfGross: pctOfGross(insurance) });

  running = round2(running - propertyTax);
  breakdown.push({ label: "Less: Property Tax", amount: `-${propertyTax.toFixed(2)}`, runningTotal: running.toFixed(2), tier: "expense", percentOfGross: pctOfGross(propertyTax) });

  running = round2(running - utility);
  breakdown.push({ label: "Less: Utilities", amount: `-${utility.toFixed(2)}`, runningTotal: running.toFixed(2), tier: "expense", percentOfGross: pctOfGross(utility) });

  running = round2(running - platformFeeAmount);
  breakdown.push({ label: `Less: Platform Management Fee (${platformFeePercent}%)`, amount: `-${platformFeeAmount.toFixed(2)}`, runningTotal: running.toFixed(2), tier: "expense", percentOfGross: pctOfGross(platformFeeAmount) });

  if (other > 0) {
    running = round2(running - other);
    breakdown.push({ label: "Less: Other Expenses", amount: `-${other.toFixed(2)}`, runningTotal: running.toFixed(2), tier: "expense", percentOfGross: pctOfGross(other) });
  }

  breakdown.push({ label: "Net Operating Income (NOI)", amount: noi.toFixed(2), runningTotal: noi.toFixed(2), tier: "noi" });

  running = round2(noi - reserveAmount);
  breakdown.push({ label: `Less: Reserve Allocation (${reservePercent}%)`, amount: `-${reserveAmount.toFixed(2)}`, runningTotal: running.toFixed(2), tier: "reserve", percentOfGross: pctOfGross(reserveAmount) });

  breakdown.push({ label: "Distributable Income", amount: distributableIncome.toFixed(2), runningTotal: distributableIncome.toFixed(2), tier: "distributable" });

  if (unitDist) {
    breakdown.push({
      label: `Income Per Unit (${unitDist.totalUnits} units)`,
      amount: unitDist.incomePerUnit,
      runningTotal: unitDist.incomePerUnit,
      tier: "per_unit",
    });
  }

  return {
    grossRent: grossRent.toFixed(2),
    vacancyImpact: vacancyImpact.toFixed(2),
    effectiveRent: effectiveRent.toFixed(2),
    maintenanceExpense: maintenance.toFixed(2),
    managementFeeExpense: managementFee.toFixed(2),
    insuranceExpense: insurance.toFixed(2),
    propertyTaxExpense: propertyTax.toFixed(2),
    utilityExpense: utility.toFixed(2),
    platformFeePercent: platformFeePercent.toFixed(4),
    platformFeeAmount: platformFeeAmount.toFixed(2),
    otherExpense: other.toFixed(2),
    totalExpenses: totalOpEx.toFixed(2),
    netOperatingIncome: noi.toFixed(2),
    reservePercent: reservePercent.toFixed(4),
    reserveAmount: reserveAmount.toFixed(2),
    distributableIncome: distributableIncome.toFixed(2),
    unitDistribution: unitDist,
    breakdown,
    totalFees: platformFeeAmount.toFixed(2),
    netDistributable: distributableIncome.toFixed(2),
    propertyMgmtFeePercent: "0.0000",
    propertyMgmtFeeAmount: "0.00",
    trusteeFeePercent: "0.0000",
    trusteeFeeAmount: "0.00",
  };
}

export function buildProofs(
  assetId: string,
  period: string,
  baseCurrency: string,
  result: WaterfallOutput,
  rents: Array<{ id: string; grossRent: string; currency: string; baseCurrencyAmount: string | null; baseCurrency: string | null; fxRate: string | null; receivedDate: string; occupancyRate?: string | null; vacancyAdjustment?: string | null; latePaymentPenalty?: string | null; effectiveRent?: string | null }>,
  expenses: Array<{ id: string; category: string; description: string | null; amount: string; currency: string; baseCurrencyAmount: string | null; baseCurrency: string | null; fxRate: string | null }>,
  feeRates: { reservePercent: number; platformFeePercent: number; propertyMgmtFeePercent?: number; trusteeFeePercent?: number }
): WaterfallProofs {
  const rentSources: RentSource[] = rents.map(r => ({
    id: r.id,
    grossRent: r.grossRent,
    currency: r.currency,
    baseCurrencyAmount: r.baseCurrencyAmount || r.grossRent,
    baseCurrency: r.baseCurrency || baseCurrency,
    fxRate: r.fxRate || "1.000000",
    receivedDate: r.receivedDate,
    occupancyRate: r.occupancyRate || "100.00",
    vacancyAdjustment: r.vacancyAdjustment || "0",
    latePaymentPenalty: r.latePaymentPenalty || "0",
    effectiveRent: r.effectiveRent || r.grossRent,
  }));

  const expenseSources: ExpenseSource[] = expenses.map(e => ({
    id: e.id,
    category: e.category,
    description: e.description,
    amount: e.amount,
    currency: e.currency,
    baseCurrencyAmount: e.baseCurrencyAmount || e.amount,
    baseCurrency: e.baseCurrency || baseCurrency,
    fxRate: e.fxRate || "1.000000",
  }));

  const categoryMap: Record<string, { count: number; total: number; ids: string[] }> = {};
  for (const e of expenseSources) {
    if (!categoryMap[e.category]) {
      categoryMap[e.category] = { count: 0, total: 0, ids: [] };
    }
    categoryMap[e.category].count++;
    categoryMap[e.category].total += parseFloat(e.baseCurrencyAmount);
    categoryMap[e.category].ids.push(e.id);
  }

  const expensesByCategory: ExpenseCategoryDetail[] = Object.entries(categoryMap)
    .sort(([, a], [, b]) => b.total - a.total)
    .map(([category, data]) => ({
      category,
      count: data.count,
      totalAmount: data.total.toFixed(2),
      expenseIds: data.ids,
    }));

  const grossRentCheck = rentSources.reduce((s, r) => s + parseFloat(r.baseCurrencyAmount), 0);
  const expenseCheck = expenseSources.reduce((s, e) => s + parseFloat(e.baseCurrencyAmount), 0);
  const noiVal = parseFloat(result.netOperatingIncome);
  const reserveVal = parseFloat(result.reserveAmount);
  const distributableVal = parseFloat(result.distributableIncome);

  return {
    assetId,
    period,
    baseCurrency,
    calculatedAt: new Date().toISOString(),
    rentSources,
    expenseSources,
    expensesByCategory,
    feeRates: {
      reservePercent: feeRates.reservePercent.toFixed(4),
      platformFeePercent: feeRates.platformFeePercent.toFixed(4),
    },
    crossCheck: {
      grossRentFromSources: grossRentCheck.toFixed(2),
      totalExpensesFromSources: expenseCheck.toFixed(2),
      noiCheck: noiVal.toFixed(2),
      reservePlusDistributable: round2(reserveVal + distributableVal).toFixed(2),
    },
  };
}
