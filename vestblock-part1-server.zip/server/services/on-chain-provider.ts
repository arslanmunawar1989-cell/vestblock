export interface OnChainReceipt {
  txHash: string;
  blockNumber?: number;
  chain: string;
  timestamp: string;
}

export interface MintParams {
  tokenSymbol: string;
  recipientAddress: string;
  amount: string;
  tokenId: string;
  metadata?: Record<string, unknown>;
}

export interface TransferParams {
  tokenSymbol: string;
  fromAddress: string;
  toAddress: string;
  amount: string;
  tokenId: string;
  metadata?: Record<string, unknown>;
}

export interface BurnParams {
  tokenSymbol: string;
  holderAddress: string;
  amount: string;
  tokenId: string;
  metadata?: Record<string, unknown>;
}

export interface OnChainProvider {
  readonly name: string;
  readonly enabled: boolean;

  mint(params: MintParams): Promise<OnChainReceipt>;
  transfer(params: TransferParams): Promise<OnChainReceipt>;
  burn(params: BurnParams): Promise<OnChainReceipt>;
}

class NoOpProvider implements OnChainProvider {
  readonly name = "noop";
  readonly enabled = false;

  async mint(params: MintParams): Promise<OnChainReceipt> {
    return {
      txHash: `offchain-mint-${Date.now()}`,
      chain: "off-chain",
      timestamp: new Date().toISOString(),
    };
  }

  async transfer(params: TransferParams): Promise<OnChainReceipt> {
    return {
      txHash: `offchain-transfer-${Date.now()}`,
      chain: "off-chain",
      timestamp: new Date().toISOString(),
    };
  }

  async burn(params: BurnParams): Promise<OnChainReceipt> {
    return {
      txHash: `offchain-burn-${Date.now()}`,
      chain: "off-chain",
      timestamp: new Date().toISOString(),
    };
  }
}

let currentProvider: OnChainProvider = new NoOpProvider();

export function getOnChainProvider(): OnChainProvider {
  return currentProvider;
}

export function setOnChainProvider(provider: OnChainProvider): void {
  console.log(`[on-chain] Provider set to "${provider.name}" (enabled=${provider.enabled})`);
  currentProvider = provider;
}
