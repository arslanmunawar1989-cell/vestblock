import { storage } from "../storage";
import type { InvestorType } from "@shared/schema";
import { INVESTOR_TYPE_RANK } from "@shared/schema";
import {
  getCountryPolicy,
  getInvestorPolicy,
  isSanctionedCountry,
  isBlockedNationality,
  meetsInvestorTypeRequirement,
  type PaymentRailId,
  type InvestorTypePolicy,
  type CountryInvestorPolicy,
} from "@shared/investor-policy";

export interface PolicyContext {
  userId: string;
  countryOfResidence: string | null;
  nationality: string | null;
  taxResidency: string | null;
  investorType: InvestorType;
  kycStatus: string;
  eddStatus: string;
  isActive: boolean;
}

export interface PolicyResult {
  allowed: boolean;
  reason: string | null;
  code: string;
  details?: Record<string, unknown>;
}

function deny(code: string, reason: string, details?: Record<string, unknown>): PolicyResult {
  return { allowed: false, reason, code, details };
}

function allow(): PolicyResult {
  return { allowed: true, reason: null, code: "OK" };
}

function checkSanctions(ctx: PolicyContext): PolicyResult | null {
  if (ctx.countryOfResidence && isSanctionedCountry(ctx.countryOfResidence)) {
    return deny("SANCTIONED_RESIDENCE", "Country of residence is on the sanctions list");
  }
  if (ctx.nationality && isBlockedNationality(ctx.nationality)) {
    return deny("BLOCKED_NATIONALITY", "Nationality is on the blocked list");
  }
  if (ctx.taxResidency && isSanctionedCountry(ctx.taxResidency)) {
    return deny("SANCTIONED_TAX_RESIDENCY", "Tax residency country is sanctioned");
  }
  return null;
}

function checkBasicEligibility(ctx: PolicyContext, typePolicy?: InvestorTypePolicy | null): PolicyResult | null {
  if (!ctx.isActive) {
    return deny("ACCOUNT_INACTIVE", "Account is deactivated");
  }
  const requiresKyc = typePolicy?.requiresKyc ?? true;
  if (requiresKyc && ctx.kycStatus !== "approved" && ctx.kycStatus !== "APPROVED") {
    return deny("KYC_NOT_APPROVED", "KYC verification must be approved before proceeding");
  }
  const requiresEdd = typePolicy?.requiresEdd ?? false;
  if (requiresEdd && ctx.eddStatus !== "completed" && ctx.eddStatus !== "COMPLETED") {
    return deny("EDD_NOT_COMPLETED", "Enhanced due diligence must be completed for your investor type");
  }
  return null;
}

function resolveCountry(ctx: PolicyContext): string | null {
  return ctx.countryOfResidence || ctx.nationality || ctx.taxResidency || null;
}

export async function buildPolicyContext(userId: string): Promise<PolicyContext> {
  const user = await storage.getUser(userId);
  if (!user) {
    throw new Error(`User not found: ${userId}`);
  }
  return {
    userId: user.id,
    countryOfResidence: (user as any).countryOfResidence ?? user.nationality ?? null,
    nationality: user.nationality ?? null,
    taxResidency: (user as any).taxResidency ?? null,
    investorType: ((user as any).investorType ?? "retail") as InvestorType,
    kycStatus: user.kycStatus,
    eddStatus: user.eddStatus ?? "none",
    isActive: user.isActive,
  };
}

function resolveTypePolicy(ctx: PolicyContext): { countryPolicy: CountryInvestorPolicy | null; typePolicy: InvestorTypePolicy | null; country: string | null } {
  const country = resolveCountry(ctx);
  if (!country) return { countryPolicy: null, typePolicy: null, country: null };
  const countryPolicy = getCountryPolicy(country);
  if (!countryPolicy) return { countryPolicy: null, typePolicy: null, country };
  const typePolicy = countryPolicy.investorPolicies[ctx.investorType] ?? null;
  return { countryPolicy, typePolicy, country };
}

export function canInvest(
  ctx: PolicyContext,
  assetMinInvestorType?: InvestorType,
  investAmount?: number
): PolicyResult {
  const sanctions = checkSanctions(ctx);
  if (sanctions) return sanctions;

  const { countryPolicy, typePolicy, country } = resolveTypePolicy(ctx);

  const basic = checkBasicEligibility(ctx, typePolicy);
  if (basic) return basic;

  if (!country) {
    return deny("NO_COUNTRY", "Country of residence must be set before investing");
  }

  if (!countryPolicy) {
    return deny("UNSUPPORTED_COUNTRY", "Investing is not available in your country");
  }
  if (countryPolicy.sanctioned || countryPolicy.blocked) {
    return deny("COUNTRY_BLOCKED", countryPolicy.blockReason || "Country is blocked from investing");
  }

  if (!typePolicy) {
    return deny("INVESTOR_TYPE_UNAVAILABLE", "Your investor type is not available in this country");
  }

  if (assetMinInvestorType && !meetsInvestorTypeRequirement(ctx.investorType, assetMinInvestorType)) {
    return deny("INVESTOR_TYPE_TOO_LOW", `This asset requires at least ${assetMinInvestorType} investor status`, {
      required: assetMinInvestorType,
      current: ctx.investorType,
    });
  }

  if (investAmount !== undefined) {
    if (investAmount < typePolicy.minInvestAmount) {
      return deny("BELOW_MIN_INVEST", `Minimum investment amount is ${typePolicy.minInvestAmount}`, {
        min: typePolicy.minInvestAmount,
      });
    }
    if (typePolicy.maxInvestAmount !== null && investAmount > typePolicy.maxInvestAmount) {
      return deny("ABOVE_MAX_INVEST", `Maximum investment amount is ${typePolicy.maxInvestAmount}`, {
        max: typePolicy.maxInvestAmount,
      });
    }
  }

  return allow();
}

export function canDeposit(ctx: PolicyContext, rail: PaymentRailId): PolicyResult {
  const sanctions = checkSanctions(ctx);
  if (sanctions) return sanctions;

  const { countryPolicy, typePolicy, country } = resolveTypePolicy(ctx);

  const basic = checkBasicEligibility(ctx, typePolicy);
  if (basic) return basic;

  if (!country) {
    return deny("NO_COUNTRY", "Country of residence must be set before depositing");
  }

  if (!countryPolicy) {
    return deny("UNSUPPORTED_COUNTRY", "Deposits are not available in your country");
  }

  if (!typePolicy) {
    return deny("INVESTOR_TYPE_UNAVAILABLE", "Your investor type is not available in this country");
  }

  if (rail === "crypto" && !typePolicy.cryptoAllowed) {
    return deny("CRYPTO_NOT_ALLOWED", "Crypto deposits are not available for your investor type in this country");
  }

  if (!typePolicy.allowedRails.includes(rail)) {
    return deny("RAIL_NOT_ALLOWED", `Payment method '${rail}' is not available for your investor type`, {
      allowedRails: typePolicy.allowedRails,
    });
  }

  return allow();
}

export function canTrade(ctx: PolicyContext): PolicyResult {
  const sanctions = checkSanctions(ctx);
  if (sanctions) return sanctions;

  const { countryPolicy, typePolicy, country } = resolveTypePolicy(ctx);

  const basic = checkBasicEligibility(ctx, typePolicy);
  if (basic) return basic;

  if (!country) {
    return deny("NO_COUNTRY", "Country of residence must be set before trading");
  }

  if (!countryPolicy) {
    return deny("UNSUPPORTED_COUNTRY", "Trading is not available in your country");
  }

  if (!typePolicy) {
    return deny("INVESTOR_TYPE_UNAVAILABLE", "Your investor type is not available in this country");
  }

  if (!typePolicy.canTrade) {
    return deny("TRADING_NOT_ALLOWED", "Secondary market trading is not available for your investor type", {
      investorType: ctx.investorType,
    });
  }

  return allow();
}

export function canHoldToken(
  ctx: PolicyContext,
  tokenMinInvestorType?: InvestorType
): PolicyResult {
  const sanctions = checkSanctions(ctx);
  if (sanctions) return sanctions;

  if (!ctx.isActive) {
    return deny("ACCOUNT_INACTIVE", "Account is deactivated");
  }

  const country = resolveCountry(ctx);
  if (country) {
    const countryPolicy = getCountryPolicy(country);
    if (countryPolicy && (countryPolicy.sanctioned || countryPolicy.blocked)) {
      return deny("COUNTRY_BLOCKED", "Country is blocked");
    }
  }

  if (tokenMinInvestorType && !meetsInvestorTypeRequirement(ctx.investorType, tokenMinInvestorType)) {
    return deny("INVESTOR_TYPE_TOO_LOW", `This token requires at least ${tokenMinInvestorType} investor status`, {
      required: tokenMinInvestorType,
      current: ctx.investorType,
    });
  }

  return allow();
}

export function getEffectivePolicy(ctx: PolicyContext): {
  countryPolicy: CountryInvestorPolicy | null;
  investorPolicy: InvestorTypePolicy | null;
  investorType: InvestorType;
  country: string | null;
} {
  const country = resolveCountry(ctx);
  const countryPolicy = country ? getCountryPolicy(country) : null;
  const investorPolicy = country ? getInvestorPolicy(country, ctx.investorType) : null;
  return {
    countryPolicy,
    investorPolicy,
    investorType: ctx.investorType,
    country,
  };
}
