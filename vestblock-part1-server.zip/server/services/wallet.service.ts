import { storage } from "../storage";
import { LIQUIDITY_RULES } from "@shared/schema";
import crypto from "crypto";

export const LEDGER_ENTRY_TYPES = {
  DEPOSIT_PENDING: "DEPOSIT_PENDING",
  DEPOSIT_CONFIRMED: "DEPOSIT_CONFIRMED",
  RESERVE: "RESERVE",
  RELEASE_RESERVE: "RELEASE_RESERVE",
  CAPTURE: "CAPTURE",
  FX_CONVERT_DEBIT: "FX_CONVERT_DEBIT",
  FX_CONVERT_CREDIT: "FX_CONVERT_CREDIT",
  DISTRIBUTION_CREDIT: "DISTRIBUTION_CREDIT",
  WITHDRAW_REQUESTED: "WITHDRAW_REQUESTED",
  WITHDRAW_APPROVED: "WITHDRAW_APPROVED",
  WITHDRAW_PAID: "WITHDRAW_PAID",
  WITHDRAW_REJECTED: "WITHDRAW_REJECTED",
  FEE: "FEE",
  REVERSAL: "REVERSAL",
  CAPITAL_REDEMPTION: "CAPITAL_REDEMPTION",
} as const;

export type LedgerEntryType = (typeof LEDGER_ENTRY_TYPES)[keyof typeof LEDGER_ENTRY_TYPES];

export const SUPPORTED_CURRENCIES = ["PKR", "AED", "USD", "GBP", "QAR", "USDT", "USDC"] as const;
export type SupportedCurrency = (typeof SUPPORTED_CURRENCIES)[number];

function generateLedgerTxId(): string {
  return `ltx_${crypto.randomUUID()}`;
}

function toFixed6(n: number): string {
  return n.toFixed(6);
}

export interface WalletBalance {
  walletAccountId: string;
  currency: string;
  available: string;
  reserved: string;
  pending: string;
  total: string;
}

export interface DepositIntentResult {
  walletAccountId: string;
  ledgerTxId: string;
  currency: string;
  amount: string;
  status: "PENDING";
}

export interface DepositConfirmResult {
  walletAccountId: string;
  ledgerTxId: string;
  currency: string;
  amount: string;
  status: "CONFIRMED";
}

export interface ReserveResult {
  walletAccountId: string;
  reserveLedgerTxId: string;
  currency: string;
  amount: string;
  referenceId: string;
}

export interface CaptureResult {
  walletAccountId: string;
  captureLedgerTxId: string;
  currency: string;
  amount: string;
  referenceId: string;
}

export interface FxConvertResult {
  debitWalletId: string;
  creditWalletId: string;
  ledgerTxId: string;
  fromCurrency: string;
  toCurrency: string;
  fromAmount: string;
  toAmount: string;
  rate: string;
}

export interface WithdrawalResult {
  walletAccountId: string;
  ledgerTxId: string;
  currency: string;
  grossAmount: string;
  fee: string;
  netAmount: string;
}

export class WalletService {
  private computeBalance(entries: any[]): { total: number; reserved: number; available: number; pending: number } {
    let settledCredits = 0;
    let settledDebits = 0;
    let pendingCredits = 0;
    let pendingDebits = 0;
    let reserved = 0;

    const HOLD_TYPES = new Set([
      LEDGER_ENTRY_TYPES.RESERVE,
      LEDGER_ENTRY_TYPES.RELEASE_RESERVE,
    ]);

    for (const entry of entries) {
      const amt = parseFloat(entry.amount);
      if (entry.status === "REVERSED") continue;
      if (entry.entryType === LEDGER_ENTRY_TYPES.REVERSAL) continue;

      if (entry.status === "PENDING") {
        if (entry.direction === "CREDIT") pendingCredits += amt;
        else pendingDebits += amt;
        continue;
      }

      if (HOLD_TYPES.has(entry.entryType)) {
        if (entry.entryType === LEDGER_ENTRY_TYPES.RESERVE) reserved += amt;
        if (entry.entryType === LEDGER_ENTRY_TYPES.RELEASE_RESERVE) reserved -= amt;
        continue;
      }

      if (entry.entryType === LEDGER_ENTRY_TYPES.CAPTURE) {
        settledDebits += amt;
        reserved -= amt;
        continue;
      }

      if (entry.direction === "CREDIT") settledCredits += amt;
      else settledDebits += amt;
    }

    reserved = Math.max(0, reserved);
    const total = settledCredits - settledDebits;
    const available = total - reserved;
    const pending = pendingCredits - pendingDebits;

    return { total, reserved, available, pending };
  }

  async getBalances(userId: string): Promise<WalletBalance[]> {
    const accounts = await storage.getWalletAccountsByUser(userId);
    const balances: WalletBalance[] = [];

    for (const acc of accounts) {
      const entries = await storage.getLedgerEntriesByAccount(acc.id);
      const bal = this.computeBalance(entries);

      balances.push({
        walletAccountId: acc.id,
        currency: acc.currency,
        available: toFixed6(bal.available),
        reserved: toFixed6(bal.reserved),
        pending: toFixed6(bal.pending),
        total: toFixed6(bal.total),
      });
    }

    return balances;
  }

  async getBalanceForWallet(walletAccountId: string): Promise<WalletBalance> {
    const account = await storage.getWalletAccount(walletAccountId);
    if (!account) throw new Error("Wallet account not found");

    const entries = await storage.getLedgerEntriesByAccount(walletAccountId);
    const bal = this.computeBalance(entries);

    return {
      walletAccountId,
      currency: account.currency,
      available: toFixed6(bal.available),
      reserved: toFixed6(bal.reserved),
      pending: toFixed6(bal.pending),
      total: toFixed6(bal.total),
    };
  }

  async depositIntent(params: {
    userId: string;
    currency: string;
    amount: number;
    description?: string;
    referenceId?: string;
    metadata?: Record<string, any>;
  }): Promise<DepositIntentResult> {
    if (params.amount <= 0) throw new Error("Amount must be positive");

    const wallet = await storage.getOrCreateWallet(params.userId, params.currency);
    const ledgerTxId = generateLedgerTxId();

    await storage.createLedgerEntries([{
      ledgerTxId,
      walletAccountId: wallet.id,
      currency: params.currency,
      amount: toFixed6(params.amount),
      direction: "CREDIT",
      status: "PENDING",
      entryType: LEDGER_ENTRY_TYPES.DEPOSIT_PENDING,
      referenceId: params.referenceId || null,
      description: params.description || "Deposit intent",
      metadata: params.metadata || null,
    }]);

    return {
      walletAccountId: wallet.id,
      ledgerTxId,
      currency: params.currency,
      amount: toFixed6(params.amount),
      status: "PENDING",
    };
  }

  async confirmDeposit(params: {
    ledgerTxId: string;
    confirmedAmount?: number;
    metadata?: Record<string, any>;
  }): Promise<DepositConfirmResult> {
    const pendingEntries = await storage.getLedgerEntriesByTxId(params.ledgerTxId);
    const depositEntry = pendingEntries.find(
      (e) => e.entryType === LEDGER_ENTRY_TYPES.DEPOSIT_PENDING && e.status === "PENDING"
    );

    if (!depositEntry) {
      throw new Error(`No pending deposit found for ledger tx: ${params.ledgerTxId}`);
    }

    await storage.reverseLedgerEntries(params.ledgerTxId, "Deposit confirmed - converting pending to posted");

    const confirmedAmount = params.confirmedAmount ?? parseFloat(depositEntry.amount);
    const confirmTxId = generateLedgerTxId();

    await storage.createLedgerEntries([{
      ledgerTxId: confirmTxId,
      walletAccountId: depositEntry.walletAccountId,
      currency: depositEntry.currency,
      amount: toFixed6(confirmedAmount),
      direction: "CREDIT",
      status: "POSTED",
      entryType: LEDGER_ENTRY_TYPES.DEPOSIT_CONFIRMED,
      referenceId: depositEntry.referenceId,
      description: "Deposit confirmed",
      metadata: { originalLedgerTxId: params.ledgerTxId, ...params.metadata },
    }]);

    return {
      walletAccountId: depositEntry.walletAccountId,
      ledgerTxId: confirmTxId,
      currency: depositEntry.currency,
      amount: toFixed6(confirmedAmount),
      status: "CONFIRMED",
    };
  }

  async directDeposit(params: {
    userId: string;
    currency: string;
    amount: number;
    description?: string;
    referenceId?: string;
    metadata?: Record<string, any>;
  }): Promise<DepositConfirmResult> {
    if (params.amount <= 0) throw new Error("Amount must be positive");

    const wallet = await storage.getOrCreateWallet(params.userId, params.currency);
    const ledgerTxId = generateLedgerTxId();

    await storage.createLedgerEntries([{
      ledgerTxId,
      walletAccountId: wallet.id,
      currency: params.currency,
      amount: toFixed6(params.amount),
      direction: "CREDIT",
      status: "POSTED",
      entryType: LEDGER_ENTRY_TYPES.DEPOSIT_CONFIRMED,
      referenceId: params.referenceId || null,
      description: params.description || "Direct deposit",
      metadata: params.metadata || null,
    }]);

    return {
      walletAccountId: wallet.id,
      ledgerTxId,
      currency: params.currency,
      amount: toFixed6(params.amount),
      status: "CONFIRMED",
    };
  }

  async reserveFunds(params: {
    userId: string;
    currency: string;
    amount: number;
    referenceId: string;
    description?: string;
    metadata?: Record<string, any>;
  }): Promise<ReserveResult> {
    if (params.amount <= 0) throw new Error("Amount must be positive");

    const wallet = await storage.getOrCreateWallet(params.userId, params.currency);
    const balance = await this.getBalanceForWallet(wallet.id);
    const availableForReserve = parseFloat(balance.available);

    if (availableForReserve < params.amount) {
      throw new Error(
        `Insufficient available balance. Available: ${toFixed6(availableForReserve)}, Requested: ${toFixed6(params.amount)}`
      );
    }

    const ledgerTxId = generateLedgerTxId();

    await storage.createLedgerEntries([{
      ledgerTxId,
      walletAccountId: wallet.id,
      currency: params.currency,
      amount: toFixed6(params.amount),
      direction: "DEBIT",
      status: "POSTED",
      entryType: LEDGER_ENTRY_TYPES.RESERVE,
      referenceId: params.referenceId,
      description: params.description || `Reserve for ${params.referenceId}`,
      metadata: params.metadata || null,
    }]);

    return {
      walletAccountId: wallet.id,
      reserveLedgerTxId: ledgerTxId,
      currency: params.currency,
      amount: toFixed6(params.amount),
      referenceId: params.referenceId,
    };
  }

  async releaseReserve(params: {
    reserveLedgerTxId: string;
    reason?: string;
  }): Promise<void> {
    const reserveEntries = await storage.getLedgerEntriesByTxId(params.reserveLedgerTxId);
    const reserveEntry = reserveEntries.find(
      (e) => e.entryType === LEDGER_ENTRY_TYPES.RESERVE && e.status === "POSTED"
    );

    if (!reserveEntry) {
      throw new Error(`No active reserve found for ledger tx: ${params.reserveLedgerTxId}`);
    }

    const releaseTxId = generateLedgerTxId();
    await storage.createLedgerEntries([{
      ledgerTxId: releaseTxId,
      walletAccountId: reserveEntry.walletAccountId,
      currency: reserveEntry.currency,
      amount: reserveEntry.amount,
      direction: "CREDIT",
      status: "POSTED",
      entryType: LEDGER_ENTRY_TYPES.RELEASE_RESERVE,
      referenceId: reserveEntry.referenceId,
      description: params.reason || `Release reserve from ${params.reserveLedgerTxId}`,
      metadata: { originalReserveTxId: params.reserveLedgerTxId },
    }]);
  }

  async captureFunds(params: {
    reserveLedgerTxId: string;
    captureAmount?: number;
    description?: string;
    metadata?: Record<string, any>;
  }): Promise<CaptureResult> {
    const reserveEntries = await storage.getLedgerEntriesByTxId(params.reserveLedgerTxId);
    const reserveEntry = reserveEntries.find(
      (e) => e.entryType === LEDGER_ENTRY_TYPES.RESERVE && e.status === "POSTED"
    );

    if (!reserveEntry) {
      throw new Error(`No active reserve found for ledger tx: ${params.reserveLedgerTxId}`);
    }

    const reservedAmount = parseFloat(reserveEntry.amount);
    const captureAmount = params.captureAmount ?? reservedAmount;

    if (captureAmount > reservedAmount) {
      throw new Error(
        `Capture amount (${captureAmount}) exceeds reserved amount (${reservedAmount})`
      );
    }

    const captureTxId = generateLedgerTxId();
    const entries: any[] = [];

    if (captureAmount < reservedAmount) {
      const releaseAmount = reservedAmount - captureAmount;
      entries.push({
        ledgerTxId: captureTxId,
        walletAccountId: reserveEntry.walletAccountId,
        currency: reserveEntry.currency,
        amount: toFixed6(releaseAmount),
        direction: "CREDIT",
        status: "POSTED",
        entryType: LEDGER_ENTRY_TYPES.RELEASE_RESERVE,
        referenceId: reserveEntry.referenceId,
        description: `Partial release: captured ${captureAmount} of ${reservedAmount}`,
        metadata: { originalReserveTxId: params.reserveLedgerTxId },
      });
    }

    entries.push({
      ledgerTxId: captureTxId,
      walletAccountId: reserveEntry.walletAccountId,
      currency: reserveEntry.currency,
      amount: toFixed6(captureAmount),
      direction: "DEBIT",
      status: "POSTED",
      entryType: LEDGER_ENTRY_TYPES.CAPTURE,
      referenceId: reserveEntry.referenceId,
      description: params.description || `Capture from reserve ${params.reserveLedgerTxId}`,
      metadata: { originalReserveTxId: params.reserveLedgerTxId, ...params.metadata },
    });

    await storage.createLedgerEntries(entries);

    return {
      walletAccountId: reserveEntry.walletAccountId,
      captureLedgerTxId: captureTxId,
      currency: reserveEntry.currency,
      amount: toFixed6(captureAmount),
      referenceId: reserveEntry.referenceId || "",
    };
  }

  async fxConvert(params: {
    userId: string;
    fromCurrency: string;
    toCurrency: string;
    fromAmount: number;
    rate: number;
    referenceId?: string;
    metadata?: Record<string, any>;
  }): Promise<FxConvertResult> {
    if (params.fromAmount <= 0) throw new Error("Amount must be positive");
    if (params.rate <= 0) throw new Error("Rate must be positive");

    const toAmount = params.fromAmount * params.rate;
    const fromWallet = await storage.getOrCreateWallet(params.userId, params.fromCurrency);
    const toWallet = await storage.getOrCreateWallet(params.userId, params.toCurrency);

    const balance = await this.getBalanceForWallet(fromWallet.id);
    const availableForFx = parseFloat(balance.available);
    if (availableForFx < params.fromAmount) {
      throw new Error(
        `Insufficient ${params.fromCurrency} balance. Available: ${toFixed6(availableForFx)}, Needed: ${toFixed6(params.fromAmount)}`
      );
    }

    const ledgerTxId = generateLedgerTxId();
    await storage.createLedgerEntries([
      {
        ledgerTxId,
        walletAccountId: fromWallet.id,
        currency: params.fromCurrency,
        amount: toFixed6(params.fromAmount),
        direction: "DEBIT",
        status: "POSTED",
        entryType: LEDGER_ENTRY_TYPES.FX_CONVERT_DEBIT,
        referenceId: params.referenceId || null,
        description: `FX convert ${params.fromCurrency} -> ${params.toCurrency} @ ${params.rate}`,
        metadata: { rate: params.rate, toAmount, toCurrency: params.toCurrency, ...params.metadata },
      },
      {
        ledgerTxId,
        walletAccountId: toWallet.id,
        currency: params.toCurrency,
        amount: toFixed6(toAmount),
        direction: "CREDIT",
        status: "POSTED",
        entryType: LEDGER_ENTRY_TYPES.FX_CONVERT_CREDIT,
        referenceId: params.referenceId || null,
        description: `FX convert ${params.fromCurrency} -> ${params.toCurrency} @ ${params.rate}`,
        metadata: { rate: params.rate, fromAmount: params.fromAmount, fromCurrency: params.fromCurrency, ...params.metadata },
      },
    ]);

    return {
      debitWalletId: fromWallet.id,
      creditWalletId: toWallet.id,
      ledgerTxId,
      fromCurrency: params.fromCurrency,
      toCurrency: params.toCurrency,
      fromAmount: toFixed6(params.fromAmount),
      toAmount: toFixed6(toAmount),
      rate: params.rate.toString(),
    };
  }

  async distributionCredit(params: {
    userId: string;
    currency: string;
    amount: number;
    referenceId: string;
    description?: string;
    metadata?: Record<string, any>;
  }): Promise<{ walletAccountId: string; ledgerTxId: string }> {
    if (params.amount <= 0) throw new Error("Amount must be positive");

    const wallet = await storage.getOrCreateWallet(params.userId, params.currency);
    const ledgerTxId = generateLedgerTxId();

    await storage.createLedgerEntries([{
      ledgerTxId,
      walletAccountId: wallet.id,
      currency: params.currency,
      amount: toFixed6(params.amount),
      direction: "CREDIT",
      status: "POSTED",
      entryType: LEDGER_ENTRY_TYPES.DISTRIBUTION_CREDIT,
      referenceId: params.referenceId,
      description: params.description || "Distribution credit",
      metadata: params.metadata || null,
    }]);

    return { walletAccountId: wallet.id, ledgerTxId };
  }

  async requestWithdrawal(params: {
    userId: string;
    currency: string;
    amount: number;
    referenceId?: string;
    description?: string;
    metadata?: Record<string, any>;
  }): Promise<WithdrawalResult> {
    if (params.amount <= 0) throw new Error("Amount must be positive");

    const wallet = await storage.getOrCreateWallet(params.userId, params.currency);
    const balance = await this.getBalanceForWallet(wallet.id);
    const availableForWithdraw = parseFloat(balance.available);

    if (availableForWithdraw < params.amount) {
      throw new Error(
        `Insufficient balance for withdrawal. Available: ${toFixed6(availableForWithdraw)}, Requested: ${toFixed6(params.amount)}`
      );
    }

    const ledgerTxId = generateLedgerTxId();
    await storage.createLedgerEntries([{
      ledgerTxId,
      walletAccountId: wallet.id,
      currency: params.currency,
      amount: toFixed6(params.amount),
      direction: "DEBIT",
      status: "PENDING",
      entryType: LEDGER_ENTRY_TYPES.WITHDRAW_REQUESTED,
      referenceId: params.referenceId || null,
      description: params.description || "Withdrawal request hold",
      metadata: params.metadata || null,
    }]);

    return {
      walletAccountId: wallet.id,
      ledgerTxId,
      currency: params.currency,
      grossAmount: toFixed6(params.amount),
      fee: "0.000000",
      netAmount: toFixed6(params.amount),
    };
  }

  async approveWithdrawal(params: {
    originalLedgerTxId: string;
    fee?: number;
    metadata?: Record<string, any>;
  }): Promise<void> {
    const pendingEntries = await storage.getLedgerEntriesByTxId(params.originalLedgerTxId);
    const holdEntry = pendingEntries.find(
      (e) => e.entryType === LEDGER_ENTRY_TYPES.WITHDRAW_REQUESTED && e.status === "PENDING"
    );

    if (!holdEntry) {
      throw new Error(`No pending withdrawal hold for ledger tx: ${params.originalLedgerTxId}`);
    }

    await storage.reverseLedgerEntries(params.originalLedgerTxId, "Withdrawal approved - converting hold to posted");

    const approvalTxId = generateLedgerTxId();
    const entries: any[] = [{
      ledgerTxId: approvalTxId,
      walletAccountId: holdEntry.walletAccountId,
      currency: holdEntry.currency,
      amount: holdEntry.amount,
      direction: "DEBIT",
      status: "POSTED",
      entryType: LEDGER_ENTRY_TYPES.WITHDRAW_APPROVED,
      referenceId: holdEntry.referenceId,
      description: "Withdrawal approved",
      metadata: { originalLedgerTxId: params.originalLedgerTxId, ...params.metadata },
    }];

    if (params.fee && params.fee > 0) {
      entries.push({
        ledgerTxId: approvalTxId,
        walletAccountId: holdEntry.walletAccountId,
        currency: holdEntry.currency,
        amount: toFixed6(params.fee),
        direction: "DEBIT",
        status: "POSTED",
        entryType: LEDGER_ENTRY_TYPES.FEE,
        referenceId: holdEntry.referenceId,
        description: "Withdrawal fee",
        metadata: { originalLedgerTxId: params.originalLedgerTxId },
      });
    }

    await storage.createLedgerEntries(entries);
  }

  async rejectWithdrawal(params: {
    originalLedgerTxId: string;
    reason?: string;
  }): Promise<void> {
    const pendingEntries = await storage.getLedgerEntriesByTxId(params.originalLedgerTxId);
    const holdEntry = pendingEntries.find(
      (e) => e.entryType === LEDGER_ENTRY_TYPES.WITHDRAW_REQUESTED && e.status === "PENDING"
    );

    if (!holdEntry) {
      throw new Error(`No pending withdrawal hold for ledger tx: ${params.originalLedgerTxId}`);
    }

    await storage.reverseLedgerEntries(
      params.originalLedgerTxId,
      params.reason || "Withdrawal rejected"
    );
  }

  async markWithdrawalPaid(params: {
    originalLedgerTxId: string;
    payoutReference: string;
    metadata?: Record<string, any>;
  }): Promise<void> {
    const entries = await storage.getLedgerEntriesByTxId(params.originalLedgerTxId);
    const approvedEntry = entries.find(
      (e) => e.entryType === LEDGER_ENTRY_TYPES.WITHDRAW_APPROVED && e.status === "POSTED"
    );

    if (!approvedEntry) {
      const allUserEntries = await storage.getLedgerEntriesByAccount(
        entries[0]?.walletAccountId || ""
      );
      const anyApproved = allUserEntries.find(
        (e) =>
          e.entryType === LEDGER_ENTRY_TYPES.WITHDRAW_APPROVED &&
          e.status === "POSTED" &&
          e.referenceId === entries[0]?.referenceId
      );
      if (!anyApproved) {
        throw new Error("No approved withdrawal found");
      }
    }

    const paidTxId = generateLedgerTxId();
    const walletAccountId = approvedEntry?.walletAccountId || entries[0]?.walletAccountId;
    const currency = approvedEntry?.currency || entries[0]?.currency;

    await storage.createLedgerEntries([{
      ledgerTxId: paidTxId,
      walletAccountId,
      currency,
      amount: "0.000000",
      direction: "DEBIT",
      status: "POSTED",
      entryType: LEDGER_ENTRY_TYPES.WITHDRAW_PAID,
      referenceId: approvedEntry?.referenceId || entries[0]?.referenceId || null,
      description: `Withdrawal paid - ref: ${params.payoutReference}`,
      metadata: { payoutReference: params.payoutReference, originalLedgerTxId: params.originalLedgerTxId, ...params.metadata },
    }]);
  }

  async getLedgerHistory(params: {
    userId?: string;
    walletAccountId?: string;
    entryType?: string;
  }): Promise<any[]> {
    if (params.walletAccountId) {
      const entries = await storage.getLedgerEntriesByAccount(params.walletAccountId);
      if (params.entryType) {
        return entries.filter((e) => e.entryType === params.entryType);
      }
      return entries;
    }
    if (params.userId) {
      const entries = await storage.getLedgerEntriesByUser(params.userId);
      if (params.entryType) {
        return entries.filter((e) => e.entryType === params.entryType);
      }
      return entries;
    }
    throw new Error("Provide userId or walletAccountId");
  }

  async getWithdrawalAvailability(userId: string, currency: string): Promise<WithdrawalAvailability> {
    const now = new Date();
    const profitCutoff = new Date(now.getTime() - LIQUIDITY_RULES.profitLockDays * 24 * 60 * 60 * 1000);
    const capitalCutoff = new Date(now.getTime() - LIQUIDITY_RULES.capitalLockDays * 24 * 60 * 60 * 1000);

    const allEntries = await storage.getLedgerEntriesByUser(userId);
    const currencyEntries = allEntries.filter(e => e.currency === currency);

    const distributionCredits = currencyEntries.filter(
      e => e.entryType === LEDGER_ENTRY_TYPES.DISTRIBUTION_CREDIT && e.status === "POSTED" && e.direction === "CREDIT"
    );
    let totalProfit = 0;
    let unlockedProfit = 0;
    let lockedProfit = 0;
    const profitLockDetails: { amount: number; creditDate: string; unlockDate: string }[] = [];

    for (const entry of distributionCredits) {
      const amt = parseFloat(entry.amount);
      totalProfit += amt;
      const entryDate = new Date(entry.createdAt);
      if (entryDate <= profitCutoff) {
        unlockedProfit += amt;
      } else {
        lockedProfit += amt;
        const unlockDate = new Date(entryDate.getTime() + LIQUIDITY_RULES.profitLockDays * 24 * 60 * 60 * 1000);
        profitLockDetails.push({
          amount: amt,
          creditDate: entryDate.toISOString(),
          unlockDate: unlockDate.toISOString(),
        });
      }
    }

    const captureEntries = currencyEntries.filter(
      e => e.entryType === LEDGER_ENTRY_TYPES.CAPTURE && e.status === "POSTED" && e.direction === "DEBIT"
    );
    const redemptionEntries = currencyEntries.filter(
      e => e.entryType === LEDGER_ENTRY_TYPES.CAPITAL_REDEMPTION && e.status === "POSTED"
    );
    const totalRedemptions = redemptionEntries.reduce((sum, e) => sum + parseFloat(e.amount), 0);

    let totalCapital = 0;
    let unlockedCapital = 0;
    let lockedCapital = 0;
    const capitalLockDetails: { amount: number; capturedDate: string; unlockDate: string }[] = [];

    for (const entry of captureEntries) {
      const amt = parseFloat(entry.amount);
      totalCapital += amt;
      const entryDate = new Date(entry.createdAt);
      if (entryDate <= capitalCutoff) {
        unlockedCapital += amt;
      } else {
        lockedCapital += amt;
        const unlockDate = new Date(entryDate.getTime() + LIQUIDITY_RULES.capitalLockDays * 24 * 60 * 60 * 1000);
        capitalLockDetails.push({
          amount: amt,
          capturedDate: entryDate.toISOString(),
          unlockDate: unlockDate.toISOString(),
        });
      }
    }

    unlockedCapital = Math.max(0, unlockedCapital + totalRedemptions);

    const existingWithdrawals = await storage.getWithdrawalRequestsByUser(userId);
    const pendingProfitWithdrawals = existingWithdrawals
      .filter(w => w.reason === "PROFIT" && w.currency === currency && ["REQUESTED", "APPROVED"].includes(w.status))
      .reduce((sum, w) => sum + parseFloat(w.amount), 0);
    const pendingCapitalWithdrawals = existingWithdrawals
      .filter(w => w.reason === "CAPITAL" && w.currency === currency && ["REQUESTED", "APPROVED"].includes(w.status))
      .reduce((sum, w) => sum + parseFloat(w.amount), 0);

    const profitAvailable = Math.max(0, unlockedProfit - pendingProfitWithdrawals);
    const capitalAvailable = Math.max(0, unlockedCapital - pendingCapitalWithdrawals);

    const wallet = await storage.getOrCreateWallet(userId, currency);
    const balance = await this.getBalanceForWallet(wallet.id);
    const totalAvailable = parseFloat(balance.available);

    const effectiveProfitAvailable = Math.min(profitAvailable, totalAvailable);
    const effectiveCapitalAvailable = Math.min(capitalAvailable, Math.max(0, totalAvailable - effectiveProfitAvailable));

    let nextProfitUnlock: string | null = null;
    if (profitLockDetails.length > 0) {
      profitLockDetails.sort((a, b) => new Date(a.unlockDate).getTime() - new Date(b.unlockDate).getTime());
      nextProfitUnlock = profitLockDetails[0].unlockDate;
    }
    let nextCapitalUnlock: string | null = null;
    if (capitalLockDetails.length > 0) {
      capitalLockDetails.sort((a, b) => new Date(a.unlockDate).getTime() - new Date(b.unlockDate).getTime());
      nextCapitalUnlock = capitalLockDetails[0].unlockDate;
    }

    return {
      currency,
      walletBalance: toFixed6(totalAvailable),
      profit: {
        total: toFixed6(totalProfit),
        unlocked: toFixed6(unlockedProfit),
        locked: toFixed6(lockedProfit),
        pendingWithdrawals: toFixed6(pendingProfitWithdrawals),
        available: toFixed6(effectiveProfitAvailable),
        lockDays: LIQUIDITY_RULES.profitLockDays,
        nextUnlockDate: nextProfitUnlock,
        lockDetails: profitLockDetails,
      },
      capital: {
        total: toFixed6(totalCapital),
        unlocked: toFixed6(unlockedCapital),
        locked: toFixed6(lockedCapital),
        pendingWithdrawals: toFixed6(pendingCapitalWithdrawals),
        available: toFixed6(effectiveCapitalAvailable),
        lockDays: LIQUIDITY_RULES.capitalLockDays,
        nextUnlockDate: nextCapitalUnlock,
        lockDetails: capitalLockDetails,
      },
      rules: {
        profitLockDays: LIQUIDITY_RULES.profitLockDays,
        capitalLockDays: LIQUIDITY_RULES.capitalLockDays,
      },
    };
  }

  async executeCapitalRedemption(params: {
    userId: string;
    currency: string;
    amount: number;
    executedBy: string;
    referenceId?: string;
    description?: string;
  }): Promise<{ ledgerTxId: string }> {
    if (params.amount <= 0) throw new Error("Amount must be positive");

    const wallet = await storage.getOrCreateWallet(params.userId, params.currency);
    const ledgerTxId = generateLedgerTxId();

    await storage.createLedgerEntries([{
      ledgerTxId,
      walletAccountId: wallet.id,
      currency: params.currency,
      amount: toFixed6(params.amount),
      direction: "CREDIT",
      status: "POSTED",
      entryType: LEDGER_ENTRY_TYPES.CAPITAL_REDEMPTION,
      referenceId: params.referenceId || null,
      description: params.description || `Capital redemption by admin`,
      metadata: { executedBy: params.executedBy },
    }]);

    return { ledgerTxId };
  }
}

export interface WithdrawalAvailability {
  currency: string;
  walletBalance: string;
  profit: {
    total: string;
    unlocked: string;
    locked: string;
    pendingWithdrawals: string;
    available: string;
    lockDays: number;
    nextUnlockDate: string | null;
    lockDetails: { amount: number; creditDate: string; unlockDate: string }[];
  };
  capital: {
    total: string;
    unlocked: string;
    locked: string;
    pendingWithdrawals: string;
    available: string;
    lockDays: number;
    nextUnlockDate: string | null;
    lockDetails: { amount: number; capturedDate: string; unlockDate: string }[];
  };
  rules: {
    profitLockDays: number;
    capitalLockDays: number;
  };
}

export const walletService = new WalletService();
