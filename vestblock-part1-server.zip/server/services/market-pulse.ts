import { db } from "../db";
import { sql } from "drizzle-orm";

export interface CityYield {
  city: string;
  avgYield: number;
  listingCount: number;
  prevAvgYield: number | null;
  changePercent: number | null;
}

export interface ListingPerformance {
  newListingsCount: number;
  avgFundingPercent: number;
  topViewed: Array<{ name: string; city: string; fundingPercent: number }>;
}

export interface ExitWindowStats {
  unitsListed: number;
  unitsSold: number;
  avgDaysToSell: number | null;
  avgPremiumPercent: number | null;
}

export interface MarketPulseMetrics {
  weekStart: string;
  weekEnd: string;
  region: string;
  rentalYieldsByCity: CityYield[];
  listingPerformance: ListingPerformance;
  exitWindowStats: ExitWindowStats;
  fundingVelocity: Array<{ date: string; avgFundingPercent: number }>;
}

function getWeekRange(date: Date = new Date()): { weekStart: string; weekEnd: string; prevWeekStart: string; prevWeekEnd: string } {
  const d = new Date(date);
  const dayOfWeek = d.getDay();
  const weekEnd = new Date(d);
  weekEnd.setDate(d.getDate() - dayOfWeek);
  weekEnd.setHours(23, 59, 59, 999);

  const weekStart = new Date(weekEnd);
  weekStart.setDate(weekEnd.getDate() - 6);
  weekStart.setHours(0, 0, 0, 0);

  const prevWeekEnd = new Date(weekStart);
  prevWeekEnd.setDate(weekStart.getDate() - 1);
  prevWeekEnd.setHours(23, 59, 59, 999);

  const prevWeekStart = new Date(prevWeekEnd);
  prevWeekStart.setDate(prevWeekEnd.getDate() - 6);
  prevWeekStart.setHours(0, 0, 0, 0);

  return {
    weekStart: weekStart.toISOString().split("T")[0],
    weekEnd: weekEnd.toISOString().split("T")[0],
    prevWeekStart: prevWeekStart.toISOString().split("T")[0],
    prevWeekEnd: prevWeekEnd.toISOString().split("T")[0],
  };
}

export async function computeMarketPulseMetrics(region: string = "PK"): Promise<MarketPulseMetrics> {
  const { weekStart, weekEnd, prevWeekStart, prevWeekEnd } = getWeekRange();

  const yieldsByCity = await computeRentalYields(region, weekStart, weekEnd, prevWeekStart, prevWeekEnd);
  const listingPerf = await computeListingPerformance(region, weekStart, weekEnd);
  const exitStats = await computeExitWindowStats(region, weekStart, weekEnd);
  const fundingVelocity = await computeFundingVelocity(region);

  return {
    weekStart,
    weekEnd,
    region,
    rentalYieldsByCity: yieldsByCity,
    listingPerformance: listingPerf,
    exitWindowStats: exitStats,
    fundingVelocity,
  };
}

async function computeRentalYields(
  region: string, weekStart: string, weekEnd: string,
  prevWeekStart: string, prevWeekEnd: string
): Promise<CityYield[]> {
  try {
    const currentYields = await db.execute(sql`
      SELECT city, 
             AVG(CAST(expected_yield AS NUMERIC)) as avg_yield,
             COUNT(*) as listing_count
      FROM cms_property_listings 
      WHERE region = ${region} 
        AND status IN ('LIVE', 'PUBLISHED', 'active')
        AND expected_yield IS NOT NULL
      GROUP BY city
      ORDER BY avg_yield DESC
    `);

    const prevYields = await db.execute(sql`
      SELECT city, 
             AVG(CAST(expected_yield AS NUMERIC)) as avg_yield
      FROM cms_property_listings 
      WHERE region = ${region} 
        AND status IN ('LIVE', 'PUBLISHED', 'active')
        AND expected_yield IS NOT NULL
        AND created_at <= ${prevWeekEnd}
      GROUP BY city
    `);

    const prevMap = new Map<string, number>();
    for (const row of (prevYields.rows || [])) {
      prevMap.set(String(row.city), Number(row.avg_yield));
    }

    return (currentYields.rows || []).map((row: any) => {
      const avgYield = Number(row.avg_yield);
      const prevAvg = prevMap.get(String(row.city)) ?? null;
      return {
        city: String(row.city),
        avgYield: Math.round(avgYield * 100) / 100,
        listingCount: Number(row.listing_count),
        prevAvgYield: prevAvg !== null ? Math.round(prevAvg * 100) / 100 : null,
        changePercent: prevAvg !== null && prevAvg !== 0
          ? Math.round(((avgYield - prevAvg) / prevAvg) * 10000) / 100
          : null,
      };
    });
  } catch (err) {
    console.error("[MarketPulse] Error computing rental yields:", err);
    return [];
  }
}

async function computeListingPerformance(region: string, weekStart: string, weekEnd: string): Promise<ListingPerformance> {
  try {
    const newListingsResult = await db.execute(sql`
      SELECT COUNT(*) as count
      FROM cms_property_listings 
      WHERE region = ${region}
        AND created_at >= ${weekStart}
    `);

    const avgFundingResult = await db.execute(sql`
      SELECT AVG(funding_progress_percent) as avg_funding
      FROM cms_property_listings 
      WHERE region = ${region}
        AND status IN ('LIVE', 'PUBLISHED', 'active')
    `);

    const topViewedResult = await db.execute(sql`
      SELECT name, city, funding_progress_percent
      FROM cms_property_listings 
      WHERE region = ${region}
        AND status IN ('LIVE', 'PUBLISHED', 'active')
      ORDER BY funding_progress_percent DESC
      LIMIT 3
    `);

    return {
      newListingsCount: Number((newListingsResult.rows || [])[0]?.count || 0),
      avgFundingPercent: Math.round(Number((avgFundingResult.rows || [])[0]?.avg_funding || 0) * 100) / 100,
      topViewed: (topViewedResult.rows || []).map((r: any) => ({
        name: String(r.name),
        city: String(r.city),
        fundingPercent: Number(r.funding_progress_percent),
      })),
    };
  } catch (err) {
    console.error("[MarketPulse] Error computing listing performance:", err);
    return { newListingsCount: 0, avgFundingPercent: 0, topViewed: [] };
  }
}

async function computeExitWindowStats(region: string, weekStart: string, weekEnd: string): Promise<ExitWindowStats> {
  try {
    const listedResult = await db.execute(sql`
      SELECT COUNT(*) as count
      FROM trade_listings tl
      JOIN assets a ON tl.asset_id = a.id
      WHERE a.country = ${region}
        AND tl.status IN ('active', 'filled')
    `);

    const soldResult = await db.execute(sql`
      SELECT COUNT(*) as count,
             AVG(EXTRACT(EPOCH FROM (tl.filled_at::timestamp - tl.created_at::timestamp)) / 86400) as avg_days
      FROM trade_listings tl
      JOIN assets a ON tl.asset_id = a.id
      WHERE a.country = ${region}
        AND tl.status = 'filled'
    `);

    return {
      unitsListed: Number((listedResult.rows || [])[0]?.count || 0),
      unitsSold: Number((soldResult.rows || [])[0]?.count || 0),
      avgDaysToSell: (soldResult.rows || [])[0]?.avg_days ? Math.round(Number((soldResult.rows || [])[0].avg_days) * 10) / 10 : null,
      avgPremiumPercent: null,
    };
  } catch (err) {
    console.error("[MarketPulse] Error computing exit window stats:", err);
    return { unitsListed: 0, unitsSold: 0, avgDaysToSell: null, avgPremiumPercent: null };
  }
}

async function computeFundingVelocity(region: string): Promise<Array<{ date: string; avgFundingPercent: number }>> {
  try {
    const result = await db.execute(sql`
      SELECT DATE(created_at) as date_bucket,
             AVG(funding_progress_percent) as avg_funding
      FROM cms_property_listings 
      WHERE region = ${region}
        AND status IN ('LIVE', 'PUBLISHED', 'active')
        AND created_at >= (NOW() - INTERVAL '30 days')
      GROUP BY DATE(created_at)
      ORDER BY date_bucket ASC
    `);

    return (result.rows || []).map((r: any) => ({
      date: String(r.date_bucket).split("T")[0],
      avgFundingPercent: Math.round(Number(r.avg_funding) * 100) / 100,
    }));
  } catch (err) {
    console.error("[MarketPulse] Error computing funding velocity:", err);
    return [];
  }
}

export function buildMarketPulsePrompt(metrics: MarketPulseMetrics): string {
  const yieldSection = metrics.rentalYieldsByCity.length > 0
    ? metrics.rentalYieldsByCity.map(c =>
      `  ${c.city}: ${c.avgYield}% avg yield (${c.listingCount} listings)${c.changePercent !== null ? ` [${c.changePercent > 0 ? "+" : ""}${c.changePercent}% WoW]` : ""}`
    ).join("\n")
    : "  No active listings with yield data found.";

  const topProperties = metrics.listingPerformance.topViewed.length > 0
    ? metrics.listingPerformance.topViewed.map((p, i) =>
      `  ${i + 1}. ${p.name} (${p.city}) — ${p.fundingPercent}% funded`
    ).join("\n")
    : "  No property data available.";

  return `You are a market analyst for VestBlock, a fractional real estate investment platform in Pakistan. Write a weekly market digest based on these DETERMINISTIC metrics for the week of ${metrics.weekStart} to ${metrics.weekEnd}.

RENTAL YIELD TRENDS BY CITY:
${yieldSection}

LISTING PERFORMANCE:
  New listings this week: ${metrics.listingPerformance.newListingsCount}
  Average funding progress: ${metrics.listingPerformance.avgFundingPercent}%
  Top Properties by Funding:
${topProperties}

EXIT WINDOW LIQUIDITY:
  Units listed for trade: ${metrics.exitWindowStats.unitsListed}
  Units sold: ${metrics.exitWindowStats.unitsSold}
  ${metrics.exitWindowStats.avgDaysToSell !== null ? `Average days to sell: ${metrics.exitWindowStats.avgDaysToSell}` : "Avg days to sell: N/A"}

Respond in valid JSON with this structure:
{
  "narrativeMd": "A 200-400 word markdown narrative (use ## headings, bullet points). Cover: yield trends, listing activity, and liquidity. Be factual, reference actual numbers. Use 'estimated', 'projected' language.",
  "highlights": [
    "Short bullet highlight 1 (one sentence)",
    "Short bullet highlight 2",
    "Short bullet highlight 3",
    "Short bullet highlight 4",
    "Short bullet highlight 5"
  ]
}

RULES:
- Reference ONLY the provided metrics. Do not invent data.
- Use compliance-safe language: "estimated", "projected", not "guaranteed".
- Keep tone professional but accessible.
- Include practical investor takeaways.
- Do NOT provide financial advice.`;
}
