import { storage } from "../storage";
import type { User, Token, Asset, ExitWindow, TokenHolding, SpvEntity } from "@shared/schema";

export interface TransferRestrictionResult {
  allowed: boolean;
  violations: string[];
}

interface TransferContext {
  sender: User;
  recipient: User;
  token: Token;
  asset: Asset | null;
  spv: SpvEntity | null;
  amount: number;
  senderHolding: TokenHolding | undefined;
  recipientHolding: TokenHolding | undefined;
  exitWindows: ExitWindow[];
}

const JURISDICTION_RESTRICTIONS: Record<string, { allowedCountries: string[]; blockedCountries: string[] }> = {
  AE: { allowedCountries: [], blockedCountries: ["US"] },
  PK: { allowedCountries: [], blockedCountries: ["US"] },
  GB: { allowedCountries: [], blockedCountries: [] },
  US: { allowedCountries: ["US"], blockedCountries: [] },
  QA: { allowedCountries: [], blockedCountries: ["US"] },
};

function checkKycApproved(ctx: TransferContext): string[] {
  const violations: string[] = [];
  const approvedStatuses = ["approved", "APPROVED"];

  if (!approvedStatuses.includes(ctx.sender.kycStatus)) {
    violations.push(`Sender KYC not approved (status: ${ctx.sender.kycStatus})`);
  }
  if (!approvedStatuses.includes(ctx.recipient.kycStatus)) {
    violations.push(`Recipient KYC not approved (status: ${ctx.recipient.kycStatus})`);
  }
  return violations;
}

function checkEddNotRequired(ctx: TransferContext): string[] {
  const violations: string[] = [];
  if (ctx.sender.eddStatus === "EDD_REQUIRED") {
    violations.push("Sender has pending Enhanced Due Diligence (EDD) requirement");
  }
  if (ctx.recipient.eddStatus === "EDD_REQUIRED") {
    violations.push("Recipient has pending Enhanced Due Diligence (EDD) requirement");
  }
  return violations;
}

function checkCountryRestrictions(ctx: TransferContext): string[] {
  const violations: string[] = [];
  if (!ctx.spv) return violations;

  const jurisdiction = ctx.spv.jurisdiction;
  const rules = JURISDICTION_RESTRICTIONS[jurisdiction];

  if (!rules) {
    return violations;
  }

  const senderCountry = ctx.sender.nationality || "";
  const recipientCountry = ctx.recipient.nationality || "";

  if (rules.allowedCountries.length > 0) {
    if (senderCountry && !rules.allowedCountries.includes(senderCountry)) {
      violations.push(`Sender country (${senderCountry}) not allowed for ${jurisdiction}-jurisdiction tokens`);
    }
    if (recipientCountry && !rules.allowedCountries.includes(recipientCountry)) {
      violations.push(`Recipient country (${recipientCountry}) not allowed for ${jurisdiction}-jurisdiction tokens`);
    }
  }

  if (rules.blockedCountries.length > 0) {
    if (senderCountry && rules.blockedCountries.includes(senderCountry)) {
      violations.push(`Sender country (${senderCountry}) is restricted for ${jurisdiction}-jurisdiction tokens`);
    }
    if (recipientCountry && rules.blockedCountries.includes(recipientCountry)) {
      violations.push(`Recipient country (${recipientCountry}) is restricted for ${jurisdiction}-jurisdiction tokens`);
    }
  }

  return violations;
}

function checkHoldingLimits(ctx: TransferContext): string[] {
  const violations: string[] = [];

  const senderCurrentBalance = parseFloat(ctx.senderHolding?.balance || "0");
  if (senderCurrentBalance < ctx.amount) {
    violations.push(
      `Sender balance (${senderCurrentBalance.toFixed(6)}) insufficient for transfer of ${ctx.amount.toFixed(6)} tokens`
    );
  }

  if (!ctx.asset) return violations;

  const pricePerToken = parseFloat(ctx.asset.pricePerToken);
  if (!pricePerToken || pricePerToken <= 0) return violations;

  if (ctx.asset.minInvestment) {
    const minTokens = parseFloat(ctx.asset.minInvestment) / pricePerToken;
    const recipientCurrentBalance = parseFloat(ctx.recipientHolding?.balance || "0");
    const recipientNewBalance = recipientCurrentBalance + ctx.amount;

    if (recipientNewBalance < minTokens && recipientNewBalance > 0) {
      violations.push(
        `Recipient holding (${recipientNewBalance.toFixed(2)} tokens) would be below minimum investment of ${ctx.asset.minInvestment} ${ctx.asset.baseCurrency} (${minTokens.toFixed(2)} tokens)`
      );
    }
  }

  if (ctx.asset.maxInvestment) {
    const maxTokens = parseFloat(ctx.asset.maxInvestment) / pricePerToken;
    const recipientCurrentBalance = parseFloat(ctx.recipientHolding?.balance || "0");
    const recipientNewBalance = recipientCurrentBalance + ctx.amount;

    if (recipientNewBalance > maxTokens) {
      violations.push(
        `Recipient holding (${recipientNewBalance.toFixed(2)} tokens) would exceed maximum investment of ${ctx.asset.maxInvestment} ${ctx.asset.baseCurrency} (${maxTokens.toFixed(2)} tokens)`
      );
    }
  }

  return violations;
}

function checkMaxOwnershipPercent(ctx: TransferContext): string[] {
  const violations: string[] = [];
  if (!ctx.asset) return violations;

  const maxPct = ctx.asset.maxOwnershipPercent ? parseFloat(ctx.asset.maxOwnershipPercent) : null;
  if (!maxPct || maxPct <= 0 || maxPct > 100) return violations;

  const totalSupply = parseFloat(ctx.asset.totalSupply);
  if (totalSupply <= 0) return violations;

  const recipientCurrentBalance = parseFloat(ctx.recipientHolding?.balance || "0");
  const recipientNewBalance = recipientCurrentBalance + ctx.amount;
  const newOwnershipPct = (recipientNewBalance / totalSupply) * 100;

  if (newOwnershipPct > maxPct) {
    const maxTokens = (maxPct / 100) * totalSupply;
    const remainingCapacity = Math.max(0, maxTokens - recipientCurrentBalance);
    violations.push(
      `Recipient would hold ${newOwnershipPct.toFixed(2)}% of total supply, exceeding the ${maxPct}% maximum ownership limit. Current holding: ${recipientCurrentBalance.toFixed(2)} tokens. Maximum allowed: ${maxTokens.toFixed(2)} tokens (${remainingCapacity.toFixed(2)} more permitted).`
    );
  }

  return violations;
}

function checkLockupPeriod(ctx: TransferContext): string[] {
  const violations: string[] = [];
  if (!ctx.senderHolding) return violations;

  const lockupUntil = (ctx.senderHolding as any).lockupUntil;
  if (!lockupUntil) return violations;

  const lockupDate = new Date(lockupUntil);
  const now = new Date();
  if (now < lockupDate) {
    violations.push(
      `Sender tokens are locked until ${lockupDate.toISOString().split("T")[0]}. Transfers are not permitted during the lockup period.`
    );
  }
  return violations;
}

function checkExitWindowGating(ctx: TransferContext): string[] {
  const violations: string[] = [];
  if (!ctx.asset) return violations;

  const now = new Date();

  const tokenRestrictions = ctx.token.transferRestrictions as any;
  const requiresExitWindow = tokenRestrictions?.requireExitWindow !== false;

  if (!requiresExitWindow) {
    return violations;
  }

  const activeWindows = ctx.exitWindows.filter((ew) => {
    const opensAt = new Date(ew.opensAt);
    const closesAt = new Date(ew.closesAt);
    return ew.status === "open" && now >= opensAt && now <= closesAt;
  });

  if (activeWindows.length === 0) {
    violations.push(
      "No active exit window for this asset. Secondary transfers are only permitted during scheduled exit windows."
    );
  }

  return violations;
}

export async function canTransfer(
  senderId: string,
  recipientId: string,
  tokenId: string,
  amount: number
): Promise<TransferRestrictionResult> {
  const violations: string[] = [];

  if (amount <= 0) {
    return { allowed: false, violations: ["Transfer amount must be greater than zero"] };
  }

  const sender = await storage.getUser(senderId);
  if (!sender) return { allowed: false, violations: ["Sender not found"] };

  const recipient = await storage.getUser(recipientId);
  if (!recipient) return { allowed: false, violations: ["Recipient not found"] };

  const token = await storage.getToken(tokenId);
  if (!token) return { allowed: false, violations: ["Token not found"] };

  if (token.frozen) {
    return { allowed: false, violations: ["Token is frozen for compliance — all transfers are suspended"] };
  }

  const shareClass = token.shareClassId ? await storage.getShareClass(token.shareClassId) : null;
  const spv = shareClass ? await storage.getSpvEntity(shareClass.spvId) : null;
  const asset = spv ? await storage.getAsset(spv.assetId) : null;

  const exitWindows = asset ? await storage.getExitWindowsByAsset(asset.id) : [];

  const [senderHolding, recipientHolding] = await Promise.all([
    storage.getTokenHolding(senderId, tokenId),
    storage.getTokenHolding(recipientId, tokenId),
  ]);

  const ctx: TransferContext = {
    sender,
    recipient,
    token,
    asset,
    spv,
    amount,
    senderHolding,
    recipientHolding,
    exitWindows,
  };

  violations.push(...checkKycApproved(ctx));
  violations.push(...checkEddNotRequired(ctx));
  violations.push(...checkCountryRestrictions(ctx));
  violations.push(...checkLockupPeriod(ctx));
  violations.push(...checkHoldingLimits(ctx));
  violations.push(...checkMaxOwnershipPercent(ctx));
  violations.push(...checkExitWindowGating(ctx));

  return {
    allowed: violations.length === 0,
    violations,
  };
}
