declare module "pdfkit" {
  class PDFDocument {
    constructor(options?: any);
    page: { width: number; height: number };
    on(event: string, callback: (...args: any[]) => void): this;
    rect(x: number, y: number, w: number, h: number): this;
    lineWidth(w: number): this;
    stroke(color?: string): this;
    fill(color?: string): this;
    fontSize(size: number): this;
    fillColor(color: string): this;
    font(name: string): this;
    text(text: string, x?: number, y?: number, options?: any): this;
    moveTo(x: number, y: number): this;
    lineTo(x: number, y: number): this;
    end(): void;
  }
  export = PDFDocument;
}

import PDFDocument from "pdfkit";
import crypto from "crypto";
import { storage } from "../storage";
import { TOKEN_LEGAL_DISCLAIMERS } from "@shared/token-legal";

export interface CertificateData {
  investorName: string;
  tokenSymbol: string;
  balance: string;
  snapshotDate: string;
  verificationHash: string;
  certificateId: string;
  propertyTitle?: string | null;
  propertyLocation?: string | null;
  spvName?: string | null;
  spvJurisdiction?: string | null;
  ownershipPercentage?: string | null;
  totalTokenSupply?: string | null;
  propertyValue?: string | null;
  currency?: string | null;
}

export function generateVerificationHash(data: {
  userId: string;
  tokenId: string;
  balance: string;
  snapshotDate: string;
}): string {
  const payload = `${data.userId}|${data.tokenId}|${data.balance}|${data.snapshotDate}`;
  return crypto.createHash("sha256").update(payload).digest("hex");
}

function formatCurrency(value: string | null | undefined, cur: string | null | undefined): string {
  if (!value) return "N/A";
  const num = parseFloat(value);
  if (isNaN(num)) return "N/A";
  const symbol = cur === "PKR" ? "PKR " : cur === "AED" ? "AED " : cur === "GBP" ? "GBP " : cur === "USD" ? "USD " : cur === "QAR" ? "QAR " : (cur || "") + " ";
  return symbol + num.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function generateCertificatePdf(data: CertificateData): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({
      size: "A4",
      layout: "landscape",
      margins: { top: 40, bottom: 40, left: 60, right: 60 },
    });

    const chunks: Buffer[] = [];
    doc.on("data", (chunk: Buffer) => chunks.push(chunk));
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);

    const pageW = doc.page.width;
    const pageH = doc.page.height;
    const cx = pageW / 2;

    doc.rect(20, 20, pageW - 40, pageH - 40).lineWidth(2).stroke("#0d9488");
    doc.rect(26, 26, pageW - 52, pageH - 52).lineWidth(0.5).stroke("#99f6e4");

    doc.fontSize(14).fillColor("#0d9488").font("Helvetica-Bold");
    doc.text("VESTBLOCK", 60, 40, { align: "left" });
    doc.fontSize(8).fillColor("#6b7280").font("Helvetica");
    doc.text("Tokenized Investment Platform", 60, 57, { align: "left" });

    doc.fontSize(8).fillColor("#6b7280").font("Helvetica");
    doc.text(`Certificate ID: ${data.certificateId}`, pageW - 300, 40, { width: 240, align: "right" });
    doc.text(`Date: ${data.snapshotDate}`, pageW - 300, 52, { width: 240, align: "right" });

    doc.moveTo(60, 72).lineTo(pageW - 60, 72).lineWidth(0.5).stroke("#d1d5db");

    doc.fontSize(22).fillColor("#111827").font("Helvetica-Bold");
    doc.text("Beneficial Ownership Certificate", 0, 82, { width: pageW, align: "center" });

    doc.fontSize(9).fillColor("#6b7280").font("Helvetica");
    doc.text("This document certifies beneficial ownership units in the property vehicle described below, as recorded on the VestBlock platform ledger", 80, 110, { width: pageW - 160, align: "center" });

    const sectionY = 140;
    const colLeft = 60;
    const colRight = cx + 20;
    const labelW = 140;
    const valueW = 200;
    const rowH = 22;

    doc.fontSize(11).fillColor("#0d9488").font("Helvetica-Bold");
    doc.text("INVESTOR DETAILS", colLeft, sectionY);
    doc.moveTo(colLeft, sectionY + 16).lineTo(colLeft + 300, sectionY + 16).lineWidth(0.3).stroke("#99f6e4");

    const investorFields = [
      { label: "Investor Name", value: data.investorName },
      { label: "Unit Symbol", value: data.tokenSymbol },
      { label: "Units Held", value: data.balance + " units" },
      { label: "Ownership Share", value: data.ownershipPercentage ? parseFloat(data.ownershipPercentage).toFixed(4) + "%" : "N/A" },
    ];

    investorFields.forEach((field, i) => {
      const y = sectionY + 24 + i * rowH;
      doc.fontSize(9).fillColor("#6b7280").font("Helvetica-Bold");
      doc.text(field.label, colLeft, y, { width: labelW });
      doc.fontSize(9).fillColor("#111827").font("Helvetica");
      doc.text(field.value, colLeft + labelW, y, { width: valueW });
    });

    doc.fontSize(11).fillColor("#0d9488").font("Helvetica-Bold");
    doc.text("PROPERTY DETAILS", colRight, sectionY);
    doc.moveTo(colRight, sectionY + 16).lineTo(colRight + 300, sectionY + 16).lineWidth(0.3).stroke("#99f6e4");

    const propertyFields = [
      { label: "Property Title", value: data.propertyTitle || "N/A" },
      { label: "Location", value: data.propertyLocation || "N/A" },
      { label: "Property Value", value: formatCurrency(data.propertyValue, data.currency) },
      { label: "Total Unit Supply", value: data.totalTokenSupply ? parseFloat(data.totalTokenSupply).toFixed(2) + " units" : "N/A" },
    ];

    propertyFields.forEach((field, i) => {
      const y = sectionY + 24 + i * rowH;
      doc.fontSize(9).fillColor("#6b7280").font("Helvetica-Bold");
      doc.text(field.label, colRight, y, { width: labelW });
      doc.fontSize(9).fillColor("#111827").font("Helvetica");
      doc.text(field.value, colRight + labelW, y, { width: valueW });
    });

    const spvY = sectionY + 24 + 4 * rowH + 16;
    doc.fontSize(11).fillColor("#0d9488").font("Helvetica-Bold");
    doc.text("SPV / LEGAL ENTITY", colLeft, spvY);
    doc.moveTo(colLeft, spvY + 16).lineTo(pageW - 60, spvY + 16).lineWidth(0.3).stroke("#99f6e4");

    const spvFields = [
      { label: "SPV Name", value: data.spvName || "N/A" },
      { label: "Jurisdiction", value: data.spvJurisdiction || "N/A" },
    ];

    spvFields.forEach((field, i) => {
      const y = spvY + 24 + i * rowH;
      doc.fontSize(9).fillColor("#6b7280").font("Helvetica-Bold");
      doc.text(field.label, colLeft, y, { width: labelW });
      doc.fontSize(9).fillColor("#111827").font("Helvetica");
      doc.text(field.value, colLeft + labelW, y, { width: valueW });
    });

    const verifyY = spvY + 24 + 2 * rowH + 16;
    doc.fontSize(11).fillColor("#0d9488").font("Helvetica-Bold");
    doc.text("VERIFICATION", colLeft, verifyY);
    doc.moveTo(colLeft, verifyY + 16).lineTo(pageW - 60, verifyY + 16).lineWidth(0.3).stroke("#99f6e4");

    doc.fontSize(8).fillColor("#6b7280").font("Helvetica-Bold");
    doc.text("Verification Hash", colLeft, verifyY + 24, { width: labelW });
    doc.fontSize(7).fillColor("#374151").font("Helvetica");
    doc.text(data.verificationHash, colLeft + labelW, verifyY + 24, { width: pageW - colLeft - labelW - 80 });

    const disclaimerY = verifyY + 56;
    doc.moveTo(60, disclaimerY).lineTo(pageW - 60, disclaimerY).lineWidth(0.5).stroke("#d1d5db");

    doc.fontSize(7).fillColor("#9ca3af").font("Helvetica");
    doc.text(
      TOKEN_LEGAL_DISCLAIMERS.certificateDisclaimer + " " +
      "The verification hash can be used to independently verify the authenticity of this document. " +
      "This certificate is issued as a private placement document and does not constitute a public offering of securities.",
      80,
      disclaimerY + 10,
      { width: pageW - 160, align: "center" }
    );

    const footerY = pageH - 55;
    doc.fontSize(7).fillColor("#9ca3af").font("Helvetica");
    doc.text(`Generated on ${new Date().toISOString().split("T")[0]} by VestBlock Platform`, 0, footerY, { width: pageW, align: "center" });

    doc.end();
  });
}

export async function createCertificateForHolding(userId: string, tokenId: string) {
  const user = await storage.getUser(userId);
  if (!user) throw new Error("User not found");

  const token = await storage.getToken(tokenId);
  if (!token) throw new Error("Token not found");

  const holding = await storage.getTokenHolding(userId, tokenId);
  if (!holding || parseFloat(holding.balance) <= 0) {
    throw new Error("No token balance to certify");
  }

  let propertyTitle: string | null = null;
  let propertyLocation: string | null = null;
  let spvName: string | null = null;
  let spvJurisdiction: string | null = null;
  let propertyValue: string | null = null;
  let currency: string | null = null;

  if (token.shareClassId) {
    const sc = await storage.getShareClass(token.shareClassId);
    if (sc?.spvId) {
      const spv = await storage.getSpvEntity(sc.spvId);
      if (spv) {
        spvName = spv.legalName;
        spvJurisdiction = spv.jurisdiction;
        if (spv.assetId) {
          const asset = await storage.getAsset(spv.assetId);
          if (asset) {
            propertyTitle = asset.name;
            propertyLocation = asset.location || asset.country;
            propertyValue = asset.totalPropertyValue || null;
            currency = asset.baseCurrency;
          }
        }
      }
    }
  }

  if (!propertyTitle && token.vehicleId) {
    const spv = await storage.getSpvEntity(token.vehicleId);
    if (spv) {
      spvName = spvName || spv.legalName;
      spvJurisdiction = spvJurisdiction || spv.jurisdiction;
      if (spv.assetId) {
        const asset = await storage.getAsset(spv.assetId);
        if (asset) {
          propertyTitle = asset.name;
          propertyLocation = asset.location || asset.country;
          propertyValue = asset.totalPropertyValue || null;
          currency = asset.baseCurrency;
        }
      }
    }
  }

  const totalSupply = token.totalSupply || "0";
  const ownershipPct = parseFloat(totalSupply) > 0
    ? ((parseFloat(holding.balance) / parseFloat(totalSupply)) * 100).toFixed(4)
    : "0";

  const snapshotDate = new Date().toISOString().split("T")[0];
  const verificationHash = generateVerificationHash({
    userId,
    tokenId,
    balance: holding.balance,
    snapshotDate,
  });

  const cert = await storage.createTokenCertificate({
    userId,
    tokenId,
    tokenSymbol: token.tokenSymbol,
    investorName: user.fullName,
    balance: holding.balance,
    snapshotDate,
    verificationHash,
    propertyTitle,
    propertyLocation,
    spvName,
    spvJurisdiction,
    ownershipPercentage: ownershipPct,
    totalTokenSupply: totalSupply,
    propertyValue,
    currency,
  });

  return cert;
}
