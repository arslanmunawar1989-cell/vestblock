import type { CreatePreferenceProfile, InvestorGoal, LiquidityNeed } from "@shared/schema";

export interface PropertyData {
  id: string;
  name: string;
  city: string;
  type: string;
  strategy: string;
  status: string;
  minInvestment: number;
  totalRaised: number;
  targetRaise: number;
  tokenPrice: number;
  totalTokens: number;
  soldTokens: number;
  annualYield: number;
  appreciation: number;
  image: string;
  listingDate: string;
  location: string;
}

export interface MatchReason {
  factor: string;
  score: number;
  maxScore: number;
  detail: string;
}

export interface PropertyMatch {
  property: PropertyData;
  totalScore: number;
  maxPossibleScore: number;
  percentMatch: number;
  reasons: MatchReason[];
}

const WEIGHTS = {
  CITY: 25,
  BUDGET: 20,
  GOAL: 25,
  LIQUIDITY: 15,
  RISK: 15,
};

function scoreCityMatch(property: PropertyData, cities: string[]): MatchReason {
  const normalizedCities = cities.map(c => c.toLowerCase().trim());
  const propCity = property.city.toLowerCase().trim();
  const isMatch = normalizedCities.includes(propCity);

  return {
    factor: "City Preference",
    score: isMatch ? WEIGHTS.CITY : 0,
    maxScore: WEIGHTS.CITY,
    detail: isMatch
      ? `Located in ${property.city}, one of your preferred cities`
      : `Located in ${property.city}, outside your preferred cities (${cities.join(", ")})`,
  };
}

function scoreBudgetMatch(property: PropertyData, budgetMin: number, budgetMax: number): MatchReason {
  const minInv = property.minInvestment;

  if (minInv > budgetMax) {
    return {
      factor: "Budget Fit",
      score: 0,
      maxScore: WEIGHTS.BUDGET,
      detail: `Minimum investment PKR ${minInv.toLocaleString()} exceeds your maximum budget of PKR ${budgetMax.toLocaleString()}`,
    };
  }

  if (minInv <= budgetMin) {
    return {
      factor: "Budget Fit",
      score: WEIGHTS.BUDGET,
      maxScore: WEIGHTS.BUDGET,
      detail: `Minimum investment PKR ${minInv.toLocaleString()} is well within your budget range (PKR ${budgetMin.toLocaleString()} - ${budgetMax.toLocaleString()})`,
    };
  }

  const ratio = 1 - (minInv - budgetMin) / (budgetMax - budgetMin);
  const score = Math.round(ratio * WEIGHTS.BUDGET);

  return {
    factor: "Budget Fit",
    score,
    maxScore: WEIGHTS.BUDGET,
    detail: `Minimum investment PKR ${minInv.toLocaleString()} fits within your budget range`,
  };
}

function scoreGoalMatch(property: PropertyData, goal: InvestorGoal): MatchReason {
  const strategy = property.strategy.toUpperCase();
  const yieldVal = property.annualYield;
  const appreciationVal = property.appreciation;

  if (goal === "INCOME") {
    if (strategy === "INCOME") {
      const yieldBonus = yieldVal >= 15 ? WEIGHTS.GOAL : Math.round((yieldVal / 15) * WEIGHTS.GOAL * 0.8) + Math.round(WEIGHTS.GOAL * 0.2);
      return {
        factor: "Investment Goal",
        score: Math.min(yieldBonus, WEIGHTS.GOAL),
        maxScore: WEIGHTS.GOAL,
        detail: `Income-focused property with ${yieldVal}% annual yield aligns with your income goal`,
      };
    }
    const partial = Math.round(WEIGHTS.GOAL * 0.3);
    return {
      factor: "Investment Goal",
      score: partial,
      maxScore: WEIGHTS.GOAL,
      detail: `Growth-focused property (${appreciationVal}% appreciation) partially aligns with income goals via potential rental yields`,
    };
  }

  if (goal === "GROWTH") {
    if (strategy === "GROWTH") {
      const growthBonus = appreciationVal >= 12 ? WEIGHTS.GOAL : Math.round((appreciationVal / 12) * WEIGHTS.GOAL * 0.8) + Math.round(WEIGHTS.GOAL * 0.2);
      return {
        factor: "Investment Goal",
        score: Math.min(growthBonus, WEIGHTS.GOAL),
        maxScore: WEIGHTS.GOAL,
        detail: `Growth-focused property with ${appreciationVal}% projected appreciation aligns with your growth goal`,
      };
    }
    const partial = Math.round(WEIGHTS.GOAL * 0.3);
    return {
      factor: "Investment Goal",
      score: partial,
      maxScore: WEIGHTS.GOAL,
      detail: `Income-focused property (${yieldVal}% yield) partially contributes to growth through reinvestment`,
    };
  }

  const incomeScore = (yieldVal / 20) * 0.5;
  const growthScore = (appreciationVal / 15) * 0.5;
  const combined = Math.min(1, incomeScore + growthScore);
  const score = Math.round(combined * WEIGHTS.GOAL);

  return {
    factor: "Investment Goal",
    score,
    maxScore: WEIGHTS.GOAL,
    detail: `Balanced profile: ${yieldVal}% yield + ${appreciationVal}% appreciation provides diversified returns`,
  };
}

function scoreLiquidityMatch(property: PropertyData, liquidityNeed: LiquidityNeed): MatchReason {
  const fundedPercent = (property.soldTokens / property.totalTokens) * 100;

  if (liquidityNeed === "HIGH") {
    if (fundedPercent >= 80) {
      return {
        factor: "Liquidity",
        score: WEIGHTS.LIQUIDITY,
        maxScore: WEIGHTS.LIQUIDITY,
        detail: `${fundedPercent.toFixed(0)}% funded — high liquidity potential with active secondary market expected`,
      };
    }
    const ratio = fundedPercent / 80;
    const score = Math.round(ratio * WEIGHTS.LIQUIDITY);
    return {
      factor: "Liquidity",
      score,
      maxScore: WEIGHTS.LIQUIDITY,
      detail: `${fundedPercent.toFixed(0)}% funded — secondary market liquidity may be limited initially`,
    };
  }

  if (liquidityNeed === "LOW") {
    const score = fundedPercent < 60 ? WEIGHTS.LIQUIDITY : Math.round(WEIGHTS.LIQUIDITY * 0.8);
    return {
      factor: "Liquidity",
      score,
      maxScore: WEIGHTS.LIQUIDITY,
      detail: `Low liquidity need aligns well — ${fundedPercent.toFixed(0)}% funded with time to appreciate`,
    };
  }

  const score = Math.round(WEIGHTS.LIQUIDITY * 0.7 + (fundedPercent / 100) * WEIGHTS.LIQUIDITY * 0.3);
  return {
    factor: "Liquidity",
    score: Math.min(score, WEIGHTS.LIQUIDITY),
    maxScore: WEIGHTS.LIQUIDITY,
    detail: `Moderate liquidity: ${fundedPercent.toFixed(0)}% funded provides reasonable exit potential`,
  };
}

function scoreRiskMatch(property: PropertyData, riskTolerance: number): MatchReason {
  const type = property.type.toLowerCase();
  let propertyRisk: number;

  if (type === "industrial") propertyRisk = 4;
  else if (type === "commercial" || type === "retail") propertyRisk = 3;
  else if (type === "mixed-use") propertyRisk = 2.5;
  else propertyRisk = 2;

  const fundedPercent = (property.soldTokens / property.totalTokens) * 100;
  if (fundedPercent < 50) propertyRisk += 0.5;

  const diff = Math.abs(riskTolerance - propertyRisk);

  if (diff <= 0.5) {
    return {
      factor: "Risk Profile",
      score: WEIGHTS.RISK,
      maxScore: WEIGHTS.RISK,
      detail: `${property.type} property matches your risk tolerance level ${riskTolerance}/5`,
    };
  }

  const score = Math.max(0, Math.round(WEIGHTS.RISK * (1 - diff / 4)));
  const direction = propertyRisk > riskTolerance ? "higher" : "lower";

  return {
    factor: "Risk Profile",
    score,
    maxScore: WEIGHTS.RISK,
    detail: `${property.type} property has ${direction} risk than your preference (tolerance ${riskTolerance}/5)`,
  };
}

export function scoreProperties(
  properties: PropertyData[],
  preferences: CreatePreferenceProfile
): PropertyMatch[] {
  const maxPossible = WEIGHTS.CITY + WEIGHTS.BUDGET + WEIGHTS.GOAL + WEIGHTS.LIQUIDITY + WEIGHTS.RISK;

  const scored = properties.map(property => {
    const reasons: MatchReason[] = [
      scoreCityMatch(property, preferences.cities),
      scoreBudgetMatch(property, preferences.budgetMin, preferences.budgetMax),
      scoreGoalMatch(property, preferences.goal),
      scoreLiquidityMatch(property, preferences.liquidityNeed),
      scoreRiskMatch(property, preferences.riskTolerance),
    ];

    const totalScore = reasons.reduce((sum, r) => sum + r.score, 0);
    const percentMatch = Math.round((totalScore / maxPossible) * 100);

    return {
      property,
      totalScore,
      maxPossibleScore: maxPossible,
      percentMatch,
      reasons,
    };
  });

  scored.sort((a, b) => b.totalScore - a.totalScore);

  return scored.slice(0, 5);
}

export function buildExplainPrompt(matches: PropertyMatch[], preferences: CreatePreferenceProfile): string {
  const matchSummaries = matches.map((m, i) => {
    const reasonDetails = m.reasons.map(r => `  - ${r.factor}: ${r.score}/${r.maxScore} — ${r.detail}`).join("\n");
    return `#${i + 1}: ${m.property.name} (${m.percentMatch}% match, score ${m.totalScore}/${m.maxPossibleScore})
Location: ${m.property.location}
Type: ${m.property.type} | Strategy: ${m.property.strategy}
Yield: ${m.property.annualYield}% | Appreciation: ${m.property.appreciation}%
Min Investment: PKR ${m.property.minInvestment.toLocaleString()}
Funding: ${((m.property.soldTokens / m.property.totalTokens) * 100).toFixed(0)}% funded
Scoring breakdown:
${reasonDetails}`;
  }).join("\n\n");

  return `You are a property investment analyst for VestBlock. Based on the deterministic scoring results below, write a human-friendly explanation.

INVESTOR PREFERENCES:
- Goal: ${preferences.goal}
- Budget: PKR ${preferences.budgetMin.toLocaleString()} - PKR ${preferences.budgetMax.toLocaleString()}
- Preferred cities: ${preferences.cities.join(", ")}
- Risk tolerance: ${preferences.riskTolerance}/5
- Investment horizon: ${preferences.horizonMonths} months
- Liquidity need: ${preferences.liquidityNeed}

MATCHED PROPERTIES (ranked by deterministic score):
${matchSummaries}

Respond in valid JSON with this exact structure:
{
  "whyTheseMatches": "A 2-3 paragraph explanation of why these specific properties were selected and how they align with the investor's stated preferences. Reference specific scoring factors.",
  "tradeoffs": "A 1-2 paragraph honest discussion of tradeoffs — what the investor gains with these picks and what they might be giving up. Mention any scoring gaps."
}

RULES:
- Never promise or guarantee returns. Use words like "projected", "estimated", "historical".
- Never provide financial advice. Frame as informational analysis only.
- Reference the deterministic scoring factors to show explainability.
- Keep language accessible for non-expert investors.
- Do not add any fields beyond whyTheseMatches and tradeoffs.`;
}
