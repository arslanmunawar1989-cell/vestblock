import { storage } from "../storage";
import { CRYPTO_AML_POLICY } from "@shared/schema";

export interface AmlScreeningResult {
  pass: boolean;
  flags: AmlFlagEntry[];
  action: "CLEAR" | "HOLD" | "REJECT";
  holdReason?: string;
  requiresEdd: boolean;
}

export interface AmlFlagEntry {
  type: string;
  severity: "low" | "medium" | "high" | "critical";
  description: string;
  timestamp: string;
}

export async function screenCryptoDeposit(
  userId: string,
  amount: number,
  chainId: string,
  tokenSymbol: string
): Promise<AmlScreeningResult> {
  const flags: AmlFlagEntry[] = [];
  let action: AmlScreeningResult["action"] = "CLEAR";
  let holdReason: string | undefined;
  let requiresEdd = false;

  const blacklistResult = await checkBlacklistedWallets(userId);
  if (blacklistResult) {
    flags.push(blacklistResult);
    action = "REJECT";
    holdReason = "User has blacklisted crypto wallet addresses";
    return { pass: false, flags, action, holdReason, requiresEdd };
  }

  const largeDepositFlag = checkLargeDeposit(amount);
  if (largeDepositFlag) {
    flags.push(largeDepositFlag);
    action = "HOLD";
    holdReason = `Large deposit ($${amount.toLocaleString()}) exceeds threshold ($${CRYPTO_AML_POLICY.largeDepositThreshold.toLocaleString()}) — EDD required`;
    requiresEdd = true;
  }

  const structuringFlag = await checkStructuring(userId, amount);
  if (structuringFlag) {
    flags.push(structuringFlag);
    if (action !== "REJECT") action = "HOLD";
    holdReason = holdReason
      ? `${holdReason}; Structuring pattern detected`
      : "Structuring pattern detected — repeated small deposits within monitoring window";
  }

  const activeAmlFlags = await storage.getActiveAmlFlagsByUser(userId);
  if (activeAmlFlags.length > 0) {
    flags.push({
      type: "EXISTING_AML_FLAGS",
      severity: "medium",
      description: `User has ${activeAmlFlags.length} active AML flag(s)`,
      timestamp: new Date().toISOString(),
    });
    if (action === "CLEAR") {
      action = "HOLD";
      holdReason = "User has existing unresolved AML flags";
    }
  }

  const user = await storage.getUser(userId);
  if (user && user.eddStatus === "EDD_REQUIRED") {
    if (action === "CLEAR") {
      action = "HOLD";
      holdReason = "User has pending EDD requirement";
    }
  }

  return {
    pass: action === "CLEAR",
    flags,
    action,
    holdReason,
    requiresEdd,
  };
}

async function checkBlacklistedWallets(userId: string): Promise<AmlFlagEntry | null> {
  const wallets = await storage.getCryptoWalletsByUser(userId);
  const blacklisted = wallets.filter(w => w.isBlacklisted);
  if (blacklisted.length > 0) {
    return {
      type: "BLACKLISTED_WALLET",
      severity: "critical",
      description: `User has ${blacklisted.length} blacklisted wallet address(es): ${blacklisted.map(w => `${w.chainId}:${w.address.slice(0, 10)}...`).join(", ")}`,
      timestamp: new Date().toISOString(),
    };
  }
  return null;
}

function checkLargeDeposit(amount: number): AmlFlagEntry | null {
  if (amount >= CRYPTO_AML_POLICY.largeDepositThreshold) {
    return {
      type: "LARGE_DEPOSIT",
      severity: "high",
      description: `Deposit amount $${amount.toLocaleString()} exceeds large deposit threshold of $${CRYPTO_AML_POLICY.largeDepositThreshold.toLocaleString()}`,
      timestamp: new Date().toISOString(),
    };
  }
  return null;
}

async function checkStructuring(userId: string, currentAmount: number): Promise<AmlFlagEntry | null> {
  if (currentAmount >= CRYPTO_AML_POLICY.structuringSmallAmountThreshold) {
    return null;
  }

  const windowStart = new Date();
  windowStart.setHours(windowStart.getHours() - CRYPTO_AML_POLICY.structuringWindowHours);

  const recentDeposits = await storage.getRecentCryptoDeposits(userId, windowStart.toISOString());
  const smallDeposits = recentDeposits.filter(
    d => parseFloat(d.amount) < CRYPTO_AML_POLICY.structuringSmallAmountThreshold && d.status !== "REJECTED"
  );

  const totalCount = smallDeposits.length + 1;
  if (totalCount >= CRYPTO_AML_POLICY.structuringMaxCount) {
    const totalAmount = smallDeposits.reduce((sum, d) => sum + parseFloat(d.amount), 0) + currentAmount;
    return {
      type: "STRUCTURING",
      severity: "high",
      description: `Potential structuring detected: ${totalCount} small deposits (each under $${CRYPTO_AML_POLICY.structuringSmallAmountThreshold.toLocaleString()}) totaling $${totalAmount.toLocaleString()} within ${CRYPTO_AML_POLICY.structuringWindowHours}h window`,
      timestamp: new Date().toISOString(),
    };
  }
  return null;
}

export async function applyAmlActions(
  userId: string,
  intentId: string,
  screening: AmlScreeningResult
): Promise<void> {
  for (const flag of screening.flags) {
    if (flag.type === "BLACKLISTED_WALLET" || flag.type === "LARGE_DEPOSIT" || flag.type === "STRUCTURING") {
      await storage.createAmlFlag({
        userId,
        flagType: `CRYPTO_${flag.type}`,
        severity: flag.severity,
        description: flag.description,
        details: { depositIntentId: intentId, ...flag },
      });
    }
  }

  if (screening.requiresEdd) {
    const user = await storage.getUser(userId);
    if (user && user.eddStatus === "none") {
      await storage.updateUserEddStatus(userId, "EDD_REQUIRED");
    }
  }
}
