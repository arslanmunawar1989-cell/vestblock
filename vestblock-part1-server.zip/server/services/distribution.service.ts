import { storage } from "../storage";
import { db } from "../db";
import type { Distribution, DistributionPayout, DistributionSnapshot } from "@shared/schema";

interface DistributionInput {
  assetId: string;
  netDistributable: number;
  currency: string;
  waterfallCalculationId?: string;
  recordDate?: string;
  createdBy: string;
}

interface PayoutDetail {
  userId: string;
  username: string;
  fullName: string;
  tokenId: string;
  holdingBalance: number;
  holdingPercent: number;
  payoutAmount: number;
  payoutCurrency: string;
  autoConverted: boolean;
  convertedAmount?: number;
  convertedCurrency?: string;
  conversionRate?: number;
}

interface SnapshotHolding {
  userId: string;
  tokenId: string;
  balance: string;
  percent: string;
}

interface DistributionResult {
  distribution: Distribution;
  snapshot: DistributionSnapshot;
  payouts: DistributionPayout[];
  summary: {
    snapshotDate: string;
    recordDate: string;
    totalDistributed: string;
    currency: string;
    recipientCount: number;
    perTokenAmount: string;
    totalTokenSupply: string;
    holdingsSnapshot: SnapshotHolding[];
    payoutDetails: PayoutDetail[];
    autoConvertedCount: number;
  };
}

export async function executeDistribution(input: DistributionInput): Promise<DistributionResult> {
  const { assetId, netDistributable, createdBy } = input;

  const asset = await storage.getAsset(assetId);
  const vehicle = !asset ? await storage.getInvestmentVehicle(assetId) : null;
  const entity = asset || vehicle;
  if (!entity) {
    throw new Error("Asset or vehicle not found");
  }

  const baseCurrency = entity.baseCurrency || "AED";

  if (input.currency !== baseCurrency) {
    throw new Error(`Distribution currency must be the base currency (${baseCurrency}). Received: ${input.currency}`);
  }

  const currency = baseCurrency;

  let token = await storage.getTokenByAssetId(assetId);
  if (!token) {
    const vehicleTokens = await storage.getTokensByVehicle(assetId);
    token = vehicleTokens.length > 0 ? vehicleTokens[0] : undefined;
  }
  if (!token) {
    throw new Error("No token found for this asset/vehicle");
  }

  const holdings = await storage.getTokenHoldingsByToken(token.id);
  const activeHoldings = holdings.filter(h => parseFloat(h.balance) > 0);

  if (activeHoldings.length === 0) {
    throw new Error("No token holders found for this asset");
  }

  const totalSupply = activeHoldings.reduce((sum, h) => sum + parseFloat(h.balance), 0);

  if (totalSupply <= 0) {
    throw new Error("Total token supply is zero");
  }

  const perTokenAmount = netDistributable / totalSupply;

  const now = new Date();
  const snapshotDate = now.toISOString();
  const recordDate = input.recordDate || snapshotDate.split("T")[0];
  const distributionDate = snapshotDate.split("T")[0];

  const holdingsSnapshot: SnapshotHolding[] = activeHoldings.map(h => ({
    userId: h.userId,
    tokenId: h.tokenId,
    balance: h.balance,
    percent: ((parseFloat(h.balance) / totalSupply) * 100).toFixed(6),
  }));

  const snapshot = await storage.createDistributionSnapshot({
    assetId,
    tokenId: token.id,
    recordDate,
    totalSupply: totalSupply.toFixed(6),
    holderCount: activeHoldings.length,
    holdings: holdingsSnapshot,
    createdBy,
  });

  const distribution = await storage.createDistribution({
    assetId,
    amount: netDistributable.toFixed(2),
    currency,
    distributionDate,
    recordDate,
    snapshotId: snapshot.id,
    status: "completed",
    perTokenAmount: perTokenAmount.toFixed(6),
    recipientCount: activeHoldings.length,
    waterfallCalculationId: input.waterfallCalculationId || null,
    createdBy,
  });

  const payouts: DistributionPayout[] = [];
  const payoutDetails: PayoutDetail[] = [];
  let autoConvertedCount = 0;

  for (const holding of activeHoldings) {
    const holdingBalance = parseFloat(holding.balance);
    const holdingPercent = (holdingBalance / totalSupply) * 100;
    const payoutAmount = Math.round(holdingBalance * perTokenAmount * 100) / 100;

    if (payoutAmount <= 0) continue;

    const user = await storage.getUser(holding.userId);
    if (!user) continue;

    const wallet = await storage.getOrCreateWallet(holding.userId, currency);

    const walletTx = await storage.createWalletTransaction({
      walletAccountId: wallet.id,
      type: "DISTRIBUTION",
      amount: payoutAmount.toFixed(2),
      currency,
      status: "COMPLETED",
      referenceId: distribution.id,
      description: `Distribution payout for ${token.tokenSymbol} - ${distributionDate}`,
      metadata: {
        distributionId: distribution.id,
        snapshotId: snapshot.id,
        tokenId: token.id,
        tokenSymbol: token.tokenSymbol,
        holdingBalance: holdingBalance.toFixed(6),
        holdingPercent: holdingPercent.toFixed(4),
        perTokenAmount: perTokenAmount.toFixed(6),
        recordDate,
      },
    });

    let autoConverted = false;
    let convertedAmount: number | undefined;
    let convertedCurrency: string | undefined;
    let conversionRate: number | undefined;
    let convertedWalletAccountId: string | undefined;
    let convertedWalletTransactionId: string | undefined;

    const userPrimaryCurrency = user.primaryCurrency;
    const prefs = user.notificationPreferences as any;
    const shouldAutoConvert = prefs?.autoConvertDistributions && userPrimaryCurrency && userPrimaryCurrency !== currency;

    if (shouldAutoConvert) {
      const targetCurrency = userPrimaryCurrency!;
      const fxRate = await storage.getActiveFxRate(currency, targetCurrency);

      if (fxRate) {
        const rate = parseFloat(fxRate.rate);
        convertedAmount = Math.round(payoutAmount * rate * 100) / 100;
        convertedCurrency = targetCurrency;
        conversionRate = rate;
        autoConverted = true;
        autoConvertedCount++;

        const targetWallet = await storage.getOrCreateWallet(holding.userId, targetCurrency);
        convertedWalletAccountId = targetWallet.id;

        const convertedTx = await storage.createWalletTransaction({
          walletAccountId: targetWallet.id,
          type: "FX_CONVERSION",
          amount: convertedAmount.toFixed(2),
          currency: targetCurrency,
          status: "COMPLETED",
          referenceId: distribution.id,
          description: `Auto-converted distribution: ${payoutAmount.toFixed(2)} ${currency} → ${convertedAmount.toFixed(2)} ${targetCurrency}`,
          metadata: {
            distributionId: distribution.id,
            snapshotId: snapshot.id,
            originalAmount: payoutAmount.toFixed(2),
            originalCurrency: currency,
            conversionRate: rate.toFixed(6),
          },
        });
        convertedWalletTransactionId = convertedTx.id;
      }
    }

    const payout = await storage.createDistributionPayout({
      distributionId: distribution.id,
      userId: holding.userId,
      tokenId: token.id,
      holdingBalance: holdingBalance.toFixed(6),
      holdingPercent: holdingPercent.toFixed(6),
      payoutAmount: payoutAmount.toFixed(2),
      payoutCurrency: currency,
      walletAccountId: wallet.id,
      walletTransactionId: walletTx.id,
      autoConverted,
      convertedAmount: convertedAmount?.toFixed(2) || null,
      convertedCurrency: convertedCurrency || null,
      conversionRate: conversionRate?.toFixed(6) || null,
      convertedWalletAccountId: convertedWalletAccountId || null,
      convertedWalletTransactionId: convertedWalletTransactionId || null,
    });

    payouts.push(payout);
    payoutDetails.push({
      userId: holding.userId,
      username: user.username,
      fullName: user.fullName,
      tokenId: token.id,
      holdingBalance,
      holdingPercent: Math.round(holdingPercent * 10000) / 10000,
      payoutAmount,
      payoutCurrency: currency,
      autoConverted,
      convertedAmount,
      convertedCurrency,
      conversionRate,
    });
  }

  return {
    distribution,
    snapshot,
    payouts,
    summary: {
      snapshotDate,
      recordDate,
      totalDistributed: netDistributable.toFixed(2),
      currency,
      recipientCount: payouts.length,
      perTokenAmount: perTokenAmount.toFixed(6),
      totalTokenSupply: totalSupply.toFixed(6),
      holdingsSnapshot,
      payoutDetails,
      autoConvertedCount,
    },
  };
}
