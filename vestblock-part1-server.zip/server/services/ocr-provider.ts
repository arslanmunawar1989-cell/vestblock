import type { DocIngestionType } from "@shared/schema";

export interface ExtractionField {
  key: string;
  value: string | null;
  confidence: number;
  source?: string;
}

export interface ExtractionResult {
  provider: string;
  docType: DocIngestionType;
  fields: ExtractionField[];
  overallConfidence: number;
  rawResponse?: unknown;
}

export interface OcrProvider {
  readonly name: string;
  readonly enabled: boolean;
  extract(docType: DocIngestionType, fileUrl: string, mimeType?: string): Promise<ExtractionResult>;
}

export const EXTRACTION_SCHEMAS: Record<DocIngestionType, { key: string; label: string; kycField?: string }[]> = {
  passport: [
    { key: "full_name", label: "Full Name", kycField: "legalName" },
    { key: "date_of_birth", label: "Date of Birth", kycField: "dob" },
    { key: "passport_number", label: "Passport Number", kycField: "idNumber" },
    { key: "nationality", label: "Nationality" },
    { key: "expiry_date", label: "Expiry Date" },
    { key: "issuing_country", label: "Issuing Country" },
    { key: "gender", label: "Gender" },
    { key: "mrz_line_1", label: "MRZ Line 1" },
    { key: "mrz_line_2", label: "MRZ Line 2" },
  ],
  national_id: [
    { key: "full_name", label: "Full Name", kycField: "legalName" },
    { key: "date_of_birth", label: "Date of Birth", kycField: "dob" },
    { key: "id_number", label: "ID Number", kycField: "idNumber" },
    { key: "nationality", label: "Nationality" },
    { key: "expiry_date", label: "Expiry Date" },
    { key: "address", label: "Address", kycField: "address" },
  ],
  bank_statement: [
    { key: "account_holder", label: "Account Holder Name" },
    { key: "bank_name", label: "Bank Name" },
    { key: "account_number", label: "Account Number" },
    { key: "iban", label: "IBAN" },
    { key: "statement_period", label: "Statement Period" },
    { key: "opening_balance", label: "Opening Balance" },
    { key: "closing_balance", label: "Closing Balance" },
    { key: "currency", label: "Currency" },
  ],
  title_deed: [
    { key: "owner_name", label: "Owner Name" },
    { key: "property_address", label: "Property Address" },
    { key: "deed_number", label: "Deed/Title Number" },
    { key: "plot_number", label: "Plot Number" },
    { key: "area_sqft", label: "Area (sq ft)" },
    { key: "registration_date", label: "Registration Date" },
    { key: "property_type", label: "Property Type" },
    { key: "municipality", label: "Municipality/Authority" },
  ],
  lease_agreement: [
    { key: "tenant_name", label: "Tenant Name" },
    { key: "landlord_name", label: "Landlord Name" },
    { key: "property_address", label: "Property Address" },
    { key: "lease_start", label: "Lease Start Date" },
    { key: "lease_end", label: "Lease End Date" },
    { key: "monthly_rent", label: "Monthly Rent" },
    { key: "currency", label: "Currency" },
    { key: "security_deposit", label: "Security Deposit" },
    { key: "contract_number", label: "Contract Number" },
  ],
  utility_bill: [
    { key: "account_holder", label: "Account Holder Name" },
    { key: "service_address", label: "Service Address", kycField: "address" },
    { key: "provider", label: "Utility Provider" },
    { key: "bill_date", label: "Bill Date" },
    { key: "amount_due", label: "Amount Due" },
    { key: "account_number", label: "Account Number" },
  ],
  tax_return: [
    { key: "taxpayer_name", label: "Taxpayer Name", kycField: "legalName" },
    { key: "tax_id", label: "Tax ID / TIN" },
    { key: "tax_year", label: "Tax Year" },
    { key: "gross_income", label: "Gross Income" },
    { key: "tax_paid", label: "Tax Paid" },
    { key: "filing_date", label: "Filing Date" },
  ],
};

class MockOcrProvider implements OcrProvider {
  readonly name = "mock";
  readonly enabled = false;

  async extract(docType: DocIngestionType, _fileUrl: string): Promise<ExtractionResult> {
    const schema = EXTRACTION_SCHEMAS[docType] || [];
    const fields: ExtractionField[] = schema.map(f => ({
      key: f.key,
      value: null,
      confidence: 0,
      source: "mock",
    }));
    return {
      provider: this.name,
      docType,
      fields,
      overallConfidence: 0,
    };
  }
}

let currentProvider: OcrProvider = new MockOcrProvider();

export function getOcrProvider(): OcrProvider {
  return currentProvider;
}

export function setOcrProvider(provider: OcrProvider): void {
  console.log(`[ocr] Provider set to "${provider.name}" (enabled=${provider.enabled})`);
  currentProvider = provider;
}
