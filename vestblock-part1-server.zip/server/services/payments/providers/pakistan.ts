import type { PaymentIntent } from "@shared/schema";
import type { PaymentProvider, PaymentProviderResult, WebhookPayload } from "../../../payment-provider";

const PK_PAYMENT_INSTRUCTIONS: Record<string, { title: string; steps: string[]; details: Record<string, string> }> = {
  jazzcash: {
    title: "JazzCash Mobile Wallet",
    steps: [
      "Open the JazzCash app on your phone",
      "Select 'Send Money' > 'To Other Account'",
      "Enter the VestBlock JazzCash account number",
      "Enter the exact amount and use the reference code in the description",
      "Confirm the transfer and screenshot the receipt",
      "Upload the receipt as proof of payment",
    ],
    details: {
      accountTitle: "VestBlock Pakistan (Pvt) Ltd",
      accountNumber: "0300-1234567",
      provider: "JazzCash",
    },
  },
  easypaisa: {
    title: "Easypaisa Mobile Wallet",
    steps: [
      "Open the Easypaisa app on your phone",
      "Select 'Send Money'",
      "Enter the VestBlock Easypaisa account number",
      "Enter the exact amount and include the reference code",
      "Confirm the transfer and screenshot the receipt",
      "Upload the receipt as proof of payment",
    ],
    details: {
      accountTitle: "VestBlock Pakistan (Pvt) Ltd",
      accountNumber: "0345-6789012",
      provider: "Easypaisa",
    },
  },
  raast: {
    title: "Raast Instant Transfer",
    steps: [
      "Open your bank's mobile app (must support Raast)",
      "Select 'Raast Payment' or 'Instant Transfer'",
      "Enter the VestBlock Raast ID",
      "Enter the exact amount and use the reference code",
      "Confirm the instant transfer",
      "Upload the confirmation screenshot as proof",
    ],
    details: {
      accountTitle: "VestBlock Pakistan (Pvt) Ltd",
      raastId: "VB-PKR-RAAST-001",
      iban: "PK36 HABB 0012 3456 7890 1234",
      provider: "Raast (SBP)",
    },
  },
  taptap_send: {
    title: "TapTap Send (International Remittance)",
    steps: [
      "Download/open the TapTap Send app",
      "Select Pakistan as the destination country",
      "Enter the VestBlock bank details as the recipient",
      "Enter the amount you wish to send (will be converted to PKR)",
      "Use the reference code in the transfer note/description",
      "Complete the transfer and screenshot the confirmation",
      "Upload the confirmation as proof of payment",
    ],
    details: {
      recipientName: "VestBlock Pakistan (Pvt) Ltd",
      bankName: "Habib Bank Limited (HBL)",
      iban: "PK36 HABB 0012 3456 7890 1234",
      provider: "TapTap Send",
      note: "Funds are converted to PKR at TapTap Send rates",
    },
  },
  pk_international_wire: {
    title: "International Wire Transfer to Pakistan",
    steps: [
      "Log into your international bank account",
      "Initiate an international wire transfer",
      "Enter the VestBlock Pakistan bank details (IBAN + SWIFT)",
      "Specify the amount in the sending currency (will settle in PKR)",
      "Include the reference code in the payment reference field",
      "Upload the wire transfer confirmation as proof",
    ],
    details: {
      bankName: "Habib Bank Limited (HBL)",
      accountTitle: "VestBlock Pakistan (Pvt) Ltd",
      iban: "PK36 HABB 0012 3456 7890 1234",
      swiftCode: "HABORPKAXXX",
      branch: "Karachi Main Branch, I.I. Chundrigar Road",
      currency: "PKR",
      correspondentBank: "Standard Chartered Bank, New York (SCBLUS33)",
      note: "International wires typically take 2-5 business days",
    },
  },
};

function createManualProvider(providerName: string): PaymentProvider {
  const instructions = PK_PAYMENT_INSTRUCTIONS[providerName];

  return {
    name: providerName,

    async createIntent(intent: PaymentIntent): Promise<PaymentProviderResult> {
      return {
        providerIntentId: `${providerName}_${intent.id}`,
        status: "CREATED",
        providerResponse: {
          message: `${instructions?.title || providerName} payment intent created. Follow instructions and upload proof.`,
          instructions: instructions?.steps || [],
          paymentDetails: instructions?.details || {},
          referenceCode: `VB-${intent.id.slice(0, 8).toUpperCase()}`,
        },
      };
    },

    async confirmIntent(intent: PaymentIntent, data?: Record<string, any>): Promise<PaymentProviderResult> {
      return {
        providerIntentId: intent.providerIntentId || `${providerName}_${intent.id}`,
        status: "CONFIRMED",
        providerResponse: {
          confirmedBy: data?.confirmedBy || "admin",
          reconciliationId: data?.reconciliationId,
          provider: providerName,
          ...data,
        },
      };
    },

    async confirmWebhook(intent: PaymentIntent, _payload: WebhookPayload): Promise<PaymentProviderResult> {
      return {
        providerIntentId: intent.providerIntentId || `${providerName}_${intent.id}`,
        status: "CONFIRMED",
        providerResponse: {
          confirmedVia: "webhook",
          provider: providerName,
        },
      };
    },

    async cancelIntent(intent: PaymentIntent): Promise<PaymentProviderResult> {
      return {
        providerIntentId: intent.providerIntentId || `${providerName}_${intent.id}`,
        status: "FAILED",
        failureReason: "Cancelled by admin",
      };
    },

    async reverse(intent: PaymentIntent, reason?: string): Promise<PaymentProviderResult> {
      return {
        providerIntentId: intent.providerIntentId || `${providerName}_${intent.id}`,
        status: "REVERSED",
        providerResponse: {
          reversedAt: new Date().toISOString(),
          reason: reason || "Reversed",
          provider: providerName,
        },
      };
    },

    async getStatus(intent: PaymentIntent): Promise<PaymentProviderResult> {
      return {
        providerIntentId: intent.providerIntentId || `${providerName}_${intent.id}`,
        status: intent.status as any,
      };
    },
  };
}

export const jazzCashProvider = createManualProvider("jazzcash");
export const easypaisaProvider = createManualProvider("easypaisa");
export const raastProvider = createManualProvider("raast");
export const tapTapSendProvider = createManualProvider("taptap_send");
export const pkInternationalWireProvider = createManualProvider("pk_international_wire");

export function getPakistanPaymentInstructions(providerName: string) {
  return PK_PAYMENT_INSTRUCTIONS[providerName] || null;
}
