import Stripe from "stripe";
import type { PaymentIntent } from "@shared/schema";
import type { PaymentProvider, PaymentProviderResult, WebhookPayload } from "../../../payment-provider";

let stripeClient: Stripe | null = null;

function getStripe(): Stripe {
  if (!stripeClient) {
    const key = process.env.STRIPE_SECRET_KEY;
    if (!key) throw new Error("STRIPE_SECRET_KEY is not configured");
    stripeClient = new Stripe(key, { apiVersion: "2025-01-27.acacia" as any });
  }
  return stripeClient;
}

export function isStripeConfigured(): boolean {
  return !!process.env.STRIPE_SECRET_KEY;
}

const STRIPE_CURRENCY_MAP: Record<string, string> = {
  AED: "aed",
  GBP: "gbp",
  USD: "usd",
  EUR: "eur",
  PKR: "pkr",
  QAR: "qar",
};

export class StripePaymentProvider implements PaymentProvider {
  name = "stripe";

  async createIntent(intent: PaymentIntent): Promise<PaymentProviderResult> {
    if (!isStripeConfigured()) {
      return {
        status: "FAILED",
        failureReason: "Stripe is not configured. Please add STRIPE_SECRET_KEY.",
      };
    }

    const stripe = getStripe();
    const stripeCurrency = STRIPE_CURRENCY_MAP[intent.currency] || intent.currency.toLowerCase();
    const amountInMinor = Math.round(parseFloat(intent.amount) * 100);

    const baseUrl = process.env.REPLIT_DEV_DOMAIN
      ? `https://${process.env.REPLIT_DEV_DOMAIN}`
      : `http://localhost:5000`;

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      payment_method_types: ["card"],
      currency: stripeCurrency,
      line_items: [
        {
          price_data: {
            currency: stripeCurrency,
            product_data: {
              name: `VestBlock Deposit`,
              description: `Fund your wallet with ${intent.currency} ${intent.amount}`,
            },
            unit_amount: amountInMinor,
          },
          quantity: 1,
        },
      ],
      metadata: {
        paymentIntentId: intent.id,
        userId: intent.userId,
        currency: intent.currency,
        walletAccountId: intent.walletAccountId || "",
      },
      success_url: `${baseUrl}/investor/add-funds?stripe=success&intent=${intent.id}`,
      cancel_url: `${baseUrl}/investor/add-funds?stripe=cancelled&intent=${intent.id}`,
    });

    return {
      providerIntentId: session.id,
      sessionUrl: session.url || undefined,
      status: "PENDING",
      providerResponse: {
        sessionId: session.id,
        sessionUrl: session.url,
        expiresAt: new Date(Date.now() + 30 * 60 * 1000).toISOString(),
      },
    };
  }

  async confirmIntent(intent: PaymentIntent, data?: Record<string, any>): Promise<PaymentProviderResult> {
    return {
      providerIntentId: intent.providerIntentId || undefined,
      status: "CONFIRMED",
      providerResponse: {
        confirmedVia: "stripe_webhook",
        stripeSessionId: intent.providerIntentId,
        ...data,
      },
    };
  }

  async confirmWebhook(intent: PaymentIntent, payload: WebhookPayload): Promise<PaymentProviderResult> {
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
    const stripeKey = process.env.STRIPE_SECRET_KEY;
    if (!webhookSecret || !stripeKey) {
      return { status: "FAILED", failureReason: "Stripe webhook not configured" };
    }

    const stripe = getStripe();
    const sig = payload.headers["stripe-signature"];
    if (!sig) {
      return { status: "FAILED", failureReason: "Missing stripe-signature header" };
    }

    try {
      const event = stripe.webhooks.constructEvent(payload.rawBody as Buffer, sig, webhookSecret);

      if (event.type === "checkout.session.completed") {
        const session = event.data.object as Stripe.Checkout.Session;
        return {
          providerIntentId: session.id,
          status: "CONFIRMED",
          providerResponse: {
            confirmedVia: "stripe_webhook",
            stripeSessionId: session.id,
            stripePaymentIntent: session.payment_intent,
            paymentStatus: session.payment_status,
          },
        };
      }

      if (event.type === "checkout.session.expired") {
        return {
          providerIntentId: intent.providerIntentId || undefined,
          status: "FAILED",
          failureReason: "Stripe checkout session expired",
        };
      }

      return { status: intent.status as any, providerResponse: { event: event.type } };
    } catch (err: any) {
      return { status: "FAILED", failureReason: `Webhook verification failed: ${err.message}` };
    }
  }

  async cancelIntent(intent: PaymentIntent): Promise<PaymentProviderResult> {
    return {
      providerIntentId: intent.providerIntentId || undefined,
      status: "FAILED",
      failureReason: "Cancelled or expired",
    };
  }

  async reverse(intent: PaymentIntent, reason?: string): Promise<PaymentProviderResult> {
    if (!isStripeConfigured() || !intent.providerIntentId) {
      return {
        providerIntentId: intent.providerIntentId || undefined,
        status: "REVERSED",
        providerResponse: { reason: reason || "Reversed", reversedAt: new Date().toISOString() },
      };
    }

    const stripe = getStripe();
    try {
      const session = await stripe.checkout.sessions.retrieve(intent.providerIntentId);
      if (session.payment_intent && typeof session.payment_intent === "string") {
        const refund = await stripe.refunds.create({
          payment_intent: session.payment_intent,
          reason: "requested_by_customer",
        });
        return {
          providerIntentId: intent.providerIntentId,
          status: "REVERSED",
          providerResponse: {
            refundId: refund.id,
            refundStatus: refund.status,
            reason: reason || "Reversed via Stripe refund",
            reversedAt: new Date().toISOString(),
          },
        };
      }
    } catch (err: any) {
      return {
        providerIntentId: intent.providerIntentId,
        status: "REVERSED",
        providerResponse: {
          reason: reason || "Reversed (refund attempted)",
          error: err.message,
          reversedAt: new Date().toISOString(),
        },
      };
    }

    return {
      providerIntentId: intent.providerIntentId,
      status: "REVERSED",
      providerResponse: { reason: reason || "Reversed", reversedAt: new Date().toISOString() },
    };
  }

  async getStatus(intent: PaymentIntent): Promise<PaymentProviderResult> {
    if (!isStripeConfigured() || !intent.providerIntentId) {
      return {
        providerIntentId: intent.providerIntentId || undefined,
        status: intent.status as any,
      };
    }

    const stripe = getStripe();
    try {
      const session = await stripe.checkout.sessions.retrieve(intent.providerIntentId);
      const statusMap: Record<string, any> = {
        complete: "CONFIRMED",
        expired: "FAILED",
        open: "PENDING",
      };
      return {
        providerIntentId: session.id,
        status: statusMap[session.status || "open"] || "PENDING",
        providerResponse: { stripeStatus: session.status, paymentStatus: session.payment_status },
      };
    } catch {
      return { providerIntentId: intent.providerIntentId, status: intent.status as any };
    }
  }
}
