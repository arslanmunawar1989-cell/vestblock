import type { PaymentIntent } from "@shared/schema";
import type { PaymentProvider, PaymentProviderResult, WebhookPayload } from "../../../payment-provider";

export type AchBankVerificationStatus =
  | "not_started"
  | "pending_micro_deposits"
  | "micro_deposits_sent"
  | "verified"
  | "failed"
  | "expired";

export type AchIntentStatus =
  | "CREATED"
  | "BANK_LINKED"
  | "PENDING"
  | "PROCESSING"
  | "CONFIRMED"
  | "FAILED"
  | "RETURNED";

export interface AchBankDetails {
  routingNumber: string;
  accountNumber: string;
  accountType: "checking" | "savings";
  accountHolderName: string;
  bankName?: string;
}

export interface AchMetadata {
  achBankVerificationStatus: AchBankVerificationStatus;
  achBankDetails?: Partial<AchBankDetails>;
  achTransferId?: string;
  achReturnCode?: string;
  achReturnReason?: string;
  achSettlementDate?: string;
  achInitiatedAt?: string;
  achCompletedAt?: string;
}

const VALID_TRANSITIONS: Record<string, string[]> = {
  CREATED: ["BANK_LINKED", "FAILED"],
  BANK_LINKED: ["PENDING", "FAILED"],
  PENDING: ["PROCESSING", "FAILED"],
  PROCESSING: ["CONFIRMED", "FAILED", "RETURNED"],
  CONFIRMED: ["RETURNED"],
  FAILED: [],
  RETURNED: [],
};

function validateTransition(from: string, to: string): boolean {
  const allowed = VALID_TRANSITIONS[from];
  return !!allowed && allowed.includes(to);
}

function maskAccountNumber(acctNum: string): string {
  if (acctNum.length <= 4) return "****";
  return "****" + acctNum.slice(-4);
}

export class AchPaymentProvider implements PaymentProvider {
  name = "ach";

  async createIntent(intent: PaymentIntent): Promise<PaymentProviderResult> {
    const achMeta: AchMetadata = {
      achBankVerificationStatus: "not_started",
    };

    return {
      providerIntentId: `ach_${intent.id}`,
      status: "CREATED",
      providerResponse: {
        message: "ACH payment intent created. Link and verify your US bank account to proceed.",
        provider: "ach",
        achMetadata: achMeta,
        instructions: [
          "Provide your US bank account details (routing number, account number)",
          "Two micro-deposits will be sent to verify your account (1-2 business days)",
          "Confirm the micro-deposit amounts to complete verification",
          "Once verified, the ACH transfer will be initiated",
          "ACH transfers typically settle in 2-3 business days",
        ],
        referenceCode: `VB-${intent.id.slice(0, 8).toUpperCase()}`,
      },
    };
  }

  async linkBankAccount(
    intent: PaymentIntent,
    bankDetails: AchBankDetails
  ): Promise<PaymentProviderResult> {
    if (!validateTransition(intent.status, "BANK_LINKED")) {
      return {
        status: intent.status as any,
        failureReason: `Cannot link bank account: invalid status transition from ${intent.status}`,
      };
    }

    const maskedAccount = maskAccountNumber(bankDetails.accountNumber);

    const achMeta: AchMetadata = {
      achBankVerificationStatus: "pending_micro_deposits",
      achBankDetails: {
        routingNumber: bankDetails.routingNumber,
        accountNumber: maskedAccount,
        accountType: bankDetails.accountType,
        accountHolderName: bankDetails.accountHolderName,
        bankName: bankDetails.bankName || "US Bank Account",
      },
    };

    return {
      providerIntentId: intent.providerIntentId || `ach_${intent.id}`,
      status: "CREATED",
      providerResponse: {
        message: `Bank account linked (${maskedAccount}). Micro-deposits will be sent for verification.`,
        achMetadata: achMeta,
        bankVerificationStatus: "pending_micro_deposits",
        estimatedVerificationTime: "1-2 business days",
      },
    };
  }

  async verifyBankAccount(
    intent: PaymentIntent,
    _microDepositAmounts?: [number, number]
  ): Promise<PaymentProviderResult> {
    const existingMeta = (intent.providerResponse as any)?.achMetadata as AchMetadata | undefined;

    if (!existingMeta || existingMeta.achBankVerificationStatus !== "pending_micro_deposits") {
      return {
        status: intent.status as any,
        failureReason: "Bank account must be in pending_micro_deposits status to verify",
      };
    }

    const updatedMeta: AchMetadata = {
      ...existingMeta,
      achBankVerificationStatus: "verified",
    };

    return {
      providerIntentId: intent.providerIntentId || `ach_${intent.id}`,
      status: "CREATED",
      providerResponse: {
        message: "Bank account verified successfully. Ready to initiate ACH transfer.",
        achMetadata: updatedMeta,
        bankVerificationStatus: "verified",
      },
    };
  }

  async initiateTransfer(intent: PaymentIntent): Promise<PaymentProviderResult> {
    const existingMeta = (intent.providerResponse as any)?.achMetadata as AchMetadata | undefined;

    if (!existingMeta || existingMeta.achBankVerificationStatus !== "verified") {
      return {
        status: intent.status as any,
        failureReason: "Bank account must be verified before initiating transfer",
      };
    }

    const updatedMeta: AchMetadata = {
      ...existingMeta,
      achTransferId: `ach_txn_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      achInitiatedAt: new Date().toISOString(),
    };

    return {
      providerIntentId: intent.providerIntentId || `ach_${intent.id}`,
      status: "PENDING",
      providerResponse: {
        message: "ACH transfer initiated. Processing will take 2-3 business days.",
        achMetadata: updatedMeta,
        achTransferId: updatedMeta.achTransferId,
        estimatedSettlement: "2-3 business days",
      },
    };
  }

  async confirmIntent(
    intent: PaymentIntent,
    data?: Record<string, any>
  ): Promise<PaymentProviderResult> {
    const existingMeta = (intent.providerResponse as any)?.achMetadata as AchMetadata | undefined;

    const updatedMeta: AchMetadata = {
      ...(existingMeta || { achBankVerificationStatus: "verified" }),
      achCompletedAt: new Date().toISOString(),
      achSettlementDate: new Date().toISOString().split("T")[0],
    };

    return {
      providerIntentId: intent.providerIntentId || `ach_${intent.id}`,
      status: "CONFIRMED",
      providerResponse: {
        confirmedBy: data?.confirmedBy || "admin",
        reconciliationId: data?.reconciliationId,
        achMetadata: updatedMeta,
        provider: "ach",
        settlementDate: updatedMeta.achSettlementDate,
        ...data,
      },
    };
  }

  async confirmWebhook(intent: PaymentIntent, payload: WebhookPayload): Promise<PaymentProviderResult> {
    const achData = payload.body;
    const existingMeta = (intent.providerResponse as any)?.achMetadata as AchMetadata | undefined;

    const updatedMeta: AchMetadata = {
      ...(existingMeta || { achBankVerificationStatus: "verified" }),
      achCompletedAt: new Date().toISOString(),
      achSettlementDate: new Date().toISOString().split("T")[0],
    };

    return {
      providerIntentId: intent.providerIntentId || `ach_${intent.id}`,
      status: "CONFIRMED",
      providerResponse: {
        confirmedVia: "ach_webhook",
        achMetadata: updatedMeta,
        webhookData: achData,
      },
    };
  }

  async cancelIntent(intent: PaymentIntent): Promise<PaymentProviderResult> {
    return {
      providerIntentId: intent.providerIntentId || `ach_${intent.id}`,
      status: "FAILED",
      failureReason: "ACH transfer cancelled",
    };
  }

  async reverse(intent: PaymentIntent, reason?: string): Promise<PaymentProviderResult> {
    const existingMeta = (intent.providerResponse as any)?.achMetadata as AchMetadata | undefined;

    const updatedMeta: AchMetadata = {
      ...(existingMeta || { achBankVerificationStatus: "verified" }),
      achReturnCode: "R06",
      achReturnReason: reason || "Reversed per ODFI request",
    };

    return {
      providerIntentId: intent.providerIntentId || `ach_${intent.id}`,
      status: "REVERSED",
      providerResponse: {
        achMetadata: updatedMeta,
        reason: reason || "ACH reversal",
        reversedAt: new Date().toISOString(),
      },
    };
  }

  async returnTransfer(
    intent: PaymentIntent,
    returnCode: string,
    returnReason: string
  ): Promise<PaymentProviderResult> {
    const existingMeta = (intent.providerResponse as any)?.achMetadata as AchMetadata | undefined;

    const updatedMeta: AchMetadata = {
      ...(existingMeta || { achBankVerificationStatus: "verified" }),
      achReturnCode: returnCode,
      achReturnReason: returnReason,
    };

    return {
      providerIntentId: intent.providerIntentId || `ach_${intent.id}`,
      status: "FAILED",
      failureReason: `ACH return: ${returnCode} - ${returnReason}`,
      providerResponse: {
        achMetadata: updatedMeta,
        returnCode,
        returnReason,
      },
    };
  }

  async getStatus(intent: PaymentIntent): Promise<PaymentProviderResult> {
    const existingMeta = (intent.providerResponse as any)?.achMetadata as AchMetadata | undefined;

    return {
      providerIntentId: intent.providerIntentId || `ach_${intent.id}`,
      status: intent.status as any,
      providerResponse: {
        achMetadata: existingMeta || { achBankVerificationStatus: "not_started" },
        currentStatus: intent.status,
      },
    };
  }
}

export const achProvider = new AchPaymentProvider();

export const ACH_RETURN_CODES: Record<string, string> = {
  R01: "Insufficient Funds",
  R02: "Account Closed",
  R03: "No Account/Unable to Locate",
  R04: "Invalid Account Number",
  R05: "Unauthorized Debit",
  R06: "Returned per ODFI Request",
  R07: "Authorization Revoked by Customer",
  R08: "Payment Stopped",
  R09: "Uncollected Funds",
  R10: "Customer Advises Not Authorized",
  R16: "Account Frozen",
  R20: "Non-Transaction Account",
  R29: "Corporate Customer Advises Not Authorized",
};
