import type { PaymentIntent, PaymentIntentStatus } from "@shared/schema";
import { StripePaymentProvider } from "./services/payments/providers/stripe";
import {
  jazzCashProvider,
  easypaisaProvider,
  raastProvider,
  tapTapSendProvider,
  pkInternationalWireProvider,
} from "./services/payments/providers/pakistan";
import { achProvider } from "./services/payments/providers/ach";

export interface PaymentProviderResult {
  providerIntentId?: string;
  sessionUrl?: string;
  providerResponse?: Record<string, any>;
  status: PaymentIntentStatus;
  failureReason?: string;
}

export interface WebhookPayload {
  headers: Record<string, string>;
  body: any;
  rawBody?: Buffer;
}

export interface PaymentProvider {
  name: string;
  createIntent(intent: PaymentIntent): Promise<PaymentProviderResult>;
  confirmIntent(intent: PaymentIntent, data?: Record<string, any>): Promise<PaymentProviderResult>;
  confirmWebhook(intent: PaymentIntent, payload: WebhookPayload): Promise<PaymentProviderResult>;
  cancelIntent(intent: PaymentIntent): Promise<PaymentProviderResult>;
  reverse(intent: PaymentIntent, reason?: string): Promise<PaymentProviderResult>;
  getStatus(intent: PaymentIntent): Promise<PaymentProviderResult>;
}

export class ManualPaymentProvider implements PaymentProvider {
  name = "manual";

  async createIntent(intent: PaymentIntent): Promise<PaymentProviderResult> {
    return {
      providerIntentId: `manual_${intent.id}`,
      status: "CREATED",
      providerResponse: {
        message: "Manual payment intent created. Awaiting admin confirmation.",
        instructions: `Transfer ${intent.currency} ${intent.amount} using reference: PI-${intent.id.slice(0, 8).toUpperCase()}`,
      },
    };
  }

  async confirmIntent(intent: PaymentIntent, data?: Record<string, any>): Promise<PaymentProviderResult> {
    return {
      providerIntentId: intent.providerIntentId || `manual_${intent.id}`,
      status: "CONFIRMED",
      providerResponse: {
        confirmedBy: data?.confirmedBy || "admin",
        reconciliationId: data?.reconciliationId,
        ...data,
      },
    };
  }

  async confirmWebhook(intent: PaymentIntent, _payload: WebhookPayload): Promise<PaymentProviderResult> {
    return {
      providerIntentId: intent.providerIntentId || `manual_${intent.id}`,
      status: "CONFIRMED",
      providerResponse: {
        confirmedVia: "webhook",
      },
    };
  }

  async cancelIntent(intent: PaymentIntent): Promise<PaymentProviderResult> {
    return {
      providerIntentId: intent.providerIntentId || `manual_${intent.id}`,
      status: "FAILED",
      failureReason: "Cancelled by admin",
    };
  }

  async reverse(intent: PaymentIntent, reason?: string): Promise<PaymentProviderResult> {
    return {
      providerIntentId: intent.providerIntentId || `manual_${intent.id}`,
      status: "REVERSED",
      providerResponse: {
        reversedAt: new Date().toISOString(),
        reason: reason || "Manual reversal",
      },
    };
  }

  async getStatus(intent: PaymentIntent): Promise<PaymentProviderResult> {
    return {
      providerIntentId: intent.providerIntentId || `manual_${intent.id}`,
      status: intent.status as PaymentIntentStatus,
    };
  }
}

const providers: Record<string, PaymentProvider> = {
  manual: new ManualPaymentProvider(),
  stripe: new StripePaymentProvider(),
  jazzcash: jazzCashProvider,
  easypaisa: easypaisaProvider,
  raast: raastProvider,
  taptap_send: tapTapSendProvider,
  pk_international_wire: pkInternationalWireProvider,
  ach: achProvider,
};

export function getPaymentProvider(name: string): PaymentProvider {
  const provider = providers[name];
  if (!provider) {
    throw new Error(`Payment provider "${name}" not found. Available: ${Object.keys(providers).join(", ")}`);
  }
  return provider;
}

export function registerPaymentProvider(provider: PaymentProvider): void {
  providers[provider.name] = provider;
}
