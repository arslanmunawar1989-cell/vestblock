import { db } from "./db";
import {
  cmsPages,
  cmsGlobalContent,
  cmsPropertyListings,
  cmsBlogPosts,
  cmsFaqItems,
  cmsGlossaryTerms,
  cmsFeeConfigs,
  cmsExitWindowSchedules,
  users,
  tenantUsers,
} from "@shared/schema";
import { log } from "./index";
import { hashPassword } from "./auth";
import { PLATFORM_TENANT_ID } from "@shared/constants";
import { eq } from "drizzle-orm";

export async function seedCmsData() {
  const existingCmsUser = await db.select().from(users).where(eq(users.username, "cms_manager"));
  if (existingCmsUser.length === 0) {
    const cmsHash = await hashPassword("password123");
    const [cmsUser] = await db.insert(users).values({
      username: "cms_manager",
      password: cmsHash,
      email: "cms@vestblock.io",
      fullName: "Website Manager",
      role: "cms",
      kycStatus: "verified",
      tenantId: PLATFORM_TENANT_ID,
    }).returning();
    await db.insert(tenantUsers).values({ tenantId: PLATFORM_TENANT_ID, userId: cmsUser.id, role: "TENANT_ADMIN" });
    log("CMS manager user created (cms_manager / password123)");
  }

  const existing = await db.select().from(cmsPages);
  if (existing.length > 0) {
    log("CMS data already seeded, skipping");
    return;
  }

  log("Seeding CMS data...");

  const pkPageSlugs = [
    "home", "about", "properties", "how-it-works", "tokenization", "pricing",
    "compliance", "faq", "blog", "contact", "careers", "partners", "press",
    "invest", "pakistan", "institutions", "fees", "mobile-app",
  ];

  const aePageSlugs = [
    "home", "about", "properties", "how-it-works", "tokenization", "pricing",
    "compliance", "faq",
  ];

  await db.insert(cmsPages).values(
    pkPageSlugs.map((slug) => ({
      region: "PK",
      slug,
      title: slug.split("-").map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" "),
      status: "PUBLISHED",
    }))
  );

  await db.insert(cmsPages).values(
    aePageSlugs.map((slug) => ({
      region: "AE",
      slug,
      title: slug.split("-").map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" "),
      status: "PUBLISHED",
    }))
  );

  await db.insert(cmsGlobalContent).values([
    {
      region: "PK",
      contentKey: "navbar_links",
      contentJson: {
        items: [
          { label: "Properties", href: "/properties" },
          { label: "How It Works", href: "/how-it-works" },
          { label: "Tokenization", href: "/tokenization" },
          { label: "Pricing", href: "/pricing" },
          { label: "Blog", href: "/blog" },
          { label: "FAQ", href: "/faq" },
          { label: "Contact", href: "/contact" },
        ],
      },
    },
    {
      region: "AE",
      contentKey: "navbar_links",
      contentJson: {
        items: [
          { label: "Properties", href: "/properties" },
          { label: "How It Works", href: "/how-it-works" },
          { label: "Tokenization", href: "/tokenization" },
          { label: "Pricing", href: "/pricing" },
          { label: "FAQ", href: "/faq" },
        ],
      },
    },
    {
      region: "PK",
      contentKey: "footer_links",
      contentJson: {
        columns: [
          {
            title: "Invest",
            links: [
              { label: "Properties", href: "/properties" },
              { label: "How It Works", href: "/how-it-works" },
              { label: "Pricing", href: "/pricing" },
              { label: "Fees", href: "/fees" },
            ],
          },
          {
            title: "Learn",
            links: [
              { label: "Blog", href: "/blog" },
              { label: "FAQ", href: "/faq" },
              { label: "Tokenization", href: "/tokenization" },
              { label: "Glossary", href: "/glossary" },
            ],
          },
          {
            title: "Company",
            links: [
              { label: "About", href: "/about" },
              { label: "Careers", href: "/careers" },
              { label: "Partners", href: "/partners" },
              { label: "Press", href: "/press" },
              { label: "Contact", href: "/contact" },
            ],
          },
          {
            title: "Legal",
            links: [
              { label: "Compliance", href: "/compliance" },
              { label: "Terms of Service", href: "/terms" },
              { label: "Privacy Policy", href: "/privacy" },
              { label: "Risk Disclosure", href: "/risk-disclosure" },
            ],
          },
        ],
      },
    },
    {
      region: "AE",
      contentKey: "footer_links",
      contentJson: {
        columns: [
          {
            title: "Invest",
            links: [
              { label: "Properties", href: "/properties" },
              { label: "How It Works", href: "/how-it-works" },
              { label: "Pricing", href: "/pricing" },
            ],
          },
          {
            title: "Learn",
            links: [
              { label: "FAQ", href: "/faq" },
              { label: "Tokenization", href: "/tokenization" },
            ],
          },
          {
            title: "Legal",
            links: [
              { label: "Compliance", href: "/compliance" },
              { label: "Terms of Service", href: "/terms" },
              { label: "Privacy Policy", href: "/privacy" },
            ],
          },
        ],
      },
    },
    {
      region: "PK",
      contentKey: "legal_disclaimer",
      contentJson: {
        text: "VestBlock is a technology platform that facilitates fractional real estate investment. All investments carry risk. Past performance does not guarantee future results. Please read the Risk Disclosure and Terms of Service before investing. VestBlock does not provide financial advice. Consult a qualified financial advisor before making investment decisions. Securities offered through SPV structures registered with SECP.",
      },
    },
    {
      region: "AE",
      contentKey: "legal_disclaimer",
      contentJson: {
        text: "VestBlock is a technology platform that facilitates fractional real estate investment. All investments carry risk. Past performance does not guarantee future results. Securities offered through SPV structures regulated by DFSA/FSRA. This platform is not available to residents of restricted jurisdictions.",
      },
    },
  ]);

  await db.insert(cmsPropertyListings).values([
    {
      region: "PK",
      slug: "karachi-skyline-tower",
      name: "Skyline Tower Residency",
      city: "Karachi",
      country: "PK",
      propertyType: "Commercial",
      strategy: "Income",
      minInvestment: "75000",
      currency: "PKR",
      expectedYield: "14.2",
      fundingTarget: "250000000",
      fundingProgressPercent: 74,
      status: "LIVE",
      shortDescription: "Premium commercial tower in Clifton, Karachi with strong rental yields.",
    },
    {
      region: "PK",
      slug: "lahore-pearl-villas",
      name: "Pearl Gate Villas",
      city: "Lahore",
      country: "PK",
      propertyType: "Residential",
      strategy: "Growth",
      minInvestment: "50000",
      currency: "PKR",
      expectedYield: "11.8",
      fundingTarget: "150000000",
      fundingProgressPercent: 80,
      status: "LIVE",
      shortDescription: "Luxury residential villas in DHA Phase 6, Lahore.",
    },
    {
      region: "PK",
      slug: "islamabad-capitol-heights",
      name: "Capitol Heights",
      city: "Islamabad",
      country: "PK",
      propertyType: "Mixed-Use",
      strategy: "Income",
      minInvestment: "100000",
      currency: "PKR",
      expectedYield: "16.5",
      fundingTarget: "400000000",
      fundingProgressPercent: 85,
      status: "LIVE",
      shortDescription: "Mixed-use development in Blue Area, Islamabad.",
    },
    {
      region: "PK",
      slug: "karachi-ocean-mall",
      name: "Ocean Mall Extension",
      city: "Karachi",
      country: "PK",
      propertyType: "Retail",
      strategy: "Income",
      minInvestment: "50000",
      currency: "PKR",
      expectedYield: "18.3",
      fundingTarget: "200000000",
      fundingProgressPercent: 48,
      status: "LIVE",
      shortDescription: "Retail extension at Clifton Block 9, Karachi.",
    },
    {
      region: "PK",
      slug: "faisalabad-textile-hub",
      name: "Textile Hub Complex",
      city: "Faisalabad",
      country: "PK",
      propertyType: "Industrial",
      strategy: "Income",
      minInvestment: "25000",
      currency: "PKR",
      expectedYield: "21.4",
      fundingTarget: "80000000",
      fundingProgressPercent: 75,
      status: "LIVE",
      shortDescription: "Industrial textile complex in M-2 Industrial Zone, Faisalabad.",
    },
    {
      region: "PK",
      slug: "lahore-gulberg-plaza",
      name: "Gulberg III Business Plaza",
      city: "Lahore",
      country: "PK",
      propertyType: "Commercial",
      strategy: "Income",
      minInvestment: "100000",
      currency: "PKR",
      expectedYield: "19.8",
      fundingTarget: "620000000",
      fundingProgressPercent: 68,
      status: "LIVE",
      shortDescription: "Prime commercial plaza in Gulberg III, Lahore.",
    },
    {
      region: "PK",
      slug: "islamabad-f7-residences",
      name: "F-7 Executive Residences",
      city: "Islamabad",
      country: "PK",
      propertyType: "Residential",
      strategy: "Growth",
      minInvestment: "200000",
      currency: "PKR",
      expectedYield: "12.4",
      fundingTarget: "350000000",
      fundingProgressPercent: 51,
      status: "LIVE",
      shortDescription: "Luxury executive residences in F-7/2, Islamabad.",
    },
    {
      region: "PK",
      slug: "karachi-korangi-warehouse",
      name: "Korangi Logistics Park",
      city: "Karachi",
      country: "PK",
      propertyType: "Industrial",
      strategy: "Income",
      minInvestment: "25000",
      currency: "PKR",
      expectedYield: "22.1",
      fundingTarget: "120000000",
      fundingProgressPercent: 38,
      status: "LIVE",
      shortDescription: "Modern logistics park in Korangi Industrial Area, Karachi.",
    },
    {
      region: "PK",
      slug: "lahore-dha-apartments",
      name: "DHA Phase 8 Luxury Apartments",
      city: "Lahore",
      country: "PK",
      propertyType: "Residential",
      strategy: "Growth",
      minInvestment: "75000",
      currency: "PKR",
      expectedYield: "13.6",
      fundingTarget: "300000000",
      fundingProgressPercent: 93,
      status: "LIVE",
      shortDescription: "Premium apartments in DHA Phase 8, Lahore.",
    },
  ]);

  await db.insert(cmsBlogPosts).values([
    {
      region: "PK",
      slug: "rental-yield-explained-pakistan",
      title: "Rental Yield Explained in Pakistan",
      excerpt: "Understanding gross vs net yield, typical ranges by city, and how tokenized ownership changes the math.",
      category: "Education",
      status: "PUBLISHED",
      publishedAt: "2026-01-28",
    },
    {
      region: "PK",
      slug: "how-exit-windows-work",
      title: "How Exit Windows Work",
      excerpt: "A complete guide to VestBlock's structured liquidity model — when you can sell, how pricing works, and what to expect.",
      category: "Education",
      status: "PUBLISHED",
      publishedAt: "2026-01-20",
    },
    {
      region: "PK",
      slug: "tokenized-ownership-vs-traditional-property",
      title: "Tokenized Ownership vs Traditional Property",
      excerpt: "A side-by-side comparison of buying property the traditional way versus investing through tokenized fractional ownership.",
      category: "Education",
      status: "PUBLISHED",
      publishedAt: "2026-01-12",
    },
    {
      region: "PK",
      slug: "fees-and-costs-breakdown",
      title: "Fees & Costs Breakdown",
      excerpt: "Every fee, every charge, fully explained — no surprises. Here is exactly what investing through VestBlock costs.",
      category: "Education",
      status: "PUBLISHED",
      publishedAt: "2026-01-05",
    },
    {
      region: "PK",
      slug: "risk-warnings-real-estate-tokenization",
      title: "Risk Warnings: What Every Investor Should Know",
      excerpt: "An honest assessment of the risks involved in tokenized real estate investment. Read before you invest.",
      category: "Risk & Compliance",
      status: "PUBLISHED",
      publishedAt: "2025-12-28",
    },
    {
      region: "PK",
      slug: "understanding-spv-structure-pakistan",
      title: "Understanding SPV Structures in Pakistani Real Estate",
      excerpt: "What is a Special Purpose Vehicle, why VestBlock uses them, and how they protect your investment.",
      category: "Education",
      status: "PUBLISHED",
      publishedAt: "2025-12-20",
    },
  ]);

  await db.insert(cmsFaqItems).values([
    {
      region: "PK",
      question: "What is VestBlock?",
      answer: "VestBlock is a technology platform that enables fractional real estate investment through tokenization. It allows investors to own a share of premium properties starting from as low as PKR 25,000, with professional management and transparent reporting.",
      category: "General",
      orderIndex: 1,
      isEnabled: true,
    },
    {
      region: "PK",
      question: "How does fractional real estate investment work?",
      answer: "Each property is held by a Special Purpose Vehicle (SPV). The SPV issues digital tokens representing fractional ownership. When you purchase tokens, you acquire a proportional beneficial interest in the property through the SPV, entitling you to rental distributions and capital appreciation.",
      category: "General",
      orderIndex: 2,
      isEnabled: true,
    },
    {
      region: "PK",
      question: "What is the minimum investment amount?",
      answer: "The minimum investment varies by property, starting from as low as PKR 25,000. Each property listing page shows its specific minimum investment requirement.",
      category: "Investment",
      orderIndex: 3,
      isEnabled: true,
    },
    {
      region: "PK",
      question: "How are returns distributed?",
      answer: "Rental income is collected by the property management team, deducted for operating expenses and management fees, and distributed to token holders proportionally. Distributions are typically made monthly or quarterly depending on the property, and credited directly to your VestBlock wallet.",
      category: "Investment",
      orderIndex: 4,
      isEnabled: true,
    },
    {
      region: "PK",
      question: "What are exit windows?",
      answer: "Exit windows are structured periods (typically twice per year, in June and December) during which you can sell your tokens on VestBlock's internal secondary marketplace. Tokens are priced at the current Net Asset Value (NAV) determined by independent property valuation.",
      category: "Investment",
      orderIndex: 5,
      isEnabled: true,
    },
    {
      region: "PK",
      question: "How does KYC verification work?",
      answer: "KYC (Know Your Customer) verification is required before you can invest. You will need to provide your CNIC or passport, proof of address, and source of funds information. The verification process is completed online and typically takes 1-3 business days.",
      category: "General",
      orderIndex: 6,
      isEnabled: true,
    },
    {
      region: "PK",
      question: "What fees does VestBlock charge?",
      answer: "VestBlock charges an entry fee (up to 1%), annual management fee (1-2%), and exit fee (0.5-1%). There may also be FX conversion fees for cross-currency transactions (0.5-1.5%). All fees are fully disclosed before any transaction. Visit the Fees page for the complete schedule.",
      category: "Fees",
      orderIndex: 7,
      isEnabled: true,
    },
    {
      region: "PK",
      question: "Is my investment secure?",
      answer: "Each property is held in a legally separate SPV, providing asset isolation and bankruptcy remoteness from VestBlock's corporate operations. However, all investments carry risk including market risk, liquidity risk, and income risk. Your capital is at risk and you may receive back less than you invested.",
      category: "Legal",
      orderIndex: 8,
      isEnabled: true,
    },
    {
      region: "PK",
      question: "What is a Special Purpose Vehicle (SPV)?",
      answer: "An SPV is a legal entity (typically a private limited company registered with SECP) created specifically to hold a single property. This structure isolates each property legally, ensuring that issues with one property do not affect others. Token holders are beneficial owners of the SPV.",
      category: "Legal",
      orderIndex: 9,
      isEnabled: true,
    },
    {
      region: "PK",
      question: "Can I invest from outside Pakistan?",
      answer: "VestBlock supports international investors subject to KYC/AML compliance and local regulatory requirements. Non-resident Pakistanis and certain foreign nationals may invest, though eligibility depends on your country of residence and applicable regulations.",
      category: "General",
      orderIndex: 10,
      isEnabled: true,
    },
    {
      region: "PK",
      question: "What currencies are supported?",
      answer: "VestBlock currently supports PKR (Pakistani Rupee), AED (UAE Dirham), USD (US Dollar), and GBP (British Pound). You can hold wallet balances in multiple currencies and convert between them at competitive FX rates.",
      category: "General",
      orderIndex: 11,
      isEnabled: true,
    },
    {
      region: "PK",
      question: "How is property valuation determined?",
      answer: "Property valuations are conducted by independent certified surveyors based on comparable market sales, rental income, occupancy rates, property condition, and local market trends. Valuations are updated periodically and used to calculate the Net Asset Value (NAV) per token.",
      category: "Investment",
      orderIndex: 12,
      isEnabled: true,
    },
    {
      region: "PK",
      question: "What happens if a tenant doesn't pay rent?",
      answer: "VestBlock's property management team handles tenant relations including rent collection and enforcement. If a tenant defaults, the team pursues legal remedies. During vacancy or default periods, distributions for the affected property may be reduced or suspended. Diversification across multiple properties helps mitigate this risk.",
      category: "Investment",
      orderIndex: 13,
      isEnabled: true,
    },
    {
      region: "PK",
      question: "Can I sell my tokens at any time?",
      answer: "No. Tokenized real estate is not a liquid investment. You can sell your tokens during structured exit windows (typically twice per year). There is no guarantee that a buyer will be found during any given window. You should be prepared to hold your investment for the full property lifecycle.",
      category: "Investment",
      orderIndex: 14,
      isEnabled: true,
    },
    {
      region: "PK",
      question: "What is the expected holding period?",
      answer: "The recommended holding period varies by property, typically ranging from 3 to 7 years. Each property listing specifies its projected holding period. Early exits may incur additional fees if made before the lockup period expires.",
      category: "Investment",
      orderIndex: 15,
      isEnabled: true,
    },
  ]);

  await db.insert(cmsFeeConfigs).values([
    {
      region: "PK",
      name: "Platform Fee",
      valueType: "PERCENT",
      value: "2.0",
      description: "Annual platform fee charged on invested capital for platform operations and technology.",
      isEnabled: true,
    },
    {
      region: "PK",
      name: "Entry Fee",
      valueType: "PERCENT",
      value: "1.0",
      description: "One-time fee applied at the time of token purchase.",
      isEnabled: true,
    },
    {
      region: "PK",
      name: "Exit Fee",
      valueType: "PERCENT",
      value: "0.5",
      description: "Fee applied to gross proceeds when selling tokens during an exit window.",
      isEnabled: true,
    },
    {
      region: "PK",
      name: "Management Fee",
      valueType: "PERCENT",
      value: "1.5",
      description: "Annual fee covering property management, tenant relations, maintenance, and reporting.",
      isEnabled: true,
    },
    {
      region: "PK",
      name: "Early Exit Penalty",
      valueType: "PERCENT",
      value: "2.0",
      description: "Additional fee if exiting before the property lockup period has elapsed.",
      isEnabled: true,
    },
    {
      region: "PK",
      name: "FX Conversion Fee",
      valueType: "PERCENT",
      value: "0.75",
      description: "Fee applied when converting between currencies (PKR/AED/USD/GBP).",
      isEnabled: true,
    },
  ]);

  await db.insert(cmsExitWindowSchedules).values([
    {
      region: "PK",
      name: "June 2026 Window",
      opensAt: "2026-06-01",
      closesAt: "2026-06-30",
      settlementDays: 10,
      notes: "First exit window of 2026. Submit exit requests by May 15, 2026.",
      isEnabled: true,
    },
    {
      region: "PK",
      name: "December 2026 Window",
      opensAt: "2026-12-01",
      closesAt: "2026-12-31",
      settlementDays: 10,
      notes: "Second exit window of 2026. Submit exit requests by November 15, 2026.",
      isEnabled: true,
    },
  ]);

  await db.insert(cmsGlossaryTerms).values([
    {
      region: "PK",
      term: "NAV (Net Asset Value)",
      definition: "The total value of a property minus liabilities, divided by the number of tokens. NAV per token represents the fair value of each token based on independent property valuation.",
      category: "Valuation",
      orderIndex: 1,
    },
    {
      region: "PK",
      term: "SPV (Special Purpose Vehicle)",
      definition: "A legal entity created specifically to hold a single property asset. Each VestBlock property is held by its own SPV registered with SECP, providing asset isolation and bankruptcy remoteness.",
      category: "Legal",
      orderIndex: 2,
    },
    {
      region: "PK",
      term: "Token",
      definition: "A digital representation of fractional ownership in a property SPV. Each token entitles the holder to a proportional share of rental distributions and capital appreciation.",
      category: "General",
      orderIndex: 3,
    },
    {
      region: "PK",
      term: "Fractional Ownership",
      definition: "A method of property investment where multiple investors each own a percentage of a property through tokenized shares, lowering the barrier to entry for real estate investment.",
      category: "General",
      orderIndex: 4,
    },
    {
      region: "PK",
      term: "Yield",
      definition: "The annual return on an investment expressed as a percentage. In real estate, yield typically refers to rental income as a percentage of property value. Gross yield excludes expenses; net yield includes them.",
      category: "Valuation",
      orderIndex: 5,
    },
    {
      region: "PK",
      term: "Distribution",
      definition: "A payment of rental income to token holders, proportional to their ownership stake. Distributions are made after deducting operating expenses and management fees.",
      category: "Investment",
      orderIndex: 6,
    },
    {
      region: "PK",
      term: "Exit Window",
      definition: "A structured period during which token holders can sell their tokens on VestBlock's internal secondary marketplace. Exit windows typically occur twice per year.",
      category: "Investment",
      orderIndex: 7,
    },
    {
      region: "PK",
      term: "KYC (Know Your Customer)",
      definition: "The identity verification process required before investing. KYC ensures compliance with anti-money laundering regulations and involves providing identification documents and source of funds information.",
      category: "Compliance",
      orderIndex: 8,
    },
    {
      region: "PK",
      term: "AML (Anti-Money Laundering)",
      definition: "Regulations and procedures designed to prevent the use of financial systems for money laundering. VestBlock conducts AML screening as part of the KYC process for all investors.",
      category: "Compliance",
      orderIndex: 9,
    },
    {
      region: "PK",
      term: "Hurdle Rate",
      definition: "The minimum rate of return that must be achieved before performance fees are charged. If actual returns exceed the hurdle rate, performance fees apply only to the excess return above the hurdle.",
      category: "Fees",
      orderIndex: 10,
    },
  ]);

  log("CMS data seeded successfully");
}
