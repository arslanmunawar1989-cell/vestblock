type LogLevel = "debug" | "info" | "warn" | "error";

const LOG_LEVELS: Record<LogLevel, number> = {
  debug: 0,
  info: 1,
  warn: 2,
  error: 3,
};

const currentLevel: LogLevel = (process.env.LOG_LEVEL as LogLevel) || "info";

interface LogEntry {
  timestamp: string;
  level: LogLevel;
  message: string;
  source?: string;
  requestId?: string;
  userId?: string;
  method?: string;
  path?: string;
  statusCode?: number;
  durationMs?: number;
  error?: string;
  stack?: string;
  [key: string]: unknown;
}

function shouldLog(level: LogLevel): boolean {
  return LOG_LEVELS[level] >= LOG_LEVELS[currentLevel];
}

function emit(entry: LogEntry) {
  const clean: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(entry)) {
    if (v !== undefined && v !== null && v !== "") clean[k] = v;
  }

  if (entry.level === "error") {
    console.error(JSON.stringify(clean));
  } else if (entry.level === "warn") {
    console.warn(JSON.stringify(clean));
  } else {
    console.log(JSON.stringify(clean));
  }
}

function createEntry(level: LogLevel, message: string, meta?: Record<string, unknown>): LogEntry {
  return {
    timestamp: new Date().toISOString(),
    level,
    message,
    ...meta,
  };
}

export const logger = {
  debug(message: string, meta?: Record<string, unknown>) {
    if (shouldLog("debug")) emit(createEntry("debug", message, meta));
  },
  info(message: string, meta?: Record<string, unknown>) {
    if (shouldLog("info")) emit(createEntry("info", message, meta));
  },
  warn(message: string, meta?: Record<string, unknown>) {
    if (shouldLog("warn")) emit(createEntry("warn", message, meta));
  },
  error(message: string, meta?: Record<string, unknown>) {
    if (shouldLog("error")) emit(createEntry("error", message, meta));
  },
  http(meta: {
    method: string;
    path: string;
    statusCode: number;
    durationMs: number;
    userId?: string;
    requestId?: string;
  }) {
    if (shouldLog("info")) {
      emit(createEntry("info", `${meta.method} ${meta.path} ${meta.statusCode} ${meta.durationMs}ms`, {
        source: "http",
        ...meta,
      }));
    }
  },
};

let requestCounter = 0;
export function generateRequestId(): string {
  requestCounter += 1;
  return `req_${Date.now()}_${requestCounter}`;
}
