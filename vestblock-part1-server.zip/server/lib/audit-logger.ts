import type { Request } from "express";
import { storage } from "../storage";
import type { InsertAuditLog } from "@shared/schema";

export interface AuditContext {
  actorId: string;
  actorRole?: string;
  ipAddress?: string;
  userAgent?: string;
}

export function getAuditContext(req: Request): AuditContext {
  const user = (req as any).user;
  return {
    actorId: user?.userId || "system",
    actorRole: user?.role || undefined,
    ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
    userAgent: req.headers["user-agent"] || undefined,
  };
}

export async function logAudit(params: {
  actorId: string;
  actorRole?: string;
  actionType: string;
  entityType: string;
  entityId?: string;
  reason?: string;
  beforeState?: any;
  afterState?: any;
  metadata?: any;
  ipAddress?: string;
  userAgent?: string;
}) {
  try {
    const data: InsertAuditLog = {
      actorId: params.actorId,
      actorRole: params.actorRole || null,
      actionType: params.actionType,
      entityType: params.entityType,
      entityId: params.entityId || null,
      reason: params.reason || null,
      beforeState: params.beforeState || null,
      afterState: params.afterState || null,
      metadata: params.metadata || null,
      ipAddress: params.ipAddress || null,
      userAgent: params.userAgent || null,
    };
    await storage.createAuditLog(data);
  } catch (err) {
    console.error("Audit log write failed:", err);
  }
}

export async function logAuditFromReq(
  req: Request,
  actionType: string,
  entityType: string,
  entityId?: string,
  opts?: {
    reason?: string;
    beforeState?: any;
    afterState?: any;
    metadata?: any;
  }
) {
  const ctx = getAuditContext(req);
  return logAudit({
    ...ctx,
    actionType,
    entityType,
    entityId,
    reason: opts?.reason,
    beforeState: opts?.beforeState,
    afterState: opts?.afterState,
    metadata: opts?.metadata,
  });
}
