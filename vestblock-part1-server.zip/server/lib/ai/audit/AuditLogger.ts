import { db } from "../../../db";
import { aiInteractionLogs } from "@shared/schema";

export type AiFeature = "ASK_RAG" | "ADT_SUMMARY" | "ROI_EXPLAIN" | "RECOMMENDER" | "MARKET_PULSE";

interface LogEntry {
  userId?: string | null;
  feature: AiFeature;
  prompt: string;
  response: string;
  sourcesJson?: unknown;
  tokensEstimated?: number;
}

export async function logAiInteraction(entry: LogEntry): Promise<void> {
  try {
    await db.insert(aiInteractionLogs).values({
      userId: entry.userId ?? null,
      feature: entry.feature,
      prompt: entry.prompt,
      response: entry.response,
      sourcesJson: entry.sourcesJson ?? null,
      tokensEstimated: entry.tokensEstimated ?? null,
    });
  } catch (err) {
    console.error("[AuditLogger] Failed to log AI interaction:", err);
  }
}
