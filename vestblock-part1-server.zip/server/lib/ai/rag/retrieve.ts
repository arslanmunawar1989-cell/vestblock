import { db } from "../../../db";
import { contentChunks, contentSources } from "@shared/schema";
import { eq } from "drizzle-orm";
import { openAIProvider } from "../providers/OpenAIProvider";

export interface RetrievedChunk {
  chunkText: string;
  score: number;
  sourceId: string;
  sourceTitle: string;
  sourceSlug: string;
  sourceType: string;
}

function cosineSimilarity(a: number[], b: number[]): number {
  if (a.length !== b.length) return 0;
  let dot = 0, magA = 0, magB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }
  const denom = Math.sqrt(magA) * Math.sqrt(magB);
  return denom === 0 ? 0 : dot / denom;
}

export async function retrieveChunks(
  query: string,
  topK: number = 8,
  region?: string
): Promise<RetrievedChunk[]> {
  const { embedding: queryEmbedding } = await openAIProvider.embed(query);

  const allChunks = await db.select().from(contentChunks);
  const sourceIds = [...new Set(allChunks.map((c) => c.sourceId))];
  const sources = await db.select().from(contentSources);
  const sourceMap = new Map(sources.map((s) => [s.id, s]));

  const scored: RetrievedChunk[] = [];
  for (const chunk of allChunks) {
    const source = sourceMap.get(chunk.sourceId);
    if (!source) continue;
    if (region && source.region !== region) continue;

    const chunkEmb = chunk.embeddingVector as number[] | null;
    if (!chunkEmb || !Array.isArray(chunkEmb)) continue;

    const score = cosineSimilarity(queryEmbedding, chunkEmb);
    scored.push({
      chunkText: chunk.chunkText,
      score,
      sourceId: chunk.sourceId,
      sourceTitle: source.title,
      sourceSlug: source.slug,
      sourceType: source.type,
    });
  }

  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, topK);
}
