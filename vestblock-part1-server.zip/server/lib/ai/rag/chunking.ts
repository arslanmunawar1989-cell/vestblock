const MAX_CHUNK_TOKENS = 600;
const MIN_CHUNK_TOKENS = 50;

function estimateTokens(text: string): number {
  return Math.ceil(text.split(/\s+/).length * 1.3);
}

export interface TextChunk {
  text: string;
  index: number;
}

export function chunkText(rawText: string): TextChunk[] {
  const sections = rawText.split(/\n#{1,3}\s+|\n\n---\n\n/);
  const chunks: TextChunk[] = [];
  let idx = 0;

  for (const section of sections) {
    const paragraphs = section.split(/\n\n+/).filter((p) => p.trim().length > 10);

    let current = "";
    for (const para of paragraphs) {
      const combined = current ? `${current}\n\n${para}` : para;
      if (estimateTokens(combined) > MAX_CHUNK_TOKENS && current) {
        chunks.push({ text: current.trim(), index: idx++ });
        current = para;
      } else {
        current = combined;
      }
    }
    if (current.trim() && estimateTokens(current) >= MIN_CHUNK_TOKENS) {
      chunks.push({ text: current.trim(), index: idx++ });
    } else if (current.trim() && chunks.length > 0) {
      chunks[chunks.length - 1].text += "\n\n" + current.trim();
    } else if (current.trim()) {
      chunks.push({ text: current.trim(), index: idx++ });
    }
  }

  return chunks;
}
