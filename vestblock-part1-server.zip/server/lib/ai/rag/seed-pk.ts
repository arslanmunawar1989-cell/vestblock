import { db } from "../../../db";
import { contentSources, contentChunks } from "@shared/schema";
import { eq } from "drizzle-orm";
import { ingestSource } from "./ingest";

const PK_FAQ_CONTENT = `# VestBlock Pakistan FAQ

## Getting Started

### How do I register on VestBlock?
Visit our registration page and provide your full name, email, phone number, and CNIC. You'll receive a verification email to activate your account. The entire process takes less than 5 minutes.

### What documents are required for KYC verification?
You'll need a valid CNIC (front and back), a recent utility bill or bank statement for address proof, and a selfie for identity verification. Corporate investors require additional documentation including company registration and board resolution.

### What is the minimum investment amount?
The minimum investment on VestBlock is PKR 50,000. This allows you to purchase fractional tokens in premium real estate properties across Pakistan.

### How long does account verification take?
Standard KYC verification is completed within 24-48 business hours. Enhanced due diligence for larger investments may take up to 5 business days. You'll receive email notifications at each step.

### Can I invest from outside Pakistan?
Yes, overseas Pakistanis can invest through VestBlock. You'll need to complete our international KYC process with your NICOP or passport, and funds can be transferred via approved banking channels.

## Investing & Returns

### What kind of returns can I expect?
Returns vary by property and include rental yields (typically 6-12% annually) and capital appreciation. Historical data shows premium properties in DHA, Bahria Town, and commercial zones delivering strong risk-adjusted returns. Past performance does not guarantee future results.

### When are rental distributions paid?
Rental income distributions are processed monthly, typically by the 15th of each month. Distributions are deposited to your VestBlock wallet after deducting applicable management fees and property expenses.

### Are there any fees for investing?
VestBlock charges an entry fee (0-1.0%) on token purchases, an annual management fee (1.0-2.0%), and an exit fee (0.5-1.0%) on secondary market sales. All fees are disclosed upfront before you confirm any transaction.

### Can I reinvest my distributions?
Yes, you can enable auto-reinvestment in your account settings. This automatically uses your rental distributions to purchase additional tokens in the same property or diversify across other offerings.

### How is property value determined?
Property values are determined by independent certified surveyors through periodic valuations. These valuations consider market comparables, rental income, property condition, and local market trends. Token pricing (NAV) is based on the most recent valuation.

## Exits & Liquidity

### How do exit windows work?
Exit windows open twice per year (typically June and December), allowing token holders to list their tokens on VestBlock's internal secondary marketplace. You can sell partial or full holdings during these windows.

### Can I exit partially?
Yes, you can sell as few as 1 token during an exit window. Your remaining tokens continue earning distributions as normal. There is no minimum holding requirement after a partial exit.

### What happens if my tokens don't sell?
If no buyer is matched during an exit window, your tokens remain in your portfolio and continue earning distributions. You can relist them in the next exit window at no additional cost. VestBlock does not guarantee liquidity.

### What is the lockup period?
Lockup periods vary by property (typically 6-24 months) and are disclosed on each property's listing page before you invest. You cannot submit an exit request until the lockup period expires.

## Wallet & Transactions

### How do I withdraw funds to my bank account?
Initiate a withdrawal from your VestBlock wallet to your linked Pakistani bank account. Withdrawals typically complete within 1-3 business days. No withdrawal fee for amounts above PKR 5,000.

### What currencies are supported?
The primary currency is PKR. VestBlock also supports AED, GBP, USD, USDT, and USDC for international investors. Currency conversion fees (0.5-1.5%) apply for cross-currency transactions.

### Is my wallet balance insured?
Investor funds are held in segregated escrow accounts with partnered scheduled banks, separate from VestBlock's operational funds. Segregation provides significant protection of investor capital.

## Security & Compliance

### Is VestBlock regulated by SECP?
VestBlock operates under the Securities and Exchange Commission of Pakistan (SECP) framework for digital asset securities. We comply with applicable securities laws, AML regulations, and data protection requirements.

### How is my personal data protected?
We use AES-256 encryption for data at rest and TLS 1.3 for data in transit. KYC documents are stored in encrypted vaults with strict access controls. We comply with Pakistan's Prevention of Electronic Crimes Act (PECA).

### What happens if VestBlock ceases operations?
Your property tokens represent legal fractional ownership through registered SPVs. In the unlikely event of platform discontinuation, your ownership rights remain intact and would be managed by an appointed trustee as per SECP regulations.

### How do you prevent fraud and money laundering?
We implement comprehensive AML/CFT procedures including mandatory KYC, transaction monitoring, suspicious activity reporting to the Financial Monitoring Unit (FMU), and periodic enhanced due diligence for high-value transactions.

## Legal & Tax

### Do I legally own the property?
You own fractional beneficial interest in a Special Purpose Vehicle (SPV) that holds legal title to the property. This entitles you to proportional rental income and capital returns. Your ownership is recorded in the SPV's register of beneficial owners.

### Are there taxes on rental income?
Rental distributions may be subject to withholding tax under Pakistani tax law. VestBlock provides transaction records and may issue tax certificates. Consult a qualified tax advisor for guidance on your specific situation.

### What about capital gains tax on exit?
Capital gains from token sales may be taxable under FBR guidelines. Tax treatment depends on your holding period and personal circumstances. Consult a qualified tax professional.`;

const PK_TOKENIZATION_CONTENT = `# How Real Estate Tokenization Works on VestBlock

## What is Real Estate Tokenization?
Real estate tokenization is the process of converting property ownership into digital tokens on a blockchain. Each token represents a fraction of ownership in a specific property. This makes real estate investment accessible to a broader range of investors by lowering the entry barrier from crores of rupees to as little as PKR 50,000.

## The Tokenization Process
1. Property Acquisition: VestBlock identifies and acquires premium real estate properties in Pakistan (DHA, Bahria Town, commercial zones).
2. Legal Structuring: Each property is held through a Special Purpose Vehicle (SPV) registered with SECP.
3. Token Creation: The property value is divided into 1,000,000 digital tokens, each representing fractional ownership.
4. Investor Offering: Tokens are offered to verified investors through the VestBlock platform.
5. Ongoing Management: VestBlock handles property management, tenant relations, and maintenance.
6. Distribution: Rental income is distributed monthly to token holders proportional to their ownership.

## Benefits
- Low minimum investment (PKR 50,000)
- Monthly rental income distributions
- Professional property management
- SECP regulatory compliance
- Transparent blockchain-based ownership records
- Semi-annual exit windows for liquidity

## SPV Structure
Each property is held in a dedicated SPV to ensure:
- Legal separation of assets
- Investor protection
- Clear ownership records
- Regulatory compliance
- Professional governance`;

const PK_ABOUT_CONTENT = `# About VestBlock

## Our Mission
VestBlock's mission is to democratize real estate investment in Pakistan by making premium property accessible to everyone through fractional tokenization. We believe quality real estate should not be limited to the ultra-wealthy.

## Platform Overview
VestBlock is an enterprise-grade fractional real estate investment platform supporting investors in Pakistan, UAE, and UK. The platform enables investors to purchase digital tokens representing fractional ownership in premium real estate properties.

## Key Features
- Fractional ownership starting from PKR 50,000
- Monthly rental income distributions
- SECP regulatory compliance
- Comprehensive KYC/AML verification
- Multi-currency wallet (PKR, AED, GBP, USD, USDT, USDC)
- Semi-annual exit windows for secondary market trading
- Professional property management
- Transparent blockchain-based records

## Supported Regions
VestBlock currently operates in Pakistan (primary market), UAE, and UK, with plans for expansion to Qatar and other markets.

## Investor Protection
- Segregated escrow accounts with scheduled banks
- SPV-based property holding structure
- Independent property valuations
- Regular financial reporting
- AML/CFT compliance procedures`;

const PK_FEES_CONTENT = `# VestBlock Fee Structure

## Entry Fee
0% to 1.0% on token purchases. Applied at the time of investment. Exact rate depends on the property offering.

## Annual Management Fee
1.0% to 2.0% of the property value, deducted from rental income before distributions. Covers property management, maintenance oversight, financial reporting, and platform operations.

## Exit Fee
0.5% to 1.0% on secondary market sales during exit windows. Deducted from the sale proceeds.

## Withdrawal Fee
No fee for withdrawals above PKR 5,000. Small processing fee may apply for micro-withdrawals.

## Currency Conversion Fee
0.5% to 1.5% for cross-currency transactions (e.g., USD to PKR).

## Early Exit Penalty
Up to 2.0% additional penalty if attempting to exit before the lockup period expires (where applicable).

## Fee Transparency
All applicable fees are disclosed upfront before you confirm any transaction. There are no hidden charges.`;

export async function seedPkContent(): Promise<{ seeded: number; ingested: number }> {
  const sources = [
    { region: "PK", type: "FAQ", title: "VestBlock Pakistan FAQ", slug: "/pk/faq", rawText: PK_FAQ_CONTENT },
    { region: "PK", type: "PAGE", title: "How Tokenization Works", slug: "/pk/tokenization", rawText: PK_TOKENIZATION_CONTENT },
    { region: "PK", type: "PAGE", title: "About VestBlock", slug: "/pk/about", rawText: PK_ABOUT_CONTENT },
    { region: "PK", type: "PAGE", title: "VestBlock Fee Structure", slug: "/pk/fees", rawText: PK_FEES_CONTENT },
  ];

  let seeded = 0;
  let ingested = 0;

  for (const src of sources) {
    const existing = await db.select().from(contentSources)
      .where(eq(contentSources.slug, src.slug));

    let sourceId: string;
    if (existing.length > 0) {
      sourceId = existing[0].id;
      await db.update(contentSources).set({ rawText: src.rawText, updatedAt: new Date().toISOString() }).where(eq(contentSources.id, sourceId));
    } else {
      const [inserted] = await db.insert(contentSources).values(src).returning();
      sourceId = inserted.id;
      seeded++;
    }

    const result = await ingestSource(sourceId);
    ingested += result.chunksCreated;
  }

  return { seeded, ingested };
}
