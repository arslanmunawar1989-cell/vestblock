import { db } from "../../../db";
import { contentSources, contentChunks } from "@shared/schema";
import { eq } from "drizzle-orm";
import { chunkText } from "./chunking";
import { openAIProvider } from "../providers/OpenAIProvider";

export async function ingestSource(sourceId: string): Promise<{ chunksCreated: number }> {
  const [source] = await db.select().from(contentSources).where(eq(contentSources.id, sourceId));
  if (!source) throw new Error(`Source ${sourceId} not found`);

  await db.delete(contentChunks).where(eq(contentChunks.sourceId, sourceId));

  const chunks = chunkText(source.rawText);
  let created = 0;

  for (const chunk of chunks) {
    const { embedding } = await openAIProvider.embed(chunk.text);
    await db.insert(contentChunks).values({
      sourceId,
      chunkText: chunk.text,
      embeddingVector: embedding,
      chunkIndex: chunk.index,
    });
    created++;
  }

  return { chunksCreated: created };
}

export async function ingestAllForRegion(region: string): Promise<{ sourcesProcessed: number; totalChunks: number }> {
  const sources = await db.select().from(contentSources).where(eq(contentSources.region, region));
  let totalChunks = 0;

  for (const source of sources) {
    const result = await ingestSource(source.id);
    totalChunks += result.chunksCreated;
  }

  return { sourcesProcessed: sources.length, totalChunks };
}
