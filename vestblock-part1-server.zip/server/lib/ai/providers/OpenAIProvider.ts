import OpenAI from "openai";
import type { AIProvider, ChatMessage, ChatResponse, EmbeddingResponse } from "../AIProvider";

const CHAT_MODEL = process.env.AI_MODEL_CHAT || "gpt-5-mini";

let _client: OpenAI | null = null;
function getClient(): OpenAI {
  if (!_client) {
    const apiKey = process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
    if (!apiKey) {
      throw new Error("AI features require AI_INTEGRATIONS_OPENAI_API_KEY to be configured");
    }
    _client = new OpenAI({
      apiKey,
      baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
    });
  }
  return _client;
}

export const openAIProvider: AIProvider = {
  async chat(messages: ChatMessage[], options?: { maxTokens?: number }): Promise<ChatResponse> {
    const response = await getClient().chat.completions.create({
      model: CHAT_MODEL,
      messages,
      max_completion_tokens: options?.maxTokens ?? 8192,
    });
    const content = response.choices[0]?.message?.content ?? "";
    const tokensEstimated =
      (response.usage?.prompt_tokens ?? 0) + (response.usage?.completion_tokens ?? 0);
    return { content, tokensEstimated };
  },

  async embed(text: string): Promise<EmbeddingResponse> {
    const words = text.split(/\s+/);
    const dimension = 256;
    const embedding: number[] = new Array(dimension).fill(0);
    for (let i = 0; i < words.length; i++) {
      const word = words[i].toLowerCase().replace(/[^a-z0-9]/g, "");
      if (!word) continue;
      let hash = 0;
      for (let j = 0; j < word.length; j++) {
        hash = ((hash << 5) - hash + word.charCodeAt(j)) | 0;
      }
      for (let d = 0; d < dimension; d++) {
        const seed = hash ^ (d * 2654435761);
        const val = Math.sin(seed) * 43758.5453;
        embedding[d] += val - Math.floor(val) - 0.5;
      }
    }
    const mag = Math.sqrt(embedding.reduce((s, v) => s + v * v, 0)) || 1;
    for (let d = 0; d < dimension; d++) embedding[d] /= mag;
    return { embedding, tokensEstimated: Math.ceil(words.length * 0.75) };
  },
};
