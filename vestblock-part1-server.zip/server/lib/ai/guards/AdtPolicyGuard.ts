const PROHIBITED_PATTERNS = [
  /guarantee[ds]?\s+(return|roi|profit|yield)/i,
  /guaranteed\s+\d+%/i,
  /risk[\s-]*free\s+(invest|return|income)/i,
  /no[\s-]*risk/i,
];

const ADT_DISCLAIMER =
  "This AI-generated summary is for informational and educational purposes only. " +
  "It does not constitute financial, legal, or investment advice. " +
  "All document analysis should be verified by qualified professionals. " +
  "Past performance is not indicative of future results.";

export function buildAdtSystemPrompt(): string {
  return (
    "You are VestBlock Document Analyzer — a specialized AI for analyzing real estate investment documents.\n\n" +
    "RULES:\n" +
    "1. NEVER guarantee returns, ROI, or profits. Use 'projected', 'estimated', 'historical'.\n" +
    "2. NEVER provide financial, legal, or investment advice. You provide analysis only.\n" +
    "3. Flag any concerning or missing information honestly.\n" +
    "4. Be thorough but concise.\n\n" +
    "OUTPUT FORMAT: Return a JSON object with these exact keys:\n" +
    "{\n" +
    '  "executiveSummary": ["bullet1", "bullet2", "bullet3", "bullet4", "bullet5"],\n' +
    '  "keyNumbers": [{"label": "...", "value": "...", "context": "..."}],\n' +
    '  "risks": [{"category": "Legal|Financial|Operational|Regulatory|Market", "description": "...", "severity": "high|medium|low"}],\n' +
    '  "missingInfo": ["item1", "item2"],\n' +
    '  "investorQuestions": ["q1", "q2", ... up to 10],\n' +
    '  "plainEnglishExplanation": "A 2-3 paragraph plain-language explanation of what this document means for investors."\n' +
    "}\n\n" +
    "Return ONLY valid JSON. No markdown code fences."
  );
}

export function sanitizeAdtResponse(text: string): string {
  let cleaned = text;
  for (const pattern of PROHIBITED_PATTERNS) {
    if (pattern.test(cleaned)) {
      cleaned = cleaned.replace(pattern, (match) => {
        if (/guarantee/i.test(match)) return match.replace(/guarantee[ds]?/i, "projected");
        if (/risk[\s-]*free/i.test(match)) return "investment";
        if (/no[\s-]*risk/i.test(match)) return "managed risk";
        return match;
      });
    }
  }
  return cleaned;
}

export { ADT_DISCLAIMER };
