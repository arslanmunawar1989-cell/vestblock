const PROHIBITED_PATTERNS = [
  /guarantee[ds]?\s+(return|roi|profit|yield)/i,
  /guaranteed\s+\d+%/i,
  /you\s+will\s+(earn|make|receive)\s+\d+%/i,
  /risk[\s-]*free\s+(invest|return|income)/i,
  /no[\s-]*risk/i,
  /can(?:no|')?t\s+lose/i,
];

const ADVICE_PATTERNS = [
  /(?:financial|investment|tax|legal)\s+advice/i,
  /you\s+should\s+(invest|buy|sell)/i,
  /i\s+recommend\s+(?:you\s+)?(?:invest|buy|sell)/i,
  /i\s+advise\s+you/i,
];

const DISCLAIMER =
  "\n\n---\n*This information is for educational purposes only and does not constitute financial, legal, or investment advice. " +
  "Past performance is not indicative of future results. All investments carry risk, including potential loss of principal. " +
  "Please consult a qualified financial advisor before making any investment decisions.*";

export function buildSystemPrompt(contextChunks: string[]): string {
  const context = contextChunks.length > 0
    ? `\n\nUse ONLY the following reference material to answer. If the answer is not in the material, say "I don't have that information in my sources."\n\n---\n${contextChunks.join("\n\n---\n")}\n---`
    : "";

  return (
    "You are VestBlock AI Assistant — a helpful, factual assistant for VestBlock, " +
    "a fractional real estate tokenization platform operating in Pakistan, UAE, and UK.\n\n" +
    "RULES:\n" +
    "1. NEVER guarantee returns, ROI, or profits. Always use language like 'projected', 'estimated', 'historical'.\n" +
    "2. NEVER provide financial, legal, or investment advice. You provide information only.\n" +
    "3. ALWAYS answer from the provided reference material. Do not make up facts.\n" +
    "4. If you don't know, say so honestly.\n" +
    "5. Keep answers concise, clear, and professional.\n" +
    "6. Support both English and Urdu queries. Respond in the language the user uses.\n" +
    "7. When citing facts, mention the source naturally (e.g., 'According to our FAQ...')." +
    context
  );
}

export function sanitizeResponse(text: string): string {
  let cleaned = text;
  for (const pattern of PROHIBITED_PATTERNS) {
    if (pattern.test(cleaned)) {
      cleaned = cleaned.replace(pattern, (match) => {
        if (/guarantee/i.test(match)) return match.replace(/guarantee[ds]?/i, "projected");
        if (/risk[\s-]*free/i.test(match)) return "investment";
        if (/no[\s-]*risk/i.test(match)) return "managed risk";
        return match;
      });
    }
  }
  for (const pattern of ADVICE_PATTERNS) {
    if (pattern.test(cleaned)) {
      cleaned = cleaned.replace(pattern, (match) => {
        return match
          .replace(/advice/i, "information")
          .replace(/should\s+(invest|buy|sell)/i, "may want to consider")
          .replace(/recommend/i, "share information about")
          .replace(/advise/i, "inform");
      });
    }
  }
  if (!cleaned.includes("not constitute")) {
    cleaned += DISCLAIMER;
  }
  return cleaned;
}
