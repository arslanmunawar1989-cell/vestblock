export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface ChatResponse {
  content: string;
  tokensEstimated: number;
}

export interface EmbeddingResponse {
  embedding: number[];
  tokensEstimated: number;
}

export interface AIProvider {
  chat(messages: ChatMessage[], options?: { maxTokens?: number }): Promise<ChatResponse>;
  embed(text: string): Promise<EmbeddingResponse>;
}
