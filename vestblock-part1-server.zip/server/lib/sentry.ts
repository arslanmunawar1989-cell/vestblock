import type { Express, Request, Response, NextFunction } from "express";

declare module "@sentry/node" {
  export function init(options: any): void;
  export function setupExpressErrorHandler(app: any): void;
  export function withScope(callback: (scope: any) => void): void;
  export function captureException(error: Error): void;
  export function captureMessage(message: string, level?: string): void;
}

let sentryClient: any = null;
let sentryInitialized = false;

export async function initSentry(app?: Express): Promise<boolean> {
  const dsn = process.env.SENTRY_DSN;
  if (!dsn) {
    return false;
  }

  try {
    const Sentry = await import("@sentry/node");
    Sentry.init({
      dsn,
      environment: process.env.NODE_ENV || "development",
      tracesSampleRate: parseFloat(process.env.SENTRY_TRACES_SAMPLE_RATE || "0.1"),
      enabled: true,
    });

    sentryClient = Sentry;
    sentryInitialized = true;

    if (app) {
      Sentry.setupExpressErrorHandler(app);
    }

    return true;
  } catch (err) {
    console.warn("Sentry init failed (optional):", (err as Error).message);
    return false;
  }
}

export function captureException(error: Error, context?: Record<string, unknown>) {
  if (sentryClient) {
    if (context) {
      sentryClient.withScope((scope: any) => {
        for (const [key, value] of Object.entries(context)) {
          scope.setExtra(key, value);
        }
        sentryClient.captureException(error);
      });
    } else {
      sentryClient.captureException(error);
    }
  }
}

export function captureMessage(message: string, level: "info" | "warning" | "error" = "info") {
  if (sentryClient) {
    sentryClient.captureMessage(message, level);
  }
}

export function isSentryEnabled(): boolean {
  return sentryInitialized;
}

export function sentryErrorMiddleware() {
  return (err: Error, req: Request, res: Response, next: NextFunction) => {
    captureException(err, {
      method: req.method,
      url: req.url,
      userId: (req as any).user?.userId,
    });
    next(err);
  };
}
