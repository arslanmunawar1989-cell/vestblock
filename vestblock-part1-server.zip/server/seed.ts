import { db } from "./db";
import { users, assets, rounds, portfolioItems, transactions, distributions, walletAccounts, walletTransactions, bankAccounts, fxRates, userCountryProfiles, receivingBankAccounts, marketplaceCountrySettings, legalDocuments, feeSchedules, tenants, tenantUsers, investmentVehicles, offerings, lockupRules, projects, projectMembers, projectActivityLogs, supportTickets, notifications, kycProfiles, tradeListings, exitWindows, tokens, tokenHoldings, appointments, emailLogs, subscribers, campaigns, auditLogs } from "@shared/schema";
import { log } from "./index";
import { hashPassword } from "./auth";
import { FEE_TYPE_DEFAULTS } from "./services/fee-engine.service";
import { eq, sql, and, like, count } from "drizzle-orm";
import crypto from "crypto";
import { PLATFORM_TENANT_ID, PLATFORM_TENANT_SLUG } from "@shared/constants";
import { seedCmsData } from "./cms-seed";

export async function seedSuperAdmin(): Promise<{ id: string } | null> {
  const superAdminEmail = process.env.SUPER_ADMIN_EMAIL;
  if (!superAdminEmail) {
    log("SUPER_ADMIN_EMAIL not set — skipping super admin creation");
    return null;
  }

  const existing = await db.select().from(users).where(eq(users.email, superAdminEmail));
  if (existing.length > 0) {
    log(`Super admin already exists (${superAdminEmail}), skipping`);
    return existing[0];
  }

  const tempPassword = process.env.SUPER_ADMIN_PASSWORD || crypto.randomBytes(16).toString("hex");
  const hashedPw = await hashPassword(tempPassword);

  const [superAdmin] = await db.insert(users).values({
    username: "super_admin",
    password: hashedPw,
    email: superAdminEmail,
    fullName: "Super Administrator",
    role: "admin",
    platformRole: "SUPER_ADMIN",
    kycStatus: "verified",
    tenantId: PLATFORM_TENANT_ID,
  }).returning();

  try {
    await db.insert(tenantUsers).values({ tenantId: PLATFORM_TENANT_ID, userId: superAdmin.id, role: "TENANT_OWNER" });
  } catch (e) {}


  log(`[SETUP] Super admin created: ${superAdminEmail}`);
  if (!process.env.SUPER_ADMIN_PASSWORD) {
    log(`[SETUP] Temporary password generated — set SUPER_ADMIN_PASSWORD env var or change via admin panel`);
  }

  return superAdmin;
}

export async function seedPlatformTenant() {
  const existing = await db.select().from(tenants).where(eq(tenants.id, PLATFORM_TENANT_ID));
  if (existing.length > 0) {
    return;
  }
  await db.insert(tenants).values({
    id: PLATFORM_TENANT_ID,
    name: "VestBlock Platform",
    slug: PLATFORM_TENANT_SLUG,
    status: "ACTIVE",
  });
  log("Platform tenant created");
}

export async function backfillTenantIds() {
  const tableNames = [
    "users", "assets", "rounds", "portfolio_items", "transactions",
    "distributions", "wallet_accounts", "wallet_transactions", "bank_accounts",
    "investment_vehicles", "kyc_profiles", "documents", "notifications",
    "aml_flags", "ledger_entries", "withdrawal_requests", "distribution_snapshots",
    "distribution_payouts", "rent_collections", "operating_expenses",
    "property_milestones", "rental_contracts", "property_managers",
    "property_expense_categories", "waterfall_calculations", "reserve_fund_entries",
    "fee_schedules", "applied_fees", "payment_intents", "support_tickets",
    "spv_entities", "share_classes", "tokens", "token_holdings", "token_transfers",
    "token_ledger_entries", "token_issuances", "token_corporate_actions",
    "token_certificates", "document_ingestions", "offerings", "commitments",
    "valuation_updates", "settlement_journal", "settlement_documents",
    "data_room_documents", "audit_logs", "property_acquisitions", "property_units",
    "property_unit_ledger", "developer_payment_schedule", "property_sale_events",
    "property_sale_payouts", "crypto_wallets", "crypto_deposit_intents",
    "trade_listings", "exit_windows", "exit_window_schedules",
  ];
  for (const tableName of tableNames) {
    try {
      await db.execute(
        `UPDATE "${tableName}" SET tenant_id = '${PLATFORM_TENANT_ID}' WHERE tenant_id IS NULL`
      );
    } catch (e) {
    }
  }
  log("Backfilled tenant IDs for existing data");
}

export async function seedSampleOffering() {
  const PT = PLATFORM_TENANT_ID;

  const existingOfferings = await db.select().from(offerings);
  if (existingOfferings.length > 0) return;

  const [asset] = await db.select().from(assets).where(eq(assets.symbol, "DMTR"));
  if (!asset) return;

  const [adminUser] = await db.select().from(users).where(eq(users.username, "admin"));
  if (!adminUser) return;

  log("Seeding sample offering + lockup rule...");

  const [vehicle] = await db.insert(investmentVehicles).values({
    name: "Dubai Marina Tower SPV",
    type: "SPV",
    jurisdictionCountry: "AE",
    baseCurrency: "AED",
    status: "ACTIVE",
    targetAum: "2500000.00",
    tenantId: PT,
    description: "Special Purpose Vehicle for Dubai Marina Tower REIT tokenization",
    createdBy: adminUser.id,
  }).returning();

  await db.insert(offerings).values({
    assetId: asset.id,
    vehicleId: vehicle.id,
    name: "Dubai Marina Tower - Series A Offering",
    targetAmount: "2500000.00",
    baseCurrency: "AED",
    minInvest: "500.00",
    maxInvest: "250000.00",
    startDate: "2026-01-15",
    endDate: "2026-06-15",
    status: "OPEN",
    totalCommitted: "1800000.00",
    createdBy: adminUser.id,
    tenantId: PT,
  });

  const existingLockup = await db.select().from(lockupRules).where(eq(lockupRules.assetId, asset.id));
  if (existingLockup.length === 0) {
    await db.insert(lockupRules).values({
      assetId: asset.id,
      profitLockDays: 30,
      capitalLockDays: 90,
      tenantId: PT,
    });
  }

  log("Sample offering + lockup rule seeded");
}

export async function seedDatabase() {
  await seedPlatformTenant();

  const existingUsers = await db.select().from(users);
  if (existingUsers.length > 0) {
    log("Database already seeded, skipping");
    await seedSuperAdmin();
    await backfillTenantIds();
    await seedSampleOffering();
    await seedCmsData();
    await seedBugBashData();
    return;
  }

  log("Seeding database...");

  const defaultHash = await hashPassword("password123");
  const adminHash = await hashPassword("admin123");

  const PT = PLATFORM_TENANT_ID;

  const [admin] = await db.insert(users).values({
    username: "admin",
    password: adminHash,
    email: "admin@vestblock.io",
    fullName: "Platform Admin",
    role: "admin",
    platformRole: "SUPER_ADMIN",
    kycStatus: "verified",
    tenantId: PT,
  }).returning();

  await db.insert(tenantUsers).values({ tenantId: PT, userId: admin.id, role: "TENANT_OWNER" });

  await seedSuperAdmin();

  const [investor1] = await db.insert(users).values({
    username: "sarah_johnson",
    password: defaultHash,
    email: "sarah@example.com",
    fullName: "Sarah Johnson",
    role: "investor",
    kycStatus: "verified",
    tenantId: PT,
  }).returning();

  const [investor2] = await db.insert(users).values({
    username: "ahmed_khan",
    password: defaultHash,
    email: "ahmed@example.com",
    fullName: "Ahmed Khan",
    role: "investor",
    kycStatus: "verified",
    tenantId: PT,
  }).returning();

  const [investor3] = await db.insert(users).values({
    username: "fatima_ali",
    password: defaultHash,
    email: "fatima@example.com",
    fullName: "Fatima Ali",
    role: "investor",
    kycStatus: "pending",
    tenantId: PT,
  }).returning();

  const [issuer1] = await db.insert(users).values({
    username: "emaar_properties",
    password: defaultHash,
    email: "admin@emaarproperties.com",
    fullName: "Emaar Properties",
    role: "issuer",
    kycStatus: "verified",
    tenantId: PT,
  }).returning();

  const [issuer2] = await db.insert(users).values({
    username: "bahria_town",
    password: defaultHash,
    email: "admin@bahriatown.com",
    fullName: "Bahria Town (Pvt) Ltd",
    role: "issuer",
    kycStatus: "verified",
    tenantId: PT,
  }).returning();

  const [agent1] = await db.insert(users).values({
    username: "omar_rashid",
    password: defaultHash,
    email: "omar@example.com",
    fullName: "Omar Rashid",
    role: "agent",
    kycStatus: "verified",
    tenantId: PT,
  }).returning();

  const [asset1] = await db.insert(assets).values({
    name: "Dubai Marina Tower REIT",
    symbol: "DMTR",
    assetType: "Commercial Real Estate",
    description: "Premium Grade-A office and retail space in Dubai Marina, one of Dubai's most sought-after waterfront destinations. The tower features 45 floors of leasable commercial space with panoramic views of the marina and Arabian Gulf.",
    totalSupply: "10000",
    pricePerToken: "250.00",
    baseCurrency: "AED",
    country: "AE",
    status: "active",
    issuerId: issuer1.id,
    tenantId: PT,
    propertyType: "Office Tower",
    location: "Dubai Marina, Dubai, UAE",
    annualYield: "7.80",
    occupancyRate: "94.50",
    totalPropertyValue: "180000000.00",
    managementFee: "1.50",
    distributionFrequency: "Quarterly",
    minInvestment: "500.00",
    riskRating: "Medium-Low",
    constructionStatus: "Completed",
    propertyClass: "Grade A",
    legalStructure: "DIFC SPV (Special Purpose Vehicle)",
    regulatoryBody: "Dubai Financial Services Authority (DFSA)",
    yearBuilt: "2019",
    totalArea: "450,000 sq ft",
    numberOfUnits: 120,
    parkingSpaces: 350,
    tenantProfile: "Multinational corporations, tech firms, financial institutions",
    highlights: "Waterfront location, 94.5% occupancy, weighted average lease expiry 6.2 years",
    tokenDecimals: 2,
    navPerToken: "262.50",
    irr: "12.50",
    expectedRentalYield: "7.80",
    projectedCapitalAppreciation: "5.50",
    holdingPeriodYears: 5,
    projectedTotalReturn: "13.30",
  }).returning();

  const [asset2] = await db.insert(assets).values({
    name: "Bahria Town Karachi Residences",
    symbol: "BTKR",
    assetType: "Residential Real Estate",
    description: "A portfolio of premium residential apartments in Bahria Town Karachi, Pakistan's largest private housing project. Features modern 2-3 bedroom apartments in a gated community with world-class amenities.",
    totalSupply: "20000",
    pricePerToken: "5000.00",
    baseCurrency: "PKR",
    country: "PK",
    status: "active",
    issuerId: issuer2.id,
    tenantId: PT,
    propertyType: "Residential Apartments",
    location: "Bahria Town, Karachi, Pakistan",
    annualYield: "9.20",
    occupancyRate: "88.00",
    totalPropertyValue: "2500000000.00",
    managementFee: "2.00",
    distributionFrequency: "Semi-Annual",
    minInvestment: "25000.00",
    riskRating: "Medium",
    constructionStatus: "Completed",
    propertyClass: "Premium Residential",
    legalStructure: "Pakistan SPV under SECP",
    regulatoryBody: "Securities and Exchange Commission of Pakistan (SECP)",
    yearBuilt: "2022",
    totalArea: "1,200,000 sq ft",
    numberOfUnits: 480,
    parkingSpaces: 600,
    tenantProfile: "Upper-middle class families, expatriates, professionals",
    highlights: "Gated community, 24/7 security, proximity to M9 motorway",
    tokenDecimals: 2,
    navPerToken: "5250.00",
    irr: "15.00",
    expectedRentalYield: "9.20",
    projectedCapitalAppreciation: "8.00",
    holdingPeriodYears: 5,
    projectedTotalReturn: "17.20",
  }).returning();

  const [asset3] = await db.insert(assets).values({
    name: "Downtown Dubai Retail Mall",
    symbol: "DDRM",
    assetType: "Retail Real Estate",
    description: "A premium retail complex located in the heart of Downtown Dubai, adjacent to Burj Khalifa and Dubai Mall. Features luxury retail outlets, F&B concepts, and lifestyle brands targeting tourists and residents.",
    totalSupply: "8000",
    pricePerToken: "500.00",
    baseCurrency: "AED",
    country: "AE",
    status: "active",
    issuerId: issuer1.id,
    tenantId: PT,
    propertyType: "Retail Mall",
    location: "Downtown Dubai, Dubai, UAE",
    annualYield: "8.50",
    occupancyRate: "97.00",
    totalPropertyValue: "320000000.00",
    managementFee: "1.75",
    distributionFrequency: "Quarterly",
    minInvestment: "1000.00",
    riskRating: "Low",
    constructionStatus: "Completed",
    propertyClass: "Prime Retail",
    legalStructure: "DIFC SPV (Special Purpose Vehicle)",
    regulatoryBody: "Dubai Financial Services Authority (DFSA)",
    yearBuilt: "2017",
    totalArea: "280,000 sq ft",
    numberOfUnits: 85,
    parkingSpaces: 500,
    tenantProfile: "International luxury brands, F&B chains, lifestyle retailers",
    highlights: "97% occupancy, Burj Khalifa district footfall, 5-year average lease terms",
    tokenDecimals: 2,
    navPerToken: "520.00",
    irr: "11.20",
    expectedRentalYield: "8.50",
    projectedCapitalAppreciation: "4.20",
    holdingPeriodYears: 5,
    projectedTotalReturn: "12.70",
  }).returning();

  const [asset4] = await db.insert(assets).values({
    name: "Lahore Smart City Plots",
    symbol: "LSCP",
    assetType: "Land Development",
    description: "Fractional ownership in pre-development commercial plots within Lahore Smart City, a master-planned community on Lahore-Islamabad Motorway. Expected significant capital appreciation upon infrastructure completion.",
    totalSupply: "15000",
    pricePerToken: "3500.00",
    baseCurrency: "PKR",
    country: "PK",
    status: "active",
    issuerId: issuer2.id,
    tenantId: PT,
    propertyType: "Commercial Plots",
    location: "Lahore Smart City, Lahore, Pakistan",
    annualYield: "0.00",
    occupancyRate: "0.00",
    totalPropertyValue: "1800000000.00",
    managementFee: "1.00",
    distributionFrequency: "On Exit",
    minInvestment: "17500.00",
    riskRating: "Medium-High",
    constructionStatus: "Under Development",
    propertyClass: "Development Land",
    legalStructure: "Trust Structure under SECP",
    regulatoryBody: "Securities and Exchange Commission of Pakistan (SECP)",
    yearBuilt: "N/A - Under Development",
    totalArea: "500 Kanal (62.5 acres)",
    tenantProfile: "N/A - Capital appreciation play",
    highlights: "Master-planned smart city, proximity to motorway, 35% expected appreciation in 3 years",
    tokenDecimals: 2,
    navPerToken: "3500.00",
    irr: "18.00",
    expectedRentalYield: "0.00",
    projectedCapitalAppreciation: "12.00",
    holdingPeriodYears: 3,
    projectedTotalReturn: "12.00",
  }).returning();

  const [asset5] = await db.insert(assets).values({
    name: "Abu Dhabi Industrial Logistics Hub",
    symbol: "AILH",
    assetType: "Industrial & Logistics",
    description: "A Grade-A logistics and warehousing facility in KIZAD (Khalifa Industrial Zone Abu Dhabi), serving e-commerce, manufacturing, and supply chain companies. Long-term leases with blue-chip tenants.",
    totalSupply: "6000",
    pricePerToken: "350.00",
    baseCurrency: "AED",
    country: "AE",
    status: "active",
    issuerId: issuer1.id,
    tenantId: PT,
    propertyType: "Logistics Warehouse",
    location: "KIZAD, Abu Dhabi, UAE",
    annualYield: "6.80",
    occupancyRate: "100.00",
    totalPropertyValue: "95000000.00",
    managementFee: "1.25",
    distributionFrequency: "Quarterly",
    minInvestment: "700.00",
    riskRating: "Low",
    constructionStatus: "Completed",
    propertyClass: "Grade A Industrial",
    legalStructure: "ADGM SPV (Abu Dhabi Global Market)",
    regulatoryBody: "Financial Services Regulatory Authority (FSRA)",
    yearBuilt: "2021",
    totalArea: "650,000 sq ft",
    numberOfUnits: 12,
    parkingSpaces: 200,
    tenantProfile: "Amazon, Noon, DHL, major FMCG distributors",
    highlights: "100% occupied, 10-year average lease terms, triple-net leases",
    tokenDecimals: 2,
    navPerToken: "365.00",
    irr: "10.50",
    expectedRentalYield: "6.80",
    projectedCapitalAppreciation: "3.80",
    holdingPeriodYears: 7,
    projectedTotalReturn: "10.60",
  }).returning();

  const [asset6] = await db.insert(assets).values({
    name: "Islamabad Blue Area Office Tower",
    symbol: "IBAO",
    assetType: "Commercial Real Estate",
    description: "Prime office space in Islamabad's prestigious Blue Area, the commercial heart of Pakistan's capital. Multi-tenant Grade-A building housing government contractors, IT firms, and financial services companies.",
    totalSupply: "12000",
    pricePerToken: "4000.00",
    baseCurrency: "PKR",
    country: "PK",
    status: "active",
    issuerId: issuer2.id,
    tenantId: PT,
    propertyType: "Office Building",
    location: "Blue Area, Islamabad, Pakistan",
    annualYield: "8.50",
    occupancyRate: "91.00",
    totalPropertyValue: "3200000000.00",
    managementFee: "1.75",
    distributionFrequency: "Quarterly",
    minInvestment: "20000.00",
    riskRating: "Medium-Low",
    constructionStatus: "Completed",
    propertyClass: "Grade A",
    legalStructure: "Pakistan SPV under SECP",
    regulatoryBody: "Securities and Exchange Commission of Pakistan (SECP)",
    yearBuilt: "2020",
    totalArea: "320,000 sq ft",
    numberOfUnits: 95,
    parkingSpaces: 180,
    tenantProfile: "IT companies, banks, consulting firms, government agencies",
    highlights: "Blue Area prime location, 91% occupancy, strong rental growth trajectory",
    tokenDecimals: 2,
    navPerToken: "4150.00",
    irr: "13.80",
    expectedRentalYield: "8.50",
    projectedCapitalAppreciation: "6.50",
    holdingPeriodYears: 5,
    projectedTotalReturn: "15.00",
  }).returning();

  const [asset7] = await db.insert(assets).values({
    name: "Dubai Healthcare City Medical Suites",
    symbol: "DHCM",
    assetType: "Healthcare Real Estate",
    description: "Medical office suites and clinic spaces within Dubai Healthcare City Free Zone, catering to international healthcare providers, specialists, and wellness centers. Stable, recession-resistant tenant base.",
    totalSupply: "5000",
    pricePerToken: "400.00",
    baseCurrency: "AED",
    country: "AE",
    status: "active",
    issuerId: issuer1.id,
    tenantId: PT,
    propertyType: "Medical Offices",
    location: "Dubai Healthcare City, Dubai, UAE",
    annualYield: "7.20",
    occupancyRate: "96.00",
    totalPropertyValue: "145000000.00",
    managementFee: "1.50",
    distributionFrequency: "Quarterly",
    minInvestment: "800.00",
    riskRating: "Low",
    constructionStatus: "Completed",
    propertyClass: "Healthcare Grade A",
    legalStructure: "DIFC SPV (Special Purpose Vehicle)",
    regulatoryBody: "Dubai Financial Services Authority (DFSA)",
    yearBuilt: "2018",
    totalArea: "180,000 sq ft",
    numberOfUnits: 65,
    parkingSpaces: 250,
    tenantProfile: "International hospitals, specialist clinics, diagnostic centers",
    highlights: "Free zone benefits, 96% occupancy, healthcare sector growth 12% YoY",
    tokenDecimals: 2,
    navPerToken: "418.00",
    irr: "11.00",
    expectedRentalYield: "7.20",
    projectedCapitalAppreciation: "4.50",
    holdingPeriodYears: 5,
    projectedTotalReturn: "11.70",
  }).returning();

  const [asset8] = await db.insert(assets).values({
    name: "DHA Lahore Mixed-Use Complex",
    symbol: "DLMU",
    assetType: "Mixed-Use Development",
    description: "A mixed-use development in DHA Phase 6, Lahore combining retail, office, and serviced apartment components. Located on Main Boulevard, one of Lahore's busiest commercial corridors.",
    totalSupply: "10000",
    pricePerToken: "6000.00",
    baseCurrency: "PKR",
    country: "PK",
    status: "active",
    issuerId: issuer2.id,
    tenantId: PT,
    propertyType: "Mixed-Use Complex",
    location: "DHA Phase 6, Main Boulevard, Lahore, Pakistan",
    annualYield: "7.50",
    occupancyRate: "85.00",
    totalPropertyValue: "4500000000.00",
    managementFee: "2.00",
    distributionFrequency: "Semi-Annual",
    minInvestment: "30000.00",
    riskRating: "Medium",
    constructionStatus: "Completed",
    propertyClass: "Premium Mixed-Use",
    legalStructure: "Trust Structure under SECP",
    regulatoryBody: "Securities and Exchange Commission of Pakistan (SECP)",
    yearBuilt: "2023",
    totalArea: "550,000 sq ft",
    numberOfUnits: 200,
    parkingSpaces: 400,
    tenantProfile: "Retail brands, professional services, corporate tenants, short-stay guests",
    highlights: "Main Boulevard frontage, DHA premium location, diversified income streams",
    tokenDecimals: 2,
    navPerToken: "6200.00",
    irr: "14.50",
    expectedRentalYield: "7.50",
    projectedCapitalAppreciation: "7.00",
    holdingPeriodYears: 5,
    projectedTotalReturn: "14.50",
  }).returning();

  await db.insert(rounds).values([
    { assetId: asset1.id, name: "Series A", targetAmount: "2500000", raisedAmount: "1800000", status: "open", startDate: "2025-11-01", tenantId: PT },
    { assetId: asset2.id, name: "Round 1", targetAmount: "100000000", raisedAmount: "72000000", status: "open", startDate: "2025-10-15", tenantId: PT },
    { assetId: asset3.id, name: "Series A", targetAmount: "4000000", raisedAmount: "3400000", status: "open", startDate: "2025-12-01", tenantId: PT },
    { assetId: asset4.id, name: "Pre-Launch", targetAmount: "52500000", raisedAmount: "48000000", status: "closing", startDate: "2025-09-01", endDate: "2026-03-31", tenantId: PT },
    { assetId: asset5.id, name: "Series A", targetAmount: "2100000", raisedAmount: "1050000", status: "open", startDate: "2026-01-01", tenantId: PT },
    { assetId: asset6.id, name: "Round 1", targetAmount: "48000000", raisedAmount: "36000000", status: "open", startDate: "2025-11-15", tenantId: PT },
    { assetId: asset7.id, name: "Series A", targetAmount: "2000000", raisedAmount: "1600000", status: "open", startDate: "2025-12-15", tenantId: PT },
    { assetId: asset8.id, name: "Round 1", targetAmount: "60000000", raisedAmount: "42000000", status: "open", startDate: "2026-01-15", tenantId: PT },
  ]);

  const [sampleVehicle] = await db.insert(investmentVehicles).values({
    name: "Dubai Marina Tower SPV",
    type: "SPV",
    jurisdictionCountry: "AE",
    baseCurrency: "AED",
    status: "ACTIVE",
    targetAum: "2500000.00",
    tenantId: PT,
    description: "Special Purpose Vehicle for Dubai Marina Tower REIT tokenization",
    createdBy: admin.id,
  }).returning();

  await db.insert(offerings).values({
    assetId: asset1.id,
    vehicleId: sampleVehicle.id,
    name: "Dubai Marina Tower - Series A Offering",
    targetAmount: "2500000.00",
    baseCurrency: "AED",
    minInvest: "500.00",
    maxInvest: "250000.00",
    startDate: "2026-01-15",
    endDate: "2026-06-15",
    status: "OPEN",
    totalCommitted: "1800000.00",
    createdBy: admin.id,
    tenantId: PT,
  });

  await db.insert(lockupRules).values({
    assetId: asset1.id,
    profitLockDays: 30,
    capitalLockDays: 90,
    tenantId: PT,
  });

  await db.insert(portfolioItems).values([
    { userId: investor1.id, assetId: asset1.id, quantity: "200", averageCost: "250.00", tenantId: PT },
    { userId: investor1.id, assetId: asset3.id, quantity: "100", averageCost: "500.00", tenantId: PT },
    { userId: investor1.id, assetId: asset2.id, quantity: "50", averageCost: "5000.00", tenantId: PT },
    { userId: investor2.id, assetId: asset2.id, quantity: "100", averageCost: "5000.00", tenantId: PT },
    { userId: investor2.id, assetId: asset6.id, quantity: "80", averageCost: "4000.00", tenantId: PT },
    { userId: investor2.id, assetId: asset1.id, quantity: "50", averageCost: "250.00", tenantId: PT },
  ]);

  const tokenRecords = await db.insert(tokens).values([
    { tenantId: PT, assetId: asset1.id, tokenSymbol: "DMTR", decimals: 2, totalSupply: "10000" },
    { tenantId: PT, assetId: asset2.id, tokenSymbol: "BTKR", decimals: 2, totalSupply: "5000" },
    { tenantId: PT, assetId: asset3.id, tokenSymbol: "DDRM", decimals: 2, totalSupply: "8000" },
    { tenantId: PT, assetId: asset4.id, tokenSymbol: "AILH", decimals: 2, totalSupply: "6000" },
    { tenantId: PT, assetId: asset5.id, tokenSymbol: "DHCM", decimals: 2, totalSupply: "5000" },
    { tenantId: PT, assetId: asset6.id, tokenSymbol: "IBOT", decimals: 2, totalSupply: "3000" },
    { tenantId: PT, assetId: asset7.id, tokenSymbol: "DLHR", decimals: 2, totalSupply: "4000" },
    { tenantId: PT, assetId: asset8.id, tokenSymbol: "KPCT", decimals: 2, totalSupply: "12000" },
  ]).returning();

  const tokenByAsset: Record<string, string> = {};
  for (const t of tokenRecords) {
    if (t.assetId) tokenByAsset[t.assetId] = t.id;
  }

  await db.insert(tokenHoldings).values([
    { tenantId: PT, userId: investor1.id, tokenId: tokenByAsset[asset1.id], balance: "200", acquiredAt: "2025-12-05" },
    { tenantId: PT, userId: investor1.id, tokenId: tokenByAsset[asset3.id], balance: "100", acquiredAt: "2025-12-10" },
    { tenantId: PT, userId: investor1.id, tokenId: tokenByAsset[asset2.id], balance: "50", acquiredAt: "2026-01-05" },
    { tenantId: PT, userId: investor2.id, tokenId: tokenByAsset[asset2.id], balance: "100", acquiredAt: "2025-12-20" },
    { tenantId: PT, userId: investor2.id, tokenId: tokenByAsset[asset6.id], balance: "80", acquiredAt: "2025-12-25" },
    { tenantId: PT, userId: investor2.id, tokenId: tokenByAsset[asset1.id], balance: "50", acquiredAt: "2026-01-10" },
  ]);

  await db.insert(transactions).values([
    { userId: investor1.id, assetId: asset1.id, type: "purchase", amount: "50000", status: "completed", description: "Purchased 200 tokens of Dubai Marina Tower REIT", tenantId: PT },
    { userId: investor1.id, assetId: asset3.id, type: "purchase", amount: "50000", status: "completed", description: "Purchased 100 tokens of Downtown Dubai Retail Mall", tenantId: PT },
    { userId: investor1.id, type: "deposit", amount: "150000", status: "completed", description: "Bank transfer deposit - Emirates NBD", tenantId: PT },
    { userId: investor2.id, assetId: asset2.id, type: "purchase", amount: "500000", status: "completed", description: "Purchased 100 tokens of Bahria Town Karachi Residences", tenantId: PT },
    { userId: investor2.id, type: "deposit", amount: "1000000", status: "completed", description: "HBL bank transfer deposit", tenantId: PT },
  ]);

  await db.insert(distributions).values([
    { assetId: asset1.id, amount: "195000", distributionDate: "2026-03-15", status: "scheduled", tenantId: PT },
    { assetId: asset3.id, amount: "340000", distributionDate: "2026-03-15", status: "scheduled", tenantId: PT },
    { assetId: asset1.id, amount: "180000", distributionDate: "2025-12-15", status: "completed", tenantId: PT },
    { assetId: asset5.id, amount: "142800", distributionDate: "2025-12-15", status: "completed", tenantId: PT },
    { assetId: asset2.id, amount: "23000000", distributionDate: "2026-06-30", status: "scheduled", tenantId: PT },
    { assetId: asset6.id, amount: "10200000", distributionDate: "2026-03-31", status: "scheduled", tenantId: PT },
  ]);

  const [aedAccount1] = await db.insert(walletAccounts).values({
    userId: investor1.id,
    currency: "AED",
    tenantId: PT,
  }).returning();

  const [pkrAccount1] = await db.insert(walletAccounts).values({
    userId: investor1.id,
    currency: "PKR",
    tenantId: PT,
  }).returning();

  const [aedAccount2] = await db.insert(walletAccounts).values({
    userId: investor2.id,
    currency: "AED",
    tenantId: PT,
  }).returning();

  const [pkrAccount2] = await db.insert(walletAccounts).values({
    userId: investor2.id,
    currency: "PKR",
    tenantId: PT,
  }).returning();

  const [aedAccount3] = await db.insert(walletAccounts).values({
    userId: investor3.id,
    currency: "AED",
    tenantId: PT,
  }).returning();

  const [pkrAccount3] = await db.insert(walletAccounts).values({
    userId: investor3.id,
    currency: "PKR",
    tenantId: PT,
  }).returning();

  await db.insert(walletTransactions).values([
    { walletAccountId: aedAccount1.id, type: "DEPOSIT", amount: "150000.00", currency: "AED", status: "COMPLETED", description: "Initial bank transfer deposit", referenceId: "DEP-001", metadata: { source: "bank_transfer", bank: "Emirates NBD", iban: "AE07...3456" }, createdAt: "2025-11-15T10:30:00Z", tenantId: PT },
    { walletAccountId: aedAccount1.id, type: "DEPOSIT", amount: "50000.00", currency: "AED", status: "COMPLETED", description: "Bank transfer top-up", referenceId: "DEP-002", metadata: { source: "bank_transfer", bank: "Emirates NBD" }, createdAt: "2025-12-01T14:00:00Z", tenantId: PT },
    { walletAccountId: aedAccount1.id, type: "INVEST_RESERVE", amount: "50000.00", currency: "AED", status: "COMPLETED", description: "Reserved for Dubai Marina Tower REIT (200 tokens)", referenceId: "INV-001", metadata: { assetSymbol: "DMTR", tokens: 200 }, createdAt: "2025-12-05T09:15:00Z", tenantId: PT },
    { walletAccountId: aedAccount1.id, type: "INVEST_CAPTURE", amount: "50000.00", currency: "AED", status: "COMPLETED", description: "Captured investment in Dubai Marina Tower REIT", referenceId: "INV-001", metadata: { assetSymbol: "DMTR", tokens: 200, pricePerToken: "250.00" }, createdAt: "2025-12-05T09:16:00Z", tenantId: PT },
    { walletAccountId: aedAccount1.id, type: "INVEST_RESERVE", amount: "50000.00", currency: "AED", status: "COMPLETED", description: "Reserved for Downtown Dubai Retail Mall (100 tokens)", referenceId: "INV-002", metadata: { assetSymbol: "DDRM", tokens: 100 }, createdAt: "2025-12-10T11:00:00Z", tenantId: PT },
    { walletAccountId: aedAccount1.id, type: "INVEST_CAPTURE", amount: "50000.00", currency: "AED", status: "COMPLETED", description: "Captured investment in Downtown Dubai Retail Mall", referenceId: "INV-002", metadata: { assetSymbol: "DDRM", tokens: 100, pricePerToken: "500.00" }, createdAt: "2025-12-10T11:01:00Z", tenantId: PT },
    { walletAccountId: aedAccount1.id, type: "DIVIDEND", amount: "3900.00", currency: "AED", status: "COMPLETED", description: "Q4 2025 dividend from Dubai Marina Tower REIT", referenceId: "DIV-001", metadata: { assetSymbol: "DMTR", quarter: "Q4 2025" }, createdAt: "2026-01-15T08:00:00Z", tenantId: PT },
    { walletAccountId: aedAccount1.id, type: "FEE", amount: "250.00", currency: "AED", status: "COMPLETED", description: "Platform management fee", referenceId: "FEE-001", metadata: { feeType: "management", period: "Q4 2025" }, createdAt: "2026-01-15T08:01:00Z", tenantId: PT },
    { walletAccountId: aedAccount1.id, type: "WITHDRAW", amount: "5000.00", currency: "AED", status: "COMPLETED", description: "Withdrawal to Emirates NBD account", referenceId: "WTH-001", metadata: { destination: "bank_transfer", bank: "Emirates NBD" }, createdAt: "2026-01-20T16:30:00Z", tenantId: PT },
    { walletAccountId: aedAccount1.id, type: "DEPOSIT", amount: "25000.00", currency: "AED", status: "PENDING", description: "Bank transfer pending clearance", referenceId: "DEP-003", metadata: { source: "bank_transfer", bank: "ADCB" }, createdAt: "2026-02-10T09:00:00Z", tenantId: PT },
    { walletAccountId: pkrAccount1.id, type: "DEPOSIT", amount: "1000000.00", currency: "PKR", status: "COMPLETED", description: "PKR deposit via HBL bank transfer", referenceId: "DEP-PKR-001", metadata: { source: "bank_transfer", bank: "HBL" }, createdAt: "2025-12-20T12:00:00Z", tenantId: PT },
    { walletAccountId: pkrAccount1.id, type: "INVEST_RESERVE", amount: "250000.00", currency: "PKR", status: "COMPLETED", description: "Reserved for Bahria Town Karachi Residences (50 tokens)", referenceId: "INV-PKR-001", metadata: { assetSymbol: "BTKR", tokens: 50 }, createdAt: "2025-12-25T10:00:00Z", tenantId: PT },
    { walletAccountId: pkrAccount1.id, type: "INVEST_CAPTURE", amount: "250000.00", currency: "PKR", status: "COMPLETED", description: "Captured investment in Bahria Town Karachi Residences", referenceId: "INV-PKR-001", metadata: { assetSymbol: "BTKR", tokens: 50, pricePerToken: "5000.00" }, createdAt: "2025-12-25T10:01:00Z", tenantId: PT },
    { walletAccountId: pkrAccount1.id, type: "FX_CONVERT", amount: "-300000.00", currency: "PKR", status: "COMPLETED", description: "Converted PKR to AED for Dubai investment", referenceId: "FX-001", metadata: { fromCurrency: "PKR", toCurrency: "AED", rate: "0.013", aedAmount: "3960.00" }, createdAt: "2026-01-05T14:30:00Z", tenantId: PT },
    { walletAccountId: pkrAccount2.id, type: "DEPOSIT", amount: "2000000.00", currency: "PKR", status: "COMPLETED", description: "PKR deposit via JazzCash", referenceId: "DEP-PKR-002", metadata: { source: "jazzcash" }, createdAt: "2025-11-10T10:00:00Z", tenantId: PT },
    { walletAccountId: pkrAccount2.id, type: "INVEST_RESERVE", amount: "500000.00", currency: "PKR", status: "COMPLETED", description: "Reserved for Bahria Town Karachi Residences (100 tokens)", referenceId: "INV-PKR-002", metadata: { assetSymbol: "BTKR", tokens: 100 }, createdAt: "2025-11-15T10:00:00Z", tenantId: PT },
    { walletAccountId: pkrAccount2.id, type: "INVEST_CAPTURE", amount: "500000.00", currency: "PKR", status: "COMPLETED", description: "Captured investment in Bahria Town Karachi Residences", referenceId: "INV-PKR-002", metadata: { assetSymbol: "BTKR", tokens: 100, pricePerToken: "5000.00" }, createdAt: "2025-11-15T10:01:00Z", tenantId: PT },
    { walletAccountId: pkrAccount2.id, type: "INVEST_RESERVE", amount: "320000.00", currency: "PKR", status: "COMPLETED", description: "Reserved for Islamabad Blue Area Office Tower (80 tokens)", referenceId: "INV-PKR-003", metadata: { assetSymbol: "IBAO", tokens: 80 }, createdAt: "2025-12-01T11:00:00Z", tenantId: PT },
    { walletAccountId: pkrAccount2.id, type: "INVEST_CAPTURE", amount: "320000.00", currency: "PKR", status: "COMPLETED", description: "Captured investment in Islamabad Blue Area Office Tower", referenceId: "INV-PKR-003", metadata: { assetSymbol: "IBAO", tokens: 80, pricePerToken: "4000.00" }, createdAt: "2025-12-01T11:01:00Z", tenantId: PT },
    { walletAccountId: aedAccount2.id, type: "DEPOSIT", amount: "20000.00", currency: "AED", status: "COMPLETED", description: "AED deposit via bank transfer", referenceId: "DEP-AED-002", metadata: { source: "bank_transfer", bank: "Emirates NBD" }, createdAt: "2025-12-05T10:00:00Z", tenantId: PT },
    { walletAccountId: aedAccount2.id, type: "INVEST_RESERVE", amount: "12500.00", currency: "AED", status: "COMPLETED", description: "Reserved for Dubai Marina Tower REIT (50 tokens)", referenceId: "INV-AED-002", metadata: { assetSymbol: "DMTR", tokens: 50 }, createdAt: "2025-12-15T10:00:00Z", tenantId: PT },
    { walletAccountId: aedAccount2.id, type: "INVEST_CAPTURE", amount: "12500.00", currency: "AED", status: "COMPLETED", description: "Captured investment in Dubai Marina Tower REIT", referenceId: "INV-AED-002", metadata: { assetSymbol: "DMTR", tokens: 50, pricePerToken: "250.00" }, createdAt: "2025-12-15T10:01:00Z", tenantId: PT },
    { walletAccountId: aedAccount3.id, type: "DEPOSIT", amount: "10000.00", currency: "AED", status: "COMPLETED", description: "Initial AED deposit", referenceId: "DEP-AED-003", metadata: { source: "bank_transfer" }, createdAt: "2026-01-10T10:00:00Z", tenantId: PT },
    { walletAccountId: pkrAccount3.id, type: "DEPOSIT", amount: "500000.00", currency: "PKR", status: "COMPLETED", description: "PKR deposit via Raast", referenceId: "DEP-PKR-003", metadata: { source: "raast" }, createdAt: "2026-01-15T10:00:00Z", tenantId: PT },
  ]);

  await db.insert(bankAccounts).values([
    {
      userId: investor1.id,
      country: "UAE",
      label: "Emirates NBD Savings",
      accountHolderName: "Sarah Johnson",
      iban: "AE070331234567890123456",
      bankName: "Emirates NBD",
      swiftCode: "EABORAEXXX",
      currency: "AED",
      status: "verified",
      isDefault: true,
      verifiedBy: admin.id,
      verifiedAt: "2025-12-01T10:00:00Z",
      verificationNotes: "Verified via bank statement",
      tenantId: PT,
    },
    {
      userId: investor1.id,
      country: "PK",
      label: "HBL Current Account",
      accountHolderName: "Sarah Johnson",
      bankName: "Habib Bank Limited (HBL)",
      accountNumber: "12345678901234",
      branchCode: "0001",
      swiftCode: "HABORPKAXXX",
      currency: "PKR",
      status: "verified",
      isDefault: true,
      verifiedBy: admin.id,
      verifiedAt: "2025-12-05T10:00:00Z",
      verificationNotes: "Verified via CNIC and bank statement",
      tenantId: PT,
    },
    {
      userId: investor2.id,
      country: "PK",
      label: "MCB Islamic Account",
      accountHolderName: "Ahmed Khan",
      bankName: "MCB Bank Limited",
      accountNumber: "98765432109876",
      branchCode: "0145",
      swiftCode: "MUCBPKKAXXX",
      currency: "PKR",
      status: "verified",
      isDefault: true,
      verifiedBy: admin.id,
      verifiedAt: "2025-11-20T10:00:00Z",
      verificationNotes: "Verified via CNIC and bank statement",
      tenantId: PT,
    },
    {
      userId: investor2.id,
      country: "UAE",
      label: "ENBD Account",
      accountHolderName: "Ahmed Khan",
      iban: "AE460261234567890123456",
      bankName: "Emirates NBD",
      swiftCode: "EABORAEXXX",
      currency: "AED",
      status: "pending",
      isDefault: false,
      tenantId: PT,
    },
    {
      userId: investor3.id,
      country: "PK",
      label: "UBL Current Account",
      accountHolderName: "Fatima Ali",
      bankName: "United Bank Limited (UBL)",
      accountNumber: "55667788990011",
      branchCode: "0230",
      swiftCode: "UNABORPKAXXX",
      currency: "PKR",
      status: "pending",
      isDefault: true,
      tenantId: PT,
    },
  ]);

  await db.insert(userCountryProfiles).values([
    { userId: investor1.id, countryCode: "AE", isPrimary: true, residencyStatus: "resident", taxResidency: true, addressLine1: "Tower 1, Apt 2305, DIFC", city: "Dubai", postalCode: "506100", phoneCountryCode: "+971", phoneNumber: "501234567", tenantId: PT },
    { userId: investor1.id, countryCode: "PK", isPrimary: false, residencyStatus: "citizen", taxResidency: false, addressLine1: "House 42, F-7/2", city: "Islamabad", stateProvince: "ICT", postalCode: "44000", phoneCountryCode: "+92", phoneNumber: "3001234567", tenantId: PT },
    { userId: investor2.id, countryCode: "PK", isPrimary: true, residencyStatus: "citizen", taxResidency: true, addressLine1: "Block 7, Clifton", city: "Karachi", stateProvince: "Sindh", postalCode: "75600", phoneCountryCode: "+92", phoneNumber: "3009876543", tenantId: PT },
    { userId: investor2.id, countryCode: "AE", isPrimary: false, residencyStatus: "resident", taxResidency: false, addressLine1: "Marina Walk, Tower B, Apt 1201", city: "Dubai", postalCode: "507100", phoneCountryCode: "+971", phoneNumber: "559876543", tenantId: PT },
    { userId: investor3.id, countryCode: "PK", isPrimary: true, residencyStatus: "citizen", taxResidency: true, addressLine1: "Model Town Extension", city: "Lahore", stateProvince: "Punjab", postalCode: "54700", phoneCountryCode: "+92", phoneNumber: "3211234567", tenantId: PT },
    { userId: admin.id, countryCode: "AE", isPrimary: true, residencyStatus: "resident", taxResidency: true, addressLine1: "Office 501, Al Manara Tower", city: "Dubai", postalCode: "506200", phoneCountryCode: "+971", phoneNumber: "509876543", tenantId: PT },
    { userId: issuer1.id, countryCode: "AE", isPrimary: true, residencyStatus: "resident", taxResidency: true, addressLine1: "Emaar Square, Building 1", city: "Dubai", postalCode: "371000", phoneCountryCode: "+971", phoneNumber: "504567890", tenantId: PT },
    { userId: issuer2.id, countryCode: "PK", isPrimary: true, residencyStatus: "citizen", taxResidency: true, addressLine1: "Bahria Town Head Office, Main Jinnah Avenue", city: "Karachi", stateProvince: "Sindh", postalCode: "75500", phoneCountryCode: "+92", phoneNumber: "3331234567", tenantId: PT },
    { userId: agent1.id, countryCode: "AE", isPrimary: true, residencyStatus: "resident", taxResidency: true, addressLine1: "Business Bay, Aspect Tower", city: "Dubai", postalCode: "507300", phoneCountryCode: "+971", phoneNumber: "551234567", tenantId: PT },
  ]);

  const fxPairs = [
    { from: "PKR", to: "AED", rate: "0.01320000", spread: "0.005000" },
    { from: "AED", to: "PKR", rate: "75.76000000", spread: "0.005000" },
    { from: "GBP", to: "AED", rate: "4.65000000", spread: "0.003000" },
    { from: "AED", to: "GBP", rate: "0.21500000", spread: "0.003000" },
    { from: "GBP", to: "PKR", rate: "352.27000000", spread: "0.006000" },
    { from: "PKR", to: "GBP", rate: "0.00284000", spread: "0.006000" },
    { from: "USD", to: "AED", rate: "3.67300000", spread: "0.002000" },
    { from: "AED", to: "USD", rate: "0.27225000", spread: "0.002000" },
    { from: "USD", to: "PKR", rate: "278.50000000", spread: "0.005000" },
    { from: "PKR", to: "USD", rate: "0.00359000", spread: "0.005000" },
    { from: "QAR", to: "AED", rate: "1.00800000", spread: "0.002000" },
    { from: "AED", to: "QAR", rate: "0.99200000", spread: "0.002000" },
    { from: "QAR", to: "PKR", rate: "76.53000000", spread: "0.006000" },
    { from: "PKR", to: "QAR", rate: "0.01307000", spread: "0.006000" },
    { from: "GBP", to: "USD", rate: "1.26500000", spread: "0.003000" },
    { from: "USD", to: "GBP", rate: "0.79050000", spread: "0.003000" },
    { from: "QAR", to: "GBP", rate: "0.21700000", spread: "0.004000" },
    { from: "GBP", to: "QAR", rate: "4.60800000", spread: "0.004000" },
    { from: "QAR", to: "USD", rate: "0.27470000", spread: "0.002000" },
    { from: "USD", to: "QAR", rate: "3.64100000", spread: "0.002000" },
    { from: "USDT", to: "USD", rate: "1.00000000", spread: "0.001000" },
    { from: "USD", to: "USDT", rate: "1.00000000", spread: "0.001000" },
    { from: "USDC", to: "USD", rate: "1.00000000", spread: "0.001000" },
    { from: "USD", to: "USDC", rate: "1.00000000", spread: "0.001000" },
    { from: "USDT", to: "AED", rate: "3.67300000", spread: "0.003000" },
    { from: "AED", to: "USDT", rate: "0.27225000", spread: "0.003000" },
    { from: "USDC", to: "AED", rate: "3.67300000", spread: "0.003000" },
    { from: "AED", to: "USDC", rate: "0.27225000", spread: "0.003000" },
    { from: "USDT", to: "PKR", rate: "278.50000000", spread: "0.006000" },
    { from: "PKR", to: "USDT", rate: "0.00359000", spread: "0.006000" },
    { from: "USDC", to: "PKR", rate: "278.50000000", spread: "0.006000" },
    { from: "PKR", to: "USDC", rate: "0.00359000", spread: "0.006000" },
    { from: "USDT", to: "GBP", rate: "0.79050000", spread: "0.004000" },
    { from: "GBP", to: "USDT", rate: "1.26500000", spread: "0.004000" },
    { from: "USDC", to: "GBP", rate: "0.79050000", spread: "0.004000" },
    { from: "GBP", to: "USDC", rate: "1.26500000", spread: "0.004000" },
    { from: "USDT", to: "QAR", rate: "3.64100000", spread: "0.003000" },
    { from: "QAR", to: "USDT", rate: "0.27470000", spread: "0.003000" },
    { from: "USDC", to: "QAR", rate: "3.64100000", spread: "0.003000" },
    { from: "QAR", to: "USDC", rate: "0.27470000", spread: "0.003000" },
    { from: "USDT", to: "USDC", rate: "1.00000000", spread: "0.000500" },
    { from: "USDC", to: "USDT", rate: "1.00000000", spread: "0.000500" },
  ];

  await db.insert(fxRates).values(
    fxPairs.map(p => ({
      fromCurrency: p.from,
      toCurrency: p.to,
      rate: p.rate,
      spread: p.spread,
      provider: "manual",
      sourceLabel: "VestBlock seed data",
      isActive: true,
      tenantId: PT,
    }))
  );

  await db.insert(receivingBankAccounts).values([
    { countryCode: "AE", currency: "AED", bankName: "Emirates NBD", accountName: "VestBlock Investment Holdings LLC", iban: "AE07 0260 0010 1234 5678 901", swiftCode: "EABORAEXXX", branch: "Dubai International Financial Centre", notes: "Primary AED receiving account", updatedBy: admin.id, tenantId: PT },
    { countryCode: "PK", currency: "PKR", bankName: "Habib Bank Limited (HBL)", accountName: "VestBlock Pakistan (Pvt) Ltd", iban: "PK36 HABB 0012 3456 7890 1234", swiftCode: "HABORPKAXXX", branch: "Karachi Main Branch, I.I. Chundrigar Road", notes: "Primary PKR receiving account", updatedBy: admin.id, tenantId: PT },
  ]);

  await db.insert(marketplaceCountrySettings).values([
    { countryCode: "PK", isVisible: true, displayOrder: 1, tenantId: PT },
    { countryCode: "AE", isVisible: true, displayOrder: 2, tenantId: PT },
    { countryCode: "GB", isVisible: false, displayOrder: 3, tenantId: PT },
    { countryCode: "US", isVisible: false, displayOrder: 4, tenantId: PT },
    { countryCode: "QA", isVisible: false, displayOrder: 5, tenantId: PT },
  ]);

  await db.insert(legalDocuments).values([
    { type: "terms_of_service", title: "Terms of Service - Pakistan", content: "These Terms of Service govern your use of VestBlock's tokenized investment platform within Pakistan. By using our services, you agree to comply with all applicable Pakistani securities laws and regulations enforced by the Securities and Exchange Commission of Pakistan (SECP). All investments are subject to SECP guidelines and applicable taxation under Pakistani law. Users must be at least 18 years of age and hold a valid CNIC or NICOP. VestBlock operates as a licensed intermediary for digital asset transactions within Pakistan. All disputes shall be resolved under the jurisdiction of Pakistani courts.", version: 1, effectiveDate: "2025-01-01", country: "PK", tenantId: PT },
    { type: "privacy_policy", title: "Privacy Policy - Pakistan", content: "This Privacy Policy describes how VestBlock collects, uses, and protects your personal data in compliance with Pakistani data protection regulations and SECP requirements. We collect CNIC details, bank account information, and transaction data as required by Pakistani regulatory authorities. Your data is stored within secure infrastructure and shared only with authorized regulatory bodies including SECP, FBR, and State Bank of Pakistan when legally required.", version: 1, effectiveDate: "2025-01-01", country: "PK", tenantId: PT },
    { type: "risk_disclosure", title: "Risk Disclosure Statement - Pakistan", content: "Investing in tokenized securities involves significant risks. The value of investments may fluctuate and you may lose some or all of your invested capital. Pakistani Rupee (PKR) denominated investments are subject to currency risk, market volatility, and regulatory changes by SECP. Past performance is not indicative of future results. Tokenized securities are a relatively new asset class in Pakistan and may have limited liquidity.", version: 1, effectiveDate: "2025-01-01", country: "PK", tenantId: PT },
    { type: "terms_of_service", title: "Terms of Service - UAE", content: "These Terms of Service govern your use of VestBlock's tokenized investment platform within the United Arab Emirates. By using our services, you agree to comply with all applicable UAE securities laws and regulations enforced by the Securities and Commodities Authority (SCA) and the Dubai Financial Services Authority (DFSA) within the DIFC.", version: 1, effectiveDate: "2025-01-01", country: "AE", tenantId: PT },
    { type: "privacy_policy", title: "Privacy Policy - UAE", content: "This Privacy Policy describes how VestBlock collects, uses, and protects your personal data in compliance with UAE Federal Decree-Law No. 45 of 2021 on Personal Data Protection and DFSA data protection regulations. We collect Emirates ID details, passport information, and financial data as required by UAE regulatory authorities.", version: 1, effectiveDate: "2025-01-01", country: "AE", tenantId: PT },
    { type: "risk_disclosure", title: "Risk Disclosure Statement - UAE", content: "Investing in tokenized securities involves significant risks. The value of investments denominated in AED may fluctuate due to market conditions, regulatory changes, and economic factors. Real estate tokenization in the UAE is subject to RERA and DLD regulations. Past performance does not guarantee future results.", version: 1, effectiveDate: "2025-01-01", country: "AE", tenantId: PT },
    { type: "terms_of_service", title: "Terms of Service - United Kingdom", content: "These Terms of Service govern your use of VestBlock's tokenized investment platform within the United Kingdom. By using our services, you agree to comply with all applicable UK financial regulations enforced by the Financial Conduct Authority (FCA). All investments are classified under the Financial Services and Markets Act 2000 (FSMA). Capital at risk.", version: 1, effectiveDate: "2025-01-01", country: "GB", tenantId: PT },
    { type: "privacy_policy", title: "Privacy Policy - United Kingdom", content: "This Privacy Policy describes how VestBlock collects, uses, and protects your personal data in compliance with the UK General Data Protection Regulation (UK GDPR) and the Data Protection Act 2018. We collect identity verification documents, financial information, and transaction data as required by FCA regulations.", version: 1, effectiveDate: "2025-01-01", country: "GB", tenantId: PT },
    { type: "risk_disclosure", title: "Risk Disclosure Statement - United Kingdom", content: "Capital at risk. Investing in tokenized securities involves significant risks including total loss of capital. GBP-denominated investments are subject to market volatility, interest rate changes, and regulatory developments. The FCA does not regulate all aspects of tokenized securities. Past performance is not a reliable indicator of future results.", version: 1, effectiveDate: "2025-01-01", country: "GB", tenantId: PT },
    { type: "terms_of_service", title: "Terms of Service - United States", content: "These Terms of Service govern your use of VestBlock's tokenized investment platform within the United States. By using our services, you agree to comply with all applicable US federal and state securities laws, including regulations enforced by the Securities and Exchange Commission (SEC).", version: 1, effectiveDate: "2025-01-01", country: "US", tenantId: PT },
    { type: "privacy_policy", title: "Privacy Policy - United States", content: "This Privacy Policy describes how VestBlock collects, uses, and protects your personal data in compliance with applicable US federal and state privacy laws, including CCPA (California Consumer Privacy Act) and other state privacy frameworks.", version: 1, effectiveDate: "2025-01-01", country: "US", tenantId: PT },
    { type: "risk_disclosure", title: "Risk Disclosure Statement - United States", content: "Investing in tokenized securities involves substantial risk of loss. USD-denominated investments are subject to market risk, credit risk, liquidity risk, and regulatory risk. Securities offered under Regulation D are restricted securities and cannot be freely traded. Past performance does not guarantee future results.", version: 1, effectiveDate: "2025-01-01", country: "US", tenantId: PT },
    { type: "terms_of_service", title: "Terms of Service - Qatar", content: "These Terms of Service govern your use of VestBlock's tokenized investment platform within Qatar. By using our services, you agree to comply with all applicable Qatari securities laws and regulations enforced by the Qatar Financial Centre Regulatory Authority (QFCRA) and the Qatar Financial Markets Authority (QFMA).", version: 1, effectiveDate: "2025-01-01", country: "QA", tenantId: PT },
    { type: "privacy_policy", title: "Privacy Policy - Qatar", content: "This Privacy Policy describes how VestBlock collects, uses, and protects your personal data in compliance with QFC Data Protection Regulations 2005 and Qatar Law No. 13 of 2016 on Personal Data Privacy Protection.", version: 1, effectiveDate: "2025-01-01", country: "QA", tenantId: PT },
    { type: "risk_disclosure", title: "Risk Disclosure Statement - Qatar", content: "Investing in tokenized securities involves significant risks. QAR-denominated investments are subject to market volatility, regulatory changes, and economic conditions. Real estate and infrastructure tokenization in Qatar is subject to QFCRA oversight. Past performance is not indicative of future results.", version: 1, effectiveDate: "2025-01-01", country: "QA", tenantId: PT },
  ]);

  log("Database seeded successfully");

  await seedCmsData();
}

export async function seedDefaultFeeSchedules() {
  const existing = await db.select().from(feeSchedules);
  if (existing.length > 0) {
    return;
  }

  log("Seeding default fee schedules...");

  const defaults: Array<{ feeType: string; rate: string; method: string; flatAmount: string; notes: string }> = [
    { feeType: "acquisition", rate: "0.02", method: "percentage", flatAmount: "0", notes: "Default 2% acquisition/structuring fee on committed capital" },
    { feeType: "management", rate: "0.02", method: "percentage", flatAmount: "0", notes: "Default 2% annual management fee on AUM" },
    { feeType: "rental_processing", rate: "0.01", method: "percentage", flatAmount: "0", notes: "Default 1% fee on rental distribution payouts" },
    { feeType: "property_sale", rate: "0.015", method: "percentage", flatAmount: "0", notes: "Default 1.5% fee on property sale/disposal proceeds" },
    { feeType: "exit_trade_buyer", rate: "0.01", method: "percentage", flatAmount: "0", notes: "Default 1% buyer fee on secondary market trades" },
    { feeType: "exit_trade_seller", rate: "0.02", method: "percentage", flatAmount: "0", notes: "Default 2% seller fee on secondary market trades" },
    { feeType: "fx", rate: "0.01", method: "percentage", flatAmount: "0", notes: "Default 1% FX conversion spread" },
    { feeType: "withdrawal", rate: "0.005", method: "percentage", flatAmount: "0", notes: "Default 0.5% withdrawal processing fee" },
    { feeType: "investment", rate: "0.005", method: "percentage", flatAmount: "0", notes: "Default 0.5% investment processing fee" },
    { feeType: "issuer_onboarding", rate: "0", method: "flat", flatAmount: "300000", notes: "Default 3 lakh PKR institutional onboarding fee covering due diligence, tokenization setup, and legal onboarding" },
    { feeType: "performance_fee", rate: "0.20", method: "percentage", flatAmount: "0", notes: "Default 20% performance fee on excess yield above hurdle rate" },
    { feeType: "valuation_uplift", rate: "0.02", method: "percentage", flatAmount: "0", notes: "Default 2% success fee on capital gains at property sale" },
    { feeType: "premium_membership", rate: "0", method: "flat", flatAmount: "50000", notes: "Default 50,000 PKR annual premium investor membership subscription" },
  ];

  for (const def of defaults) {
    await db.insert(feeSchedules).values({
      vehicleId: null,
      feeType: def.feeType,
      currency: "*",
      method: def.method,
      rate: def.rate,
      flatAmount: def.flatAmount,
      tiers: null,
      minFee: null,
      maxFee: null,
      version: 1,
      isActive: true,
      effectiveFrom: new Date(),
      createdBy: "system",
      notes: def.notes,
    });
  }

  log(`Seeded ${defaults.length} default fee schedules`);
}

export async function seedExtendedData() {
  const existingUsers = await db.select().from(users);
  const hasExtendedUsers = existingUsers.some(u => u.username === "khalid_malik");
  const existingProjects = await db.select().from(projects);
  if (hasExtendedUsers && existingProjects.length > 0) {
    log("Extended data already seeded, skipping");
    return;
  }

  log("Seeding extended data for agents, agency, and managers...");

  const defaultHash = await hashPassword("password123");
  const PT = PLATFORM_TENANT_ID;

  const allUsers = await db.select().from(users);
  const adminUser = allUsers.find(u => u.username === "admin");
  const omar = allUsers.find(u => u.username === "omar_rashid");
  const sarah = allUsers.find(u => u.username === "sarah_johnson");
  const ahmed = allUsers.find(u => u.username === "ahmed_khan");
  const fatima = allUsers.find(u => u.username === "fatima_ali");

  if (!adminUser || !omar || !sarah || !ahmed) {
    log("Required users not found, skipping extended seed");
    return;
  }

  const allAssets = await db.select().from(assets);
  const dmtr = allAssets.find(a => a.symbol === "DMTR");
  const btkr = allAssets.find(a => a.symbol === "BTKR");
  const ddrm = allAssets.find(a => a.symbol === "DDRM");
  const ailh = allAssets.find(a => a.symbol === "AILH");

  if (!dmtr || !btkr || !ddrm) {
    log("Required assets not found, skipping extended seed");
    return;
  }

  async function getOrCreateUser(data: any) {
    const existing = allUsers.find(u => u.username === data.username);
    if (existing) return existing;
    const [created] = await db.insert(users).values(data).returning();
    return created;
  }

  const agent2 = await getOrCreateUser({ username: "khalid_malik", password: defaultHash, email: "khalid@vestblock.io", fullName: "Khalid Malik", role: "agent", kycStatus: "verified", tenantId: PT });
  const agent3 = await getOrCreateUser({ username: "aisha_rahman", password: defaultHash, email: "aisha@vestblock.io", fullName: "Aisha Rahman", role: "agent", kycStatus: "verified", tenantId: PT });
  const investor4 = await getOrCreateUser({ username: "james_wilson", password: defaultHash, email: "james@example.com", fullName: "James Wilson", role: "investor", kycStatus: "verified", tenantId: PT });
  const investor5 = await getOrCreateUser({ username: "lisa_chen", password: defaultHash, email: "lisa@example.com", fullName: "Lisa Chen", role: "investor", kycStatus: "verified", tenantId: PT });
  const investor6 = await getOrCreateUser({ username: "robert_kim", password: defaultHash, email: "robert@example.com", fullName: "Robert Kim", role: "investor", kycStatus: "pending", tenantId: PT });
  const investor7 = await getOrCreateUser({ username: "maria_santos", password: defaultHash, email: "maria@example.com", fullName: "Maria Santos", role: "investor", kycStatus: "verified", tenantId: PT });
  const investor8 = await getOrCreateUser({ username: "tariq_hussain", password: defaultHash, email: "tariq@example.com", fullName: "Tariq Hussain", role: "investor", kycStatus: "verified", tenantId: PT });
  const agencyMgr = await getOrCreateUser({ username: "agency_manager", password: defaultHash, email: "manager@vestblock.io", fullName: "Nadia Al-Farsi", role: "admin", platformRole: "PLATFORM_ADMIN", kycStatus: "verified", tenantId: PT });

  const existingTenantUsers = await db.select().from(tenantUsers);
  const tuSet = new Set(existingTenantUsers.map(tu => tu.userId));
  const newTUs = [
    { tenantId: PT, userId: agencyMgr.id, role: "TENANT_ADMIN" as const },
    { tenantId: PT, userId: agent2.id, role: "TENANT_USER" as const },
    { tenantId: PT, userId: agent3.id, role: "TENANT_USER" as const },
    { tenantId: PT, userId: omar.id, role: "TENANT_USER" as const },
  ].filter(tu => !tuSet.has(tu.userId));
  if (newTUs.length > 0) {
    await db.insert(tenantUsers).values(newTUs);
  }

  // Agent assignments removed - registered_agent column not on users table

  await db.insert(kycProfiles).values([
    { userId: investor4.id, status: "APPROVED", legalName: "James William Wilson", dob: "1985-03-14", address: "Tower 2, Apt 1501, JBR, Dubai, UAE", idType: "passport", idNumber: "US8374652", emiratesIdFlag: false, sourceOfWealth: "Business ownership", sourceOfFunds: "Company dividends", pepFlag: false, riskScore: 25, submittedAt: "2025-10-20T09:00:00Z", reviewedAt: "2025-10-22T14:00:00Z", reviewNotes: "All documents verified", tenantId: PT },
    { userId: investor5.id, status: "APPROVED", legalName: "Lisa Wei Chen", dob: "1990-07-22", address: "Marina Walk, Tower A, Apt 802, Dubai, UAE", idType: "passport", idNumber: "CN6283741", emiratesIdFlag: false, sourceOfWealth: "Employment - Tech Industry", sourceOfFunds: "Salary and savings", pepFlag: false, riskScore: 15, submittedAt: "2025-11-01T10:00:00Z", reviewedAt: "2025-11-03T11:00:00Z", reviewNotes: "Low risk profile", tenantId: PT },
    { userId: investor6.id, status: "PENDING", legalName: "Robert Jin Kim", dob: "1988-11-30", address: "Business Bay, Executive Tower, Dubai, UAE", idType: "emirates_id", idNumber: "784-1988-1234567-8", emiratesIdFlag: true, sourceOfWealth: "Employment", sourceOfFunds: "Salary", pepFlag: false, submittedAt: "2026-02-10T08:00:00Z", tenantId: PT },
    { userId: investor7.id, status: "APPROVED", legalName: "Maria Elena Santos", dob: "1992-04-18", address: "Palm Jumeirah, Shoreline Apartments, Dubai, UAE", idType: "passport", idNumber: "PH2847361", emiratesIdFlag: false, sourceOfWealth: "Investment returns", sourceOfFunds: "Portfolio income", pepFlag: false, riskScore: 20, submittedAt: "2025-12-01T10:00:00Z", reviewedAt: "2025-12-03T15:00:00Z", reviewNotes: "Verified - experienced investor", tenantId: PT },
    { userId: investor8.id, status: "APPROVED", legalName: "Tariq Hussain", dob: "1980-06-25", address: "DHA Phase 5, House 12, Lahore, Pakistan", idType: "cnic", idNumber: "35201-1234567-1", emiratesIdFlag: false, sourceOfWealth: "Business ownership - Textiles", sourceOfFunds: "Business revenue", pepFlag: false, riskScore: 30, submittedAt: "2025-11-15T10:00:00Z", reviewedAt: "2025-11-18T12:00:00Z", reviewNotes: "Background check passed", tenantId: PT },
    { userId: agent2.id, status: "APPROVED", legalName: "Khalid Malik", dob: "1987-09-12", address: "Al Nahda, Sharjah, UAE", idType: "emirates_id", idNumber: "784-1987-9876543-2", emiratesIdFlag: true, sourceOfWealth: "Employment - Financial Services", sourceOfFunds: "Salary", pepFlag: false, riskScore: 10, submittedAt: "2025-09-01T10:00:00Z", reviewedAt: "2025-09-03T14:00:00Z", reviewNotes: "Agent onboarding - verified", tenantId: PT },
    { userId: agent3.id, status: "APPROVED", legalName: "Aisha Rahman", dob: "1993-02-08", address: "Gulberg III, Lahore, Pakistan", idType: "cnic", idNumber: "35202-5678901-2", emiratesIdFlag: false, sourceOfWealth: "Employment - Real Estate", sourceOfFunds: "Commission income", pepFlag: false, riskScore: 15, submittedAt: "2025-09-10T10:00:00Z", reviewedAt: "2025-09-12T11:00:00Z", reviewNotes: "Agent onboarding - approved", tenantId: PT },
  ]);

  const [wa4aed] = await db.insert(walletAccounts).values({ userId: investor4.id, currency: "AED", tenantId: PT }).returning();
  const [wa5aed] = await db.insert(walletAccounts).values({ userId: investor5.id, currency: "AED", tenantId: PT }).returning();
  const [wa6aed] = await db.insert(walletAccounts).values({ userId: investor6.id, currency: "AED", tenantId: PT }).returning();
  const [wa7aed] = await db.insert(walletAccounts).values({ userId: investor7.id, currency: "AED", tenantId: PT }).returning();
  const [wa8pkr] = await db.insert(walletAccounts).values({ userId: investor8.id, currency: "PKR", tenantId: PT }).returning();
  const [wa8aed] = await db.insert(walletAccounts).values({ userId: investor8.id, currency: "AED", tenantId: PT }).returning();

  await db.insert(walletTransactions).values([
    { walletAccountId: wa4aed.id, type: "DEPOSIT", amount: "100000.00", currency: "AED", status: "COMPLETED", description: "Initial deposit", referenceId: "DEP-JW-001", createdAt: "2025-11-01T10:00:00Z", tenantId: PT },
    { walletAccountId: wa4aed.id, type: "INVEST_RESERVE", amount: "25000.00", currency: "AED", status: "COMPLETED", description: "Reserved for DMTR (100 tokens)", referenceId: "INV-JW-001", createdAt: "2025-11-10T10:00:00Z", tenantId: PT },
    { walletAccountId: wa4aed.id, type: "INVEST_CAPTURE", amount: "25000.00", currency: "AED", status: "COMPLETED", description: "Captured DMTR investment", referenceId: "INV-JW-001", createdAt: "2025-11-10T10:01:00Z", tenantId: PT },
    { walletAccountId: wa5aed.id, type: "DEPOSIT", amount: "200000.00", currency: "AED", status: "COMPLETED", description: "Bank transfer deposit", referenceId: "DEP-LC-001", createdAt: "2025-10-15T10:00:00Z", tenantId: PT },
    { walletAccountId: wa5aed.id, type: "INVEST_RESERVE", amount: "50000.00", currency: "AED", status: "COMPLETED", description: "Reserved for DDRM (100 tokens)", referenceId: "INV-LC-001", createdAt: "2025-10-20T10:00:00Z", tenantId: PT },
    { walletAccountId: wa5aed.id, type: "INVEST_CAPTURE", amount: "50000.00", currency: "AED", status: "COMPLETED", description: "Captured DDRM investment", referenceId: "INV-LC-001", createdAt: "2025-10-20T10:01:00Z", tenantId: PT },
    { walletAccountId: wa5aed.id, type: "INVEST_RESERVE", amount: "35000.00", currency: "AED", status: "COMPLETED", description: "Reserved for AILH (100 tokens)", referenceId: "INV-LC-002", createdAt: "2025-11-05T10:00:00Z", tenantId: PT },
    { walletAccountId: wa5aed.id, type: "INVEST_CAPTURE", amount: "35000.00", currency: "AED", status: "COMPLETED", description: "Captured AILH investment", referenceId: "INV-LC-002", createdAt: "2025-11-05T10:01:00Z", tenantId: PT },
    { walletAccountId: wa5aed.id, type: "DIVIDEND", amount: "2800.00", currency: "AED", status: "COMPLETED", description: "Q4 2025 dividend - DDRM", referenceId: "DIV-LC-001", createdAt: "2026-01-15T08:00:00Z", tenantId: PT },
    { walletAccountId: wa6aed.id, type: "DEPOSIT", amount: "50000.00", currency: "AED", status: "COMPLETED", description: "Wire transfer deposit", referenceId: "DEP-RK-001", createdAt: "2026-01-20T10:00:00Z", tenantId: PT },
    { walletAccountId: wa7aed.id, type: "DEPOSIT", amount: "150000.00", currency: "AED", status: "COMPLETED", description: "Initial deposit via ADCB", referenceId: "DEP-MS-001", createdAt: "2025-11-01T10:00:00Z", tenantId: PT },
    { walletAccountId: wa7aed.id, type: "INVEST_RESERVE", amount: "25000.00", currency: "AED", status: "COMPLETED", description: "Reserved for DMTR (100 tokens)", referenceId: "INV-MS-001", createdAt: "2025-11-15T10:00:00Z", tenantId: PT },
    { walletAccountId: wa7aed.id, type: "INVEST_CAPTURE", amount: "25000.00", currency: "AED", status: "COMPLETED", description: "Captured DMTR investment", referenceId: "INV-MS-001", createdAt: "2025-11-15T10:01:00Z", tenantId: PT },
    { walletAccountId: wa7aed.id, type: "INVEST_RESERVE", amount: "37500.00", currency: "AED", status: "COMPLETED", description: "Reserved for DDRM (75 tokens)", referenceId: "INV-MS-002", createdAt: "2025-12-01T10:00:00Z", tenantId: PT },
    { walletAccountId: wa7aed.id, type: "INVEST_CAPTURE", amount: "37500.00", currency: "AED", status: "COMPLETED", description: "Captured DDRM investment", referenceId: "INV-MS-002", createdAt: "2025-12-01T10:01:00Z", tenantId: PT },
    { walletAccountId: wa8pkr.id, type: "DEPOSIT", amount: "5000000.00", currency: "PKR", status: "COMPLETED", description: "HBL deposit", referenceId: "DEP-TH-001", createdAt: "2025-11-20T10:00:00Z", tenantId: PT },
    { walletAccountId: wa8pkr.id, type: "INVEST_RESERVE", amount: "500000.00", currency: "PKR", status: "COMPLETED", description: "Reserved for BTKR (100 tokens)", referenceId: "INV-TH-001", createdAt: "2025-12-01T10:00:00Z", tenantId: PT },
    { walletAccountId: wa8pkr.id, type: "INVEST_CAPTURE", amount: "500000.00", currency: "PKR", status: "COMPLETED", description: "Captured BTKR investment", referenceId: "INV-TH-001", createdAt: "2025-12-01T10:01:00Z", tenantId: PT },
    { walletAccountId: wa8aed.id, type: "DEPOSIT", amount: "80000.00", currency: "AED", status: "COMPLETED", description: "AED deposit via FAB", referenceId: "DEP-TH-002", createdAt: "2025-12-10T10:00:00Z", tenantId: PT },
  ]);

  await db.insert(portfolioItems).values([
    { userId: investor4.id, assetId: dmtr.id, quantity: "100", averageCost: "250.00", tenantId: PT },
    { userId: investor5.id, assetId: ddrm.id, quantity: "100", averageCost: "500.00", tenantId: PT },
    { userId: investor5.id, assetId: ailh!.id, quantity: "100", averageCost: "350.00", tenantId: PT },
    { userId: investor7.id, assetId: dmtr.id, quantity: "100", averageCost: "250.00", tenantId: PT },
    { userId: investor7.id, assetId: ddrm.id, quantity: "75", averageCost: "500.00", tenantId: PT },
    { userId: investor8.id, assetId: btkr.id, quantity: "100", averageCost: "5000.00", tenantId: PT },
  ]);

  await db.insert(transactions).values([
    { userId: investor4.id, assetId: dmtr.id, type: "purchase", amount: "25000", status: "completed", description: "Purchased 100 tokens of Dubai Marina Tower REIT via Agent Omar", tenantId: PT },
    { userId: investor5.id, assetId: ddrm.id, type: "purchase", amount: "50000", status: "completed", description: "Purchased 100 tokens of Downtown Dubai Retail Mall via Agent Omar", tenantId: PT },
    { userId: investor5.id, assetId: ailh!.id, type: "purchase", amount: "35000", status: "completed", description: "Purchased 100 tokens of Abu Dhabi Industrial Logistics Hub", tenantId: PT },
    { userId: investor6.id, type: "deposit", amount: "50000", status: "completed", description: "Wire transfer deposit", tenantId: PT },
    { userId: investor7.id, assetId: dmtr.id, type: "purchase", amount: "25000", status: "completed", description: "Purchased 100 tokens of DMTR via Agent Khalid", tenantId: PT },
    { userId: investor7.id, assetId: ddrm.id, type: "purchase", amount: "37500", status: "completed", description: "Purchased 75 tokens of DDRM via Agent Khalid", tenantId: PT },
    { userId: investor8.id, assetId: btkr.id, type: "purchase", amount: "500000", status: "completed", description: "Purchased 100 tokens of BTKR via Agent Aisha", tenantId: PT },
  ]);

  await db.insert(userCountryProfiles).values([
    { userId: investor4.id, countryCode: "AE", isPrimary: true, residencyStatus: "resident", taxResidency: true, addressLine1: "Tower 2, Apt 1501, JBR", city: "Dubai", postalCode: "506200", phoneCountryCode: "+971", phoneNumber: "501112233", tenantId: PT },
    { userId: investor5.id, countryCode: "AE", isPrimary: true, residencyStatus: "resident", taxResidency: true, addressLine1: "Marina Walk, Tower A, Apt 802", city: "Dubai", postalCode: "507100", phoneCountryCode: "+971", phoneNumber: "552233445", tenantId: PT },
    { userId: investor6.id, countryCode: "AE", isPrimary: true, residencyStatus: "resident", taxResidency: true, addressLine1: "Business Bay, Executive Tower", city: "Dubai", postalCode: "507200", phoneCountryCode: "+971", phoneNumber: "553344556", tenantId: PT },
    { userId: investor7.id, countryCode: "AE", isPrimary: true, residencyStatus: "resident", taxResidency: true, addressLine1: "Palm Jumeirah, Shoreline Apartments", city: "Dubai", postalCode: "507300", phoneCountryCode: "+971", phoneNumber: "554455667", tenantId: PT },
    { userId: investor8.id, countryCode: "PK", isPrimary: true, residencyStatus: "citizen", taxResidency: true, addressLine1: "DHA Phase 5, House 12", city: "Lahore", stateProvince: "Punjab", postalCode: "54000", phoneCountryCode: "+92", phoneNumber: "3001234567", tenantId: PT },
    { userId: investor8.id, countryCode: "AE", isPrimary: false, residencyStatus: "non_resident", taxResidency: false, addressLine1: "c/o VestBlock", city: "Dubai", postalCode: "506100", phoneCountryCode: "+971", phoneNumber: "555566778", tenantId: PT },
    { userId: agent2.id, countryCode: "AE", isPrimary: true, residencyStatus: "resident", taxResidency: true, addressLine1: "Al Nahda, Sharjah", city: "Sharjah", postalCode: "510100", phoneCountryCode: "+971", phoneNumber: "556677889", tenantId: PT },
    { userId: agent3.id, countryCode: "PK", isPrimary: true, residencyStatus: "citizen", taxResidency: true, addressLine1: "Gulberg III", city: "Lahore", stateProvince: "Punjab", postalCode: "54660", phoneCountryCode: "+92", phoneNumber: "3009876543", tenantId: PT },
    { userId: agencyMgr.id, countryCode: "AE", isPrimary: true, residencyStatus: "resident", taxResidency: true, addressLine1: "DIFC Gate Village, Building 3", city: "Dubai", postalCode: "506100", phoneCountryCode: "+971", phoneNumber: "507788990", tenantId: PT },
  ]);

  await db.insert(bankAccounts).values([
    { userId: investor4.id, country: "UAE", label: "FAB Savings", accountHolderName: "James Wilson", iban: "AE580340001234567890123", bankName: "First Abu Dhabi Bank", swiftCode: "NBABORAEXXX", currency: "AED", status: "verified", isDefault: true, verifiedBy: adminUser.id, verifiedAt: "2025-11-05T10:00:00Z", tenantId: PT },
    { userId: investor5.id, country: "UAE", label: "Mashreq Account", accountHolderName: "Lisa Chen", iban: "AE320460001234567890123", bankName: "Mashreq Bank", swiftCode: "BOMLAEAD", currency: "AED", status: "verified", isDefault: true, verifiedBy: adminUser.id, verifiedAt: "2025-10-18T10:00:00Z", tenantId: PT },
    { userId: investor7.id, country: "UAE", label: "ADCB Current", accountHolderName: "Maria Santos", iban: "AE140300001234567890123", bankName: "ADCB Bank", swiftCode: "ADCBORAEXXX", currency: "AED", status: "verified", isDefault: true, verifiedBy: adminUser.id, verifiedAt: "2025-11-10T10:00:00Z", tenantId: PT },
    { userId: investor8.id, country: "PK", label: "Meezan Bank", accountHolderName: "Tariq Hussain", bankName: "Meezan Bank Limited", accountNumber: "01234567890123", branchCode: "0021", swiftCode: "MEABORPKAXXX", currency: "PKR", status: "verified", isDefault: true, verifiedBy: adminUser.id, verifiedAt: "2025-11-22T10:00:00Z", tenantId: PT },
  ]);

  const [project1] = await db.insert(projects).values({
    tenantId: PT, name: "Dubai Marina Tower Tokenization", description: "Complete tokenization and investor onboarding for Dubai Marina Tower REIT", type: "TOKENIZATION", status: "IN_PROGRESS", startDate: "2025-10-01", dueDate: "2026-06-30", healthScore: 85, marketScore: 78, createdBy: adminUser.id,
  }).returning();

  const [project2] = await db.insert(projects).values({
    tenantId: PT, name: "Bahria Town Karachi Launch", description: "Regulatory approval and launch of Bahria Town Karachi residential token offering", type: "DEVELOPMENT", status: "IN_PROGRESS", startDate: "2025-09-15", dueDate: "2026-04-30", healthScore: 72, marketScore: 65, createdBy: adminUser.id,
  }).returning();

  const [project3] = await db.insert(projects).values({
    tenantId: PT, name: "Platform KYC Enhancement", description: "Upgrade KYC verification with AI-powered document validation and biometric checks", type: "DEVELOPMENT", status: "PLANNING", startDate: "2026-03-01", dueDate: "2026-08-31", healthScore: 100, marketScore: 50, createdBy: adminUser.id,
  }).returning();

  const [project4] = await db.insert(projects).values({
    tenantId: PT, name: "Downtown Dubai Retail Distribution", description: "Q1 2026 rental distribution processing for Downtown Dubai Retail Mall investors", type: "OPERATIONS", status: "COMPLETED", startDate: "2025-12-01", dueDate: "2026-01-31", healthScore: 100, marketScore: 82, createdBy: adminUser.id,
  }).returning();

  const [project5] = await db.insert(projects).values({
    tenantId: PT, name: "Abu Dhabi Logistics Expansion", description: "Additional warehouse acquisition and token issuance for KIZAD logistics hub", type: "TOKENIZATION", status: "PLANNING", startDate: "2026-04-01", dueDate: "2026-12-31", healthScore: 95, marketScore: 70, createdBy: adminUser.id,
  }).returning();

  const [project6] = await db.insert(projects).values({
    tenantId: PT, name: "Secondary Market Trading Platform", description: "Build and deploy peer-to-peer secondary market with exit window scheduling", type: "DEVELOPMENT", status: "ON_HOLD", startDate: "2025-11-01", dueDate: "2026-05-31", healthScore: 45, marketScore: 88, createdBy: adminUser.id,
  }).returning();

  await db.insert(projectMembers).values([
    { projectId: project1.id, userId: adminUser.id, role: "LEAD" },
    { projectId: project1.id, userId: omar.id, role: "DEV" },
    { projectId: project1.id, userId: agent2.id, role: "DEV" },
    { projectId: project2.id, userId: adminUser.id, role: "LEAD" },
    { projectId: project2.id, userId: agent3.id, role: "DEV" },
    { projectId: project2.id, userId: agencyMgr.id, role: "QA" },
    { projectId: project3.id, userId: adminUser.id, role: "LEAD" },
    { projectId: project3.id, userId: agencyMgr.id, role: "LEAD" },
    { projectId: project4.id, userId: adminUser.id, role: "LEAD" },
    { projectId: project4.id, userId: omar.id, role: "DEV" },
    { projectId: project5.id, userId: adminUser.id, role: "LEAD" },
    { projectId: project5.id, userId: agent2.id, role: "DEV" },
    { projectId: project6.id, userId: adminUser.id, role: "LEAD" },
    { projectId: project6.id, userId: agencyMgr.id, role: "QA" },
  ]);

  const activityDates = [
    "2026-01-15T09:00:00Z", "2026-01-18T14:30:00Z", "2026-01-22T11:00:00Z",
    "2026-01-28T16:00:00Z", "2026-02-01T10:00:00Z", "2026-02-03T09:30:00Z",
    "2026-02-05T14:00:00Z", "2026-02-08T11:30:00Z", "2026-02-10T16:00:00Z",
    "2026-02-12T10:00:00Z", "2026-02-14T13:00:00Z", "2026-02-16T09:00:00Z",
    "2026-02-17T15:30:00Z", "2026-02-18T10:00:00Z", "2026-02-19T08:30:00Z",
  ];

  await db.insert(projectActivityLogs).values([
    { projectId: project1.id, userId: adminUser.id, action: "Created project", details: "Initiated Dubai Marina Tower tokenization project", createdAt: "2025-10-01T09:00:00Z" },
    { projectId: project1.id, userId: omar.id, action: "Updated status", details: "Moved to IN_PROGRESS after DFSA approval received", createdAt: "2025-11-01T10:00:00Z" },
    { projectId: project1.id, userId: agent2.id, action: "Added investor lead", details: "Onboarded 3 new qualified investors", createdAt: activityDates[0] },
    { projectId: project1.id, userId: omar.id, action: "Distribution scheduled", details: "Q1 2026 dividend distribution configured", createdAt: activityDates[2] },
    { projectId: project1.id, userId: adminUser.id, action: "Milestone completed", details: "Token issuance Phase 1 complete - 7,200 tokens distributed", createdAt: activityDates[4] },
    { projectId: project2.id, userId: adminUser.id, action: "Created project", details: "Started Bahria Town Karachi regulatory submission", createdAt: "2025-09-15T09:00:00Z" },
    { projectId: project2.id, userId: agent3.id, action: "Document uploaded", details: "SECP submission documents prepared and uploaded", createdAt: activityDates[1] },
    { projectId: project2.id, userId: agencyMgr.id, action: "Review completed", details: "Legal compliance review passed", createdAt: activityDates[3] },
    { projectId: project2.id, userId: agent3.id, action: "Investor outreach", details: "Completed roadshow with 12 institutional investors", createdAt: activityDates[6] },
    { projectId: project3.id, userId: adminUser.id, action: "Created project", details: "KYC enhancement project initiated", createdAt: activityDates[5] },
    { projectId: project3.id, userId: agencyMgr.id, action: "Requirements defined", details: "Biometric verification requirements finalized", createdAt: activityDates[7] },
    { projectId: project4.id, userId: adminUser.id, action: "Distribution executed", details: "AED 340,000 distributed to 85 investors", createdAt: "2026-01-15T08:00:00Z" },
    { projectId: project4.id, userId: omar.id, action: "Project completed", details: "All distributions settled and confirmed", createdAt: "2026-01-31T17:00:00Z" },
    { projectId: project5.id, userId: adminUser.id, action: "Created project", details: "Abu Dhabi expansion planning started", createdAt: activityDates[8] },
    { projectId: project5.id, userId: agent2.id, action: "Market research", details: "Completed KIZAD warehouse availability analysis", createdAt: activityDates[10] },
    { projectId: project6.id, userId: adminUser.id, action: "Status changed", details: "Put on hold pending regulatory clarity on P2P trading", createdAt: activityDates[9] },
    { projectId: project6.id, userId: agencyMgr.id, action: "Risk assessment", details: "Secondary market risk framework drafted", createdAt: activityDates[11] },
  ]);

  const ewIds = await db.select({ id: exitWindows.id }).from(exitWindows).limit(3);

  if (ewIds.length > 0) {
    await db.insert(tradeListings).values([
      { exitWindowId: ewIds[0].id, assetId: dmtr.id, sellerId: sarah.id, quantity: "20", pricePerToken: "265.00", currency: "AED", remainingQuantity: "20", status: "active", tenantId: PT },
      { exitWindowId: ewIds[0].id, assetId: dmtr.id, sellerId: investor4.id, quantity: "10", pricePerToken: "260.00", currency: "AED", remainingQuantity: "0", status: "filled", buyerId: investor7.id, filledAt: "2026-02-10T14:00:00Z", tenantId: PT },
      { exitWindowId: ewIds.length > 1 ? ewIds[1].id : ewIds[0].id, assetId: ddrm.id, sellerId: investor5.id, quantity: "25", pricePerToken: "520.00", currency: "AED", remainingQuantity: "25", status: "active", tenantId: PT },
      { exitWindowId: ewIds.length > 1 ? ewIds[1].id : ewIds[0].id, assetId: ddrm.id, sellerId: investor7.id, quantity: "15", pricePerToken: "515.00", currency: "AED", remainingQuantity: "15", status: "active", tenantId: PT },
      { exitWindowId: ewIds.length > 2 ? ewIds[2].id : ewIds[0].id, assetId: btkr.id, sellerId: ahmed.id, quantity: "30", pricePerToken: "5300.00", currency: "PKR", remainingQuantity: "10", status: "partial", buyerId: investor8.id, tenantId: PT },
    ]);
  }

  await db.insert(notifications).values([
    { userId: omar.id, type: "referral", title: "New Client Registered", message: "James Wilson registered through your referral link and completed KYC verification.", tenantId: PT, createdAt: "2026-02-01T10:00:00Z" },
    { userId: omar.id, type: "commission", title: "Commission Earned", message: "You earned AED 625 commission on James Wilson's AED 25,000 investment in DMTR.", tenantId: PT, createdAt: "2026-02-02T10:00:00Z" },
    { userId: omar.id, type: "referral", title: "New Client Registered", message: "Lisa Chen registered through your referral link.", tenantId: PT, createdAt: "2025-10-16T10:00:00Z" },
    { userId: omar.id, type: "commission", title: "Commission Earned", message: "You earned AED 1,250 commission on Lisa Chen's AED 50,000 investment in DDRM.", tenantId: PT, createdAt: "2025-10-21T10:00:00Z" },
    { userId: agent2.id, type: "referral", title: "New Client Registered", message: "Ahmed Khan registered through your referral link.", tenantId: PT, createdAt: "2025-11-01T10:00:00Z" },
    { userId: agent2.id, type: "commission", title: "Commission Earned", message: "You earned AED 625 commission on Maria Santos' AED 25,000 investment in DMTR.", tenantId: PT, createdAt: "2025-11-16T10:00:00Z" },
    { userId: agent2.id, type: "referral", title: "Client KYC Pending", message: "Robert Kim's KYC is pending review. Follow up to ensure completion.", tenantId: PT, createdAt: "2026-02-11T10:00:00Z" },
    { userId: agent3.id, type: "referral", title: "New Client Registered", message: "Tariq Hussain registered through your referral link and completed KYC.", tenantId: PT, createdAt: "2025-11-16T10:00:00Z" },
    { userId: agent3.id, type: "commission", title: "Commission Earned", message: "You earned PKR 12,500 commission on Tariq Hussain's PKR 500,000 investment in BTKR.", tenantId: PT, createdAt: "2025-12-02T10:00:00Z" },
    { userId: agencyMgr.id, type: "system", title: "Monthly Platform Report", message: "January 2026 platform report is ready. Total AUM: AED 12.5M, Active investors: 8.", tenantId: PT, createdAt: "2026-02-01T08:00:00Z" },
    { userId: agencyMgr.id, type: "compliance", title: "KYC Review Required", message: "3 pending KYC applications require agency compliance review.", tenantId: PT, createdAt: "2026-02-12T09:00:00Z" },
    { userId: agencyMgr.id, type: "system", title: "New Agent Onboarded", message: "Khalid Malik has been onboarded as a sales agent. Background check completed.", tenantId: PT, createdAt: "2025-09-04T10:00:00Z" },
    { userId: investor4.id, type: "investment", title: "Investment Confirmed", message: "Your investment of AED 25,000 in Dubai Marina Tower REIT (100 tokens) has been confirmed.", tenantId: PT, createdAt: "2025-11-10T10:02:00Z" },
    { userId: investor5.id, type: "dividend", title: "Dividend Received", message: "You received AED 2,800 dividend payment from Downtown Dubai Retail Mall (Q4 2025).", tenantId: PT, createdAt: "2026-01-15T08:01:00Z" },
    { userId: investor7.id, type: "investment", title: "Investment Confirmed", message: "Your investment of AED 25,000 in Dubai Marina Tower REIT (100 tokens) has been confirmed.", tenantId: PT, createdAt: "2025-11-15T10:02:00Z" },
    { userId: investor8.id, type: "investment", title: "Investment Confirmed", message: "Your investment of PKR 500,000 in Bahria Town Karachi Residences (100 tokens) has been confirmed.", tenantId: PT, createdAt: "2025-12-01T10:02:00Z" },
  ]);

  await db.insert(supportTickets).values([
    { userId: omar.id, subject: "Commission report discrepancy", description: "My commission report for December shows AED 1,250 but I expected AED 1,500 based on the 2.5% rate agreed in my agent contract.", countryCode: "AE", currency: "AED", category: "billing", priority: "medium", status: "open", tenantId: PT },
    { userId: agent2.id, subject: "Client KYC taking too long", description: "Robert Kim submitted his KYC documents on Feb 10 but hasn't received approval yet. Can this be expedited?", countryCode: "AE", currency: "AED", category: "kyc", priority: "high", status: "open", tenantId: PT },
    { userId: agent3.id, subject: "Referral link not tracking", description: "Two investors mentioned they used my referral link but they don't appear in my client list. Their emails are zara@example.com and hassan@example.com.", countryCode: "PK", currency: "PKR", category: "technical", priority: "medium", status: "in_progress", adminNotes: "Investigating referral tracking system", tenantId: PT },
    { userId: investor4.id, subject: "Withdrawal processing time", description: "I submitted a withdrawal request 3 days ago and it's still pending. When can I expect the funds?", countryCode: "AE", currency: "AED", category: "withdrawal", priority: "medium", status: "resolved", resolvedBy: adminUser.id, resolvedAt: "2026-02-15T10:00:00Z", adminNotes: "Withdrawal processed successfully. Standard 3-5 business day processing time.", tenantId: PT },
    { userId: investor5.id, subject: "Dividend payment inquiry", description: "I received AED 2,800 as Q4 dividend for DDRM but expected higher based on 8.5% annual yield. Can you explain the calculation?", countryCode: "AE", currency: "AED", category: "distributions", priority: "low", status: "resolved", resolvedBy: adminUser.id, resolvedAt: "2026-01-20T14:00:00Z", adminNotes: "Dividend calculation explained: 100 tokens * 500 AED * 8.5% / 4 quarters * pro-rata 66% (Oct-Dec holding period).", tenantId: PT },
    { userId: investor8.id, subject: "Currency conversion rates", description: "When I convert PKR to AED for investing, the rate shown seems different from the market rate. Is there a spread applied?", countryCode: "PK", currency: "PKR", category: "fx", priority: "low", status: "open", tenantId: PT },
    { userId: agencyMgr.id, subject: "Agent performance report", description: "Please generate Q4 2025 performance reports for all agents showing client acquisition, AUM growth, and commission earned.", countryCode: "AE", currency: "AED", category: "reporting", priority: "medium", status: "in_progress", adminNotes: "Compiling report from analytics system", tenantId: PT },
  ]);

  log("Extended data seeded successfully: agents, agency manager, investors, projects, trade listings, notifications, support tickets");

  await seedBugBashData();
}

export async function seedBugBashData() {
  try {
    log("[BugBash] Starting bug-bash seed...");
    const PT = PLATFORM_TENANT_ID;
    const pw = await hashPassword("password123");

    async function getOrCreateBugBashUser(email: string, data: { username: string; fullName: string; role: string; platformRole?: string; kycStatus: string }) {
      const existing = await db.select().from(users).where(eq(users.email, email));
      if (existing.length > 0) return existing[0];
      const [created] = await db.insert(users).values({
        email,
        username: data.username,
        password: pw,
        fullName: data.fullName,
        role: data.role,
        platformRole: data.platformRole,
        kycStatus: data.kycStatus,
        tenantId: PT,
      }).returning();
      return created;
    }

    const superAdmin = await getOrCreateBugBashUser("admin@vestblock.test", { username: "vb_super_admin", fullName: "QA Super Admin", role: "admin", platformRole: "SUPER_ADMIN", kycStatus: "verified" });
    const webManager = await getOrCreateBugBashUser("web@vestblock.test", { username: "vb_web_manager", fullName: "QA Web Manager", role: "cms", kycStatus: "verified" });
    const manager = await getOrCreateBugBashUser("manager@vestblock.test", { username: "vb_manager", fullName: "QA Manager", role: "admin", platformRole: "PLATFORM_ADMIN", kycStatus: "verified" });
    const agent1 = await getOrCreateBugBashUser("agent1@vestblock.test", { username: "vb_agent1", fullName: "QA Agent One", role: "agent", kycStatus: "verified" });
    const agent2 = await getOrCreateBugBashUser("agent2@vestblock.test", { username: "vb_agent2", fullName: "QA Agent Two", role: "agent", kycStatus: "verified" });

    const clientNames = ["One", "Two", "Three", "Four", "Five"];
    const clients: any[] = [];
    for (let i = 1; i <= 5; i++) {
      const c = await getOrCreateBugBashUser(`client${i}@vestblock.test`, { username: `vb_client${i}`, fullName: `QA Client ${clientNames[i - 1]}`, role: "investor", kycStatus: "verified" });
      clients.push(c);
    }

    log("[BugBash] Users ready");

    const clientIds = clients.map(c => c.id);

    try {
      const [{ value: apptCount }] = await db.select({ value: count() }).from(appointments).where(
        sql`${appointments.userId} IN (${sql.join(clientIds.map(id => sql`${id}`), sql`, `)})`
      );
      if (Number(apptCount) < 5) {
        log("[BugBash] Seeding appointments...");
        const now = new Date();
        const apptData = [
          { userId: clients[0].id, assignedToUserId: agent1.id, datetime: new Date(now.getTime() + 86400000).toISOString(), mode: "virtual" as const, status: "REQUESTED", notes: "Initial consultation", tenantId: PT },
          { userId: clients[1].id, assignedToUserId: agent1.id, datetime: new Date(now.getTime() + 172800000).toISOString(), mode: "in_person" as const, status: "REQUESTED", notes: "Portfolio review", tenantId: PT },
          { userId: clients[2].id, assignedToUserId: agent2.id, datetime: new Date(now.getTime() + 259200000).toISOString(), mode: "phone" as const, status: "REQUESTED", notes: "KYC follow-up", tenantId: PT },
          { userId: clients[0].id, assignedToUserId: agent1.id, datetime: new Date(now.getTime() + 345600000).toISOString(), mode: "virtual" as const, status: "CONFIRMED", notes: "Investment strategy session", tenantId: PT },
          { userId: clients[1].id, assignedToUserId: agent2.id, datetime: new Date(now.getTime() + 432000000).toISOString(), mode: "in_person" as const, status: "CONFIRMED", notes: "Property viewing", tenantId: PT },
          { userId: clients[3].id, assignedToUserId: agent1.id, datetime: new Date(now.getTime() + 518400000).toISOString(), mode: "virtual" as const, status: "CONFIRMED", notes: "Onboarding call", tenantId: PT },
          { userId: clients[2].id, assignedToUserId: agent2.id, datetime: new Date(now.getTime() + 604800000).toISOString(), mode: "phone" as const, status: "RESCHEDULED", notes: "Rescheduled from last week", tenantId: PT },
          { userId: clients[4].id, assignedToUserId: agent1.id, datetime: new Date(now.getTime() - 86400000).toISOString(), mode: "virtual" as const, status: "CANCELLED", notes: "Client unavailable", tenantId: PT },
          { userId: clients[3].id, assignedToUserId: agent2.id, datetime: new Date(now.getTime() - 172800000).toISOString(), mode: "in_person" as const, status: "COMPLETED", notes: "Successful meeting", tenantId: PT },
          { userId: clients[4].id, assignedToUserId: agent1.id, datetime: new Date(now.getTime() - 259200000).toISOString(), mode: "virtual" as const, status: "COMPLETED", notes: "Account setup completed", tenantId: PT },
        ];
        await db.insert(appointments).values(apptData);
        log("[BugBash] 10 appointments created");
      }
    } catch (e) {
      log("[BugBash] Appointments seed error: " + (e as Error).message);
    }

    const apptRows = await db.select({ id: appointments.id }).from(appointments).where(
      sql`${appointments.userId} IN (${sql.join(clientIds.map(id => sql`${id}`), sql`, `)})`
    ).limit(3);

    try {
      const [{ value: txCount }] = await db.select({ value: count() }).from(transactions).where(
        sql`${transactions.userId} IN (${sql.join(clientIds.map(id => sql`${id}`), sql`, `)})`
      );
      if (Number(txCount) < 5) {
        log("[BugBash] Seeding transactions...");
        const txData = [
          { userId: clients[0].id, type: "purchase", amount: "50000.00", currency: "PKR", status: "pending_confirmation", description: "Token purchase - BTKR", tenantId: PT },
          { userId: clients[1].id, type: "deposit", amount: "25000.00", currency: "AED", status: "pending_confirmation", description: "Wallet deposit", tenantId: PT },
          { userId: clients[2].id, type: "purchase", amount: "100000.00", currency: "PKR", status: "pending_confirmation", description: "Token purchase - LSCP", tenantId: PT },
          { userId: clients[0].id, type: "deposit", amount: "10000.00", currency: "AED", status: "confirmed", description: "Bank transfer deposit", tenantId: PT },
          { userId: clients[1].id, type: "purchase", amount: "75000.00", currency: "PKR", status: "confirmed", description: "Token purchase - IBAO", tenantId: PT },
          { userId: clients[3].id, type: "deposit", amount: "5000.00", currency: "AED", status: "confirmed", description: "Wire transfer", tenantId: PT },
          { userId: clients[4].id, type: "purchase", amount: "30000.00", currency: "PKR", status: "confirmed", description: "Token purchase - DLMU", tenantId: PT },
          { userId: clients[2].id, type: "withdrawal", amount: "15000.00", currency: "AED", status: "failed", description: "Withdrawal rejected - insufficient balance", tenantId: PT },
          { userId: clients[3].id, type: "withdrawal", amount: "20000.00", currency: "PKR", status: "failed", description: "Withdrawal - bank details invalid", tenantId: PT },
          { userId: clients[4].id, type: "deposit", amount: "8000.00", currency: "AED", status: "pending", description: "Pending wire transfer", tenantId: PT },
        ];
        await db.insert(transactions).values(txData);
        log("[BugBash] 10 transactions created");
      }
    } catch (e) {
      log("[BugBash] Transactions seed error: " + (e as Error).message);
    }

    const txRows = await db.select({ id: transactions.id }).from(transactions).where(
      sql`${transactions.userId} IN (${sql.join(clientIds.map(id => sql`${id}`), sql`, `)})`
    ).limit(3);

    try {
      const [{ value: emailCount }] = await db.select({ value: count() }).from(emailLogs).where(like(emailLogs.toAddress, "%@vestblock.test"));
      if (Number(emailCount) < 10) {
        log("[BugBash] Seeding email logs...");
        const emailData: any[] = [];
        const subjects = [
          "Appointment Confirmation", "Appointment Reminder", "Appointment Cancelled",
          "Transaction Initiated", "Transaction Confirmed", "Transaction Failed",
          "KYC Verification Required", "Welcome to VestBlock", "Portfolio Update",
          "Distribution Payment Notification",
        ];
        const statuses = ["sent", "queued"];
        for (let i = 0; i < 30; i++) {
          const clientIdx = i % 5;
          const subjectIdx = i % subjects.length;
          const entry: any = {
            toAddress: `client${clientIdx + 1}@vestblock.test`,
            subject: subjects[subjectIdx],
            body: `<p>Dear QA Client ${clientNames[clientIdx]},</p><p>${subjects[subjectIdx]} - Test email #${i + 1}</p>`,
            status: statuses[i % 2],
            tenantId: PT,
          };
          if (i < 5 && apptRows.length > 0) {
            entry.relatedEntityType = "appointment";
            entry.relatedEntityId = apptRows[i % apptRows.length].id;
          } else if (i >= 5 && i < 10 && txRows.length > 0) {
            entry.relatedEntityType = "transaction";
            entry.relatedEntityId = txRows[(i - 5) % txRows.length].id;
          }
          emailData.push(entry);
        }
        await db.insert(emailLogs).values(emailData);
        log("[BugBash] 30 email logs created");
      }
    } catch (e) {
      log("[BugBash] Email logs seed error: " + (e as Error).message);
    }

    try {
      const [{ value: subCount }] = await db.select({ value: count() }).from(subscribers).where(like(subscribers.email, "%@vestblock.test"));
      if (Number(subCount) < 20) {
        log("[BugBash] Seeding subscribers...");
        const regions = ["PK", "AE", "GB", "US", "QA"];
        const subData = [];
        for (let i = 1; i <= 50; i++) {
          subData.push({
            email: `subscriber${i}@vestblock.test`,
            region: regions[(i - 1) % regions.length],
            source: "website",
            isActive: true,
          });
        }
        await db.insert(subscribers).values(subData).onConflictDoNothing();
        log("[BugBash] 50 subscribers created");
      }
    } catch (e) {
      log("[BugBash] Subscribers seed error: " + (e as Error).message);
    }

    try {
      const [{ value: campCount }] = await db.select({ value: count() }).from(campaigns).where(like(campaigns.subject, "QA %"));
      if (Number(campCount) < 2) {
        log("[BugBash] Seeding campaigns...");
        await db.insert(campaigns).values([
          { subject: "QA Draft Campaign - February Newsletter", body: "<h1>VestBlock Monthly Update</h1><p>This is a draft campaign for QA testing.</p>", segment: "all", recipientCount: 0, status: "draft", tenantId: PT, sentBy: webManager.id },
          { subject: "QA Sent Campaign - Welcome Series", body: "<h1>Welcome to VestBlock</h1><p>This is a sent campaign for QA testing.</p>", segment: "new_subscribers", recipientCount: 50, status: "sent", tenantId: PT, sentBy: webManager.id },
        ]);
        log("[BugBash] 2 campaigns created");
      }
    } catch (e) {
      log("[BugBash] Campaigns seed error: " + (e as Error).message);
    }

    try {
      const [{ value: auditCount }] = await db.select({ value: count() }).from(auditLogs).where(like(auditLogs.actorId, sql`(SELECT id FROM users WHERE username LIKE 'vb_%' LIMIT 1)`));
      const actorCheck = await db.select({ value: count() }).from(auditLogs).where(
        sql`${auditLogs.actorId} IN (${sql.join([superAdmin.id, manager.id, agent1.id, agent2.id, clients[0].id].map(id => sql`${id}`), sql`, `)})`
      );
      if (Number(actorCheck[0].value) < 5) {
        log("[BugBash] Seeding audit logs...");
        const auditData = [
          { actorId: clients[0].id, actorRole: "investor", actionType: "appointment.created", entityType: "appointment", entityId: apptRows[0]?.id, tenantId: PT, ipAddress: "192.168.1.10" },
          { actorId: clients[1].id, actorRole: "investor", actionType: "appointment.created", entityType: "appointment", entityId: apptRows[1]?.id, tenantId: PT, ipAddress: "192.168.1.11" },
          { actorId: clients[0].id, actorRole: "investor", actionType: "transaction.initiated_2fa", entityType: "transaction", entityId: txRows[0]?.id, tenantId: PT, ipAddress: "192.168.1.10" },
          { actorId: clients[1].id, actorRole: "investor", actionType: "transaction.initiated_2fa", entityType: "transaction", entityId: txRows[1]?.id, tenantId: PT, ipAddress: "192.168.1.11" },
          { actorId: clients[2].id, actorRole: "investor", actionType: "otp.verified", entityType: "transaction", entityId: txRows[2]?.id, tenantId: PT, ipAddress: "192.168.1.12" },
          { actorId: superAdmin.id, actorRole: "admin", actionType: "user.login", entityType: "user", entityId: superAdmin.id, tenantId: PT, ipAddress: "10.0.0.1" },
          { actorId: manager.id, actorRole: "admin", actionType: "user.login", entityType: "user", entityId: manager.id, tenantId: PT, ipAddress: "10.0.0.2" },
          { actorId: agent1.id, actorRole: "agent", actionType: "user.login", entityType: "user", entityId: agent1.id, tenantId: PT, ipAddress: "10.0.0.3" },
          { actorId: agent2.id, actorRole: "agent", actionType: "user.login", entityType: "user", entityId: agent2.id, tenantId: PT, ipAddress: "10.0.0.4" },
          { actorId: clients[3].id, actorRole: "investor", actionType: "user.login", entityType: "user", entityId: clients[3].id, tenantId: PT, ipAddress: "192.168.1.13" },
        ];
        await db.insert(auditLogs).values(auditData);
        log("[BugBash] 10 audit logs created");
      }
    } catch (e) {
      log("[BugBash] Audit logs seed error: " + (e as Error).message);
    }

    log("[BugBash] Bug-bash seed complete");
  } catch (e) {
    log("[BugBash] Fatal seed error: " + (e as Error).message);
  }
}
