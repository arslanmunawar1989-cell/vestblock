import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import type { Request, Response, NextFunction } from "express";
import type { User } from "@shared/schema";
import { storage } from "./storage";
import {
  DEFAULT_ROLE_PERMISSIONS,
  type Permission,
  type PlatformRole,
  type TenantRole,
  type PlatformAction,
  type TenantAction,
  type RbacAction,
  PLATFORM_ROLE_PERMISSIONS,
  TENANT_ROLE_PERMISSIONS,
  PLATFORM_ROLES,
  legacyRoleToPlatformRole,
} from "@shared/constants";

const JWT_SECRET = process.env.SESSION_SECRET || "vestblock-dev-secret";
const TOKEN_EXPIRY = "7d";

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10);
}

export async function verifyPassword(
  password: string,
  hash: string
): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export interface JwtPayload {
  userId: string;
  username: string;
  role: string;
  platformRole?: PlatformRole | null;
  tenantId?: string;
  tenantRole?: TenantRole | null;
  tokenVersion?: number;
  impersonatorId?: string;
  impersonatorUsername?: string;
}

export function generateToken(user: User, tenantId?: string, tenantRole?: TenantRole | null, impersonation?: { impersonatorId: string; impersonatorUsername: string }): string {
  const payload: JwtPayload = {
    userId: user.id,
    username: user.username,
    role: user.role,
    platformRole: (user.platformRole as PlatformRole) || null,
    tenantId,
    tenantRole: tenantRole || null,
    tokenVersion: user.tokenVersion ?? 0,
    ...(impersonation ? { impersonatorId: impersonation.impersonatorId, impersonatorUsername: impersonation.impersonatorUsername } : {}),
  };
  return jwt.sign(payload, JWT_SECRET, { expiresIn: TOKEN_EXPIRY });
}

export function verifyToken(token: string): JwtPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as JwtPayload;
  } catch {
    return null;
  }
}

export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const token =
    req.cookies?.token || req.headers.authorization?.replace("Bearer ", "");
  if (!token) {
    return res.status(401).json({ message: "Authentication required" });
  }
  const payload = verifyToken(token);
  if (!payload) {
    return res.status(401).json({ message: "Invalid or expired token" });
  }
  try {
    const user = await storage.getUser(payload.userId);
    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }
    if (user.accountStatus === "DISABLED") {
      res.clearCookie("token");
      return res.status(403).json({ message: "Account has been disabled. Please contact support." });
    }
    if (user.accountStatus === "ARCHIVED") {
      res.clearCookie("token");
      return res.status(403).json({ message: "Account has been archived." });
    }
    if (user.tokenVersion > 0 && (payload.tokenVersion === undefined || payload.tokenVersion < user.tokenVersion)) {
      res.clearCookie("token");
      return res.status(401).json({ message: "Session has been revoked. Please log in again." });
    }
    const session = await storage.getSessionByToken(token);
    if (session && session.revokedAt) {
      res.clearCookie("token");
      return res.status(401).json({ message: "Session has been revoked. Please log in again." });
    }
  } catch (err) {
    console.error("Auth status check error:", err);
  }
  if (req.tenantId && !payload.tenantId) {
    payload.tenantId = req.tenantId;
  }
  (req as any).user = payload;
  next();
}

export function requireActiveAccount(req: Request, res: Response, next: NextFunction) {
  const user = (req as any).user as JwtPayload | undefined;
  if (!user) {
    return res.status(401).json({ message: "Authentication required" });
  }
  next();
}

export function requireRole(...roles: string[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    const user = (req as any).user as JwtPayload | undefined;
    if (!user) {
      return res.status(401).json({ message: "Authentication required" });
    }
    if (user.platformRole === "SUPER_ADMIN") {
      return next();
    }
    if (roles.includes(user.role)) {
      return next();
    }
    const effectivePlatformRole = user.platformRole || legacyRoleToPlatformRole(user.role);
    if (effectivePlatformRole && roles.includes("admin")) {
      return next();
    }
    return res.status(403).json({ message: "Insufficient permissions" });
  };
}

export function requirePlatformRole(...roles: PlatformRole[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    const user = (req as any).user as JwtPayload | undefined;
    if (!user) {
      return res.status(401).json({ message: "Authentication required" });
    }
    const effectiveRole = user.platformRole || legacyRoleToPlatformRole(user.role);
    if (!effectiveRole) {
      return res.status(403).json({ message: "Platform role required" });
    }
    if (effectiveRole === "SUPER_ADMIN") {
      return next();
    }
    if (!roles.includes(effectiveRole)) {
      return res.status(403).json({ message: "Insufficient platform permissions" });
    }
    next();
  };
}

export function requirePlatformAction(...actions: PlatformAction[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    const user = (req as any).user as JwtPayload | undefined;
    if (!user) {
      return res.status(401).json({ message: "Authentication required" });
    }
    const effectiveRole = user.platformRole || legacyRoleToPlatformRole(user.role);
    if (!effectiveRole) {
      return res.status(403).json({ message: "Platform role required" });
    }
    if (effectiveRole === "SUPER_ADMIN") {
      return next();
    }
    const perms = PLATFORM_ROLE_PERMISSIONS[effectiveRole];
    const hasAll = actions.every(a => (perms as readonly string[]).includes(a));
    if (!hasAll) {
      return res.status(403).json({ message: "Insufficient platform permissions", required: actions });
    }
    next();
  };
}

export function requireTenantRole(...roles: TenantRole[]) {
  return async (req: Request, res: Response, next: NextFunction) => {
    const user = (req as any).user as JwtPayload | undefined;
    if (!user) {
      return res.status(401).json({ message: "Authentication required" });
    }
    if (user.platformRole === "SUPER_ADMIN") {
      return next();
    }
    const rawTenantId = req.params.tenantId || req.params.id || user.tenantId;
    const tenantId = Array.isArray(rawTenantId) ? rawTenantId[0] : rawTenantId;
    if (!tenantId) {
      return res.status(400).json({ message: "Tenant context required" });
    }
    const tenantUser = await storage.getTenantUser(tenantId, user.userId);
    if (!tenantUser || tenantUser.status !== "ACTIVE") {
      return res.status(403).json({ message: "No active tenant membership" });
    }
    const userTenantRole = tenantUser.role as TenantRole;
    if (!roles.includes(userTenantRole) && userTenantRole !== "TENANT_OWNER") {
      return res.status(403).json({ message: "Insufficient tenant permissions" });
    }
    (req as any).tenantRole = userTenantRole;
    next();
  };
}

export function requireTenantAction(...actions: TenantAction[]) {
  return async (req: Request, res: Response, next: NextFunction) => {
    const user = (req as any).user as JwtPayload | undefined;
    if (!user) {
      return res.status(401).json({ message: "Authentication required" });
    }
    if (user.platformRole === "SUPER_ADMIN") {
      return next();
    }
    const rawTenantId2 = req.params.tenantId || req.params.id || user.tenantId;
    const tenantId = Array.isArray(rawTenantId2) ? rawTenantId2[0] : rawTenantId2;
    if (!tenantId) {
      return res.status(400).json({ message: "Tenant context required" });
    }
    const tenantUser = await storage.getTenantUser(tenantId, user.userId);
    if (!tenantUser || tenantUser.status !== "ACTIVE") {
      return res.status(403).json({ message: "No active tenant membership" });
    }
    const userTenantRole = tenantUser.role as TenantRole;
    const perms = TENANT_ROLE_PERMISSIONS[userTenantRole];
    if (!perms) {
      return res.status(403).json({ message: "Invalid tenant role" });
    }
    const hasAll = actions.every(a => (perms as readonly string[]).includes(a));
    if (!hasAll) {
      return res.status(403).json({ message: "Insufficient tenant permissions", required: actions });
    }
    (req as any).tenantRole = userTenantRole;
    next();
  };
}

export function requirePermission(...permissions: Permission[]) {
  return async (req: Request, res: Response, next: NextFunction) => {
    const user = (req as any).user as JwtPayload | undefined;
    if (!user) {
      return res.status(401).json({ message: "Authentication required" });
    }

    if (user.platformRole === "SUPER_ADMIN") {
      return next();
    }

    const rolePerms = await storage.getRolePermissions(user.role);
    const grantedPerms = rolePerms.length > 0
      ? rolePerms.map(rp => rp.permission)
      : DEFAULT_ROLE_PERMISSIONS[user.role as keyof typeof DEFAULT_ROLE_PERMISSIONS] || [];

    const hasAll = permissions.every(p => grantedPerms.includes(p));
    if (!hasAll) {
      return res.status(403).json({ message: "Insufficient permissions", required: permissions });
    }
    next();
  };
}

export async function getUserPermissions(role: string): Promise<string[]> {
  const rolePerms = await storage.getRolePermissions(role);
  if (rolePerms.length > 0) {
    return rolePerms.map(rp => rp.permission);
  }
  return DEFAULT_ROLE_PERMISSIONS[role as keyof typeof DEFAULT_ROLE_PERMISSIONS] || [];
}

export function resolveEffectivePlatformRole(user: { role: string; platformRole?: string | null }): PlatformRole | null {
  if (user.platformRole && PLATFORM_ROLES.includes(user.platformRole as PlatformRole)) {
    return user.platformRole as PlatformRole;
  }
  return legacyRoleToPlatformRole(user.role);
}
