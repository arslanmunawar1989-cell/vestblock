import express, { type Request, Response, NextFunction } from "express";
import cookieParser from "cookie-parser";
import { registerRoutes } from "./routes";
import { serveStatic } from "./static";
import { createServer } from "http";
import { tenantContext } from "./middleware/tenant-context";

const app = express();
const httpServer = createServer(app);

app.get("/__health", (_req, res) => {
  res.status(200).send("ok");
});

app.get("/health", async (_req, res) => {
  const startTime = process.hrtime();
  let dbOk = false;
  let dbError: string | undefined;
  try {
    const { pool } = await import("./db");
    await pool.query("SELECT 1");
    dbOk = true;
  } catch (err: any) {
    dbError = err?.message || "Unknown database error";
  }
  const [s, ns] = process.hrtime(startTime);
  const latencyMs = Math.round(s * 1000 + ns / 1e6);
  const status = dbOk ? "healthy" : "degraded";
  const body: Record<string, unknown> = {
    status,
    uptime: Math.floor(process.uptime()),
    timestamp: new Date().toISOString(),
    database: dbOk ? "connected" : "unreachable",
    latencyMs,
  };
  if (dbError) body.error = dbError;
  res.status(dbOk ? 200 : 503).json(body);
});

declare module "http" {
  interface IncomingMessage {
    rawBody: unknown;
  }
}

app.use(
  express.json({
    verify: (req, _res, buf) => {
      req.rawBody = buf;
    },
  }),
);

app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(tenantContext());

export function log(message: string, source = "express") {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });

  console.log(`${formattedTime} [${source}] ${message}`);
}

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse).substring(0, 200)}`;
      }
      log(logLine);
    }
  });

  next();
});

(async () => {
  const { seedDatabase, seedDefaultFeeSchedules, seedExtendedData } = await import("./seed");
  try {
    await seedDatabase();
    await seedDefaultFeeSchedules();
    await seedExtendedData();
  } catch (e) {
    console.error("Seed error:", e);
  }

  await registerRoutes(httpServer, app);

  app.use((err: any, _req: Request, res: Response, next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    console.error("Internal Server Error:", err);

    if (res.headersSent) {
      return next(err);
    }

    return res.status(status).json({ message });
  });

  if (process.env.NODE_ENV === "production") {
    serveStatic(app);
  } else {
    const { setupVite } = await import("./vite");
    await setupVite(httpServer, app);
  }

  const port = parseInt(process.env.PORT || "5000", 10);
  httpServer.listen(
    {
      port,
      host: "0.0.0.0",
      reusePort: true,
    },
    () => {
      log(`serving on port ${port}`);
    },
  );
})();
