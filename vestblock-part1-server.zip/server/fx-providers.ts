import { storage } from "./storage";

export interface FxRateResult {
  rate: number;
  spread: number;
  provider: string;
  sourceLabel: string;
  fetchedAt: Date;
  rateId: string;
}

export interface FxProvider {
  name: string;
  fetchRate(base: string, quote: string): Promise<FxRateResult | null>;
  isConfigured(): boolean;
}

export class ManualRateProvider implements FxProvider {
  name = "manual";

  async fetchRate(base: string, quote: string): Promise<FxRateResult | null> {
    const fxRate = await storage.getActiveFxRate(base, quote);
    if (!fxRate) return null;
    return {
      rate: parseFloat(fxRate.rate),
      spread: parseFloat(fxRate.spread),
      provider: fxRate.provider,
      sourceLabel: fxRate.sourceLabel,
      fetchedAt: fxRate.fetchedAt,
      rateId: fxRate.id,
    };
  }

  isConfigured(): boolean {
    return true;
  }
}

const providers: FxProvider[] = [new ManualRateProvider()];

export function registerProvider(provider: FxProvider): void {
  const existing = providers.findIndex(p => p.name === provider.name);
  if (existing >= 0) {
    providers[existing] = provider;
  } else {
    providers.push(provider);
  }
}

export function getProvider(name: string): FxProvider | undefined {
  return providers.find(p => p.name === name);
}

export function listProviders(): FxProvider[] {
  return [...providers];
}

const KNOWN_PROVIDERS = [
  { name: "manual", label: "Manual Entry", description: "Rates entered manually by admin" },
  { name: "market_feed", label: "Market Feed", description: "Live market data feed" },
  { name: "central_bank", label: "Central Bank", description: "Central bank reference rates" },
  { name: "bloomberg", label: "Bloomberg", description: "Bloomberg terminal rates" },
  { name: "reuters", label: "Reuters", description: "Reuters/Refinitiv rates" },
];

export function listAllProviders(): { name: string; label: string; description: string; configured: boolean }[] {
  return KNOWN_PROVIDERS.map(kp => ({
    ...kp,
    configured: providers.some(p => p.name === kp.name && p.isConfigured()),
  }));
}

export async function fetchBestRate(base: string, quote: string): Promise<FxRateResult | null> {
  for (const provider of providers) {
    if (!provider.isConfigured()) continue;
    const result = await provider.fetchRate(base, quote);
    if (result) return result;
  }
  return null;
}
