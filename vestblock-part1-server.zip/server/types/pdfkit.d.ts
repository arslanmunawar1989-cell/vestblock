declare module 'pdfkit' {
  class PDFDocument {
    constructor(options?: any);
    pipe(stream: any): this;
    fontSize(size: number): this;
    font(name: string): this;
    text(text: string, x?: number | any, y?: number, options?: any): this;
    moveDown(lines?: number): this;
    end(): void;
    y: number;
    x: number;
    page: { width: number; height: number };
    rect(x: number, y: number, w: number, h: number): this;
    fill(color: string): this;
    fillColor(color: string): this;
    strokeColor(color: string): this;
    lineWidth(width: number): this;
    moveTo(x: number, y: number): this;
    lineTo(x: number, y: number): this;
    stroke(): this;
    on(event: string, listener: (...args: any[]) => void): this;
  }
  export = PDFDocument;
}
