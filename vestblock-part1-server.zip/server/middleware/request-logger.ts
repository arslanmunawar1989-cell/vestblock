import { Request, Response, NextFunction } from "express";
import { logger } from "../lib/logger";
import crypto from "crypto";

export function requestLogger(req: Request, res: Response, next: NextFunction) {
  const start = Date.now();
  const requestId = crypto.randomUUID();
  (req as any).requestId = requestId;

  res.on("finish", () => {
    const duration = Date.now() - start;
    const logData = {
      requestId,
      method: req.method,
      path: req.path,
      statusCode: res.statusCode,
      duration,
      tenantId: (req as any).tenantId || null,
      userId: (req as any).user?.userId || null,
      userAgent: req.headers["user-agent"],
      ip: req.ip || req.headers["x-forwarded-for"],
    };
    if (res.statusCode >= 500) {
      logger.error("Request completed with server error", logData);
    } else if (res.statusCode >= 400) {
      logger.warn("Request completed with client error", logData);
    } else {
      logger.info("Request completed", logData);
    }
  });
  next();
}
