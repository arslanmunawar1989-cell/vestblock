import type { Request, Response, NextFunction } from "express";
import { eq, and } from "drizzle-orm";
import { db } from "../db";
import { tenants, tenantUsers } from "@shared/schema";
import { PLATFORM_TENANT_ID, PLATFORM_TENANT_SLUG } from "@shared/constants";

export interface TenantContext {
  tenantId: string;
  tenantSlug: string;
  tenantName: string;
  tenantStatus: string;
}

declare global {
  namespace Express {
    interface Request {
      tenant?: TenantContext;
      tenantId?: string;
    }
  }
}

const tenantCache = new Map<string, { tenant: TenantContext; expiresAt: number }>();
const CACHE_TTL_MS = 60_000;

async function resolveTenantBySlug(slug: string): Promise<TenantContext | null> {
  const cached = tenantCache.get(slug);
  if (cached && cached.expiresAt > Date.now()) {
    return cached.tenant;
  }

  const [row] = await db.select().from(tenants).where(eq(tenants.slug, slug)).limit(1);
  if (!row) return null;

  const ctx: TenantContext = {
    tenantId: row.id,
    tenantSlug: row.slug,
    tenantName: row.name,
    tenantStatus: row.status,
  };

  tenantCache.set(slug, { tenant: ctx, expiresAt: Date.now() + CACHE_TTL_MS });
  return ctx;
}

export function clearTenantCache(slug?: string) {
  if (slug) {
    tenantCache.delete(slug);
  } else {
    tenantCache.clear();
  }
}

export function tenantContext() {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (req.path.startsWith("/__health") || req.path.startsWith("/health")) {
      return next();
    }

    let slug: string | null = null;

    const pathMatch = req.path.match(/^\/t\/([a-zA-Z0-9_-]+)(\/|$)/);
    if (pathMatch) {
      slug = pathMatch[1];
      req.url = req.url.replace(`/t/${slug}`, "") || "/";
    }

    if (!slug) {
      const host = req.hostname || req.headers.host || "";
      const hostWithoutPort = host.split(":")[0];
      const parts = hostWithoutPort.split(".");
      const isReplit = hostWithoutPort.endsWith(".repl.co") ||
        hostWithoutPort.endsWith(".replit.dev") ||
        hostWithoutPort.endsWith(".replit.app") ||
        hostWithoutPort.endsWith(".repl.it") ||
        hostWithoutPort.endsWith(".kirk.sh") ||
        hostWithoutPort.endsWith(".picard.replit.dev") ||
        hostWithoutPort.endsWith(".spock.replit.dev") ||
        hostWithoutPort === "localhost";
      if (!isReplit && parts.length >= 3 && parts[0] !== "www") {
        slug = parts[0];
      }
    }

    if (!slug || slug === PLATFORM_TENANT_SLUG) {
      req.tenant = {
        tenantId: PLATFORM_TENANT_ID,
        tenantSlug: PLATFORM_TENANT_SLUG,
        tenantName: "VestBlock Platform",
        tenantStatus: "ACTIVE",
      };
      req.tenantId = PLATFORM_TENANT_ID;
      return next();
    }

    try {
      const tenant = await resolveTenantBySlug(slug);
      if (!tenant) {
        return res.status(404).json({ message: `Tenant '${slug}' not found` });
      }
      if (tenant.tenantStatus === "SUSPENDED") {
        return res.status(403).json({ message: "This tenant is currently suspended" });
      }
      req.tenant = tenant;
      req.tenantId = tenant.tenantId;
      next();
    } catch (err) {
      console.error("Tenant resolution error:", err);
      req.tenant = {
        tenantId: PLATFORM_TENANT_ID,
        tenantSlug: PLATFORM_TENANT_SLUG,
        tenantName: "VestBlock Platform",
        tenantStatus: "ACTIVE",
      };
      req.tenantId = PLATFORM_TENANT_ID;
      next();
    }
  };
}

export async function getUserTenantMembership(userId: string, tenantId: string) {
  const [membership] = await db
    .select()
    .from(tenantUsers)
    .where(and(eq(tenantUsers.userId, userId), eq(tenantUsers.tenantId, tenantId)))
    .limit(1);
  return membership || null;
}
