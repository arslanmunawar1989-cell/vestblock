import rateLimit from "express-rate-limit";
import type { Request } from "express";

const getClientKey = (req: Request): string => {
  const userId = (req as any).user?.userId;
  if (userId) return String(userId);
  return "anonymous";
};

export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: "Too many authentication attempts, please try again after 15 minutes" },
  skipSuccessfulRequests: false,
  validate: { xForwardedForHeader: false },
});

export const paymentLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: getClientKey,
  message: { message: "Too many payment requests, please slow down" },
  validate: { xForwardedForHeader: false },
});

export const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 120,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: getClientKey,
  message: { message: "Too many requests, please slow down" },
  validate: { xForwardedForHeader: false },
});

export const webhookLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: "Too many webhook calls" },
  validate: { xForwardedForHeader: false },
});
