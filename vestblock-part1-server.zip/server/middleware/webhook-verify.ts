import crypto from "crypto";
import type { Request, Response, NextFunction } from "express";
import { logger } from "../lib/logger";

export interface WebhookConfig {
  secret: string;
  headerName: string;
  algorithm?: string;
  signaturePrefix?: string;
  computeSignature: (payload: Buffer | string, secret: string) => string;
}

export function createHmacSignature(payload: Buffer | string, secret: string, algorithm = "sha256"): string {
  return crypto.createHmac(algorithm, secret).update(payload).digest("hex");
}

export function verifyHmacSignature(
  payload: Buffer | string,
  signature: string,
  secret: string,
  algorithm = "sha256",
  prefix = ""
): boolean {
  const expected = prefix + createHmacSignature(payload, secret, algorithm);
  try {
    return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected));
  } catch {
    return false;
  }
}

export function webhookSignatureGuard(config: {
  secretEnvVar: string;
  headerName: string;
  algorithm?: string;
  signaturePrefix?: string;
}) {
  return (req: Request, res: Response, next: NextFunction) => {
    const secret = process.env[config.secretEnvVar];
    if (!secret) {
      logger.warn("Webhook secret not configured", { source: "webhook", envVar: config.secretEnvVar });
      return res.status(500).json({ message: "Webhook not configured" });
    }

    const signature = req.headers[config.headerName.toLowerCase()] as string;
    if (!signature) {
      logger.warn("Missing webhook signature header", {
        source: "webhook",
        header: config.headerName,
        ip: req.ip,
      });
      return res.status(401).json({ message: "Missing webhook signature" });
    }

    const rawBody = (req as any).rawBody as Buffer;
    if (!rawBody) {
      logger.error("Raw body not available for webhook verification", { source: "webhook" });
      return res.status(500).json({ message: "Cannot verify webhook - raw body unavailable" });
    }

    const valid = verifyHmacSignature(
      rawBody,
      signature,
      secret,
      config.algorithm || "sha256",
      config.signaturePrefix || ""
    );

    if (!valid) {
      logger.warn("Webhook signature verification failed", {
        source: "webhook",
        ip: req.ip,
        header: config.headerName,
      });
      return res.status(401).json({ message: "Invalid webhook signature" });
    }

    logger.info("Webhook signature verified", { source: "webhook", path: req.path });
    next();
  };
}
