import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { logAuditFromReq } from "../lib/audit-logger";
import { z } from "zod";
import { db } from "../db";
import { portfolioItems } from "@shared/schema";
import { eq } from "drizzle-orm";
import { createQuote, executeConversion } from "../fx";
import { CURRENCY_DETAILS } from "@shared/constants";
import { NotificationTemplates } from "../services/notification-templates";
import { creditDistributionRequestSchema } from "@shared/dto/distribution.dto";
import { validateBody } from "../middleware/validate";

export function registerDistributionRoutes(app: Express) {
  app.post("/api/admin/distributions/credit", requireAuth, requireRole("admin"), validateBody(creditDistributionRequestSchema), async (req, res) => {
    try {
      const adminId = (req as any).user.userId;
      const data = req.body;

      const asset = await storage.getAsset(data.assetId);
      if (!asset) return res.status(404).json({ message: "Asset not found" });

      const baseCurrency = asset.baseCurrency;
      const currencyDetail = CURRENCY_DETAILS[baseCurrency as keyof typeof CURRENCY_DETAILS];
      const currencySymbol = currencyDetail?.symbol || baseCurrency;

      const allPortfolios = await db.select().from(portfolioItems)
        .where(eq(portfolioItems.assetId, data.assetId));

      if (allPortfolios.length === 0) {
        return res.status(400).json({ message: "No investors hold tokens for this asset" });
      }

      const distDate = data.distributionDate || new Date().toISOString().split("T")[0];
      let totalDistributed = 0;
      let recipientCount = 0;
      const results: {
        userId: string;
        amount: number;
        currency: string;
        autoConverted: boolean;
        convertedTo?: string;
        convertedAmount?: number;
      }[] = [];

      for (const portfolio of allPortfolios) {
        const tokens = parseFloat(portfolio.quantity);
        if (tokens <= 0) continue;

        const distributionAmount = parseFloat((tokens * data.perTokenAmount).toFixed(2));
        if (distributionAmount <= 0) continue;

        const walletAccount = await storage.getOrCreateWallet(portfolio.userId, baseCurrency);

        const refId = `DIST-${Date.now().toString(36).toUpperCase()}-${recipientCount}`;

        await storage.createWalletTransaction({
          walletAccountId: walletAccount.id,
          type: "DIVIDEND",
          amount: distributionAmount.toString(),
          currency: baseCurrency,
          status: "COMPLETED",
          referenceId: refId,
          description: `Distribution from ${asset.name}: ${currencySymbol} ${distributionAmount.toFixed(2)} (${tokens} tokens x ${currencySymbol} ${data.perTokenAmount}/token)`,
          metadata: {
            assetId: data.assetId,
            assetSymbol: asset.symbol,
            perTokenAmount: data.perTokenAmount,
            tokenCount: tokens,
            distributionDate: distDate,
          },
        });

        totalDistributed += distributionAmount;
        recipientCount++;

        let autoConverted = false;
        let convertedTo: string | undefined;
        let convertedAmount: number | undefined;

        const user = await storage.getUser(portfolio.userId);
        if (user) {
          const prefs = user.notificationPreferences as any;
          if (prefs?.autoConvertDistributions === true) {
            const countryProfiles = await storage.getCountryProfiles(portfolio.userId);
            const primary = countryProfiles.find(p => p.isPrimary) || countryProfiles[0];
            if (primary) {
              const { COUNTRY_TO_CURRENCY } = await import("@shared/constants");
              const userCurrency = COUNTRY_TO_CURRENCY[primary.countryCode as keyof typeof COUNTRY_TO_CURRENCY] || "AED";

              if (userCurrency !== baseCurrency) {
                try {
                  const quote = await createQuote(baseCurrency, userCurrency, distributionAmount, portfolio.userId);
                  if (quote) {
                    const convResult = await executeConversion(portfolio.userId, quote.id);
                    autoConverted = true;
                    convertedTo = userCurrency;
                    convertedAmount = parseFloat(convResult.fxTransaction.amountTo);
                  }
                } catch (fxErr: any) {
                  console.warn(`Auto-convert failed for user ${portfolio.userId}: ${fxErr.message?.slice(0, 100)}`);
                }
              }
            }
          }

          const distNotif = NotificationTemplates.distribution.received(
            asset.name, distributionAmount, baseCurrency, autoConverted, convertedTo, convertedAmount ?? undefined
          );
          await storage.createNotification({ userId: portfolio.userId, ...distNotif });
        }

        results.push({
          userId: portfolio.userId,
          amount: distributionAmount,
          currency: baseCurrency,
          autoConverted,
          convertedTo,
          convertedAmount,
        });
      }

      const distribution = await storage.createDistribution({
        assetId: data.assetId,
        amount: totalDistributed.toFixed(2),
        currency: baseCurrency,
        distributionDate: distDate,
        status: "completed",
        perTokenAmount: data.perTokenAmount.toString(),
        recipientCount,
        createdBy: adminId,
      });

      await logAuditFromReq(req, "DISTRIBUTION_CREDIT", "distribution", distribution.id, {
        reason: `Credited ${currencySymbol} ${totalDistributed.toFixed(2)} to ${recipientCount} investors for ${asset.name} (${data.perTokenAmount}/token)`,
        metadata: { totalDistributed, recipientCount, perTokenAmount: data.perTokenAmount, assetId: data.assetId },
      });

      res.json({
        success: true,
        distribution: {
          id: distribution.id,
          assetId: data.assetId,
          assetName: asset.name,
          currency: baseCurrency,
          totalDistributed: totalDistributed.toFixed(2),
          perTokenAmount: data.perTokenAmount,
          recipientCount,
          distributionDate: distDate,
          recipients: results,
        },
      });
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Distribution credit error:", err);
      res.status(500).json({ message: "Failed to process distribution" });
    }
  });

  app.get("/api/distributions/my", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const accounts = await storage.getWalletAccountsByUser(userId);

      const distTxs: any[] = [];
      for (const acc of accounts) {
        const txs = await storage.getWalletTransactions(acc.id);
        const dividends = txs.filter(t => t.type === "DIVIDEND");
        distTxs.push(...dividends.map(t => ({
          id: t.id,
          amount: t.amount,
          currency: t.currency,
          status: t.status,
          description: t.description,
          date: t.createdAt,
          metadata: t.metadata,
          referenceId: t.referenceId,
        })));
      }

      distTxs.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      res.json(distTxs);
    } catch (err: any) {
      console.error("My distributions error:", err);
      res.status(500).json({ message: "Failed to fetch distributions" });
    }
  });

  app.get("/api/distributions/preference", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const user = await storage.getUser(userId);
      if (!user) return res.status(404).json({ message: "User not found" });
      const prefs = user.notificationPreferences as any;
      res.json({ autoConvertDistributions: prefs?.autoConvertDistributions === true });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch preference" });
    }
  });

  app.patch("/api/distributions/preference", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const { autoConvertDistributions } = z.object({ autoConvertDistributions: z.boolean() }).parse(req.body);

      const user = await storage.getUser(userId);
      if (!user) return res.status(404).json({ message: "User not found" });

      const currentPrefs = (user.notificationPreferences as any) || {};
      const updated = await storage.updateNotificationPreferences(userId, {
        ...currentPrefs,
        autoConvertDistributions,
      });

      res.json({ success: true, autoConvertDistributions });
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed" });
      res.status(500).json({ message: "Failed to update preference" });
    }
  });
}
