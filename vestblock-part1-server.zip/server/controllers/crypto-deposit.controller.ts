import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { logAuditFromReq } from "../lib/audit-logger";
import { createQuote, executeConversion } from "../fx";
import {
  SUPPORTED_CHAINS,
  SUPPORTED_TOKENS,
  CHAIN_CONFIRMATIONS,
  PLATFORM_RECEIVING_ADDRESSES,
  createCryptoDepositSchema,
  confirmCryptoDepositSchema,
} from "@shared/schema";
import { screenCryptoDeposit, applyAmlActions } from "../services/crypto-aml";
import { NotificationTemplates } from "../services/notification-templates";
import { paymentLimiter } from "../middleware/rate-limit";

function buildQrPayload(chainId: string, tokenSymbol: string, address: string, amount: number, memo?: string): string {
  const chain = SUPPORTED_CHAINS.find(c => c.id === chainId);
  if (!chain) return address;

  if (chain.networkType === "evm") {
    return `ethereum:${address}?value=${amount}&token=${tokenSymbol}`;
  } else if (chain.networkType === "tron") {
    let payload = `tron:${address}?amount=${amount}&token=${tokenSymbol}`;
    if (memo) payload += `&memo=${memo}`;
    return payload;
  } else if (chain.networkType === "solana") {
    return `solana:${address}?amount=${amount}&spl-token=${tokenSymbol}`;
  }
  return address;
}

export function registerCryptoDepositRoutes(app: Express) {
  app.post("/api/crypto/deposit-intents", requireAuth, paymentLimiter, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const parsed = createCryptoDepositSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Validation failed", errors: parsed.error.errors });
      }

      const { chainId, tokenSymbol, amount } = parsed.data;

      const chain = SUPPORTED_CHAINS.find(c => c.id === chainId);
      if (!chain) {
        return res.status(400).json({ message: `Unsupported chain: ${chainId}` });
      }

      const token = SUPPORTED_TOKENS.find(t => t.symbol === tokenSymbol);
      if (!token || !token.chains.includes(chainId as any)) {
        return res.status(400).json({ message: `${tokenSymbol} is not supported on ${chainId}` });
      }

      const receivingConfig = PLATFORM_RECEIVING_ADDRESSES[chainId]?.[tokenSymbol];
      if (!receivingConfig) {
        return res.status(400).json({ message: `No receiving address configured for ${tokenSymbol} on ${chainId}` });
      }

      const screening = await screenCryptoDeposit(userId, amount, chainId, tokenSymbol);

      if (screening.action === "REJECT") {
        await applyAmlActions(userId, "pre-creation", screening);

        const notif = NotificationTemplates.crypto.rejected(tokenSymbol, screening.holdReason);
        await storage.createNotification({ userId, ...notif });

        return res.status(403).json({
          message: "Deposit rejected by compliance policy",
          reason: screening.holdReason,
          flags: screening.flags.map(f => f.type),
        });
      }

      const invoiceAddress = receivingConfig.address;
      const memo = receivingConfig.memo || null;
      const requiredConfirmations = CHAIN_CONFIRMATIONS[chainId] || 12;
      const qrPayload = buildQrPayload(chainId, tokenSymbol, invoiceAddress, amount, memo || undefined);

      const intentStatus = screening.action === "HOLD" ? "AML_HOLD" : "CREATED";
      const amlStatus = screening.action === "HOLD" ? "HOLD" : "CLEAR";

      const intent = await storage.createCryptoDepositIntent({
        userId,
        chainId,
        tokenSymbol,
        amount: amount.toString(),
        invoiceAddress,
        memo,
        qrPayload,
        requiredConfirmations,
      });

      if (screening.action === "HOLD") {
        await storage.updateCryptoDepositIntent(intent.id, {
          status: "AML_HOLD",
          amlStatus: "HOLD",
          amlFlags: screening.flags,
          holdReason: screening.holdReason || "AML policy hold",
          heldAt: new Date().toISOString(),
        });

        await applyAmlActions(userId, intent.id, screening);

        const holdNotif = NotificationTemplates.crypto.underReview(tokenSymbol, amount);
        await storage.createNotification({ userId, ...holdNotif });

        const updatedIntent = await storage.getCryptoDepositIntentById(intent.id);
        return res.status(201).json(updatedIntent);
      }

      res.status(201).json(intent);
    } catch (err: any) {
      console.error("Create crypto deposit intent error:", err);
      res.status(500).json({ message: "Failed to create deposit intent" });
    }
  });

  app.get("/api/crypto/deposit-intents", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const intents = await storage.getCryptoDepositIntentsByUser(userId);
      res.json(intents);
    } catch (err: any) {
      console.error("Get crypto deposit intents error:", err);
      res.status(500).json({ message: "Failed to fetch deposit intents" });
    }
  });

  app.get("/api/crypto/deposit-intents/:id", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const intent = await storage.getCryptoDepositIntentById(req.params.id as string);
      if (!intent) return res.status(404).json({ message: "Deposit intent not found" });
      if (intent.userId !== userId) return res.status(403).json({ message: "Access denied" });
      res.json(intent);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch deposit intent" });
    }
  });

  app.get("/api/admin/crypto/deposit-intents", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const intents = await storage.getAllCryptoDepositIntents(req.tenantId);
      res.json(intents);
    } catch (err: any) {
      console.error("Admin get crypto deposit intents error:", err);
      res.status(500).json({ message: "Failed to fetch deposit intents" });
    }
  });

  app.post("/api/admin/crypto/deposit-intents/:id/hold", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const adminId = (req as any).user.userId;
      const intent = await storage.getCryptoDepositIntentById(req.params.id as string);
      if (!intent) return res.status(404).json({ message: "Deposit intent not found" });

      if (intent.status === "CONFIRMED" || intent.status === "REJECTED") {
        return res.status(400).json({ message: `Cannot hold deposit with status ${intent.status}` });
      }

      if (intent.status === "AML_HOLD") {
        return res.status(400).json({ message: "Deposit is already on hold" });
      }

      const { reason } = req.body || {};

      const updated = await storage.updateCryptoDepositIntent(intent.id, {
        status: "AML_HOLD",
        amlStatus: "HOLD",
        holdReason: reason || "Manual compliance hold",
        heldBy: adminId,
        heldAt: new Date().toISOString(),
      });

      await storage.createAmlFlag({
        userId: intent.userId,
        flagType: "CRYPTO_MANUAL_HOLD",
        severity: "medium",
        description: `Crypto deposit ${intent.id} placed on manual hold: ${reason || "No reason provided"}`,
        details: { depositIntentId: intent.id, amount: intent.amount, chainId: intent.chainId },
      });

      const holdNotif2 = NotificationTemplates.crypto.holdPlaced(intent.tokenSymbol, intent.amount);
      await storage.createNotification({ userId: intent.userId, ...holdNotif2 });

      await logAuditFromReq(req, "CRYPTO_DEPOSIT_HOLD", "crypto_deposit_intent", intent.id, {
        reason: `Deposit held: ${reason || "Manual hold"}`,
        beforeState: { status: intent.status },
        afterState: { status: "AML_HOLD" },
      });

      res.json(updated);
    } catch (err: any) {
      console.error("Admin hold crypto deposit error:", err);
      res.status(500).json({ message: "Failed to hold deposit" });
    }
  });

  app.post("/api/admin/crypto/deposit-intents/:id/release", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const adminId = (req as any).user.userId;
      const intent = await storage.getCryptoDepositIntentById(req.params.id as string);
      if (!intent) return res.status(404).json({ message: "Deposit intent not found" });

      if (intent.status !== "AML_HOLD") {
        return res.status(400).json({ message: `Can only release deposits that are on AML hold. Current status: ${intent.status}` });
      }

      const { notes } = req.body || {};

      const updated = await storage.updateCryptoDepositIntent(intent.id, {
        status: "CREATED",
        amlStatus: "CLEARED",
        clearedBy: adminId,
        clearedAt: new Date().toISOString(),
        adminNotes: notes || "AML hold cleared by compliance",
      });

      const clearNotif = NotificationTemplates.crypto.cleared(intent.tokenSymbol, intent.amount);
      await storage.createNotification({ userId: intent.userId, ...clearNotif });

      await logAuditFromReq(req, "CRYPTO_DEPOSIT_RELEASE", "crypto_deposit_intent", intent.id, {
        reason: `AML hold released: ${notes || "Cleared by compliance"}`,
        beforeState: { status: intent.status, amlStatus: intent.amlStatus },
        afterState: { status: "CREATED", amlStatus: "CLEARED" },
      });

      res.json(updated);
    } catch (err: any) {
      console.error("Admin release crypto deposit error:", err);
      res.status(500).json({ message: "Failed to release deposit" });
    }
  });

  app.post("/api/admin/crypto/deposit-intents/:id/confirm", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const adminId = (req as any).user.userId;
      const intent = await storage.getCryptoDepositIntentById(req.params.id as string);
      if (!intent) return res.status(404).json({ message: "Deposit intent not found" });

      if (intent.status === "CONFIRMED") {
        return res.status(400).json({ message: "Deposit already confirmed" });
      }
      if (intent.status === "REJECTED" || intent.status === "EXPIRED") {
        return res.status(400).json({ message: `Cannot confirm deposit with status ${intent.status}` });
      }
      if (intent.status === "AML_HOLD") {
        return res.status(400).json({ message: "Deposit is on AML hold. Release it first before confirming." });
      }

      const parsed = confirmCryptoDepositSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Validation failed", errors: parsed.error.errors });
      }

      const { txHash, confirmations, convertToAed } = parsed.data;
      const requiredConf = intent.requiredConfirmations;

      if (confirmations < requiredConf) {
        return res.status(400).json({
          message: `Insufficient confirmations. Required: ${requiredConf}, provided: ${confirmations}`,
        });
      }

      const depositAmount = parseFloat(intent.amount);
      const reScreening = await screenCryptoDeposit(intent.userId, depositAmount, intent.chainId, intent.tokenSymbol);
      if (reScreening.action === "REJECT") {
        await storage.updateCryptoDepositIntent(intent.id, {
          status: "REJECTED",
          amlStatus: "FLAGGED",
          amlFlags: reScreening.flags,
          holdReason: reScreening.holdReason,
          adminNotes: "Auto-rejected on confirm: " + (reScreening.holdReason || "AML policy"),
        });
        await applyAmlActions(intent.userId, intent.id, reScreening);
        return res.status(403).json({
          message: "Deposit rejected by compliance policy during confirmation screening",
          reason: reScreening.holdReason,
        });
      }

      if (reScreening.action === "HOLD" && intent.amlStatus !== "CLEARED") {
        await storage.updateCryptoDepositIntent(intent.id, {
          status: "AML_HOLD",
          amlStatus: "HOLD",
          amlFlags: reScreening.flags,
          holdReason: reScreening.holdReason,
          heldAt: new Date().toISOString(),
        });
        await applyAmlActions(intent.userId, intent.id, reScreening);
        return res.status(400).json({
          message: "Deposit placed on AML hold during confirmation screening. Release it first.",
          reason: reScreening.holdReason,
          flags: reScreening.flags.map(f => f.type),
        });
      }

      const updated = await storage.updateCryptoDepositIntent(intent.id, {
        txHash,
        confirmations,
        status: "CONFIRMED",
        confirmedAt: new Date().toISOString(),
        confirmedBy: adminId,
        convertToAed: convertToAed || false,
      });

      const depositCurrency = intent.tokenSymbol;

      const walletAccount = await storage.getOrCreateWallet(intent.userId, depositCurrency);

      await storage.createWalletTransaction({
        walletAccountId: walletAccount.id,
        type: "CRYPTO_DEPOSIT",
        amount: depositAmount.toString(),
        currency: depositCurrency,
        status: "COMPLETED",
        referenceId: intent.id,
        description: `Crypto deposit: ${intent.amount} ${intent.tokenSymbol} on ${intent.chainId} (TX: ${txHash.slice(0, 12)}...)`,
        metadata: {
          cryptoDepositIntentId: intent.id,
          chainId: intent.chainId,
          tokenSymbol: intent.tokenSymbol,
          txHash,
          confirmations,
        },
      });

      let fxResult = null;
      if (convertToAed && depositAmount > 0) {
        try {
          const quote = await createQuote(depositCurrency, "AED", depositAmount, intent.userId);
          if (quote && !quote.requiresApproval) {
            fxResult = await executeConversion(intent.userId, quote.id);
            await storage.updateCryptoDepositIntent(intent.id, { fxQuoteId: quote.id });
          } else if (quote?.requiresApproval) {
            fxResult = { message: "FX conversion requires admin approval", quoteId: quote.id };
            await storage.updateCryptoDepositIntent(intent.id, { fxQuoteId: quote.id });
          }
        } catch (fxErr: any) {
          console.warn("FX conversion after crypto deposit failed (non-blocking):", fxErr.message);
          fxResult = { error: fxErr.message };
        }
      }

      await logAuditFromReq(req, "CRYPTO_DEPOSIT_CONFIRMED", "crypto_deposit_intent", intent.id, {
        reason: `Crypto deposit confirmed: ${intent.amount} ${intent.tokenSymbol} on ${intent.chainId}. TX: ${txHash}. Confirmations: ${confirmations}/${requiredConf}. Convert to AED: ${convertToAed}`,
        beforeState: { status: intent.status },
        afterState: { status: "CONFIRMED" },
        metadata: { txHash, confirmations, convertToAed },
      });

      const confirmNotif = NotificationTemplates.crypto.confirmed(intent.tokenSymbol, intent.amount, intent.chainId);
      await storage.createNotification({ userId: intent.userId, ...confirmNotif });

      res.json({ intent: updated, fxResult });
    } catch (err: any) {
      console.error("Admin confirm crypto deposit error:", err);
      res.status(500).json({ message: "Failed to confirm deposit" });
    }
  });

  app.post("/api/admin/crypto/deposit-intents/:id/reject", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const adminId = (req as any).user.userId;
      const intent = await storage.getCryptoDepositIntentById(req.params.id as string);
      if (!intent) return res.status(404).json({ message: "Deposit intent not found" });

      if (intent.status === "CONFIRMED" || intent.status === "REJECTED") {
        return res.status(400).json({ message: `Cannot reject deposit with status ${intent.status}` });
      }

      const { reason } = req.body || {};

      const updated = await storage.updateCryptoDepositIntent(intent.id, {
        status: "REJECTED",
        adminNotes: reason || "Rejected by admin",
        confirmedBy: adminId,
      });

      const rejectNotif = NotificationTemplates.crypto.depositRejected(intent.tokenSymbol, intent.amount, intent.chainId, reason);
      await storage.createNotification({ userId: intent.userId, ...rejectNotif });

      res.json(updated);
    } catch (err: any) {
      console.error("Admin reject crypto deposit error:", err);
      res.status(500).json({ message: "Failed to reject deposit" });
    }
  });
}
