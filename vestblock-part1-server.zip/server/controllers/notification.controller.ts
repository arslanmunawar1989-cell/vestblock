import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth } from "../auth";
import { getVapidPublicKey, generateVapidKeys } from "../services/push-notification.service";
import { z } from "zod";

const pushSubscribeSchema = z.object({
  endpoint: z.string().url(),
  keys: z.object({
    p256dh: z.string(),
    auth: z.string(),
  }),
});

export function registerNotificationRoutes(app: Express) {
  app.get("/api/notifications", requireAuth, async (req, res) => {
    try {
      const notifications = await storage.getNotifications((req as any).user.userId);
      res.json(notifications);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch notifications" });
    }
  });

  app.get("/api/notifications/unread-count", requireAuth, async (req, res) => {
    try {
      const count = await storage.getUnreadNotificationCount((req as any).user.userId);
      res.json({ count });
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch count" });
    }
  });

  app.post("/api/notifications/:id/read", requireAuth, async (req, res) => {
    try {
      const notifId = Array.isArray(req.params.id) ? req.params.id[0] : String(req.params.id);
      const notification = await storage.markNotificationRead(notifId);
      if (!notification) return res.status(404).json({ error: "Not found" });
      res.json(notification);
    } catch (err) {
      res.status(500).json({ error: "Failed to mark read" });
    }
  });

  app.post("/api/notifications/read-all", requireAuth, async (req, res) => {
    try {
      await storage.markAllNotificationsRead((req as any).user.userId);
      res.json({ ok: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to mark all read" });
    }
  });

  app.get("/api/push/vapid-public-key", requireAuth, async (_req, res) => {
    const key = getVapidPublicKey();
    if (!key) {
      return res.json({ key: null, configured: false });
    }
    res.json({ key, configured: true });
  });

  app.post("/api/push/subscribe", requireAuth, async (req, res) => {
    try {
      const body = pushSubscribeSchema.parse(req.body);
      await storage.createPushSubscription({
        userId: (req as any).user.userId,
        endpoint: body.endpoint,
        p256dh: body.keys.p256dh,
        auth: body.keys.auth,
        userAgent: req.headers["user-agent"] || null,
      });
      res.json({ ok: true });
    } catch (err) {
      res.status(400).json({ error: "Invalid subscription data" });
    }
  });

  app.post("/api/push/unsubscribe", requireAuth, async (req, res) => {
    try {
      const { endpoint } = req.body;
      if (endpoint) {
        await storage.deletePushSubscription(endpoint);
      } else {
        await storage.deletePushSubscriptionsByUser((req as any).user.userId);
      }
      res.json({ ok: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to unsubscribe" });
    }
  });

  app.get("/api/push/generate-vapid", requireAuth, async (req, res) => {
    if ((req as any).user.role !== "admin") return res.status(403).json({ error: "Admin only" });
    const keys = generateVapidKeys();
    res.json(keys);
  });
}
