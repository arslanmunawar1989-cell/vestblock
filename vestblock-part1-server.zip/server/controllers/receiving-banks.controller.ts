import type { Express, Request, Response } from "express";
import { requireAuth, requireRole } from "../auth";
import { storage } from "../storage";
import { createReceivingBankAccountSchema } from "@shared/schema";

export function registerReceivingBanksRoutes(app: Express) {
  app.get("/api/receiving-banks", requireAuth, async (_req: Request, res: Response) => {
    try {
      const accounts = await storage.getActiveReceivingBankAccounts();
      res.json(accounts);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/receiving-banks/:currency", requireAuth, async (req: Request, res: Response) => {
    try {
      const currency = (req.params.currency as string).toUpperCase();
      const countryCode = (req.query.country as string)?.toUpperCase();

      let account;
      if (countryCode) {
        account = await storage.getReceivingBankAccountByCountryAndCurrency(countryCode, currency);
      }
      if (!account) {
        account = await storage.getReceivingBankAccountByCurrency(currency);
      }
      if (!account) {
        return res.status(404).json({ error: `No active receiving bank account for ${currency}` });
      }
      res.json(account);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/admin/receiving-banks", requireAuth, requireRole("admin"), async (_req: Request, res: Response) => {
    try {
      const accounts = await storage.getAllReceivingBankAccounts();
      res.json(accounts);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/admin/receiving-banks", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const parsed = createReceivingBankAccountSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Validation failed", details: parsed.error.flatten().fieldErrors });
      }
      const account = await storage.createReceivingBankAccount({
        ...parsed.data,
        updatedBy: (req as any).userId,
      });
      res.status(201).json(account);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.patch("/api/admin/receiving-banks/:id", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const existing = await storage.getReceivingBankAccountById(req.params.id as string);
      if (!existing) {
        return res.status(404).json({ error: "Receiving bank account not found" });
      }
      const parsed = createReceivingBankAccountSchema.partial().safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Validation failed", details: parsed.error.flatten().fieldErrors });
      }
      const updated = await storage.updateReceivingBankAccount(req.params.id as string, {
        ...parsed.data,
        updatedBy: (req as any).userId,
      });
      res.json(updated);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete("/api/admin/receiving-banks/:id", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const existing = await storage.getReceivingBankAccountById(req.params.id as string);
      if (!existing) {
        return res.status(404).json({ error: "Receiving bank account not found" });
      }
      const deactivated = await storage.deactivateReceivingBankAccount(req.params.id as string);
      res.json(deactivated);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });
}
