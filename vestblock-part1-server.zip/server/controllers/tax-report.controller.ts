import type { Express } from "express";
import { requireAuth } from "../auth";
import { db } from "../db";
import { portfolioItems, assets, distributions, walletTransactions, walletAccounts, transactions } from "@shared/schema";
import { eq, and, gte, lt, inArray } from "drizzle-orm";

function escapeCsv(val: string | number | null | undefined): string {
  if (val === null || val === undefined) return "";
  const str = String(val);
  if (str.includes(",") || str.includes('"') || str.includes("\n")) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

function buildCsv(headers: string[], rows: (string | number | null | undefined)[][]): string {
  const headerLine = headers.map(escapeCsv).join(",");
  const dataLines = rows.map(row => row.map(escapeCsv).join(","));
  return [headerLine, ...dataLines].join("\n");
}

export function registerTaxReportRoutes(app: Express) {
  app.get("/api/tax-reports/holdings", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;

      const userPortfolio = await db.select()
        .from(portfolioItems)
        .where(eq(portfolioItems.userId, userId));

      const assetIds = userPortfolio.map(p => p.assetId);
      let assetMap: Record<string, any> = {};
      if (assetIds.length > 0) {
        const assetList = await db.select().from(assets).where(inArray(assets.id, assetIds));
        assetMap = Object.fromEntries(assetList.map(a => [a.id, a]));
      }

      const holdings = userPortfolio.map(p => {
        const asset = assetMap[p.assetId];
        return {
          quantity: p.quantity,
          averageCost: p.averageCost,
          assetName: asset?.name || "Unknown",
          assetSymbol: asset?.symbol || "N/A",
          assetType: asset?.type || "N/A",
          baseCurrency: asset?.baseCurrency || "N/A",
          country: asset?.country || "N/A",
          pricePerToken: asset?.pricePerToken || "0",
        };
      });

      const rows = holdings.map(h => {
        const qty = parseFloat(h.quantity);
        const avgCost = parseFloat(h.averageCost);
        const currentPrice = parseFloat(h.pricePerToken);
        const totalCost = qty * avgCost;
        const currentValue = qty * currentPrice;
        const unrealizedGain = currentValue - totalCost;
        return [
          h.assetName,
          h.assetSymbol,
          h.assetType,
          h.country,
          h.baseCurrency,
          qty.toFixed(6),
          avgCost.toFixed(6),
          currentPrice.toFixed(6),
          totalCost.toFixed(2),
          currentValue.toFixed(2),
          unrealizedGain.toFixed(2),
        ];
      });

      const headers = [
        "Asset Name", "Symbol", "Type", "Country", "Currency",
        "Units Held", "Avg Cost/Unit", "Current Price/Unit",
        "Total Cost Basis", "Current Market Value", "Unrealized Gain/Loss",
      ];

      const csv = buildCsv(headers, rows);
      const today = new Date().toISOString().slice(0, 10);
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="holdings_by_country_${today}_for_accountant_export.csv"`);
      res.send(csv);
    } catch (err: any) {
      console.error("Holdings export error:", err);
      res.status(500).json({ message: "Failed to generate holdings export" });
    }
  });

  app.get("/api/tax-reports/distributions", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const { startDate, endDate } = req.query as { startDate?: string; endDate?: string };

      const userAccounts = await db.select({ id: walletAccounts.id, currency: walletAccounts.currency })
        .from(walletAccounts)
        .where(eq(walletAccounts.userId, userId));

      if (userAccounts.length === 0) {
        const csv = buildCsv(
          ["Date", "Asset Name", "Symbol", "Country", "Currency", "Gross Amount", "Type", "Reference"],
          []
        );
        const today = new Date().toISOString().slice(0, 10);
        res.setHeader("Content-Type", "text/csv");
        res.setHeader("Content-Disposition", `attachment; filename="distribution_summary_${today}_for_accountant_export.csv"`);
        return res.send(csv);
      }

      const accountIds = userAccounts.map(a => a.id);
      const accountCurrencyMap = Object.fromEntries(userAccounts.map(a => [a.id, a.currency]));

      const conditions = [
        inArray(walletTransactions.walletAccountId, accountIds),
        eq(walletTransactions.type, "DIVIDEND"),
        eq(walletTransactions.status, "COMPLETED"),
      ];
      if (startDate) conditions.push(gte(walletTransactions.createdAt, startDate));
      if (endDate) conditions.push(lt(walletTransactions.createdAt, endDate + "T23:59:59.999Z"));

      const dividendTxs = await db.select().from(walletTransactions)
        .where(and(...conditions));

      const assetIds = new Set<string>();
      for (const tx of dividendTxs) {
        const meta = tx.metadata as any;
        if (meta?.assetId) assetIds.add(meta.assetId);
      }

      let assetMap: Record<string, any> = {};
      if (assetIds.size > 0) {
        const assetList = await db.select({
          id: assets.id,
          name: assets.name,
          symbol: assets.symbol,
          country: assets.country,
        }).from(assets).where(inArray(assets.id, Array.from(assetIds)));
        assetMap = Object.fromEntries(assetList.map(a => [a.id, a]));
      }

      const rows = dividendTxs.map(tx => {
        const meta = tx.metadata as any;
        const asset = meta?.assetId ? assetMap[meta.assetId] : null;
        return [
          tx.createdAt ? tx.createdAt.slice(0, 10) : "",
          asset?.name || "N/A",
          asset?.symbol || "N/A",
          asset?.country || "N/A",
          tx.currency,
          parseFloat(tx.amount).toFixed(2),
          "Distribution/Dividend",
          tx.referenceId || "",
        ];
      });

      rows.sort((a, b) => String(a[0]).localeCompare(String(b[0])));

      const headers = ["Date", "Asset Name", "Symbol", "Country", "Currency", "Gross Amount", "Type", "Reference"];
      const csv = buildCsv(headers, rows);
      const today = new Date().toISOString().slice(0, 10);
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="distribution_summary_${today}_for_accountant_export.csv"`);
      res.send(csv);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to generate distribution export" });
    }
  });

  app.get("/api/tax-reports/capital-gains", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;

      const userAccounts = await db.select({ id: walletAccounts.id, currency: walletAccounts.currency })
        .from(walletAccounts)
        .where(eq(walletAccounts.userId, userId));

      const accountIds = userAccounts.length > 0 ? userAccounts.map(a => a.id) : ["__none__"];

      const tradeSellTxs = await db.select().from(walletTransactions)
        .where(and(
          inArray(walletTransactions.walletAccountId, accountIds),
          eq(walletTransactions.type, "TRADE_SELL"),
          eq(walletTransactions.status, "COMPLETED"),
        ));

      const assetIds = new Set<string>();
      for (const tx of tradeSellTxs) {
        const meta = tx.metadata as any;
        if (meta?.assetId) assetIds.add(meta.assetId);
      }

      let assetMap: Record<string, any> = {};
      if (assetIds.size > 0) {
        const assetList = await db.select({
          id: assets.id,
          name: assets.name,
          symbol: assets.symbol,
          country: assets.country,
          baseCurrency: assets.baseCurrency,
        }).from(assets).where(inArray(assets.id, Array.from(assetIds)));
        assetMap = Object.fromEntries(assetList.map(a => [a.id, a]));
      }

      const rows = tradeSellTxs.map(tx => {
        const meta = tx.metadata as any;
        const asset = meta?.assetId ? assetMap[meta.assetId] : null;
        const units = meta?.units ? parseFloat(meta.units) : 0;
        const salePrice = parseFloat(tx.amount);
        return [
          tx.createdAt ? tx.createdAt.slice(0, 10) : "",
          asset?.name || "N/A",
          asset?.symbol || "N/A",
          asset?.country || "N/A",
          tx.currency,
          units.toFixed(6),
          salePrice.toFixed(2),
          "N/A (placeholder)",
          "N/A (placeholder)",
          "N/A (placeholder)",
          "Requires cost basis calculation",
        ];
      });

      rows.sort((a, b) => String(a[0]).localeCompare(String(b[0])));

      const headers = [
        "Sale Date", "Asset Name", "Symbol", "Country", "Currency",
        "Units Sold", "Sale Proceeds", "Cost Basis", "Capital Gain/Loss", "Holding Period",
        "Notes",
      ];

      const csv = buildCsv(headers, rows);
      const today = new Date().toISOString().slice(0, 10);
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="capital_gains_${today}_for_accountant_export_PLACEHOLDER.csv"`);
      res.send(csv);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to generate capital gains export" });
    }
  });
}
