import type { Express } from "express";
import { requireAuth, requireRole } from "../auth";
import { db } from "../db";
import { sql } from "drizzle-orm";
import fs from "fs";
import path from "path";

export function registerHealthRoutes(app: Express) {
  app.get("/api/health", async (_req, res) => {
    const checks: Record<string, { ok: boolean; detail?: string }> = {};

    try {
      await db.execute(sql`SELECT 1`);
      checks.database = { ok: true };
    } catch (err: any) {
      checks.database = { ok: false, detail: err.message };
    }

    checks.auth = { ok: true, detail: "JWT + session-based auth active" };

    const resendKey = process.env.RESEND_API_KEY;
    checks.email = {
      ok: true,
      detail: resendKey ? "production (Resend)" : "development (log-only)",
    };

    const allOk = Object.values(checks).every((c) => c.ok);

    res.status(allOk ? 200 : 503).json({
      status: allOk ? "healthy" : "degraded",
      timestamp: new Date().toISOString(),
      checks,
    });
  });

  app.get("/api/health/rbac", requireAuth, requireRole("admin"), async (_req, res) => {
    const roleMapping = {
      CLIENT: "investor",
      AGENT: "agent",
      MANAGER: "admin",
      WEBSITE_MANAGER: "cms",
      SUPER_ADMIN: "SUPER_ADMIN",
    };

    res.json({
      status: "ok",
      roleMapping,
      defaultRole: "investor",
      platformRoles: ["SUPER_ADMIN", "PLATFORM_ADMIN"],
      baseRoles: ["investor", "issuer", "agent", "admin", "cms"],
    });
  });

  app.get("/api/health/pwa", (_req, res) => {
    const publicDir = path.resolve(process.cwd(), "client", "public");

    const manifestExists = fs.existsSync(path.join(publicDir, "manifest.json"));
    const swExists = fs.existsSync(path.join(publicDir, "sw.js"));
    const offlineExists = fs.existsSync(path.join(publicDir, "offline.html"));
    const icon192 = fs.existsSync(path.join(publicDir, "icon-192.png"));
    const icon512 = fs.existsSync(path.join(publicDir, "icon-512.png"));

    const allOk = manifestExists && swExists && offlineExists && icon192 && icon512;

    res.json({
      status: allOk ? "ready" : "incomplete",
      assets: {
        manifest: manifestExists,
        serviceWorker: swExists,
        offlinePage: offlineExists,
        icon192: icon192,
        icon512: icon512,
      },
    });
  });
}
