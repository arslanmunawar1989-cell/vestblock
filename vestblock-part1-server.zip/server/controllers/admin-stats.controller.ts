import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { CURRENCY_TO_COUNTRY } from "@shared/constants";

export function registerAdminStatsRoutes(app: Express) {
  app.get("/api/admin/dashboard/stats", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const [paymentIntents, withdrawals, fxTransactions, dists, kycProfiles, users] = await Promise.all([
        storage.getAllPaymentIntents(req.tenantId),
        storage.getAllWithdrawalRequests(req.tenantId),
        storage.getAllFxTransactions(req.tenantId),
        storage.getDistributions(req.tenantId),
        storage.getAllKycProfiles(req.tenantId),
        storage.getUsers(req.tenantId),
      ]);

      const currencyStats: Record<string, {
        totalDeposits: number;
        depositCount: number;
        totalWithdrawals: number;
        withdrawalCount: number;
        totalFxConversions: number;
        fxCount: number;
        totalDistributions: number;
        distributionCount: number;
      }> = {};

      const ensureCurrency = (c: string) => {
        if (!currencyStats[c]) {
          currencyStats[c] = {
            totalDeposits: 0, depositCount: 0,
            totalWithdrawals: 0, withdrawalCount: 0,
            totalFxConversions: 0, fxCount: 0,
            totalDistributions: 0, distributionCount: 0,
          };
        }
      };

      for (const pi of paymentIntents) {
        if (pi.status === "CONFIRMED") {
          ensureCurrency(pi.currency);
          currencyStats[pi.currency].totalDeposits += parseFloat(pi.netAmount) || 0;
          currencyStats[pi.currency].depositCount++;
        }
      }

      for (const wr of withdrawals) {
        if (wr.status === "APPROVED" || wr.status === "PAID") {
          ensureCurrency(wr.currency);
          currencyStats[wr.currency].totalWithdrawals += parseFloat(wr.amount) || 0;
          currencyStats[wr.currency].withdrawalCount++;
        }
      }

      for (const fx of fxTransactions) {
        if (fx.status === "COMPLETED") {
          ensureCurrency(fx.fromCurrency);
          currencyStats[fx.fromCurrency].totalFxConversions += parseFloat(fx.amountFrom) || 0;
          currencyStats[fx.fromCurrency].fxCount++;
        }
      }

      for (const d of dists) {
        ensureCurrency(d.currency);
        currencyStats[d.currency].totalDistributions += parseFloat(d.amount) || 0;
        currencyStats[d.currency].distributionCount++;
      }

      const pendingKyc = kycProfiles.filter(p => p.status === "IN_REVIEW").length;
      const pendingDeposits = paymentIntents.filter(p => p.status === "PENDING" || p.status === "CREATED").length;
      const pendingWithdrawals = withdrawals.filter(w => w.status === "REQUESTED").length;

      res.json({
        currencyStats,
        totals: {
          users: users.length,
          kycProfiles: kycProfiles.length,
          pendingKyc,
          pendingDeposits,
          pendingWithdrawals,
          totalDeposits: paymentIntents.filter(p => p.status === "CONFIRMED").length,
          totalWithdrawals: withdrawals.filter(w => w.status === "APPROVED" || w.status === "PAID").length,
          totalFxTransactions: fxTransactions.filter(f => f.status === "COMPLETED").length,
          totalDistributions: dists.length,
        },
      });
    } catch (err: any) {
      console.error("Admin dashboard stats error:", err);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  app.get("/api/admin/distributions", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const dists = await storage.getDistributions(req.tenantId);
      const assetMap = new Map<string, any>();
      for (const d of dists) {
        if (!assetMap.has(d.assetId)) {
          const asset = await storage.getAsset(d.assetId);
          assetMap.set(d.assetId, asset);
        }
      }
      const enriched = dists.map(d => ({
        ...d,
        asset: assetMap.get(d.assetId) ? { id: assetMap.get(d.assetId).id, name: assetMap.get(d.assetId).name, symbol: assetMap.get(d.assetId).symbol } : null,
      }));
      res.json(enriched);
    } catch (err: any) {
      console.error("Admin distributions list error:", err);
      res.status(500).json({ message: "Failed to fetch distributions" });
    }
  });

  app.get("/api/admin/fx-transactions", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const txs = await storage.getAllFxTransactions(req.tenantId);
      const userMap = new Map<string, any>();
      for (const tx of txs) {
        if (!userMap.has(tx.userId)) {
          const user = await storage.getUser(tx.userId);
          userMap.set(tx.userId, user);
        }
      }
      const enriched = txs.map(tx => ({
        ...tx,
        user: userMap.get(tx.userId) ? {
          fullName: userMap.get(tx.userId).fullName,
          username: userMap.get(tx.userId).username,
          email: userMap.get(tx.userId).email,
        } : null,
      }));
      res.json(enriched);
    } catch (err: any) {
      console.error("Admin FX transactions list error:", err);
      res.status(500).json({ message: "Failed to fetch FX transactions" });
    }
  });
}
