import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth } from "../auth";
import { upsertCountryProfileSchema } from "@shared/schema";
import { countryCodeSchema } from "@shared/constants";
import { z } from "zod";

export function registerCountryProfileRoutes(app: Express) {
  app.get("/api/country-profiles", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const profiles = await storage.getCountryProfiles(userId);
      res.json(profiles);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch country profiles" });
    }
  });

  app.post("/api/country-profiles", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const data = upsertCountryProfileSchema.parse(req.body);

      const profile = await storage.upsertCountryProfile(userId, {
        ...data,
        userId,
        residencyStatus: data.residencyStatus ?? null,
        addressLine1: data.addressLine1 ?? null,
        addressLine2: data.addressLine2 ?? null,
        city: data.city ?? null,
        stateProvince: data.stateProvince ?? null,
        postalCode: data.postalCode ?? null,
        phoneCountryCode: data.phoneCountryCode ?? null,
        phoneNumber: data.phoneNumber ?? null,
      });

      let pendingLegalDocs: any[] = [];

      if (data.isPrimary) {
        const countryDocs = await storage.getActiveLegalDocumentsByCountry(data.countryCode);
        const acceptances = await storage.getUserAcceptances(userId);
        const acceptedDocIds = new Set(acceptances.map(a => a.legalDocumentId));
        pendingLegalDocs = countryDocs.filter(d => !acceptedDocIds.has(d.id));

        if (pendingLegalDocs.length === 0) {
          await storage.setPrimaryCountry(userId, data.countryCode);
        }
      }

      const profiles = await storage.getCountryProfiles(userId);
      res.json({
        profile,
        profiles,
        pendingLegalDocs: pendingLegalDocs.map(d => ({
          id: d.id,
          type: d.type,
          title: d.title,
          content: d.content,
          version: d.version,
          country: d.country,
        })),
        requiresLegalAcceptance: pendingLegalDocs.length > 0,
      });
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      res.status(500).json({ message: "Failed to save country profile" });
    }
  });

  app.post("/api/country-profiles/confirm-primary", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const schema = z.object({
        countryCode: countryCodeSchema,
        acceptedDocumentIds: z.array(z.string().min(1)).min(1),
      });
      const { countryCode, acceptedDocumentIds } = schema.parse(req.body);

      const countryDocs = await storage.getActiveLegalDocumentsByCountry(countryCode);
      const countryDocIds = new Set(countryDocs.map(d => d.id));

      const invalidIds = acceptedDocumentIds.filter(id => !countryDocIds.has(id));
      if (invalidIds.length > 0) {
        return res.status(400).json({ message: "Some document IDs do not belong to this country" });
      }

      for (const docId of acceptedDocumentIds) {
        const already = await storage.hasUserAcceptedDocument(userId, docId);
        if (already) continue;
        await storage.createLegalAcceptance({
          userId,
          legalDocumentId: docId,
          ipAddress: req.ip || req.socket.remoteAddress || null,
        });
      }

      const acceptances = await storage.getUserAcceptances(userId);
      const acceptedSet = new Set(acceptances.map(a => a.legalDocumentId));
      const stillPending = countryDocs.filter(d => !acceptedSet.has(d.id));
      if (stillPending.length > 0) {
        return res.status(400).json({
          message: "Not all required legal documents for this country have been accepted",
          pendingDocs: stillPending.map(d => ({ id: d.id, type: d.type, title: d.title })),
        });
      }

      await storage.setPrimaryCountry(userId, countryCode);

      const profiles = await storage.getCountryProfiles(userId);
      res.json({ success: true, profiles });
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      res.status(500).json({ message: "Failed to confirm primary country" });
    }
  });

  app.delete("/api/country-profiles/:countryCode", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const countryCode = countryCodeSchema.parse(req.params.countryCode as string);
      const deleted = await storage.deleteCountryProfile(userId, countryCode);
      if (!deleted) return res.status(404).json({ message: "Country profile not found" });
      const profiles = await storage.getCountryProfiles(userId);
      res.json({ success: true, profiles });
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Invalid country code" });
      res.status(500).json({ message: "Failed to delete country profile" });
    }
  });
}
