import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { logAuditFromReq } from "../lib/audit-logger";
import type { AmlFlagType } from "@shared/schema";
import { z } from "zod";
import { getPolicy, shouldAutoEscalatePep, isLargeDeposit, getMaxOpenFlags } from "@shared/compliance-policy";

const HIGH_RISK_COUNTRIES = ["iran", "north korea", "syria", "cuba", "myanmar", "russia", "belarus", "venezuela", "yemen", "somalia", "libya", "afghanistan"];

async function runRiskRules(userId: string): Promise<{ flagType: AmlFlagType; severity: string; description: string; details: any }[]> {
  const flags: { flagType: AmlFlagType; severity: string; description: string; details: any }[] = [];
  const user = await storage.getUser(userId);
  if (!user) return flags;

  const kycProfile = await storage.getKycProfile(userId);

  const countryProfiles = await storage.getCountryProfiles(userId);
  const primary = countryProfiles.find(p => p.isPrimary) || countryProfiles[0];
  const userCountry = primary?.countryCode || "AE";
  const policy = getPolicy(userCountry);

  if (user.nationality && HIGH_RISK_COUNTRIES.some(c => user.nationality!.toLowerCase().includes(c))) {
    flags.push({
      flagType: "high_risk_country",
      severity: "high",
      description: `User nationality "${user.nationality}" is associated with a high-risk jurisdiction`,
      details: { nationality: user.nationality },
    });
  }

  if (kycProfile?.pepFlag && shouldAutoEscalatePep(userCountry)) {
    flags.push({
      flagType: "pep_flag",
      severity: "high",
      description: `PEP flagged - auto-escalation per ${policy.countryName} compliance policy`,
      details: { pepFlag: true, legalName: kycProfile.legalName, countryPolicy: userCountry },
    });
  }

  const txs = await storage.getTransactions(userId);
  const largeThreshold = policy.riskThresholds.largeDepositAmount;
  const largeTxs = txs.filter(t => parseFloat(t.amount) >= largeThreshold && (t.type === "deposit" || t.type === "purchase"));
  if (largeTxs.length > 0) {
    flags.push({
      flagType: "large_deposit",
      severity: "medium",
      description: `${largeTxs.length} transaction(s) exceed ${policy.riskThresholds.largeDepositCurrency} ${largeThreshold.toLocaleString()} threshold (${policy.countryName} policy)`,
      details: { transactions: largeTxs.map(t => ({ id: t.id, amount: t.amount, type: t.type })), threshold: largeThreshold, currency: policy.riskThresholds.largeDepositCurrency },
    });
  }

  if (kycProfile && user.fullName) {
    const normalize = (s: string) => s.toLowerCase().replace(/[^a-z]/g, "");
    if (normalize(kycProfile.legalName) !== normalize(user.fullName)) {
      flags.push({
        flagType: "name_mismatch",
        severity: "medium",
        description: `Account name "${user.fullName}" does not match KYC legal name "${kycProfile.legalName}"`,
        details: { accountName: user.fullName, kycName: kycProfile.legalName },
      });
    }
  }

  return flags;
}

const createFlagSchema = z.object({
  userId: z.string().min(1),
  flagType: z.enum(["high_risk_country", "pep_flag", "large_deposit", "name_mismatch"]),
  severity: z.enum(["low", "medium", "high", "critical"]).default("medium"),
  description: z.string().min(1),
  details: z.any().optional(),
});

const resolveFlagSchema = z.object({
  notes: z.string().min(1, "Resolution notes are required"),
});

export function registerAmlRoutes(app: Express) {
  app.post("/api/admin/aml/scan/:userId", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const targetUserId = req.params.userId as string;
      const user = await storage.getUser(targetUserId);
      if (!user) return res.status(404).json({ message: "User not found" });

      const riskResults = await runRiskRules(targetUserId);
      const existingFlags = await storage.getActiveAmlFlagsByUser(targetUserId);
      const existingTypes = new Set(existingFlags.map(f => f.flagType));

      const newFlags = [];
      for (const r of riskResults) {
        if (!existingTypes.has(r.flagType)) {
          const flag = await storage.createAmlFlag({
            userId: targetUserId,
            flagType: r.flagType,
            severity: r.severity,
            description: r.description,
            details: r.details,
            status: "active",
          });
          newFlags.push(flag);
        }
      }

      if (newFlags.length > 0 || existingFlags.length > 0) {
        await storage.updateUserEddStatus(targetUserId, "EDD_REQUIRED");
        await storage.createNotification({
          userId: targetUserId as string,
          type: "aml_flag",
          title: "Account Under Review",
          message: "Your account has been flagged for enhanced due diligence review. Some features may be temporarily restricted.",
          relatedEntityId: targetUserId as string,
          relatedEntityType: "user",
        });
      }

      await logAuditFromReq(req, "AML_SCAN", "user", targetUserId, {
        reason: `AML scan completed. ${newFlags.length} new flag(s) created. Total active: ${existingFlags.length + newFlags.length}`,
        metadata: { newFlagCount: newFlags.length, totalActive: existingFlags.length + newFlags.length },
      });

      res.json({ newFlags, existingFlags, totalActive: existingFlags.length + newFlags.length });
    } catch (err: any) {
      console.error("AML scan error:", err);
      res.status(500).json({ message: "Failed to run AML scan" });
    }
  });

  app.post("/api/admin/aml/flags", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const data = createFlagSchema.parse(req.body);
      const user = await storage.getUser(data.userId);
      if (!user) return res.status(404).json({ message: "User not found" });

      const flag = await storage.createAmlFlag({
        userId: data.userId,
        flagType: data.flagType,
        severity: data.severity,
        description: data.description,
        details: data.details || null,
        status: "active",
      });

      await storage.updateUserEddStatus(data.userId, "EDD_REQUIRED");

      await storage.createNotification({
        userId: data.userId,
        type: "aml_flag",
        title: "Account Under Review",
        message: "Your account has been flagged for enhanced due diligence review. Some features may be temporarily restricted.",
        relatedEntityId: flag.id,
        relatedEntityType: "aml_flag",
      });

      await logAuditFromReq(req, "AML_FLAG_CREATED", "aml_flag", flag.id, {
        reason: `Manual AML flag created: ${data.flagType} (${data.severity}) - ${data.description}`,
        afterState: { flagType: data.flagType, severity: data.severity, status: "active" },
      });

      res.status(201).json(flag);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("AML flag create error:", err);
      res.status(500).json({ message: "Failed to create AML flag" });
    }
  });

  app.get("/api/admin/aml/flags", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const flags = await storage.getAllAmlFlags(req.tenantId);
      const enriched = await Promise.all(flags.map(async (f) => {
        const user = await storage.getUser(f.userId);
        return {
          ...f,
          user: user ? { id: user.id, username: user.username, email: user.email, fullName: user.fullName, eddStatus: user.eddStatus } : null,
        };
      }));
      res.json(enriched);
    } catch (err: any) {
      console.error("AML flags list error:", err);
      res.status(500).json({ message: "Failed to fetch AML flags" });
    }
  });

  app.get("/api/admin/aml/flags/user/:userId", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const flags = await storage.getAmlFlagsByUser(req.params.userId as string);
      const user = await storage.getUser(req.params.userId as string);
      res.json({ flags, user: user ? { id: user.id, username: user.username, fullName: user.fullName, eddStatus: user.eddStatus } : null });
    } catch (err: any) {
      console.error("User AML flags error:", err);
      res.status(500).json({ message: "Failed to fetch user AML flags" });
    }
  });

  app.post("/api/admin/aml/flags/:id/resolve", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const flag = await storage.getAmlFlagById(req.params.id as string);
      if (!flag) return res.status(404).json({ message: "AML flag not found" });

      const { notes } = resolveFlagSchema.parse(req.body);
      const adminId = (req as any).user.userId;

      const resolved = await storage.resolveAmlFlag(flag.id, adminId, notes);

      const remainingActive = await storage.getActiveAmlFlagsByUser(flag.userId);
      if (remainingActive.length === 0) {
        await storage.updateUserEddStatus(flag.userId, "EDD_COMPLETE");
        await storage.createNotification({
          userId: flag.userId,
          type: "aml_cleared",
          title: "Account Restrictions Lifted",
          message: "All compliance flags on your account have been resolved. Your account is now fully active.",
          relatedEntityId: flag.userId,
          relatedEntityType: "user",
        });
      }

      await logAuditFromReq(req, "AML_FLAG_RESOLVED", "aml_flag", flag.id, {
        reason: `Flag resolved by admin ${adminId}: ${notes}`,
        beforeState: { status: flag.status },
        afterState: { status: "resolved" },
      });

      res.json(resolved);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("AML flag resolve error:", err);
      res.status(500).json({ message: "Failed to resolve AML flag" });
    }
  });

  app.post("/api/admin/aml/edd/:userId/complete", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const user = await storage.getUser(req.params.userId as string);
      if (!user) return res.status(404).json({ message: "User not found" });

      const notesSchema = z.object({ notes: z.string().optional() });
      const { notes } = notesSchema.parse(req.body);
      const adminId = (req as any).user.userId;

      await storage.updateUserEddStatus(user.id, "EDD_COMPLETE");

      await storage.createNotification({
        userId: user.id,
        type: "edd_complete",
        title: "Enhanced Due Diligence Complete",
        message: notes || "Your enhanced due diligence review has been completed. Your account is now fully active.",
        relatedEntityId: user.id,
        relatedEntityType: "user",
      });

      await logAuditFromReq(req, "EDD_COMPLETE", "user", user.id, {
        reason: `EDD marked complete by admin ${adminId}${notes ? `: ${notes}` : ""}`,
        beforeState: { eddStatus: user.eddStatus },
        afterState: { eddStatus: "EDD_COMPLETE" },
      });

      res.json({ message: "EDD marked as complete", eddStatus: "EDD_COMPLETE" });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("EDD complete error:", err);
      res.status(500).json({ message: "Failed to complete EDD" });
    }
  });

  app.get("/api/edd-status", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const user = await storage.getUser(userId);
      if (!user) return res.status(404).json({ message: "User not found" });
      const activeFlags = await storage.getActiveAmlFlagsByUser(userId);
      res.json({
        eddStatus: user.eddStatus,
        hasActiveFlags: activeFlags.length > 0,
        activeFlagCount: activeFlags.length,
        isBlocked: user.eddStatus === "EDD_REQUIRED" || user.eddStatus === "EDD_IN_PROGRESS",
      });
    } catch (err: any) {
      console.error("EDD status error:", err);
      res.status(500).json({ message: "Failed to fetch EDD status" });
    }
  });
}
