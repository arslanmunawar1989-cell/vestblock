import type { Express, Request, Response } from "express";
import { requireAuth, requireRole, requireTenantAction } from "../auth";
import { db } from "../db";
import { tenants, tenantUsers, users, projects, projectMembers, projectActivityLogs, paymentIntents, kycProfiles, portfolioItems, assets, walletAccounts, walletTransactions, tradeListings, notifications } from "@shared/schema";
import { sql, count, desc, eq, and } from "drizzle-orm";

export function registerAnalyticsRoutes(app: Express) {
  app.get("/api/analytics/platform", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const [tenantRows] = await db.select({ count: count() }).from(tenants);
      const [userRows] = await db.select({ count: count() }).from(users);
      const [projectRows] = await db.select({ count: count() }).from(projects);
      const [activeInvestors] = await db.select({ count: count() }).from(users).where(sql`${users.role} = 'investor'`);
      const [activeTenants] = await db.select({ count: count() }).from(tenants).where(sql`${tenants.status} = 'ACTIVE'`);
      const [confirmedDeposits] = await db.select({
        count: count(),
        total: sql<string>`COALESCE(SUM(CAST(net_amount AS NUMERIC)), 0)`,
      }).from(paymentIntents).where(sql`${paymentIntents.status} = 'CONFIRMED'`);
      const [kycCount] = await db.select({ count: count() }).from(kycProfiles);

      const projectsByStatus = await db.select({
        status: projects.status,
        count: count(),
      }).from(projects).groupBy(projects.status);

      const projectsByType = await db.select({
        type: projects.type,
        count: count(),
      }).from(projects).groupBy(projects.type);

      const tenantProjectCounts = await db.select({
        tenantId: projects.tenantId,
        count: count(),
      }).from(projects).groupBy(projects.tenantId);
      const tenantNames = await db.select({ id: tenants.id, name: tenants.name }).from(tenants);
      const nameMap = Object.fromEntries(tenantNames.map(t => [t.id, t.name]));
      const projectsByTenant = tenantProjectCounts.map(r => ({
        name: nameMap[r.tenantId] || r.tenantId.slice(0, 8),
        projects: Number(r.count),
      }));

      const usersByRole = await db.select({
        role: users.role,
        count: count(),
      }).from(users).groupBy(users.role);

      const thirtyDaysAgo = new Date(Date.now() - 30 * 86400000).toISOString();

      const recentTenantUsers = await db.select({
        date: sql<string>`DATE(${tenantUsers.createdAt})`,
        count: count(),
      }).from(tenantUsers).where(sql`${tenantUsers.createdAt} >= ${thirtyDaysAgo}`).groupBy(sql`DATE(${tenantUsers.createdAt})`);

      const recentProjects = await db.select({
        date: sql<string>`DATE(${projects.createdAt})`,
        count: count(),
      }).from(projects).where(sql`${projects.createdAt} >= ${thirtyDaysAgo}`).groupBy(sql`DATE(${projects.createdAt})`);

      const recentActivity = await db.select({
        date: sql<string>`DATE(${projectActivityLogs.createdAt})`,
        count: count(),
      }).from(projectActivityLogs).where(sql`${projectActivityLogs.createdAt} >= ${thirtyDaysAgo}`).groupBy(sql`DATE(${projectActivityLogs.createdAt})`);

      const last30 = generateDateRange(30);
      const userGrowth = fillDateSeries(last30, recentTenantUsers);
      const projectGrowth = fillDateSeries(last30, recentProjects);
      const activityTrend = fillDateSeries(last30, recentActivity);

      const recentTenants = await db.select({
        date: sql<string>`DATE(${tenants.createdAt})`,
        count: count(),
      }).from(tenants).where(sql`${tenants.createdAt} >= ${thirtyDaysAgo}`).groupBy(sql`DATE(${tenants.createdAt})`);
      const tenantGrowth = fillDateSeries(last30, recentTenants);

      res.json({
        kpis: {
          totalTenants: Number(tenantRows.count),
          activeTenants: Number(activeTenants.count),
          totalUsers: Number(userRows.count),
          totalProjects: Number(projectRows.count),
          activeInvestors: Number(activeInvestors.count),
          totalDeposits: Number(confirmedDeposits.count),
          depositVolume: parseFloat(confirmedDeposits.total as string) || 0,
          kycProfiles: Number(kycCount.count),
        },
        charts: {
          projectsByStatus: projectsByStatus.map(r => ({ name: formatLabel(r.status), value: Number(r.count) })),
          projectsByType: projectsByType.map(r => ({ name: formatLabel(r.type), value: Number(r.count) })),
          projectsByTenant,
          usersByRole: usersByRole.map(r => ({ name: formatLabel(r.role), value: Number(r.count) })),
          userGrowth,
          projectGrowth,
          activityTrend,
          tenantGrowth,
        },
      });
    } catch (err: any) {
      console.error("Platform analytics error:", err);
      res.status(500).json({ message: "Failed to fetch platform analytics" });
    }
  });

  app.get("/api/analytics/agent", requireAuth, requireRole("agent"), async (req: Request, res: Response) => {
    try {
      const agentId = (req as any).user.userId;
      console.log("Agent analytics for:", agentId);

      const clientResult = await db.execute(sql`SELECT id, full_name, username, email, kyc_status FROM users WHERE registered_agent = ${agentId}`);
      const clients: any[] = clientResult.rows || [];

      const clientIds = clients.map((c: any) => c.id);

      let clientPortfolios: any[] = [];
      let totalAum = 0;
      let totalInvestedAmount = 0;
      if (clientIds.length > 0) {
        const portfolioResult = await db.execute(sql`
          SELECT pi.user_id, pi.asset_id, pi.quantity, pi.average_cost,
                 a.name as asset_name, a.symbol as asset_symbol, a.base_currency, a.price_per_token
          FROM portfolio_items pi
          INNER JOIN assets a ON pi.asset_id = a.id
          WHERE pi.user_id IN (${sql.join(clientIds.map(id => sql`${id}`), sql`, `)})
        `);
        clientPortfolios = (portfolioResult.rows || []) as any[];
        for (const row of clientPortfolios) {
          const qty = parseFloat(row.quantity || "0");
          const price = parseFloat(row.price_per_token || "0");
          const cost = parseFloat(row.average_cost || "0");
          totalAum += qty * price;
          totalInvestedAmount += qty * cost;
        }
      }

      let activeListings = 0;
      if (clientIds.length > 0) {
        const listingResult = await db.execute(sql`
          SELECT COUNT(*) as cnt FROM trade_listings
          WHERE seller_id IN (${sql.join(clientIds.map(id => sql`${id}`), sql`, `)}) AND status = 'active'
        `);
        activeListings = Number((listingResult.rows || [])[0]?.cnt || 0);
      }

      const notifResult = await db.execute(sql`
        SELECT id, type, title, message, read, created_at FROM notifications
        WHERE user_id = ${agentId}
        ORDER BY created_at DESC LIMIT 10
      `);
      const agentNotifications: any[] = (notifResult.rows || []) as any[];

      const commissionNotifs = agentNotifications.filter((n: any) => n.type === "commission");
      let totalCommission = 0;
      for (const n of commissionNotifs) {
        const match = n.message?.match(/([\d,]+(?:\.\d+)?)\s*commission/i) || n.message?.match(/earned\s+\w+\s+([\d,]+(?:\.\d+)?)/i);
        if (match) {
          totalCommission += parseFloat(match[1].replace(/,/g, ""));
        }
      }

      const topClients = clients.map((c: any) => {
        const holdings = clientPortfolios.filter((p: any) => p.user_id === c.id);
        const invested = holdings.reduce((s: number, h: any) => s + parseFloat(h.quantity || "0") * parseFloat(h.average_cost || "0"), 0);
        const currentValue = holdings.reduce((s: number, h: any) => s + parseFloat(h.quantity || "0") * parseFloat(h.price_per_token || "0"), 0);
        return {
          id: c.id,
          name: c.full_name || c.username,
          email: c.email,
          kycStatus: c.kyc_status,
          invested,
          currentValue,
          assets: holdings.length,
        };
      }).sort((a: any, b: any) => b.currentValue - a.currentValue);

      const recentOffers = clientPortfolios.slice(0, 5).map((p: any) => ({
        client: clients.find((c: any) => c.id === p.user_id)?.full_name || "Unknown",
        asset: p.asset_name,
        symbol: p.asset_symbol,
        amount: parseFloat(p.quantity || "0") * parseFloat(p.average_cost || "0"),
        currency: p.base_currency,
        status: "Completed",
      }));

      const kycPending = clients.filter((c: any) => c.kyc_status === "pending").length;
      const kycVerified = clients.filter((c: any) => c.kyc_status === "verified").length;

      res.json({
        kpis: {
          totalClients: clients.length,
          activeListings,
          totalCommission,
          totalAum,
          kycPending,
          kycVerified,
          conversionRate: clients.length > 0 ? Math.round((kycVerified / clients.length) * 100) : 0,
        },
        topClients,
        recentOffers,
        notifications: agentNotifications.map((n: any) => ({
          id: n.id,
          type: n.type,
          title: n.title,
          message: n.message,
          read: n.read,
          createdAt: n.created_at,
        })),
      });
    } catch (err: any) {
      console.error("Agent analytics error:", err);
      res.status(500).json({ message: "Failed to fetch agent analytics" });
    }
  });

  app.get("/api/analytics/agency/:tenantId", requireAuth, requireTenantAction("tenant_projects.view"), async (req: Request, res: Response) => {
    try {
      const tenantId = req.params.tenantId;

      const tenantProjects = await db.select().from(projects).where(sql`${projects.tenantId} = ${tenantId}`);
      const [memberCount] = await db.select({ count: count() }).from(projectMembers)
        .where(sql`${projectMembers.projectId} IN (SELECT id FROM projects WHERE tenant_id = ${tenantId})`);
      const [tenantUserCount] = await db.select({ count: count() }).from(tenantUsers).where(sql`${tenantUsers.tenantId} = ${tenantId}`);

      const totalProjects = tenantProjects.length;
      const activeProjects = tenantProjects.filter(p => p.status === "IN_PROGRESS").length;
      const planningProjects = tenantProjects.filter(p => p.status === "PLANNING").length;
      const completedProjects = tenantProjects.filter(p => p.status === "COMPLETED").length;
      const onHoldProjects = tenantProjects.filter(p => p.status === "ON_HOLD").length;

      const now = new Date();
      const onTime = tenantProjects.filter(p => {
        if (!p.dueDate || p.status === "COMPLETED" || p.status === "CANCELLED") return true;
        return new Date(p.dueDate) >= now;
      }).length;
      const delayed = totalProjects - onTime;

      const avgHealth = totalProjects > 0
        ? Math.round(tenantProjects.reduce((s, p) => s + (p.healthScore || 0), 0) / totalProjects)
        : 0;
      const avgMarket = totalProjects > 0
        ? Math.round(tenantProjects.reduce((s, p) => s + (p.marketScore || 0), 0) / totalProjects)
        : 0;

      const projectsByStatus = [
        { name: "Planning", value: planningProjects },
        { name: "In Progress", value: activeProjects },
        { name: "On Hold", value: onHoldProjects },
        { name: "Completed", value: completedProjects },
        { name: "Cancelled", value: tenantProjects.filter(p => p.status === "CANCELLED").length },
      ].filter(r => r.value > 0);

      const projectsByType = Object.entries(
        tenantProjects.reduce<Record<string, number>>((acc, p) => {
          acc[p.type] = (acc[p.type] || 0) + 1;
          return acc;
        }, {})
      ).map(([name, value]) => ({ name: formatLabel(name), value }));

      const healthDistribution = tenantProjects.map(p => ({
        name: p.name.length > 20 ? p.name.slice(0, 20) + "..." : p.name,
        health: p.healthScore || 0,
        market: p.marketScore || 0,
      }));

      const thirtyDaysAgo = new Date(Date.now() - 30 * 86400000).toISOString();
      const projectIds = tenantProjects.map(p => p.id);

      let recentActivity: { date: string; count: number }[] = [];
      if (projectIds.length > 0) {
        const rawActivity = await db.select({
          date: sql<string>`DATE(${projectActivityLogs.createdAt})`,
          count: count(),
        }).from(projectActivityLogs)
          .where(sql`${projectActivityLogs.projectId} IN (SELECT id FROM projects WHERE tenant_id = ${tenantId}) AND ${projectActivityLogs.createdAt} >= ${thirtyDaysAgo}`)
          .groupBy(sql`DATE(${projectActivityLogs.createdAt})`);
        recentActivity = rawActivity.map(r => ({ date: String(r.date), count: Number(r.count) }));
      }

      const last30 = generateDateRange(30);
      const activityTrend = fillDateSeries(last30, recentActivity);

      let milestones: any[] = [];
      if (projectIds.length > 0) {
        const rawMilestones = await db.select({
          id: projectActivityLogs.id,
          projectId: projectActivityLogs.projectId,
          action: projectActivityLogs.action,
          details: projectActivityLogs.details,
          createdAt: projectActivityLogs.createdAt,
        }).from(projectActivityLogs)
          .where(sql`${projectActivityLogs.projectId} IN (SELECT id FROM projects WHERE tenant_id = ${tenantId})`)
          .orderBy(desc(projectActivityLogs.createdAt))
          .limit(10);

        const projectNameMap = Object.fromEntries(tenantProjects.map(p => [p.id, p.name]));
        milestones = rawMilestones.map(m => ({
          ...m,
          projectName: projectNameMap[m.projectId] || "Unknown",
        }));
      }

      const recentTenantUsers = await db.select({
        date: sql<string>`DATE(${tenantUsers.createdAt})`,
        count: count(),
      }).from(tenantUsers)
        .where(sql`${tenantUsers.tenantId} = ${tenantId} AND ${tenantUsers.createdAt} >= ${thirtyDaysAgo}`)
        .groupBy(sql`DATE(${tenantUsers.createdAt})`);
      const userGrowth = fillDateSeries(last30, recentTenantUsers);

      res.json({
        kpis: {
          totalProjects,
          activeProjects,
          planningProjects,
          completedProjects,
          onHoldProjects,
          totalMembers: Number(memberCount.count),
          totalUsers: Number(tenantUserCount.count),
          onTime,
          delayed,
          avgHealth,
          avgMarket,
        },
        charts: {
          projectsByStatus,
          projectsByType,
          healthDistribution,
          activityTrend,
          userGrowth,
          onTimeVsDelayed: [
            { name: "On Time", value: onTime },
            { name: "Delayed", value: delayed },
          ].filter(r => r.value > 0),
        },
        milestones,
      });
    } catch (err: any) {
      console.error("Agency analytics error:", err);
      res.status(500).json({ message: "Failed to fetch agency analytics" });
    }
  });
}

function generateDateRange(days: number): string[] {
  const dates: string[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(Date.now() - i * 86400000);
    dates.push(d.toISOString().split("T")[0]);
  }
  return dates;
}

function fillDateSeries(dates: string[], data: { date: string; count: number }[]): { date: string; value: number }[] {
  const map = new Map(data.map(d => [d.date, Number(d.count)]));
  return dates.map(date => ({ date, value: map.get(date) || 0 }));
}

function formatLabel(s: string): string {
  return s.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase()).toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
}
