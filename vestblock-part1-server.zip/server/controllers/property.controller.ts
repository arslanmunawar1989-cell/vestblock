import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { z } from "zod";
import { milestoneStatusEnum, contractStatusEnum, developerPaymentStatusEnum, createPropertyAcquisitionSchema, updatePropertyAcquisitionSchema, createPropertyUnitSchema, updatePropertyUnitSchema, createPropertySaleSchema } from "@shared/schema";
import { previewPropertySale, executePropertySale } from "../services/property-sale.service";

const createMilestoneSchema = z.object({
  assetId: z.string().min(1),
  name: z.string().min(1),
  description: z.string().optional(),
  status: z.enum(milestoneStatusEnum).default("planned"),
  targetDate: z.string().optional(),
  completionDate: z.string().optional(),
  progressPercent: z.number().min(0).max(100).default(0),
  sortOrder: z.number().int().default(0),
  notes: z.string().optional(),
});

const updateMilestoneSchema = z.object({
  name: z.string().min(1).optional(),
  description: z.string().optional(),
  status: z.enum(milestoneStatusEnum).optional(),
  targetDate: z.string().optional(),
  completionDate: z.string().optional(),
  progressPercent: z.number().min(0).max(100).optional(),
  sortOrder: z.number().int().optional(),
  notes: z.string().optional(),
});

const createContractSchema = z.object({
  assetId: z.string().min(1),
  tenantName: z.string().min(1),
  tenantEmail: z.string().email().optional().or(z.literal("")),
  tenantPhone: z.string().optional(),
  unitIdentifier: z.string().optional(),
  startDate: z.string().min(1),
  endDate: z.string().min(1),
  monthlyRent: z.string().refine(v => parseFloat(v) > 0, "Monthly rent must be positive"),
  currency: z.string().min(1).default("AED"),
  securityDeposit: z.string().optional(),
  status: z.enum(contractStatusEnum).default("draft"),
  contractRef: z.string().optional(),
  notes: z.string().optional(),
});

const updateContractSchema = z.object({
  tenantName: z.string().min(1).optional(),
  tenantEmail: z.string().email().optional().or(z.literal("")),
  tenantPhone: z.string().optional(),
  unitIdentifier: z.string().optional(),
  startDate: z.string().min(1).optional(),
  endDate: z.string().min(1).optional(),
  monthlyRent: z.string().optional(),
  currency: z.string().optional(),
  securityDeposit: z.string().optional(),
  status: z.enum(contractStatusEnum).optional(),
  contractRef: z.string().optional(),
  notes: z.string().optional(),
});

const createManagerSchema = z.object({
  name: z.string().min(1),
  company: z.string().optional(),
  email: z.string().email().optional().or(z.literal("")),
  phone: z.string().optional(),
  licenseNumber: z.string().optional(),
  country: z.string().min(1).default("AE"),
  isActive: z.boolean().default(true),
  assignedAssetIds: z.array(z.string()).optional(),
  notes: z.string().optional(),
});

const updateManagerSchema = z.object({
  name: z.string().min(1).optional(),
  company: z.string().optional(),
  email: z.string().email().optional().or(z.literal("")),
  phone: z.string().optional(),
  licenseNumber: z.string().optional(),
  country: z.string().optional(),
  isActive: z.boolean().optional(),
  assignedAssetIds: z.array(z.string()).optional(),
  notes: z.string().optional(),
});

const createCategorySchema = z.object({
  name: z.string().min(1),
  description: z.string().optional(),
  isDefault: z.boolean().default(false),
});

const createDevPaymentSchema = z.object({
  assetId: z.string().min(1),
  milestoneId: z.string().optional(),
  label: z.string().min(1),
  dueDate: z.string().min(1),
  amount: z.string().refine(v => parseFloat(v) > 0, "Amount must be positive"),
  currency: z.string().min(1).default("AED"),
  status: z.enum(developerPaymentStatusEnum).default("planned"),
  paidDate: z.string().optional(),
  notes: z.string().optional(),
  sortOrder: z.number().int().default(0),
});

const updateDevPaymentSchema = z.object({
  label: z.string().min(1).optional(),
  dueDate: z.string().optional(),
  amount: z.string().optional(),
  currency: z.string().optional(),
  status: z.enum(developerPaymentStatusEnum).optional(),
  paidDate: z.string().optional(),
  notes: z.string().optional(),
  sortOrder: z.number().int().optional(),
  milestoneId: z.string().nullable().optional(),
});

export function registerPropertyRoutes(app: Express) {

  app.get("/api/properties/:assetId/milestones", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const milestones = await storage.getPropertyMilestonesByAsset(String(req.params.assetId));
      res.json(milestones);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/properties/:assetId/milestones", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const parsed = createMilestoneSchema.parse({ ...req.body, assetId: String(String(req.params.assetId)) });
      const milestone = await storage.createPropertyMilestone({
        ...parsed,
        createdBy: user.userId,
      });
      res.status(201).json(milestone);
    } catch (err: any) {
      if (err.name === "ZodError") return res.status(400).json({ message: "Validation error", errors: err.errors });
      res.status(500).json({ message: err.message });
    }
  });

  app.patch("/api/properties/milestones/:id", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const parsed = updateMilestoneSchema.parse(req.body);
      const milestone = await storage.updatePropertyMilestone(String(req.params.id), parsed);
      if (!milestone) return res.status(404).json({ message: "Milestone not found" });
      res.json(milestone);
    } catch (err: any) {
      if (err.name === "ZodError") return res.status(400).json({ message: "Validation error", errors: err.errors });
      res.status(500).json({ message: err.message });
    }
  });

  app.delete("/api/properties/milestones/:id", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const deleted = await storage.deletePropertyMilestone(String(req.params.id));
      if (!deleted) return res.status(404).json({ message: "Milestone not found" });
      res.json({ message: "Milestone deleted" });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/properties/:assetId/contracts", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const contracts = await storage.getRentalContractsByAsset(String(req.params.assetId));
      res.json(contracts);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/properties/contracts", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const contracts = await storage.getAllRentalContracts(req.tenantId);
      res.json(contracts);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/properties/:assetId/contracts", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const parsed = createContractSchema.parse({ ...req.body, assetId: String(String(req.params.assetId)) });
      const contract = await storage.createRentalContract({
        ...parsed,
        tenantEmail: parsed.tenantEmail || null,
        securityDeposit: parsed.securityDeposit || null,
        contractRef: parsed.contractRef || null,
        notes: parsed.notes || null,
        createdBy: user.userId,
      });
      res.status(201).json(contract);
    } catch (err: any) {
      if (err.name === "ZodError") return res.status(400).json({ message: "Validation error", errors: err.errors });
      res.status(500).json({ message: err.message });
    }
  });

  app.patch("/api/properties/contracts/:id", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const parsed = updateContractSchema.parse(req.body);
      const contract = await storage.updateRentalContract(String(req.params.id), parsed);
      if (!contract) return res.status(404).json({ message: "Contract not found" });
      res.json(contract);
    } catch (err: any) {
      if (err.name === "ZodError") return res.status(400).json({ message: "Validation error", errors: err.errors });
      res.status(500).json({ message: err.message });
    }
  });

  app.delete("/api/properties/contracts/:id", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const deleted = await storage.deleteRentalContract(String(req.params.id));
      if (!deleted) return res.status(404).json({ message: "Contract not found" });
      res.json({ message: "Contract deleted" });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/property-managers", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const managers = await storage.getAllPropertyManagers(req.tenantId);
      res.json(managers);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/property-managers", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const parsed = createManagerSchema.parse(req.body);
      const manager = await storage.createPropertyManager({
        ...parsed,
        email: parsed.email || null,
        company: parsed.company || null,
        phone: parsed.phone || null,
        licenseNumber: parsed.licenseNumber || null,
        notes: parsed.notes || null,
        assignedAssetIds: parsed.assignedAssetIds || [],
        createdBy: user.userId,
      });
      res.status(201).json(manager);
    } catch (err: any) {
      if (err.name === "ZodError") return res.status(400).json({ message: "Validation error", errors: err.errors });
      res.status(500).json({ message: err.message });
    }
  });

  app.patch("/api/property-managers/:id", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const parsed = updateManagerSchema.parse(req.body);
      const manager = await storage.updatePropertyManager(String(req.params.id), parsed);
      if (!manager) return res.status(404).json({ message: "Manager not found" });
      res.json(manager);
    } catch (err: any) {
      if (err.name === "ZodError") return res.status(400).json({ message: "Validation error", errors: err.errors });
      res.status(500).json({ message: err.message });
    }
  });

  app.delete("/api/property-managers/:id", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const deleted = await storage.deletePropertyManager(String(req.params.id));
      if (!deleted) return res.status(404).json({ message: "Manager not found" });
      res.json({ message: "Manager deleted" });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/property-expense-categories", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const categories = await storage.getAllPropertyExpenseCategories(req.tenantId);
      res.json(categories);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/property-expense-categories", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const parsed = createCategorySchema.parse(req.body);
      const category = await storage.createPropertyExpenseCategory({
        ...parsed,
        description: parsed.description || null,
        createdBy: user.userId,
      });
      res.status(201).json(category);
    } catch (err: any) {
      if (err.name === "ZodError") return res.status(400).json({ message: "Validation error", errors: err.errors });
      res.status(500).json({ message: err.message });
    }
  });

  app.patch("/api/property-expense-categories/:id", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const parsed = createCategorySchema.partial().parse(req.body);
      const category = await storage.updatePropertyExpenseCategory(String(req.params.id), parsed);
      if (!category) return res.status(404).json({ message: "Category not found" });
      res.json(category);
    } catch (err: any) {
      if (err.name === "ZodError") return res.status(400).json({ message: "Validation error", errors: err.errors });
      res.status(500).json({ message: err.message });
    }
  });

  app.delete("/api/property-expense-categories/:id", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admin can delete expense categories" });
      }
      const deleted = await storage.deletePropertyExpenseCategory(String(req.params.id));
      if (!deleted) return res.status(404).json({ message: "Category not found" });
      res.json({ message: "Category deleted" });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/assets/:assetId/acquisition", requireAuth, async (req, res) => {
    try {
      const acquisition = await storage.getPropertyAcquisition(String(req.params.assetId));
      if (!acquisition) return res.status(404).json({ message: "Acquisition data not found for this property" });
      res.json(acquisition);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/assets/:assetId/acquisition", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can create acquisition data" });
      }

      const asset = await storage.getAsset(String(req.params.assetId));
      if (!asset) return res.status(404).json({ message: "Asset not found" });

      const existing = await storage.getPropertyAcquisition(String(req.params.assetId));
      if (existing) return res.status(409).json({ message: "Acquisition data already exists. Use PATCH to update." });

      const parsed = createPropertyAcquisitionSchema.parse({ ...req.body, assetId: req.params.assetId });
      const computed = computeAcquisitionTotals(parsed, asset.totalSupply);

      const acquisition = await storage.createPropertyAcquisition({
        ...computed,
        createdBy: user.id,
      });
      res.status(201).json(acquisition);
    } catch (err: any) {
      if (err.name === "ZodError") return res.status(400).json({ message: "Validation error", errors: err.errors });
      res.status(500).json({ message: err.message });
    }
  });

  app.patch("/api/assets/:assetId/acquisition", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can update acquisition data" });
      }

      const asset = await storage.getAsset(String(req.params.assetId));
      if (!asset) return res.status(404).json({ message: "Asset not found" });

      const existing = await storage.getPropertyAcquisition(String(req.params.assetId));
      if (!existing) return res.status(404).json({ message: "Acquisition data not found. Use POST to create." });

      const existingUnit = await storage.getPropertyUnit(String(req.params.assetId));
      if (existingUnit) {
        return res.status(400).json({ message: "Cannot modify acquisition costs after units have been created. Unit pricing is derived from Total Capital Required." });
      }

      const parsed = updatePropertyAcquisitionSchema.parse(req.body);

      const merged = {
        assetId: String(req.params.assetId),
        currency: parsed.currency !== undefined ? parsed.currency : existing.currency,
        purchasePrice: parsed.purchasePrice !== undefined ? parsed.purchasePrice : existing.purchasePrice,
        stampDuty: parsed.stampDuty !== undefined ? parsed.stampDuty : existing.stampDuty,
        registrationFee: parsed.registrationFee !== undefined ? parsed.registrationFee : existing.registrationFee,
        legalCost: parsed.legalCost !== undefined ? parsed.legalCost : existing.legalCost,
        renovationCost: parsed.renovationCost !== undefined ? parsed.renovationCost : existing.renovationCost,
        furnitureCost: parsed.furnitureCost !== undefined ? parsed.furnitureCost : existing.furnitureCost,
        brokerage: parsed.brokerage !== undefined ? parsed.brokerage : existing.brokerage,
        contingencyPercent: parsed.contingencyPercent !== undefined ? parsed.contingencyPercent : existing.contingencyPercent,
        otherCosts: parsed.otherCosts !== undefined ? parsed.otherCosts : existing.otherCosts,
        otherCostsDescription: parsed.otherCostsDescription !== undefined ? parsed.otherCostsDescription : existing.otherCostsDescription,
        notes: parsed.notes !== undefined ? parsed.notes : existing.notes,
      };

      const computed = computeAcquisitionTotals(merged, asset.totalSupply);

      const updated = await storage.updatePropertyAcquisition(String(req.params.assetId), computed);
      if (!updated) return res.status(500).json({ message: "Failed to update acquisition data" });
      res.json(updated);
    } catch (err: any) {
      if (err.name === "ZodError") return res.status(400).json({ message: "Validation error", errors: err.errors });
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/admin/property-acquisitions", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Admin only" });
      }
      const acquisitions = await storage.getAllPropertyAcquisitions(req.tenantId);
      res.json(acquisitions);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/assets/:assetId/units", requireAuth, async (req, res) => {
    try {
      const unit = await storage.getPropertyUnit(String(req.params.assetId));
      if (!unit) return res.status(404).json({ message: "No unit configuration for this property" });
      res.json(unit);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/assets/:assetId/units", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can create unit configuration" });
      }

      const assetId = String(req.params.assetId);
      const asset = await storage.getAsset(assetId);
      if (!asset) return res.status(404).json({ message: "Asset not found" });

      const existing = await storage.getPropertyUnit(assetId);
      if (existing) return res.status(409).json({ message: "Unit configuration already exists. Use PATCH to update." });

      const acquisition = await storage.getPropertyAcquisition(assetId);
      if (!acquisition) return res.status(400).json({ message: "Property acquisition data must be created first. Total Capital Required is needed to compute unit price." });

      const parsed = createPropertyUnitSchema.parse({ ...req.body, assetId });
      const totalUnits = parseFloat(parsed.totalUnits);
      if (totalUnits <= 0) return res.status(400).json({ message: "Total units must be greater than zero" });

      const totalCapital = parseFloat(acquisition.totalAcquisitionCost);
      const unitPrice = parseFloat((totalCapital / totalUnits).toFixed(6));

      const unit = await storage.createPropertyUnit({
        assetId,
        totalUnits: parsed.totalUnits,
        unitPrice: unitPrice.toString(),
        unitDecimals: parsed.unitDecimals,
        currency: acquisition.currency,
        totalCapitalRequired: acquisition.totalAcquisitionCost,
        unitsIssued: "0",
        status: "draft",
        createdBy: user.id,
      });

      await storage.createPropertyUnitLedgerEntry({
        propertyUnitId: unit.id,
        assetId,
        userId: null,
        direction: "CREDIT",
        units: parsed.totalUnits,
        unitPriceAtTime: unitPrice.toString(),
        totalValue: totalCapital.toString(),
        reason: "MINT",
        refId: unit.id,
        notes: `Initial minting of ${parsed.totalUnits} units for ${asset.name}`,
      });

      res.status(201).json(unit);
    } catch (err: any) {
      if (err.name === "ZodError") return res.status(400).json({ message: "Validation error", errors: err.errors });
      res.status(500).json({ message: err.message });
    }
  });

  app.patch("/api/assets/:assetId/units", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can update unit configuration" });
      }

      const assetId = String(req.params.assetId);
      const existing = await storage.getPropertyUnit(assetId);
      if (!existing) return res.status(404).json({ message: "No unit configuration found. Use POST to create." });

      if (parseFloat(existing.unitsIssued) > 0 && req.body.totalUnits) {
        return res.status(400).json({ message: "Cannot change total units after units have been issued to investors" });
      }

      const parsed = updatePropertyUnitSchema.parse(req.body);
      const updateData: any = {};

      if (parsed.totalUnits !== undefined) {
        const totalUnits = parseFloat(parsed.totalUnits);
        if (totalUnits <= 0) return res.status(400).json({ message: "Total units must be greater than zero" });
        updateData.totalUnits = parsed.totalUnits;
        const totalCapital = parseFloat(existing.totalCapitalRequired);
        updateData.unitPrice = (totalCapital / totalUnits).toFixed(6);
      }
      if (parsed.unitDecimals !== undefined) updateData.unitDecimals = parsed.unitDecimals;
      if (parsed.status !== undefined) updateData.status = parsed.status;

      const updated = await storage.updatePropertyUnit(assetId, updateData);
      if (!updated) return res.status(500).json({ message: "Failed to update" });
      res.json(updated);
    } catch (err: any) {
      if (err.name === "ZodError") return res.status(400).json({ message: "Validation error", errors: err.errors });
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/assets/:assetId/units/ledger", requireAuth, async (req, res) => {
    try {
      const ledger = await storage.getPropertyUnitLedger(String(req.params.assetId));
      res.json(ledger);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/admin/property-units", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Admin only" });
      }
      const units = await storage.getAllPropertyUnits(req.tenantId);
      res.json(units);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/properties/:assetId/developer-payments", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const payments = await storage.getDeveloperPaymentsByAsset(req.params.assetId);
      res.json(payments);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/properties/:assetId/developer-payments", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const data = createDevPaymentSchema.parse({ ...req.body, assetId: req.params.assetId });
      const payment = await storage.createDeveloperPayment(data as any);
      res.status(201).json(payment);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ message: "Validation error", errors: err.errors });
      }
      res.status(500).json({ message: err.message });
    }
  });

  app.patch("/api/developer-payments/:id", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const data = updateDevPaymentSchema.parse(req.body);
      const payment = await storage.updateDeveloperPayment(req.params.id, data as any);
      if (!payment) return res.status(404).json({ message: "Payment not found" });
      res.json(payment);
    } catch (err: any) {
      if (err.name === "ZodError") {
        return res.status(400).json({ message: "Validation error", errors: err.errors });
      }
      res.status(500).json({ message: err.message });
    }
  });

  app.delete("/api/developer-payments/:id", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }
      const deleted = await storage.deleteDeveloperPayment(req.params.id);
      if (!deleted) return res.status(404).json({ message: "Payment not found" });
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/admin/property-sales", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const sales = await storage.getAllPropertySaleEvents(req.tenantId);
      const enriched = await Promise.all(sales.map(async (sale) => {
        const asset = await storage.getAsset(sale.assetId);
        const payouts = await storage.getPropertySalePayouts(sale.id);
        return { ...sale, assetName: asset?.name || "Unknown", payoutCount: payouts.length };
      }));
      res.json(enriched);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/admin/property-sales/:id", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const sale = await storage.getPropertySaleEvent(req.params.id);
      if (!sale) return res.status(404).json({ message: "Sale event not found" });
      const asset = await storage.getAsset(sale.assetId);
      const payouts = await storage.getPropertySalePayouts(sale.id);
      const enrichedPayouts = await Promise.all(payouts.map(async (p) => {
        const user = await storage.getUser(p.userId);
        return { ...p, username: user?.username || "Unknown", fullName: `${user?.firstName || ""} ${user?.lastName || ""}`.trim() || user?.username || "Unknown" };
      }));
      res.json({ ...sale, assetName: asset?.name || "Unknown", payouts: enrichedPayouts });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/admin/property-sales/preview", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const parsed = createPropertySaleSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Validation failed", errors: parsed.error.errors });
      }
      const data = parsed.data;
      const preview = await previewPropertySale({
        assetId: data.assetId,
        saleAmount: parseFloat(data.saleAmount),
        agentCommission: parseFloat(data.agentCommission),
        legalFees: parseFloat(data.legalFees),
        transferTax: parseFloat(data.transferTax),
        otherCosts: parseFloat(data.otherCosts),
        otherCostsDescription: data.otherCostsDescription,
        notes: data.notes,
        createdBy: (req as any).user.userId,
      });
      res.json(preview);
    } catch (err: any) {
      res.status(400).json({ message: err.message });
    }
  });

  app.post("/api/admin/property-sales/execute", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const parsed = createPropertySaleSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Validation failed", errors: parsed.error.errors });
      }
      const data = parsed.data;
      const result = await executePropertySale({
        assetId: data.assetId,
        saleAmount: parseFloat(data.saleAmount),
        agentCommission: parseFloat(data.agentCommission),
        legalFees: parseFloat(data.legalFees),
        transferTax: parseFloat(data.transferTax),
        otherCosts: parseFloat(data.otherCosts),
        otherCostsDescription: data.otherCostsDescription,
        notes: data.notes,
        createdBy: (req as any).user.userId,
      });
      res.json(result);
    } catch (err: any) {
      res.status(400).json({ message: err.message });
    }
  });

  app.get("/api/investor/property-sales", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const payouts = await storage.getPropertySalePayoutsByUser(userId);
      const enriched = await Promise.all(payouts.map(async (p) => {
        const sale = await storage.getPropertySaleEvent(p.saleEventId);
        const asset = sale ? await storage.getAsset(sale.assetId) : null;
        return {
          ...p,
          saleEvent: sale || null,
          assetName: asset?.name || "Unknown",
          assetId: sale?.assetId || null,
        };
      }));
      res.json(enriched);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/investor/property-sales/:saleEventId", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const sale = await storage.getPropertySaleEvent(req.params.saleEventId);
      if (!sale) return res.status(404).json({ message: "Sale event not found" });
      const asset = await storage.getAsset(sale.assetId);
      const payouts = await storage.getPropertySalePayouts(sale.id);
      const myPayout = payouts.find(p => p.userId === userId);
      if (!myPayout) return res.status(404).json({ message: "No payout found for this sale" });
      res.json({
        saleEvent: { ...sale, assetName: asset?.name || "Unknown" },
        payout: myPayout,
      });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });
}

function computeAcquisitionTotals(data: any, totalSupply: string): any {
  const purchasePrice = parseFloat(data.purchasePrice || "0");
  const stampDuty = parseFloat(data.stampDuty || "0");
  const registrationFee = parseFloat(data.registrationFee || "0");
  const legalCost = parseFloat(data.legalCost || "0");
  const renovationCost = parseFloat(data.renovationCost || "0");
  const furnitureCost = parseFloat(data.furnitureCost || "0");
  const brokerage = parseFloat(data.brokerage || "0");
  const otherCosts = parseFloat(data.otherCosts || "0");
  const contingencyPercent = parseFloat(data.contingencyPercent || "5");

  const baseCost = purchasePrice + stampDuty + registrationFee + legalCost +
    renovationCost + furnitureCost + brokerage + otherCosts;
  const contingencyAmount = parseFloat((baseCost * contingencyPercent / 100).toFixed(2));
  const totalAcquisitionCost = parseFloat((baseCost + contingencyAmount).toFixed(2));

  const supply = parseFloat(totalSupply || "0");
  const costPerToken = supply > 0 ? (totalAcquisitionCost / supply).toFixed(6) : null;

  return {
    ...data,
    contingencyAmount: contingencyAmount.toString(),
    totalAcquisitionCost: totalAcquisitionCost.toString(),
    costPerToken,
    status: "draft",
  };
}
