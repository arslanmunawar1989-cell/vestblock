import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { SUPPORTED_COUNTRIES, COUNTRY_DETAILS, CURRENCY_TO_COUNTRY } from "@shared/constants";

export function registerMarketplaceRoutes(app: Express) {
  app.get("/api/marketplace/assets/:id", requireAuth, async (req, res) => {
    try {
      const asset = await storage.getAsset(req.params.id as string);
      if (!asset) {
        return res.status(404).json({ error: "Asset not found" });
      }
      if (req.tenantId && asset.tenantId && asset.tenantId !== req.tenantId) {
        return res.status(404).json({ error: "Asset not found" });
      }
      const rounds = await storage.getRoundsByAsset(asset.id);
      const assetDistributions = await storage.getDistributionsByAsset(asset.id);

      const openRound = rounds.find(r => r.status === "open");
      const totalRaised = rounds.reduce((sum, r) => sum + parseFloat(r.raisedAmount || "0"), 0);
      const totalTarget = rounds.reduce((sum, r) => sum + parseFloat(r.targetAmount || "0"), 0);
      const completedDistributions = assetDistributions.filter(d => d.status === "completed");
      const totalDistributed = completedDistributions.reduce((sum, d) => sum + parseFloat(d.amount || "0"), 0);
      const nextDistribution = assetDistributions.find(d => d.status === "scheduled");

      res.json({
        ...asset,
        rounds,
        distributions: assetDistributions,
        metrics: {
          totalRaised,
          totalTarget,
          raisePercentage: totalTarget > 0 ? Math.round((totalRaised / totalTarget) * 100) : 0,
          totalDistributed,
          distributionCount: completedDistributions.length,
          nextDistributionDate: nextDistribution?.distributionDate || null,
          nextDistributionAmount: nextDistribution?.amount || null,
          hasOpenRound: !!openRound,
          tokensAvailable: openRound ? parseFloat(openRound.targetAmount) - parseFloat(openRound.raisedAmount) : 0,
        },
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/marketplace/countries", requireAuth, async (_req, res) => {
    try {
      const settings = await storage.getVisibleMarketplaceCountries();
      const countries = settings.map(s => ({
        ...s,
        name: COUNTRY_DETAILS[s.countryCode as keyof typeof COUNTRY_DETAILS]?.name || s.countryCode,
      }));
      res.json(countries);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/marketplace/assets", requireAuth, async (req, res) => {
    try {
      const country = req.query.country as string | undefined;
      const allAssets = await storage.getAssets(req.tenantId);
      const visibleSettings = await storage.getVisibleMarketplaceCountries();
      const visibleCodes = new Set(visibleSettings.map(s => s.countryCode));

      let filtered = allAssets.filter(a => {
        const assetCountry = a.country || CURRENCY_TO_COUNTRY[a.baseCurrency as keyof typeof CURRENCY_TO_COUNTRY] || "AE";
        return visibleCodes.has(assetCountry);
      });

      if (country) {
        filtered = filtered.filter(a => {
          const assetCountry = a.country || CURRENCY_TO_COUNTRY[a.baseCurrency as keyof typeof CURRENCY_TO_COUNTRY] || "AE";
          return assetCountry === country;
        });
      }

      res.json(filtered);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/admin/marketplace/countries", requireAuth, requireRole("admin"), async (_req, res) => {
    try {
      const settings = await storage.getMarketplaceCountrySettings();
      const settingsMap = new Map(settings.map(s => [s.countryCode, s]));

      const allCountries = SUPPORTED_COUNTRIES.map((code, idx) => {
        const existing = settingsMap.get(code);
        return {
          countryCode: code,
          name: COUNTRY_DETAILS[code]?.name || code,
          isVisible: existing?.isVisible ?? true,
          displayOrder: existing?.displayOrder ?? idx,
          id: existing?.id || null,
        };
      });

      allCountries.sort((a, b) => a.displayOrder - b.displayOrder);
      res.json(allCountries);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.patch("/api/admin/marketplace/countries/:countryCode", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const { countryCode } = req.params;
      const { isVisible, displayOrder } = req.body;

      if (typeof isVisible !== "boolean") {
        return res.status(400).json({ error: "isVisible must be a boolean" });
      }

      const setting = await storage.upsertMarketplaceCountrySetting(
        countryCode as string,
        isVisible,
        typeof displayOrder === "number" ? displayOrder : undefined
      );

      res.json(setting);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });
}
