import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { logAuditFromReq } from "../lib/audit-logger";
import { requestWithdrawalSchema } from "@shared/schema";
import { applyFee } from "../services/fee-engine.service";
import { walletService, LEDGER_ENTRY_TYPES, SUPPORTED_CURRENCIES } from "../services/wallet.service";
import { NotificationTemplates } from "../services/notification-templates";
import { z } from "zod";
import { paymentLimiter } from "../middleware/rate-limit";

const depositIntentSchema = z.object({
  currency: z.string().min(1),
  amount: z.number().positive(),
  description: z.string().optional(),
  referenceId: z.string().optional(),
});

const confirmDepositSchema = z.object({
  ledgerTxId: z.string().min(1),
  confirmedAmount: z.number().positive().optional(),
});

const directDepositSchema = z.object({
  userId: z.string().min(1),
  currency: z.string().min(1),
  amount: z.number().positive(),
  description: z.string().optional(),
  referenceId: z.string().optional(),
});

const reserveSchema = z.object({
  currency: z.string().min(1),
  amount: z.number().positive(),
  referenceId: z.string().min(1),
  description: z.string().optional(),
});

const captureSchema = z.object({
  reserveLedgerTxId: z.string().min(1),
  captureAmount: z.number().positive().optional(),
  description: z.string().optional(),
});

const releaseReserveSchema = z.object({
  reserveLedgerTxId: z.string().min(1),
  reason: z.string().optional(),
});

const fxConvertSchema = z.object({
  fromCurrency: z.string().min(1),
  toCurrency: z.string().min(1),
  fromAmount: z.number().positive(),
  rate: z.number().positive(),
  referenceId: z.string().optional(),
});

const withdrawalActionSchema = z.object({
  action: z.enum(["approve", "decline"]),
  notes: z.string().optional(),
});

const markPaidSchema = z.object({
  payoutReference: z.string().min(1, "Payout reference is required"),
});

export function registerWalletRoutes(app: Express) {

  app.get("/api/wallet/balances", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const balances = await walletService.getBalances(userId);
      res.json(balances);
    } catch (err: any) {
      console.error("Wallet balances error:", err);
      res.status(500).json({ message: "Failed to fetch balances" });
    }
  });

  app.get("/api/wallet/accounts", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const accounts = await storage.getWalletAccountsByUser(userId);
      const balances = await walletService.getBalances(userId);
      const balanceMap = new Map(balances.map(b => [b.walletAccountId, b]));

      const accountsWithBalance = accounts.map(acc => {
        const bal = balanceMap.get(acc.id);
        return {
          ...acc,
          available: bal?.available || "0.000000",
          reserved: bal?.reserved || "0.000000",
          pending: bal?.pending || "0.000000",
          total: bal?.total || "0.000000",
        };
      });
      res.json(accountsWithBalance);
    } catch (err: any) {
      console.error("Wallet accounts error:", err);
      res.status(500).json({ message: "Failed to fetch wallet accounts" });
    }
  });

  app.get("/api/wallet/currencies", requireAuth, async (_req, res) => {
    res.json(SUPPORTED_CURRENCIES);
  });

  app.post("/api/wallet/deposit-intent", requireAuth, paymentLimiter, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const data = depositIntentSchema.parse(req.body);

      const result = await walletService.depositIntent({
        userId,
        currency: data.currency,
        amount: data.amount,
        description: data.description,
        referenceId: data.referenceId,
      });

      await logAuditFromReq(req, "DEPOSIT_INTENT", "wallet_account", result.walletAccountId, {
        reason: `Deposit intent: ${data.amount} ${data.currency}. LedgerTx: ${result.ledgerTxId}`,
        metadata: { amount: data.amount, currency: data.currency, ledgerTxId: result.ledgerTxId },
      });

      res.status(201).json(result);
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Deposit intent error:", err);
      res.status(400).json({ message: err.message || "Failed to create deposit intent" });
    }
  });

  app.post("/api/wallet/deposit-confirm", requireAuth, paymentLimiter, async (req, res) => {
    try {
      const data = confirmDepositSchema.parse(req.body);
      const result = await walletService.confirmDeposit({
        ledgerTxId: data.ledgerTxId,
        confirmedAmount: data.confirmedAmount,
      });

      await logAuditFromReq(req, "DEPOSIT_CONFIRMED", "wallet_account", result.walletAccountId, {
        reason: `Deposit confirmed: ${result.amount} ${result.currency}. LedgerTx: ${result.ledgerTxId}`,
        metadata: { amount: result.amount, currency: result.currency, ledgerTxId: result.ledgerTxId },
      });

      res.json(result);
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Deposit confirm error:", err);
      res.status(400).json({ message: err.message || "Failed to confirm deposit" });
    }
  });

  app.post("/api/admin/ledger/deposit", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const data = directDepositSchema.parse(req.body);
      const adminId = (req as any).user.userId;

      const result = await walletService.directDeposit({
        userId: data.userId,
        currency: data.currency,
        amount: data.amount,
        description: data.description || "Admin deposit",
        referenceId: data.referenceId,
        metadata: { adminId },
      });

      await logAuditFromReq(req, "ADMIN_DEPOSIT", "wallet_account", result.walletAccountId, {
        reason: `Admin ${adminId} deposited ${data.amount} ${data.currency} to user ${data.userId}. LedgerTx: ${result.ledgerTxId}`,
        metadata: { amount: data.amount, currency: data.currency, targetUserId: data.userId, ledgerTxId: result.ledgerTxId },
      });

      const balance = await walletService.getBalanceForWallet(result.walletAccountId);
      res.status(201).json({ ...result, balance });
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Admin deposit error:", err);
      res.status(400).json({ message: err.message || "Failed to process deposit" });
    }
  });

  app.post("/api/wallet/reserve", requireAuth, paymentLimiter, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const data = reserveSchema.parse(req.body);

      const result = await walletService.reserveFunds({
        userId,
        currency: data.currency,
        amount: data.amount,
        referenceId: data.referenceId,
        description: data.description,
      });

      await logAuditFromReq(req, "FUNDS_RESERVED", "wallet_account", result.walletAccountId, {
        reason: `Reserved ${data.amount} ${data.currency} for ${data.referenceId}. LedgerTx: ${result.reserveLedgerTxId}`,
        metadata: { amount: data.amount, currency: data.currency, referenceId: data.referenceId },
      });

      res.status(201).json(result);
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Reserve funds error:", err);
      res.status(400).json({ message: err.message || "Failed to reserve funds" });
    }
  });

  app.post("/api/wallet/release-reserve", requireAuth, paymentLimiter, async (req, res) => {
    try {
      const data = releaseReserveSchema.parse(req.body);
      await walletService.releaseReserve({
        reserveLedgerTxId: data.reserveLedgerTxId,
        reason: data.reason,
      });

      await logAuditFromReq(req, "RESERVE_RELEASED", "ledger_entry", data.reserveLedgerTxId, {
        reason: data.reason || "Reserve released",
      });

      res.json({ message: "Reserve released" });
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Release reserve error:", err);
      res.status(400).json({ message: err.message || "Failed to release reserve" });
    }
  });

  app.post("/api/wallet/capture", requireAuth, paymentLimiter, async (req, res) => {
    try {
      const data = captureSchema.parse(req.body);
      const result = await walletService.captureFunds({
        reserveLedgerTxId: data.reserveLedgerTxId,
        captureAmount: data.captureAmount,
        description: data.description,
      });

      await logAuditFromReq(req, "FUNDS_CAPTURED", "wallet_account", result.walletAccountId, {
        reason: `Captured ${result.amount} ${result.currency} from reserve ${data.reserveLedgerTxId}. LedgerTx: ${result.captureLedgerTxId}`,
        metadata: { amount: result.amount, currency: result.currency, referenceId: result.referenceId },
      });

      res.json(result);
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Capture funds error:", err);
      res.status(400).json({ message: err.message || "Failed to capture funds" });
    }
  });

  app.post("/api/wallet/fx-convert", requireAuth, paymentLimiter, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const data = fxConvertSchema.parse(req.body);

      const result = await walletService.fxConvert({
        userId,
        fromCurrency: data.fromCurrency,
        toCurrency: data.toCurrency,
        fromAmount: data.fromAmount,
        rate: data.rate,
        referenceId: data.referenceId,
      });

      await logAuditFromReq(req, "FX_CONVERT", "wallet_account", result.debitWalletId, {
        reason: `FX: ${result.fromAmount} ${result.fromCurrency} -> ${result.toAmount} ${result.toCurrency} @ ${result.rate}`,
        metadata: result,
      });

      res.json(result);
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("FX convert error:", err);
      res.status(400).json({ message: err.message || "Failed to convert currency" });
    }
  });

  app.get("/api/wallet/withdrawal-availability", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const currency = (req.query.currency as string) || "AED";
      const availability = await walletService.getWithdrawalAvailability(userId, currency);
      res.json(availability);
    } catch (err: any) {
      console.error("Withdrawal availability error:", err);
      res.status(500).json({ message: "Failed to fetch withdrawal availability" });
    }
  });

  app.post("/api/withdrawals", requireAuth, paymentLimiter, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const data = requestWithdrawalSchema.parse(req.body);

      const user = await storage.getUser(userId);
      if (!user) return res.status(404).json({ message: "User not found" });

      const kycProfile = await storage.getKycProfile(userId);
      if (!kycProfile || kycProfile.status !== "APPROVED") {
        return res.status(400).json({ message: "KYC must be approved before requesting withdrawals" });
      }

      const bankAccount = await storage.getBankAccountById(data.bankAccountId);
      if (!bankAccount || bankAccount.userId !== userId) {
        return res.status(400).json({ message: "Invalid bank account" });
      }
      if (bankAccount.status !== "verified") {
        return res.status(400).json({ message: "Bank account must be verified before withdrawals" });
      }
      if (bankAccount.currency !== data.currency) {
        return res.status(400).json({ message: "Bank account currency does not match withdrawal currency" });
      }

      const availability = await walletService.getWithdrawalAvailability(userId, data.currency);
      if (data.reason === "PROFIT") {
        const profitAvail = parseFloat(availability.profit.available);
        if (data.amount > profitAvail) {
          return res.status(400).json({
            message: `Insufficient unlocked profit balance. Available: ${profitAvail.toFixed(2)} ${data.currency}. Distribution profits are locked for ${availability.rules.profitLockDays} days after payout.`,
            code: "PROFIT_LOCKED",
            available: profitAvail,
            lockDays: availability.rules.profitLockDays,
            nextUnlockDate: availability.profit.nextUnlockDate,
          });
        }
      } else if (data.reason === "CAPITAL") {
        const capitalAvail = parseFloat(availability.capital.available);
        if (data.amount > capitalAvail) {
          return res.status(400).json({
            message: `Insufficient unlocked capital balance. Available: ${capitalAvail.toFixed(2)} ${data.currency}. Invested capital is locked for ${availability.rules.capitalLockDays} days after capture.`,
            code: "CAPITAL_LOCKED",
            available: capitalAvail,
            lockDays: availability.rules.capitalLockDays,
            nextUnlockDate: availability.capital.nextUnlockDate,
          });
        }
      }

      const { calculation: feeCalc } = await applyFee({
        feeType: "withdrawal",
        amount: data.amount,
        currency: data.currency,
        userId,
        referenceEntityType: "withdrawal_request",
        description: "Withdrawal fee",
      });
      const fee = feeCalc.fee;
      const netAmount = feeCalc.netAmount;

      const withdrawal = await storage.createWithdrawalRequest({
        userId,
        walletAccountId: (await storage.getOrCreateWallet(userId, data.currency)).id,
        bankAccountId: data.bankAccountId,
        amount: data.amount.toFixed(2),
        currency: data.currency,
        reason: data.reason,
        fee: fee.toFixed(2),
        netAmount: netAmount.toFixed(2),
      });

      const ledgerResult = await walletService.requestWithdrawal({
        userId,
        currency: data.currency,
        amount: data.amount,
        referenceId: withdrawal.id,
        description: `${data.reason} withdrawal to ${bankAccount.bankName} (${bankAccount.label})`,
        metadata: { withdrawalId: withdrawal.id, bankAccountId: bankAccount.id, reason: data.reason },
      });

      const wdNotif = NotificationTemplates.withdrawal.requested(data.amount, data.currency, bankAccount.bankName, bankAccount.label);
      await storage.createNotification({ userId, ...wdNotif, relatedEntityId: withdrawal.id, relatedEntityType: "withdrawal_request" });

      await logAuditFromReq(req, "WITHDRAWAL_REQUESTED", "withdrawal_request", withdrawal.id, {
        reason: `${data.reason} withdrawal of ${data.amount} ${data.currency} requested. Fee: ${fee}, Net: ${netAmount}. LedgerTx: ${ledgerResult.ledgerTxId}`,
        metadata: { amount: data.amount, currency: data.currency, fee, netAmount, ledgerTxId: ledgerResult.ledgerTxId, withdrawalReason: data.reason },
      });

      res.status(201).json({ ...withdrawal, ledgerTxId: ledgerResult.ledgerTxId });
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Withdrawal request error:", err);
      res.status(400).json({ message: err.message || "Failed to create withdrawal request" });
    }
  });

  app.get("/api/withdrawals", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const withdrawals = await storage.getWithdrawalRequestsByUser(userId);
      const enriched = await Promise.all(withdrawals.map(async (w) => {
        const bankAccount = await storage.getBankAccountById(w.bankAccountId);
        return { ...w, bankAccount: bankAccount ? { id: bankAccount.id, label: bankAccount.label, bankName: bankAccount.bankName, currency: bankAccount.currency } : null };
      }));
      res.json(enriched);
    } catch (err: any) {
      console.error("Withdrawals fetch error:", err);
      res.status(500).json({ message: "Failed to fetch withdrawals" });
    }
  });

  app.get("/api/admin/withdrawals", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const withdrawals = await storage.getAllWithdrawalRequests(req.tenantId);
      const enriched = await Promise.all(withdrawals.map(async (w) => {
        const user = await storage.getUser(w.userId);
        const bankAccount = await storage.getBankAccountById(w.bankAccountId);
        return {
          ...w,
          user: user ? { id: user.id, username: user.username, email: user.email, fullName: user.fullName } : null,
          bankAccount: bankAccount ? { id: bankAccount.id, label: bankAccount.label, bankName: bankAccount.bankName, iban: bankAccount.iban, accountNumber: bankAccount.accountNumber, currency: bankAccount.currency, country: bankAccount.country } : null,
        };
      }));
      res.json(enriched);
    } catch (err: any) {
      console.error("Admin withdrawals error:", err);
      res.status(500).json({ message: "Failed to fetch withdrawals" });
    }
  });

  app.post("/api/admin/withdrawals/:id/review", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const adminId = (req as any).user.userId;
      const withdrawal = await storage.getWithdrawalRequestById(String(req.params.id));
      if (!withdrawal) return res.status(404).json({ message: "Withdrawal request not found" });
      if (withdrawal.status !== "REQUESTED") {
        return res.status(400).json({ message: `Cannot review a withdrawal with status: ${withdrawal.status}` });
      }

      const { action, notes } = withdrawalActionSchema.parse(req.body);
      const newStatus = action === "approve" ? "APPROVED" : "DECLINED";
      const updated = await storage.updateWithdrawalRequestStatus(withdrawal.id, newStatus, adminId, notes);

      const withdrawalLedgerEntries = await storage.getLedgerEntriesByAccount(withdrawal.walletAccountId);
      const holdEntry = withdrawalLedgerEntries.find(
        e => e.referenceId === withdrawal.id && e.entryType === LEDGER_ENTRY_TYPES.WITHDRAW_REQUESTED && e.status === "PENDING"
      );

      if (action === "approve" && holdEntry) {
        await walletService.approveWithdrawal({
          originalLedgerTxId: holdEntry.ledgerTxId,
          fee: parseFloat(withdrawal.fee),
          metadata: { adminId, withdrawalId: withdrawal.id },
        });

        const approveNotif = NotificationTemplates.withdrawal.approved(withdrawal.amount, withdrawal.currency, withdrawal.netAmount);
        await storage.createNotification({ userId: withdrawal.userId, ...approveNotif, relatedEntityId: withdrawal.id, relatedEntityType: "withdrawal_request" });
      } else if (action === "decline" && holdEntry) {
        await walletService.rejectWithdrawal({
          originalLedgerTxId: holdEntry.ledgerTxId,
          reason: notes || "Withdrawal declined by admin",
        });

        const declineNotif = NotificationTemplates.withdrawal.declined(withdrawal.amount, withdrawal.currency, notes);
        await storage.createNotification({ userId: withdrawal.userId, ...declineNotif, relatedEntityId: withdrawal.id, relatedEntityType: "withdrawal_request" });
      }

      await logAuditFromReq(req, `WITHDRAWAL_${action.toUpperCase()}D`, "withdrawal_request", withdrawal.id, {
        reason: `Withdrawal ${action}d by admin ${adminId}${notes ? `: ${notes}` : ""}`,
        beforeState: { status: withdrawal.status },
        afterState: { status: newStatus },
      });

      res.json(updated);
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Withdrawal review error:", err);
      res.status(500).json({ message: "Failed to review withdrawal" });
    }
  });

  app.post("/api/admin/withdrawals/:id/paid", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const adminId = (req as any).user.userId;
      const withdrawal = await storage.getWithdrawalRequestById(String(req.params.id));
      if (!withdrawal) return res.status(404).json({ message: "Withdrawal request not found" });
      if (withdrawal.status !== "APPROVED") {
        return res.status(400).json({ message: `Can only mark APPROVED withdrawals as paid. Current: ${withdrawal.status}` });
      }

      const { payoutReference } = markPaidSchema.parse(req.body);
      const updated = await storage.markWithdrawalPaid(withdrawal.id, adminId, payoutReference);

      const paidNotif = NotificationTemplates.withdrawal.paid(withdrawal.netAmount, withdrawal.currency, payoutReference);
      await storage.createNotification({ userId: withdrawal.userId, ...paidNotif, relatedEntityId: withdrawal.id, relatedEntityType: "withdrawal_request" });

      await logAuditFromReq(req, "WITHDRAWAL_PAID", "withdrawal_request", withdrawal.id, {
        reason: `Payout reference: ${payoutReference}`,
        beforeState: { status: withdrawal.status },
        afterState: { status: "PAID" },
      });

      res.json(updated);
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Withdrawal paid error:", err);
      res.status(500).json({ message: "Failed to mark withdrawal as paid" });
    }
  });

  app.get("/api/wallet/transactions", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const txs = await storage.getWalletTransactionsByUser(userId);
      res.json(txs);
    } catch (err: any) {
      console.error("Wallet transactions error:", err);
      res.status(500).json({ message: "Failed to fetch wallet transactions" });
    }
  });

  app.get("/api/wallet/transactions/:id", requireAuth, async (req, res) => {
    try {
      const tx = await storage.getWalletTransactionById(String(req.params.id));
      if (!tx) return res.status(404).json({ message: "Transaction not found" });
      const account = await storage.getWalletAccount(tx.walletAccountId);
      if (!account) return res.status(404).json({ message: "Account not found" });
      const userId = (req as any).user.userId;
      if (account.userId !== userId) return res.status(403).json({ message: "Forbidden" });
      res.json({ ...tx, walletAccount: account });
    } catch (err: any) {
      console.error("Wallet transaction detail error:", err);
      res.status(500).json({ message: "Failed to fetch transaction" });
    }
  });

  app.get("/api/wallet/export", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const txs = await storage.getWalletTransactionsByUser(userId);
      const header = "Date,Type,Amount,Currency,Status,Description,Reference ID\n";
      const rows = txs.map(tx => {
        const date = new Date(tx.createdAt).toISOString().split("T")[0];
        const desc = (tx.description || "").replace(/,/g, ";").replace(/"/g, '""');
        return `${date},${tx.type},${tx.amount},${tx.currency},${tx.status},"${desc}",${tx.referenceId || ""}`;
      }).join("\n");
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", "attachment; filename=wallet_transactions.csv");
      res.send(header + rows);
    } catch (err: any) {
      console.error("Wallet export error:", err);
      res.status(500).json({ message: "Failed to export transactions" });
    }
  });

  app.get("/api/wallet/ledger", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const { entryType } = req.query;
      const entries = await walletService.getLedgerHistory({
        userId,
        entryType: entryType as string | undefined,
      });
      res.json(entries);
    } catch (err: any) {
      console.error("Ledger entries error:", err);
      res.status(500).json({ message: "Failed to fetch ledger entries" });
    }
  });

  app.get("/api/wallet/ledger/balance", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const balances = await walletService.getBalances(userId);
      res.json(balances);
    } catch (err: any) {
      console.error("Ledger balance error:", err);
      res.status(500).json({ message: "Failed to fetch ledger balances" });
    }
  });

  app.get("/api/wallet/ledger/:walletAccountId", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const account = await storage.getWalletAccount(String(req.params.walletAccountId));
      if (!account) return res.status(404).json({ message: "Wallet account not found" });
      if (account.userId !== userId) return res.status(403).json({ message: "Forbidden" });
      const entries = await storage.getLedgerEntriesByAccount(account.id);
      const balance = await walletService.getBalanceForWallet(account.id);
      res.json({ entries, balance });
    } catch (err: any) {
      console.error("Ledger account entries error:", err);
      res.status(500).json({ message: "Failed to fetch ledger entries" });
    }
  });

  app.get("/api/wallet/entry-types", requireAuth, async (_req, res) => {
    res.json(LEDGER_ENTRY_TYPES);
  });

  app.get("/api/admin/ledger/entries", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const { walletAccountId, userId, entryType } = req.query;
      if (walletAccountId) {
        const entries = await walletService.getLedgerHistory({
          walletAccountId: walletAccountId as string,
          entryType: entryType as string | undefined,
        });
        return res.json(entries);
      }
      if (userId) {
        const entries = await walletService.getLedgerHistory({
          userId: userId as string,
          entryType: entryType as string | undefined,
        });
        return res.json(entries);
      }
      res.status(400).json({ message: "Provide walletAccountId or userId query param" });
    } catch (err: any) {
      console.error("Admin ledger entries error:", err);
      res.status(500).json({ message: "Failed to fetch ledger entries" });
    }
  });

  app.post("/api/admin/ledger/reverse/:ledgerTxId", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const adminId = (req as any).user.userId;
      const ledgerTxId = String(req.params.ledgerTxId);
      const { reason } = z.object({ reason: z.string().min(1) }).parse(req.body);

      const reversals = await storage.reverseLedgerEntries(ledgerTxId, reason);
      if (reversals.length === 0) {
        return res.status(404).json({ message: "No active entries found for this ledger transaction" });
      }

      await logAuditFromReq(req, "LEDGER_REVERSAL", "ledger_entry", ledgerTxId, {
        reason: `Admin ${adminId} reversed ledger tx ${ledgerTxId}: ${reason}`,
        metadata: { reversedCount: reversals.length },
      });

      res.json({ message: "Reversed", reversals });
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Ledger reversal error:", err);
      res.status(500).json({ message: "Failed to reverse entries" });
    }
  });

  app.post("/api/admin/distribution-credit", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const schema = z.object({
        userId: z.string().min(1),
        currency: z.string().min(1),
        amount: z.number().positive(),
        referenceId: z.string().min(1),
        description: z.string().optional(),
      });
      const data = schema.parse(req.body);
      const adminId = (req as any).user.userId;

      const result = await walletService.distributionCredit({
        userId: data.userId,
        currency: data.currency,
        amount: data.amount,
        referenceId: data.referenceId,
        description: data.description,
        metadata: { adminId },
      });

      await logAuditFromReq(req, "DISTRIBUTION_CREDIT", "wallet_account", result.walletAccountId, {
        reason: `Distribution credit: ${data.amount} ${data.currency} to user ${data.userId}. Ref: ${data.referenceId}`,
        metadata: { ...data, ledgerTxId: result.ledgerTxId },
      });

      const balance = await walletService.getBalanceForWallet(result.walletAccountId);
      res.status(201).json({ ...result, balance });
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Distribution credit error:", err);
      res.status(400).json({ message: err.message || "Failed to credit distribution" });
    }
  });
}
