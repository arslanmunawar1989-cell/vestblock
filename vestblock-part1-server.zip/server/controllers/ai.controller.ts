import type { Express, Request, Response } from "express";
import { requireAuth, requireRole } from "../auth";
import { openAIProvider } from "../lib/ai/providers/OpenAIProvider";
import { buildSystemPrompt, sanitizeResponse } from "../lib/ai/guards/PolicyGuard";
import { buildAdtSystemPrompt, sanitizeAdtResponse } from "../lib/ai/guards/AdtPolicyGuard";
import { logAiInteraction } from "../lib/ai/audit/AuditLogger";
import { retrieveChunks } from "../lib/ai/rag/retrieve";
import { ingestAllForRegion, ingestSource } from "../lib/ai/rag/ingest";
import { db } from "../db";
import { contentSources, adtDocuments, docSummaries, investorPreferenceProfiles, createPreferenceProfileSchema, marketPulseMetricSnapshots, marketPulseReports } from "@shared/schema";
import { eq, desc, and } from "drizzle-orm";
import { scoreProperties, buildExplainPrompt } from "../services/property-match";
import type { PropertyData } from "../services/property-match";
import featuredProperties from "../../client/src/data/featured-properties.json";
import { seedPkContent } from "../lib/ai/rag/seed-pk";
import multer from "multer";
import * as pdfParseModule from "pdf-parse";
const pdfParse = (pdfParseModule as any).default || pdfParseModule;

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

function requireAdtWrite(req: Request, res: Response, next: Function) {
  const user = (req as any).user;
  if (!user) return res.status(401).json({ message: "Authentication required" });
  if (["admin", "issuer", "agent"].includes(user.role) || user.platformRole === "SUPER_ADMIN") return next();
  return res.status(403).json({ message: "Managers only: insufficient permissions to upload or analyze documents" });
}

function requireAdtRead(req: Request, res: Response, next: Function) {
  const user = (req as any).user;
  if (!user) return res.status(401).json({ message: "Authentication required" });
  return next();
}

export function registerAiRoutes(app: Express): void {
  app.get("/api/ai/health", async (_req: Request, res: Response) => {
    try {
      const result = await openAIProvider.chat([
        { role: "user", content: "Reply with exactly: OK" },
      ], { maxTokens: 16 });
      res.json({
        status: "healthy",
        provider: "openai",
        model: process.env.AI_MODEL_CHAT || "gpt-5-mini",
        response: result.content.trim(),
      });
    } catch (err: any) {
      res.status(503).json({
        status: "unhealthy",
        error: err.message,
      });
    }
  });

  app.post("/api/ai/rag/seed", requireAuth, requireRole("admin"), async (_req: Request, res: Response) => {
    try {
      const result = await seedPkContent();
      res.json({ ok: true, ...result });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/ai/rag/ingest", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const { region = "PK", sourceId } = req.body;
      if (sourceId) {
        const result = await ingestSource(sourceId);
        return res.json({ ok: true, ...result });
      }
      const result = await ingestAllForRegion(region);
      res.json({ ok: true, ...result });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post("/api/ai/rag/query", async (req: Request, res: Response) => {
    try {
      const { query, region = "PK" } = req.body;
      if (!query || typeof query !== "string" || query.trim().length < 2) {
        return res.status(400).json({ error: "Query is required (min 2 characters)" });
      }

      const chunks = await retrieveChunks(query.trim(), 8, region);

      if (chunks.length === 0) {
        const fallback = "I don't have enough information in my sources to answer that question. Please try rephrasing or ask about VestBlock's services, tokenization, fees, or investment process.";
        const userId = (req as any).user?.userId ?? null;
        await logAiInteraction({
          userId,
          feature: "ASK_RAG",
          prompt: query,
          response: fallback,
          sourcesJson: [],
          tokensEstimated: 0,
        });
        return res.json({
          answer: fallback,
          citations: [],
        });
      }

      const contextTexts = chunks.map((c) => c.chunkText);
      const systemPrompt = buildSystemPrompt(contextTexts);

      const result = await openAIProvider.chat([
        { role: "system", content: systemPrompt },
        { role: "user", content: query.trim() },
      ]);

      const safeAnswer = sanitizeResponse(result.content);

      const uniqueSources = new Map<string, { title: string; slug: string; type: string }>();
      for (const c of chunks) {
        if (!uniqueSources.has(c.sourceId)) {
          uniqueSources.set(c.sourceId, {
            title: c.sourceTitle,
            slug: c.sourceSlug,
            type: c.sourceType,
          });
        }
      }
      const citations = Array.from(uniqueSources.values());

      const userId = (req as any).user?.userId ?? null;
      await logAiInteraction({
        userId,
        feature: "ASK_RAG",
        prompt: query,
        response: safeAnswer,
        sourcesJson: citations,
        tokensEstimated: result.tokensEstimated,
      });

      res.json({
        answer: safeAnswer,
        citations,
      });
    } catch (err: any) {
      console.error("[AI RAG Query] Error:", err);
      res.status(500).json({ error: "Failed to process query" });
    }
  });

  app.post("/api/ai/adt/upload", requireAuth, requireAdtWrite, upload.single("file"), async (req: Request, res: Response) => {
    try {
      const { filename, extractedText, fileUrl, region = "PK", propertyId } = req.body;
      let text = extractedText || "";
      let docFilename = filename || "";

      if (req.file) {
        docFilename = docFilename || req.file.originalname;
        const mime = req.file.mimetype;
        if (mime === "application/pdf") {
          try {
            const pdfData = await pdfParse(req.file.buffer);
            text = pdfData.text || "";
          } catch (pdfErr: any) {
            return res.status(400).json({ error: "Failed to parse PDF: " + pdfErr.message });
          }
        } else if (mime === "text/plain" || mime === "text/csv" || mime.startsWith("text/")) {
          text = req.file.buffer.toString("utf-8");
        } else {
          return res.status(400).json({ error: "Unsupported file type. Upload PDF or text files." });
        }
      }

      if (!docFilename || typeof docFilename !== "string") {
        return res.status(400).json({ error: "filename is required" });
      }
      if (!text || typeof text !== "string" || text.trim().length < 50) {
        return res.status(400).json({ error: "Document text is required (min 50 characters). Upload a file or paste text." });
      }
      const userId = (req as any).user?.userId ?? null;
      const [doc] = await db.insert(adtDocuments).values({
        region,
        propertyId: propertyId || null,
        filename: docFilename.trim(),
        fileUrl: fileUrl || null,
        extractedText: text.trim(),
        uploadedByUserId: userId,
      }).returning();
      res.json({ ok: true, document: doc });
    } catch (err: any) {
      console.error("[ADT Upload] Error:", err);
      res.status(500).json({ error: "Failed to upload document" });
    }
  });

  app.post("/api/ai/adt/summarize", requireAuth, requireAdtWrite, async (req: Request, res: Response) => {
    try {
      const { documentId } = req.body;
      if (!documentId) {
        return res.status(400).json({ error: "documentId is required" });
      }
      const docs = await db.select().from(adtDocuments).where(eq(adtDocuments.id, documentId)).limit(1);
      if (docs.length === 0) {
        return res.status(404).json({ error: "Document not found" });
      }
      const doc = docs[0];
      const text = doc.extractedText;

      const systemPrompt = buildAdtSystemPrompt();
      const result = await openAIProvider.chat([
        { role: "system", content: systemPrompt },
        { role: "user", content: `Analyze the following document and provide a structured summary:\n\n---\n${text.substring(0, 12000)}\n---` },
      ], { maxTokens: 4096 });

      let parsed: any;
      try {
        const jsonMatch = result.content.match(/```(?:json)?\s*([\s\S]*?)```/);
        const jsonStr = jsonMatch ? jsonMatch[1] : result.content;
        parsed = JSON.parse(jsonStr.trim());
      } catch {
        parsed = {
          executiveSummary: [result.content.substring(0, 500)],
          keyNumbers: [],
          risks: [],
          missingInfo: [],
          investorQuestions: [],
          plainEnglishExplanation: result.content.substring(0, 1000),
        };
      }

      const safeContent = sanitizeAdtResponse(JSON.stringify(parsed));
      const safeParsed = JSON.parse(safeContent);

      const [summary] = await db.insert(docSummaries).values({
        documentId,
        summaryJson: safeParsed,
        riskFlagsJson: safeParsed.risks || [],
        questionsJson: safeParsed.investorQuestions || [],
      }).returning();

      const userId = (req as any).user?.userId ?? null;
      await logAiInteraction({
        userId,
        feature: "ADT_SUMMARY",
        prompt: `Summarize: ${doc.filename}`,
        response: JSON.stringify(safeParsed).substring(0, 2000),
        tokensEstimated: result.tokensEstimated,
      });

      res.json({ ok: true, summary });
    } catch (err: any) {
      console.error("[ADT Summarize] Error:", err);
      res.status(500).json({ error: "Failed to summarize document" });
    }
  });

  app.get("/api/ai/adt/documents", requireAuth, requireAdtRead, async (req: Request, res: Response) => {
    try {
      const documents = await db.select().from(adtDocuments).orderBy(desc(adtDocuments.createdAt)).limit(50);
      res.json(documents);
    } catch (err: any) {
      res.status(500).json({ error: "Failed to fetch documents" });
    }
  });

  app.get("/api/ai/adt/documents/:id", requireAuth, requireAdtRead, async (req: Request, res: Response) => {
    try {
      const docs = await db.select().from(adtDocuments).where(eq(adtDocuments.id, req.params.id)).limit(1);
      if (docs.length === 0) return res.status(404).json({ error: "Not found" });
      const summaries = await db.select().from(docSummaries).where(eq(docSummaries.documentId, req.params.id)).orderBy(desc(docSummaries.createdAt));
      res.json({ document: docs[0], summaries });
    } catch (err: any) {
      res.status(500).json({ error: "Failed to fetch document" });
    }
  });

  app.post("/api/ai/recommender/match", async (req: Request, res: Response) => {
    try {
      const parsed = createPreferenceProfileSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid preferences", details: parsed.error.flatten() });
      }

      const preferences = parsed.data;
      const properties = featuredProperties as PropertyData[];
      const matches = scoreProperties(properties, preferences);

      const prompt = buildExplainPrompt(matches, preferences);
      let explanation = { whyTheseMatches: "", tradeoffs: "" };

      try {
        const systemPrompt = "You are a compliant property investment analyst. Never guarantee returns. Use projected/estimated language only. Output valid JSON only.";
        const aiResult = await openAIProvider.chat([
          { role: "system", content: systemPrompt },
          { role: "user", content: prompt },
        ], { maxTokens: 2048 });

        const cleaned = aiResult.content.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
        explanation = JSON.parse(cleaned);

        const userId = (req as any).user?.userId ?? null;
        await logAiInteraction({
          userId,
          feature: "RECOMMENDER",
          prompt: JSON.stringify({ preferences, matchCount: matches.length }),
          response: JSON.stringify(explanation),
          sourcesJson: matches.map(m => ({ id: m.property.id, score: m.totalScore, percent: m.percentMatch })),
          tokensEstimated: aiResult.tokensEstimated,
        });
      } catch (aiErr: any) {
        console.error("[Recommender] AI explanation failed, returning matches without AI text:", aiErr.message);
        explanation = {
          whyTheseMatches: "These properties were selected using our deterministic scoring algorithm based on your stated preferences for city, budget, investment goal, risk tolerance, and liquidity needs.",
          tradeoffs: "Each property involves different tradeoffs between projected income yield and capital appreciation potential. Review the individual scoring breakdowns for details.",
        };
      }

      if ((req as any).user?.userId) {
        try {
          await db.insert(investorPreferenceProfiles).values({
            userId: (req as any).user.userId,
            region: preferences.region,
            budgetMin: preferences.budgetMin.toString(),
            budgetMax: preferences.budgetMax.toString(),
            goal: preferences.goal,
            citiesJson: preferences.cities,
            riskTolerance: preferences.riskTolerance,
            horizonMonths: preferences.horizonMonths,
            liquidityNeed: preferences.liquidityNeed,
          });
        } catch (saveErr) {
          console.error("[Recommender] Failed to save preference profile:", saveErr);
        }
      }

      res.json({
        ok: true,
        matches,
        explanation,
        preferences: {
          goal: preferences.goal,
          budgetRange: `PKR ${preferences.budgetMin.toLocaleString()} - PKR ${preferences.budgetMax.toLocaleString()}`,
          cities: preferences.cities,
          riskTolerance: preferences.riskTolerance,
          horizonMonths: preferences.horizonMonths,
          liquidityNeed: preferences.liquidityNeed,
        },
      });
    } catch (err: any) {
      console.error("[Recommender] Error:", err);
      res.status(500).json({ error: "Failed to generate property matches" });
    }
  });

  app.post("/api/ai/roi/explain", async (req: Request, res: Response) => {
    try {
      const { amount, yieldPct, occupancy, fees, months, currency, liquidityNeed } = req.body;
      if (!amount || !yieldPct || occupancy == null || fees == null || !months) {
        return res.status(400).json({ error: "Missing required fields: amount, yieldPct, occupancy, fees, months" });
      }
      const liqNeed = liquidityNeed || "MED";

      const effectiveYield = (yieldPct * (occupancy / 100)) - fees;
      const annualReturn = amount * (effectiveYield / 100);
      const monthlyDist = annualReturn / 12;
      const totalReturn = annualReturn * (months / 12);
      const roiPercent = (totalReturn / amount) * 100;

      const scenarios = [
        { label: "Low", yieldAdj: -2, occAdj: -10 },
        { label: "Base", yieldAdj: 0, occAdj: 0 },
        { label: "High", yieldAdj: 2, occAdj: 5 },
      ].map((s) => {
        const adjYield = yieldPct + s.yieldAdj;
        const adjOcc = Math.min(100, occupancy + s.occAdj);
        const effYield = (adjYield * (adjOcc / 100)) - fees;
        const annual = amount * (effYield / 100);
        const monthly = annual / 12;
        const total = annual * (months / 12);
        const roi = (total / amount) * 100;
        return { label: s.label, yieldUsed: adjYield, occUsed: adjOcc, effectiveYield: effYield, annual, monthly, total, roi };
      });

      const sensitivity = {
        occupancyDrop10: (() => {
          const eff = (yieldPct * ((occupancy - 10) / 100)) - fees;
          return { effectiveYield: eff, annual: amount * (eff / 100), monthly: amount * (eff / 100) / 12, impact: ((eff - effectiveYield) / Math.abs(effectiveYield || 1)) * 100 };
        })(),
        feesUp1: (() => {
          const eff = (yieldPct * (occupancy / 100)) - (fees + 1);
          return { effectiveYield: eff, annual: amount * (eff / 100), monthly: amount * (eff / 100) / 12, impact: ((eff - effectiveYield) / Math.abs(effectiveYield || 1)) * 100 };
        })(),
        yieldDown1: (() => {
          const eff = ((yieldPct - 1) * (occupancy / 100)) - fees;
          return { effectiveYield: eff, annual: amount * (eff / 100), monthly: amount * (eff / 100) / 12, impact: ((eff - effectiveYield) / Math.abs(effectiveYield || 1)) * 100 };
        })(),
      };

      let currencyNote = "";
      const fxRates: Record<string, number> = { AED: 0.067, USD: 0.0036, GBP: 0.0029 };
      let convertedMonthly = null;
      if (currency && currency !== "PKR" && fxRates[currency]) {
        convertedMonthly = monthlyDist * fxRates[currency];
        currencyNote = `At approximate rate, PKR ${Math.round(monthlyDist).toLocaleString()} ≈ ${currency} ${convertedMonthly.toFixed(2)}. FX rates fluctuate; actual conversion may differ.`;
      }

      const prompt = `You are a compliant real estate investment analyst for VestBlock. Analyze these DETERMINISTIC ROI calculation results and provide a clear explanation.

INPUTS:
- Investment: PKR ${amount.toLocaleString()}
- Expected Yield: ${yieldPct}%
- Occupancy: ${occupancy}%
- Management Fees: ${fees}%
- Holding Period: ${months} months
- Liquidity Need: ${liqNeed} (LOW = can lock capital, MED = may need partial access, HIGH = wants ability to exit anytime)
${currency && currency !== "PKR" ? `- Display Currency: ${currency}` : ""}

DETERMINISTIC RESULTS:
- Effective Yield: ${effectiveYield.toFixed(2)}%
- Estimated Monthly: PKR ${Math.round(monthlyDist).toLocaleString()}
- Estimated Annual: PKR ${Math.round(annualReturn).toLocaleString()}
- Projected ROI over ${months} months: ${roiPercent.toFixed(1)}%
${convertedMonthly ? `- Converted Monthly: ${currency} ${convertedMonthly.toFixed(2)} (approximate)` : ""}

SCENARIOS:
${scenarios.map(s => `  ${s.label}: Yield ${s.yieldUsed}%, Occ ${s.occUsed}% → Monthly PKR ${Math.round(s.monthly).toLocaleString()}, ROI ${s.roi.toFixed(1)}%`).join("\n")}

SENSITIVITY:
- Occupancy -10%: Annual drops to PKR ${Math.round(sensitivity.occupancyDrop10.annual).toLocaleString()} (${sensitivity.occupancyDrop10.impact.toFixed(1)}% change)
- Fees +1%: Annual drops to PKR ${Math.round(sensitivity.feesUp1.annual).toLocaleString()} (${sensitivity.feesUp1.impact.toFixed(1)}% change)
- Yield -1%: Annual drops to PKR ${Math.round(sensitivity.yieldDown1.annual).toLocaleString()} (${sensitivity.yieldDown1.impact.toFixed(1)}% change)

Respond in valid JSON:
{
  "plainExplanation": "2-3 sentences explaining what these numbers mean in simple terms. Reference the actual computed values.",
  "biggestFactor": "1-2 sentences on which input affects payout the most based on the sensitivity analysis.",
  "nextSteps": "2-3 actionable next steps (review property documents, understand risk factors, check exit windows, etc.)",
  "holdingStrategy": "1-2 sentences on the holding period choice based on the ${months}-month term and ${liqNeed} liquidity need. If HIGH liquidity, mention exit windows. If LOW, discuss long-term hold benefits.",
  "currencyNote": "${currencyNote || 'N/A — investor is using PKR.'}"
}

RULES:
- Never promise or guarantee returns. Use "estimated", "projected", "illustrative".
- Never give financial advice. Frame as educational analysis.
- Reference the ACTUAL computed numbers, not made-up figures.
- Keep language accessible for non-expert investors.`;

      const systemPrompt = "You are a compliant investment analyst. Never guarantee returns. Output valid JSON only.";
      let explanation = {
        plainExplanation: `Based on your inputs, the estimated monthly distribution is approximately PKR ${Math.round(monthlyDist).toLocaleString()} with an effective yield of ${effectiveYield.toFixed(2)}% after accounting for ${occupancy}% occupancy and ${fees}% fees.`,
        biggestFactor: "Occupancy rate tends to have the largest impact on your projected returns, as it directly scales the yield before fees are deducted.",
        nextSteps: "Review the property's historical occupancy data, understand the fee structure, and check available exit windows for your holding period.",
        holdingStrategy: `A ${months}-month holding period provides time for potential appreciation alongside distribution income.`,
        currencyNote: currencyNote || "You are viewing results in PKR.",
      };

      try {
        const aiResult = await openAIProvider.chat([
          { role: "system", content: systemPrompt },
          { role: "user", content: prompt },
        ], { maxTokens: 1536 });

        const cleaned = aiResult.content.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
        const parsed = JSON.parse(cleaned);
        explanation = { ...explanation, ...parsed };

        const userId = (req as any).user?.userId ?? null;
        await logAiInteraction({
          userId,
          feature: "ROI_EXPLAIN",
          prompt: JSON.stringify({ amount, yieldPct, occupancy, fees, months, currency }),
          response: JSON.stringify(explanation),
          sourcesJson: { effectiveYield, annualReturn, monthlyDist, roiPercent, scenarios: scenarios.map(s => ({ label: s.label, roi: s.roi })) },
          tokensEstimated: aiResult.tokensEstimated,
        });
      } catch (aiErr: any) {
        console.error("[ROI Explain] AI failed, returning deterministic explanation:", aiErr.message);
        const userId = (req as any).user?.userId ?? null;
        await logAiInteraction({
          userId,
          feature: "ROI_EXPLAIN",
          prompt: JSON.stringify({ amount, yieldPct, occupancy, fees, months, currency, liquidityNeed: liqNeed, aiError: aiErr.message }),
          response: JSON.stringify(explanation),
          sourcesJson: { effectiveYield, annualReturn, monthlyDist, roiPercent, fallback: true },
          tokensEstimated: 0,
        });
      }

      res.json({
        ok: true,
        deterministic: {
          effectiveYield,
          annualReturn,
          monthlyDist,
          totalReturn,
          roiPercent,
          scenarios,
          sensitivity,
          convertedMonthly,
          currency: currency || "PKR",
        },
        explanation,
      });
    } catch (err: any) {
      console.error("[ROI Explain] Error:", err);
      res.status(500).json({ error: "Failed to generate ROI explanation" });
    }
  });

  app.post("/api/ai/market-pulse/run", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const { computeMarketPulseMetrics, buildMarketPulsePrompt } = await import("../services/market-pulse");
      const region = req.body.region || "PK";
      const metrics = await computeMarketPulseMetrics(region);

      const [snapshot] = await db.insert(marketPulseMetricSnapshots).values({
        weekStart: metrics.weekStart,
        weekEnd: metrics.weekEnd,
        region,
        metricsJson: metrics as any,
      }).returning();

      let narrativeMd = `## Market Pulse: ${metrics.weekStart} to ${metrics.weekEnd}\n\n`;
      narrativeMd += `### Rental Yield Trends\n`;
      if (metrics.rentalYieldsByCity.length > 0) {
        metrics.rentalYieldsByCity.forEach(c => {
          narrativeMd += `- **${c.city}**: ${c.avgYield}% avg yield (${c.listingCount} listings)${c.changePercent !== null ? ` — ${c.changePercent > 0 ? "+" : ""}${c.changePercent}% WoW` : ""}\n`;
        });
      } else {
        narrativeMd += `- No active listings with yield data found for this period.\n`;
      }
      narrativeMd += `\n### Listing Activity\n`;
      narrativeMd += `- New listings: ${metrics.listingPerformance.newListingsCount}\n`;
      narrativeMd += `- Average funding: ${metrics.listingPerformance.avgFundingPercent}%\n`;
      narrativeMd += `\n### Exit Window Liquidity\n`;
      narrativeMd += `- Units listed: ${metrics.exitWindowStats.unitsListed}\n`;
      narrativeMd += `- Units sold: ${metrics.exitWindowStats.unitsSold}\n`;

      let highlights = [
        `${metrics.rentalYieldsByCity.length} cities tracked for rental yields`,
        `${metrics.listingPerformance.newListingsCount} new listings this week`,
        `Average funding at ${metrics.listingPerformance.avgFundingPercent}%`,
        `${metrics.exitWindowStats.unitsListed} units on secondary market`,
        `${metrics.exitWindowStats.unitsSold} units sold`,
      ];

      try {
        const prompt = buildMarketPulsePrompt(metrics);
        const aiResult = await openAIProvider.chat([
          { role: "system", content: "You are a compliant market analyst. Never guarantee returns. Output valid JSON only." },
          { role: "user", content: prompt },
        ], { maxTokens: 2048 });

        const cleaned = aiResult.content.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
        const parsed = JSON.parse(cleaned);
        if (parsed.narrativeMd) narrativeMd = parsed.narrativeMd;
        if (parsed.highlights) highlights = parsed.highlights;

        const userId = (req as any).user?.userId ?? null;
        await logAiInteraction({
          userId,
          feature: "MARKET_PULSE",
          prompt: JSON.stringify({ region, weekStart: metrics.weekStart, weekEnd: metrics.weekEnd }),
          response: JSON.stringify({ narrativeMd: narrativeMd.substring(0, 500), highlightsCount: highlights.length }),
          sourcesJson: { metricsSnapshotId: snapshot.id, rentalCities: metrics.rentalYieldsByCity.length, newListings: metrics.listingPerformance.newListingsCount },
          tokensEstimated: aiResult.tokensEstimated,
        });
      } catch (aiErr: any) {
        console.error("[MarketPulse] AI failed, using deterministic narrative:", aiErr.message);
        const userId = (req as any).user?.userId ?? null;
        await logAiInteraction({
          userId,
          feature: "MARKET_PULSE",
          prompt: JSON.stringify({ region, weekStart: metrics.weekStart, weekEnd: metrics.weekEnd, aiError: aiErr.message }),
          response: JSON.stringify({ fallback: true }),
          sourcesJson: { metricsSnapshotId: snapshot.id },
          tokensEstimated: 0,
        });
      }

      const [report] = await db.insert(marketPulseReports).values({
        weekStart: metrics.weekStart,
        weekEnd: metrics.weekEnd,
        region,
        status: "draft",
        narrativeMd,
        highlightsJson: highlights as any,
        metricsSnapshotId: snapshot.id,
      }).returning();

      res.json({ ok: true, report, snapshot });
    } catch (err: any) {
      console.error("[MarketPulse] Run error:", err);
      const userId = (req as any).user?.userId ?? null;
      try {
        await logAiInteraction({
          userId,
          feature: "MARKET_PULSE",
          prompt: JSON.stringify({ region: req.body.region || "PK", error: err.message }),
          response: JSON.stringify({ error: true, message: err.message }),
          sourcesJson: {},
          tokensEstimated: 0,
        });
      } catch (_) {}
      res.status(500).json({ error: "Failed to generate market pulse report" });
    }
  });

  app.get("/api/ai/market-pulse/reports", requireAuth, requireRole("admin"), async (_req: Request, res: Response) => {
    try {
      const reports = await db.select().from(marketPulseReports)
        .where(eq(marketPulseReports.region, "PK"))
        .orderBy(desc(marketPulseReports.createdAt))
        .limit(20);
      res.json({ ok: true, reports });
    } catch (err: any) {
      console.error("[MarketPulse] List error:", err);
      res.status(500).json({ error: "Failed to fetch reports" });
    }
  });

  app.get("/api/ai/market-pulse/reports/:id", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const [report] = await db.select().from(marketPulseReports).where(eq(marketPulseReports.id, req.params.id));
      if (!report) return res.status(404).json({ error: "Report not found" });

      let snapshot = null;
      if (report.metricsSnapshotId) {
        const [snap] = await db.select().from(marketPulseMetricSnapshots).where(eq(marketPulseMetricSnapshots.id, report.metricsSnapshotId));
        snapshot = snap || null;
      }

      res.json({ ok: true, report, snapshot });
    } catch (err: any) {
      console.error("[MarketPulse] Detail error:", err);
      res.status(500).json({ error: "Failed to fetch report" });
    }
  });

  app.patch("/api/ai/market-pulse/reports/:id/publish", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const [updated] = await db.update(marketPulseReports)
        .set({ status: "published" })
        .where(eq(marketPulseReports.id, req.params.id))
        .returning();
      if (!updated) return res.status(404).json({ error: "Report not found" });
      res.json({ ok: true, report: updated });
    } catch (err: any) {
      console.error("[MarketPulse] Publish error:", err);
      res.status(500).json({ error: "Failed to publish report" });
    }
  });

  app.get("/api/ai/market-pulse/latest", async (_req: Request, res: Response) => {
    try {
      const [report] = await db.select().from(marketPulseReports)
        .where(and(eq(marketPulseReports.region, "PK"), eq(marketPulseReports.status, "published")))
        .orderBy(desc(marketPulseReports.createdAt))
        .limit(1);

      if (!report) return res.json({ ok: true, report: null, snapshot: null });

      let snapshot = null;
      if (report.metricsSnapshotId) {
        const [snap] = await db.select().from(marketPulseMetricSnapshots).where(eq(marketPulseMetricSnapshots.id, report.metricsSnapshotId));
        snapshot = snap || null;
      }

      res.json({ ok: true, report, snapshot });
    } catch (err: any) {
      console.error("[MarketPulse] Latest error:", err);
      res.status(500).json({ error: "Failed to fetch latest report" });
    }
  });
}
