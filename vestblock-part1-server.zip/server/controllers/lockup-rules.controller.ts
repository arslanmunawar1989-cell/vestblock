import type { Express, Request, Response } from "express";
import { requireAuth, requireRole } from "../auth";
import { storage } from "../storage";
import { insertLockupRuleSchema } from "@shared/schema";

export function registerLockupRulesRoutes(app: Express) {
  app.get("/api/admin/lockup-rules", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    const tenantId = req.tenantId as string | undefined;
    const rules = await storage.getLockupRules(tenantId);
    res.json(rules);
  });

  app.get("/api/admin/lockup-rules/asset/:assetId", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    const rule = await storage.getLockupRuleByAsset(req.params.assetId as string);
    if (!rule) return res.status(404).json({ message: "No lockup rule found for this asset" });
    res.json(rule);
  });

  app.post("/api/admin/lockup-rules", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    const tenantId = req.tenantId as string | undefined;
    const parsed = insertLockupRuleSchema.safeParse({ ...req.body, tenantId });
    if (!parsed.success) return res.status(400).json({ message: "Validation failed", errors: parsed.error.flatten() });

    const existing = await storage.getLockupRuleByAsset(parsed.data.assetId);
    if (existing) return res.status(409).json({ message: "Lockup rule already exists for this asset" });

    const rule = await storage.createLockupRule(parsed.data);
    res.status(201).json(rule);
  });

  app.patch("/api/admin/lockup-rules/:id", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    const updated = await storage.updateLockupRule(req.params.id as string, req.body);
    if (!updated) return res.status(404).json({ message: "Lockup rule not found" });
    res.json(updated);
  });

  app.delete("/api/admin/lockup-rules/:id", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    const deleted = await storage.deleteLockupRule(req.params.id as string);
    if (!deleted) return res.status(404).json({ message: "Lockup rule not found" });
    res.json({ message: "Lockup rule deleted" });
  });
}
