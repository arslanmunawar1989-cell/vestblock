import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import {
  SUPPORTED_CHAINS,
  SUPPORTED_TOKENS,
  attachCryptoWalletSchema,
  blacklistCryptoWalletSchema,
  adminNotesCryptoWalletSchema,
} from "@shared/schema";
import { paymentLimiter } from "../middleware/rate-limit";

export function registerCryptoWalletRoutes(app: Express) {
  app.get("/api/crypto/chains", requireAuth, (_req, res) => {
    res.json({ chains: SUPPORTED_CHAINS, tokens: SUPPORTED_TOKENS });
  });

  app.get("/api/crypto/wallets", requireAuth, async (req, res) => {
    try {
      const jwtUser = (req as any).user;
      const wallets = await storage.getCryptoWalletsByUser(jwtUser.userId);
      res.json(wallets);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/crypto/wallets", requireAuth, paymentLimiter, async (req, res) => {
    try {
      const jwtUser = (req as any).user;
      const parsed = attachCryptoWalletSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Validation failed", errors: parsed.error.flatten().fieldErrors });
      }

      const { chainId, address, label } = parsed.data;

      const chain = SUPPORTED_CHAINS.find(c => c.id === chainId);
      if (!chain) {
        return res.status(400).json({ message: `Unsupported chain: ${chainId}` });
      }

      const regex = new RegExp(chain.addressPattern);
      if (!regex.test(address)) {
        return res.status(400).json({ message: `Invalid address format for ${chain.name}` });
      }

      const existing = await storage.getCryptoWalletsByUser(jwtUser.userId);
      const duplicate = existing.find(w => w.chainId === chainId && w.address.toLowerCase() === address.toLowerCase());
      if (duplicate) {
        return res.status(409).json({ message: "This wallet address is already attached for this chain" });
      }

      const wallet = await storage.createCryptoWallet({
        userId: jwtUser.userId,
        chainId,
        address,
        label: label || null,
      });

      res.status(201).json(wallet);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/crypto/wallets/:id", requireAuth, async (req, res) => {
    try {
      const jwtUser = (req as any).user;
      const wallet = await storage.getCryptoWalletById(String(String(req.params.id)));
      if (!wallet) return res.status(404).json({ message: "Wallet not found" });
      if (wallet.userId !== jwtUser.userId && jwtUser.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      if (wallet.isBlacklisted) {
        return res.status(400).json({ message: "Cannot delete a blacklisted wallet" });
      }

      await storage.deleteCryptoWallet(String(String(req.params.id)));
      res.json({ message: "Wallet removed" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/crypto/wallets", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const wallets = await storage.getAllCryptoWallets(req.tenantId);
      res.json(wallets);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/crypto/wallets/:id/blacklist", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const jwtUser = (req as any).user;
      const parsed = blacklistCryptoWalletSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Validation error", errors: parsed.error.flatten() });
      }

      const wallet = await storage.getCryptoWalletById(String(String(req.params.id)));
      if (!wallet) return res.status(404).json({ message: "Wallet not found" });

      const updated = await storage.blacklistCryptoWallet(String(String(req.params.id)), jwtUser.userId, parsed.data.reason);
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/crypto/wallets/:id/unblacklist", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const wallet = await storage.getCryptoWalletById(String(String(req.params.id)));
      if (!wallet) return res.status(404).json({ message: "Wallet not found" });

      const updated = await storage.unblacklistCryptoWallet(String(String(req.params.id)));
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/admin/crypto/wallets/:id/notes", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const parsed = adminNotesCryptoWalletSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Validation error", errors: parsed.error.flatten() });
      }

      const wallet = await storage.getCryptoWalletById(String(String(req.params.id)));
      if (!wallet) return res.status(404).json({ message: "Wallet not found" });

      const updated = await storage.updateCryptoWalletAdminNotes(String(String(req.params.id)), parsed.data.notes);
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
}
