import type { Express, Request, Response } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole, requirePlatformRole } from "../auth";
import { logAudit } from "../lib/audit-logger";
import { z } from "zod";

const updateStatusSchema = z.object({
  status: z.enum(["ACTIVE", "DISABLED", "ARCHIVED"]),
  reason: z.string().optional(),
});

const assignRoleSchema = z.object({
  role: z.string().optional(),
  platformRole: z.enum(["SUPER_ADMIN", "PLATFORM_ADMIN", "COMPLIANCE_OFFICER", "FINANCE_MANAGER", "SUPPORT_AGENT", "VIEWER"]).optional(),
});

export function registerAccountLifecycleRoutes(app: Express) {
  app.get("/api/admin/users", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const users = await storage.getUsers(req.tenantId);
      const safeUsers = users.map(u => {
        const { password, ...safe } = u;
        return safe;
      });
      res.json(safeUsers);
    } catch (err: any) {
      console.error("Get users error:", err);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.get("/api/admin/users/:userId", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const user = await storage.getUser(req.params.userId as string);
      if (!user) return res.status(404).json({ message: "User not found" });
      const { password, ...safe } = user;
      const hasFinancial = await storage.hasFinancialRecords(user.id);
      res.json({ ...safe, hasFinancialRecords: hasFinancial });
    } catch (err: any) {
      console.error("Get user error:", err);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.post("/api/admin/users/:userId/status", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const parsed = updateStatusSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Validation failed", errors: parsed.error.errors });
      }
      const { status, reason } = parsed.data;
      const targetUserId = req.params.userId as string;
      const actor = (req as any).user;

      const targetUser = await storage.getUser(targetUserId);
      if (!targetUser) return res.status(404).json({ message: "User not found" });

      if (targetUserId === actor.userId) {
        return res.status(400).json({ message: "You cannot change your own account status" });
      }

      if (status === "DISABLED" || status === "ARCHIVED") {
        const ownedProjects = await storage.getProjectsByCreator(targetUserId);
        if (ownedProjects.length > 0) {
          const activeAdmins = await storage.getActiveAdminUsers();
          const alternateOwner = activeAdmins.find(u => u.id !== targetUserId);
          if (!alternateOwner) {
            return res.status(409).json({
              message: "Cannot disable/archive: this user owns projects and no other active admin is available to receive ownership. Transfer projects first.",
              ownedProjectCount: ownedProjects.length,
            });
          }
          const transferCount = await storage.transferProjectOwnership(targetUserId, alternateOwner.id);
          await logAudit({
            actorId: actor.userId,
            actorRole: actor.role,
            actionType: "PROJECT_OWNERSHIP_TRANSFERRED",
            entityType: "project",
            entityId: targetUserId,
            reason: `Transferred ${transferCount} projects from ${targetUser.username} to ${alternateOwner.username} (auto-transfer on ${status.toLowerCase()})`,
            ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
            userAgent: req.headers["user-agent"] || undefined,
          });
        }
      }

      const updated = await storage.updateAccountStatus(targetUserId, status, actor.userId);
      if (!updated) return res.status(500).json({ message: "Failed to update status" });

      if (status !== "ACTIVE") {
        await storage.incrementTokenVersion(targetUserId);
      }

      await logAudit({
        actorId: actor.userId,
        actorRole: actor.role,
        actionType: `ACCOUNT_${status}`,
        entityType: "user",
        entityId: targetUserId,
        reason: reason || `Account status changed to ${status} for user ${targetUser.username}`,
        beforeState: { accountStatus: targetUser.accountStatus },
        afterState: { accountStatus: status },
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });

      const { password, ...safe } = updated;
      res.json({ ...safe, message: `Account ${status.toLowerCase()} successfully` });
    } catch (err: any) {
      console.error("Update account status error:", err);
      res.status(500).json({ message: "Failed to update account status" });
    }
  });

  app.post("/api/admin/users/:userId/force-logout", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const targetUserId = req.params.userId as string;
      const actor = (req as any).user;
      const targetUser = await storage.getUser(targetUserId);
      if (!targetUser) return res.status(404).json({ message: "User not found" });

      await storage.incrementTokenVersion(targetUserId);

      await logAudit({
        actorId: actor.userId,
        actorRole: actor.role,
        actionType: "FORCE_LOGOUT",
        entityType: "user",
        entityId: targetUserId,
        reason: `Force logout issued for user ${targetUser.username}`,
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });

      res.json({ message: `All sessions for ${targetUser.username} have been revoked` });
    } catch (err: any) {
      console.error("Force logout error:", err);
      res.status(500).json({ message: "Failed to force logout" });
    }
  });

  app.delete("/api/admin/users/:userId", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const targetUserId = req.params.userId as string;
      const actor = (req as any).user;
      const targetUser = await storage.getUser(targetUserId);
      if (!targetUser) return res.status(404).json({ message: "User not found" });

      if (targetUserId === actor.userId) {
        return res.status(400).json({ message: "You cannot delete your own account" });
      }

      const hasFinancial = await storage.hasFinancialRecords(targetUserId);
      if (hasFinancial) {
        return res.status(409).json({
          message: "Cannot delete user with financial records. Archive the account instead to preserve audit history.",
          hasFinancialRecords: true,
          suggestion: "ARCHIVED",
        });
      }

      await storage.updateAccountStatus(targetUserId, "ARCHIVED", actor.userId);
      await storage.incrementTokenVersion(targetUserId);

      await logAudit({
        actorId: actor.userId,
        actorRole: actor.role,
        actionType: "ACCOUNT_DELETED",
        entityType: "user",
        entityId: targetUserId,
        reason: `User ${targetUser.username} archived (soft-delete, no financial records)`,
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });

      res.json({ message: "User account has been archived" });
    } catch (err: any) {
      console.error("Delete user error:", err);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  app.post("/api/admin/users/:userId/transfer-projects", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const { toUserId } = req.body;
      const fromUserId = req.params.userId as string;
      const actor = (req as any).user;

      if (!toUserId) return res.status(400).json({ message: "toUserId is required" });

      const fromUser = await storage.getUser(fromUserId);
      const toUser = await storage.getUser(toUserId);
      if (!fromUser) return res.status(404).json({ message: "Source user not found" });
      if (!toUser) return res.status(404).json({ message: "Target user not found" });
      if (toUser.accountStatus !== "ACTIVE") {
        return res.status(400).json({ message: "Cannot transfer to a non-active user" });
      }

      const count = await storage.transferProjectOwnership(fromUserId, toUserId);

      await logAudit({
        actorId: actor.userId,
        actorRole: actor.role,
        actionType: "PROJECT_OWNERSHIP_TRANSFERRED",
        entityType: "project",
        entityId: fromUserId,
        reason: `Transferred ${count} projects from ${fromUser.username} to ${toUser.username}`,
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });

      res.json({ message: `${count} projects transferred successfully`, count });
    } catch (err: any) {
      console.error("Transfer projects error:", err);
      res.status(500).json({ message: "Failed to transfer projects" });
    }
  });

  app.get("/api/admin/users/:userId/audit-log", requireAuth, requireRole("admin"), async (req: Request, res: Response) => {
    try {
      const targetUserId = req.params.userId as string;
      const logs = await storage.getAuditLogsByEntity("user", targetUserId);
      res.json(logs);
    } catch (err: any) {
      console.error("Get audit log error:", err);
      res.status(500).json({ message: "Failed to fetch audit log" });
    }
  });

  app.post("/api/admin/users/:userId/role", requireAuth, requireRole("admin"), requirePlatformRole("SUPER_ADMIN"), async (req: Request, res: Response) => {
    try {
      const parsed = assignRoleSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Validation failed", errors: parsed.error.errors });
      }
      const { role, platformRole } = parsed.data;
      const reason = req.body.reason as string | undefined;
      const targetUserId = req.params.userId as string;
      const actor = (req as any).user;

      const validRoles = ["admin", "investor", "issuer", "agent"];
      const validPlatformRoles = ["SUPER_ADMIN", "PLATFORM_ADMIN", "PLATFORM_FINANCE", "PLATFORM_COMPLIANCE"];

      if (role !== undefined && !validRoles.includes(role)) {
        return res.status(400).json({ message: `Role must be one of: ${validRoles.join(", ")}` });
      }

      if (platformRole !== undefined && platformRole !== null && !validPlatformRoles.includes(platformRole)) {
        return res.status(400).json({ message: `platformRole must be one of: ${validPlatformRoles.join(", ")} or null` });
      }

      const targetUser = await storage.getUser(targetUserId);
      if (!targetUser) return res.status(404).json({ message: "User not found" });

      if (targetUserId === actor.userId && platformRole !== undefined) {
        const currentIndex = targetUser.platformRole ? validPlatformRoles.indexOf(targetUser.platformRole) : -1;
        const newIndex = platformRole === null ? -1 : validPlatformRoles.indexOf(platformRole);
        if (newIndex < currentIndex) {
          return res.status(400).json({ message: "You cannot demote your own platformRole" });
        }
      }

      const updates: Record<string, any> = {};
      if (role !== undefined) updates.role = role;
      if (platformRole !== undefined) updates.platformRole = platformRole;

      if (Object.keys(updates).length === 0) {
        return res.status(400).json({ message: "No role changes provided" });
      }

      const updated = await storage.updateUser(targetUserId, updates);
      if (!updated) return res.status(500).json({ message: "Failed to update role" });

      await logAudit({
        actorId: actor.userId,
        actorRole: actor.role,
        actionType: "ROLE_CHANGED",
        entityType: "user",
        entityId: targetUserId,
        reason: reason || `Role changed for user ${targetUser.username}`,
        beforeState: { role: targetUser.role, platformRole: targetUser.platformRole },
        afterState: { role: updated.role, platformRole: updated.platformRole },
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });

      const { password, ...safe } = updated;
      res.json(safe);
    } catch (err: any) {
      console.error("Update role error:", err);
      res.status(500).json({ message: "Failed to update role" });
    }
  });
}
