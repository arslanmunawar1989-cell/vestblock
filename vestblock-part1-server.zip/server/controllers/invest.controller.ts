import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth } from "../auth";
import { logAuditFromReq } from "../lib/audit-logger";
import { z } from "zod";
import { CURRENCY_DETAILS } from "@shared/constants";
import { db } from "../db";
import { walletTransactions, portfolioItems, rounds, transactions } from "@shared/schema";
import type { InvestorType } from "@shared/schema";
import { eq, and } from "drizzle-orm";
import { investRequestSchema } from "@shared/dto/invest.dto";
import { validateBody } from "../middleware/validate";
import { checkAndTriggerAutoIssuance } from "../services/token-issuance.service";
import { buildPolicyContext, canInvest, getEffectivePolicy } from "../services/policy.service";
import { executeConversion, getFxQuote } from "../fx";
import { isSanctionedCountry, isBlockedNationality } from "@shared/investor-policy";
import { getPolicy } from "@shared/compliance-policy";
import { COUNTRY_DETAILS } from "@shared/constants";

function decimalMul(a: string, b: number): string {
  const aNum = Math.round(parseFloat(a) * 1e6);
  const bNum = Math.round(b * 1e6);
  return (aNum * bNum / 1e12).toFixed(2);
}

function decimalCompare(a: string, b: string): number {
  const diff = parseFloat(a) - parseFloat(b);
  if (Math.abs(diff) < 0.005) return 0;
  return diff;
}

export function registerInvestRoutes(app: Express) {
  app.post("/api/invest", requireAuth, validateBody(investRequestSchema), async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const data = req.body;

      const asset = await storage.getAsset(data.assetId);
      if (!asset) return res.status(404).json({ message: "Asset not found" });
      if (asset.status !== "active") return res.status(400).json({ message: "Asset is not open for investment" });

      const policyCtx = await buildPolicyContext(userId);
      const totalForPolicy = parseFloat(asset.pricePerToken) * data.quantity;
      const policyCheck = canInvest(
        policyCtx,
        (asset as any).minInvestorType as InvestorType | undefined,
        totalForPolicy
      );
      if (!policyCheck.allowed) {
        return res.status(403).json({
          message: policyCheck.reason,
          code: policyCheck.code,
          details: policyCheck.details,
        });
      }

      const userCountry = policyCtx.countryOfResidence || policyCtx.nationality || policyCtx.taxResidency || null;
      const assetEligible = asset.eligibleCountries || [];
      const assetRestricted = asset.restrictedCountries || [];
      if (!userCountry && (assetEligible.length > 0 || assetRestricted.length > 0)) {
        return res.status(403).json({
          message: "Country of residence must be set to invest in this asset",
          code: "NO_COUNTRY_FOR_ASSET",
        });
      }
      if (userCountry && assetEligible.length > 0 && !assetEligible.includes(userCountry)) {
        const eligibleNames = assetEligible.map(c => (COUNTRY_DETAILS as any)[c]?.name || c).join(", ");
        return res.status(403).json({
          message: `This asset is only available to investors in: ${eligibleNames}`,
          code: "ASSET_GEO_NOT_ELIGIBLE",
          details: { userCountry, eligibleCountries: assetEligible },
        });
      }
      if (userCountry && assetRestricted.length > 0 && assetRestricted.includes(userCountry)) {
        const countryName = (COUNTRY_DETAILS as any)[userCountry]?.name || userCountry;
        return res.status(403).json({
          message: `This asset is restricted for investors in ${countryName}`,
          code: "ASSET_GEO_RESTRICTED",
          details: { userCountry, restrictedCountries: assetRestricted },
        });
      }

      let vehicleType = "GENERAL";
      if (asset.vehicleId) {
        const vehicle = await storage.getInvestmentVehicle(asset.vehicleId);
        if (vehicle) vehicleType = vehicle.type;
      }
      const requiredDocs = await storage.getRequiredDocsForInvestment(asset.country, vehicleType);
      const { allAccepted, pending } = await storage.hasAcceptedAllRequiredDocs(userId, requiredDocs);
      if (!allAccepted) {
        return res.status(403).json({
          message: "You must accept all required legal documents before investing",
          code: "LEGAL_NOT_ACCEPTED",
          details: {
            pendingCount: pending.length,
            pendingDocs: pending.map(d => ({ id: d.id, type: d.type, title: d.title, productType: d.productType })),
            country: asset.country,
            vehicleType,
          },
        });
      }

      const tokenDecimals = asset.tokenDecimals ?? 2;
      const multiplier = Math.pow(10, tokenDecimals);
      if (Math.round(data.quantity * multiplier) !== data.quantity * multiplier) {
        return res.status(400).json({
          message: `This asset allows up to ${tokenDecimals} decimal places for token quantities (e.g. ${(1 / multiplier).toFixed(tokenDecimals)} minimum increment)`,
          code: "INVALID_PRECISION",
          tokenDecimals,
        });
      }

      const baseCurrency = asset.baseCurrency;
      const currencyDetail = CURRENCY_DETAILS[baseCurrency as keyof typeof CURRENCY_DETAILS];
      const currencySymbol = currencyDetail?.symbol || baseCurrency;

      const totalInvestAmount = decimalMul(asset.pricePerToken, data.quantity);
      if (asset.minInvestment && decimalCompare(totalInvestAmount, asset.minInvestment) < 0) {
        const minTokens = (parseFloat(asset.minInvestment) / parseFloat(asset.pricePerToken));
        return res.status(400).json({
          message: `Minimum investment is ${currencySymbol} ${parseFloat(asset.minInvestment).toLocaleString()} (${minTokens.toFixed(tokenDecimals)} tokens)`,
          code: "BELOW_MINIMUM_INVESTMENT",
          minInvestment: asset.minInvestment,
          minTokens: parseFloat(minTokens.toFixed(tokenDecimals)),
          yourAmount: totalInvestAmount,
        });
      }
      if (asset.maxInvestment && decimalCompare(totalInvestAmount, asset.maxInvestment) > 0) {
        const maxTokens = (parseFloat(asset.maxInvestment) / parseFloat(asset.pricePerToken));
        return res.status(400).json({
          message: `Maximum investment is ${currencySymbol} ${parseFloat(asset.maxInvestment).toLocaleString()} (${maxTokens.toFixed(tokenDecimals)} tokens)`,
          code: "ABOVE_MAXIMUM_INVESTMENT",
          maxInvestment: asset.maxInvestment,
          maxTokens: parseFloat(maxTokens.toFixed(tokenDecimals)),
          yourAmount: totalInvestAmount,
        });
      }

      if (asset.maxOwnershipPercent) {
        const maxPct = parseFloat(asset.maxOwnershipPercent);
        if (maxPct > 0 && maxPct <= 100) {
          const totalSupply = parseFloat(asset.totalSupply);
          if (totalSupply > 0) {
            const existingPortfolio = await storage.getPortfolioItem(userId, data.assetId);
            const currentTokens = existingPortfolio ? parseFloat(existingPortfolio.quantity) : 0;
            const newTotal = currentTokens + data.quantity;
            const newPct = (newTotal / totalSupply) * 100;
            if (newPct > maxPct) {
              const maxTokens = (maxPct / 100) * totalSupply;
              const canBuy = Math.max(0, maxTokens - currentTokens);
              return res.status(400).json({
                message: `This purchase would give you ${newPct.toFixed(2)}% ownership, exceeding the ${maxPct}% maximum per investor. You currently hold ${currentTokens.toFixed(tokenDecimals)} tokens and can purchase up to ${canBuy.toFixed(tokenDecimals)} more.`,
                code: "MAX_OWNERSHIP_EXCEEDED",
                maxOwnershipPercent: maxPct,
                currentOwnershipPercent: parseFloat(((currentTokens / totalSupply) * 100).toFixed(2)),
                requestedOwnershipPercent: parseFloat(newPct.toFixed(2)),
                maxTokens: parseFloat(maxTokens.toFixed(tokenDecimals)),
                currentTokens: parseFloat(currentTokens.toFixed(tokenDecimals)),
                canBuyTokens: parseFloat(canBuy.toFixed(tokenDecimals)),
              });
            }
          }
        }
      }

      const assetRounds = await storage.getRoundsByAsset(data.assetId);
      const round = assetRounds.find(r => r.id === data.roundId);
      if (!round) return res.status(404).json({ message: "Investment round not found" });
      if (round.status !== "open") return res.status(400).json({ message: "This investment round is not currently open" });

      const totalCost = decimalMul(asset.pricePerToken, data.quantity);

      const isCrossCurrency = data.sourceCurrency && data.sourceCurrency !== baseCurrency;
      if (isCrossCurrency && !data.fxQuoteId) {
        return res.status(400).json({
          message: "An FX quote is required for cross-currency investments",
          code: "FX_QUOTE_REQUIRED",
        });
      }
      if (!isCrossCurrency && data.fxQuoteId) {
        return res.status(400).json({
          message: "FX quote should only be provided for cross-currency investments",
          code: "FX_QUOTE_NOT_NEEDED",
        });
      }

      let fxConversionResult: { referenceId: string; ledgerTxId: string } | null = null;

      if (isCrossCurrency && data.fxQuoteId) {
        const quote = await storage.getFxQuoteById(data.fxQuoteId);
        if (!quote) {
          return res.status(400).json({ message: "FX quote not found", code: "FX_QUOTE_NOT_FOUND" });
        }
        if (quote.fromCurrency !== data.sourceCurrency) {
          return res.status(400).json({
            message: `FX quote source currency (${quote.fromCurrency}) does not match requested source (${data.sourceCurrency})`,
            code: "FX_QUOTE_CURRENCY_MISMATCH",
          });
        }
        if (quote.toCurrency !== baseCurrency) {
          return res.status(400).json({
            message: `FX quote target currency (${quote.toCurrency}) does not match asset currency (${baseCurrency})`,
            code: "FX_QUOTE_TARGET_MISMATCH",
          });
        }
        try {
          const convResult = await executeConversion(userId, data.fxQuoteId);
          fxConversionResult = { referenceId: convResult.referenceId, ledgerTxId: convResult.ledgerTxId };
        } catch (fxErr: any) {
          return res.status(400).json({
            message: `Currency conversion failed: ${fxErr.message}`,
            code: "FX_CONVERSION_FAILED",
          });
        }
      }

      const walletAccount = await storage.getWalletAccountByUserAndCurrency(userId, baseCurrency);
      if (!walletAccount) {
        return res.status(400).json({
          message: `You need a ${baseCurrency} wallet to invest in this asset`,
          code: "NO_WALLET",
          baseCurrency,
          requiredAmount: totalCost,
        });
      }

      const balance = await storage.getComputedBalance(walletAccount.id);

      if (decimalCompare(balance.available, totalCost) < 0) {
        const userAccounts = await storage.getWalletAccountsByUser(userId);
        const otherBalances: { currency: string; available: string }[] = [];
        for (const acc of userAccounts) {
          if (acc.currency !== baseCurrency) {
            const bal = await storage.getComputedBalance(acc.id);
            if (decimalCompare(bal.available, "0") > 0) {
              otherBalances.push({ currency: acc.currency, available: bal.available });
            }
          }
        }

        return res.status(400).json({
          message: `Insufficient ${baseCurrency} balance. You need ${currencySymbol} ${totalCost} but have ${currencySymbol} ${balance.available}.${fxConversionResult ? " The FX conversion was completed and funds are in your wallet. Please retry the investment." : ""}`,
          code: "INSUFFICIENT_BALANCE",
          baseCurrency,
          requiredAmount: totalCost,
          availableAmount: balance.available,
          shortfall: (parseFloat(totalCost) - parseFloat(balance.available)).toFixed(2),
          otherBalances,
          fxConversionCompleted: !!fxConversionResult,
        });
      }

      const remaining = (parseFloat(round.targetAmount) - parseFloat(round.raisedAmount)).toFixed(2);
      if (decimalCompare(totalCost, remaining) > 0) {
        return res.status(400).json({
          message: `Investment amount exceeds remaining capacity. Only ${currencySymbol} ${remaining} available in this round.`,
          code: "ROUND_CAPACITY_EXCEEDED",
          remainingCapacity: remaining,
        });
      }

      const refId = `INV-${Date.now().toString(36).toUpperCase()}`;
      const pricePerToken = asset.pricePerToken;

      const result = await db.transaction(async (tx) => {
        const [reserveTx] = await tx.insert(walletTransactions).values({
          walletAccountId: walletAccount.id,
          type: "INVEST_RESERVE",
          amount: totalCost,
          currency: baseCurrency,
          status: "COMPLETED",
          referenceId: refId,
          description: `Reserved for ${asset.name} (${data.quantity} tokens)`,
          metadata: { assetSymbol: asset.symbol, tokens: data.quantity },
        }).returning();

        await tx.insert(walletTransactions).values({
          walletAccountId: walletAccount.id,
          type: "INVEST_CAPTURE",
          amount: totalCost,
          currency: baseCurrency,
          status: "COMPLETED",
          referenceId: refId,
          description: `Captured investment in ${asset.name}`,
          metadata: { assetSymbol: asset.symbol, tokens: data.quantity, pricePerToken },
        });

        const [existingPortfolio] = await tx.select().from(portfolioItems)
          .where(and(eq(portfolioItems.userId, userId), eq(portfolioItems.assetId, data.assetId)));

        let portfolioItem;
        if (existingPortfolio) {
          const oldQty = parseFloat(existingPortfolio.quantity);
          const oldCost = parseFloat(existingPortfolio.averageCost);
          const newQty = data.quantity;
          const newCost = parseFloat(pricePerToken);
          const totalQty = oldQty + newQty;
          const weightedAvgCost = totalQty > 0 ? ((oldQty * oldCost + newQty * newCost) / totalQty) : newCost;
          const [updated] = await tx.update(portfolioItems)
            .set({
              quantity: totalQty.toFixed(6),
              averageCost: weightedAvgCost.toFixed(6),
            })
            .where(eq(portfolioItems.id, existingPortfolio.id))
            .returning();
          portfolioItem = updated;
        } else {
          const [created] = await tx.insert(portfolioItems).values({
            userId,
            assetId: data.assetId,
            quantity: data.quantity.toFixed(6),
            averageCost: pricePerToken,
          }).returning();
          portfolioItem = created;
        }

        const newRaised = (parseFloat(round.raisedAmount) + parseFloat(totalCost)).toFixed(2);
        await tx.update(rounds)
          .set({ raisedAmount: newRaised })
          .where(eq(rounds.id, data.roundId));

        await tx.insert(transactions).values({
          userId,
          assetId: data.assetId,
          type: "purchase",
          amount: totalCost,
          status: "completed",
          description: `Purchased ${data.quantity} tokens of ${asset.name} at ${currencySymbol} ${parseFloat(pricePerToken).toFixed(2)} per token`,
        });

        return { portfolioItem, reserveTx };
      });

      await logAuditFromReq(req, "INVESTMENT", "asset", data.assetId, {
        reason: `Invested ${currencySymbol} ${totalCost} in ${asset.name} (${data.quantity} tokens at ${currencySymbol} ${parseFloat(pricePerToken).toFixed(2)}/token)`,
        metadata: { quantity: data.quantity, totalCost, currency: baseCurrency, pricePerToken, assetName: asset.name },
      });

      try {
        const now = new Date().toISOString();
        await storage.createSettlementEntry({
          assetId: data.assetId,
          roundId: data.roundId,
          userId,
          walletTransactionId: result.reserveTx?.id || null,
          paymentIntentId: null,
          referenceId: refId,
          state: "CLIENT_MONEY_HELD",
          amount: totalCost,
          currency: baseCurrency,
          previousState: null,
          notes: `Client money held: ${data.quantity} tokens of ${asset.name} at ${parseFloat(pricePerToken).toFixed(2)} per token`,
          proofDocumentUrl: null,
          advancedBy: null,
          advancedAt: null,
          metadata: { assetSymbol: asset.symbol, tokens: data.quantity, pricePerToken },
          createdAt: now,
        });
        await storage.createSettlementEntry({
          assetId: data.assetId,
          roundId: data.roundId,
          userId,
          walletTransactionId: result.reserveTx?.id || null,
          paymentIntentId: null,
          referenceId: refId,
          state: "SETTLEMENT_INITIATED",
          amount: totalCost,
          currency: baseCurrency,
          previousState: "CLIENT_MONEY_HELD",
          notes: `Settlement initiated: funds captured for ${asset.name} investment`,
          proofDocumentUrl: null,
          advancedBy: null,
          advancedAt: now,
          metadata: { assetSymbol: asset.symbol, tokens: data.quantity, pricePerToken },
          createdAt: now,
        });
      } catch (settlementErr) {
        console.warn("Settlement journal creation failed (non-blocking):", (settlementErr as any).message?.slice(0, 100));
      }

      let tokenIssuanceTriggered = false;
      try {
        const issuanceResult = await checkAndTriggerAutoIssuance(data.roundId, userId);
        if (issuanceResult?.success) {
          tokenIssuanceTriggered = true;
          console.log(`Auto token issuance triggered for round ${data.roundId}: ${issuanceResult.issuanceId}`);
        }
      } catch (issuanceErr) {
        console.warn("Auto token issuance check failed (non-blocking):", (issuanceErr as any).message?.slice(0, 100));
      }

      res.json({
        success: true,
        tokenIssuanceTriggered,
        investment: {
          assetId: data.assetId,
          assetName: asset.name,
          assetSymbol: asset.symbol,
          quantity: data.quantity,
          pricePerToken: parseFloat(pricePerToken),
          totalCost: parseFloat(totalCost),
          currency: baseCurrency,
          referenceId: refId,
          portfolioItem: result.portfolioItem,
          fxConversion: fxConversionResult ? {
            sourceCurrency: data.sourceCurrency,
            fxReferenceId: fxConversionResult.referenceId,
            fxLedgerTxId: fxConversionResult.ledgerTxId,
          } : undefined,
        },
      });
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Invest error:", err);
      res.status(500).json({ message: "Failed to process investment" });
    }
  });

  app.get("/api/invest/check/:assetId", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const asset = await storage.getAsset(req.params.assetId as string);
      if (!asset) return res.status(404).json({ message: "Asset not found" });

      const baseCurrency = asset.baseCurrency;
      const walletAccount = await storage.getWalletAccountByUserAndCurrency(userId, baseCurrency);
      let availableBalance = "0";
      if (walletAccount) {
        const balance = await storage.getComputedBalance(walletAccount.id);
        availableBalance = balance.available;
      }

      const userAccounts = await storage.getWalletAccountsByUser(userId);
      const otherBalances: { currency: string; available: number; fxRate?: number; fxSpread?: number; fxProvider?: string }[] = [];
      for (const acc of userAccounts) {
        if (acc.currency !== baseCurrency) {
          const bal = await storage.getComputedBalance(acc.id);
          if (decimalCompare(bal.available, "0") > 0) {
            const entry: { currency: string; available: number; fxRate?: number; fxSpread?: number; fxProvider?: string } = {
              currency: acc.currency,
              available: parseFloat(bal.available),
            };
            try {
              const fxQuote = await getFxQuote(acc.currency, baseCurrency, 1);
              if (fxQuote) {
                entry.fxRate = fxQuote.rate;
                entry.fxSpread = fxQuote.spread;
                entry.fxProvider = fxQuote.sourceLabel;
              }
            } catch {}
            otherBalances.push(entry);
          }
        }
      }

      const minInvestment = asset.minInvestment ? parseFloat(asset.minInvestment) : null;
      const maxInvestment = asset.maxInvestment ? parseFloat(asset.maxInvestment) : null;
      const ppt = parseFloat(asset.pricePerToken);
      const minTokens = minInvestment && ppt > 0 ? minInvestment / ppt : null;
      const maxTokens = maxInvestment && ppt > 0 ? maxInvestment / ppt : null;

      const maxOwnershipPercent = asset.maxOwnershipPercent ? parseFloat(asset.maxOwnershipPercent) : null;
      let currentOwnershipPercent: number | null = null;
      let maxOwnershipTokens: number | null = null;
      let remainingOwnershipCapacity: number | null = null;
      if (maxOwnershipPercent && maxOwnershipPercent > 0) {
        const totalSupply = parseFloat(asset.totalSupply);
        if (totalSupply > 0) {
          const portfolio = await storage.getPortfolioItem(userId, req.params.assetId as string);
          const currentTokens = portfolio ? parseFloat(portfolio.quantity) : 0;
          currentOwnershipPercent = parseFloat(((currentTokens / totalSupply) * 100).toFixed(2));
          maxOwnershipTokens = parseFloat(((maxOwnershipPercent / 100) * totalSupply).toFixed(asset.tokenDecimals ?? 2));
          remainingOwnershipCapacity = parseFloat(Math.max(0, maxOwnershipTokens - currentTokens).toFixed(asset.tokenDecimals ?? 2));
        }
      }

      res.json({
        baseCurrency,
        availableBalance: parseFloat(availableBalance),
        hasWallet: !!walletAccount,
        pricePerToken: ppt,
        tokenDecimals: asset.tokenDecimals ?? 2,
        totalSupply: parseFloat(asset.totalSupply),
        totalPropertyValue: asset.totalPropertyValue ? parseFloat(asset.totalPropertyValue) : null,
        minInvestment,
        maxInvestment,
        minTokens: minTokens !== null ? parseFloat(minTokens.toFixed(asset.tokenDecimals ?? 2)) : null,
        maxTokens: maxTokens !== null ? parseFloat(maxTokens.toFixed(asset.tokenDecimals ?? 2)) : null,
        maxOwnershipPercent,
        currentOwnershipPercent,
        maxOwnershipTokens,
        remainingOwnershipCapacity,
        otherBalances,
      });
    } catch (err: any) {
      console.error("Invest check error:", err);
      res.status(500).json({ message: "Failed to check investment eligibility" });
    }
  });

  app.get("/api/investor/eligibility/:assetId", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const asset = await storage.getAsset(req.params.assetId as string);
      if (!asset) return res.status(404).json({ message: "Asset not found" });

      const user = await storage.getUser(userId);
      if (!user) return res.status(404).json({ message: "User not found" });

      interface EligibilityCheck {
        check: string;
        passed: boolean;
        reason?: string;
        code?: string;
        details?: Record<string, unknown>;
      }

      const checks: EligibilityCheck[] = [];

      const kycApproved = ["approved", "APPROVED"].includes(user.kycStatus);
      checks.push(kycApproved
        ? { check: "kyc_status", passed: true }
        : { check: "kyc_status", passed: false, reason: `KYC status is '${user.kycStatus}' — must be approved`, code: "KYC_NOT_APPROVED" }
      );

      const userCountry = (user as any).countryOfResidence || user.nationality || (user as any).taxResidency || null;

      if (userCountry) {
        const sanctioned = isSanctionedCountry(userCountry);
        checks.push(sanctioned
          ? { check: "sanctions_screening", passed: false, reason: "Country of residence is on the sanctions list", code: "SANCTIONED_RESIDENCE", details: { country: userCountry } }
          : { check: "sanctions_screening", passed: true }
        );
      } else {
        checks.push({ check: "sanctions_screening", passed: false, reason: "Country of residence must be set", code: "NO_COUNTRY" });
      }

      if (user.nationality) {
        const blocked = isBlockedNationality(user.nationality);
        checks.push(blocked
          ? { check: "nationality_screening", passed: false, reason: "Nationality is on the blocked list", code: "BLOCKED_NATIONALITY", details: { nationality: user.nationality } }
          : { check: "nationality_screening", passed: true }
        );
      } else {
        checks.push({ check: "nationality_screening", passed: true });
      }

      const assetEligible = asset.eligibleCountries || [];
      const assetRestricted = asset.restrictedCountries || [];

      if (userCountry) {
        if (assetEligible.length > 0 && !assetEligible.includes(userCountry)) {
          const eligibleNames = assetEligible.map(c => (COUNTRY_DETAILS as any)[c]?.name || c).join(", ");
          checks.push({
            check: "asset_geo_eligible",
            passed: false,
            reason: `This asset is only available to investors in: ${eligibleNames}`,
            code: "ASSET_GEO_NOT_ELIGIBLE",
            details: { userCountry, eligibleCountries: assetEligible },
          });
        } else if (assetRestricted.length > 0 && assetRestricted.includes(userCountry)) {
          const countryName = (COUNTRY_DETAILS as any)[userCountry]?.name || userCountry;
          checks.push({
            check: "asset_geo_eligible",
            passed: false,
            reason: `This asset is restricted for investors in ${countryName}`,
            code: "ASSET_GEO_RESTRICTED",
            details: { userCountry, restrictedCountries: assetRestricted },
          });
        } else {
          checks.push({ check: "asset_geo_eligible", passed: true });
        }
      } else {
        checks.push({ check: "asset_geo_eligible", passed: false, reason: "Country of residence must be set to verify geo eligibility", code: "NO_COUNTRY" });
      }

      const policyCtx = await buildPolicyContext(userId);
      const investPolicy = canInvest(
        policyCtx,
        (asset as any).minInvestorType as InvestorType | undefined,
      );
      checks.push(investPolicy.allowed
        ? { check: "investment_policy", passed: true }
        : { check: "investment_policy", passed: false, reason: investPolicy.reason || "Policy denied", code: investPolicy.code, details: investPolicy.details }
      );

      const eddStatus = user.eddStatus ?? "none";
      const { investorPolicy } = getEffectivePolicy(policyCtx);
      if (investorPolicy?.requiresEdd) {
        const eddCompleted = ["completed", "COMPLETED"].includes(eddStatus);
        checks.push(eddCompleted
          ? { check: "edd_status", passed: true }
          : { check: "edd_status", passed: false, reason: "Enhanced Due Diligence must be completed for your investor type", code: "EDD_NOT_COMPLETED" }
        );
      } else {
        checks.push({ check: "edd_status", passed: true });
      }

      let vehicleType = "GENERAL";
      if (asset.vehicleId) {
        const vehicle = await storage.getInvestmentVehicle(asset.vehicleId);
        if (vehicle) vehicleType = vehicle.type;
      }
      const requiredDocs = await storage.getRequiredDocsForInvestment(asset.country, vehicleType);
      const { allAccepted, pending } = await storage.hasAcceptedAllRequiredDocs(userId, requiredDocs);
      checks.push(allAccepted
        ? { check: "legal_documents", passed: true }
        : {
            check: "legal_documents",
            passed: false,
            reason: `${pending.length} required legal document(s) must be accepted`,
            code: "LEGAL_NOT_ACCEPTED",
            details: { pendingCount: pending.length, pendingDocs: pending.map(d => d.title) },
          }
      );

      if (asset.status !== "active") {
        checks.push({
          check: "asset_status",
          passed: false,
          reason: `Asset is currently '${asset.status}' and not open for investment`,
          code: "ASSET_NOT_ACTIVE",
        });
      } else {
        checks.push({ check: "asset_status", passed: true });
      }

      const eligible = checks.every(c => c.passed);

      const countryPolicy = userCountry ? getPolicy(userCountry) : null;

      res.json({
        eligible,
        checks,
        summary: {
          assetName: asset.name,
          assetCountry: asset.country,
          investorCountry: userCountry,
          investorType: policyCtx.investorType,
          kycStatus: user.kycStatus,
          eddStatus,
          countryPolicyNotes: countryPolicy?.notes || [],
        },
      });
    } catch (err: any) {
      console.error("Eligibility check error:", err);
      res.status(500).json({ message: "Failed to check eligibility" });
    }
  });
}
