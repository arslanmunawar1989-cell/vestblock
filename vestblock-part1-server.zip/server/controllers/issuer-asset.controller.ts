import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole, type JwtPayload } from "../auth";
import { issuerSubmitAssetSchema, adminReviewAssetSchema } from "@shared/schema";
import { JURISDICTION_DOCS, COUNTRY_TO_CURRENCY, CURRENCY_TO_COUNTRY } from "@shared/constants";
import type { CountryCode } from "@shared/constants";

export function registerIssuerAssetRoutes(app: Express) {
  app.get("/api/issuer/assets", requireAuth, requireRole("issuer"), async (req, res) => {
    try {
      const jwt = (req as any).user as JwtPayload;
      const assets = await storage.getAssetsByIssuer(jwt.userId);
      res.json(assets);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch issuer assets" });
    }
  });

  app.post("/api/issuer/assets", requireAuth, requireRole("issuer"), async (req, res) => {
    try {
      const jwt = (req as any).user as JwtPayload;
      const user = await storage.getUser(jwt.userId);
      if (!user) return res.status(401).json({ error: "User not found" });

      const parsed = issuerSubmitAssetSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Validation failed", details: parsed.error.flatten() });
      }

      const data = parsed.data;
      const country = data.country as CountryCode;
      const requiredDocs = JURISDICTION_DOCS[country] || [];
      const checklist = data.jurisdictionChecklist || {};

      const missingRequired = requiredDocs
        .filter(d => d.required && !checklist[d.key])
        .map(d => d.label);

      const asset = await storage.createAsset({
        name: data.name,
        symbol: data.symbol,
        assetType: data.assetType,
        description: data.description,
        totalSupply: data.totalSupply,
        pricePerToken: data.pricePerToken,
        baseCurrency: data.baseCurrency,
        country: data.country,
        location: data.location || null,
        propertyType: data.propertyType || null,
        annualYield: data.annualYield || null,
        legalStructure: data.legalStructure || null,
        regulatoryBody: data.regulatoryBody || null,
        minInvestment: data.minInvestment || null,
        maxOwnershipPercent: data.maxOwnershipPercent || null,
        issuerId: user.id,
        issuerName: user.fullName,
        jurisdictionChecklist: checklist,
        submissionStatus: missingRequired.length > 0 ? "draft" : "submitted",
        submittedAt: missingRequired.length > 0 ? null : new Date().toISOString(),
        status: "pending",
      });

      res.status(201).json({
        asset,
        missingRequired,
        message: missingRequired.length > 0
          ? `Asset saved as draft. Missing required documents: ${missingRequired.join(", ")}`
          : "Asset submitted for admin review",
      });
    } catch (err) {
      console.error("Error creating issuer asset:", err);
      res.status(500).json({ error: "Failed to create asset" });
    }
  });

  app.patch("/api/issuer/assets/:id", requireAuth, requireRole("issuer"), async (req, res) => {
    try {
      const jwt = (req as any).user as JwtPayload;
      const asset = await storage.getAsset(String(req.params.id));
      if (!asset) return res.status(404).json({ error: "Asset not found" });
      if (asset.issuerId !== jwt.userId) return res.status(403).json({ error: "Not your asset" });
      if (asset.submissionStatus === "approved") return res.status(400).json({ error: "Cannot edit an approved asset" });

      const parsed = issuerSubmitAssetSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Validation failed", details: parsed.error.flatten() });
      }

      const data = parsed.data;
      const country = data.country as CountryCode;
      const requiredDocs = JURISDICTION_DOCS[country] || [];
      const checklist = data.jurisdictionChecklist || {};

      const missingRequired = requiredDocs
        .filter(d => d.required && !checklist[d.key])
        .map(d => d.label);

      const updated = await storage.updateAsset(String(req.params.id), {
        name: data.name,
        symbol: data.symbol,
        assetType: data.assetType,
        description: data.description,
        totalSupply: data.totalSupply,
        pricePerToken: data.pricePerToken,
        baseCurrency: data.baseCurrency,
        country: data.country,
        location: data.location || null,
        propertyType: data.propertyType || null,
        annualYield: data.annualYield || null,
        legalStructure: data.legalStructure || null,
        regulatoryBody: data.regulatoryBody || null,
        minInvestment: data.minInvestment || null,
        maxOwnershipPercent: data.maxOwnershipPercent || null,
        jurisdictionChecklist: checklist,
        submissionStatus: missingRequired.length > 0 ? "draft" : "submitted",
        submittedAt: missingRequired.length > 0 ? null : new Date().toISOString(),
      });

      res.json({ asset: updated, missingRequired });
    } catch (err) {
      res.status(500).json({ error: "Failed to update asset" });
    }
  });

  app.get("/api/issuer/jurisdiction-docs/:country", requireAuth, async (req, res) => {
    const country = String(String(req.params.country)) as CountryCode;
    const docs = JURISDICTION_DOCS[country];
    if (!docs) return res.status(404).json({ error: "Country not supported" });
    res.json(docs);
  });

  app.get("/api/admin/asset-submissions", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const allAssets = await storage.getAssets(req.tenantId);
      const submissions = allAssets.filter(a => a.submissionStatus && a.submissionStatus !== "active");

      const enriched = await Promise.all(
        submissions.map(async (asset) => {
          const issuer = await storage.getUser(asset.issuerId);
          const country = asset.country as CountryCode;
          const requiredDocs = JURISDICTION_DOCS[country] || [];
          const checklist = (asset.jurisdictionChecklist || {}) as Record<string, boolean>;
          const completedCount = requiredDocs.filter(d => checklist[d.key]).length;
          const requiredCount = requiredDocs.filter(d => d.required).length;
          const completedRequiredCount = requiredDocs.filter(d => d.required && checklist[d.key]).length;

          return {
            ...asset,
            issuerFullName: issuer?.fullName || "Unknown",
            issuerEmail: issuer?.email || "",
            jurisdictionDocs: requiredDocs,
            checklistSummary: {
              total: requiredDocs.length,
              completed: completedCount,
              requiredTotal: requiredCount,
              requiredCompleted: completedRequiredCount,
            },
          };
        })
      );

      res.json(enriched);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch submissions" });
    }
  });

  app.patch("/api/admin/asset-submissions/:id/review", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const parsed = adminReviewAssetSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Validation failed", details: parsed.error.flatten() });
      }

      const asset = await storage.getAsset(String(req.params.id));
      if (!asset) return res.status(404).json({ error: "Asset not found" });

      const updateData: any = {
        submissionStatus: parsed.data.submissionStatus,
        adminReviewNotes: parsed.data.adminReviewNotes || null,
        reviewedAt: new Date().toISOString(),
      };

      if (parsed.data.submissionStatus === "approved") {
        updateData.status = "active";
      }

      const updated = await storage.updateAsset(String(req.params.id), updateData);

      if (updated) {
        const notification = {
          userId: asset.issuerId,
          type: "asset_review",
          title: parsed.data.submissionStatus === "approved"
            ? `Asset "${asset.name}" Approved`
            : parsed.data.submissionStatus === "rejected"
              ? `Asset "${asset.name}" Rejected`
              : `Changes Requested for "${asset.name}"`,
          message: parsed.data.adminReviewNotes || `Your asset submission has been ${parsed.data.submissionStatus}.`,
          isRead: false,
        };
        await storage.createNotification(notification);
      }

      res.json(updated);
    } catch (err) {
      res.status(500).json({ error: "Failed to review asset" });
    }
  });
}
