import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { db } from "../db";
import { auditLogs } from "@shared/schema";
import { sql } from "drizzle-orm";

function toCsv(headers: string[], rows: string[][]): string {
  const escape = (v: string) => {
    if (v.includes(",") || v.includes('"') || v.includes("\n")) {
      return `"${v.replace(/"/g, '""')}"`;
    }
    return v;
  };
  return [headers.map(escape).join(","), ...rows.map(r => r.map(escape).join(","))].join("\n");
}

export function registerAuditLogRoutes(app: Express) {
  app.get("/api/admin/audit-logs", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const {
        actorId,
        actionType,
        entityType,
        entityId,
        from,
        to,
        search,
        limit: limitStr,
        offset: offsetStr,
      } = req.query;

      const filters = {
        actorId: actorId as string | undefined,
        actionType: actionType as string | undefined,
        entityType: entityType as string | undefined,
        entityId: entityId as string | undefined,
        from: from as string | undefined,
        to: to as string | undefined,
        search: search as string | undefined,
        limit: limitStr ? parseInt(limitStr as string, 10) : 50,
        offset: offsetStr ? parseInt(offsetStr as string, 10) : 0,
      };

      const result = await storage.searchAuditLogs(filters);

      const enriched = await Promise.all(result.logs.map(async (log) => {
        const actor = await storage.getUser(log.actorId);
        return {
          ...log,
          actorName: actor?.fullName || actor?.username || log.actorId,
          actorEmail: actor?.email || "",
        };
      }));

      res.json({
        logs: enriched,
        total: result.total,
        limit: filters.limit,
        offset: filters.offset,
      });
    } catch (err: any) {
      console.error("Audit log search error:", err);
      res.status(500).json({ message: "Failed to search audit logs" });
    }
  });

  app.get("/api/admin/audit-logs/action-types", requireAuth, requireRole("admin"), async (_req, res) => {
    try {
      const result = await db.selectDistinct({ actionType: auditLogs.actionType }).from(auditLogs);
      res.json(result.map(r => r.actionType).sort());
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch action types" });
    }
  });

  app.get("/api/admin/audit-logs/entity-types", requireAuth, requireRole("admin"), async (_req, res) => {
    try {
      const result = await db.selectDistinct({ entityType: auditLogs.entityType }).from(auditLogs);
      res.json(result.map(r => r.entityType).sort());
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch entity types" });
    }
  });

  app.get("/api/admin/audit-logs/stats", requireAuth, requireRole("admin"), async (_req, res) => {
    try {
      const [totalResult] = await db.select({ count: sql<number>`count(*)::int` }).from(auditLogs);
      const today = new Date().toISOString().split("T")[0];
      const [todayResult] = await db.select({ count: sql<number>`count(*)::int` }).from(auditLogs)
        .where(sql`${auditLogs.createdAt} >= ${today}`);

      res.json({
        totalLogs: totalResult?.count || 0,
        todayLogs: todayResult?.count || 0,
      });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch audit stats" });
    }
  });

  app.get("/api/admin/audit-logs/export", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const { actorId, actionType, entityType, entityId, from, to, search } = req.query;
      const result = await storage.searchAuditLogs({
        actorId: actorId as string | undefined,
        actionType: actionType as string | undefined,
        entityType: entityType as string | undefined,
        entityId: entityId as string | undefined,
        from: from as string | undefined,
        to: to as string | undefined,
        search: search as string | undefined,
        limit: 10000,
        offset: 0,
      });

      const headers = ["ID", "Date", "Actor ID", "Actor Role", "Action", "Entity Type", "Entity ID", "Reason", "IP Address", "Before State", "After State"];
      const rows = await Promise.all(result.logs.map(async (log) => {
        const actor = await storage.getUser(log.actorId);
        return [
          log.id,
          log.createdAt ? new Date(log.createdAt).toISOString() : "",
          actor?.fullName || actor?.username || log.actorId,
          log.actorRole || "",
          log.actionType,
          log.entityType,
          log.entityId || "",
          log.reason || "",
          log.ipAddress || "",
          log.beforeState ? JSON.stringify(log.beforeState) : "",
          log.afterState ? JSON.stringify(log.afterState) : "",
        ];
      }));

      const csv = toCsv(headers, rows);
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="audit_logs_${new Date().toISOString().split("T")[0]}.csv"`);
      res.send(csv);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to export audit logs" });
    }
  });
}
