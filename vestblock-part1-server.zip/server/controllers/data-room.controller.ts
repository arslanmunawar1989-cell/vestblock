import type { Express } from "express";
import { requireAuth } from "../auth";
import { db } from "../db";
import { dataRoomDocuments, createDataRoomDocSchema, updateDataRoomDocSchema, assets, offerings, tokens, tokenHoldings, propertyUnitLedger, propertyUnits, DEFAULT_TIER_THRESHOLDS, DATA_ROOM_ACCESS_TIER_ORDER } from "@shared/schema";
import type { DataRoomAccessTier } from "@shared/schema";
import { getAssetChecklist, getOfferingChecklist } from "@shared/data-room-policy";
import { eq, and, desc, gt, sql } from "drizzle-orm";

async function getInvestorInvestmentAmount(userId: string, assetId: string): Promise<{ invested: boolean; amount: number }> {
  const [asset] = await db.select().from(assets).where(eq(assets.id, assetId)).limit(1);
  if (!asset) return { invested: false, amount: 0 };

  let totalAmount = 0;
  let invested = false;
  const pricePerToken = parseFloat(asset.pricePerToken) || 0;

  if (asset.vehicleId) {
    const vehicleTokens = await db.select({ id: tokens.id })
      .from(tokens)
      .where(eq(tokens.vehicleId, asset.vehicleId));

    for (const token of vehicleTokens) {
      const holdings = await db.select()
        .from(tokenHoldings)
        .where(and(
          eq(tokenHoldings.userId, userId),
          eq(tokenHoldings.tokenId, token.id),
          gt(tokenHoldings.balance, "0")
        ));
      for (const h of holdings) {
        const balance = parseFloat(h.balance) || 0;
        totalAmount += balance * pricePerToken;
        if (balance > 0) invested = true;
      }
    }
  }

  const units = await db.select({ id: propertyUnits.id, unitPrice: propertyUnits.unitPrice })
    .from(propertyUnits)
    .where(eq(propertyUnits.assetId, assetId));

  for (const unit of units) {
    const ledger = await db.select()
      .from(propertyUnitLedger)
      .where(and(
        eq(propertyUnitLedger.propertyUnitId, unit.id),
        eq(propertyUnitLedger.userId, userId),
        eq(propertyUnitLedger.direction, "CREDIT")
      ));
    for (const entry of ledger) {
      const qty = parseFloat(entry.quantity) || 0;
      const unitPrice = parseFloat(unit.unitPrice) || pricePerToken;
      totalAmount += qty * unitPrice;
      if (qty > 0) invested = true;
    }
  }

  return { invested, amount: totalAmount };
}

function getAssetTierThresholds(asset: any): Record<DataRoomAccessTier, number> {
  if (asset.dataRoomTierThresholds && typeof asset.dataRoomTierThresholds === "object") {
    return { ...DEFAULT_TIER_THRESHOLDS, ...(asset.dataRoomTierThresholds as Record<string, number>) };
  }
  return { ...DEFAULT_TIER_THRESHOLDS };
}

function computeTierFromAmount(amount: number, thresholds: Record<DataRoomAccessTier, number>): DataRoomAccessTier {
  const tiers: DataRoomAccessTier[] = ["confidential", "qualified", "standard", "public"];
  for (const tier of tiers) {
    if (amount >= (thresholds[tier] || 0)) return tier;
  }
  return "public";
}

async function isInvestorInProperty(userId: string, assetId: string): Promise<boolean> {
  const result = await getInvestorInvestmentAmount(userId, assetId);
  return result.invested;
}

export function registerDataRoomRoutes(app: Express) {
  app.get("/api/data-room/assets/:assetId/docs", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      const assetId = String(req.params.assetId);

      const [asset] = await db.select().from(assets).where(eq(assets.id, assetId)).limit(1);
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }

      if (user.role === "investor") {
        const { invested, amount } = await getInvestorInvestmentAmount(user.userId, assetId);
        if (!invested) {
          return res.status(403).json({ message: "You must be an investor in this property to view its data room" });
        }

        const thresholds = getAssetTierThresholds(asset);
        const investorTier = computeTierFromAmount(amount, thresholds);
        const investorTierOrder = DATA_ROOM_ACCESS_TIER_ORDER[investorTier];

        const allDocs = await db.select().from(dataRoomDocuments)
          .where(and(
            eq(dataRoomDocuments.assetId, assetId),
            eq(dataRoomDocuments.scope, "asset"),
            eq(dataRoomDocuments.status, "live")
          ))
          .orderBy(desc(dataRoomDocuments.createdAt));

        const accessible = allDocs.filter(d => DATA_ROOM_ACCESS_TIER_ORDER[(d.accessTier as DataRoomAccessTier) || "public"] <= investorTierOrder);
        const locked = allDocs
          .filter(d => DATA_ROOM_ACCESS_TIER_ORDER[(d.accessTier as DataRoomAccessTier) || "public"] > investorTierOrder)
          .map(d => ({ id: d.id, title: d.title, accessTier: d.accessTier, category: d.category, docType: d.docType }));

        return res.json({
          docs: accessible,
          lockedDocs: locked,
          investorTier,
          investedAmount: amount,
          thresholds,
        });
      }

      const docs = await db.select().from(dataRoomDocuments)
        .where(and(
          eq(dataRoomDocuments.assetId, assetId),
          eq(dataRoomDocuments.scope, "asset")
        ))
        .orderBy(desc(dataRoomDocuments.createdAt));
      res.json({ docs, lockedDocs: [], investorTier: "confidential", investedAmount: 0, thresholds: getAssetTierThresholds(asset) });
    } catch (err: any) {
      res.status(500).json({ message: err.message || "Failed to fetch data room documents" });
    }
  });

  app.get("/api/data-room/offerings/:offeringId/docs", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      const offeringId = String(req.params.offeringId);

      const [offering] = await db.select().from(offerings).where(eq(offerings.id, offeringId)).limit(1);
      if (!offering) {
        return res.status(404).json({ message: "Offering not found" });
      }

      if (user.role === "investor") {
        if (offering.status !== "OPEN" && offering.status !== "FUNDED") {
          return res.status(403).json({ message: "Data room not available for this offering" });
        }
        const docs = await db.select().from(dataRoomDocuments)
          .where(and(
            eq(dataRoomDocuments.offeringId, offeringId),
            eq(dataRoomDocuments.scope, "offering"),
            eq(dataRoomDocuments.status, "live")
          ))
          .orderBy(desc(dataRoomDocuments.createdAt));
        return res.json(docs);
      }

      const docs = await db.select().from(dataRoomDocuments)
        .where(and(
          eq(dataRoomDocuments.offeringId, offeringId),
          eq(dataRoomDocuments.scope, "offering")
        ))
        .orderBy(desc(dataRoomDocuments.createdAt));
      res.json(docs);
    } catch (err: any) {
      res.status(500).json({ message: err.message || "Failed to fetch offering data room documents" });
    }
  });

  app.get("/api/data-room/checklist/asset/:assetId", requireAuth, async (req, res) => {
    try {
      const assetId = String(req.params.assetId);
      const [asset] = await db.select().from(assets).where(eq(assets.id, assetId)).limit(1);
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }

      const checklist = getAssetChecklist(asset.country);
      const docs = await db.select().from(dataRoomDocuments)
        .where(and(
          eq(dataRoomDocuments.assetId, assetId),
          eq(dataRoomDocuments.scope, "asset")
        ));

      const uploadedKeys = new Set(docs.filter(d => d.checklistKey).map(d => d.checklistKey));
      const items = checklist.map(item => ({
        ...item,
        uploaded: uploadedKeys.has(item.key),
        document: docs.find(d => d.checklistKey === item.key) || null,
      }));

      const totalRequired = checklist.filter(i => i.required).length;
      const completedRequired = items.filter(i => i.required && i.uploaded).length;

      res.json({
        country: asset.country,
        assetId,
        items,
        totalRequired,
        completedRequired,
        complete: completedRequired >= totalRequired,
      });
    } catch (err: any) {
      res.status(500).json({ message: err.message || "Failed to fetch checklist" });
    }
  });

  app.get("/api/data-room/checklist/offering/:offeringId", requireAuth, async (req, res) => {
    try {
      const offeringId = String(req.params.offeringId);
      const [offering] = await db.select().from(offerings).where(eq(offerings.id, offeringId)).limit(1);
      if (!offering) {
        return res.status(404).json({ message: "Offering not found" });
      }

      const assetResults = await db.select().from(assets).limit(1);
      const country = assetResults[0]?.country || "AE";

      const checklist = getOfferingChecklist(country);
      const docs = await db.select().from(dataRoomDocuments)
        .where(and(
          eq(dataRoomDocuments.offeringId, offeringId),
          eq(dataRoomDocuments.scope, "offering")
        ));

      const uploadedKeys = new Set(docs.filter(d => d.checklistKey).map(d => d.checklistKey));
      const items = checklist.map(item => ({
        ...item,
        uploaded: uploadedKeys.has(item.key),
        document: docs.find(d => d.checklistKey === item.key) || null,
      }));

      const totalRequired = checklist.filter(i => i.required).length;
      const completedRequired = items.filter(i => i.required && i.uploaded).length;

      res.json({
        country,
        offeringId,
        items,
        totalRequired,
        completedRequired,
        complete: completedRequired >= totalRequired,
      });
    } catch (err: any) {
      res.status(500).json({ message: err.message || "Failed to fetch offering checklist" });
    }
  });

  app.post("/api/data-room/docs", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can upload data room documents" });
      }

      const parsed = createDataRoomDocSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Validation failed", errors: parsed.error.flatten() });
      }

      const data = parsed.data;
      if (data.scope === "asset" && !data.assetId) {
        return res.status(400).json({ message: "assetId is required for asset-scoped documents" });
      }
      if (data.scope === "offering" && !data.offeringId) {
        return res.status(400).json({ message: "offeringId is required for offering-scoped documents" });
      }

      if (data.assetId) {
        const [asset] = await db.select().from(assets).where(eq(assets.id, data.assetId)).limit(1);
        if (!asset) return res.status(404).json({ message: "Asset not found" });
        if (!data.jurisdiction) data.jurisdiction = asset.country;
      }

      const [doc] = await db.insert(dataRoomDocuments).values({
        ...data,
        uploadedBy: user.userId,
      }).returning();

      res.status(201).json(doc);
    } catch (err: any) {
      res.status(500).json({ message: err.message || "Failed to create data room document" });
    }
  });

  app.patch("/api/data-room/docs/:id", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can update data room documents" });
      }

      const parsed = updateDataRoomDocSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Validation failed", errors: parsed.error.flatten() });
      }

      const [doc] = await db.update(dataRoomDocuments)
        .set({ ...parsed.data, updatedAt: new Date().toISOString() })
        .where(eq(dataRoomDocuments.id, String(String(req.params.id))))
        .returning();

      if (!doc) {
        return res.status(404).json({ message: "Document not found" });
      }
      res.json(doc);
    } catch (err: any) {
      res.status(500).json({ message: err.message || "Failed to update document" });
    }
  });

  app.delete("/api/data-room/docs/:id", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can delete data room documents" });
      }

      const [doc] = await db.delete(dataRoomDocuments)
        .where(eq(dataRoomDocuments.id, String(String(req.params.id))))
        .returning();

      if (!doc) {
        return res.status(404).json({ message: "Document not found" });
      }
      res.json({ message: "Document deleted", id: doc.id });
    } catch (err: any) {
      res.status(500).json({ message: err.message || "Failed to delete document" });
    }
  });

  app.get("/api/data-room/investor/properties", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "investor") {
        return res.status(403).json({ message: "Investor access required" });
      }

      const allAssets = await db.select().from(assets);
      const investorAssets = [];

      for (const asset of allAssets) {
        const { invested, amount } = await getInvestorInvestmentAmount(user.userId, asset.id);
        if (invested) {
          const thresholds = getAssetTierThresholds(asset);
          const tier = computeTierFromAmount(amount, thresholds);
          const allDocs = await db.select()
            .from(dataRoomDocuments)
            .where(and(
              eq(dataRoomDocuments.assetId, asset.id),
              eq(dataRoomDocuments.scope, "asset"),
              eq(dataRoomDocuments.status, "live")
            ));
          const tierOrder = DATA_ROOM_ACCESS_TIER_ORDER[tier];
          const accessibleCount = allDocs.filter(d => DATA_ROOM_ACCESS_TIER_ORDER[(d.accessTier as DataRoomAccessTier) || "public"] <= tierOrder).length;
          const lockedCount = allDocs.length - accessibleCount;
          investorAssets.push({
            id: asset.id,
            name: asset.name,
            symbol: asset.symbol,
            country: asset.country,
            status: asset.status,
            imageUrl: asset.imageUrl,
            documentCount: accessibleCount,
            lockedCount,
            totalDocuments: allDocs.length,
            investorTier: tier,
            investedAmount: amount,
            baseCurrency: asset.baseCurrency,
          });
        }
      }

      res.json(investorAssets);
    } catch (err: any) {
      res.status(500).json({ message: err.message || "Failed to fetch investor properties" });
    }
  });

  app.get("/api/data-room/all", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Admin or issuer access required" });
      }

      const { assetId, scope, status } = req.query;
      let conditions = [];
      if (assetId) conditions.push(eq(dataRoomDocuments.assetId, assetId as string));
      if (scope) conditions.push(eq(dataRoomDocuments.scope, scope as string));
      if (status) conditions.push(eq(dataRoomDocuments.status, status as string));

      const docs = conditions.length > 0
        ? await db.select().from(dataRoomDocuments).where(and(...conditions)).orderBy(desc(dataRoomDocuments.createdAt))
        : await db.select().from(dataRoomDocuments).orderBy(desc(dataRoomDocuments.createdAt));

      res.json(docs);
    } catch (err: any) {
      res.status(500).json({ message: err.message || "Failed to fetch documents" });
    }
  });

  app.get("/api/data-room/assets/:assetId/tier-thresholds", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Admin or issuer access required" });
      }
      const assetId = String(req.params.assetId);
      const [asset] = await db.select().from(assets).where(eq(assets.id, assetId)).limit(1);
      if (!asset) return res.status(404).json({ message: "Asset not found" });

      res.json({
        assetId,
        assetName: asset.name,
        thresholds: getAssetTierThresholds(asset),
      });
    } catch (err: any) {
      res.status(500).json({ message: err.message || "Failed to fetch tier thresholds" });
    }
  });

  app.put("/api/data-room/assets/:assetId/tier-thresholds", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Admin access required" });
      }
      const assetId = String(req.params.assetId);
      const [asset] = await db.select().from(assets).where(eq(assets.id, assetId)).limit(1);
      if (!asset) return res.status(404).json({ message: "Asset not found" });

      const { thresholds } = req.body;
      if (!thresholds || typeof thresholds !== "object") {
        return res.status(400).json({ message: "Thresholds object is required" });
      }

      const validTiers = ["public", "standard", "qualified", "confidential"];
      const sanitized: Record<string, number> = {};
      for (const tier of validTiers) {
        if (tier in thresholds) {
          const val = Number(thresholds[tier]);
          if (isNaN(val) || val < 0) {
            return res.status(400).json({ message: `Invalid threshold for ${tier}` });
          }
          sanitized[tier] = val;
        }
      }

      const [updated] = await db.update(assets)
        .set({ dataRoomTierThresholds: sanitized })
        .where(eq(assets.id, assetId))
        .returning();

      res.json({
        assetId,
        assetName: updated.name,
        thresholds: getAssetTierThresholds(updated),
      });
    } catch (err: any) {
      res.status(500).json({ message: err.message || "Failed to update tier thresholds" });
    }
  });
}
