import type { Express } from "express";
import { requireAuth } from "../auth";
import { storage } from "../storage";
import PDFDocument from "pdfkit";

const CURRENCY_SYMBOLS: Record<string, string> = {
  AED: "AED",
  PKR: "PKR",
  GBP: "GBP",
  USD: "USD",
  QAR: "QAR",
};

const COUNTRY_NAMES: Record<string, string> = {
  AE: "United Arab Emirates",
  PK: "Pakistan",
  GB: "United Kingdom",
  US: "United States",
  QA: "Qatar",
};

function fmtAmount(amount: string, currency: string): string {
  const num = parseFloat(amount);
  const sym = CURRENCY_SYMBOLS[currency] || currency;
  return `${sym} ${num.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function fmtDate(dateStr: string | null): string {
  if (!dateStr) return "N/A";
  return new Date(dateStr).toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    timeZoneName: "short",
  });
}

export function registerReceiptRoutes(app: Express) {
  app.get("/api/payment-intents/:id/receipt", requireAuth, async (req, res) => {
    try {
      const jwtUser = (req as any).user;
      const intent = await storage.getPaymentIntent(String(String(req.params.id)));

      if (!intent) {
        return res.status(404).json({ message: "Payment intent not found" });
      }

      if (intent.userId !== jwtUser.userId && jwtUser.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }

      if (intent.status !== "CONFIRMED") {
        return res.status(400).json({ message: "Receipt is only available for confirmed deposits" });
      }

      const user = await storage.getUser(intent.userId);
      const bankInfo = await storage.getReceivingBankAccountByCurrency(intent.currency);
      const refCode = intent.referenceCode || `VB-${intent.id.slice(0, 8).toUpperCase()}`;

      const doc = new PDFDocument({
        size: "A4",
        margins: { top: 50, bottom: 50, left: 50, right: 50 },
        info: {
          Title: `Deposit Receipt - ${refCode}`,
          Author: "VestBlock",
          Subject: `Deposit Receipt ${refCode}`,
        },
      });

      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="VestBlock_Receipt_${refCode}.pdf"`);
      doc.pipe(res);

      const pageWidth = doc.page.width - doc.page.margins.left - doc.page.margins.right;
      const primaryColor = "#1a7a4c";
      const headerBg = "#f0fdf4";
      const borderColor = "#d1d5db";
      const textColor = "#111827";
      const mutedColor = "#6b7280";

      doc.rect(doc.page.margins.left - 10, 40, pageWidth + 20, 80)
        .fill(headerBg);

      doc.fontSize(22).fillColor(primaryColor).font("Helvetica-Bold")
        .text("VestBlock", doc.page.margins.left, 55);

      doc.fontSize(9).fillColor(mutedColor).font("Helvetica")
        .text("Tokenized Investment Platform", doc.page.margins.left, 82);

      doc.fontSize(16).fillColor(textColor).font("Helvetica-Bold")
        .text("DEPOSIT RECEIPT", doc.page.margins.left + pageWidth - 200, 55, { width: 200, align: "right" });

      doc.fontSize(10).fillColor(primaryColor).font("Helvetica-Bold")
        .text(refCode, doc.page.margins.left + pageWidth - 200, 78, { width: 200, align: "right" });

      doc.moveTo(doc.page.margins.left, 130)
        .lineTo(doc.page.margins.left + pageWidth, 130)
        .strokeColor(borderColor).lineWidth(1).stroke();

      let y = 145;

      doc.fontSize(11).fillColor(primaryColor).font("Helvetica-Bold")
        .text("Transaction Details", doc.page.margins.left, y);
      y += 22;

      const leftCol = doc.page.margins.left;
      const rightCol = doc.page.margins.left + 160;

      const addRow = (label: string, value: string, bold = false) => {
        doc.fontSize(10).fillColor(mutedColor).font("Helvetica")
          .text(label, leftCol, y, { width: 150 });
        doc.fontSize(10).fillColor(textColor).font(bold ? "Helvetica-Bold" : "Helvetica")
          .text(value, rightCol, y, { width: pageWidth - 160 });
        y += 20;
      };

      addRow("Reference", refCode, true);
      addRow("Status", "CONFIRMED");
      addRow("Date Created", fmtDate(intent.createdAt));
      addRow("Date Confirmed", fmtDate(intent.confirmedAt));
      addRow("Payment Method", intent.paymentMethod.replace(/_/g, " ").replace(/\b\w/g, l => l.toUpperCase()));

      y += 5;
      doc.moveTo(leftCol, y).lineTo(leftCol + pageWidth, y)
        .strokeColor(borderColor).lineWidth(0.5).stroke();
      y += 15;

      doc.fontSize(11).fillColor(primaryColor).font("Helvetica-Bold")
        .text("Amount Summary", leftCol, y);
      y += 22;

      addRow("Gross Amount", fmtAmount(intent.amount, intent.currency), true);
      addRow("Processing Fee", `- ${fmtAmount(intent.fee, intent.currency)}`);

      y += 2;
      doc.moveTo(rightCol, y).lineTo(leftCol + pageWidth, y)
        .strokeColor(borderColor).lineWidth(0.5).stroke();
      y += 10;

      doc.fontSize(12).fillColor(primaryColor).font("Helvetica-Bold")
        .text("Net Credited", leftCol, y, { width: 150 });
      doc.fontSize(12).fillColor(primaryColor).font("Helvetica-Bold")
        .text(fmtAmount(intent.netAmount, intent.currency), rightCol, y, { width: pageWidth - 160 });
      y += 25;

      y += 5;
      doc.moveTo(leftCol, y).lineTo(leftCol + pageWidth, y)
        .strokeColor(borderColor).lineWidth(0.5).stroke();
      y += 15;

      doc.fontSize(11).fillColor(primaryColor).font("Helvetica-Bold")
        .text("Account Holder", leftCol, y);
      y += 22;

      if (user) {
        addRow("Name", user.fullName || user.username);
        if (user.email) addRow("Email", user.email);
      }
      addRow("Currency", intent.currency);
      if (intent.countryCode) {
        addRow("Country", COUNTRY_NAMES[intent.countryCode] || intent.countryCode);
      }

      if (bankInfo) {
        y += 5;
        doc.moveTo(leftCol, y).lineTo(leftCol + pageWidth, y)
          .strokeColor(borderColor).lineWidth(0.5).stroke();
        y += 15;

        doc.fontSize(11).fillColor(primaryColor).font("Helvetica-Bold")
          .text("Receiving Bank Details", leftCol, y);
        y += 22;

        addRow("Bank", bankInfo.bankName);
        addRow("Account Name", bankInfo.accountName);
        if (bankInfo.iban) addRow("IBAN", bankInfo.iban);
        if (bankInfo.swiftCode) addRow("SWIFT/BIC", bankInfo.swiftCode);
        if (bankInfo.sortCode) addRow("Sort Code", bankInfo.sortCode);
        if (bankInfo.routingNumber) addRow("Routing Number", bankInfo.routingNumber);
        if (bankInfo.accountNumber) addRow("Account Number", bankInfo.accountNumber);
        if (bankInfo.branch) addRow("Branch", bankInfo.branch);
      }

      if (intent.reconciliationId) {
        y += 5;
        doc.moveTo(leftCol, y).lineTo(leftCol + pageWidth, y)
          .strokeColor(borderColor).lineWidth(0.5).stroke();
        y += 15;
        addRow("Reconciliation ID", intent.reconciliationId);
      }

      const footerY = doc.page.height - 80;
      doc.moveTo(leftCol, footerY)
        .lineTo(leftCol + pageWidth, footerY)
        .strokeColor(borderColor).lineWidth(0.5).stroke();

      doc.fontSize(8).fillColor(mutedColor).font("Helvetica")
        .text(
          "This is a system-generated receipt from VestBlock. This document confirms that the referenced deposit has been verified and credited to your wallet account.",
          leftCol,
          footerY + 10,
          { width: pageWidth, align: "center" }
        );

      doc.fontSize(8).fillColor(mutedColor)
        .text(
          `Generated on ${new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "long", year: "numeric" })} | VestBlock Tokenized Investment Platform`,
          leftCol,
          footerY + 35,
          { width: pageWidth, align: "center" }
        );

      doc.end();
    } catch (err: any) {
      console.error("Receipt generation error:", err);
      if (!res.headersSent) {
        res.status(500).json({ message: "Failed to generate receipt" });
      }
    }
  });
}
