import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth } from "../auth";
import { logAuditFromReq } from "../lib/audit-logger";
import { updateProfileSchema, notificationPreferencesSchema } from "@shared/schema";
import { z } from "zod";

export function registerProfileRoutes(app: Express) {
  const stripPassword = (user: any) => {
    const { password, ...safe } = user;
    return safe;
  };

  app.patch("/api/profile", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const data = updateProfileSchema.parse(req.body);
      const currentUser = await storage.getUser(userId);
      if (!currentUser) return res.status(404).json({ message: "User not found" });

      const changedFields: string[] = [];
      if (data.fullName !== undefined && data.fullName !== currentUser.fullName) changedFields.push("fullName");
      if (data.phone !== undefined && data.phone !== currentUser.phone) changedFields.push("phone");
      if (data.nationality !== undefined && data.nationality !== currentUser.nationality) changedFields.push("nationality");
      if (data.address !== undefined && data.address !== currentUser.address) changedFields.push("address");
      if (data.timezone !== undefined && data.timezone !== currentUser.timezone) changedFields.push("timezone");

      const updated = await storage.updateUserProfile(userId, data);
      if (!updated) return res.status(404).json({ message: "User not found" });

      if (changedFields.length > 0) {
        await logAuditFromReq(req, "PROFILE_UPDATE", "user", userId, {
          reason: `Updated fields: ${changedFields.join(", ")}`,
          metadata: { changedFields },
        });
      }

      res.json({ user: stripPassword(updated) });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("Profile update error:", err);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  app.patch("/api/profile/notifications", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const prefs = notificationPreferencesSchema.parse(req.body);

      const updated = await storage.updateNotificationPreferences(userId, prefs);
      if (!updated) return res.status(404).json({ message: "User not found" });

      await logAuditFromReq(req, "NOTIFICATION_PREFERENCES_UPDATE", "user", userId, {
        reason: `Updated notification preferences`,
      });

      res.json({ user: stripPassword(updated) });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("Notification preferences update error:", err);
      res.status(500).json({ message: "Failed to update notification preferences" });
    }
  });
}
