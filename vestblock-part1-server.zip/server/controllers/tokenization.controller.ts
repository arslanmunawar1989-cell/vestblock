import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { insertSpvEntitySchema, insertShareClassSchema, insertTokenSchema } from "@shared/schema";
import { validateBody } from "../middleware/validate";
import { z } from "zod";
import { executeTokenIssuancePipeline } from "../services/token-issuance.service";
import { executeSplit, executeMerge, executeBuyback, executeRedemption, executeBurnOnClosure } from "../services/corporate-action.service";
import { canTransfer } from "../services/transfer-restrictions.service";
import { createCertificateForHolding, generateCertificatePdf, generateVerificationHash } from "../services/certificate-generator.service";
import { logAuditFromReq } from "../lib/audit-logger";

const createTransferSchema = z.object({
  toUserId: z.string().min(1),
  tokenId: z.string().min(1),
  amount: z.string().refine(v => parseFloat(v) > 0, "Amount must be positive"),
  reason: z.string().optional(),
});

export function registerTokenizationRoutes(app: Express) {
  app.post("/api/tokenization/spv", requireAuth, validateBody(insertSpvEntitySchema), async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can create SPV entities" });
      }
      const asset = await storage.getAsset(req.body.assetId);
      if (!asset) return res.status(404).json({ message: "Asset not found" });
      const spv = await storage.createSpvEntity(req.body);
      res.status(201).json(spv);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/spv/asset/:assetId", requireAuth, async (req, res) => {
    try {
      const spvs = await storage.getSpvEntitiesByAsset(String(String(req.params.assetId)));
      res.json(spvs);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/spv/:id", requireAuth, async (req, res) => {
    try {
      const spv = await storage.getSpvEntity(String(String(req.params.id)));
      if (!spv) return res.status(404).json({ message: "SPV entity not found" });
      res.json(spv);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tokenization/share-class", requireAuth, validateBody(insertShareClassSchema), async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can create share classes" });
      }
      const spv = await storage.getSpvEntity(req.body.spvId);
      if (!spv) return res.status(404).json({ message: "SPV entity not found" });
      const shareClass = await storage.createShareClass(req.body);
      res.status(201).json(shareClass);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/share-class/spv/:spvId", requireAuth, async (req, res) => {
    try {
      const classes = await storage.getShareClassesBySpv(String(String(req.params.spvId)));
      res.json(classes);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/share-class/:id", requireAuth, async (req, res) => {
    try {
      const sc = await storage.getShareClass(String(String(req.params.id)));
      if (!sc) return res.status(404).json({ message: "Share class not found" });
      res.json(sc);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tokenization/token", requireAuth, validateBody(insertTokenSchema), async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admin can create tokens" });
      }
      if (req.body.shareClassId) {
        const shareClass = await storage.getShareClass(req.body.shareClassId);
        if (!shareClass) return res.status(404).json({ message: "Share class not found" });
      }
      if (req.body.vehicleId) {
        const vehicle = await storage.getInvestmentVehicle(req.body.vehicleId);
        if (!vehicle) return res.status(404).json({ message: "Investment vehicle not found" });
      }
      if (!req.body.shareClassId && !req.body.vehicleId) {
        return res.status(400).json({ message: "Either shareClassId or vehicleId is required" });
      }
      const token = await storage.createToken(req.body);
      res.status(201).json(token);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/tokens", requireAuth, async (req, res) => {
    try {
      const allTokens = await storage.getAllTokens(req.tenantId);
      res.json(allTokens);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/token/:id", requireAuth, async (req, res) => {
    try {
      const token = await storage.getToken(String(String(req.params.id)));
      if (!token) return res.status(404).json({ message: "Token not found" });
      res.json(token);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/token/:id/share-class", requireAuth, async (req, res) => {
    try {
      const tokens = await storage.getTokensByShareClass(String(String(req.params.id)));
      res.json(tokens);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/holdings", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      let holdings = await storage.getTokenHoldingsByUser(userId);

      if (holdings.length === 0) {
        const allTokens = await storage.getAllTokens(req.tenantId);
        for (const token of allTokens) {
          if (!token.shareClassId) continue;
          const shareClass = await storage.getShareClass(token.shareClassId);
          if (!shareClass) continue;
          const spv = await storage.getSpvEntity(shareClass.spvId);
          if (!spv) continue;
          const portfolioItem = await storage.getPortfolioItem(userId, spv.assetId);
          if (portfolioItem && parseFloat(portfolioItem.quantity) > 0) {
            await storage.upsertTokenHolding(userId, token.id, portfolioItem.quantity);
          }
        }
        holdings = await storage.getTokenHoldingsByUser(userId);
      }

      res.json(holdings);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/holdings/token/:tokenId", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admin can view all holders" });
      }
      const holdings = await storage.getTokenHoldingsByToken(String(String(req.params.tokenId)));
      res.json(holdings);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tokenization/transfer/check", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const { toUserId, tokenId, amount } = req.body;

      if (!toUserId || !tokenId || !amount) {
        return res.status(400).json({ message: "toUserId, tokenId, and amount are required" });
      }
      if (toUserId === userId) {
        return res.status(400).json({ allowed: false, violations: ["Cannot transfer to yourself"] });
      }

      const result = await canTransfer(userId, toUserId, tokenId, parseFloat(amount));
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tokenization/transfer", requireAuth, validateBody(createTransferSchema), async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const { toUserId, tokenId, amount, reason } = req.body;

      if (toUserId === userId) {
        return res.status(400).json({ message: "Cannot transfer to yourself" });
      }

      const restrictionResult = await canTransfer(userId, toUserId, tokenId, parseFloat(amount));
      if (!restrictionResult.allowed) {
        return res.status(403).json({
          message: "Transfer blocked by restrictions",
          violations: restrictionResult.violations,
        });
      }

      const transfer = await storage.createTokenTransfer({
        fromUserId: userId,
        toUserId,
        tokenId,
        amount,
        status: "pending",
        reason: reason || null,
      });

      res.status(201).json(transfer);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tokenization/transfer/:id/approve", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admin can approve transfers" });
      }

      const transferRow = await storage.getTokenTransfer(String(String(req.params.id)));
      if (!transferRow) return res.status(404).json({ message: "Transfer not found" });
      if (transferRow.status !== "pending") {
        return res.status(400).json({ message: `Transfer is already ${transferRow.status}` });
      }

      const ledgerBalance = await storage.computeTokenBalanceFromLedger(transferRow.fromUserId, transferRow.tokenId);
      const fromBalance = parseFloat(ledgerBalance);
      const transferAmt = parseFloat(transferRow.amount);

      if (fromBalance < transferAmt) {
        return res.status(400).json({ message: `Sender has insufficient balance. Ledger balance: ${ledgerBalance}, transfer amount: ${transferRow.amount}` });
      }

      const newFromBalance = (fromBalance - transferAmt).toFixed(6);
      if (parseFloat(newFromBalance) < 0) {
        return res.status(400).json({ message: "Transfer would result in negative balance" });
      }
      await storage.upsertTokenHolding(transferRow.fromUserId, transferRow.tokenId, newFromBalance);

      const toHolding = await storage.getTokenHolding(transferRow.toUserId, transferRow.tokenId);
      const toBalance = parseFloat(toHolding?.balance || "0") + transferAmt;
      await storage.upsertTokenHolding(transferRow.toUserId, transferRow.tokenId, toBalance.toFixed(6));

      await storage.createTokenLedgerEntry({
        tokenId: transferRow.tokenId,
        fromUserId: transferRow.fromUserId,
        toUserId: transferRow.toUserId,
        amount: transferRow.amount,
        reason: "transfer",
        refId: transferRow.id,
      });

      const transfer = await storage.updateTokenTransferStatus(String(String(req.params.id)), "completed");

      res.json({ message: "Transfer approved", transfer });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tokenization/transfer/:id/reject", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admin can reject transfers" });
      }
      const existing = await storage.getTokenTransfer(String(String(req.params.id)));
      if (!existing) return res.status(404).json({ message: "Transfer not found" });
      if (existing.status !== "pending") {
        return res.status(400).json({ message: `Transfer is already ${existing.status}` });
      }
      const transfer = await storage.updateTokenTransferStatus(String(String(req.params.id)), "rejected");
      res.json({ message: "Transfer rejected", transfer });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/transfers", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const transfers = await storage.getTokenTransfersByUser(userId);
      res.json(transfers);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/ledger/:tokenId", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Admin only" });
      }
      const entries = await storage.getTokenLedgerEntriesByToken(String(String(req.params.tokenId)));
      res.json(entries);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/ledger/user/me", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const entries = await storage.getTokenLedgerEntriesByUser(userId);
      res.json(entries);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/balance/:tokenId", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const ledgerBalance = await storage.computeTokenBalanceFromLedger(userId, String(String(req.params.tokenId)));
      const holding = await storage.getTokenHolding(userId, String(String(req.params.tokenId)));
      res.json({
        tokenId: String(String(req.params.tokenId)),
        userId,
        ledgerBalance,
        holdingBalance: holding?.balance || "0",
        isConsistent: ledgerBalance === (holding?.balance || "0"),
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tokenization/migrate-holdings", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admin can trigger migration" });
      }

      const allTokens = await storage.getAllTokens(req.tenantId);
      const users = await storage.getUsers(req.tenantId);
      let migrated = 0;

      const assetToToken = new Map<string, string>();
      for (const token of allTokens) {
        if (!token.shareClassId) continue;
        const shareClass = await storage.getShareClass(token.shareClassId);
        if (!shareClass) continue;
        const spv = await storage.getSpvEntity(shareClass.spvId);
        if (!spv) continue;
        if (!assetToToken.has(spv.assetId)) {
          assetToToken.set(spv.assetId, token.id);
        }
      }

      for (const [assetId, tokenId] of Array.from(assetToToken)) {
        for (const u of users) {
          const portfolioItem = await storage.getPortfolioItem(u.id, assetId);
          if (portfolioItem && parseFloat(portfolioItem.quantity) > 0) {
            await storage.upsertTokenHolding(u.id, tokenId, portfolioItem.quantity);
            migrated++;
          }
        }
      }

      res.json({ message: `Migrated ${migrated} holdings to token balances` });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tokenization/issue/:roundId", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admin can trigger token issuance" });
      }

      const result = await executeTokenIssuancePipeline(String(String(req.params.roundId)), user.userId);
      if (!result.success) {
        return res.status(400).json({ message: result.error });
      }

      res.status(201).json({
        message: "Token issuance completed successfully",
        issuanceId: result.issuanceId,
        report: result.report,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/issuances", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admin can view issuance records" });
      }
      const issuances = await storage.getAllTokenIssuances(req.tenantId);
      res.json(issuances);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/issuances/round/:roundId", requireAuth, async (req, res) => {
    try {
      const issuances = await storage.getTokenIssuancesByRound(String(String(req.params.roundId)));
      res.json(issuances);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/issuances/asset/:assetId", requireAuth, async (req, res) => {
    try {
      const issuances = await storage.getTokenIssuancesByAsset(String(String(req.params.assetId)));
      res.json(issuances);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tokenization/certificates/generate", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const { tokenId } = req.body;
      if (!tokenId) {
        return res.status(400).json({ message: "tokenId is required" });
      }
      const cert = await createCertificateForHolding(userId, tokenId);
      res.status(201).json(cert);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/certificates", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const certs = await storage.getTokenCertificatesByUser(userId);
      res.json(certs);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/certificates/:id/download", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const cert = await storage.getTokenCertificate(String(String(req.params.id)));
      if (!cert) return res.status(404).json({ message: "Certificate not found" });
      if (cert.userId !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const pdfBuffer = await generateCertificatePdf({
        investorName: cert.investorName,
        tokenSymbol: cert.tokenSymbol,
        balance: cert.balance,
        snapshotDate: cert.snapshotDate,
        verificationHash: cert.verificationHash,
        certificateId: cert.id,
        propertyTitle: cert.propertyTitle,
        propertyLocation: cert.propertyLocation,
        spvName: cert.spvName,
        spvJurisdiction: cert.spvJurisdiction,
        ownershipPercentage: cert.ownershipPercentage,
        totalTokenSupply: cert.totalTokenSupply,
        propertyValue: cert.propertyValue,
        currency: cert.currency,
      });

      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="certificate_${cert.tokenSymbol}_${cert.snapshotDate}.pdf"`);
      res.send(pdfBuffer);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/admin/spvs", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") return res.status(403).json({ message: "Admin only" });
      const spvs = await storage.getAllSpvEntities(req.tenantId);
      res.json(spvs);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/admin/share-classes", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") return res.status(403).json({ message: "Admin only" });
      const classes = await storage.getAllShareClasses(req.tenantId);
      res.json(classes);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/admin/cap-table/:tokenId", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") return res.status(403).json({ message: "Admin only" });

      const token = await storage.getToken(String(req.params.tokenId));
      if (!token) return res.status(404).json({ message: "Token not found" });

      const holdings = await storage.getTokenHoldingsByToken(String(req.params.tokenId));

      let vehicle = token.vehicleId ? await storage.getInvestmentVehicle(token.vehicleId) : null;
      const shareClass = token.shareClassId ? await storage.getShareClass(token.shareClassId) : null;
      const spv = shareClass ? await storage.getSpvEntity(shareClass.spvId) : null;
      const asset = spv ? await storage.getAsset(spv.assetId) : null;

      const totalSupply = parseFloat(token.totalSupply || shareClass?.totalSupply || "0");

      const enriched = await Promise.all(
        holdings
          .filter((h) => parseFloat(h.balance) > 0)
          .map(async (h) => {
            const investor = await storage.getUser(h.userId);
            return {
              holdingId: h.id,
              userId: h.userId,
              investorName: investor?.fullName || "Unknown",
              email: investor?.email || "",
              nationality: investor?.nationality || "",
              kycStatus: investor?.kycStatus || "pending",
              balance: h.balance,
              percentage: totalSupply > 0
                ? ((parseFloat(h.balance) / totalSupply) * 100).toFixed(4)
                : "0",
              updatedAt: h.updatedAt,
            };
          })
      );

      res.json({
        token: {
          id: token.id,
          tokenSymbol: token.tokenSymbol,
          frozen: token.frozen,
          decimals: token.decimals,
          totalSupply: token.totalSupply,
        },
        vehicle: vehicle ? { id: vehicle.id, name: vehicle.name, type: vehicle.type, jurisdiction: vehicle.jurisdiction } : null,
        shareClass: shareClass ? { id: shareClass.id, name: shareClass.name, totalSupply: shareClass.totalSupply, currency: shareClass.currency } : null,
        spv: spv ? { id: spv.id, legalName: spv.legalName, jurisdiction: spv.jurisdiction } : null,
        asset: asset ? { id: asset.id, name: asset.name, symbol: asset.symbol } : null,
        holders: enriched,
        totalHolders: enriched.length,
        totalAllocated: enriched.reduce((sum, h) => sum + parseFloat(h.balance), 0).toFixed(6),
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/admin/cap-table/:tokenId/export", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") return res.status(403).json({ message: "Admin only" });

      const token = await storage.getToken(String(req.params.tokenId));
      if (!token) return res.status(404).json({ message: "Token not found" });

      const holdings = await storage.getTokenHoldingsByToken(String(req.params.tokenId));

      let vehicle = token.vehicleId ? await storage.getInvestmentVehicle(token.vehicleId) : null;
      const shareClass = token.shareClassId ? await storage.getShareClass(token.shareClassId) : null;
      const spv = shareClass ? await storage.getSpvEntity(shareClass.spvId) : null;

      const totalSupply = parseFloat(token.totalSupply || shareClass?.totalSupply || "0");
      const vehicleName = vehicle?.name || spv?.legalName || "N/A";
      const vehicleType = vehicle?.type || (spv ? "SPV" : "N/A");

      const rows: string[] = [];
      rows.push("Token Symbol,Vehicle,Vehicle Type,Investor Name,Email,Nationality,KYC Status,Balance,Decimals,Ownership %,Last Updated");

      for (const h of holdings) {
        if (parseFloat(h.balance) <= 0) continue;
        const investor = await storage.getUser(h.userId);
        if (!investor) continue;
        const pct = totalSupply > 0
          ? ((parseFloat(h.balance) / totalSupply) * 100).toFixed(4)
          : "0";
        rows.push(
          [
            `"${token.tokenSymbol}"`,
            `"${vehicleName}"`,
            `"${vehicleType}"`,
            `"${investor.fullName}"`,
            `"${investor.email}"`,
            `"${investor.nationality || ""}"`,
            investor.kycStatus,
            h.balance,
            token.decimals,
            `${pct}%`,
            h.updatedAt ? new Date(h.updatedAt).toISOString() : "",
          ].join(",")
        );
      }

      const csv = rows.join("\n");
      const filename = `cap_table_${token.tokenSymbol}_${new Date().toISOString().split("T")[0]}.csv`;

      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
      res.send(csv);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/admin/investor-registry/:tokenId", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") return res.status(403).json({ message: "Admin only" });

      const token = await storage.getToken(String(String(req.params.tokenId)));
      if (!token) return res.status(404).json({ message: "Token not found" });

      const holdings = await storage.getTokenHoldingsByToken(String(String(req.params.tokenId)));
      const shareClass = token.shareClassId ? await storage.getShareClass(token.shareClassId) : null;
      const spv = shareClass ? await storage.getSpvEntity(shareClass.spvId) : null;

      const totalSupply = parseFloat(token.totalSupply || shareClass?.totalSupply || "0");
      const jurisdictionFilter = (req.query.jurisdiction as string) || "";

      const rows: string[] = [];
      rows.push("Investor Name,Email,Nationality,KYC Status,Balance,Percentage,Last Updated");

      for (const h of holdings) {
        if (parseFloat(h.balance) <= 0) continue;
        const investor = await storage.getUser(h.userId);
        if (!investor) continue;
        if (jurisdictionFilter && investor.nationality !== jurisdictionFilter) continue;
        const pct = totalSupply > 0
          ? ((parseFloat(h.balance) / totalSupply) * 100).toFixed(4)
          : "0";
        rows.push(
          [
            `"${investor.fullName}"`,
            `"${investor.email}"`,
            `"${investor.nationality || ""}"`,
            investor.kycStatus,
            h.balance,
            `${pct}%`,
            h.updatedAt ? new Date(h.updatedAt).toISOString() : "",
          ].join(",")
        );
      }

      const csv = rows.join("\n");
      const filename = `investor_registry_${token.tokenSymbol}${jurisdictionFilter ? `_${jurisdictionFilter}` : ""}_${new Date().toISOString().split("T")[0]}.csv`;

      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
      res.send(csv);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tokenization/admin/token/:id/freeze", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") return res.status(403).json({ message: "Admin only" });

      const token = await storage.getToken(String(String(req.params.id)));
      if (!token) return res.status(404).json({ message: "Token not found" });

      const updated = await storage.updateTokenFrozen(String(String(req.params.id)), true);

      await logAuditFromReq(req, "TOKEN_FROZEN", "token", token.id, {
        reason: `Token ${token.tokenSymbol} has been frozen`,
        beforeState: { frozen: false },
        afterState: { frozen: true },
      });

      res.json({ message: `Token ${token.tokenSymbol} has been frozen`, token: updated });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/tokenization/admin/token/:id/unfreeze", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") return res.status(403).json({ message: "Admin only" });

      const token = await storage.getToken(String(String(req.params.id)));
      if (!token) return res.status(404).json({ message: "Token not found" });

      const updated = await storage.updateTokenFrozen(String(String(req.params.id)), false);

      await logAuditFromReq(req, "TOKEN_UNFROZEN", "token", token.id, {
        reason: `Token ${token.tokenSymbol} has been unfrozen`,
        beforeState: { frozen: true },
        afterState: { frozen: false },
      });

      res.json({ message: `Token ${token.tokenSymbol} has been unfrozen`, token: updated });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/certificates/:id/verify", async (req, res) => {
    try {
      const cert = await storage.getTokenCertificate(String(String(req.params.id)));
      if (!cert) return res.status(404).json({ message: "Certificate not found", valid: false });

      const expectedHash = generateVerificationHash({
        userId: cert.userId,
        tokenId: cert.tokenId,
        balance: cert.balance,
        snapshotDate: cert.snapshotDate,
      });

      const valid = expectedHash === cert.verificationHash;
      res.json({
        valid,
        certificateId: cert.id,
        tokenSymbol: cert.tokenSymbol,
        investorName: cert.investorName,
        balance: cert.balance,
        snapshotDate: cert.snapshotDate,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const corporateActionSchema = z.object({
    tokenId: z.string().min(1),
    ratioNumerator: z.number().int().positive(),
    ratioDenominator: z.number().int().positive(),
    reason: z.string().optional(),
  });

  app.post("/api/admin/tokens/split", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admin can execute token splits" });
      }
      const parsed = corporateActionSchema.parse(req.body);
      const result = await executeSplit(
        parsed.tokenId,
        parsed.ratioNumerator,
        parsed.ratioDenominator,
        user.userId,
        parsed.reason
      );

      await logAuditFromReq(req, "TOKEN_SPLIT", "token", parsed.tokenId, {
        reason: parsed.reason || `Token split ${parsed.ratioNumerator}:${parsed.ratioDenominator}`,
        metadata: { ratioNumerator: parsed.ratioNumerator, ratioDenominator: parsed.ratioDenominator },
      });

      res.json({ message: "Token split executed successfully", ...result });
    } catch (error: any) {
      res.status(error.message?.includes("not found") || error.message?.includes("frozen") ? 400 : 500)
        .json({ message: error.message });
    }
  });

  app.post("/api/admin/tokens/merge", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admin can execute token merges" });
      }
      const parsed = corporateActionSchema.parse(req.body);
      const result = await executeMerge(
        parsed.tokenId,
        parsed.ratioNumerator,
        parsed.ratioDenominator,
        user.userId,
        parsed.reason
      );

      await logAuditFromReq(req, "TOKEN_MERGE", "token", parsed.tokenId, {
        reason: parsed.reason || `Token merge ${parsed.ratioNumerator}:${parsed.ratioDenominator}`,
        metadata: { ratioNumerator: parsed.ratioNumerator, ratioDenominator: parsed.ratioDenominator },
      });

      res.json({ message: "Token merge executed successfully", ...result });
    } catch (error: any) {
      res.status(error.message?.includes("not found") || error.message?.includes("frozen") ? 400 : 500)
        .json({ message: error.message });
    }
  });

  const buybackSchema = z.object({
    tokenId: z.string().min(1),
    targets: z.array(z.object({
      userId: z.string().min(1),
      amount: z.string().refine(v => parseFloat(v) > 0, "Amount must be positive"),
    })).min(1, "At least one target required"),
    pricePerToken: z.string().refine(v => parseFloat(v) > 0, "Price must be positive"),
    currency: z.string().min(1),
    reason: z.string().optional(),
  });

  app.post("/api/admin/tokens/buyback", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admin can execute token buybacks" });
      }
      const parsed = buybackSchema.parse(req.body);
      const result = await executeBuyback(
        parsed.tokenId,
        parsed.targets,
        parsed.pricePerToken,
        parsed.currency,
        user.userId,
        parsed.reason
      );

      await logAuditFromReq(req, "TOKEN_BUYBACK", "token", parsed.tokenId, {
        reason: parsed.reason || `Token buyback at ${parsed.pricePerToken} ${parsed.currency}`,
        metadata: { targetCount: parsed.targets.length, pricePerToken: parsed.pricePerToken, currency: parsed.currency },
      });

      res.json({ message: "Token buyback executed successfully", ...result });
    } catch (error: any) {
      const status = error.message?.includes("not found") || error.message?.includes("frozen") || error.message?.includes("holds") ? 400 : 500;
      res.status(status).json({ message: error.message });
    }
  });

  const redemptionSchema = z.object({
    tokenId: z.string().min(1),
    userId: z.string().min(1),
    amount: z.string().refine(v => parseFloat(v) > 0, "Amount must be positive"),
    pricePerToken: z.string().refine(v => parseFloat(v) > 0, "Price must be positive"),
    currency: z.string().min(1),
    reason: z.string().optional(),
  });

  app.post("/api/admin/tokens/redemption", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admin can execute token redemptions" });
      }
      const parsed = redemptionSchema.parse(req.body);
      const result = await executeRedemption(
        parsed.tokenId,
        parsed.userId,
        parsed.amount,
        parsed.pricePerToken,
        parsed.currency,
        user.userId,
        parsed.reason
      );

      await logAuditFromReq(req, "TOKEN_REDEMPTION", "token", parsed.tokenId, {
        reason: parsed.reason || `Token redemption: ${parsed.amount} at ${parsed.pricePerToken} ${parsed.currency}`,
        metadata: { userId: parsed.userId, amount: parsed.amount, pricePerToken: parsed.pricePerToken, currency: parsed.currency },
      });

      res.json({ message: "Token redemption executed successfully", ...result });
    } catch (error: any) {
      const status = error.message?.includes("not found") || error.message?.includes("frozen") || error.message?.includes("holds") ? 400 : 500;
      res.status(status).json({ message: error.message });
    }
  });

  const burnClosureSchema = z.object({
    tokenId: z.string().min(1),
    reason: z.string().optional(),
  });

  app.post("/api/admin/tokens/burn-closure", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admin can execute burn-on-closure" });
      }
      const parsed = burnClosureSchema.parse(req.body);
      const result = await executeBurnOnClosure(
        parsed.tokenId,
        user.userId,
        parsed.reason
      );

      await logAuditFromReq(req, "TOKEN_BURN_CLOSURE", "token", parsed.tokenId, {
        reason: parsed.reason || "Burn-on-closure executed — all tokens burned and token frozen",
      });

      res.json({ message: "Burn-on-closure executed successfully — all tokens burned and token frozen", ...result });
    } catch (error: any) {
      const status = error.message?.includes("not found") || error.message?.includes("No active") ? 400 : 500;
      res.status(status).json({ message: error.message });
    }
  });

  app.get("/api/admin/tokens/:tokenId/corporate-actions", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admin can view corporate action history" });
      }
      const actions = await storage.getTokenCorporateActionsByToken(String(req.params.tokenId));
      res.json(actions);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/corporate-actions", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admin can view corporate actions" });
      }
      const actions = await storage.getAllTokenCorporateActions(req.tenantId);
      res.json(actions);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/admin/property-cap-table/:assetId", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") return res.status(403).json({ message: "Admin only" });

      const assetId = String(req.params.assetId);
      const asset = await storage.getAsset(assetId);
      if (!asset) return res.status(404).json({ message: "Property not found" });

      const spvs = await storage.getSpvEntitiesByAsset(assetId);
      const holdersMap = new Map<string, {
        userId: string;
        investorName: string;
        email: string;
        nationality: string;
        kycStatus: string;
        totalTokens: number;
        totalValue: number;
        holdings: { tokenSymbol: string; shareClassName: string; currency: string; balance: string; percentage: string; }[];
      }>();

      let grandTotalSupply = 0;

      for (const spv of spvs) {
        const shareClasses = await storage.getShareClassesBySpv(spv.id);
        for (const sc of shareClasses) {
          const tokens = await storage.getTokensByShareClass(sc.id);
          for (const token of tokens) {
            const tokenTotalSupply = parseFloat(token.totalSupply || sc.totalSupply || "0");
            grandTotalSupply += tokenTotalSupply;

            const holdings = await storage.getTokenHoldingsByToken(token.id);
            for (const h of holdings) {
              if (parseFloat(h.balance) <= 0) continue;
              const bal = parseFloat(h.balance);
              const pct = tokenTotalSupply > 0 ? (bal / tokenTotalSupply) * 100 : 0;
              const value = bal * parseFloat(asset.pricePerToken || "0");

              let entry = holdersMap.get(h.userId);
              if (!entry) {
                const investor = await storage.getUser(h.userId);
                entry = {
                  userId: h.userId,
                  investorName: investor?.fullName || "Unknown",
                  email: investor?.email || "",
                  nationality: investor?.nationality || "",
                  kycStatus: investor?.kycStatus || "pending",
                  totalTokens: 0,
                  totalValue: 0,
                  holdings: [],
                };
                holdersMap.set(h.userId, entry);
              }
              entry.totalTokens += bal;
              entry.totalValue += value;
              entry.holdings.push({
                tokenSymbol: token.tokenSymbol,
                shareClassName: sc.name,
                currency: sc.currency,
                balance: h.balance,
                percentage: pct.toFixed(4),
              });
            }
          }
        }
      }

      const holders = Array.from(holdersMap.values()).sort((a, b) => b.totalValue - a.totalValue);
      const totalValue = holders.reduce((sum, h) => sum + h.totalValue, 0);

      res.json({
        asset: {
          id: asset.id,
          name: asset.name,
          symbol: asset.symbol,
          baseCurrency: asset.baseCurrency,
          pricePerToken: asset.pricePerToken,
          totalSupply: asset.totalSupply,
        },
        holders: holders.map(h => ({
          ...h,
          ownershipPercent: grandTotalSupply > 0 ? ((h.totalTokens / grandTotalSupply) * 100).toFixed(4) : "0",
          totalValue: h.totalValue.toFixed(2),
        })),
        totalHolders: holders.length,
        totalValue: totalValue.toFixed(2),
        grandTotalSupply: grandTotalSupply.toFixed(6),
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tokenization/admin/property-cap-table/:assetId/export", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") return res.status(403).json({ message: "Admin only" });

      const assetId = String(req.params.assetId);
      const asset = await storage.getAsset(assetId);
      if (!asset) return res.status(404).json({ message: "Property not found" });

      const spvs = await storage.getSpvEntitiesByAsset(assetId);
      const rows: string[] = [];
      rows.push("Property,Investor Name,Email,Nationality,KYC Status,Token Symbol,Share Class,Currency,Balance,Ownership %,Value (" + (asset.baseCurrency || "USD") + ")");

      let grandTotalSupply = 0;
      const allEntries: { investor: any; token: any; sc: any; balance: string; tokenTotalSupply: number }[] = [];

      for (const spv of spvs) {
        const shareClasses = await storage.getShareClassesBySpv(spv.id);
        for (const sc of shareClasses) {
          const tokens = await storage.getTokensByShareClass(sc.id);
          for (const token of tokens) {
            const tokenTotalSupply = parseFloat(token.totalSupply || sc.totalSupply || "0");
            grandTotalSupply += tokenTotalSupply;
            const holdings = await storage.getTokenHoldingsByToken(token.id);
            for (const h of holdings) {
              if (parseFloat(h.balance) <= 0) continue;
              const investor = await storage.getUser(h.userId);
              if (!investor) continue;
              allEntries.push({ investor, token, sc, balance: h.balance, tokenTotalSupply });
            }
          }
        }
      }

      for (const entry of allEntries) {
        const bal = parseFloat(entry.balance);
        const pct = grandTotalSupply > 0 ? ((bal / grandTotalSupply) * 100).toFixed(4) : "0";
        const value = (bal * parseFloat(asset.pricePerToken || "0")).toFixed(2);
        rows.push([
          `"${asset.name}"`,
          `"${entry.investor.fullName}"`,
          `"${entry.investor.email}"`,
          `"${entry.investor.nationality || ""}"`,
          entry.investor.kycStatus,
          `"${entry.token.tokenSymbol}"`,
          `"${entry.sc.name}"`,
          entry.sc.currency,
          entry.balance,
          `${pct}%`,
          value,
        ].join(","));
      }

      const csv = rows.join("\n");
      const safeName = asset.symbol || asset.name.replace(/[^a-zA-Z0-9]/g, "_");
      const filename = `cap_table_${safeName}_${new Date().toISOString().split("T")[0]}.csv`;

      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
      res.send(csv);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
}
