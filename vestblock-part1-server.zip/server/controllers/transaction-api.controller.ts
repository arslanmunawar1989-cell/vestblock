import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth } from "../auth";
import { createTransactionSchema, updateTransactionStatusSchema } from "@shared/schema";
import { db } from "../db";
import { auditLogs } from "@shared/schema";
import { emailService, transactionEmail } from "../services/email.service";

export function registerTransactionApiRoutes(app: Express) {
  app.post("/api/transactions/create", requireAuth, async (req, res) => {
    try {
      const parsed = createTransactionSchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({ message: "Invalid payload", errors: parsed.error.flatten().fieldErrors });
        return;
      }

      const { type, amount, currency, description, assetId, metadataJson } = parsed.data;
      const userId = (req as any).user.userId;
      const tenantId = (req as any).user.tenantId || null;

      const transaction = await storage.createTransaction({
        userId,
        tenantId,
        type,
        amount,
        status: "pending",
        description: description || null,
        assetId: assetId || null,
        currency: currency || "PKR",
        metadataJson: metadataJson || null,
      });

      await db.insert(auditLogs).values({
        tenantId,
        actorId: userId,
        actorRole: (req as any).user.role,
        actionType: "transaction.created",
        entityType: "transaction",
        entityId: transaction.id,
        afterState: transaction,
        ipAddress: req.ip || null,
        userAgent: req.headers["user-agent"] || null,
      });

      const creator = await storage.getUser(userId);
      if (creator?.email) {
        emailService.send(transactionEmail(creator.email, "created", { amount, currency: currency || "PKR", type, description }, { tenantId, transactionId: transaction.id })).catch(() => {});
      }

      res.status(201).json(transaction);
    } catch (err: any) {
      console.error("Create transaction error:", err);
      res.status(500).json({ message: "Failed to create transaction" });
    }
  });

  app.post("/api/transactions/update-status", requireAuth, async (req, res) => {
    try {
      const parsed = updateTransactionStatusSchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({ message: "Invalid payload", errors: parsed.error.flatten().fieldErrors });
        return;
      }

      const { id, status } = parsed.data;
      const userId = (req as any).user.userId;
      const role = (req as any).user.role;

      const existing = await storage.getTransaction(id);
      if (!existing) {
        res.status(404).json({ message: "Transaction not found" });
        return;
      }

      const isAdmin = role === "admin" || role === "super_admin";
      if (existing.userId !== userId && !isAdmin) {
        res.status(403).json({ message: "Not authorized to update this transaction" });
        return;
      }

      const updated = await storage.updateTransactionStatus(id, status);

      await db.insert(auditLogs).values({
        tenantId: existing.tenantId,
        actorId: userId,
        actorRole: role,
        actionType: "transaction.status_updated",
        entityType: "transaction",
        entityId: id,
        beforeState: { status: existing.status },
        afterState: { status },
        ipAddress: req.ip || null,
        userAgent: req.headers["user-agent"] || null,
      });

      const txUser = await storage.getUser(existing.userId);
      if (txUser?.email) {
        const eventMap: Record<string, "settled" | "failed"> = { completed: "settled", failed: "failed" };
        const emailEvent = eventMap[status];
        if (emailEvent) {
          emailService.send(transactionEmail(txUser.email, emailEvent, { amount: existing.amount, currency: existing.currency || "PKR", type: existing.type, description: existing.description || undefined }, { tenantId: existing.tenantId || undefined, transactionId: id })).catch(() => {});
        }
      }

      res.json(updated);
    } catch (err: any) {
      console.error("Update transaction status error:", err);
      res.status(500).json({ message: "Failed to update transaction status" });
    }
  });
}
