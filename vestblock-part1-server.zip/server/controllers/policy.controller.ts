import type { Express } from "express";
import { requireAuth } from "../auth";
import { storage } from "../storage";
import {
  buildPolicyContext,
  canInvest,
  canDeposit,
  canTrade,
  canHoldToken,
  getEffectivePolicy,
} from "../services/policy.service";
import type { InvestorType } from "@shared/schema";
import type { PaymentRailId } from "@shared/investor-policy";

export function registerPolicyRoutes(app: Express) {
  app.get("/api/policy/me", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const ctx = await buildPolicyContext(userId);
      const effective = getEffectivePolicy(ctx);

      const investCheck = canInvest(ctx);
      const tradeCheck = canTrade(ctx);

      res.json({
        investorType: ctx.investorType,
        country: effective.country,
        countryPolicy: effective.countryPolicy
          ? {
              countryCode: effective.countryPolicy.countryCode,
              countryName: effective.countryPolicy.countryName,
              sanctioned: effective.countryPolicy.sanctioned,
              blocked: effective.countryPolicy.blocked,
            }
          : null,
        investorPolicy: effective.investorPolicy,
        checks: {
          canInvest: investCheck,
          canTrade: tradeCheck,
        },
      });
    } catch (err: any) {
      console.error("Policy check error:", err);
      res.status(500).json({ message: "Failed to check policy" });
    }
  });

  app.post("/api/policy/check-invest", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const { assetId, amount } = req.body;

      const ctx = await buildPolicyContext(userId);
      let minInvestorType: InvestorType | undefined;

      if (assetId) {
        const asset = await storage.getAsset(assetId);
        if (asset) {
          minInvestorType = (asset as any).minInvestorType as InvestorType | undefined;
        }
      }

      const result = canInvest(ctx, minInvestorType, amount);
      res.json(result);
    } catch (err: any) {
      console.error("Check invest policy error:", err);
      res.status(500).json({ message: "Failed to check invest policy" });
    }
  });

  app.post("/api/policy/check-deposit", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const { rail } = req.body;

      if (!rail) {
        return res.status(400).json({ message: "rail is required" });
      }

      const ctx = await buildPolicyContext(userId);
      const result = canDeposit(ctx, rail as PaymentRailId);
      res.json(result);
    } catch (err: any) {
      console.error("Check deposit policy error:", err);
      res.status(500).json({ message: "Failed to check deposit policy" });
    }
  });

  app.post("/api/policy/check-trade", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const ctx = await buildPolicyContext(userId);
      const result = canTrade(ctx);
      res.json(result);
    } catch (err: any) {
      console.error("Check trade policy error:", err);
      res.status(500).json({ message: "Failed to check trade policy" });
    }
  });

  app.post("/api/policy/check-hold", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const { assetId } = req.body;

      const ctx = await buildPolicyContext(userId);
      let minInvestorType: InvestorType | undefined;

      if (assetId) {
        const asset = await storage.getAsset(assetId);
        if (asset) {
          minInvestorType = (asset as any).minInvestorType as InvestorType | undefined;
        }
      }

      const result = canHoldToken(ctx, minInvestorType);
      res.json(result);
    } catch (err: any) {
      console.error("Check hold policy error:", err);
      res.status(500).json({ message: "Failed to check hold policy" });
    }
  });

  app.patch("/api/policy/investor-type", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const { investorType, countryOfResidence, taxResidency } = req.body;

      const validTypes = ["retail", "sophisticated", "accredited", "institutional"];
      if (investorType && !validTypes.includes(investorType)) {
        return res.status(400).json({ message: "Invalid investor type" });
      }

      const updates: Record<string, string> = {};
      if (investorType) updates.investorType = investorType;
      if (countryOfResidence !== undefined) updates.countryOfResidence = countryOfResidence;
      if (taxResidency !== undefined) updates.taxResidency = taxResidency;

      if (Object.keys(updates).length === 0) {
        return res.status(400).json({ message: "No fields to update" });
      }

      await storage.updateUser(userId, updates);
      const ctx = await buildPolicyContext(userId);
      const effective = getEffectivePolicy(ctx);

      res.json({
        message: "Profile updated",
        investorType: ctx.investorType,
        country: effective.country,
        investorPolicy: effective.investorPolicy,
      });
    } catch (err: any) {
      console.error("Update investor type error:", err);
      res.status(500).json({ message: "Failed to update investor type" });
    }
  });
}
