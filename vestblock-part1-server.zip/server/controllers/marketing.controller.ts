import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { subscribeSchema, createCampaignSchema } from "@shared/schema";
import { emailService } from "../services/email.service";

export function registerMarketingRoutes(app: Express) {
  app.post("/api/marketing/subscribe", async (req, res) => {
    try {
      const parsed = subscribeSchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({ message: "Invalid email", errors: parsed.error.flatten().fieldErrors });
        return;
      }

      const { email, region, source } = parsed.data;
      const existing = await storage.getSubscriberByEmail(email);
      if (existing) {
        res.json({ message: "Already subscribed", subscriber: existing });
        return;
      }

      const subscriber = await storage.createSubscriber({
        email,
        region: region || null,
        source: source || "website",
        isActive: true,
      });

      res.status(201).json({ message: "Subscribed successfully", subscriber });
    } catch (err: any) {
      console.error("Subscribe error:", err);
      res.status(500).json({ message: "Failed to subscribe" });
    }
  });

  app.get("/api/admin/marketing/subscribers", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const { region } = req.query;
      const subs = await storage.getSubscribers({
        region: region as string | undefined,
        isActive: true,
      });
      const total = await storage.getSubscriberCount();
      res.json({ subscribers: subs, total });
    } catch (err: any) {
      console.error("Get subscribers error:", err);
      res.status(500).json({ message: "Failed to fetch subscribers" });
    }
  });

  app.get("/api/admin/marketing/subscribers/export", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const { region } = req.query;
      const subs = await storage.getSubscribers({
        region: region as string | undefined,
        isActive: true,
      });

      const esc = (v: string) => {
        if (!v) return "";
        const needsQuote = v.includes(",") || v.includes('"') || v.includes("\n");
        const sanitized = /^[=+\-@\t\r]/.test(v) ? `'${v}` : v;
        return needsQuote ? `"${sanitized.replace(/"/g, '""')}"` : sanitized;
      };

      const csv = [
        "email,region,source,created_at",
        ...subs.map(s => `${esc(s.email)},${esc(s.region || "")},${esc(s.source || "")},${esc(s.createdAt)}`),
      ].join("\n");

      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", "attachment; filename=subscribers.csv");
      res.send(csv);
    } catch (err: any) {
      console.error("Export subscribers error:", err);
      res.status(500).json({ message: "Failed to export subscribers" });
    }
  });

  app.get("/api/admin/marketing/campaigns", requireAuth, requireRole("admin"), async (_req, res) => {
    try {
      const list = await storage.getCampaigns();
      res.json({ campaigns: list });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch campaigns" });
    }
  });

  app.post("/api/admin/marketing/campaigns/send", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const parsed = createCampaignSchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({ message: "Invalid payload", errors: parsed.error.flatten().fieldErrors });
        return;
      }

      const { subject, body, segment } = parsed.data;
      const userId = (req as any).user.userId;
      const tenantId = (req as any).user.tenantId || null;

      const campaign = await storage.createCampaign({
        tenantId,
        subject,
        body,
        segment: segment || null,
        sentBy: userId,
        status: "sending",
      });

      const subs = await storage.getSubscribers({
        region: segment || undefined,
        isActive: true,
      });

      const payloads = subs.map(s => ({
        to: s.email,
        subject,
        body,
        tenantId,
        relatedEntityType: "campaign" as const,
        relatedEntityId: campaign.id,
      }));

      const result = await emailService.sendBulk(payloads);

      await storage.updateCampaignStatus(campaign.id, "sent", result.sent);

      res.json({
        campaign: { ...campaign, status: "sent", recipientCount: result.sent },
        sent: result.sent,
        failed: result.failed,
      });
    } catch (err: any) {
      console.error("Send campaign error:", err);
      res.status(500).json({ message: "Failed to send campaign" });
    }
  });
}
