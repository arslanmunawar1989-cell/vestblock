import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";

export function registerEmailOutboxRoutes(app: Express) {
  app.get("/api/admin/email-outbox", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const { limit: limitStr, offset: offsetStr, status } = req.query;

      const filters = {
        limit: limitStr ? parseInt(limitStr as string, 10) : 50,
        offset: offsetStr ? parseInt(offsetStr as string, 10) : 0,
        status: status as string | undefined,
      };

      const result = await storage.getEmailLogs(filters);

      res.json({
        logs: result.logs,
        total: result.total,
        limit: filters.limit,
        offset: filters.offset,
      });
    } catch (err: any) {
      console.error("Email outbox error:", err);
      res.status(500).json({ message: "Failed to fetch email outbox" });
    }
  });
}
