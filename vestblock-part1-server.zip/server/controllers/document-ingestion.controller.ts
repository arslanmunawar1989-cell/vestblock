import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { logAuditFromReq } from "../lib/audit-logger";
import { z } from "zod";
import { docIngestionTypeEnum, type DocIngestionType } from "@shared/schema";
import { getOcrProvider, EXTRACTION_SCHEMAS } from "../services/ocr-provider";

const startIngestionSchema = z.object({
  documentId: z.string().min(1),
  docType: z.enum(docIngestionTypeEnum),
});

const reviewFieldsSchema = z.object({
  reviewedFields: z.record(z.string(), z.string().nullable()),
  reviewNotes: z.string().optional(),
});

const approveRejectSchema = z.object({
  action: z.enum(["approve", "reject"]),
  reviewNotes: z.string().optional(),
  autoFillKyc: z.boolean().optional().default(false),
});

export function registerDocumentIngestionRoutes(app: Express) {
  app.get("/api/document-ingestion/schemas", requireAuth, (_req, res) => {
    res.json(EXTRACTION_SCHEMAS);
  });

  app.get("/api/document-ingestion/schemas/:docType", requireAuth, (req, res) => {
    const docType = req.params.docType as DocIngestionType;
    const schema = EXTRACTION_SCHEMAS[docType];
    if (!schema) return res.status(404).json({ message: "Unknown document type" });
    res.json({ docType, fields: schema });
  });

  app.post("/api/document-ingestion/start", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const data = startIngestionSchema.parse(req.body);

      const docs = await storage.getDocumentsByOwner(userId);
      const doc = docs.find(d => d.id === data.documentId);
      if (!doc) return res.status(404).json({ message: "Document not found" });

      const existing = await storage.getDocumentIngestionsByDocument(data.documentId);
      const active = existing.find(e => !["rejected", "failed"].includes(e.status));
      if (active) {
        return res.status(409).json({ message: "Ingestion already in progress for this document", ingestion: active });
      }

      const ingestion = await storage.createDocumentIngestion({
        documentId: data.documentId,
        userId,
        docType: data.docType,
        status: "uploaded",
        extractedFields: null,
        reviewedFields: null,
        confidence: null,
        ocrProvider: null,
        reviewedBy: null,
        reviewNotes: null,
        kycAutoFilled: false,
      });

      const ocrProvider = getOcrProvider();
      if (ocrProvider.enabled) {
        await storage.updateDocumentIngestion(ingestion.id, { status: "extracting" });

        try {
          const result = await ocrProvider.extract(data.docType as DocIngestionType, doc.url, doc.mimeType || undefined);
          const extractedFields: Record<string, string | null> = {};
          for (const f of result.fields) {
            extractedFields[f.key] = f.value;
          }
          await storage.updateDocumentIngestion(ingestion.id, {
            status: "extracted",
            extractedFields,
            confidence: result.overallConfidence.toFixed(2),
            ocrProvider: result.provider,
          });

          const updated = await storage.getDocumentIngestion(ingestion.id);
          return res.status(201).json(updated);
        } catch (err: any) {
          await storage.updateDocumentIngestion(ingestion.id, {
            status: "failed",
            reviewNotes: `OCR extraction failed: ${err.message?.slice(0, 200)}`,
          });
          const updated = await storage.getDocumentIngestion(ingestion.id);
          return res.status(201).json(updated);
        }
      }

      const schema = EXTRACTION_SCHEMAS[data.docType as DocIngestionType] || [];
      const emptyFields: Record<string, string | null> = {};
      for (const f of schema) {
        emptyFields[f.key] = null;
      }
      await storage.updateDocumentIngestion(ingestion.id, {
        status: "extracted",
        extractedFields: emptyFields,
        confidence: "0.00",
        ocrProvider: "manual",
      });

      const updated = await storage.getDocumentIngestion(ingestion.id);
      res.status(201).json(updated);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("Document ingestion start error:", err);
      res.status(500).json({ message: "Failed to start document ingestion" });
    }
  });

  app.get("/api/document-ingestion/my", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const ingestions = await storage.getDocumentIngestionsByUser(userId);
      res.json(ingestions);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch ingestions" });
    }
  });

  app.get("/api/document-ingestion/:id", requireAuth, async (req, res) => {
    try {
      const ingestion = await storage.getDocumentIngestion(req.params.id as string);
      if (!ingestion) return res.status(404).json({ message: "Ingestion not found" });

      const userId = (req as any).user.userId;
      const userRole = (req as any).user.role;
      if (ingestion.userId !== userId && userRole !== "admin") {
        return res.status(403).json({ message: "Access denied" });
      }

      const schema = EXTRACTION_SCHEMAS[ingestion.docType as DocIngestionType] || [];
      res.json({ ...ingestion, fieldSchema: schema });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch ingestion" });
    }
  });

  app.get("/api/admin/document-ingestion", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const ingestions = await storage.getAllDocumentIngestions(req.tenantId);
      const enriched = await Promise.all(ingestions.map(async (ing) => {
        const user = await storage.getUser(ing.userId);
        return {
          ...ing,
          user: user ? { id: user.id, username: user.username, email: user.email, fullName: user.fullName } : null,
          fieldSchema: EXTRACTION_SCHEMAS[ing.docType as DocIngestionType] || [],
        };
      }));
      res.json(enriched);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch ingestions" });
    }
  });

  app.patch("/api/admin/document-ingestion/:id/fields", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const ingestion = await storage.getDocumentIngestion(req.params.id as string);
      if (!ingestion) return res.status(404).json({ message: "Ingestion not found" });
      if (!["extracted", "review"].includes(ingestion.status)) {
        return res.status(400).json({ message: `Cannot edit fields in status "${ingestion.status}"` });
      }

      const data = reviewFieldsSchema.parse(req.body);
      const adminId = (req as any).user.userId;

      const updated = await storage.updateDocumentIngestion(ingestion.id, {
        reviewedFields: data.reviewedFields,
        reviewNotes: data.reviewNotes || ingestion.reviewNotes,
        reviewedBy: adminId,
        status: "review",
      });

      res.json(updated);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      res.status(500).json({ message: "Failed to update fields" });
    }
  });

  app.post("/api/admin/document-ingestion/:id/action", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const ingestion = await storage.getDocumentIngestion(req.params.id as string);
      if (!ingestion) return res.status(404).json({ message: "Ingestion not found" });
      if (!["extracted", "review"].includes(ingestion.status)) {
        return res.status(400).json({ message: `Cannot process action in status "${ingestion.status}"` });
      }

      const data = approveRejectSchema.parse(req.body);
      const adminId = (req as any).user.userId;

      if (data.action === "reject") {
        const updated = await storage.updateDocumentIngestion(ingestion.id, {
          status: "rejected",
          reviewedBy: adminId,
          reviewNotes: data.reviewNotes || "Rejected by admin",
        });

        await storage.createNotification({
          userId: ingestion.userId,
          type: "document_review",
          title: "Document Rejected",
          message: `Your ${ingestion.docType.replace(/_/g, " ")} document was rejected. ${data.reviewNotes || "Please re-upload a clearer copy."}`,
          relatedEntityId: ingestion.id,
          relatedEntityType: "document_ingestion",
        });

        return res.json(updated);
      }

      const finalFields = ingestion.reviewedFields || ingestion.extractedFields || {};
      const updated = await storage.updateDocumentIngestion(ingestion.id, {
        status: "approved",
        reviewedBy: adminId,
        reviewedFields: finalFields,
        reviewNotes: data.reviewNotes || "Approved",
      });

      if (data.autoFillKyc) {
        await autoFillKycFromIngestion(ingestion.userId, ingestion.docType as DocIngestionType, finalFields as Record<string, string | null>);
        await storage.updateDocumentIngestion(ingestion.id, { kycAutoFilled: true });
      }

      await storage.createNotification({
        userId: ingestion.userId,
        type: "document_review",
        title: "Document Approved",
        message: `Your ${ingestion.docType.replace(/_/g, " ")} document has been verified and approved.${data.autoFillKyc ? " Extracted data has been applied to your KYC profile." : ""}`,
        relatedEntityId: ingestion.id,
        relatedEntityType: "document_ingestion",
      });

      await logAuditFromReq(req, "DOCUMENT_INGESTION_APPROVED", "document_ingestion", ingestion.id, {
        reason: `Document ingestion approved for user ${ingestion.userId}, type: ${ingestion.docType}${data.autoFillKyc ? ", KYC auto-filled" : ""}`,
        metadata: { docType: ingestion.docType, autoFillKyc: data.autoFillKyc },
      });

      res.json(updated);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("Document ingestion action error:", err);
      res.status(500).json({ message: "Failed to process action" });
    }
  });
}

async function autoFillKycFromIngestion(
  userId: string,
  docType: DocIngestionType,
  fields: Record<string, string | null>
): Promise<void> {
  const schema = EXTRACTION_SCHEMAS[docType];
  if (!schema) return;

  const kycProfile = await storage.getKycProfile(userId);
  if (!kycProfile) return;

  const updates: Record<string, string> = {};
  for (const fieldDef of schema) {
    if (fieldDef.kycField && fields[fieldDef.key]) {
      const value = fields[fieldDef.key];
      if (value && value.trim()) {
        updates[fieldDef.kycField] = value.trim();
      }
    }
  }

  if (Object.keys(updates).length === 0) return;

  const { db } = await import("../db");
  const { kycProfiles } = await import("@shared/schema");
  const { eq } = await import("drizzle-orm");
  await db.update(kycProfiles).set(updates).where(eq(kycProfiles.id, kycProfile.id));
}
