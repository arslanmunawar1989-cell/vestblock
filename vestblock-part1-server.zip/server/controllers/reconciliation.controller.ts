import type { Express } from "express";
import { requireAuth, requireRole } from "../auth";
import { db } from "../db";
import { storage } from "../storage";
import { walletTransactions, walletAccounts } from "@shared/schema";
import { eq, and, gte, lt } from "drizzle-orm";
import { WALLET_CURRENCIES } from "@shared/constants";

interface DailyTotals {
  currency: string;
  date: string;
  deposits: { count: number; total: number };
  withdrawals: { count: number; total: number };
  fxConversionsIn: { count: number; total: number };
  fxConversionsOut: { count: number; total: number };
  investments: { count: number; total: number };
  dividends: { count: number; total: number };
  fees: { count: number; total: number };
  trades: { buyCount: number; buyTotal: number; sellCount: number; sellTotal: number };
  netFlow: number;
  ledgerBalance: number;
  walletBalance: number;
  discrepancy: number;
  hasDiscrepancy: boolean;
}

function dayRange(dateStr: string): [string, string] {
  const start = new Date(dateStr + "T00:00:00.000Z");
  const nextDay = new Date(start);
  nextDay.setUTCDate(nextDay.getUTCDate() + 1);
  return [start.toISOString(), nextDay.toISOString()];
}

async function getDailyReconciliation(date: string, currency?: string): Promise<DailyTotals[]> {
  const [dayStart, dayEnd] = dayRange(date);
  const currencies = currency ? [currency] : [...WALLET_CURRENCIES];
  const results: DailyTotals[] = [];

  for (const curr of currencies) {
    const accountsForCurrency = await db.select({ id: walletAccounts.id })
      .from(walletAccounts)
      .where(eq(walletAccounts.currency, curr));

    const accountIds = accountsForCurrency.map(a => a.id);

    if (accountIds.length === 0) {
      results.push(emptyTotals(curr, date));
      continue;
    }

    const dayTxs = await db.select().from(walletTransactions)
      .where(
        and(
          eq(walletTransactions.currency, curr),
          eq(walletTransactions.status, "COMPLETED"),
          gte(walletTransactions.createdAt, dayStart),
          lt(walletTransactions.createdAt, dayEnd),
        )
      );

    let deposits = { count: 0, total: 0 };
    let withdrawals = { count: 0, total: 0 };
    let fxIn = { count: 0, total: 0 };
    let fxOut = { count: 0, total: 0 };
    let investments = { count: 0, total: 0 };
    let dividends = { count: 0, total: 0 };
    let fees = { count: 0, total: 0 };
    let trades = { buyCount: 0, buyTotal: 0, sellCount: 0, sellTotal: 0 };

    for (const tx of dayTxs) {
      const amt = parseFloat(tx.amount);
      switch (tx.type) {
        case "DEPOSIT":
        case "CRYPTO_DEPOSIT":
          deposits.count++;
          deposits.total += amt;
          break;
        case "WITHDRAW":
          withdrawals.count++;
          withdrawals.total += amt;
          break;
        case "FX_CONVERT":
          if (amt >= 0) {
            fxIn.count++;
            fxIn.total += amt;
          } else {
            fxOut.count++;
            fxOut.total += Math.abs(amt);
          }
          break;
        case "INVEST_CAPTURE":
          investments.count++;
          investments.total += amt;
          break;
        case "DIVIDEND":
          dividends.count++;
          dividends.total += amt;
          break;
        case "FEE":
          fees.count++;
          fees.total += amt;
          break;
        case "TRADE_BUY":
          trades.buyCount++;
          trades.buyTotal += amt;
          break;
        case "TRADE_SELL":
          trades.sellCount++;
          trades.sellTotal += amt;
          break;
      }
    }

    const netFlow = deposits.total + fxIn.total + dividends.total + trades.sellTotal
      - withdrawals.total - fxOut.total - investments.total - fees.total - trades.buyTotal;

    const allCompletedTxs = await db.select().from(walletTransactions)
      .where(
        and(
          eq(walletTransactions.currency, curr),
          eq(walletTransactions.status, "COMPLETED"),
          lt(walletTransactions.createdAt, dayEnd),
        )
      );

    let ledgerBalance = 0;
    const creditTypes = ["DEPOSIT", "REFUND", "DIVIDEND", "TRADE_SELL", "CRYPTO_DEPOSIT"];
    const debitTypes = ["WITHDRAW", "INVEST_CAPTURE", "FEE", "TRADE_BUY"];

    for (const tx of allCompletedTxs) {
      const amt = parseFloat(tx.amount);
      if (tx.type === "FX_CONVERT") {
        ledgerBalance += amt;
      } else if (creditTypes.includes(tx.type)) {
        ledgerBalance += amt;
      } else if (debitTypes.includes(tx.type)) {
        ledgerBalance -= amt;
      }
    }

    let walletBalance = 0;
    for (const accId of accountIds) {
      const bal = await storage.getComputedBalance(accId);
      walletBalance += parseFloat(bal.available);
    }

    const discrepancy = Math.abs(round2(ledgerBalance) - round2(walletBalance));
    const hasDiscrepancy = discrepancy > 0.01;

    results.push({
      currency: curr,
      date,
      deposits,
      withdrawals,
      fxConversionsIn: fxIn,
      fxConversionsOut: fxOut,
      investments,
      dividends,
      fees,
      trades,
      netFlow: round2(netFlow),
      ledgerBalance: round2(ledgerBalance),
      walletBalance: round2(walletBalance),
      discrepancy: round2(discrepancy),
      hasDiscrepancy,
    });
  }

  return results;
}

function round2(n: number): number {
  return parseFloat(n.toFixed(2));
}

function emptyTotals(curr: string, date: string): DailyTotals {
  return {
    currency: curr,
    date,
    deposits: { count: 0, total: 0 },
    withdrawals: { count: 0, total: 0 },
    fxConversionsIn: { count: 0, total: 0 },
    fxConversionsOut: { count: 0, total: 0 },
    investments: { count: 0, total: 0 },
    dividends: { count: 0, total: 0 },
    fees: { count: 0, total: 0 },
    trades: { buyCount: 0, buyTotal: 0, sellCount: 0, sellTotal: 0 },
    netFlow: 0,
    ledgerBalance: 0,
    walletBalance: 0,
    discrepancy: 0,
    hasDiscrepancy: false,
  };
}

function toCsv(data: DailyTotals[]): string {
  const headers = [
    "Date", "Currency",
    "Deposits Count", "Deposits Total",
    "Withdrawals Count", "Withdrawals Total",
    "FX In Count", "FX In Total",
    "FX Out Count", "FX Out Total",
    "Investments Count", "Investments Total",
    "Dividends Count", "Dividends Total",
    "Fees Count", "Fees Total",
    "Trade Buy Count", "Trade Buy Total",
    "Trade Sell Count", "Trade Sell Total",
    "Net Flow", "Ledger Balance", "Wallet Balance",
    "Discrepancy", "Has Discrepancy",
  ];

  const rows = data.map(d => [
    d.date, d.currency,
    d.deposits.count, d.deposits.total.toFixed(2),
    d.withdrawals.count, d.withdrawals.total.toFixed(2),
    d.fxConversionsIn.count, d.fxConversionsIn.total.toFixed(2),
    d.fxConversionsOut.count, d.fxConversionsOut.total.toFixed(2),
    d.investments.count, d.investments.total.toFixed(2),
    d.dividends.count, d.dividends.total.toFixed(2),
    d.fees.count, d.fees.total.toFixed(2),
    d.trades.buyCount, d.trades.buyTotal.toFixed(2),
    d.trades.sellCount, d.trades.sellTotal.toFixed(2),
    d.netFlow.toFixed(2), d.ledgerBalance.toFixed(2), d.walletBalance.toFixed(2),
    d.discrepancy.toFixed(2), d.hasDiscrepancy ? "YES" : "NO",
  ]);

  return [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
}

export function registerReconciliationRoutes(app: Express) {
  app.get("/api/admin/reconciliation/daily", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const date = (req.query.date as string) || new Date().toISOString().split("T")[0];
      const currency = req.query.currency as string | undefined;

      if (currency && !WALLET_CURRENCIES.includes(currency as any)) {
        return res.status(400).json({ message: "Invalid currency" });
      }

      const data = await getDailyReconciliation(date, currency);
      res.json(data);
    } catch (err: any) {
      console.error("Reconciliation error:", err);
      res.status(500).json({ message: "Failed to generate reconciliation data" });
    }
  });

  app.get("/api/admin/reconciliation/export", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const date = (req.query.date as string) || new Date().toISOString().split("T")[0];
      const currency = req.query.currency as string | undefined;

      if (currency && !WALLET_CURRENCIES.includes(currency as any)) {
        return res.status(400).json({ message: "Invalid currency" });
      }

      const data = await getDailyReconciliation(date, currency);
      const csv = toCsv(data);

      const filename = currency
        ? `reconciliation_${date}_${currency}.csv`
        : `reconciliation_${date}_all.csv`;

      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
      res.send(csv);
    } catch (err: any) {
      console.error("CSV export error:", err);
      res.status(500).json({ message: "Failed to export reconciliation data" });
    }
  });

  app.get("/api/admin/reconciliation/range", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const startDate = req.query.startDate as string;
      const endDate = req.query.endDate as string;
      const currency = req.query.currency as string | undefined;

      if (!startDate || !endDate) {
        return res.status(400).json({ message: "startDate and endDate are required" });
      }

      if (currency && !WALLET_CURRENCIES.includes(currency as any)) {
        return res.status(400).json({ message: "Invalid currency" });
      }

      const start = new Date(startDate);
      const end = new Date(endDate);
      const diffDays = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));

      if (diffDays > 31) {
        return res.status(400).json({ message: "Date range cannot exceed 31 days" });
      }

      const allData: DailyTotals[] = [];
      const current = new Date(start);
      while (current <= end) {
        const dateStr = current.toISOString().split("T")[0];
        const dayData = await getDailyReconciliation(dateStr, currency);
        allData.push(...dayData);
        current.setDate(current.getDate() + 1);
      }

      res.json(allData);
    } catch (err: any) {
      console.error("Reconciliation range error:", err);
      res.status(500).json({ message: "Failed to generate reconciliation range data" });
    }
  });

  app.get("/api/admin/reconciliation/range/export", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const startDate = req.query.startDate as string;
      const endDate = req.query.endDate as string;
      const currency = req.query.currency as string | undefined;

      if (!startDate || !endDate) {
        return res.status(400).json({ message: "startDate and endDate are required" });
      }

      if (currency && !WALLET_CURRENCIES.includes(currency as any)) {
        return res.status(400).json({ message: "Invalid currency" });
      }

      const start = new Date(startDate);
      const end = new Date(endDate);
      const diffDays = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));

      if (diffDays > 31) {
        return res.status(400).json({ message: "Date range cannot exceed 31 days" });
      }

      const allData: DailyTotals[] = [];
      const current = new Date(start);
      while (current <= end) {
        const dateStr = current.toISOString().split("T")[0];
        const dayData = await getDailyReconciliation(dateStr, currency);
        allData.push(...dayData);
        current.setDate(current.getDate() + 1);
      }

      const csv = toCsv(allData);
      const filename = currency
        ? `reconciliation_${startDate}_to_${endDate}_${currency}.csv`
        : `reconciliation_${startDate}_to_${endDate}_all.csv`;

      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
      res.send(csv);
    } catch (err: any) {
      console.error("CSV range export error:", err);
      res.status(500).json({ message: "Failed to export reconciliation range data" });
    }
  });
}
