import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { logAuditFromReq } from "../lib/audit-logger";
import { createFeeScheduleSchema, feeTypeEnum, type FeeType, FEE_CATEGORY_MAP, FEE_CATEGORIES } from "@shared/schema";
import { previewFee, applyFee, getVehicleFeeConfig, FEE_TYPE_LABELS, FEE_TYPE_DEFAULTS } from "../services/fee-engine.service";
import { z } from "zod";

export function registerFeesRoutes(app: Express) {
  app.get("/api/fees/preview", requireAuth, async (req, res) => {
    try {
      const feeType = req.query.feeType as string;
      const amount = parseFloat(req.query.amount as string);
      const currency = req.query.currency as string | undefined;
      const vehicleId = req.query.vehicleId as string | undefined;

      if (!feeType || !feeTypeEnum.includes(feeType as any)) {
        return res.status(400).json({ message: "Invalid fee type" });
      }
      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({ message: "Invalid amount" });
      }

      const preview = await previewFee(feeType as FeeType, amount, currency, vehicleId);
      res.json(preview);
    } catch (err: any) {
      console.error("Fee preview error:", err);
      res.status(500).json({ message: "Failed to calculate fee preview" });
    }
  });

  app.get("/api/fees/active", requireAuth, async (req, res) => {
    try {
      const schedules = await storage.getAllFeeSchedules();
      const active = schedules.filter(s => s.isActive);
      res.json(active);
    } catch (err: any) {
      console.error("Active fees error:", err);
      res.status(500).json({ message: "Failed to fetch active fees" });
    }
  });

  app.get("/api/fees/types", requireAuth, async (_req, res) => {
    res.json({ labels: FEE_TYPE_LABELS, defaults: FEE_TYPE_DEFAULTS, types: feeTypeEnum });
  });

  app.get("/api/admin/fees", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const vehicleId = req.query.vehicleId as string | undefined;
      let schedules;
      if (vehicleId) {
        schedules = await storage.getFeeSchedulesByVehicle(vehicleId);
      } else {
        schedules = await storage.getAllFeeSchedules();
      }
      res.json(schedules);
    } catch (err: any) {
      console.error("Admin fees error:", err);
      res.status(500).json({ message: "Failed to fetch fee schedules" });
    }
  });

  app.get("/api/admin/fees/vehicle/:vehicleId/config", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const config = await getVehicleFeeConfig(req.params.vehicleId);
      res.json(config);
    } catch (err: any) {
      console.error("Vehicle fee config error:", err);
      res.status(500).json({ message: "Failed to fetch vehicle fee config" });
    }
  });

  app.get("/api/admin/fees/:id", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const schedule = await storage.getFeeScheduleById(req.params.id as string);
      if (!schedule) return res.status(404).json({ message: "Fee schedule not found" });
      res.json(schedule);
    } catch (err: any) {
      console.error("Fee schedule detail error:", err);
      res.status(500).json({ message: "Failed to fetch fee schedule" });
    }
  });

  app.get("/api/admin/fees/history/:feeType", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const feeType = req.params.feeType as FeeType;
      const currency = req.query.currency as string | undefined;
      const vehicleId = req.query.vehicleId as string | undefined;
      if (!feeTypeEnum.includes(feeType as any)) {
        return res.status(400).json({ message: "Invalid fee type" });
      }
      const history = await storage.getFeeScheduleHistory(feeType, currency, vehicleId);
      res.json(history);
    } catch (err: any) {
      console.error("Fee history error:", err);
      res.status(500).json({ message: "Failed to fetch fee history" });
    }
  });

  app.post("/api/admin/fees", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const adminId = (req as any).user.userId;
      const data = createFeeScheduleSchema.parse(req.body);

      const schedule = await storage.createFeeSchedule({
        vehicleId: data.vehicleId || null,
        feeType: data.feeType,
        currency: data.currency,
        method: data.method,
        rate: data.rate,
        flatAmount: data.flatAmount,
        tiers: data.tiers || null,
        minFee: data.minFee || null,
        maxFee: data.maxFee || null,
        notes: data.notes || null,
      }, adminId);

      await logAuditFromReq(req, "FEE_SCHEDULE_CREATED", "fee_schedule", schedule.id, {
        reason: `Fee schedule v${schedule.version} created for ${schedule.feeType} (${schedule.currency})${schedule.vehicleId ? ` on vehicle ${schedule.vehicleId}` : " (global)"}: ${schedule.method} rate=${schedule.rate}, flat=${schedule.flatAmount}`,
        afterState: { feeType: schedule.feeType, currency: schedule.currency, method: schedule.method, rate: schedule.rate, version: schedule.version, vehicleId: schedule.vehicleId },
      });

      res.status(201).json(schedule);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("Create fee schedule error:", err);
      res.status(500).json({ message: "Failed to create fee schedule" });
    }
  });

  app.post("/api/admin/fees/:id/deactivate", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const adminId = (req as any).user.userId;
      const schedule = await storage.deactivateFeeSchedule(req.params.id as string);
      if (!schedule) return res.status(404).json({ message: "Fee schedule not found" });

      await logAuditFromReq(req, "FEE_SCHEDULE_DEACTIVATED", "fee_schedule", schedule.id, {
        reason: `Fee schedule v${schedule.version} for ${schedule.feeType} (${schedule.currency})${schedule.vehicleId ? ` on vehicle ${schedule.vehicleId}` : " (global)"} deactivated by admin`,
        beforeState: { isActive: true },
        afterState: { isActive: false },
      });

      res.json(schedule);
    } catch (err: any) {
      console.error("Deactivate fee schedule error:", err);
      res.status(500).json({ message: "Failed to deactivate fee schedule" });
    }
  });

  app.get("/api/admin/applied-fees", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const vehicleId = req.query.vehicleId as string | undefined;
      const userId = req.query.userId as string | undefined;
      const entityType = req.query.entityType as string | undefined;
      const entityId = req.query.entityId as string | undefined;

      let fees;
      if (vehicleId) {
        fees = await storage.getAppliedFeesByVehicle(vehicleId);
      } else if (userId) {
        fees = await storage.getAppliedFeesByUser(userId);
      } else if (entityType && entityId) {
        fees = await storage.getAppliedFeesByEntity(entityType, entityId);
      } else {
        fees = await storage.getAllAppliedFees(200);
      }
      res.json(fees);
    } catch (err: any) {
      console.error("Applied fees error:", err);
      res.status(500).json({ message: "Failed to fetch applied fees" });
    }
  });

  app.get("/api/investor/my-fees", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const fees = await storage.getAppliedFeesByUser(userId);
      res.json(fees);
    } catch (err: any) {
      console.error("My fees error:", err);
      res.status(500).json({ message: "Failed to fetch your fees" });
    }
  });

  app.get("/api/admin/revenue/analytics", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const allFees = await storage.getAllAppliedFees(10000);

      const byCategory: Record<string, { total: number; count: number; feeTypes: string[] }> = {};
      const byFeeType: Record<string, { total: number; count: number }> = {};
      const byVehicle: Record<string, { total: number; count: number; name: string }> = {};
      const byMonth: Record<string, { total: number; count: number }> = {};

      for (const fee of allFees) {
        const amount = parseFloat(fee.feeAmount || "0");
        const catInfo = FEE_CATEGORY_MAP[fee.feeType];
        const catKey = catInfo?.category || "core";

        if (!byCategory[catKey]) byCategory[catKey] = { total: 0, count: 0, feeTypes: [] };
        byCategory[catKey].total += amount;
        byCategory[catKey].count += 1;
        if (!byCategory[catKey].feeTypes.includes(fee.feeType)) byCategory[catKey].feeTypes.push(fee.feeType);

        if (!byFeeType[fee.feeType]) byFeeType[fee.feeType] = { total: 0, count: 0 };
        byFeeType[fee.feeType].total += amount;
        byFeeType[fee.feeType].count += 1;

        if (fee.vehicleId) {
          if (!byVehicle[fee.vehicleId]) byVehicle[fee.vehicleId] = { total: 0, count: 0, name: fee.vehicleId };
          byVehicle[fee.vehicleId].total += amount;
          byVehicle[fee.vehicleId].count += 1;
        }

        const month = fee.createdAt ? new Date(fee.createdAt).toISOString().slice(0, 7) : "unknown";
        if (!byMonth[month]) byMonth[month] = { total: 0, count: 0 };
        byMonth[month].total += amount;
        byMonth[month].count += 1;
      }

      const totalRevenue = allFees.reduce((sum, f) => sum + parseFloat(f.feeAmount || "0"), 0);
      const totalTransactions = allFees.length;

      const vehicles = await storage.getAllInvestmentVehicles(req.tenantId) || [];
      for (const [vid, vData] of Object.entries(byVehicle)) {
        const v = vehicles.find((x: any) => x.id === vid);
        if (v) vData.name = (v as any).name || vid;
      }

      res.json({
        totalRevenue: parseFloat(totalRevenue.toFixed(2)),
        totalTransactions,
        byCategory,
        byFeeType,
        byVehicle,
        byMonth: Object.entries(byMonth)
          .sort(([a], [b]) => a.localeCompare(b))
          .map(([month, data]) => ({ month, ...data })),
        categories: FEE_CATEGORIES,
      });
    } catch (err: any) {
      console.error("Revenue analytics error:", err);
      res.status(500).json({ message: "Failed to fetch revenue analytics" });
    }
  });

  app.get("/api/fees/disclosure", requireAuth, async (_req, res) => {
    try {
      const schedules = await storage.getAllFeeSchedules();
      const activeSchedules = schedules.filter(s => s.isActive && !s.vehicleId);

      const disclosure = FEE_CATEGORIES.map(cat => ({
        category: cat.key,
        categoryLabel: cat.label,
        categoryDescription: cat.description,
        fees: feeTypeEnum
          .filter(ft => FEE_CATEGORY_MAP[ft]?.category === cat.key)
          .map(ft => {
            const info = FEE_CATEGORY_MAP[ft];
            const defaults = FEE_TYPE_DEFAULTS[ft];
            const activeSchedule = activeSchedules.find(s => s.feeType === ft);
            return {
              feeType: ft,
              label: info?.label || ft,
              legalLabel: info?.legalLabel || ft,
              description: info?.description || "",
              rateRange: defaults ? `${(parseFloat(defaults.minRate) * 100).toFixed(1)}% - ${(parseFloat(defaults.maxRate) * 100).toFixed(1)}%` : "Variable",
              currentRate: activeSchedule ? (activeSchedule.method === "percentage" ? `${(parseFloat(activeSchedule.rate || "0") * 100).toFixed(2)}%` : `${parseFloat(activeSchedule.flatAmount || "0").toFixed(2)} flat`) : "Not configured",
              method: activeSchedule?.method || "none",
              isActive: !!activeSchedule,
            };
          }),
      }));

      res.json({ categories: disclosure, lastUpdated: new Date().toISOString() });
    } catch (err: any) {
      console.error("Fee disclosure error:", err);
      res.status(500).json({ message: "Failed to fetch fee disclosure" });
    }
  });
}
