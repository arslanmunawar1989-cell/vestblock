import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { createAppointmentSchema, updateAppointmentSchema, assignAppointmentSchema, agentRespondAppointmentSchema } from "@shared/schema";
import { db } from "../db";
import { auditLogs } from "@shared/schema";
import { emailService, appointmentEmail } from "../services/email.service";

export function registerAppointmentRoutes(app: Express) {
  app.post("/api/appointments/create", requireAuth, async (req, res) => {
    try {
      const parsed = createAppointmentSchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({ message: "Invalid payload", errors: parsed.error.flatten().fieldErrors });
        return;
      }

      const { datetime, mode, notes, assignedToUserId } = parsed.data;
      const userId = (req as any).user.userId;
      const tenantId = (req as any).user.tenantId || null;

      const appointment = await storage.createAppointment({
        userId,
        tenantId,
        datetime,
        mode,
        status: "REQUESTED",
        notes: notes || null,
        assignedToUserId: assignedToUserId || null,
      });

      await db.insert(auditLogs).values({
        tenantId,
        actorId: userId,
        actorRole: (req as any).user.role,
        actionType: "appointment.created",
        entityType: "appointment",
        entityId: appointment.id,
        afterState: appointment,
        ipAddress: req.ip || null,
        userAgent: req.headers["user-agent"] || null,
      });

      const creator = await storage.getUser(userId);
      if (creator?.email) {
        emailService.send(appointmentEmail(creator.email, "requested", { datetime, mode }, { tenantId, appointmentId: appointment.id })).catch(() => {});
      }

      res.status(201).json(appointment);
    } catch (err: any) {
      console.error("Create appointment error:", err);
      res.status(500).json({ message: "Failed to create appointment" });
    }
  });

  app.get("/api/appointments/my", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const role = (req as any).user.role;

      let appts;
      if (role === "agent") {
        appts = await storage.getAppointmentsByAgent(userId);
      } else {
        appts = await storage.getAppointmentsByUser(userId);
      }

      const enriched = await Promise.all(appts.map(async (a) => {
        const client = await storage.getUser(a.userId);
        const agent = a.assignedToUserId ? await storage.getUser(a.assignedToUserId) : null;
        return {
          ...a,
          clientName: client?.fullName || "Unknown",
          clientEmail: client?.email || "",
          agentName: agent?.fullName || null,
          agentEmail: agent?.email || null,
        };
      }));

      res.json({ appointments: enriched });
    } catch (err: any) {
      console.error("Get appointments error:", err);
      res.status(500).json({ message: "Failed to fetch appointments" });
    }
  });

  app.get("/api/appointments/all", requireAuth, requireRole("admin"), async (_req, res) => {
    try {
      const appts = await storage.getAllAppointments();

      const enriched = await Promise.all(appts.map(async (a) => {
        const client = await storage.getUser(a.userId);
        const agent = a.assignedToUserId ? await storage.getUser(a.assignedToUserId) : null;
        return {
          ...a,
          clientName: client?.fullName || "Unknown",
          clientEmail: client?.email || "",
          agentName: agent?.fullName || null,
          agentEmail: agent?.email || null,
        };
      }));

      res.json({ appointments: enriched });
    } catch (err: any) {
      console.error("Get all appointments error:", err);
      res.status(500).json({ message: "Failed to fetch appointments" });
    }
  });

  app.get("/api/appointments/agents", requireAuth, requireRole("admin"), async (_req, res) => {
    try {
      const users = await storage.getUsers();
      const agents = users.filter(u => u.role === "agent" && u.isActive).map(u => ({
        id: u.id,
        fullName: u.fullName,
        email: u.email,
        username: u.username,
      }));
      res.json({ agents });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch agents" });
    }
  });

  app.post("/api/appointments/assign", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const parsed = assignAppointmentSchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({ message: "Invalid payload", errors: parsed.error.flatten().fieldErrors });
        return;
      }

      const { id, assignedToUserId } = parsed.data;
      const existing = await storage.getAppointmentById(id);
      if (!existing) {
        res.status(404).json({ message: "Appointment not found" });
        return;
      }

      const agent = await storage.getUser(assignedToUserId);
      if (!agent || agent.role !== "agent") {
        res.status(400).json({ message: "Invalid agent" });
        return;
      }

      const updated = await storage.updateAppointment(id, { assignedToUserId });

      await db.insert(auditLogs).values({
        tenantId: existing.tenantId,
        actorId: (req as any).user.userId,
        actorRole: (req as any).user.role,
        actionType: "appointment.assigned",
        entityType: "appointment",
        entityId: id,
        beforeState: { assignedToUserId: existing.assignedToUserId },
        afterState: { assignedToUserId },
        ipAddress: req.ip || null,
        userAgent: req.headers["user-agent"] || null,
      });

      res.json(updated);
    } catch (err: any) {
      console.error("Assign appointment error:", err);
      res.status(500).json({ message: "Failed to assign appointment" });
    }
  });

  app.post("/api/appointments/respond", requireAuth, async (req, res) => {
    try {
      const parsed = agentRespondAppointmentSchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({ message: "Invalid payload", errors: parsed.error.flatten().fieldErrors });
        return;
      }

      const { id, action, datetime, notes } = parsed.data;
      const userId = (req as any).user.userId;
      const role = (req as any).user.role;

      const existing = await storage.getAppointmentById(id);
      if (!existing) {
        res.status(404).json({ message: "Appointment not found" });
        return;
      }

      const isAdmin = role === "admin" || role === "super_admin";
      if (existing.assignedToUserId !== userId && !isAdmin) {
        res.status(403).json({ message: "Not authorized to respond to this appointment" });
        return;
      }

      const updateData: Record<string, any> = {};

      if (action === "accept") {
        updateData.status = "CONFIRMED";
      } else if (action === "reschedule") {
        if (!datetime) {
          res.status(400).json({ message: "New datetime required for reschedule" });
          return;
        }
        updateData.status = "RESCHEDULED";
        updateData.datetime = datetime;
      } else if (action === "cancel") {
        updateData.status = "CANCELLED";
      }

      if (notes) {
        updateData.notes = (existing.notes ? existing.notes + "\n---\n" : "") + notes;
      }

      const updated = await storage.updateAppointment(id, updateData);

      await db.insert(auditLogs).values({
        tenantId: existing.tenantId,
        actorId: userId,
        actorRole: role,
        actionType: `appointment.${action}`,
        entityType: "appointment",
        entityId: id,
        beforeState: { status: existing.status, datetime: existing.datetime },
        afterState: { status: updated?.status, datetime: updated?.datetime },
        ipAddress: req.ip || null,
        userAgent: req.headers["user-agent"] || null,
      });

      const client = await storage.getUser(existing.userId);
      const agent = await storage.getUser(userId);
      const eventMap: Record<string, "confirmed" | "rescheduled" | "cancelled"> = { accept: "confirmed", reschedule: "rescheduled", cancel: "cancelled" };
      const emailEvent = eventMap[action];
      if (emailEvent && client?.email) {
        emailService.send(appointmentEmail(client.email, emailEvent, { datetime: updated?.datetime || existing.datetime, mode: existing.mode, agentName: agent?.fullName }, { tenantId: existing.tenantId || undefined, appointmentId: id })).catch(() => {});
      }

      res.json(updated);
    } catch (err: any) {
      console.error("Respond appointment error:", err);
      res.status(500).json({ message: "Failed to respond to appointment" });
    }
  });

  app.post("/api/appointments/update", requireAuth, async (req, res) => {
    try {
      const parsed = updateAppointmentSchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({ message: "Invalid payload", errors: parsed.error.flatten().fieldErrors });
        return;
      }

      const { id, ...updates } = parsed.data;
      const userId = (req as any).user.userId;
      const role = (req as any).user.role;

      const existing = await storage.getAppointmentById(id);
      if (!existing) {
        res.status(404).json({ message: "Appointment not found" });
        return;
      }

      const isAdmin = role === "admin" || role === "super_admin";
      if (existing.userId !== userId && existing.assignedToUserId !== userId && !isAdmin) {
        res.status(403).json({ message: "Not authorized to update this appointment" });
        return;
      }

      const updateData: Record<string, any> = {};
      if (updates.datetime !== undefined) updateData.datetime = updates.datetime;
      if (updates.mode !== undefined) updateData.mode = updates.mode;
      if (updates.status !== undefined) updateData.status = updates.status;
      if (updates.notes !== undefined) updateData.notes = updates.notes;
      if (updates.assignedToUserId !== undefined) updateData.assignedToUserId = updates.assignedToUserId;

      const updated = await storage.updateAppointment(id, updateData);

      await db.insert(auditLogs).values({
        tenantId: existing.tenantId,
        actorId: userId,
        actorRole: role,
        actionType: "appointment.updated",
        entityType: "appointment",
        entityId: id,
        beforeState: existing,
        afterState: updated,
        ipAddress: req.ip || null,
        userAgent: req.headers["user-agent"] || null,
      });

      res.json(updated);
    } catch (err: any) {
      console.error("Update appointment error:", err);
      res.status(500).json({ message: "Failed to update appointment" });
    }
  });

  app.post("/api/appointments/complete", requireAuth, async (req, res) => {
    try {
      const { id } = req.body;
      if (!id) {
        res.status(400).json({ message: "Appointment ID required" });
        return;
      }

      const userId = (req as any).user.userId;
      const role = (req as any).user.role;

      const existing = await storage.getAppointmentById(id);
      if (!existing) {
        res.status(404).json({ message: "Appointment not found" });
        return;
      }

      const isAdmin = role === "admin" || role === "super_admin";
      if (existing.assignedToUserId !== userId && !isAdmin) {
        res.status(403).json({ message: "Not authorized" });
        return;
      }

      if (existing.status !== "CONFIRMED") {
        res.status(400).json({ message: "Only confirmed appointments can be completed" });
        return;
      }

      const updated = await storage.updateAppointment(id, { status: "COMPLETED" });

      await db.insert(auditLogs).values({
        tenantId: existing.tenantId,
        actorId: userId,
        actorRole: role,
        actionType: "appointment.completed",
        entityType: "appointment",
        entityId: id,
        beforeState: { status: existing.status },
        afterState: { status: "COMPLETED" },
        ipAddress: req.ip || null,
        userAgent: req.headers["user-agent"] || null,
      });

      res.json(updated);
    } catch (err: any) {
      console.error("Complete appointment error:", err);
      res.status(500).json({ message: "Failed to complete appointment" });
    }
  });
}
