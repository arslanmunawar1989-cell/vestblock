import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { z } from "zod";
import { db } from "../db";
import { walletTransactions, walletAccounts } from "@shared/schema";
import { eq, and, desc, gte, lt } from "drizzle-orm";
import { WALLET_CURRENCIES } from "@shared/constants";
import { logAuditFromReq } from "../lib/audit-logger";

function toCsv(headers: string[], rows: string[][]): string {
  const escape = (v: string) => {
    if (v.includes(",") || v.includes('"') || v.includes("\n")) {
      return `"${v.replace(/"/g, '""')}"`;
    }
    return v;
  };
  return [headers.map(escape).join(","), ...rows.map(r => r.map(escape).join(","))].join("\n");
}

export function registerFinanceConsoleRoutes(app: Express) {

  app.get("/api/admin/finance/deposits", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const { currency, status, from, to } = req.query;

      const accountConditions: any[] = [];
      if (req.tenantId) accountConditions.push(eq(walletAccounts.tenantId, req.tenantId));
      const allAccounts = await db.select().from(walletAccounts).where(accountConditions.length > 0 ? and(...accountConditions) : undefined);
      const accountMap = new Map(allAccounts.map(a => [a.id, a]));

      let conditions: any[] = [];
      if (req.tenantId) {
        conditions.push(eq(walletTransactions.tenantId, req.tenantId));
      }
      if (currency) {
        conditions.push(eq(walletTransactions.currency, currency as string));
      }
      if (status) {
        conditions.push(eq(walletTransactions.status, status as string));
      }
      if (from) {
        conditions.push(gte(walletTransactions.createdAt, from as string));
      }
      if (to) {
        conditions.push(lt(walletTransactions.createdAt, to as string));
      }

      const depositTypes = ["DEPOSIT", "CRYPTO_DEPOSIT"];
      const allTxs = await db.select().from(walletTransactions)
        .where(conditions.length > 0 ? and(...conditions) : undefined)
        .orderBy(desc(walletTransactions.createdAt));

      const deposits = allTxs.filter(tx => depositTypes.includes(tx.type));

      const enriched = await Promise.all(deposits.map(async (tx) => {
        const acc = accountMap.get(tx.walletAccountId);
        let user = null;
        if (acc?.userId) {
          user = await storage.getUser(acc.userId);
        }
        return {
          ...tx,
          userName: user?.fullName || user?.username || "Unknown",
          userEmail: user?.email || "",
          userId: acc?.userId || "",
        };
      }));

      const totalAmount = enriched.reduce((sum, d) => sum + parseFloat(d.amount), 0);
      const pendingCount = enriched.filter(d => d.status === "PENDING").length;
      const completedCount = enriched.filter(d => d.status === "COMPLETED").length;

      res.json({
        deposits: enriched,
        stats: {
          totalCount: enriched.length,
          totalAmount: totalAmount.toFixed(2),
          pendingCount,
          completedCount,
        },
      });
    } catch (err: any) {
      console.error("Admin deposits error:", err);
      res.status(500).json({ message: "Failed to fetch deposits" });
    }
  });

  app.get("/api/admin/finance/deposits/export", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const { currency } = req.query;
      const expAccConds: any[] = [];
      if (req.tenantId) expAccConds.push(eq(walletAccounts.tenantId, req.tenantId));
      const allAccounts = await db.select().from(walletAccounts).where(expAccConds.length > 0 ? and(...expAccConds) : undefined);
      const accountMap = new Map(allAccounts.map(a => [a.id, a]));

      let conditions: any[] = [];
      if (req.tenantId) {
        conditions.push(eq(walletTransactions.tenantId, req.tenantId));
      }
      if (currency) {
        conditions.push(eq(walletTransactions.currency, currency as string));
      }

      const allTxs = await db.select().from(walletTransactions)
        .where(conditions.length > 0 ? and(...conditions) : undefined)
        .orderBy(desc(walletTransactions.createdAt));

      const deposits = allTxs.filter(tx => ["DEPOSIT", "CRYPTO_DEPOSIT"].includes(tx.type));

      const headers = ["ID", "Date", "Type", "Amount", "Currency", "Status", "Description", "Reference"];
      const rows = deposits.map(d => [
        d.id,
        d.createdAt ? new Date(d.createdAt).toISOString() : "",
        d.type,
        d.amount,
        d.currency,
        d.status,
        d.description || "",
        d.referenceId || "",
      ]);

      const csv = toCsv(headers, rows);
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="deposits_${new Date().toISOString().split("T")[0]}.csv"`);
      res.send(csv);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to export deposits" });
    }
  });

  app.get("/api/admin/finance/crypto-deposits", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const { status } = req.query;
      let intents = await storage.getAllCryptoDepositIntents(req.tenantId);

      if (status) {
        intents = intents.filter(i => i.status === status);
      }

      const enriched = await Promise.all(intents.map(async (intent) => {
        const user = await storage.getUser(intent.userId);
        return {
          ...intent,
          userName: user?.fullName || user?.username || "Unknown",
          userEmail: user?.email || "",
        };
      }));

      const pendingReview = intents.filter(i => i.status === "PENDING" || i.status === "AML_HOLD").length;
      const confirmed = intents.filter(i => i.status === "CONFIRMED").length;
      const rejected = intents.filter(i => i.status === "REJECTED").length;
      const totalConfirmedAmount = intents
        .filter(i => i.status === "CONFIRMED")
        .reduce((sum, i) => sum + parseFloat(String(i.amount)), 0);

      res.json({
        deposits: enriched,
        stats: {
          totalCount: intents.length,
          pendingReview,
          confirmed,
          rejected,
          totalConfirmedAmount: totalConfirmedAmount.toFixed(2),
        },
      });
    } catch (err: any) {
      console.error("Admin crypto deposits error:", err);
      res.status(500).json({ message: "Failed to fetch crypto deposits" });
    }
  });

  const cryptoReviewSchema = z.object({
    action: z.enum(["approve", "reject", "aml_hold", "clear"]),
    notes: z.string().optional(),
    txHash: z.string().optional(),
  });

  app.post("/api/admin/finance/crypto-deposits/:id/review", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const parsed = cryptoReviewSchema.parse(req.body);
      const intent = await storage.getCryptoDepositIntentById(req.params.id);
      if (!intent) return res.status(404).json({ message: "Crypto deposit not found" });

      const validTransitions: Record<string, string[]> = {
        approve: ["PENDING"],
        reject: ["PENDING", "AML_HOLD"],
        aml_hold: ["PENDING"],
        clear: ["AML_HOLD"],
      };

      const allowed = validTransitions[parsed.action] || [];
      if (!allowed.includes(intent.status)) {
        return res.status(409).json({
          message: `Cannot ${parsed.action} a deposit with status ${intent.status}`,
        });
      }

      const adminId = (req as any).user.userId;
      const now = new Date().toISOString();

      const statusMap: Record<string, string> = {
        approve: "CONFIRMED",
        reject: "REJECTED",
        aml_hold: "AML_HOLD",
        clear: "CONFIRMED",
      };

      const amlStatusMap: Record<string, string> = {
        approve: "CLEAR",
        reject: "FLAGGED",
        aml_hold: "HOLD",
        clear: "CLEARED",
      };

      const updates: Record<string, any> = {
        status: statusMap[parsed.action],
        amlStatus: amlStatusMap[parsed.action],
        reviewedBy: adminId,
        reviewedAt: now,
        reviewNotes: parsed.notes || null,
      };

      if (parsed.action === "approve" || parsed.action === "clear") {
        updates.confirmedAt = now;
        if (parsed.txHash) updates.txHash = parsed.txHash;
      }

      const updated = await storage.updateCryptoDepositIntent(intent.id, updates);

      await logAuditFromReq(req, "CRYPTO_DEPOSIT_REVIEWED", "crypto_deposit_intent", intent.id, {
        reason: `Crypto deposit ${parsed.action}: ${intent.chain} ${intent.currency} ${intent.amount}`,
        beforeState: { status: intent.status, amlStatus: intent.amlStatus },
        afterState: { status: updates.status, amlStatus: updates.amlStatus },
        metadata: { action: parsed.action, notes: parsed.notes },
      });

      if ((parsed.action === "approve" || parsed.action === "clear") && updated) {
        const existingTxs = await db.select().from(walletTransactions)
          .where(and(
            eq(walletTransactions.referenceId, intent.id),
            eq(walletTransactions.type, "CRYPTO_DEPOSIT"),
          ));

        if (existingTxs.length === 0) {
          const wallet = await storage.getOrCreateWallet(intent.userId, intent.currency);
          await storage.createWalletTransaction({
            walletAccountId: wallet.id,
            type: "CRYPTO_DEPOSIT",
            amount: String(intent.amount),
            currency: intent.currency,
            status: "COMPLETED",
            description: `Crypto deposit ${intent.chain} ${intent.currency} - ${parsed.action}`,
            referenceId: intent.id,
          });
        }
      }

      res.json(updated);
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Crypto review error:", err);
      res.status(500).json({ message: "Failed to review crypto deposit" });
    }
  });

  app.get("/api/admin/finance/crypto-deposits/export", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const intents = await storage.getAllCryptoDepositIntents(req.tenantId);
      const headers = ["ID", "Date", "User", "Chain", "Currency", "Amount", "Status", "AML Status", "TX Hash"];
      const rows = await Promise.all(intents.map(async (i) => {
        const user = await storage.getUser(i.userId);
        return [
          i.id,
          i.createdAt ? new Date(i.createdAt).toISOString() : "",
          user?.fullName || user?.username || "",
          i.chain,
          i.currency,
          String(i.amount),
          i.status,
          i.amlStatus || "",
          i.txHash || "",
        ];
      }));
      const csv = toCsv(headers, rows);
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="crypto_deposits_${new Date().toISOString().split("T")[0]}.csv"`);
      res.send(csv);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to export crypto deposits" });
    }
  });

  app.get("/api/admin/finance/fx/overview", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const [rates, quotes, conversions, transactions] = await Promise.all([
        storage.getAllFxRates(),
        storage.getAllFxQuotes(),
        storage.getFxConversionRequests(),
        storage.getAllFxTransactions(req.tenantId),
      ]);

      const activeRates = rates.filter(r => r.isActive);
      const pendingConversions = conversions.filter(c => c.status === "PENDING");
      const totalVolume = transactions.reduce((sum, t) => sum + parseFloat(t.amountFrom), 0);

      res.json({
        rates: activeRates,
        allRates: rates,
        recentQuotes: quotes.slice(0, 50),
        conversions,
        recentTransactions: transactions.slice(0, 50),
        stats: {
          activeRateCount: activeRates.length,
          totalRateCount: rates.length,
          pendingConversionCount: pendingConversions.length,
          totalQuotes: quotes.length,
          totalTransactions: transactions.length,
          totalVolume: totalVolume.toFixed(2),
        },
      });
    } catch (err: any) {
      console.error("FX overview error:", err);
      res.status(500).json({ message: "Failed to fetch FX overview" });
    }
  });

  app.get("/api/admin/finance/fx/export", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const transactions = await storage.getAllFxTransactions(req.tenantId);
      const headers = ["ID", "Date", "User ID", "From", "To", "Amount From", "Amount To", "Rate", "Status"];
      const rows = transactions.map(t => [
        t.id,
        t.createdAt ? new Date(t.createdAt).toISOString() : "",
        t.userId,
        t.fromCurrency,
        t.toCurrency,
        t.amountFrom,
        t.amountTo,
        t.rate || "",
        t.status,
      ]);
      const csv = toCsv(headers, rows);
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="fx_transactions_${new Date().toISOString().split("T")[0]}.csv"`);
      res.send(csv);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to export FX data" });
    }
  });

  app.get("/api/admin/finance/distributions/overview", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const distributions = await storage.getDistributions(req.tenantId);

      const enriched = await Promise.all(distributions.map(async (d) => {
        const asset = await storage.getAsset(d.assetId);
        const payouts = await storage.getDistributionPayoutsByDistribution(d.id);
        let waterfall = null;
        if (d.waterfallCalculationId) {
          waterfall = await storage.getWaterfallCalculation(d.waterfallCalculationId);
        }
        return {
          ...d,
          assetName: asset?.name || "Unknown",
          assetSymbol: asset?.symbol || "",
          payoutCount: payouts.length,
          totalPaidOut: payouts.reduce((sum, p) => sum + parseFloat(p.payoutAmount), 0).toFixed(2),
          waterfallPeriod: waterfall?.period || null,
        };
      }));

      const totalDistributed = enriched.reduce((sum, d) => sum + parseFloat(d.totalPaidOut), 0);

      res.json({
        distributions: enriched,
        stats: {
          totalDistributions: distributions.length,
          totalDistributed: totalDistributed.toFixed(2),
        },
      });
    } catch (err: any) {
      console.error("Distributions overview error:", err);
      res.status(500).json({ message: "Failed to fetch distributions overview" });
    }
  });

  app.get("/api/admin/finance/distributions/export", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const distributions = await storage.getDistributions(req.tenantId);

      const headers = ["ID", "Date", "Asset ID", "Per Token Amount", "Currency", "Total Amount", "Snapshot ID", "Created"];
      const rows = distributions.map(d => [
        d.id,
        d.distributionDate,
        d.assetId,
        d.perTokenAmount,
        d.currency,
        d.totalAmount,
        d.snapshotId || "",
        d.createdAt ? new Date(d.createdAt as any).toISOString() : "",
      ]);
      const csv = toCsv(headers, rows);
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="distributions_${new Date().toISOString().split("T")[0]}.csv"`);
      res.send(csv);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to export distributions" });
    }
  });

  app.get("/api/admin/finance/discrepancies", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const date = (req.query.date as string) || new Date().toISOString().split("T")[0];
      const currencies = [...WALLET_CURRENCIES];
      const flags: any[] = [];

      for (const currency of currencies) {
        const accForCurrConds: any[] = [eq(walletAccounts.currency, currency)];
        if (req.tenantId) accForCurrConds.push(eq(walletAccounts.tenantId, req.tenantId));
        const accountsForCurrency = await db.select({ id: walletAccounts.id, userId: walletAccounts.userId })
          .from(walletAccounts)
          .where(and(...accForCurrConds));

        if (accountsForCurrency.length === 0) continue;

        let walletBalance = 0;
        for (const acc of accountsForCurrency) {
          const bal = await storage.getComputedBalance(acc.id);
          walletBalance += parseFloat(bal.available);
        }

        const [dayStart, dayEnd] = dayRange(date);
        const reconTxConds: any[] = [
          eq(walletTransactions.currency, currency),
          eq(walletTransactions.status, "COMPLETED"),
          lt(walletTransactions.createdAt, dayEnd),
        ];
        if (req.tenantId) reconTxConds.push(eq(walletTransactions.tenantId, req.tenantId));
        const allCompletedTxs = await db.select().from(walletTransactions)
          .where(and(...reconTxConds));

        let ledgerBalance = 0;
        const creditTypes = ["DEPOSIT", "REFUND", "DIVIDEND", "TRADE_SELL", "CRYPTO_DEPOSIT"];
        const debitTypes = ["WITHDRAW", "INVEST_CAPTURE", "FEE", "TRADE_BUY"];

        for (const tx of allCompletedTxs) {
          const amt = parseFloat(tx.amount);
          if (tx.type === "FX_CONVERT") {
            ledgerBalance += amt;
          } else if (creditTypes.includes(tx.type)) {
            ledgerBalance += amt;
          } else if (debitTypes.includes(tx.type)) {
            ledgerBalance -= amt;
          }
        }

        const discrepancy = Math.abs(round2(ledgerBalance) - round2(walletBalance));
        if (discrepancy > 0.01) {
          flags.push({
            currency,
            date,
            ledgerBalance: round2(ledgerBalance),
            walletBalance: round2(walletBalance),
            discrepancy: round2(discrepancy),
            severity: discrepancy > 100 ? "critical" : discrepancy > 10 ? "warning" : "info",
          });
        }
      }

      res.json({
        date,
        hasDiscrepancies: flags.length > 0,
        flags,
        checkedCurrencies: currencies.length,
      });
    } catch (err: any) {
      console.error("Discrepancy check error:", err);
      res.status(500).json({ message: "Failed to check discrepancies" });
    }
  });

  app.get("/api/admin/finance/withdrawals/export", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const withdrawals = await storage.getAllWithdrawalRequests(req.tenantId);
      const headers = ["ID", "Date", "User ID", "Amount", "Currency", "Fee", "Net Amount", "Status", "Bank Account", "Payout Reference"];
      const rows = withdrawals.map(w => [
        w.id,
        w.requestedAt ? new Date(w.requestedAt).toISOString() : "",
        w.userId,
        w.amount,
        w.currency,
        w.fee,
        w.netAmount,
        w.status,
        w.bankAccountId,
        w.payoutReference || "",
      ]);
      const csv = toCsv(headers, rows);
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="withdrawals_${new Date().toISOString().split("T")[0]}.csv"`);
      res.send(csv);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to export withdrawals" });
    }
  });

  const depositConfirmSchema = z.object({
    action: z.enum(["confirm", "reject"]),
    notes: z.string().optional(),
  });

  app.post("/api/admin/finance/deposits/:id/confirm", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const parsed = depositConfirmSchema.parse(req.body);
      const id = req.params.id;

      const rows = await db.select().from(walletTransactions).where(eq(walletTransactions.id, id));
      if (rows.length === 0) return res.status(404).json({ message: "Transaction not found" });

      const tx = rows[0];

      if (tx.type !== "DEPOSIT" || tx.status !== "PENDING") {
        return res.status(409).json({ message: "Only PENDING deposits can be confirmed or rejected" });
      }

      const newStatus = parsed.action === "confirm" ? "COMPLETED" : "FAILED";

      await db.update(walletTransactions).set({ status: newStatus }).where(eq(walletTransactions.id, id));

      await logAuditFromReq(req, "DEPOSIT_REVIEWED", "wallet_transaction", id, {
        reason: parsed.notes || `Deposit ${parsed.action}ed`,
        beforeState: { status: tx.status },
        afterState: { status: newStatus },
      });

      const updatedRows = await db.select().from(walletTransactions).where(eq(walletTransactions.id, id));
      res.json(updatedRows[0]);
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Deposit confirm error:", err);
      res.status(500).json({ message: "Failed to process deposit" });
    }
  });
}

function dayRange(dateStr: string): [string, string] {
  const start = new Date(dateStr + "T00:00:00.000Z");
  const nextDay = new Date(start);
  nextDay.setUTCDate(nextDay.getUTCDate() + 1);
  return [start.toISOString(), nextDay.toISOString()];
}

function round2(n: number): number {
  return parseFloat(n.toFixed(2));
}
