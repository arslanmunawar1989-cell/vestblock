import type { Express, Request, Response, NextFunction } from "express";
import { db } from "../db";
import { requireAuth, requireRole } from "../auth";
import { eq, desc, asc, and, sql } from "drizzle-orm";
import { z } from "zod";
import {
  cmsPages,
  cmsPageSections,
  cmsGlobalContent,
  cmsPropertyListings,
  cmsBlogPosts,
  cmsFaqItems,
  cmsGuides,
  cmsGlossaryTerms,
  cmsFeeConfigs,
  cmsExitWindowSchedules,
  cmsAuditLog,
} from "@shared/schema";

function requireCmsAccess(req: Request, res: Response, next: NextFunction) {
  const user = (req as any).user;
  if (!user) {
    return res.status(401).json({ message: "Authentication required" });
  }
  if (user.role === "admin" || user.role === "cms") {
    return next();
  }
  return res.status(403).json({ message: "CMS access required" });
}

async function logCmsAudit(userId: string, entityType: string, entityId: string, action: string, diffJson?: any) {
  await db.insert(cmsAuditLog).values({ userId, entityType, entityId, action, diffJson });
}

export function registerCmsRoutes(app: Express) {

  // ─── Pages CRUD ───────────────────────────────────────────────────

  app.get("/api/cms/pages", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const { region, status } = req.query;
      const conditions = [];
      if (region) conditions.push(eq(cmsPages.region, region as string));
      if (status) conditions.push(eq(cmsPages.status, status as string));
      const rows = await db.select().from(cmsPages)
        .where(conditions.length ? and(...conditions) : undefined)
        .orderBy(desc(cmsPages.updatedAt));
      res.json(rows);
    } catch (err: any) {
      console.error("CMS pages list error:", err);
      res.status(500).json({ message: "Failed to fetch pages" });
    }
  });

  app.post("/api/cms/pages", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [page] = await db.insert(cmsPages).values(req.body).returning();
      await logCmsAudit((req as any).user.userId, "page", page.id, "CREATE");
      res.status(201).json(page);
    } catch (err: any) {
      console.error("CMS page create error:", err);
      res.status(500).json({ message: "Failed to create page" });
    }
  });

  app.get("/api/cms/pages/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [page] = await db.select().from(cmsPages).where(eq(cmsPages.id, req.params.id));
      if (!page) return res.status(404).json({ message: "Page not found" });
      const sections = await db.select().from(cmsPageSections)
        .where(eq(cmsPageSections.pageId, req.params.id))
        .orderBy(asc(cmsPageSections.orderIndex));
      res.json({ ...page, sections });
    } catch (err: any) {
      console.error("CMS page get error:", err);
      res.status(500).json({ message: "Failed to fetch page" });
    }
  });

  app.put("/api/cms/pages/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [updated] = await db.update(cmsPages)
        .set({ ...req.body, updatedAt: new Date().toISOString() })
        .where(eq(cmsPages.id, req.params.id))
        .returning();
      if (!updated) return res.status(404).json({ message: "Page not found" });
      await logCmsAudit((req as any).user.userId, "page", updated.id, "UPDATE", req.body);
      res.json(updated);
    } catch (err: any) {
      console.error("CMS page update error:", err);
      res.status(500).json({ message: "Failed to update page" });
    }
  });

  app.delete("/api/cms/pages/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      await db.delete(cmsPageSections).where(eq(cmsPageSections.pageId, req.params.id));
      const [deleted] = await db.delete(cmsPages).where(eq(cmsPages.id, req.params.id)).returning();
      if (!deleted) return res.status(404).json({ message: "Page not found" });
      await logCmsAudit((req as any).user.userId, "page", deleted.id, "DELETE");
      res.json({ message: "Page deleted" });
    } catch (err: any) {
      console.error("CMS page delete error:", err);
      res.status(500).json({ message: "Failed to delete page" });
    }
  });

  app.post("/api/cms/pages/:id/publish", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [updated] = await db.update(cmsPages)
        .set({ status: "PUBLISHED", updatedAt: new Date().toISOString() })
        .where(eq(cmsPages.id, req.params.id))
        .returning();
      if (!updated) return res.status(404).json({ message: "Page not found" });
      await logCmsAudit((req as any).user.userId, "page", updated.id, "PUBLISH");
      res.json(updated);
    } catch (err: any) {
      console.error("CMS page publish error:", err);
      res.status(500).json({ message: "Failed to publish page" });
    }
  });

  app.post("/api/cms/pages/:id/unpublish", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [updated] = await db.update(cmsPages)
        .set({ status: "DRAFT", updatedAt: new Date().toISOString() })
        .where(eq(cmsPages.id, req.params.id))
        .returning();
      if (!updated) return res.status(404).json({ message: "Page not found" });
      await logCmsAudit((req as any).user.userId, "page", updated.id, "UNPUBLISH");
      res.json(updated);
    } catch (err: any) {
      console.error("CMS page unpublish error:", err);
      res.status(500).json({ message: "Failed to unpublish page" });
    }
  });

  // ─── Page Sections CRUD ───────────────────────────────────────────

  app.get("/api/cms/pages/:pageId/sections", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const sections = await db.select().from(cmsPageSections)
        .where(eq(cmsPageSections.pageId, req.params.pageId))
        .orderBy(asc(cmsPageSections.orderIndex));
      res.json(sections);
    } catch (err: any) {
      console.error("CMS sections list error:", err);
      res.status(500).json({ message: "Failed to fetch sections" });
    }
  });

  app.post("/api/cms/pages/:pageId/sections", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [section] = await db.insert(cmsPageSections)
        .values({ ...req.body, pageId: req.params.pageId })
        .returning();
      await logCmsAudit((req as any).user.userId, "page_section", section.id, "CREATE");
      res.status(201).json(section);
    } catch (err: any) {
      console.error("CMS section create error:", err);
      res.status(500).json({ message: "Failed to create section" });
    }
  });

  app.put("/api/cms/sections/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [updated] = await db.update(cmsPageSections)
        .set({ ...req.body, updatedAt: new Date().toISOString() })
        .where(eq(cmsPageSections.id, req.params.id))
        .returning();
      if (!updated) return res.status(404).json({ message: "Section not found" });
      await logCmsAudit((req as any).user.userId, "page_section", updated.id, "UPDATE", req.body);
      res.json(updated);
    } catch (err: any) {
      console.error("CMS section update error:", err);
      res.status(500).json({ message: "Failed to update section" });
    }
  });

  app.delete("/api/cms/sections/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [deleted] = await db.delete(cmsPageSections)
        .where(eq(cmsPageSections.id, req.params.id))
        .returning();
      if (!deleted) return res.status(404).json({ message: "Section not found" });
      await logCmsAudit((req as any).user.userId, "page_section", deleted.id, "DELETE");
      res.json({ message: "Section deleted" });
    } catch (err: any) {
      console.error("CMS section delete error:", err);
      res.status(500).json({ message: "Failed to delete section" });
    }
  });

  app.put("/api/cms/sections/:id/toggle", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [existing] = await db.select().from(cmsPageSections).where(eq(cmsPageSections.id, req.params.id));
      if (!existing) return res.status(404).json({ message: "Section not found" });
      const [updated] = await db.update(cmsPageSections)
        .set({ isEnabled: !existing.isEnabled, updatedAt: new Date().toISOString() })
        .where(eq(cmsPageSections.id, req.params.id))
        .returning();
      await logCmsAudit((req as any).user.userId, "page_section", updated.id, "UPDATE", { isEnabled: updated.isEnabled });
      res.json(updated);
    } catch (err: any) {
      console.error("CMS section toggle error:", err);
      res.status(500).json({ message: "Failed to toggle section" });
    }
  });

  app.put("/api/cms/pages/:pageId/sections/reorder", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const items: { id: string; orderIndex: number }[] = req.body;
      for (const item of items) {
        await db.update(cmsPageSections)
          .set({ orderIndex: item.orderIndex, updatedAt: new Date().toISOString() })
          .where(eq(cmsPageSections.id, item.id));
      }
      const sections = await db.select().from(cmsPageSections)
        .where(eq(cmsPageSections.pageId, req.params.pageId))
        .orderBy(asc(cmsPageSections.orderIndex));
      res.json(sections);
    } catch (err: any) {
      console.error("CMS sections reorder error:", err);
      res.status(500).json({ message: "Failed to reorder sections" });
    }
  });

  // ─── Global Content CRUD ──────────────────────────────────────────

  app.get("/api/cms/globals", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const { region } = req.query;
      const conditions = [];
      if (region) conditions.push(eq(cmsGlobalContent.region, region as string));
      const rows = await db.select().from(cmsGlobalContent)
        .where(conditions.length ? and(...conditions) : undefined)
        .orderBy(desc(cmsGlobalContent.updatedAt));
      res.json(rows);
    } catch (err: any) {
      console.error("CMS globals list error:", err);
      res.status(500).json({ message: "Failed to fetch global content" });
    }
  });

  app.post("/api/cms/globals", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [item] = await db.insert(cmsGlobalContent).values(req.body).returning();
      await logCmsAudit((req as any).user.userId, "global_content", item.id, "CREATE");
      res.status(201).json(item);
    } catch (err: any) {
      console.error("CMS global create error:", err);
      res.status(500).json({ message: "Failed to create global content" });
    }
  });

  app.put("/api/cms/globals/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [updated] = await db.update(cmsGlobalContent)
        .set({ ...req.body, updatedAt: new Date().toISOString() })
        .where(eq(cmsGlobalContent.id, req.params.id))
        .returning();
      if (!updated) return res.status(404).json({ message: "Global content not found" });
      await logCmsAudit((req as any).user.userId, "global_content", updated.id, "UPDATE", req.body);
      res.json(updated);
    } catch (err: any) {
      console.error("CMS global update error:", err);
      res.status(500).json({ message: "Failed to update global content" });
    }
  });

  app.delete("/api/cms/globals/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [deleted] = await db.delete(cmsGlobalContent)
        .where(eq(cmsGlobalContent.id, req.params.id))
        .returning();
      if (!deleted) return res.status(404).json({ message: "Global content not found" });
      await logCmsAudit((req as any).user.userId, "global_content", deleted.id, "DELETE");
      res.json({ message: "Global content deleted" });
    } catch (err: any) {
      console.error("CMS global delete error:", err);
      res.status(500).json({ message: "Failed to delete global content" });
    }
  });

  // ─── Property Listings CRUD ───────────────────────────────────────

  app.get("/api/cms/properties", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const { region, status } = req.query;
      const conditions = [];
      if (region) conditions.push(eq(cmsPropertyListings.region, region as string));
      if (status) conditions.push(eq(cmsPropertyListings.status, status as string));
      const rows = await db.select().from(cmsPropertyListings)
        .where(conditions.length ? and(...conditions) : undefined)
        .orderBy(desc(cmsPropertyListings.updatedAt));
      res.json(rows);
    } catch (err: any) {
      console.error("CMS properties list error:", err);
      res.status(500).json({ message: "Failed to fetch properties" });
    }
  });

  app.post("/api/cms/properties", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [item] = await db.insert(cmsPropertyListings).values(req.body).returning();
      await logCmsAudit((req as any).user.userId, "property_listing", item.id, "CREATE");
      res.status(201).json(item);
    } catch (err: any) {
      console.error("CMS property create error:", err);
      res.status(500).json({ message: "Failed to create property" });
    }
  });

  app.get("/api/cms/properties/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [item] = await db.select().from(cmsPropertyListings)
        .where(eq(cmsPropertyListings.id, req.params.id));
      if (!item) return res.status(404).json({ message: "Property not found" });
      res.json(item);
    } catch (err: any) {
      console.error("CMS property get error:", err);
      res.status(500).json({ message: "Failed to fetch property" });
    }
  });

  app.put("/api/cms/properties/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [updated] = await db.update(cmsPropertyListings)
        .set({ ...req.body, updatedAt: new Date().toISOString() })
        .where(eq(cmsPropertyListings.id, req.params.id))
        .returning();
      if (!updated) return res.status(404).json({ message: "Property not found" });
      await logCmsAudit((req as any).user.userId, "property_listing", updated.id, "UPDATE", req.body);
      res.json(updated);
    } catch (err: any) {
      console.error("CMS property update error:", err);
      res.status(500).json({ message: "Failed to update property" });
    }
  });

  app.delete("/api/cms/properties/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [deleted] = await db.delete(cmsPropertyListings)
        .where(eq(cmsPropertyListings.id, req.params.id))
        .returning();
      if (!deleted) return res.status(404).json({ message: "Property not found" });
      await logCmsAudit((req as any).user.userId, "property_listing", deleted.id, "DELETE");
      res.json({ message: "Property deleted" });
    } catch (err: any) {
      console.error("CMS property delete error:", err);
      res.status(500).json({ message: "Failed to delete property" });
    }
  });

  // ─── Blog Posts CRUD ──────────────────────────────────────────────

  app.get("/api/cms/blog", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const { region, status, category } = req.query;
      const conditions = [];
      if (region) conditions.push(eq(cmsBlogPosts.region, region as string));
      if (status) conditions.push(eq(cmsBlogPosts.status, status as string));
      if (category) conditions.push(eq(cmsBlogPosts.category, category as string));
      const rows = await db.select().from(cmsBlogPosts)
        .where(conditions.length ? and(...conditions) : undefined)
        .orderBy(desc(cmsBlogPosts.updatedAt));
      res.json(rows);
    } catch (err: any) {
      console.error("CMS blog list error:", err);
      res.status(500).json({ message: "Failed to fetch blog posts" });
    }
  });

  app.post("/api/cms/blog", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [item] = await db.insert(cmsBlogPosts).values(req.body).returning();
      await logCmsAudit((req as any).user.userId, "blog_post", item.id, "CREATE");
      res.status(201).json(item);
    } catch (err: any) {
      console.error("CMS blog create error:", err);
      res.status(500).json({ message: "Failed to create blog post" });
    }
  });

  app.get("/api/cms/blog/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [item] = await db.select().from(cmsBlogPosts)
        .where(eq(cmsBlogPosts.id, req.params.id));
      if (!item) return res.status(404).json({ message: "Blog post not found" });
      res.json(item);
    } catch (err: any) {
      console.error("CMS blog get error:", err);
      res.status(500).json({ message: "Failed to fetch blog post" });
    }
  });

  app.put("/api/cms/blog/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [updated] = await db.update(cmsBlogPosts)
        .set({ ...req.body, updatedAt: new Date().toISOString() })
        .where(eq(cmsBlogPosts.id, req.params.id))
        .returning();
      if (!updated) return res.status(404).json({ message: "Blog post not found" });
      await logCmsAudit((req as any).user.userId, "blog_post", updated.id, "UPDATE", req.body);
      res.json(updated);
    } catch (err: any) {
      console.error("CMS blog update error:", err);
      res.status(500).json({ message: "Failed to update blog post" });
    }
  });

  app.delete("/api/cms/blog/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [deleted] = await db.delete(cmsBlogPosts)
        .where(eq(cmsBlogPosts.id, req.params.id))
        .returning();
      if (!deleted) return res.status(404).json({ message: "Blog post not found" });
      await logCmsAudit((req as any).user.userId, "blog_post", deleted.id, "DELETE");
      res.json({ message: "Blog post deleted" });
    } catch (err: any) {
      console.error("CMS blog delete error:", err);
      res.status(500).json({ message: "Failed to delete blog post" });
    }
  });

  // ─── FAQ Items CRUD ───────────────────────────────────────────────

  app.get("/api/cms/faq", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const { region, category } = req.query;
      const conditions = [];
      if (region) conditions.push(eq(cmsFaqItems.region, region as string));
      if (category) conditions.push(eq(cmsFaqItems.category, category as string));
      const rows = await db.select().from(cmsFaqItems)
        .where(conditions.length ? and(...conditions) : undefined)
        .orderBy(asc(cmsFaqItems.orderIndex));
      res.json(rows);
    } catch (err: any) {
      console.error("CMS faq list error:", err);
      res.status(500).json({ message: "Failed to fetch FAQ items" });
    }
  });

  app.post("/api/cms/faq", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [item] = await db.insert(cmsFaqItems).values(req.body).returning();
      await logCmsAudit((req as any).user.userId, "faq_item", item.id, "CREATE");
      res.status(201).json(item);
    } catch (err: any) {
      console.error("CMS faq create error:", err);
      res.status(500).json({ message: "Failed to create FAQ item" });
    }
  });

  app.put("/api/cms/faq/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [updated] = await db.update(cmsFaqItems)
        .set({ ...req.body, updatedAt: new Date().toISOString() })
        .where(eq(cmsFaqItems.id, req.params.id))
        .returning();
      if (!updated) return res.status(404).json({ message: "FAQ item not found" });
      await logCmsAudit((req as any).user.userId, "faq_item", updated.id, "UPDATE", req.body);
      res.json(updated);
    } catch (err: any) {
      console.error("CMS faq update error:", err);
      res.status(500).json({ message: "Failed to update FAQ item" });
    }
  });

  app.delete("/api/cms/faq/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [deleted] = await db.delete(cmsFaqItems)
        .where(eq(cmsFaqItems.id, req.params.id))
        .returning();
      if (!deleted) return res.status(404).json({ message: "FAQ item not found" });
      await logCmsAudit((req as any).user.userId, "faq_item", deleted.id, "DELETE");
      res.json({ message: "FAQ item deleted" });
    } catch (err: any) {
      console.error("CMS faq delete error:", err);
      res.status(500).json({ message: "Failed to delete FAQ item" });
    }
  });

  // ─── Guides CRUD ──────────────────────────────────────────────────

  app.get("/api/cms/guides", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const rows = await db.select().from(cmsGuides).orderBy(desc(cmsGuides.updatedAt));
      res.json(rows);
    } catch (err: any) {
      console.error("CMS guides list error:", err);
      res.status(500).json({ message: "Failed to fetch guides" });
    }
  });

  app.post("/api/cms/guides", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [item] = await db.insert(cmsGuides).values(req.body).returning();
      await logCmsAudit((req as any).user.userId, "guide", item.id, "CREATE");
      res.status(201).json(item);
    } catch (err: any) {
      console.error("CMS guide create error:", err);
      res.status(500).json({ message: "Failed to create guide" });
    }
  });

  app.get("/api/cms/guides/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [item] = await db.select().from(cmsGuides)
        .where(eq(cmsGuides.id, req.params.id));
      if (!item) return res.status(404).json({ message: "Guide not found" });
      res.json(item);
    } catch (err: any) {
      console.error("CMS guide get error:", err);
      res.status(500).json({ message: "Failed to fetch guide" });
    }
  });

  app.put("/api/cms/guides/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [updated] = await db.update(cmsGuides)
        .set({ ...req.body, updatedAt: new Date().toISOString() })
        .where(eq(cmsGuides.id, req.params.id))
        .returning();
      if (!updated) return res.status(404).json({ message: "Guide not found" });
      await logCmsAudit((req as any).user.userId, "guide", updated.id, "UPDATE", req.body);
      res.json(updated);
    } catch (err: any) {
      console.error("CMS guide update error:", err);
      res.status(500).json({ message: "Failed to update guide" });
    }
  });

  app.delete("/api/cms/guides/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [deleted] = await db.delete(cmsGuides)
        .where(eq(cmsGuides.id, req.params.id))
        .returning();
      if (!deleted) return res.status(404).json({ message: "Guide not found" });
      await logCmsAudit((req as any).user.userId, "guide", deleted.id, "DELETE");
      res.json({ message: "Guide deleted" });
    } catch (err: any) {
      console.error("CMS guide delete error:", err);
      res.status(500).json({ message: "Failed to delete guide" });
    }
  });

  // ─── Glossary Terms CRUD ──────────────────────────────────────────

  app.get("/api/cms/glossary", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const rows = await db.select().from(cmsGlossaryTerms).orderBy(asc(cmsGlossaryTerms.orderIndex));
      res.json(rows);
    } catch (err: any) {
      console.error("CMS glossary list error:", err);
      res.status(500).json({ message: "Failed to fetch glossary terms" });
    }
  });

  app.post("/api/cms/glossary", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [item] = await db.insert(cmsGlossaryTerms).values(req.body).returning();
      await logCmsAudit((req as any).user.userId, "glossary_term", item.id, "CREATE");
      res.status(201).json(item);
    } catch (err: any) {
      console.error("CMS glossary create error:", err);
      res.status(500).json({ message: "Failed to create glossary term" });
    }
  });

  app.put("/api/cms/glossary/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [updated] = await db.update(cmsGlossaryTerms)
        .set({ ...req.body, updatedAt: new Date().toISOString() })
        .where(eq(cmsGlossaryTerms.id, req.params.id))
        .returning();
      if (!updated) return res.status(404).json({ message: "Glossary term not found" });
      await logCmsAudit((req as any).user.userId, "glossary_term", updated.id, "UPDATE", req.body);
      res.json(updated);
    } catch (err: any) {
      console.error("CMS glossary update error:", err);
      res.status(500).json({ message: "Failed to update glossary term" });
    }
  });

  app.delete("/api/cms/glossary/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [deleted] = await db.delete(cmsGlossaryTerms)
        .where(eq(cmsGlossaryTerms.id, req.params.id))
        .returning();
      if (!deleted) return res.status(404).json({ message: "Glossary term not found" });
      await logCmsAudit((req as any).user.userId, "glossary_term", deleted.id, "DELETE");
      res.json({ message: "Glossary term deleted" });
    } catch (err: any) {
      console.error("CMS glossary delete error:", err);
      res.status(500).json({ message: "Failed to delete glossary term" });
    }
  });

  // ─── Fee Configs CRUD ─────────────────────────────────────────────

  app.get("/api/cms/fees", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const rows = await db.select().from(cmsFeeConfigs).orderBy(desc(cmsFeeConfigs.updatedAt));
      res.json(rows);
    } catch (err: any) {
      console.error("CMS fees list error:", err);
      res.status(500).json({ message: "Failed to fetch fee configs" });
    }
  });

  app.post("/api/cms/fees", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [item] = await db.insert(cmsFeeConfigs).values(req.body).returning();
      await logCmsAudit((req as any).user.userId, "fee_config", item.id, "CREATE");
      res.status(201).json(item);
    } catch (err: any) {
      console.error("CMS fee create error:", err);
      res.status(500).json({ message: "Failed to create fee config" });
    }
  });

  app.put("/api/cms/fees/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [updated] = await db.update(cmsFeeConfigs)
        .set({ ...req.body, updatedAt: new Date().toISOString() })
        .where(eq(cmsFeeConfigs.id, req.params.id))
        .returning();
      if (!updated) return res.status(404).json({ message: "Fee config not found" });
      await logCmsAudit((req as any).user.userId, "fee_config", updated.id, "UPDATE", req.body);
      res.json(updated);
    } catch (err: any) {
      console.error("CMS fee update error:", err);
      res.status(500).json({ message: "Failed to update fee config" });
    }
  });

  app.delete("/api/cms/fees/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [deleted] = await db.delete(cmsFeeConfigs)
        .where(eq(cmsFeeConfigs.id, req.params.id))
        .returning();
      if (!deleted) return res.status(404).json({ message: "Fee config not found" });
      await logCmsAudit((req as any).user.userId, "fee_config", deleted.id, "DELETE");
      res.json({ message: "Fee config deleted" });
    } catch (err: any) {
      console.error("CMS fee delete error:", err);
      res.status(500).json({ message: "Failed to delete fee config" });
    }
  });

  // ─── Exit Window Schedules CRUD ───────────────────────────────────

  app.get("/api/cms/exit-windows", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const rows = await db.select().from(cmsExitWindowSchedules).orderBy(desc(cmsExitWindowSchedules.updatedAt));
      res.json(rows);
    } catch (err: any) {
      console.error("CMS exit windows list error:", err);
      res.status(500).json({ message: "Failed to fetch exit windows" });
    }
  });

  app.post("/api/cms/exit-windows", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [item] = await db.insert(cmsExitWindowSchedules).values(req.body).returning();
      await logCmsAudit((req as any).user.userId, "exit_window", item.id, "CREATE");
      res.status(201).json(item);
    } catch (err: any) {
      console.error("CMS exit window create error:", err);
      res.status(500).json({ message: "Failed to create exit window" });
    }
  });

  app.put("/api/cms/exit-windows/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [updated] = await db.update(cmsExitWindowSchedules)
        .set({ ...req.body, updatedAt: new Date().toISOString() })
        .where(eq(cmsExitWindowSchedules.id, req.params.id))
        .returning();
      if (!updated) return res.status(404).json({ message: "Exit window not found" });
      await logCmsAudit((req as any).user.userId, "exit_window", updated.id, "UPDATE", req.body);
      res.json(updated);
    } catch (err: any) {
      console.error("CMS exit window update error:", err);
      res.status(500).json({ message: "Failed to update exit window" });
    }
  });

  app.delete("/api/cms/exit-windows/:id", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [deleted] = await db.delete(cmsExitWindowSchedules)
        .where(eq(cmsExitWindowSchedules.id, req.params.id))
        .returning();
      if (!deleted) return res.status(404).json({ message: "Exit window not found" });
      await logCmsAudit((req as any).user.userId, "exit_window", deleted.id, "DELETE");
      res.json({ message: "Exit window deleted" });
    } catch (err: any) {
      console.error("CMS exit window delete error:", err);
      res.status(500).json({ message: "Failed to delete exit window" });
    }
  });

  // ─── Audit Log (read-only) ────────────────────────────────────────

  app.get("/api/cms/audit", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const { entityType, limit } = req.query;
      const conditions = [];
      if (entityType) conditions.push(eq(cmsAuditLog.entityType, entityType as string));
      const maxRows = limit ? Math.min(parseInt(limit as string, 10), 500) : 100;
      const rows = await db.select().from(cmsAuditLog)
        .where(conditions.length ? and(...conditions) : undefined)
        .orderBy(desc(cmsAuditLog.createdAt))
        .limit(maxRows);
      res.json(rows);
    } catch (err: any) {
      console.error("CMS audit log error:", err);
      res.status(500).json({ message: "Failed to fetch audit log" });
    }
  });

  // ─── CMS Stats ────────────────────────────────────────────────────

  app.get("/api/cms/stats", requireAuth, requireCmsAccess, async (req, res) => {
    try {
      const [publishedPages] = await db.select({ count: sql<number>`count(*)` }).from(cmsPages).where(eq(cmsPages.status, "PUBLISHED"));
      const [draftPages] = await db.select({ count: sql<number>`count(*)` }).from(cmsPages).where(eq(cmsPages.status, "DRAFT"));
      const [liveProperties] = await db.select({ count: sql<number>`count(*)` }).from(cmsPropertyListings).where(eq(cmsPropertyListings.status, "LIVE"));
      const [draftProperties] = await db.select({ count: sql<number>`count(*)` }).from(cmsPropertyListings).where(eq(cmsPropertyListings.status, "DRAFT"));
      const [publishedPosts] = await db.select({ count: sql<number>`count(*)` }).from(cmsBlogPosts).where(eq(cmsBlogPosts.status, "PUBLISHED"));
      const [draftPosts] = await db.select({ count: sql<number>`count(*)` }).from(cmsBlogPosts).where(eq(cmsBlogPosts.status, "DRAFT"));
      const [totalFaqs] = await db.select({ count: sql<number>`count(*)` }).from(cmsFaqItems);
      const [totalGuides] = await db.select({ count: sql<number>`count(*)` }).from(cmsGuides);
      const [totalGlossary] = await db.select({ count: sql<number>`count(*)` }).from(cmsGlossaryTerms);
      const [totalFees] = await db.select({ count: sql<number>`count(*)` }).from(cmsFeeConfigs);
      const [totalExitWindows] = await db.select({ count: sql<number>`count(*)` }).from(cmsExitWindowSchedules);
      const [totalGlobals] = await db.select({ count: sql<number>`count(*)` }).from(cmsGlobalContent);

      const pagesByRegion = await db.select({
        region: cmsPages.region,
        count: sql<number>`count(*)`,
      }).from(cmsPages).groupBy(cmsPages.region);

      const propertiesByRegion = await db.select({
        region: cmsPropertyListings.country,
        count: sql<number>`count(*)`,
      }).from(cmsPropertyListings).groupBy(cmsPropertyListings.country);

      const blogByCategory = await db.select({
        category: cmsBlogPosts.category,
        count: sql<number>`count(*)`,
      }).from(cmsBlogPosts).groupBy(cmsBlogPosts.category);

      const faqByCategory = await db.select({
        category: cmsFaqItems.category,
        count: sql<number>`count(*)`,
      }).from(cmsFaqItems).groupBy(cmsFaqItems.category);

      const recentAudit = await db.select().from(cmsAuditLog)
        .orderBy(desc(cmsAuditLog.createdAt))
        .limit(10);

      res.json({
        publishedPages: Number(publishedPages.count),
        draftPages: Number(draftPages.count),
        liveProperties: Number(liveProperties.count),
        draftProperties: Number(draftProperties.count),
        publishedPosts: Number(publishedPosts.count),
        draftPosts: Number(draftPosts.count),
        totalFaqs: Number(totalFaqs.count),
        totalGuides: Number(totalGuides.count),
        totalGlossary: Number(totalGlossary.count),
        totalFees: Number(totalFees.count),
        totalExitWindows: Number(totalExitWindows.count),
        totalGlobals: Number(totalGlobals.count),
        pagesByRegion: pagesByRegion.map(r => ({ region: r.region, count: Number(r.count) })),
        propertiesByRegion: propertiesByRegion.map(r => ({ region: r.region, count: Number(r.count) })),
        blogByCategory: blogByCategory.map(r => ({ category: r.category, count: Number(r.count) })),
        faqByCategory: faqByCategory.map(r => ({ category: r.category, count: Number(r.count) })),
        recentAudit,
      });
    } catch (err: any) {
      console.error("CMS stats error:", err);
      res.status(500).json({ message: "Failed to fetch CMS stats" });
    }
  });

  // ─── Public Read Routes (NO auth required) ────────────────────────

  app.get("/api/public/cms/pages/:region/:slug", async (req, res) => {
    try {
      const [page] = await db.select().from(cmsPages)
        .where(and(
          eq(cmsPages.region, req.params.region),
          eq(cmsPages.slug, req.params.slug),
          eq(cmsPages.status, "PUBLISHED")
        ));
      if (!page) return res.status(404).json({ message: "Page not found" });
      const sections = await db.select().from(cmsPageSections)
        .where(and(
          eq(cmsPageSections.pageId, page.id),
          eq(cmsPageSections.isEnabled, true)
        ))
        .orderBy(asc(cmsPageSections.orderIndex));
      res.json({ ...page, sections });
    } catch (err: any) {
      console.error("Public CMS page error:", err);
      res.status(500).json({ message: "Failed to fetch page" });
    }
  });

  app.get("/api/public/cms/properties", async (req, res) => {
    try {
      const { region } = req.query;
      const conditions = [eq(cmsPropertyListings.status, "LIVE")];
      if (region) conditions.push(eq(cmsPropertyListings.region, region as string));
      const rows = await db.select().from(cmsPropertyListings)
        .where(and(...conditions))
        .orderBy(desc(cmsPropertyListings.updatedAt));
      res.json(rows);
    } catch (err: any) {
      console.error("Public CMS properties error:", err);
      res.status(500).json({ message: "Failed to fetch properties" });
    }
  });

  app.get("/api/public/cms/blog", async (req, res) => {
    try {
      const { region, category } = req.query;
      const conditions = [eq(cmsBlogPosts.status, "PUBLISHED")];
      if (region) conditions.push(eq(cmsBlogPosts.region, region as string));
      if (category) conditions.push(eq(cmsBlogPosts.category, category as string));
      const rows = await db.select().from(cmsBlogPosts)
        .where(and(...conditions))
        .orderBy(desc(cmsBlogPosts.publishedAt));
      res.json(rows);
    } catch (err: any) {
      console.error("Public CMS blog error:", err);
      res.status(500).json({ message: "Failed to fetch blog posts" });
    }
  });

  app.get("/api/public/cms/blog/:slug", async (req, res) => {
    try {
      const [post] = await db.select().from(cmsBlogPosts)
        .where(and(
          eq(cmsBlogPosts.slug, req.params.slug),
          eq(cmsBlogPosts.status, "PUBLISHED")
        ));
      if (!post) return res.status(404).json({ message: "Blog post not found" });
      res.json(post);
    } catch (err: any) {
      console.error("Public CMS blog post error:", err);
      res.status(500).json({ message: "Failed to fetch blog post" });
    }
  });

  app.get("/api/public/cms/faq", async (req, res) => {
    try {
      const { region, category } = req.query;
      const conditions = [eq(cmsFaqItems.isEnabled, true)];
      if (region) conditions.push(eq(cmsFaqItems.region, region as string));
      if (category) conditions.push(eq(cmsFaqItems.category, category as string));
      const rows = await db.select().from(cmsFaqItems)
        .where(and(...conditions))
        .orderBy(asc(cmsFaqItems.orderIndex));
      res.json(rows);
    } catch (err: any) {
      console.error("Public CMS faq error:", err);
      res.status(500).json({ message: "Failed to fetch FAQ items" });
    }
  });

  app.get("/api/public/cms/guides", async (_req, res) => {
    try {
      const rows = await db.select().from(cmsGuides)
        .where(eq(cmsGuides.status, "PUBLISHED"))
        .orderBy(desc(cmsGuides.updatedAt));
      res.json(rows);
    } catch (err: any) {
      console.error("Public CMS guides error:", err);
      res.status(500).json({ message: "Failed to fetch guides" });
    }
  });

  app.get("/api/public/cms/guides/:slug", async (req, res) => {
    try {
      const [guide] = await db.select().from(cmsGuides)
        .where(and(
          eq(cmsGuides.slug, req.params.slug),
          eq(cmsGuides.status, "PUBLISHED")
        ));
      if (!guide) return res.status(404).json({ message: "Guide not found" });
      res.json(guide);
    } catch (err: any) {
      console.error("Public CMS guide error:", err);
      res.status(500).json({ message: "Failed to fetch guide" });
    }
  });

  app.get("/api/public/cms/glossary", async (_req, res) => {
    try {
      const rows = await db.select().from(cmsGlossaryTerms)
        .orderBy(asc(cmsGlossaryTerms.orderIndex));
      res.json(rows);
    } catch (err: any) {
      console.error("Public CMS glossary error:", err);
      res.status(500).json({ message: "Failed to fetch glossary terms" });
    }
  });

  app.get("/api/public/cms/fees", async (req, res) => {
    try {
      const { region } = req.query;
      const conditions = [eq(cmsFeeConfigs.isEnabled, true)];
      if (region) conditions.push(eq(cmsFeeConfigs.region, region as string));
      const rows = await db.select().from(cmsFeeConfigs)
        .where(and(...conditions))
        .orderBy(desc(cmsFeeConfigs.updatedAt));
      res.json(rows);
    } catch (err: any) {
      console.error("Public CMS fees error:", err);
      res.status(500).json({ message: "Failed to fetch fees" });
    }
  });

  app.get("/api/public/cms/exit-windows", async (_req, res) => {
    try {
      const rows = await db.select().from(cmsExitWindowSchedules)
        .where(eq(cmsExitWindowSchedules.isEnabled, true))
        .orderBy(asc(cmsExitWindowSchedules.opensAt));
      res.json(rows);
    } catch (err: any) {
      console.error("Public CMS exit windows error:", err);
      res.status(500).json({ message: "Failed to fetch exit windows" });
    }
  });

  app.get("/api/public/cms/globals/:region/:key", async (req, res) => {
    try {
      const [item] = await db.select().from(cmsGlobalContent)
        .where(and(
          eq(cmsGlobalContent.region, req.params.region),
          eq(cmsGlobalContent.contentKey, req.params.key)
        ));
      if (!item) return res.status(404).json({ message: "Global content not found" });
      res.json(item);
    } catch (err: any) {
      console.error("Public CMS global content error:", err);
      res.status(500).json({ message: "Failed to fetch global content" });
    }
  });
}
