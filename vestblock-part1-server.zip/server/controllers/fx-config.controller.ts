import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { logAuditFromReq } from "../lib/audit-logger";
import { createFxSpreadConfigSchema, USER_TIERS } from "@shared/schema";
import { z } from "zod";

export function registerFxConfigRoutes(app: Express) {
  app.get("/api/admin/fx-configs", requireAuth, requireRole("admin"), async (_req, res) => {
    try {
      const configs = await storage.getFxSpreadConfigs();
      res.json(configs);
    } catch (err: any) {
      console.error("Fetch FX configs error:", err);
      res.status(500).json({ message: "Failed to fetch FX configs" });
    }
  });

  app.get("/api/admin/fx-configs/:id", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const config = await storage.getFxSpreadConfigById(String(req.params.id));
      if (!config) return res.status(404).json({ message: "Config not found" });
      res.json(config);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch FX config" });
    }
  });

  app.post("/api/admin/fx-configs", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const data = createFxSpreadConfigSchema.parse(req.body);

      if (data.fromCurrency === data.toCurrency) {
        return res.status(400).json({ message: "From and To currencies must be different" });
      }

      const existing = await storage.getActiveFxSpreadConfig(data.fromCurrency, data.toCurrency);
      if (existing) {
        return res.status(400).json({ message: `Active config already exists for ${data.fromCurrency}/${data.toCurrency}. Deactivate it first or update it.` });
      }

      const config = await storage.createFxSpreadConfig({
        fromCurrency: data.fromCurrency,
        toCurrency: data.toCurrency,
        spreadOverride: data.spreadOverride,
        tierLimits: data.tierLimits || {},
        approvalThreshold: data.approvalThreshold || null,
        approvalRequired: data.approvalRequired || false,
        isActive: true,
        createdBy: userId,
      });

      await logAuditFromReq(req, "FX_CONFIG_CREATE", "fx_spread_config", config.id, {
        reason: `Created FX spread config: ${data.fromCurrency}/${data.toCurrency}, spread=${data.spreadOverride}, approval=${data.approvalRequired}`,
        afterState: { fromCurrency: data.fromCurrency, toCurrency: data.toCurrency, spreadOverride: data.spreadOverride, approvalRequired: data.approvalRequired },
      });

      res.json(config);
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Create FX config error:", err);
      res.status(500).json({ message: "Failed to create FX config" });
    }
  });

  app.patch("/api/admin/fx-configs/:id", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const configId = String(String(req.params.id));

      const existing = await storage.getFxSpreadConfigById(configId);
      if (!existing) return res.status(404).json({ message: "Config not found" });

      const updateSchema = z.object({
        spreadOverride: z.string().refine(v => parseFloat(v) >= 0, "Spread must be non-negative").optional(),
        tierLimits: z.record(z.string(), z.object({
          minAmount: z.number().min(0),
          maxAmount: z.number().positive(),
        })).optional(),
        approvalThreshold: z.string().optional().nullable(),
        approvalRequired: z.boolean().optional(),
      });

      const data = updateSchema.parse(req.body);
      const updated = await storage.updateFxSpreadConfig(configId, data as any);

      const changes: string[] = [];
      if (data.spreadOverride !== undefined) changes.push(`spread=${data.spreadOverride}`);
      if (data.tierLimits !== undefined) changes.push(`tierLimits updated`);
      if (data.approvalThreshold !== undefined) changes.push(`threshold=${data.approvalThreshold}`);
      if (data.approvalRequired !== undefined) changes.push(`approvalRequired=${data.approvalRequired}`);

      await logAuditFromReq(req, "FX_CONFIG_UPDATE", "fx_spread_config", configId, {
        reason: `Updated FX config ${existing.fromCurrency}/${existing.toCurrency}: ${changes.join(", ")}`,
        beforeState: { spreadOverride: existing.spreadOverride, approvalRequired: existing.approvalRequired, approvalThreshold: existing.approvalThreshold },
        afterState: data,
      });

      res.json(updated);
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Update FX config error:", err);
      res.status(500).json({ message: "Failed to update FX config" });
    }
  });

  app.post("/api/admin/fx-configs/:id/deactivate", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const config = await storage.deactivateFxSpreadConfig(String(req.params.id));
      if (!config) return res.status(404).json({ message: "Config not found" });

      await logAuditFromReq(req, "FX_CONFIG_DEACTIVATE", "fx_spread_config", config.id, {
        reason: `Deactivated FX config: ${config.fromCurrency}/${config.toCurrency}`,
        beforeState: { isActive: true },
        afterState: { isActive: false },
      });

      res.json(config);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to deactivate FX config" });
    }
  });

  app.get("/api/admin/fx-approvals", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const status = req.query.status as string | undefined;
      const requests = await storage.getFxConversionRequests(status);
      const enriched = await Promise.all(requests.map(async (r) => {
        const user = await storage.getUser(r.userId);
        return {
          ...r,
          user: user ? { id: user.id, fullName: user.fullName, username: user.username, email: user.email, tier: user.tier } : null,
        };
      }));
      res.json(enriched);
    } catch (err: any) {
      console.error("Fetch FX approvals error:", err);
      res.status(500).json({ message: "Failed to fetch FX approval requests" });
    }
  });

  app.post("/api/admin/fx-approvals/:id/approve", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const adminUserId = (req as any).user.userId;
      const requestId = String(String(req.params.id));
      const { notes } = req.body || {};

      const request = await storage.getFxConversionRequestById(requestId);
      if (!request) return res.status(404).json({ message: "Approval request not found" });
      if (request.status !== "pending") return res.status(400).json({ message: "Request is no longer pending" });

      const updated = await storage.updateFxConversionRequestStatus(requestId, "approved", adminUserId, notes);

      await logAuditFromReq(req, "FX_APPROVAL_APPROVE", "fx_conversion_request", requestId, {
        reason: `Approved FX conversion: ${request.fromCurrency} ${request.amountFrom} → ${request.toCurrency} for user ${request.userId}`,
        beforeState: { status: request.status },
        afterState: { status: "approved" },
      });

      res.json(updated);
    } catch (err: any) {
      console.error("Approve FX conversion error:", err);
      res.status(500).json({ message: "Failed to approve conversion" });
    }
  });

  app.post("/api/admin/fx-approvals/:id/reject", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const adminUserId = (req as any).user.userId;
      const requestId = String(String(req.params.id));
      const { notes } = req.body || {};

      const request = await storage.getFxConversionRequestById(requestId);
      if (!request) return res.status(404).json({ message: "Approval request not found" });
      if (request.status !== "pending") return res.status(400).json({ message: "Request is no longer pending" });

      const updated = await storage.updateFxConversionRequestStatus(requestId, "rejected", adminUserId, notes);

      await storage.expireFxQuote(request.quoteId);

      await logAuditFromReq(req, "FX_APPROVAL_REJECT", "fx_conversion_request", requestId, {
        reason: `Rejected FX conversion: ${request.fromCurrency} ${request.amountFrom} → ${request.toCurrency} for user ${request.userId}. Reason: ${notes || "No reason provided"}`,
        beforeState: { status: request.status },
        afterState: { status: "rejected" },
      });

      res.json(updated);
    } catch (err: any) {
      console.error("Reject FX conversion error:", err);
      res.status(500).json({ message: "Failed to reject conversion" });
    }
  });

  app.patch("/api/admin/users/:id/tier", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const adminUserId = (req as any).user.userId;
      const targetUserId = String(String(req.params.id));
      const { tier } = req.body;

      if (!USER_TIERS.includes(tier)) {
        return res.status(400).json({ message: `Invalid tier. Must be one of: ${USER_TIERS.join(", ")}` });
      }

      const updated = await storage.updateUserTier(targetUserId, tier);
      if (!updated) return res.status(404).json({ message: "User not found" });

      await logAuditFromReq(req, "USER_TIER_UPDATE", "user", targetUserId, {
        reason: `Updated user tier to ${tier}`,
        afterState: { tier },
      });

      res.json(updated);
    } catch (err: any) {
      console.error("Update user tier error:", err);
      res.status(500).json({ message: "Failed to update user tier" });
    }
  });
}
