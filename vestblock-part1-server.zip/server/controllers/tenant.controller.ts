import type { Express, Request, Response } from "express";
import { storage } from "../storage";
import { requireAuth, requirePlatformRole, requirePlatformAction, generateToken, resolveEffectivePlatformRole } from "../auth";
import { insertTenantSchema } from "@shared/schema";
import { PLATFORM_TENANT_ID, type TenantRole } from "@shared/constants";
import { clearTenantCache } from "../middleware/tenant-context";
import { logAudit } from "../lib/audit-logger";
import { z } from "zod";

export function registerTenantRoutes(app: Express) {
  app.get("/api/tenants", requireAuth, requirePlatformAction("tenants.view"), async (req: Request, res: Response) => {
    try {
      const tenantsList = await storage.getTenants();
      const tenantsWithMetrics = await Promise.all(
        tenantsList.map(async (t) => {
          const userCount = await storage.getTenantUserCount(t.id);
          return { ...t, userCount };
        })
      );
      res.json(tenantsWithMetrics);
    } catch (err: any) {
      console.error("Get tenants error:", err);
      res.status(500).json({ message: "Failed to fetch tenants" });
    }
  });

  app.get("/api/tenants/:id", requireAuth, requirePlatformAction("tenants.view"), async (req: Request, res: Response) => {
    try {
      const tenant = await storage.getTenant(req.params.id);
      if (!tenant) {
        return res.status(404).json({ message: "Tenant not found" });
      }
      const members = await storage.getTenantUsers(tenant.id);
      const userCount = await storage.getTenantUserCount(tenant.id);
      res.json({ ...tenant, members, userCount });
    } catch (err: any) {
      console.error("Get tenant error:", err);
      res.status(500).json({ message: "Failed to fetch tenant" });
    }
  });

  app.post("/api/tenants", requireAuth, requirePlatformAction("tenants.create"), async (req: Request, res: Response) => {
    try {
      const data = insertTenantSchema.parse(req.body);
      const existing = await storage.getTenantBySlug(data.slug);
      if (existing) {
        return res.status(409).json({ message: "Tenant with this slug already exists" });
      }
      const tenant = await storage.createTenant(data);
      const user = (req as any).user;

      await logAudit({
        actorId: user.userId,
        actorRole: user.role,
        actionType: "TENANT_CREATED",
        entityType: "tenant",
        entityId: tenant.id,
        reason: `Tenant created: ${tenant.name} (${tenant.slug})`,
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });

      res.status(201).json(tenant);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("Create tenant error:", err);
      res.status(500).json({ message: "Failed to create tenant" });
    }
  });

  app.patch("/api/tenants/:id", requireAuth, requirePlatformAction("tenants.manage"), async (req: Request, res: Response) => {
    try {
      if (req.params.id === PLATFORM_TENANT_ID && (req.body.status === "SUSPENDED" || req.body.status === "DELETED")) {
        return res.status(400).json({ message: "Cannot suspend or delete the platform tenant" });
      }
      const updated = await storage.updateTenant(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ message: "Tenant not found" });
      }
      clearTenantCache(updated.slug);

      const user = (req as any).user;
      await logAudit({
        actorId: user.userId,
        actorRole: user.role,
        actionType: "TENANT_UPDATED",
        entityType: "tenant",
        entityId: updated.id,
        reason: `Tenant updated: ${updated.name} → status: ${updated.status}`,
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });

      res.json(updated);
    } catch (err: any) {
      console.error("Update tenant error:", err);
      res.status(500).json({ message: "Failed to update tenant" });
    }
  });

  app.delete("/api/tenants/:id", requireAuth, requirePlatformRole("SUPER_ADMIN"), async (req: Request, res: Response) => {
    try {
      if (req.params.id === PLATFORM_TENANT_ID) {
        return res.status(400).json({ message: "Cannot delete the platform tenant" });
      }
      const updated = await storage.updateTenant(req.params.id, { status: "DELETED" } as any);
      if (!updated) {
        return res.status(404).json({ message: "Tenant not found" });
      }
      clearTenantCache(updated.slug);

      const user = (req as any).user;
      await logAudit({
        actorId: user.userId,
        actorRole: user.role,
        actionType: "TENANT_ARCHIVED",
        entityType: "tenant",
        entityId: updated.id,
        reason: `Tenant archived (safe delete): ${updated.name}`,
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });

      res.json({ message: "Tenant archived", tenant: updated });
    } catch (err: any) {
      console.error("Delete tenant error:", err);
      res.status(500).json({ message: "Failed to archive tenant" });
    }
  });

  app.get("/api/tenants/:id/users", requireAuth, requirePlatformAction("tenants.view"), async (req: Request, res: Response) => {
    try {
      const members = await storage.getTenantUsers(req.params.id);
      const membersWithDetails = await Promise.all(
        members.map(async (m) => {
          const user = await storage.getUser(m.userId);
          return {
            ...m,
            user: user ? { id: user.id, username: user.username, email: user.email, fullName: user.fullName, isActive: user.isActive, avatarUrl: user.avatarUrl } : null,
          };
        })
      );
      res.json(membersWithDetails);
    } catch (err: any) {
      console.error("Get tenant users error:", err);
      res.status(500).json({ message: "Failed to fetch tenant users" });
    }
  });

  app.post("/api/tenants/:id/users", requireAuth, requirePlatformAction("tenants.manage"), async (req: Request, res: Response) => {
    try {
      const { userId, role } = req.body;
      if (!userId) {
        return res.status(400).json({ message: "userId is required" });
      }
      const existing = await storage.getTenantUser(req.params.id, userId);
      if (existing) {
        return res.status(409).json({ message: "User is already a member of this tenant" });
      }
      const tenantUser = await storage.createTenantUser({
        tenantId: req.params.id,
        userId,
        role: role || "TENANT_USER",
      });

      const actor = (req as any).user;
      await logAudit({
        actorId: actor.userId,
        actorRole: actor.role,
        actionType: "TENANT_USER_ADDED",
        entityType: "tenant_user",
        entityId: tenantUser.id,
        reason: `User ${userId} added to tenant ${req.params.id} with role ${role || "TENANT_USER"}`,
        afterState: { role: role || "TENANT_USER", tenantId: req.params.id },
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });

      res.status(201).json(tenantUser);
    } catch (err: any) {
      console.error("Add tenant user error:", err);
      res.status(500).json({ message: "Failed to add user to tenant" });
    }
  });

  app.patch("/api/tenants/:tenantId/users/:userId", requireAuth, requirePlatformAction("tenants.manage"), async (req: Request, res: Response) => {
    try {
      const { role, status } = req.body;
      const updated = await storage.updateTenantUser(req.params.tenantId, req.params.userId, { role, status });
      if (!updated) {
        return res.status(404).json({ message: "Tenant user not found" });
      }

      const actor = (req as any).user;
      await logAudit({
        actorId: actor.userId,
        actorRole: actor.role,
        actionType: "TENANT_USER_UPDATED",
        entityType: "tenant_user",
        entityId: updated.id,
        reason: `Tenant user updated in tenant ${req.params.tenantId}`,
        afterState: { role, status },
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });

      res.json(updated);
    } catch (err: any) {
      console.error("Update tenant user error:", err);
      res.status(500).json({ message: "Failed to update tenant user" });
    }
  });

  app.delete("/api/tenants/:tenantId/users/:userId", requireAuth, requirePlatformAction("tenants.manage"), async (req: Request, res: Response) => {
    try {
      await storage.removeTenantUser(req.params.tenantId, req.params.userId);

      const actor = (req as any).user;
      await logAudit({
        actorId: actor.userId,
        actorRole: actor.role,
        actionType: "TENANT_USER_REMOVED",
        entityType: "tenant_user",
        reason: `User ${req.params.userId} removed from tenant ${req.params.tenantId}`,
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });

      res.json({ message: "User removed from tenant" });
    } catch (err: any) {
      console.error("Remove tenant user error:", err);
      res.status(500).json({ message: "Failed to remove user from tenant" });
    }
  });

  app.post("/api/tenants/:id/impersonate", requireAuth, requirePlatformRole("SUPER_ADMIN"), async (req: Request, res: Response) => {
    try {
      const actor = (req as any).user;
      const tenant = await storage.getTenant(req.params.id);
      if (!tenant) {
        return res.status(404).json({ message: "Tenant not found" });
      }

      await storage.createImpersonationLog({
        actorId: actor.userId,
        actorUsername: actor.username,
        targetTenantId: tenant.id,
        targetTenantName: tenant.name,
        reason: req.body.reason || "Support impersonation",
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });

      await logAudit({
        actorId: actor.userId,
        actorRole: actor.role,
        actionType: "TENANT_IMPERSONATED",
        entityType: "tenant",
        entityId: tenant.id,
        reason: `Super admin ${actor.username} impersonated tenant: ${tenant.name}`,
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });

      const impersonatorUser = await storage.getUser(actor.userId);
      if (!impersonatorUser) {
        return res.status(404).json({ message: "Actor user not found" });
      }

      const impersonationToken = generateToken(
        impersonatorUser,
        tenant.id,
        "TENANT_OWNER" as TenantRole,
        { impersonatorId: actor.userId, impersonatorUsername: actor.username }
      );

      const cookieOptions = {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax" as const,
        maxAge: 2 * 60 * 60 * 1000,
        path: "/",
      };
      res.cookie("token", impersonationToken, cookieOptions);
      res.json({ message: "Impersonation started", tenantId: tenant.id, tenantName: tenant.name });
    } catch (err: any) {
      console.error("Impersonate tenant error:", err);
      res.status(500).json({ message: "Failed to impersonate tenant" });
    }
  });

  app.post("/api/tenants/stop-impersonation", requireAuth, async (req: Request, res: Response) => {
    try {
      const user = (req as any).user;
      if (!user.impersonatorId) {
        return res.status(400).json({ message: "Not currently impersonating" });
      }

      const originalUser = await storage.getUser(user.impersonatorId);
      if (!originalUser) {
        return res.status(404).json({ message: "Original user not found" });
      }

      await logAudit({
        actorId: user.impersonatorId,
        actorRole: "SUPER_ADMIN",
        actionType: "TENANT_IMPERSONATION_ENDED",
        entityType: "tenant",
        reason: `Super admin ${originalUser.username} stopped impersonating tenant`,
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });

      const token = generateToken(originalUser, PLATFORM_TENANT_ID, null);
      const cookieOptions = {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax" as const,
        maxAge: 7 * 24 * 60 * 60 * 1000,
        path: "/",
      };
      res.cookie("token", token, cookieOptions);
      res.json({ message: "Impersonation ended" });
    } catch (err: any) {
      console.error("Stop impersonation error:", err);
      res.status(500).json({ message: "Failed to stop impersonation" });
    }
  });

  app.get("/api/impersonation-logs", requireAuth, requirePlatformRole("SUPER_ADMIN"), async (req: Request, res: Response) => {
    try {
      const logs = await storage.getImpersonationLogs(100);
      res.json(logs);
    } catch (err: any) {
      console.error("Get impersonation logs error:", err);
      res.status(500).json({ message: "Failed to fetch impersonation logs" });
    }
  });
}
