import type { Express, Request, Response } from "express";
import { requireAuth, requireRole, requirePermission, getUserPermissions, type JwtPayload } from "../auth";
import { storage } from "../storage";
import { ROLES, PERMISSIONS, DEFAULT_ROLE_PERMISSIONS, type Permission, type Role } from "@shared/constants";
import { logAuditFromReq } from "../lib/audit-logger";

export function registerRolePermissionsRoutes(app: Express) {
  app.get("/api/permissions/me", requireAuth, async (req: Request, res: Response) => {
    const user = (req as any).user as JwtPayload;
    const permissions = await getUserPermissions(user.role);
    res.json({ role: user.role, permissions });
  });

  app.get("/api/admin/permissions/matrix", requireAuth, requireRole("admin"), async (_req: Request, res: Response) => {
    const allPerms = await storage.getAllRolePermissions();

    const matrix: Record<string, string[]> = {};
    for (const role of ROLES) {
      const rolePerms = allPerms.filter(p => p.role === role);
      matrix[role] = rolePerms.length > 0
        ? rolePerms.map(p => p.permission)
        : [...(DEFAULT_ROLE_PERMISSIONS[role as Role] || [])];
    }

    res.json({
      roles: [...ROLES],
      permissions: [...PERMISSIONS],
      matrix,
      defaults: DEFAULT_ROLE_PERMISSIONS,
    });
  });

  app.put("/api/admin/permissions/:role", requireAuth, requireRole("admin"), requirePermission("roles.manage"), async (req: Request, res: Response) => {
    const role = String(req.params.role);
    const { permissions } = req.body;
    const user = (req as any).user as JwtPayload;

    if (!ROLES.includes(role as any)) {
      return res.status(400).json({ message: "Invalid role" });
    }

    if (!Array.isArray(permissions)) {
      return res.status(400).json({ message: "permissions must be an array" });
    }

    const validPerms = permissions.filter((p: string) => PERMISSIONS.includes(p as any));

    if (role === "admin" && !validPerms.includes("roles.manage")) {
      validPerms.push("roles.manage");
    }

    const result = await storage.setRolePermissions(role, validPerms, user.userId);

    await logAuditFromReq(req, "ROLE_PERMISSIONS_SET", "role", role, {
      reason: `Set ${validPerms.length} permissions for role ${role}`,
      afterState: { permissions: validPerms },
    });

    res.json({
      role,
      permissions: result.map(r => r.permission),
      count: result.length,
    });
  });

  app.post("/api/admin/permissions/:role/grant", requireAuth, requireRole("admin"), requirePermission("roles.manage"), async (req: Request, res: Response) => {
    const role = String(req.params.role);
    const { permission } = req.body;
    const user = (req as any).user as JwtPayload;

    if (!ROLES.includes(role as any)) {
      return res.status(400).json({ message: "Invalid role" });
    }
    if (!PERMISSIONS.includes(permission as any)) {
      return res.status(400).json({ message: "Invalid permission" });
    }

    const existing = await storage.hasPermission(role, permission);
    if (existing) {
      return res.json({ message: "Permission already granted" });
    }

    await storage.addRolePermission({ role, permission, grantedBy: user.userId });

    await logAuditFromReq(req, "PERMISSION_GRANTED", "role", role, {
      reason: `Granted permission "${permission}" to role "${role}"`,
      afterState: { permission },
    });

    res.json({ message: "Permission granted", role, permission });
  });

  app.post("/api/admin/permissions/:role/revoke", requireAuth, requireRole("admin"), requirePermission("roles.manage"), async (req: Request, res: Response) => {
    const role = String(req.params.role);
    const { permission } = req.body;

    if (!ROLES.includes(role as any)) {
      return res.status(400).json({ message: "Invalid role" });
    }

    const removed = await storage.removeRolePermission(role, permission);
    if (!removed) {
      return res.status(404).json({ message: "Permission not found for role" });
    }

    await logAuditFromReq(req, "PERMISSION_REVOKED", "role", role, {
      reason: `Revoked permission "${permission}" from role "${role}"`,
      beforeState: { permission },
    });

    res.json({ message: "Permission revoked", role, permission });
  });

  app.post("/api/admin/permissions/:role/reset", requireAuth, requireRole("admin"), requirePermission("roles.manage"), async (req: Request, res: Response) => {
    const role = String(req.params.role);
    const user = (req as any).user as JwtPayload;

    if (!ROLES.includes(role as any)) {
      return res.status(400).json({ message: "Invalid role" });
    }

    const defaults = DEFAULT_ROLE_PERMISSIONS[role as Role] || [];
    await storage.setRolePermissions(role, defaults, user.userId);

    await logAuditFromReq(req, "ROLE_PERMISSIONS_RESET", "role", role, {
      reason: `Reset permissions for role "${role}" to defaults`,
      afterState: { permissions: defaults },
    });

    res.json({ message: "Permissions reset to defaults", role, permissions: defaults });
  });
}
