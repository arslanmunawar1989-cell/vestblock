import type { Express } from "express";
import { requireAuth, requireRole } from "../auth";
import { storage } from "../storage";
import {
  createOfferingSchema,
  updateOfferingSchema,
  offeringStatusTransitionSchema,
  createCommitmentSchema,
} from "@shared/schema";
import { getLiveRate } from "../fx";
import { executeOfferingIssuance } from "../services/offering-issuance.service";
import { walletService } from "../services/wallet.service";

const VALID_OFFERING_TRANSITIONS: Record<string, string[]> = {
  DRAFT: ["OPEN"],
  OPEN: ["FUNDED", "CLOSED", "CANCELLED"],
  FUNDED: ["CLOSED"],
  CLOSED: [],
  CANCELLED: [],
};

const COOLING_OFF_DAYS = 14;

function normalizeAmounts(data: Record<string, any>): Record<string, any> {
  const result = { ...data };
  if (result.maxInvest === "" || result.maxInvest === undefined) {
    result.maxInvest = null;
  }
  return result;
}

export function registerOfferingRoutes(app: Express) {
  app.post("/api/admin/offerings", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const parsed = createOfferingSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Validation failed", details: parsed.error.flatten() });
      }
      const user = (req as any).user;
      const vehicle = await storage.getInvestmentVehicle(parsed.data.vehicleId);
      if (!vehicle) return res.status(404).json({ message: "Vehicle not found" });
      if (vehicle.status !== "ACTIVE") {
        return res.status(400).json({ message: "Vehicle must be ACTIVE to create an offering" });
      }
      if (new Date(parsed.data.endDate) <= new Date(parsed.data.startDate)) {
        return res.status(400).json({ message: "End date must be after start date" });
      }
      const minInvest = parseFloat(parsed.data.minInvest);
      const maxInvest = parsed.data.maxInvest ? parseFloat(parsed.data.maxInvest) : null;
      if (maxInvest !== null && maxInvest < minInvest) {
        return res.status(400).json({ message: "Maximum investment must be greater than or equal to minimum" });
      }
      const data = normalizeAmounts(parsed.data);
      const offering = await storage.createOffering({
        ...data,
        totalCommitted: "0",
        createdBy: user.userId,
        status: "DRAFT",
      });
      res.status(201).json(offering);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/offerings", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const allOfferings = await storage.getAllOfferings(req.tenantId);
      const enriched = await Promise.all(
        allOfferings.map(async (o) => {
          const vehicle = await storage.getInvestmentVehicle(o.vehicleId);
          const linkedAssets = await storage.getAssetsByVehicle(o.vehicleId);
          const property = linkedAssets[0] || null;
          return { ...o, vehicle, property };
        })
      );
      res.json(enriched);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/offerings/:id", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const offering = await storage.getOffering(String(req.params.id));
      if (!offering) return res.status(404).json({ message: "Offering not found" });
      const vehicle = await storage.getInvestmentVehicle(offering.vehicleId);
      const linkedAssets = await storage.getAssetsByVehicle(offering.vehicleId);
      const property = linkedAssets[0] || null;
      let propertyAcquisition = null;
      let propertyUnit = null;
      if (property) {
        propertyAcquisition = await storage.getPropertyAcquisition(property.id);
        propertyUnit = await storage.getPropertyUnit(property.id);
      }
      const offeringCommitments = await storage.getCommitmentsByOffering(offering.id);
      res.json({ ...offering, vehicle, property, propertyAcquisition, propertyUnit, commitments: offeringCommitments });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/admin/offerings/:id", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const parsed = updateOfferingSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Validation failed", details: parsed.error.flatten() });
      }
      const offering = await storage.getOffering(String(req.params.id));
      if (!offering) return res.status(404).json({ message: "Offering not found" });
      if (offering.status !== "DRAFT") {
        return res.status(400).json({ message: "Can only edit offerings in DRAFT status" });
      }
      const data = normalizeAmounts(parsed.data);
      const updated = await storage.updateOffering(String(req.params.id), data as any);
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/admin/offerings/:id/status", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const parsed = offeringStatusTransitionSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Validation failed", details: parsed.error.flatten() });
      }
      const offering = await storage.getOffering(String(req.params.id));
      if (!offering) return res.status(404).json({ message: "Offering not found" });

      const allowedNext = VALID_OFFERING_TRANSITIONS[offering.status] || [];
      if (!allowedNext.includes(parsed.data.status)) {
        return res.status(400).json({
          message: `Cannot transition from ${offering.status} to ${parsed.data.status}. Allowed: ${allowedNext.join(", ") || "none"}`,
        });
      }

      const newStatus = parsed.data.status;

      if (newStatus === "FUNDED") {
        const totalCommitted = parseFloat(offering.totalCommitted || "0");
        const targetAmount = parseFloat(offering.targetAmount);
        if (totalCommitted < targetAmount) {
          return res.status(400).json({
            message: `Cannot mark as FUNDED: committed ${offering.totalCommitted} of ${offering.targetAmount} target.`,
          });
        }

        const activeCommitments = await storage.getActiveCommitmentsByOffering(offering.id);
        const unreserved = activeCommitments.filter(c => !c.reserveLedgerTxId);
        if (unreserved.length > 0) {
          return res.status(400).json({
            message: `Cannot fund: ${unreserved.length} commitment(s) missing wallet reserves. IDs: ${unreserved.map(c => c.id).join(", ")}`,
          });
        }
        for (const commitment of activeCommitments) {
          if (commitment.reserveLedgerTxId) {
            await walletService.captureFunds({
              reserveLedgerTxId: commitment.reserveLedgerTxId,
              description: `Investment captured for offering ${offering.name}`,
              metadata: { offeringId: offering.id, commitmentId: commitment.id },
            });
          }
          await storage.updateCommitmentStatus(commitment.id, "SETTLED");
        }

        await storage.updateOfferingStatus(String(req.params.id), "FUNDED");

        const user = (req as any).user;
        let issuanceResult = null;
        try {
          issuanceResult = await executeOfferingIssuance(String(req.params.id), user.userId);
        } catch (issuanceErr: any) {
          console.warn("Auto-issuance on FUNDED failed (non-blocking):", issuanceErr.message?.slice(0, 200));
        }

        const updated = await storage.getOffering(String(req.params.id));
        return res.json({
          ...updated,
          ...(issuanceResult?.success ? { issuanceTriggered: true, issuanceId: issuanceResult.issuanceId } : {}),
        });
      }

      if (newStatus === "CANCELLED") {
        const activeCommitments = await storage.getActiveCommitmentsByOffering(offering.id);
        for (const commitment of activeCommitments) {
          if (commitment.reserveLedgerTxId) {
            await walletService.releaseReserve({
              reserveLedgerTxId: commitment.reserveLedgerTxId,
              reason: `Offering ${offering.id} cancelled — reserve released`,
            });
          }
          await storage.updateCommitmentStatus(commitment.id, "CANCELLED");
        }
      }

      const updated = await storage.updateOfferingStatus(String(req.params.id), newStatus);
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/offerings/:id/commitments", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const offering = await storage.getOffering(String(req.params.id));
      if (!offering) return res.status(404).json({ message: "Offering not found" });
      const offeringCommitments = await storage.getCommitmentsByOffering(String(req.params.id));
      res.json(offeringCommitments);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/admin/commitments/:id/status", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const { status } = req.body;
      if (!["CONFIRMED", "CANCELLED", "SETTLED"].includes(status)) {
        return res.status(400).json({ message: "Invalid commitment status" });
      }
      const commitment = await storage.getCommitment(String(req.params.id));
      if (!commitment) return res.status(404).json({ message: "Commitment not found" });

      if (status === "CANCELLED" && commitment.reserveLedgerTxId) {
        await walletService.releaseReserve({
          reserveLedgerTxId: commitment.reserveLedgerTxId,
          reason: `Admin cancelled commitment ${commitment.id}`,
        });
        const convertedAmount = parseFloat(commitment.convertedAmount || commitment.amount);
        await storage.updateOfferingTotalCommitted(commitment.offeringId, (-convertedAmount).toFixed(2));
      }

      const updated = await storage.updateCommitmentStatus(String(req.params.id), status);
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/offerings/open", requireAuth, async (_req, res) => {
    try {
      const openOfferings = await storage.getOpenOfferings();
      const enriched = await Promise.all(
        openOfferings.map(async (o) => {
          const vehicle = await storage.getInvestmentVehicle(o.vehicleId);
          const linkedAssets = await storage.getAssetsByVehicle(o.vehicleId);
          const property = linkedAssets[0] || null;
          let propertyAcquisition = null;
          let propertyUnit = null;
          if (property) {
            propertyAcquisition = await storage.getPropertyAcquisition(property.id);
            propertyUnit = await storage.getPropertyUnit(property.id);
          }
          return { ...o, vehicle, property, propertyAcquisition, propertyUnit };
        })
      );
      res.json(enriched);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/offerings/:id", requireAuth, async (req, res) => {
    try {
      const offering = await storage.getOffering(String(req.params.id));
      if (!offering) return res.status(404).json({ message: "Offering not found" });
      const vehicle = await storage.getInvestmentVehicle(offering.vehicleId);
      const linkedAssets = await storage.getAssetsByVehicle(offering.vehicleId);
      const property = linkedAssets[0] || null;
      let propertyAcquisition = null;
      let propertyUnit = null;
      if (property) {
        propertyAcquisition = await storage.getPropertyAcquisition(property.id);
        propertyUnit = await storage.getPropertyUnit(property.id);
      }
      res.json({ ...offering, vehicle, property, propertyAcquisition, propertyUnit });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/offerings/:id/commit", requireAuth, async (req, res) => {
    try {
      const parsed = createCommitmentSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Validation failed", details: parsed.error.flatten() });
      }
      const user = (req as any).user;
      const offering = await storage.getOffering(String(req.params.id));
      if (!offering) return res.status(404).json({ message: "Offering not found" });
      if (offering.status !== "OPEN") {
        return res.status(400).json({ message: "Offering is not open for commitments" });
      }

      const now = new Date();
      if (new Date(offering.endDate) < now) {
        return res.status(400).json({ message: "Offering has ended" });
      }
      if (new Date(offering.startDate) > now) {
        return res.status(400).json({ message: "Offering has not started yet" });
      }

      const amount = parseFloat(parsed.data.amount);
      const minInvest = parseFloat(offering.minInvest);
      const maxInvest = offering.maxInvest ? parseFloat(offering.maxInvest) : null;

      if (amount < minInvest) {
        return res.status(400).json({ message: `Minimum investment is ${offering.minInvest}` });
      }
      if (maxInvest !== null && amount > maxInvest) {
        return res.status(400).json({ message: `Maximum investment is ${offering.maxInvest}` });
      }

      const vehicle = await storage.getInvestmentVehicle(offering.vehicleId);
      if (!vehicle) return res.status(500).json({ message: "Vehicle not found for this offering" });

      let convertedAmount = amount;
      let fxRate: number | null = null;
      let baseCurrency = vehicle.baseCurrency;

      if (parsed.data.currency !== vehicle.baseCurrency) {
        const rateData = await getLiveRate(parsed.data.currency, vehicle.baseCurrency);
        if (!rateData) {
          return res.status(400).json({ message: `Cannot convert ${parsed.data.currency} to ${vehicle.baseCurrency}. FX rate unavailable.` });
        }
        fxRate = rateData.rate;
        convertedAmount = parseFloat((amount * rateData.rate).toFixed(2));
      }

      const targetAmount = parseFloat(offering.targetAmount);
      const currentCommitted = parseFloat(offering.totalCommitted || "0");
      if (currentCommitted + convertedAmount > targetAmount) {
        const remaining = targetAmount - currentCommitted;
        return res.status(400).json({ message: `Commitment exceeds remaining capacity. Available: ${remaining.toFixed(2)} ${vehicle.baseCurrency}` });
      }

      let reserveResult;
      try {
        reserveResult = await walletService.reserveFunds({
          userId: user.userId,
          currency: parsed.data.currency,
          amount,
          referenceId: `offering_${offering.id}`,
          description: `Investment reserve for offering ${offering.name}`,
          metadata: { offeringId: offering.id },
        });
      } catch (reserveErr: any) {
        return res.status(400).json({
          message: reserveErr.message || `Insufficient wallet balance for ${parsed.data.currency}`,
        });
      }

      const reserveLedgerTxId = reserveResult.reserveLedgerTxId;

      const updated = await storage.atomicAddToOfferingCommitted(
        offering.id, convertedAmount.toFixed(2), offering.targetAmount
      );
      if (!updated) {
        await walletService.releaseReserve({ reserveLedgerTxId, reason: "Offering capacity exceeded — reserve reversed" });
        return res.status(409).json({ message: "Offering capacity exceeded. Please try a smaller amount." });
      }

      const coolingOffEndsAt = new Date(Date.now() + COOLING_OFF_DAYS * 24 * 60 * 60 * 1000).toISOString();

      let commitment;
      try {
        commitment = await storage.createCommitment({
          userId: user.userId,
          offeringId: offering.id,
          amount: parsed.data.amount,
          currency: parsed.data.currency,
          convertedAmount: convertedAmount.toFixed(2),
          baseCurrency,
          fxRate: fxRate?.toString() || null,
          status: "COOLING_OFF",
          coolingOffEndsAt,
          reserveLedgerTxId,
          walletAccountId: reserveResult.walletAccountId,
        });
      } catch (commitErr) {
        await walletService.releaseReserve({ reserveLedgerTxId, reason: "Commitment creation failed — reserve reversed" });
        await storage.updateOfferingTotalCommitted(offering.id, (-convertedAmount).toFixed(2));
        throw commitErr;
      }

      let autoFunded = false;
      const refreshed = await storage.getOffering(offering.id);
      if (refreshed) {
        const totalCommitted = parseFloat(refreshed.totalCommitted || "0");
        const target = parseFloat(refreshed.targetAmount);
        if (totalCommitted >= target && refreshed.status === "OPEN") {
          await storage.updateOfferingStatus(offering.id, "FUNDED");
          autoFunded = true;
        }
      }

      res.status(201).json({
        ...commitment,
        ...(autoFunded ? { autoFunded: true } : {}),
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/my/commitments", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      const userCommitments = await storage.getCommitmentsByUser(user.userId);
      const enriched = await Promise.all(
        userCommitments.map(async (c) => {
          const offering = await storage.getOffering(c.offeringId);
          let property = null;
          if (offering) {
            const linkedAssets = await storage.getAssetsByVehicle(offering.vehicleId);
            property = linkedAssets[0] || null;
          }
          return { ...c, offering, property };
        })
      );
      res.json(enriched);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/my/commitments/:id/cancel", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      const commitment = await storage.getCommitment(String(req.params.id));
      if (!commitment) return res.status(404).json({ message: "Commitment not found" });
      if (commitment.userId !== user.userId) {
        return res.status(403).json({ message: "Not your commitment" });
      }
      if (!["COOLING_OFF", "PENDING"].includes(commitment.status)) {
        return res.status(400).json({ message: "Cannot cancel this commitment" });
      }

      if (commitment.reserveLedgerTxId) {
        await walletService.releaseReserve({
          reserveLedgerTxId: commitment.reserveLedgerTxId,
          reason: `User cancelled commitment ${commitment.id}`,
        });
      }

      const updated = await storage.updateCommitmentStatus(String(req.params.id), "CANCELLED");

      const convertedAmount = parseFloat(commitment.convertedAmount || commitment.amount);
      await storage.updateOfferingTotalCommitted(commitment.offeringId, (-convertedAmount).toFixed(2));

      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/offerings/:id/fund", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const user = (req as any).user;
      const offering = await storage.getOffering(String(req.params.id));
      if (!offering) return res.status(404).json({ message: "Offering not found" });

      if (offering.status !== "OPEN" && offering.status !== "FUNDED") {
        return res.status(400).json({ message: `Offering must be OPEN or FUNDED. Current status: ${offering.status}` });
      }

      const totalCommitted = parseFloat(offering.totalCommitted || "0");
      const targetAmount = parseFloat(offering.targetAmount);
      if (totalCommitted < targetAmount) {
        return res.status(400).json({
          message: `Offering is not fully funded. Committed ${offering.totalCommitted} of ${offering.targetAmount}.`,
        });
      }

      if (offering.status === "OPEN") {
        await storage.updateOfferingStatus(String(req.params.id), "FUNDED");
      }

      const activeCommitments = await storage.getActiveCommitmentsByOffering(offering.id);
      const unreserved = activeCommitments.filter(c => !c.reserveLedgerTxId);
      if (unreserved.length > 0) {
        return res.status(400).json({
          message: `Cannot fund: ${unreserved.length} commitment(s) missing wallet reserves. IDs: ${unreserved.map(c => c.id).join(", ")}`,
        });
      }
      const captureResults = [];
      for (const commitment of activeCommitments) {
        if (commitment.reserveLedgerTxId) {
          const captureResult = await walletService.captureFunds({
            reserveLedgerTxId: commitment.reserveLedgerTxId,
            description: `Investment captured for offering ${offering.name}`,
            metadata: { offeringId: offering.id, commitmentId: commitment.id },
          });
          captureResults.push({ commitmentId: commitment.id, captureTxId: captureResult.captureLedgerTxId });
        }
        await storage.updateCommitmentStatus(commitment.id, "SETTLED");
      }

      const issuanceResult = await executeOfferingIssuance(String(req.params.id), user.userId);

      res.status(200).json({
        message: "Offering funded, reserves captured, and tokens minted successfully",
        capturedCommitments: captureResults.length,
        ...(issuanceResult?.success ? {
          issuanceId: issuanceResult.issuanceId,
          report: issuanceResult.report,
        } : {
          issuanceError: issuanceResult?.error,
        }),
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/offerings/:id/issue-tokens", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const user = (req as any).user;
      const offering = await storage.getOffering(String(req.params.id));
      if (!offering) return res.status(404).json({ message: "Offering not found" });

      if (offering.status !== "FUNDED" && offering.status !== "OPEN") {
        return res.status(400).json({ message: `Offering must be OPEN or FUNDED to issue tokens. Current status: ${offering.status}` });
      }

      const totalCommitted = parseFloat(offering.totalCommitted || "0");
      const targetAmount = parseFloat(offering.targetAmount);
      if (totalCommitted < targetAmount) {
        return res.status(400).json({
          message: `Offering is not fully funded. Committed ${offering.totalCommitted} of ${offering.targetAmount}.`,
        });
      }

      if (offering.status === "OPEN") {
        await storage.updateOfferingStatus(String(req.params.id), "FUNDED");
      }

      const result = await executeOfferingIssuance(String(req.params.id), user.userId);
      if (!result.success) {
        return res.status(400).json({ message: result.error });
      }

      res.status(201).json({
        message: "Token issuance completed successfully",
        issuanceId: result.issuanceId,
        report: result.report,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/offerings/:id/issuance-report", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const issuances = await storage.getTokenIssuancesByOffering(String(req.params.id));
      if (issuances.length === 0) {
        return res.status(404).json({ message: "No issuance found for this offering" });
      }
      res.json(issuances[0]);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/offerings/:id/cap-table", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const issuances = await storage.getTokenIssuancesByOffering(String(req.params.id));
      if (issuances.length === 0) {
        return res.status(404).json({ message: "No issuance found for this offering. Issue tokens first." });
      }

      const report = issuances[0].issuanceReport as any;
      if (!report?.capTableSnapshot) {
        return res.status(404).json({ message: "Cap table snapshot not available in issuance report" });
      }

      const format = req.query.format as string;
      if (format === "csv") {
        const rows = ["Investor Name,User ID,Token Balance,Ownership %"];
        for (const entry of report.capTableSnapshot) {
          rows.push(`"${entry.investorName}","${entry.userId}",${entry.balance},${entry.percentage}%`);
        }
        const csv = rows.join("\n");
        const filename = `cap_table_${report.tokenSymbol || "tokens"}_${new Date().toISOString().split("T")[0]}.csv`;
        res.setHeader("Content-Type", "text/csv");
        res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
        return res.send(csv);
      }

      res.json({
        offeringId: String(req.params.id),
        offeringName: report.offeringName,
        tokenSymbol: report.tokenSymbol,
        totalSupplyMinted: report.totalSupplyMinted,
        holdersAllocated: report.holdersAllocated,
        capTable: report.capTableSnapshot,
        issuedAt: report.issuedAt,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/investor/ownership", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      const userId = user.userId;

      const ledgerEntries = await storage.getPropertyUnitLedgerByUser(userId);
      if (ledgerEntries.length === 0) {
        return res.json({ ownership: [] });
      }

      const ownershipByAsset = new Map<string, { credits: number; debits: number; entries: typeof ledgerEntries }>();
      for (const entry of ledgerEntries) {
        const existing = ownershipByAsset.get(entry.assetId) || { credits: 0, debits: 0, entries: [] };
        const units = parseFloat(entry.units);
        if (entry.direction === "CREDIT") {
          existing.credits += units;
        } else {
          existing.debits += units;
        }
        existing.entries.push(entry);
        ownershipByAsset.set(entry.assetId, existing);
      }

      const ownership = [];
      for (const [assetId, data] of ownershipByAsset) {
        const unitsOwned = data.credits - data.debits;
        if (unitsOwned <= 0) continue;

        const asset = await storage.getAsset(assetId);
        if (!asset) continue;

        const propertyUnit = await storage.getPropertyUnit(assetId);
        const acquisition = await storage.getPropertyAcquisition(assetId);

        const totalUnits = propertyUnit ? parseFloat(propertyUnit.totalUnits) : 0;
        const percentageOwned = totalUnits > 0 ? ((unitsOwned / totalUnits) * 100) : 0;
        const unitPrice = propertyUnit ? parseFloat(propertyUnit.unitPrice) : 0;
        const currentValue = unitsOwned * unitPrice;

        ownership.push({
          assetId,
          propertyName: asset.name,
          propertySymbol: asset.symbol,
          location: asset.location,
          country: asset.country,
          propertyType: asset.propertyType,
          unitsOwned: unitsOwned.toFixed(6),
          totalUnits: propertyUnit?.totalUnits || "0",
          percentageOwned: percentageOwned.toFixed(4),
          unitPrice: propertyUnit?.unitPrice || "0",
          currentValue: currentValue.toFixed(2),
          currency: propertyUnit?.currency || asset.baseCurrency || "AED",
          totalCapitalRequired: acquisition?.totalAcquisitionCost || "0",
          ledgerEntries: data.entries.map(e => ({
            id: e.id,
            direction: e.direction,
            units: e.units,
            unitPriceAtTime: e.unitPriceAtTime,
            totalValue: e.totalValue,
            reason: e.reason,
            notes: e.notes,
            createdAt: e.createdAt,
          })),
        });
      }

      res.json({ ownership });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/properties/:assetId/ownership", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const assetId = String(req.params.assetId);
      const asset = await storage.getAsset(assetId);
      if (!asset) return res.status(404).json({ message: "Property not found" });

      const propertyUnit = await storage.getPropertyUnit(assetId);
      if (!propertyUnit) return res.json({ owners: [], summary: null });

      const ledgerEntries = await storage.getPropertyUnitLedger(assetId);
      const totalUnits = parseFloat(propertyUnit.totalUnits);

      const ownerBalances = new Map<string, number>();
      for (const entry of ledgerEntries) {
        if (!entry.userId) continue;
        const current = ownerBalances.get(entry.userId) || 0;
        const units = parseFloat(entry.units);
        ownerBalances.set(entry.userId, entry.direction === "CREDIT" ? current + units : current - units);
      }

      const owners = [];
      for (const [userId, balance] of ownerBalances) {
        if (balance <= 0) continue;
        const user = await storage.getUser(userId);
        owners.push({
          userId,
          username: user?.username || userId,
          fullName: user?.fullName || "Unknown",
          unitsOwned: balance.toFixed(6),
          percentageOwned: totalUnits > 0 ? ((balance / totalUnits) * 100).toFixed(4) : "0",
          currentValue: (balance * parseFloat(propertyUnit.unitPrice)).toFixed(2),
        });
      }

      owners.sort((a, b) => parseFloat(b.unitsOwned) - parseFloat(a.unitsOwned));

      const totalAllocated = owners.reduce((sum, o) => sum + parseFloat(o.unitsOwned), 0);

      res.json({
        property: {
          assetId,
          name: asset.name,
          symbol: asset.symbol,
          location: asset.location,
          country: asset.country,
        },
        unitConfig: {
          totalUnits: propertyUnit.totalUnits,
          unitPrice: propertyUnit.unitPrice,
          currency: propertyUnit.currency,
          unitsIssued: propertyUnit.unitsIssued,
          status: propertyUnit.status,
        },
        summary: {
          totalOwners: owners.length,
          totalAllocated: totalAllocated.toFixed(6),
          totalUnallocated: (totalUnits - totalAllocated).toFixed(6),
          percentAllocated: totalUnits > 0 ? ((totalAllocated / totalUnits) * 100).toFixed(2) : "0",
        },
        owners,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
}
