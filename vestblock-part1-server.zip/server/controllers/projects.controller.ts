import type { Express, Request, Response } from "express";
import { storage } from "../storage";
import { requireAuth, requireTenantAction } from "../auth";

function p(val: string | string[]): string {
  return Array.isArray(val) ? val[0] : val;
}

export function registerProjectRoutes(app: Express) {
  app.get("/api/tenant/:tenantId/projects", requireAuth, requireTenantAction("tenant_projects.view"), async (req: Request, res: Response) => {
    try {
      const tenantId = p(req.params.tenantId);
      const projects = await storage.getProjectsByTenant(tenantId);
      const projectsWithMembers = await Promise.all(
        projects.map(async (project) => {
          const members = await storage.getProjectMembers(project.id);
          const membersWithUsers = await Promise.all(
            members.map(async (m) => {
              const user = await storage.getUser(m.userId);
              return { ...m, user: user ? { id: user.id, fullName: user.fullName, email: user.email, avatarUrl: user.avatarUrl } : null };
            })
          );
          return { ...project, members: membersWithUsers };
        })
      );
      res.json(projectsWithMembers);
    } catch (err: any) {
      console.error("Get projects error:", err);
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  app.get("/api/tenant/:tenantId/projects/my", requireAuth, requireTenantAction("tenant_projects.view"), async (req: Request, res: Response) => {
    try {
      const tenantId = p(req.params.tenantId);
      const userId = (req as any).user?.userId;
      if (!userId) return res.status(401).json({ message: "Unauthorized" });
      const projects = await storage.getProjectsForUser(userId, tenantId);
      res.json(projects);
    } catch (err: any) {
      console.error("Get my projects error:", err);
      res.status(500).json({ message: "Failed to fetch assigned projects" });
    }
  });

  app.get("/api/tenant/:tenantId/projects/:projectId", requireAuth, requireTenantAction("tenant_projects.view"), async (req: Request, res: Response) => {
    try {
      const project = await storage.getProjectById(p(req.params.projectId));
      if (!project || project.tenantId !== p(req.params.tenantId)) {
        return res.status(404).json({ message: "Project not found" });
      }
      const members = await storage.getProjectMembers(project.id);
      const membersWithUsers = await Promise.all(
        members.map(async (m) => {
          const user = await storage.getUser(m.userId);
          return { ...m, user: user ? { id: user.id, fullName: user.fullName, email: user.email, avatarUrl: user.avatarUrl } : null };
        })
      );
      const activityLogs = await storage.getProjectActivityLogs(project.id);
      const logsWithUsers = await Promise.all(
        activityLogs.map(async (log) => {
          const user = await storage.getUser(log.userId);
          return { ...log, user: user ? { id: user.id, fullName: user.fullName } : null };
        })
      );
      res.json({ ...project, members: membersWithUsers, activityLogs: logsWithUsers });
    } catch (err: any) {
      console.error("Get project error:", err);
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });

  app.post("/api/tenant/:tenantId/projects", requireAuth, requireTenantAction("tenant_projects.manage"), async (req: Request, res: Response) => {
    try {
      const tenantId = p(req.params.tenantId);
      const userId = (req as any).user?.userId;
      const data = { ...req.body, tenantId, createdBy: userId };
      const project = await storage.createProject(data);
      await storage.addProjectActivityLog({ projectId: project.id, userId, action: "PROJECT_CREATED", details: `Project "${project.name}" created` });
      res.status(201).json(project);
    } catch (err: any) {
      console.error("Create project error:", err);
      res.status(500).json({ message: "Failed to create project" });
    }
  });

  app.patch("/api/tenant/:tenantId/projects/:projectId", requireAuth, requireTenantAction("tenant_projects.manage"), async (req: Request, res: Response) => {
    try {
      const projectId = p(req.params.projectId);
      const tenantId = p(req.params.tenantId);
      const existing = await storage.getProjectById(projectId);
      if (!existing || existing.tenantId !== tenantId) {
        return res.status(404).json({ message: "Project not found" });
      }
      const userId = (req as any).user?.userId;
      const updated = await storage.updateProject(projectId, req.body);
      if (req.body.status && req.body.status !== existing.status) {
        await storage.addProjectActivityLog({ projectId, userId, action: "STATUS_CHANGED", details: `Status changed from ${existing.status} to ${req.body.status}` });
      }
      res.json(updated);
    } catch (err: any) {
      console.error("Update project error:", err);
      res.status(500).json({ message: "Failed to update project" });
    }
  });

  app.delete("/api/tenant/:tenantId/projects/:projectId", requireAuth, requireTenantAction("tenant_projects.manage"), async (req: Request, res: Response) => {
    try {
      const projectId = p(req.params.projectId);
      const tenantId = p(req.params.tenantId);
      const existing = await storage.getProjectById(projectId);
      if (!existing || existing.tenantId !== tenantId) {
        return res.status(404).json({ message: "Project not found" });
      }
      await storage.deleteProject(projectId);
      res.json({ success: true });
    } catch (err: any) {
      console.error("Delete project error:", err);
      res.status(500).json({ message: "Failed to delete project" });
    }
  });

  app.post("/api/tenant/:tenantId/projects/:projectId/members", requireAuth, requireTenantAction("tenant_projects.manage"), async (req: Request, res: Response) => {
    try {
      const projectId = p(req.params.projectId);
      const tenantId = p(req.params.tenantId);
      const existing = await storage.getProjectById(projectId);
      if (!existing || existing.tenantId !== tenantId) {
        return res.status(404).json({ message: "Project not found" });
      }
      const { userId, role } = req.body;
      if (!userId || !role) return res.status(400).json({ message: "userId and role are required" });
      const existingMembers = await storage.getProjectMembers(projectId);
      if (existingMembers.some(m => m.userId === userId)) {
        return res.status(409).json({ message: "User is already a member of this project" });
      }
      const member = await storage.addProjectMember({ projectId, userId, role });
      const actorId = (req as any).user?.userId;
      const user = await storage.getUser(userId);
      await storage.addProjectActivityLog({ projectId, userId: actorId, action: "MEMBER_ADDED", details: `${user?.fullName || userId} added as ${role}` });
      res.status(201).json(member);
    } catch (err: any) {
      console.error("Add project member error:", err);
      res.status(500).json({ message: "Failed to add project member" });
    }
  });

  app.delete("/api/tenant/:tenantId/projects/:projectId/members/:userId", requireAuth, requireTenantAction("tenant_projects.manage"), async (req: Request, res: Response) => {
    try {
      const projectId = p(req.params.projectId);
      const tenantId = p(req.params.tenantId);
      const userId = p(req.params.userId);
      const existing = await storage.getProjectById(projectId);
      if (!existing || existing.tenantId !== tenantId) {
        return res.status(404).json({ message: "Project not found" });
      }
      await storage.removeProjectMember(projectId, userId);
      const actorId = (req as any).user?.userId;
      const user = await storage.getUser(userId);
      await storage.addProjectActivityLog({ projectId, userId: actorId, action: "MEMBER_REMOVED", details: `${user?.fullName || userId} removed` });
      res.json({ success: true });
    } catch (err: any) {
      console.error("Remove project member error:", err);
      res.status(500).json({ message: "Failed to remove project member" });
    }
  });

  app.get("/api/tenant/:tenantId/projects/:projectId/activity", requireAuth, requireTenantAction("tenant_projects.view"), async (req: Request, res: Response) => {
    try {
      const projectId = p(req.params.projectId);
      const logs = await storage.getProjectActivityLogs(projectId);
      const logsWithUsers = await Promise.all(
        logs.map(async (log) => {
          const user = await storage.getUser(log.userId);
          return { ...log, user: user ? { id: user.id, fullName: user.fullName } : null };
        })
      );
      res.json(logsWithUsers);
    } catch (err: any) {
      console.error("Get activity logs error:", err);
      res.status(500).json({ message: "Failed to fetch activity logs" });
    }
  });

  app.post("/api/tenant/:tenantId/projects/:projectId/activity", requireAuth, requireTenantAction("tenant_projects.manage"), async (req: Request, res: Response) => {
    try {
      const projectId = p(req.params.projectId);
      const tenantId = p(req.params.tenantId);
      const existing = await storage.getProjectById(projectId);
      if (!existing || existing.tenantId !== tenantId) {
        return res.status(404).json({ message: "Project not found" });
      }
      const userId = (req as any).user?.userId;
      const { action, details } = req.body;
      if (!action) return res.status(400).json({ message: "action is required" });
      const log = await storage.addProjectActivityLog({ projectId, userId, action, details });
      res.status(201).json(log);
    } catch (err: any) {
      console.error("Add activity log error:", err);
      res.status(500).json({ message: "Failed to add activity log" });
    }
  });
}
