import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { logAuditFromReq } from "../lib/audit-logger";
import { createFxRateSchema } from "@shared/schema";
import { getLiveRate, createQuote, executeConversion, getFxQuote, getActiveProviders } from "../fx";
import { listAllProviders } from "../fx-providers";
import { z } from "zod";
import { walletCurrencySchema } from "@shared/constants";
import { isFxAllowed, isActionBlocked, getPolicy } from "@shared/compliance-policy";
import { fxQuoteRequestSchema, fxConvertRequestSchema } from "@shared/dto/fx.dto";
import { validateBody } from "../middleware/validate";

export function registerFxRoutes(app: Express) {

  app.get("/api/fx/rate", requireAuth, async (req, res) => {
    try {
      const from = req.query.from as string;
      const to = req.query.to as string;
      if (!from || !to) return res.status(400).json({ message: "from and to query params required" });
      const rateData = await getLiveRate(from, to);
      if (rateData === null) return res.status(400).json({ message: `No exchange rate available for ${from} → ${to}` });
      res.json({
        from, to,
        rate: rateData.rate,
        spread: rateData.spread,
        provider: rateData.provider,
        sourceLabel: rateData.sourceLabel,
        fetchedAt: rateData.fetchedAt,
      });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch exchange rate" });
    }
  });

  app.post("/api/fx/quote", requireAuth, validateBody(fxQuoteRequestSchema), async (req, res) => {
    try {
      const data = req.body;
      if (data.fromCurrency === data.toCurrency) {
        return res.status(400).json({ message: "Cannot convert to the same currency" });
      }
      const userId = (req as any).user.userId;
      const quote = await createQuote(data.fromCurrency, data.toCurrency, data.amount, userId);
      if (!quote) return res.status(400).json({ message: `No exchange rate available for ${data.fromCurrency} → ${data.toCurrency}` });
      res.json(quote);
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      res.status(500).json({ message: "Failed to get FX quote" });
    }
  });

  app.post("/api/fx/convert", requireAuth, validateBody(fxConvertRequestSchema), async (req, res) => {
    try {
      const userId = (req as any).user.userId;

      const countryProfiles = await storage.getCountryProfiles(userId);
      const primary = countryProfiles.find(p => p.isPrimary) || countryProfiles[0];
      const userCountry = primary?.countryCode || "AE";

      if (!isFxAllowed(userCountry) || isActionBlocked(userCountry, "fx_conversion")) {
        const policy = getPolicy(userCountry);
        return res.status(403).json({
          message: `FX conversion is not available for ${policy.countryName} residents due to regulatory restrictions`,
        });
      }

      const result = await executeConversion(userId, req.body.quoteId);

      await logAuditFromReq(req, "FX_CONVERT", "wallet", result.referenceId, {
        reason: `Converted ${result.fxTransaction.fromCurrency} ${result.fxTransaction.amountFrom} → ${result.fxTransaction.toCurrency} ${result.fxTransaction.amountTo} at rate ${result.fxTransaction.rateUsed}`,
        metadata: { fromCurrency: result.fxTransaction.fromCurrency, toCurrency: result.fxTransaction.toCurrency, rate: result.fxTransaction.rateUsed },
      });

      res.json({
        success: true,
        fxTransactionId: result.fxTransaction.id,
        fromCurrency: result.fxTransaction.fromCurrency,
        toCurrency: result.fxTransaction.toCurrency,
        amountDebited: parseFloat(result.fxTransaction.amountFrom),
        amountCredited: parseFloat(result.fxTransaction.amountTo),
        fee: parseFloat(result.fxTransaction.fees),
        spread: parseFloat(result.fxTransaction.spread),
        spreadAmount: parseFloat(result.fxTransaction.spreadAmount),
        rate: parseFloat(result.fxTransaction.rateUsed),
        referenceId: result.referenceId,
        ledgerTxId: result.ledgerTxId,
      });
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      if (err.message.includes("expired") || err.message.includes("not found") ||
          err.message.includes("Insufficient") || err.message.includes("no longer active") ||
          err.message.includes("does not belong")) {
        return res.status(400).json({ message: err.message });
      }
      console.error("FX convert error:", err);
      res.status(500).json({ message: "Failed to convert currency" });
    }
  });

  app.get("/api/fx/transactions", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const transactions = await storage.getFxTransactionsByUser(userId);
      res.json(transactions);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch FX transactions" });
    }
  });

  app.get("/api/fx/transactions/:id", requireAuth, async (req, res) => {
    try {
      const tx = await storage.getFxTransactionById(req.params.id as string);
      if (!tx) return res.status(404).json({ message: "FX transaction not found" });
      const userId = (req as any).user.userId;
      if (tx.userId !== userId) return res.status(403).json({ message: "Access denied" });
      res.json(tx);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch FX transaction" });
    }
  });

  app.get("/api/admin/fx-rates", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const rates = await storage.getAllFxRates();
      res.json(rates);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch FX rates" });
    }
  });

  app.post("/api/admin/fx-rates", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const data = createFxRateSchema.parse(req.body);
      if (data.fromCurrency === data.toCurrency) {
        return res.status(400).json({ message: "From and To currencies must be different" });
      }
      const rate = await storage.createFxRate({
        fromCurrency: data.fromCurrency,
        toCurrency: data.toCurrency,
        rate: data.rate,
        spread: data.spread || "0",
        provider: data.provider || "manual",
        sourceLabel: data.sourceLabel || "manual",
        isActive: true,
        createdBy: userId,
      });
      res.json(rate);
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Create FX rate error:", err);
      res.status(500).json({ message: "Failed to create FX rate" });
    }
  });

  app.post("/api/admin/fx-rates/:id/deactivate", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const rate = await storage.deactivateFxRate(req.params.id as string);
      if (!rate) return res.status(404).json({ message: "FX rate not found" });
      res.json(rate);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to deactivate FX rate" });
    }
  });

  app.get("/api/admin/fx-providers", requireAuth, requireRole("admin"), async (_req, res) => {
    try {
      res.json(listAllProviders());
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch providers" });
    }
  });

  app.get("/api/admin/fx-rates/history", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const from = req.query.from as string | undefined;
      const to = req.query.to as string | undefined;
      const allRates = await storage.getAllFxRates();
      let filtered = allRates;
      if (from) filtered = filtered.filter(r => r.fromCurrency === from);
      if (to) filtered = filtered.filter(r => r.toCurrency === to);
      res.json(filtered);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch rate history" });
    }
  });
}
