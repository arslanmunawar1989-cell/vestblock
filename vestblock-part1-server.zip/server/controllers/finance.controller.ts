import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { z } from "zod";
import { calculateWaterfall, buildProofs } from "../services/waterfall-calculator.service";
import { executeDistribution } from "../services/distribution.service";
import { createValuationUpdateSchema, advanceSettlementSchema, settlementDocumentTypeEnum } from "@shared/schema";
import { paymentLimiter } from "../middleware/rate-limit";

const rentCollectionSchema = z.object({
  assetId: z.string().min(1),
  period: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/, "Period must be YYYY-MM format"),
  grossRent: z.string().refine(v => parseFloat(v) > 0, "Gross rent must be positive"),
  occupancyRate: z.string().optional().default("100.00"),
  latePaymentPenalty: z.string().optional().default("0"),
  vacancyAdjustment: z.string().optional().default("0"),
  currency: z.string().min(1),
  receivedDate: z.string().min(1),
  notes: z.string().optional(),
});

const operatingExpenseSchema = z.object({
  assetId: z.string().min(1),
  period: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/, "Period must be YYYY-MM format"),
  category: z.string().min(1),
  description: z.string().optional(),
  amount: z.string().refine(v => parseFloat(v) > 0, "Amount must be positive"),
  currency: z.string().min(1),
});

async function normalizeToBaseCurrency(
  amount: string,
  currency: string,
  baseCurrency: string
): Promise<{ baseCurrencyAmount: string; fxRate: string }> {
  if (currency === baseCurrency) {
    return { baseCurrencyAmount: amount, fxRate: "1.000000" };
  }

  const fxRate = await storage.getActiveFxRate(currency, baseCurrency);
  if (fxRate) {
    const rate = parseFloat(fxRate.rate);
    const converted = (parseFloat(amount) * rate).toFixed(2);
    return { baseCurrencyAmount: converted, fxRate: fxRate.rate };
  }

  const reverseRate = await storage.getActiveFxRate(baseCurrency, currency);
  if (reverseRate) {
    const rate = 1 / parseFloat(reverseRate.rate);
    const converted = (parseFloat(amount) * rate).toFixed(2);
    return { baseCurrencyAmount: converted, fxRate: rate.toFixed(6) };
  }

  return { baseCurrencyAmount: amount, fxRate: "1.000000" };
}

export function registerFinanceRoutes(app: Express) {
  app.post("/api/finance/rent-collections", requireAuth, paymentLimiter, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can post rent collections" });
      }

      const parsed = rentCollectionSchema.parse(req.body);

      const asset = await storage.getAsset(parsed.assetId);
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }

      const baseCurrency = asset.baseCurrency || "AED";
      const { baseCurrencyAmount, fxRate } = await normalizeToBaseCurrency(
        parsed.grossRent, parsed.currency, baseCurrency
      );

      const grossRentNum = parseFloat(parsed.grossRent);
      const vacancyAdj = parseFloat(parsed.vacancyAdjustment || "0");
      const latePayment = parseFloat(parsed.latePaymentPenalty || "0");
      const effectiveRent = (grossRentNum - vacancyAdj + latePayment).toFixed(2);

      const rent = await storage.createRentCollection({
        assetId: parsed.assetId,
        period: parsed.period,
        grossRent: parsed.grossRent,
        occupancyRate: parsed.occupancyRate || "100.00",
        latePaymentPenalty: parsed.latePaymentPenalty || "0",
        vacancyAdjustment: parsed.vacancyAdjustment || "0",
        effectiveRent,
        currency: parsed.currency,
        baseCurrencyAmount,
        baseCurrency,
        fxRate,
        receivedDate: parsed.receivedDate,
        notes: parsed.notes || null,
        postedBy: user.userId,
      });

      res.status(201).json(rent);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/finance/rent-collections", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can view rent collections" });
      }

      const { assetId, period } = req.query;
      if (assetId && period) {
        const rents = await storage.getRentCollectionsByPeriod(assetId as string, period as string);
        return res.json(rents);
      }
      if (assetId) {
        const rents = await storage.getRentCollectionsByAsset(assetId as string);
        return res.json(rents);
      }
      const rents = await storage.getAllRentCollections(req.tenantId);
      res.json(rents);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/finance/operating-expenses", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can post operating expenses" });
      }

      const parsed = operatingExpenseSchema.parse(req.body);

      const asset = await storage.getAsset(parsed.assetId);
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }

      const baseCurrency = asset.baseCurrency || "AED";
      const { baseCurrencyAmount, fxRate } = await normalizeToBaseCurrency(
        parsed.amount, parsed.currency, baseCurrency
      );

      const expense = await storage.createOperatingExpense({
        assetId: parsed.assetId,
        period: parsed.period,
        category: parsed.category,
        description: parsed.description || null,
        amount: parsed.amount,
        currency: parsed.currency,
        baseCurrencyAmount,
        baseCurrency,
        fxRate,
        postedBy: user.userId,
      });

      res.status(201).json(expense);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/finance/operating-expenses", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can view operating expenses" });
      }

      const { assetId, period } = req.query;
      if (assetId && period) {
        const expenses = await storage.getOperatingExpensesByPeriod(assetId as string, period as string);
        return res.json(expenses);
      }
      if (assetId) {
        const expenses = await storage.getOperatingExpensesByAsset(assetId as string);
        return res.json(expenses);
      }
      const expenses = await storage.getAllOperatingExpenses(req.tenantId);
      res.json(expenses);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/rental-operations/:assetId", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can view rental operations" });
      }

      const assetId = String(req.params.assetId);
      const asset = await storage.getAsset(assetId);
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }

      const allRents = await storage.getRentCollectionsByAsset(assetId);
      const allExpenses = await storage.getOperatingExpensesByAsset(assetId);
      const baseCurrency = asset.baseCurrency || "AED";

      const periodsSet = new Set<string>();
      allRents.forEach(r => periodsSet.add(r.period));
      allExpenses.forEach(e => periodsSet.add(e.period));
      const periods = Array.from(periodsSet).sort().reverse();

      const monthlyCycles = periods.map(period => {
        const periodRents = allRents.filter(r => r.period === period);
        const periodExpenses = allExpenses.filter(e => e.period === period);

        const grossRent = periodRents.reduce((s, r) => s + parseFloat(r.baseCurrencyAmount || r.grossRent), 0);
        const occupancyRate = periodRents.length > 0
          ? periodRents.reduce((s, r) => s + parseFloat(r.occupancyRate || "100"), 0) / periodRents.length
          : 100;
        const vacancyAdjustment = periodRents.reduce((s, r) => s + parseFloat(r.vacancyAdjustment || "0"), 0);
        const latePaymentPenalty = periodRents.reduce((s, r) => s + parseFloat(r.latePaymentPenalty || "0"), 0);
        const effectiveRent = grossRent - vacancyAdjustment + latePaymentPenalty;

        const expensesByCategory: Record<string, number> = {};
        for (const e of periodExpenses) {
          expensesByCategory[e.category] = (expensesByCategory[e.category] || 0) + parseFloat(e.baseCurrencyAmount || e.amount);
        }

        const maintenance = expensesByCategory["maintenance"] || 0;
        const managementFee = expensesByCategory["management_fee"] || 0;
        const insurance = expensesByCategory["insurance"] || 0;
        const propertyTax = expensesByCategory["property_tax"] || 0;
        const utilityReserve = expensesByCategory["utility_reserve"] || 0;
        const otherExpenses = Object.entries(expensesByCategory)
          .filter(([cat]) => !["maintenance", "management_fee", "insurance", "property_tax", "utility_reserve", "vacancy_adjustment", "late_payment"].includes(cat))
          .reduce((s, [, v]) => s + v, 0);

        const opPeriodExpenses = periodExpenses.filter(e => !["vacancy_adjustment", "late_payment"].includes(e.category));
        const totalExpenses = opPeriodExpenses.reduce((s, e) => s + parseFloat(e.baseCurrencyAmount || e.amount), 0);
        const netOperatingIncome = effectiveRent - totalExpenses;

        return {
          period,
          rentCollection: {
            grossRent: grossRent.toFixed(2),
            occupancyRate: occupancyRate.toFixed(2),
            vacancyAdjustment: vacancyAdjustment.toFixed(2),
            latePaymentPenalty: latePaymentPenalty.toFixed(2),
            effectiveRent: effectiveRent.toFixed(2),
            entries: periodRents,
          },
          operatingExpenses: {
            maintenance: maintenance.toFixed(2),
            managementFee: managementFee.toFixed(2),
            insurance: insurance.toFixed(2),
            propertyTax: propertyTax.toFixed(2),
            utilityReserve: utilityReserve.toFixed(2),
            otherExpenses: otherExpenses.toFixed(2),
            totalExpenses: totalExpenses.toFixed(2),
            entries: periodExpenses,
          },
          netOperatingIncome: netOperatingIncome.toFixed(2),
        };
      });

      const totalGrossRent = monthlyCycles.reduce((s, c) => s + parseFloat(c.rentCollection.grossRent), 0);
      const totalEffectiveRent = monthlyCycles.reduce((s, c) => s + parseFloat(c.rentCollection.effectiveRent), 0);
      const totalAllExpenses = monthlyCycles.reduce((s, c) => s + parseFloat(c.operatingExpenses.totalExpenses), 0);
      const totalNOI = monthlyCycles.reduce((s, c) => s + parseFloat(c.netOperatingIncome), 0);

      res.json({
        assetId,
        assetName: asset.name,
        baseCurrency,
        currency: asset.baseCurrency || "AED",
        summary: {
          totalPeriods: periods.length,
          totalGrossRent: totalGrossRent.toFixed(2),
          totalEffectiveRent: totalEffectiveRent.toFixed(2),
          totalExpenses: totalAllExpenses.toFixed(2),
          totalNetOperatingIncome: totalNOI.toFixed(2),
          avgOccupancyRate: monthlyCycles.length > 0
            ? (monthlyCycles.reduce((s, c) => s + parseFloat(c.rentCollection.occupancyRate), 0) / monthlyCycles.length).toFixed(2)
            : "100.00",
        },
        monthlyCycles,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/rental-operations", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can view rental operations" });
      }

      const assets = await storage.getAssets(req.tenantId);
      const propertyAssets = assets.filter(a => a.assetType === "real_estate" || a.propertyType);

      const summaries = [];
      for (const asset of propertyAssets) {
        const rents = await storage.getRentCollectionsByAsset(asset.id);
        const expenses = await storage.getOperatingExpensesByAsset(asset.id);

        const periodsSet = new Set<string>();
        rents.forEach(r => periodsSet.add(r.period));
        expenses.forEach(e => periodsSet.add(e.period));
        const sortedPeriods = Array.from(periodsSet).sort().reverse();

        const totalGrossRent = rents.reduce((s, r) => s + parseFloat(r.baseCurrencyAmount || r.grossRent), 0);
        const totalVacancyAdj = rents.reduce((s, r) => s + parseFloat(r.vacancyAdjustment || "0"), 0);
        const totalLatePenalty = rents.reduce((s, r) => s + parseFloat(r.latePaymentPenalty || "0"), 0);
        const totalEffectiveRent = totalGrossRent - totalVacancyAdj + totalLatePenalty;
        const opExpenses = expenses.filter(e => !["vacancy_adjustment", "late_payment"].includes(e.category));
        const totalExpenses = opExpenses.reduce((s, e) => s + parseFloat(e.baseCurrencyAmount || e.amount), 0);

        summaries.push({
          assetId: asset.id,
          assetName: asset.name,
          location: asset.location,
          propertyType: asset.propertyType,
          baseCurrency: asset.baseCurrency || "AED",
          totalPeriods: periodsSet.size,
          totalGrossRent: totalGrossRent.toFixed(2),
          totalExpenses: totalExpenses.toFixed(2),
          netOperatingIncome: (totalEffectiveRent - totalExpenses).toFixed(2),
          latestPeriod: sortedPeriods.length > 0 ? sortedPeriods[0] : null,
        });
      }

      res.json(summaries);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/finance/summary/:assetId/:period", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can view financial summaries" });
      }

      const assetId = String(req.params.assetId);
      const period = String(req.params.period);

      const asset = await storage.getAsset(assetId);
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }

      const rents = await storage.getRentCollectionsByPeriod(assetId, period);
      const expenses = await storage.getOperatingExpensesByPeriod(assetId, period);

      const baseCurrency = asset.baseCurrency || "AED";

      const totalGrossRent = rents.reduce(
        (sum, r) => sum + parseFloat(r.baseCurrencyAmount || r.grossRent), 0
      );
      const totalExpenses = expenses.reduce(
        (sum, e) => sum + parseFloat(e.baseCurrencyAmount || e.amount), 0
      );
      const netOperatingIncome = totalGrossRent - totalExpenses;

      const expensesByCategory: Record<string, number> = {};
      for (const e of expenses) {
        const cat = e.category;
        expensesByCategory[cat] = (expensesByCategory[cat] || 0) + parseFloat(e.baseCurrencyAmount || e.amount);
      }

      res.json({
        assetId,
        assetName: asset.name,
        period,
        baseCurrency,
        totalGrossRent: totalGrossRent.toFixed(2),
        totalExpenses: totalExpenses.toFixed(2),
        netOperatingIncome: netOperatingIncome.toFixed(2),
        rentCollectionCount: rents.length,
        expenseCount: expenses.length,
        expensesByCategory,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const waterfallInputSchema = z.object({
    assetId: z.string().min(1),
    period: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/, "Period must be YYYY-MM format"),
    reservePercent: z.number().min(0).max(100),
    platformFeePercent: z.number().min(0).max(100),
    force: z.boolean().optional().default(false),
  });

  app.post("/api/finance/waterfall", requireAuth, paymentLimiter, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can run waterfall calculations" });
      }

      const parsed = waterfallInputSchema.parse(req.body);

      const asset = await storage.getAsset(parsed.assetId);
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }

      if (asset.constructionStatus && asset.constructionStatus.toLowerCase() !== "completed") {
        return res.status(400).json({
          message: "Distributions are blocked for properties under construction. This property's construction status is: " + asset.constructionStatus,
          constructionStatus: asset.constructionStatus,
          expectedCompletionDate: asset.expectedCompletionDate || null,
        });
      }

      const existing = await storage.getWaterfallCalculationsByPeriod(parsed.assetId, parsed.period);
      if (existing.length > 0 && !parsed.force) {
        return res.status(409).json({
          message: `Waterfall already calculated for ${parsed.period}. Set force=true to recalculate.`,
          existingId: existing[0].id,
          existingNetDistributable: existing[0].netDistributable,
        });
      }

      const baseCurrency = asset.baseCurrency || "AED";

      const rents = await storage.getRentCollectionsByPeriod(parsed.assetId, parsed.period);
      const expenses = await storage.getOperatingExpensesByPeriod(parsed.assetId, parsed.period);

      if (rents.length === 0) {
        return res.status(400).json({ message: `No rent collections found for asset ${parsed.assetId} in period ${parsed.period}` });
      }

      const grossRent = rents.reduce(
        (sum, r) => sum + parseFloat(r.baseCurrencyAmount || r.grossRent), 0
      );
      const vacancyImpact = rents.reduce(
        (sum, r) => sum + parseFloat(r.vacancyAdjustment || "0"), 0
      );

      const opExpenses = expenses.filter(e => !["vacancy_adjustment", "late_payment"].includes(e.category));
      const expByCat: Record<string, number> = {};
      for (const e of opExpenses) {
        const cat = e.category;
        expByCat[cat] = (expByCat[cat] || 0) + parseFloat(e.baseCurrencyAmount || e.amount);
      }

      const propertyUnit = await storage.getPropertyUnit(parsed.assetId);
      const totalUnits = propertyUnit ? parseFloat(propertyUnit.totalUnits) : undefined;

      const feeRates = {
        reservePercent: parsed.reservePercent,
        platformFeePercent: parsed.platformFeePercent,
      };

      const result = calculateWaterfall({
        grossRent,
        vacancyImpact,
        expensesByCategory: expByCat,
        platformFeePercent: parsed.platformFeePercent,
        reservePercent: parsed.reservePercent,
        totalUnits,
      });

      if (result.unitDistribution) {
        result.unitDistribution.currency = baseCurrency;
      }

      const proofs = buildProofs(parsed.assetId, parsed.period, baseCurrency, result, rents, opExpenses, feeRates);

      let investorPayouts: Array<{ userId: string; username?: string; units: string; incomePerUnit: string; totalPayout: string }> = [];
      if (propertyUnit && result.unitDistribution) {
        const unitLedger = await storage.getPropertyUnitLedger(parsed.assetId);
        const userBalances: Record<string, number> = {};
        for (const entry of unitLedger) {
          if (!entry.userId) continue;
          const units = parseFloat(entry.units);
          if (entry.direction === "CREDIT") {
            userBalances[entry.userId] = (userBalances[entry.userId] || 0) + units;
          } else {
            userBalances[entry.userId] = (userBalances[entry.userId] || 0) - units;
          }
        }

        const incomePerUnit = parseFloat(result.unitDistribution.incomePerUnit);
        const activeHolders = Object.entries(userBalances).filter(([, u]) => u > 0);
        const userObjects = await Promise.all(activeHolders.map(([uid]) => storage.getUser(uid)));
        activeHolders.forEach(([userId, units], i) => {
          investorPayouts.push({
            userId,
            username: userObjects[i]?.username || userId,
            units: units.toFixed(6),
            incomePerUnit: incomePerUnit.toFixed(6),
            totalPayout: (units * incomePerUnit).toFixed(2),
          });
        });
      }

      const saved = await storage.createWaterfallCalculation({
        assetId: parsed.assetId,
        period: parsed.period,
        baseCurrency,
        grossRent: result.grossRent,
        totalExpenses: result.totalExpenses,
        netOperatingIncome: result.netOperatingIncome,
        reservePercent: result.reservePercent,
        reserveAmount: result.reserveAmount,
        propertyMgmtFeePercent: result.propertyMgmtFeePercent,
        propertyMgmtFeeAmount: result.propertyMgmtFeeAmount,
        platformFeePercent: result.platformFeePercent,
        platformFeeAmount: result.platformFeeAmount,
        trusteeFeePercent: result.trusteeFeePercent,
        trusteeFeeAmount: result.trusteeFeeAmount,
        totalFees: result.totalFees,
        netDistributable: result.netDistributable,
        breakdown: { steps: result.breakdown, proofs, investorPayouts },
        calculatedBy: user.userId,
      });

      if (parseFloat(result.reserveAmount) > 0) {
        await storage.createReserveFundEntry({
          assetId: parsed.assetId,
          period: parsed.period,
          entryType: "CREDIT",
          amount: result.reserveAmount,
          currency: baseCurrency,
          waterfallCalculationId: saved.id,
          description: `Reserve from waterfall ${parsed.period} (${result.reservePercent}% of NOI)`,
          postedBy: user.userId,
        });
      }

      const reserveBalance = await storage.getReserveFundBalance(parsed.assetId);

      res.status(201).json({
        ...saved,
        reserveBalance,
        unitDistribution: result.unitDistribution,
        investorPayouts,
      });
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/finance/waterfall/:id", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can view waterfall calculations" });
      }

      const calc = await storage.getWaterfallCalculation(String(req.params.id));
      if (!calc) {
        return res.status(404).json({ message: "Waterfall calculation not found" });
      }
      res.json(calc);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/finance/waterfall/:id/proofs", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can view waterfall proofs" });
      }

      const calc = await storage.getWaterfallCalculation(String(req.params.id));
      if (!calc) {
        return res.status(404).json({ message: "Waterfall calculation not found" });
      }

      const breakdown = calc.breakdown as any;
      if (breakdown?.proofs) {
        return res.json({
          waterfallId: calc.id,
          period: calc.period,
          assetId: calc.assetId,
          netDistributable: calc.netDistributable,
          proofs: breakdown.proofs,
          steps: breakdown.steps || [],
        });
      }

      res.json({
        waterfallId: calc.id,
        period: calc.period,
        assetId: calc.assetId,
        netDistributable: calc.netDistributable,
        proofs: null,
        steps: Array.isArray(breakdown) ? breakdown : [],
        note: "This waterfall was calculated before proof tracking was added",
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/finance/waterfall", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can view waterfall calculations" });
      }

      const { assetId, period } = req.query;
      if (assetId && period) {
        const calcs = await storage.getWaterfallCalculationsByPeriod(assetId as string, period as string);
        return res.json(calcs);
      }
      if (assetId) {
        const calcs = await storage.getWaterfallCalculationsByAsset(assetId as string);
        return res.json(calcs);
      }
      res.status(400).json({ message: "assetId query parameter is required" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/finance/waterfall/preview", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can preview waterfall" });
      }

      const parsed = waterfallInputSchema.parse(req.body);

      const asset = await storage.getAsset(parsed.assetId);
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }

      if (asset.constructionStatus && asset.constructionStatus.toLowerCase() !== "completed") {
        return res.status(400).json({
          message: "Distributions are blocked for properties under construction. This property's construction status is: " + asset.constructionStatus,
          constructionStatus: asset.constructionStatus,
          expectedCompletionDate: asset.expectedCompletionDate || null,
        });
      }

      const baseCurrency = asset.baseCurrency || "AED";

      const rents = await storage.getRentCollectionsByPeriod(parsed.assetId, parsed.period);
      const expenses = await storage.getOperatingExpensesByPeriod(parsed.assetId, parsed.period);

      if (rents.length === 0) {
        return res.status(400).json({ message: `No rent collections found for asset ${parsed.assetId} in period ${parsed.period}` });
      }

      const grossRent = rents.reduce(
        (sum, r) => sum + parseFloat(r.baseCurrencyAmount || r.grossRent), 0
      );
      const vacancyImpact = rents.reduce(
        (sum, r) => sum + parseFloat(r.vacancyAdjustment || "0"), 0
      );

      const opExpenses = expenses.filter(e => !["vacancy_adjustment", "late_payment"].includes(e.category));
      const expByCat: Record<string, number> = {};
      for (const e of opExpenses) {
        const cat = e.category;
        expByCat[cat] = (expByCat[cat] || 0) + parseFloat(e.baseCurrencyAmount || e.amount);
      }

      const propertyUnit = await storage.getPropertyUnit(parsed.assetId);
      const totalUnits = propertyUnit ? parseFloat(propertyUnit.totalUnits) : undefined;

      const result = calculateWaterfall({
        grossRent,
        vacancyImpact,
        expensesByCategory: expByCat,
        platformFeePercent: parsed.platformFeePercent,
        reservePercent: parsed.reservePercent,
        totalUnits,
      });

      if (result.unitDistribution) {
        result.unitDistribution.currency = baseCurrency;
      }

      let investorPayouts: Array<{ userId: string; username?: string; units: string; incomePerUnit: string; totalPayout: string }> = [];
      if (propertyUnit && result.unitDistribution) {
        const unitLedger = await storage.getPropertyUnitLedger(parsed.assetId);
        const userBalances: Record<string, number> = {};
        for (const entry of unitLedger) {
          if (!entry.userId) continue;
          const units = parseFloat(entry.units);
          if (entry.direction === "CREDIT") {
            userBalances[entry.userId] = (userBalances[entry.userId] || 0) + units;
          } else {
            userBalances[entry.userId] = (userBalances[entry.userId] || 0) - units;
          }
        }

        const incomePerUnit = parseFloat(result.unitDistribution.incomePerUnit);
        const activeHolders = Object.entries(userBalances).filter(([, u]) => u > 0);
        const userObjects = await Promise.all(activeHolders.map(([uid]) => storage.getUser(uid)));
        activeHolders.forEach(([userId, units], i) => {
          investorPayouts.push({
            userId,
            username: userObjects[i]?.username || userId,
            units: units.toFixed(6),
            incomePerUnit: incomePerUnit.toFixed(6),
            totalPayout: (units * incomePerUnit).toFixed(2),
          });
        });
      }

      res.json({
        preview: true,
        assetId: parsed.assetId,
        assetName: asset.name,
        period: parsed.period,
        baseCurrency,
        ...result,
        investorPayouts,
        rentCollectionCount: rents.length,
        expenseCount: opExpenses.length,
      });
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  const distributionSchema = z.object({
    assetId: z.string().min(1),
    netDistributable: z.number().positive("Net distributable must be positive"),
    currency: z.string().min(1),
    waterfallCalculationId: z.string().optional(),
    recordDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Record date must be YYYY-MM-DD").optional(),
  });

  app.post("/api/finance/distributions", requireAuth, paymentLimiter, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admin can execute distributions" });
      }

      const parsed = distributionSchema.parse(req.body);

      const asset = await storage.getAsset(parsed.assetId);
      if (!asset) {
        const vehicle = await storage.getInvestmentVehicle(parsed.assetId);
        if (!vehicle) {
          return res.status(404).json({ message: "Asset or vehicle not found" });
        }
      }

      if (asset && asset.constructionStatus && asset.constructionStatus.toLowerCase() !== "completed") {
        return res.status(400).json({
          message: "Distributions are blocked for properties under construction. This property's construction status is: " + asset.constructionStatus,
          constructionStatus: asset.constructionStatus,
          expectedCompletionDate: asset.expectedCompletionDate || null,
        });
      }

      if (parsed.waterfallCalculationId) {
        const existingDistributions = await storage.getDistributionsByAsset(parsed.assetId);
        const duplicate = existingDistributions.find(
          (d: any) => d.waterfallCalculationId === parsed.waterfallCalculationId
        );
        if (duplicate) {
          return res.status(409).json({
            message: "Distribution already executed for this waterfall calculation",
            existingDistributionId: duplicate.id,
          });
        }
      }

      const result = await executeDistribution({
        assetId: parsed.assetId,
        netDistributable: parsed.netDistributable,
        currency: parsed.currency,
        waterfallCalculationId: parsed.waterfallCalculationId,
        recordDate: parsed.recordDate,
        createdBy: user.userId,
      });

      res.status(201).json(result);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/finance/distributions/:distributionId/payouts", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can view distribution payouts" });
      }

      const payouts = await storage.getDistributionPayoutsByDistribution(String(req.params.distributionId));
      res.json(payouts);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/finance/distributions/:distributionId/snapshot", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can view snapshots" });
      }

      const dist = await storage.getDistribution(String(req.params.distributionId));
      if (!dist) {
        return res.status(404).json({ message: "Distribution not found" });
      }

      if (!dist.snapshotId) {
        return res.json({ distributionId: dist.id, snapshot: null, note: "Distribution was created before snapshot tracking" });
      }

      const snapshot = await storage.getDistributionSnapshot(dist.snapshotId);
      if (!snapshot) {
        return res.status(404).json({ message: "Snapshot not found" });
      }

      res.json({
        distributionId: dist.id,
        recordDate: dist.recordDate,
        snapshot,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/finance/snapshots/:assetId", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can view snapshots" });
      }

      const snapshots = await storage.getDistributionSnapshotsByAsset(String(req.params.assetId));
      res.json(snapshots);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/finance/reserves/:assetId", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can view reserve fund" });
      }

      const assetId = String(req.params.assetId);
      const entries = await storage.getReserveFundEntriesByAsset(assetId);
      const balance = await storage.getReserveFundBalance(assetId);
      res.json({ assetId, balance, entries });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const reserveDrawdownSchema = z.object({
    assetId: z.string().min(1),
    period: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/, "Period must be YYYY-MM format"),
    amount: z.string().refine(v => parseFloat(v) > 0, "Amount must be positive"),
    currency: z.string().min(1),
    description: z.string().min(1),
  });

  app.post("/api/finance/reserves/drawdown", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin") {
        return res.status(403).json({ message: "Only admin can draw down reserves" });
      }

      const parsed = reserveDrawdownSchema.parse(req.body);

      const currentBalance = await storage.getReserveFundBalance(parsed.assetId);
      if (parseFloat(currentBalance) < parseFloat(parsed.amount)) {
        return res.status(400).json({
          message: `Insufficient reserve balance. Available: ${currentBalance}, Requested: ${parsed.amount}`,
        });
      }

      const entry = await storage.createReserveFundEntry({
        assetId: parsed.assetId,
        period: parsed.period,
        entryType: "DEBIT",
        amount: parsed.amount,
        currency: parsed.currency,
        waterfallCalculationId: null,
        description: parsed.description,
        postedBy: user.userId,
      });

      const newBalance = await storage.getReserveFundBalance(parsed.assetId);
      res.status(201).json({ entry, balance: newBalance });
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/finance/my-distributions", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      const payouts = await storage.getDistributionPayoutsByUser(user.userId);
      res.json(payouts);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/finance/my-statement", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      const userId = user.userId;

      const payouts = await storage.getDistributionPayoutsByUser(userId);

      if (payouts.length === 0) {
        return res.json({
          userId,
          statementDate: new Date().toISOString().split("T")[0],
          totalDistributions: 0,
          totalReceived: "0.00",
          totalAutoConverted: "0.00",
          entries: [],
        });
      }

      const distIds = Array.from(new Set(payouts.map(p => p.distributionId)));
      const distMap: Record<string, any> = {};
      for (const did of distIds) {
        const dist = await storage.getDistribution(did);
        if (dist) distMap[did] = dist;
      }

      const tokenIds = Array.from(new Set(payouts.map(p => p.tokenId)));
      const tokenMap: Record<string, any> = {};
      for (const tid of tokenIds) {
        const token = await storage.getToken(tid);
        if (token) tokenMap[tid] = token;
      }

      const assetMap: Record<string, any> = {};
      for (const dist of Object.values(distMap)) {
        if (!assetMap[dist.assetId]) {
          const asset = await storage.getAsset(dist.assetId);
          if (asset) assetMap[dist.assetId] = asset;
        }
      }

      let totalReceived = 0;
      let totalAutoConverted = 0;

      const entries = payouts.map(p => {
        const dist = distMap[p.distributionId];
        const token = tokenMap[p.tokenId];
        const asset = dist ? assetMap[dist.assetId] : null;
        const amount = parseFloat(p.payoutAmount);
        totalReceived += amount;

        if (p.autoConverted && p.convertedAmount) {
          totalAutoConverted += parseFloat(p.convertedAmount);
        }

        return {
          distributionId: p.distributionId,
          distributionDate: dist?.distributionDate || null,
          recordDate: dist?.recordDate || null,
          assetId: dist?.assetId || null,
          assetName: asset?.name || null,
          tokenSymbol: token?.tokenSymbol || null,
          holdingBalance: p.holdingBalance,
          holdingPercent: p.holdingPercent,
          perTokenAmount: dist?.perTokenAmount || null,
          payoutAmount: p.payoutAmount,
          payoutCurrency: p.payoutCurrency,
          autoConverted: p.autoConverted,
          convertedAmount: p.convertedAmount,
          convertedCurrency: p.convertedCurrency,
          conversionRate: p.conversionRate,
          createdAt: p.createdAt,
        };
      });

      entries.sort((a, b) => {
        const da = a.distributionDate || "";
        const db = b.distributionDate || "";
        return db.localeCompare(da);
      });

      res.json({
        userId,
        statementDate: new Date().toISOString().split("T")[0],
        totalDistributions: payouts.length,
        totalReceived: totalReceived.toFixed(2),
        totalAutoConverted: totalAutoConverted.toFixed(2),
        primaryCurrency: user.primaryCurrency || null,
        entries,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/finance/my-preferences", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      const { primaryCurrency, autoConvertDistributions } = req.body;

      const updates: Record<string, any> = {};

      if (primaryCurrency !== undefined) {
        updates.primaryCurrency = primaryCurrency;
      }

      if (autoConvertDistributions !== undefined) {
        const currentPrefs = (user.notificationPreferences || {}) as any;
        updates.notificationPreferences = {
          ...currentPrefs,
          autoConvertDistributions: !!autoConvertDistributions,
        };
      }

      if (Object.keys(updates).length === 0) {
        return res.status(400).json({ message: "No preferences to update" });
      }

      const updated = await storage.updateUserProfile(user.userId, updates);
      res.json({
        message: "Preferences updated",
        primaryCurrency: updated?.primaryCurrency || null,
        autoConvertDistributions: (updated?.notificationPreferences as any)?.autoConvertDistributions || false,
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/valuations", requireAuth, requireRole("admin", "issuer"), async (req, res) => {
    try {
      const parsed = createValuationUpdateSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: parsed.error.errors[0].message });
      }

      const { assetId, date, valuationAmount, currency, method, notes, docs } = parsed.data;

      const asset = await storage.getAsset(assetId);
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }

      const totalSupply = parseFloat(asset.totalSupply);
      const valuation = parseFloat(valuationAmount);
      const impliedTokenPrice = totalSupply > 0 ? (valuation / totalSupply).toFixed(6) : "0";

      const user = (req as any).user;
      const valuationUpdate = await storage.createValuationUpdate({
        assetId,
        date,
        valuationAmount,
        currency,
        method,
        notes: notes || null,
        docs: docs || null,
        impliedTokenPrice,
        createdBy: user.userId,
      });

      await storage.updateAsset(assetId, {
        pricePerToken: impliedTokenPrice,
        totalPropertyValue: valuationAmount,
      });

      res.status(201).json(valuationUpdate);
    } catch (error: any) {
      console.error("Valuation update error:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/assets/:id/valuations", requireAuth, async (req, res) => {
    try {
      const id = String(req.params.id);
      const asset = await storage.getAsset(id);
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }

      const valuations = await storage.getValuationsByAsset(id);
      res.json(valuations);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/assets/:id/latest-valuation", requireAuth, async (req, res) => {
    try {
      const id = String(req.params.id);
      const valuation = await storage.getLatestValuation(id);
      res.json(valuation || null);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/investor/analytics", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      const userId = user.userId;

      const [holdings, portfolioItems, distributionPayouts, walletAccounts, walletTransactions, allAssets, allDistributions] = await Promise.all([
        storage.getTokenHoldingsByUser(userId),
        storage.getPortfolioItems(userId, req.tenantId),
        storage.getDistributionPayoutsByUser(userId),
        storage.getWalletAccountsByUser(userId),
        storage.getWalletTransactionsByUser(userId),
        storage.getAssets(req.tenantId),
        storage.getDistributions(req.tenantId),
      ]);

      const activeHoldings = holdings.filter(h => parseFloat(h.balance) > 0);

      const assetById: Record<string, any> = {};
      for (const a of allAssets) assetById[a.id] = a;

      const distributionById: Record<string, any> = {};
      for (const d of allDistributions) distributionById[d.id] = d;

      const tokenIds = Array.from(new Set(activeHoldings.map(h => h.tokenId)));
      const tokenMap: Record<string, any> = {};
      const shareClassMap: Record<string, any> = {};
      for (const tid of tokenIds) {
        const token = await storage.getToken(tid);
        if (token) {
          tokenMap[tid] = token;
          if (token.shareClassId && !shareClassMap[token.shareClassId]) {
            shareClassMap[token.shareClassId] = await storage.getShareClass(token.shareClassId);
          }
        }
      }

      const tokenToAsset: Record<string, any> = {};
      for (const tid of tokenIds) {
        const token = tokenMap[tid];
        if (!token) continue;
        const sc = token.shareClassId ? shareClassMap[token.shareClassId] : null;
        if (sc && assetById[sc.spvId]) {
          tokenToAsset[tid] = assetById[sc.spvId];
        } else {
          for (const a of allAssets) {
            const t = await storage.getTokenByAssetId(a.id);
            if (t && t.id === tid) {
              tokenToAsset[tid] = a;
              break;
            }
          }
        }
      }

      let totalInvestedBase = 0;
      let totalCurrentValueBase = 0;
      const holdingsDetail: any[] = [];

      for (const h of activeHoldings) {
        const balance = parseFloat(h.balance);
        if (balance <= 0) continue;

        const asset = tokenToAsset[h.tokenId];
        if (!asset) continue;

        const pricePerToken = parseFloat(asset.pricePerToken || "0");
        const currentValue = balance * pricePerToken;

        const pi = portfolioItems.find(p => p.assetId === asset.id);
        const avgCost = pi ? parseFloat(pi.averageCost) : pricePerToken;
        const costBasis = balance * avgCost;

        totalInvestedBase += costBasis;
        totalCurrentValueBase += currentValue;

        const unrealizedGain = currentValue - costBasis;
        const unrealizedGainPercent = costBasis > 0 ? ((unrealizedGain / costBasis) * 100) : 0;

        holdingsDetail.push({
          tokenId: h.tokenId,
          assetId: asset.id,
          assetName: asset.name,
          assetSymbol: asset.symbol,
          baseCurrency: asset.baseCurrency,
          balance: h.balance,
          pricePerToken: pricePerToken.toFixed(6),
          currentValue: currentValue.toFixed(2),
          costBasis: costBasis.toFixed(2),
          unrealizedGain: unrealizedGain.toFixed(2),
          unrealizedGainPercent: unrealizedGainPercent.toFixed(2),
          annualYield: asset.annualYield || null,
          propertyType: asset.propertyType || null,
          location: asset.location || null,
        });
      }

      let totalDistributionsReceived = 0;
      const payoutHistory: any[] = [];
      const monthlyPayouts: Record<string, number> = {};

      for (const p of distributionPayouts) {
        const amount = parseFloat(p.payoutAmount);
        totalDistributionsReceived += amount;

        const dist = distributionById[p.distributionId];
        const asset = dist ? assetById[dist.assetId] : null;
        const month = dist?.distributionDate?.slice(0, 7) ||
          (p.createdAt ? new Date(p.createdAt).toISOString().slice(0, 7) : "unknown");

        monthlyPayouts[month] = (monthlyPayouts[month] || 0) + amount;

        payoutHistory.push({
          id: p.id,
          distributionId: p.distributionId,
          assetName: asset?.name || "Unknown",
          assetSymbol: asset?.symbol || "?",
          payoutAmount: p.payoutAmount,
          payoutCurrency: p.payoutCurrency,
          holdingBalance: p.holdingBalance,
          holdingPercent: p.holdingPercent,
          autoConverted: p.autoConverted,
          convertedAmount: p.convertedAmount,
          convertedCurrency: p.convertedCurrency,
          date: dist?.distributionDate || (p.createdAt ? new Date(p.createdAt).toISOString() : null),
        });
      }

      const feeTransactions = walletTransactions.filter(
        t => t.type === "FEE" || t.type === "fee" ||
             (t.description && t.description.toLowerCase().includes("fee"))
      );
      let totalFeesBase = 0;
      const feeSummary: any[] = [];
      for (const ft of feeTransactions) {
        const amount = Math.abs(parseFloat(ft.amount));
        totalFeesBase += amount;
        feeSummary.push({
          id: ft.id,
          amount: amount.toFixed(2),
          currency: ft.currency,
          description: ft.description,
          date: ft.createdAt,
        });
      }

      const unrealizedGain = totalCurrentValueBase - totalInvestedBase;
      const totalReturn = totalDistributionsReceived + unrealizedGain;
      const roiPercent = totalInvestedBase > 0 ? ((totalReturn / totalInvestedBase) * 100) : 0;

      const sortedMonths = Object.keys(monthlyPayouts).sort();
      const rentalYieldPercent = totalInvestedBase > 0
        ? ((totalDistributionsReceived / totalInvestedBase) * 100)
        : 0;

      const walletBalances = await Promise.all(
        walletAccounts.map(async (wa) => {
          const computed = await storage.getComputedBalance(wa.id);
          return {
            id: wa.id,
            currency: wa.currency,
            available: computed.available,
            pending: computed.pending,
          };
        })
      );

      res.json({
        overview: {
          totalInvested: totalInvestedBase.toFixed(2),
          currentPortfolioValue: totalCurrentValueBase.toFixed(2),
          totalDistributionsReceived: totalDistributionsReceived.toFixed(2),
          unrealizedGain: unrealizedGain.toFixed(2),
          totalReturn: totalReturn.toFixed(2),
          roiPercent: roiPercent.toFixed(2),
          rentalYieldPercent: rentalYieldPercent.toFixed(2),
          totalFees: totalFeesBase.toFixed(2),
          holdingsCount: activeHoldings.length,
        },
        holdings: holdingsDetail,
        payoutHistory,
        monthlyPayouts: sortedMonths.map(m => ({
          month: m,
          amount: monthlyPayouts[m].toFixed(2),
        })),
        feeSummary,
        walletBalances,
      });
    } catch (error: any) {
      console.error("Analytics error:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/investor/dashboard-roi", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      const userId = user.userId;

      const [holdings, portfolioItemsList, distributionPayoutsList, allAssets, allDistributions, walletAccountsList] = await Promise.all([
        storage.getTokenHoldingsByUser(userId),
        storage.getPortfolioItems(userId, req.tenantId),
        storage.getDistributionPayoutsByUser(userId),
        storage.getAssets(req.tenantId),
        storage.getDistributions(req.tenantId),
        storage.getWalletAccountsByUser(userId),
      ]);

      const activeHoldings = holdings.filter(h => parseFloat(h.balance) > 0);

      const assetById: Record<string, any> = {};
      for (const a of allAssets) assetById[a.id] = a;

      const distributionById: Record<string, any> = {};
      for (const d of allDistributions) distributionById[d.id] = d;

      const tokenToAsset: Record<string, any> = {};
      if (activeHoldings.length > 0) {
        const tokenIds = Array.from(new Set(activeHoldings.map(h => h.tokenId)));
        const tokenMap: Record<string, any> = {};
        for (const tid of tokenIds) {
          const token = await storage.getToken(tid);
          if (token) tokenMap[tid] = token;
        }
        for (const tid of tokenIds) {
          const token = tokenMap[tid];
          if (!token) continue;
          if (token.shareClassId) {
            const sc = await storage.getShareClass(token.shareClassId);
            if (sc && assetById[sc.spvId]) {
              tokenToAsset[tid] = assetById[sc.spvId];
              continue;
            }
          }
          for (const a of allAssets) {
            const t = await storage.getTokenByAssetId(a.id);
            if (t && t.id === tid) {
              tokenToAsset[tid] = a;
              break;
            }
          }
        }
      }

      const distPayoutsByAsset: Record<string, number> = {};
      for (const p of distributionPayoutsList) {
        const dist = distributionById[p.distributionId];
        if (dist) {
          const assetId = dist.assetId;
          distPayoutsByAsset[assetId] = (distPayoutsByAsset[assetId] || 0) + parseFloat(p.payoutAmount);
        }
      }

      let totalInvested = 0;
      let totalCurrentValue = 0;
      let totalRentalReceived = 0;
      let totalUnrealizedGain = 0;

      const propertyHoldings: any[] = [];
      const processedAssetIds = new Set<string>();

      for (const h of activeHoldings) {
        const balance = parseFloat(h.balance);
        if (balance <= 0) continue;

        const asset = tokenToAsset[h.tokenId];
        if (!asset) continue;

        processedAssetIds.add(asset.id);
        const impliedUnitPrice = parseFloat(asset.navPerToken || asset.pricePerToken || "0");
        const currentMarketValue = balance * impliedUnitPrice;

        const pi = portfolioItemsList.find(p => p.assetId === asset.id);
        const avgCost = pi ? parseFloat(pi.averageCost) : impliedUnitPrice;
        const initialInvestment = balance * avgCost;

        const rentalReceived = distPayoutsByAsset[asset.id] || 0;
        const unrealizedGain = currentMarketValue - initialInvestment;
        const totalReturn = rentalReceived + currentMarketValue - initialInvestment;
        const roiPercent = initialInvestment > 0 ? ((totalReturn / initialInvestment) * 100) : 0;

        totalInvested += initialInvestment;
        totalCurrentValue += currentMarketValue;
        totalRentalReceived += rentalReceived;
        totalUnrealizedGain += unrealizedGain;

        const isOffPlan = asset.constructionStatus && asset.constructionStatus !== "completed";

        propertyHoldings.push({
          assetId: asset.id,
          assetName: asset.name,
          assetSymbol: asset.symbol,
          propertyType: asset.propertyType || null,
          location: asset.location || null,
          country: asset.country,
          baseCurrency: asset.baseCurrency,
          initialInvestment: initialInvestment.toFixed(2),
          currentUnits: balance.toFixed(6),
          totalRentalReceived: rentalReceived.toFixed(2),
          currentImpliedUnitPrice: impliedUnitPrice.toFixed(6),
          currentMarketValue: currentMarketValue.toFixed(2),
          unrealizedGain: unrealizedGain.toFixed(2),
          totalReturn: totalReturn.toFixed(2),
          roiPercent: roiPercent.toFixed(2),
          annualYield: asset.annualYield || null,
          occupancyRate: asset.occupancyRate || null,
          constructionStatus: asset.constructionStatus || null,
          expectedCompletionDate: asset.expectedCompletionDate || null,
          projectedRentalYield: asset.annualYield || null,
          isOffPlan: !!isOffPlan,
        });
      }

      for (const pi of portfolioItemsList) {
        if (processedAssetIds.has(pi.assetId)) continue;
        const asset = assetById[pi.assetId];
        if (!asset) continue;

        const balance = parseFloat(pi.quantity);
        if (balance <= 0) continue;

        const avgCost = parseFloat(pi.averageCost);
        const impliedUnitPrice = parseFloat(asset.navPerToken || asset.pricePerToken || "0");
        const initialInvestment = balance * avgCost;
        const currentMarketValue = balance * impliedUnitPrice;

        const rentalReceived = distPayoutsByAsset[asset.id] || 0;
        const unrealizedGain = currentMarketValue - initialInvestment;
        const totalReturn = rentalReceived + currentMarketValue - initialInvestment;
        const roiPercent = initialInvestment > 0 ? ((totalReturn / initialInvestment) * 100) : 0;

        totalInvested += initialInvestment;
        totalCurrentValue += currentMarketValue;
        totalRentalReceived += rentalReceived;
        totalUnrealizedGain += unrealizedGain;

        const isOffPlan2 = asset.constructionStatus && asset.constructionStatus !== "completed";

        propertyHoldings.push({
          assetId: asset.id,
          assetName: asset.name,
          assetSymbol: asset.symbol,
          propertyType: asset.propertyType || null,
          location: asset.location || null,
          country: asset.country,
          baseCurrency: asset.baseCurrency,
          initialInvestment: initialInvestment.toFixed(2),
          currentUnits: balance.toFixed(6),
          totalRentalReceived: rentalReceived.toFixed(2),
          currentImpliedUnitPrice: impliedUnitPrice.toFixed(6),
          currentMarketValue: currentMarketValue.toFixed(2),
          unrealizedGain: unrealizedGain.toFixed(2),
          totalReturn: totalReturn.toFixed(2),
          roiPercent: roiPercent.toFixed(2),
          annualYield: asset.annualYield || null,
          occupancyRate: asset.occupancyRate || null,
          constructionStatus: asset.constructionStatus || null,
          expectedCompletionDate: asset.expectedCompletionDate || null,
          projectedRentalYield: asset.annualYield || null,
          isOffPlan: !!isOffPlan2,
        });
      }

      const overallTotalReturn = totalRentalReceived + totalCurrentValue - totalInvested;
      const overallRoiPercent = totalInvested > 0 ? ((overallTotalReturn / totalInvested) * 100) : 0;

      const walletBalances = await Promise.all(
        walletAccountsList.map(async (wa) => {
          const computed = await storage.getComputedBalance(wa.id);
          return {
            id: wa.id,
            currency: wa.currency,
            available: computed.available,
            pending: computed.pending,
          };
        })
      );

      const totalWalletBalance = walletBalances.reduce(
        (sum, w) => sum + parseFloat(w.available), 0
      );

      res.json({
        summary: {
          totalInvested: totalInvested.toFixed(2),
          totalCurrentValue: totalCurrentValue.toFixed(2),
          totalRentalReceived: totalRentalReceived.toFixed(2),
          totalUnrealizedGain: totalUnrealizedGain.toFixed(2),
          overallTotalReturn: overallTotalReturn.toFixed(2),
          overallRoiPercent: overallRoiPercent.toFixed(2),
          holdingsCount: propertyHoldings.length,
          totalWalletBalance: totalWalletBalance.toFixed(2),
        },
        properties: propertyHoldings,
        walletBalances,
      });
    } catch (error: any) {
      console.error("Dashboard ROI error:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/finance/settlements", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can view settlements" });
      }

      const { assetId, state, referenceId } = req.query;
      let entries;
      if (referenceId) {
        entries = await storage.getSettlementsByReference(referenceId as string);
      } else if (assetId && state) {
        const byAsset = await storage.getSettlementsByAsset(assetId as string);
        entries = byAsset.filter(e => e.state === state);
      } else if (assetId) {
        entries = await storage.getSettlementsByAsset(assetId as string);
      } else if (state) {
        entries = await storage.getSettlementsByState(state as string);
      } else {
        entries = await storage.getAllSettlements(req.tenantId);
      }

      const enriched = await Promise.all(entries.map(async (entry) => {
        const [asset, investorUser, docs] = await Promise.all([
          storage.getAsset(entry.assetId),
          storage.getUser(entry.userId),
          storage.getSettlementDocuments(entry.id),
        ]);
        return {
          ...entry,
          assetName: asset?.name || "Unknown",
          assetSymbol: asset?.symbol || "",
          investorName: investorUser ? investorUser.fullName || investorUser.username : "Unknown",
          documentCount: docs.length,
        };
      }));

      res.json(enriched);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/finance/settlements/:id", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      const entry = await storage.getSettlementEntry(String(req.params.id));
      if (!entry) return res.status(404).json({ message: "Settlement entry not found" });

      if (user.role !== "admin" && user.role !== "issuer" && entry.userId !== user.userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const [asset, investorUser, docs, trail] = await Promise.all([
        storage.getAsset(entry.assetId),
        storage.getUser(entry.userId),
        storage.getSettlementDocuments(entry.id),
        storage.getSettlementsByReference(entry.referenceId),
      ]);

      const validTransitions: Record<string, string[]> = {
        CLIENT_MONEY_HELD: ["SETTLEMENT_INITIATED", "FAILED"],
        SETTLEMENT_INITIATED: ["ACQUISITION_PAID", "FAILED"],
        ACQUISITION_PAID: ["SETTLED", "FAILED"],
      };

      const latestInTrail = trail.reduce((latest, e) =>
        e.createdAt > latest.createdAt ? e : latest, trail[0]);
      const currentState = latestInTrail?.state || entry.state;

      res.json({
        ...entry,
        state: currentState,
        assetName: asset?.name || "Unknown",
        assetSymbol: asset?.symbol || "",
        investorName: investorUser ? investorUser.fullName || investorUser.username : "Unknown",
        documents: docs,
        auditTrail: trail,
        allowedTransitions: validTransitions[currentState] || [],
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/finance/settlements/:id/advance", requireAuth, paymentLimiter, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can advance settlement" });
      }

      const parsed = advanceSettlementSchema.parse(req.body);
      const existing = await storage.getSettlementEntry(String(req.params.id));
      if (!existing) return res.status(404).json({ message: "Settlement entry not found" });

      const validTransitions: Record<string, string[]> = {
        CLIENT_MONEY_HELD: ["SETTLEMENT_INITIATED", "FAILED"],
        SETTLEMENT_INITIATED: ["ACQUISITION_PAID", "FAILED"],
        ACQUISITION_PAID: ["SETTLED", "FAILED"],
      };

      const allowed = validTransitions[existing.state];
      if (!allowed || !allowed.includes(parsed.state)) {
        return res.status(400).json({
          message: `Cannot transition from ${existing.state} to ${parsed.state}`,
          allowedTransitions: allowed || [],
        });
      }

      if (parsed.state === "ACQUISITION_PAID" && !parsed.proofDocumentUrl) {
        return res.status(400).json({ message: "Proof document URL is required when marking acquisition as paid" });
      }

      const newEntry = await storage.createSettlementEntry({
        assetId: existing.assetId,
        roundId: existing.roundId,
        userId: existing.userId,
        walletTransactionId: existing.walletTransactionId,
        paymentIntentId: existing.paymentIntentId,
        referenceId: existing.referenceId,
        state: parsed.state,
        amount: existing.amount,
        currency: existing.currency,
        previousState: existing.state,
        notes: parsed.notes || null,
        proofDocumentUrl: parsed.proofDocumentUrl || null,
        advancedBy: user.userId,
        advancedAt: new Date().toISOString(),
        metadata: existing.metadata as any,
        createdAt: new Date().toISOString(),
      });

      if (parsed.proofDocumentUrl) {
        await storage.createSettlementDocument({
          settlementJournalId: newEntry.id,
          documentType: parsed.state === "ACQUISITION_PAID" ? "payment_proof" : "other",
          documentUrl: parsed.proofDocumentUrl,
          fileName: `proof-${newEntry.id}`,
          description: parsed.notes || `Proof for ${parsed.state} transition`,
          uploadedBy: user.userId,
          createdAt: new Date().toISOString(),
        });
      }

      res.status(201).json(newEntry);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/finance/settlements/:id/documents", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Only admin or issuer can attach documents" });
      }

      const existing = await storage.getSettlementEntry(String(req.params.id));
      if (!existing) return res.status(404).json({ message: "Settlement entry not found" });

      const docSchema = z.object({
        documentType: z.enum(settlementDocumentTypeEnum),
        documentUrl: z.string().optional(),
        fileName: z.string().optional(),
        description: z.string().optional(),
      });

      const parsed = docSchema.parse(req.body);

      const doc = await storage.createSettlementDocument({
        settlementJournalId: existing.id,
        documentType: parsed.documentType,
        documentUrl: parsed.documentUrl || null,
        fileName: parsed.fileName || null,
        description: parsed.description || null,
        uploadedBy: user.userId,
        createdAt: new Date().toISOString(),
      });

      res.status(201).json(doc);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/finance/settlements/:id/documents", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      const entry = await storage.getSettlementEntry(String(req.params.id));
      if (!entry) return res.status(404).json({ message: "Settlement entry not found" });

      if (user.role !== "admin" && user.role !== "issuer" && entry.userId !== user.userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const docs = await storage.getSettlementDocuments(entry.id);
      res.json(docs);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/investor/settlements", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const entries = await storage.getSettlementsByUser(userId);

      const enriched = await Promise.all(entries.map(async (entry) => {
        const asset = await storage.getAsset(entry.assetId);
        return {
          ...entry,
          assetName: asset?.name || "Unknown",
          assetSymbol: asset?.symbol || "",
        };
      }));

      res.json(enriched);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/investor/properties/:assetId/construction", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const assetId = String(req.params.assetId);

      const asset = await storage.getAsset(assetId);
      if (!asset) {
        return res.status(404).json({ message: "Property not found" });
      }

      const milestones = await storage.getPropertyMilestonesByAsset(assetId);

      const completedCount = milestones.filter(m => m.status === "completed").length;
      const overallProgress = milestones.length > 0
        ? Math.round(milestones.reduce((sum, m) => sum + (m.progressPercent || 0), 0) / milestones.length)
        : 0;

      res.json({
        assetId: asset.id,
        assetName: asset.name,
        constructionStatus: asset.constructionStatus || null,
        expectedCompletionDate: asset.expectedCompletionDate || null,
        projectedRentalYield: asset.annualYield || null,
        overallProgress,
        completedMilestones: completedCount,
        totalMilestones: milestones.length,
        milestones: milestones.map(m => ({
          id: m.id,
          name: m.name,
          description: m.description,
          status: m.status,
          progressPercent: m.progressPercent || 0,
          startDate: m.targetDate,
          expectedDate: m.targetDate,
          completionDate: m.completionDate,
          sortOrder: m.sortOrder,
        })),
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/finance/settlement-stats", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      if (user.role !== "admin" && user.role !== "issuer") {
        return res.status(403).json({ message: "Access denied" });
      }

      const all = await storage.getAllSettlements(req.tenantId);
      const latestByRef = new Map<string, typeof all[0]>();
      for (const entry of all) {
        const existing = latestByRef.get(entry.referenceId);
        if (!existing || entry.createdAt > existing.createdAt) {
          latestByRef.set(entry.referenceId, entry);
        }
      }

      const latest = Array.from(latestByRef.values());
      const stats = {
        totalEntries: all.length,
        uniqueSettlements: latest.length,
        byState: {
          CLIENT_MONEY_HELD: latest.filter(e => e.state === "CLIENT_MONEY_HELD").length,
          SETTLEMENT_INITIATED: latest.filter(e => e.state === "SETTLEMENT_INITIATED").length,
          ACQUISITION_PAID: latest.filter(e => e.state === "ACQUISITION_PAID").length,
          SETTLED: latest.filter(e => e.state === "SETTLED").length,
          FAILED: latest.filter(e => e.state === "FAILED").length,
        },
        totalAmount: latest.reduce((sum, e) => sum + parseFloat(e.amount), 0).toFixed(2),
      };

      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/investor/statements/holdings", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const format = (req.query.format as string) || "csv";

      const [holdings, portfolioItemsList, allAssets, allDistributions, distributionPayoutsList] = await Promise.all([
        storage.getTokenHoldingsByUser(userId),
        storage.getPortfolioItems(userId, req.tenantId),
        storage.getAssets(req.tenantId),
        storage.getDistributions(req.tenantId),
        storage.getDistributionPayoutsByUser(userId),
      ]);

      const assetById: Record<string, any> = {};
      for (const a of allAssets) assetById[a.id] = a;

      const activeHoldings = holdings.filter(h => parseFloat(h.balance) > 0);
      const tokenIds = Array.from(new Set(activeHoldings.map(h => h.tokenId)));
      const tokenToAsset: Record<string, any> = {};
      for (const tid of tokenIds) {
        const token = await storage.getToken(tid);
        if (!token) continue;
        if (token.shareClassId) {
          const sc = await storage.getShareClass(token.shareClassId);
          if (sc && assetById[sc.spvId]) { tokenToAsset[tid] = assetById[sc.spvId]; continue; }
        }
        for (const a of allAssets) {
          const t = await storage.getTokenByAssetId(a.id);
          if (t && t.id === tid) { tokenToAsset[tid] = a; break; }
        }
      }

      const rows: any[] = [];
      let totalCost = 0, totalValue = 0, totalGain = 0, totalDistributions = 0;

      for (const h of activeHoldings) {
        const balance = parseFloat(h.balance);
        if (balance <= 0) continue;
        const asset = tokenToAsset[h.tokenId];
        if (!asset) continue;
        const pricePerToken = parseFloat(asset.pricePerToken || "0");
        const currentValue = balance * pricePerToken;
        const pi = portfolioItemsList.find(p => p.assetId === asset.id);
        const avgCost = pi ? parseFloat(pi.averageCost) : pricePerToken;
        const costBasis = balance * avgCost;
        const unrealizedGain = currentValue - costBasis;
        const gainPct = costBasis > 0 ? (unrealizedGain / costBasis) * 100 : 0;

        const assetDist = distributionPayoutsList.filter(dp => {
          const dist = allDistributions.find(d => d.id === dp.distributionId);
          return dist && dist.assetId === asset.id;
        });
        const distTotal = assetDist.reduce((s, dp) => s + parseFloat(dp.payoutAmount), 0);
        totalDistributions += distTotal;

        totalCost += costBasis;
        totalValue += currentValue;
        totalGain += unrealizedGain;

        rows.push({
          asset: asset.name,
          symbol: asset.symbol,
          currency: asset.baseCurrency,
          tokens: balance,
          avgCost: avgCost.toFixed(2),
          currentPrice: pricePerToken.toFixed(2),
          costBasis: costBasis.toFixed(2),
          currentValue: currentValue.toFixed(2),
          unrealizedGain: unrealizedGain.toFixed(2),
          gainPercent: gainPct.toFixed(2) + "%",
          distributionsReceived: distTotal.toFixed(2),
          propertyType: asset.propertyType || "",
          location: asset.location || "",
        });
      }

      if (format === "pdf") {
        const PDFDocument = (await import("pdfkit")).default;
        const doc = new PDFDocument({ size: "A4", layout: "landscape", margin: 40 });
        res.setHeader("Content-Type", "application/pdf");
        res.setHeader("Content-Disposition", "attachment; filename=holdings-statement.pdf");
        doc.pipe(res);

        doc.fontSize(18).font("Helvetica-Bold").text("VestBlock - Portfolio Holdings Statement", { align: "center" });
        doc.moveDown(0.3);
        doc.fontSize(9).font("Helvetica").text(`Generated: ${new Date().toLocaleDateString("en-GB")}`, { align: "center" });
        doc.moveDown(1);

        const headers = ["Asset", "Symbol", "Currency", "Tokens", "Avg Cost", "Price", "Cost Basis", "Value", "Gain/Loss", "%", "Distributions"];
        const colWidths = [110, 50, 50, 55, 60, 60, 70, 70, 70, 45, 70];
        let x = 40;
        const tableTop = doc.y;

        doc.font("Helvetica-Bold").fontSize(7);
        headers.forEach((h, i) => {
          doc.text(h, x, tableTop, { width: colWidths[i], align: i >= 3 ? "right" : "left" });
          x += colWidths[i] + 4;
        });
        doc.moveDown(0.5);
        doc.moveTo(40, doc.y).lineTo(770, doc.y).stroke();
        doc.moveDown(0.3);

        doc.font("Helvetica").fontSize(7);
        for (const row of rows) {
          x = 40;
          const y = doc.y;
          const vals = [row.asset, row.symbol, row.currency, row.tokens.toFixed(2), row.avgCost, row.currentPrice, row.costBasis, row.currentValue, row.unrealizedGain, row.gainPercent, row.distributionsReceived];
          vals.forEach((v, i) => {
            doc.text(String(v), x, y, { width: colWidths[i], align: i >= 3 ? "right" : "left" });
            x += colWidths[i] + 4;
          });
          doc.moveDown(0.5);
        }

        doc.moveDown(0.5);
        doc.moveTo(40, doc.y).lineTo(770, doc.y).stroke();
        doc.moveDown(0.5);
        doc.font("Helvetica-Bold").fontSize(8);
        doc.text(`Total Cost Basis: ${totalCost.toFixed(2)}  |  Total Current Value: ${totalValue.toFixed(2)}  |  Total Gain/Loss: ${totalGain.toFixed(2)}  |  Total Distributions: ${totalDistributions.toFixed(2)}`, 40);

        doc.end();
      } else {
        const csvHeaders = "Asset,Symbol,Currency,Tokens,Average Cost,Current Price,Cost Basis,Current Value,Unrealized Gain,Gain %,Distributions Received,Property Type,Location\n";
        const csvRows = rows.map(r =>
          `"${r.asset}","${r.symbol}","${r.currency}",${r.tokens.toFixed(2)},${r.avgCost},${r.currentPrice},${r.costBasis},${r.currentValue},${r.unrealizedGain},${r.gainPercent},${r.distributionsReceived},"${r.propertyType}","${r.location}"`
        ).join("\n");
        const footer = `\nTotal,,,,,,${totalCost.toFixed(2)},${totalValue.toFixed(2)},${totalGain.toFixed(2)},,${totalDistributions.toFixed(2)},,`;
        res.setHeader("Content-Type", "text/csv");
        res.setHeader("Content-Disposition", "attachment; filename=holdings-statement.csv");
        res.send(csvHeaders + csvRows + footer);
      }
    } catch (error: any) {
      console.error("Holdings statement error:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/investor/statements/rental-income", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const format = (req.query.format as string) || "csv";

      const [distributionPayouts, allDistributions, allAssets] = await Promise.all([
        storage.getDistributionPayoutsByUser(userId),
        storage.getDistributions(req.tenantId),
        storage.getAssets(req.tenantId),
      ]);

      const distById: Record<string, any> = {};
      for (const d of allDistributions) distById[d.id] = d;
      const assetById: Record<string, any> = {};
      for (const a of allAssets) assetById[a.id] = a;

      const rows: any[] = [];
      let totalIncome = 0;

      for (const p of distributionPayouts) {
        const dist = distById[p.distributionId];
        const asset = dist ? assetById[dist.assetId] : null;
        const amount = parseFloat(p.payoutAmount);
        totalIncome += amount;

        rows.push({
          date: dist?.distributionDate || (p.createdAt ? new Date(p.createdAt).toISOString().slice(0, 10) : "N/A"),
          asset: asset?.name || "Unknown",
          symbol: asset?.symbol || "?",
          tokensHeld: parseFloat(p.holdingBalance).toFixed(2),
          holdingPercent: parseFloat(p.holdingPercent).toFixed(2) + "%",
          amount: amount.toFixed(2),
          currency: p.payoutCurrency,
          autoConverted: p.autoConverted ? "Yes" : "No",
          convertedAmount: p.convertedAmount ? parseFloat(p.convertedAmount).toFixed(2) : "",
          convertedCurrency: p.convertedCurrency || "",
        });
      }

      rows.sort((a, b) => a.date.localeCompare(b.date));

      if (format === "pdf") {
        const PDFDocument = (await import("pdfkit")).default;
        const doc = new PDFDocument({ size: "A4", layout: "landscape", margin: 40 });
        res.setHeader("Content-Type", "application/pdf");
        res.setHeader("Content-Disposition", "attachment; filename=rental-income-statement.pdf");
        doc.pipe(res);

        doc.fontSize(18).font("Helvetica-Bold").text("VestBlock - Rental Income Statement", { align: "center" });
        doc.moveDown(0.3);
        doc.fontSize(9).font("Helvetica").text(`Generated: ${new Date().toLocaleDateString("en-GB")}`, { align: "center" });
        doc.moveDown(1);

        const headers = ["Date", "Asset", "Symbol", "Tokens Held", "Share %", "Amount", "Currency", "Auto-Converted", "Converted Amt", "Conv. Currency"];
        const colWidths = [70, 120, 50, 65, 55, 65, 55, 70, 70, 70];
        let x = 40;
        const tableTop = doc.y;

        doc.font("Helvetica-Bold").fontSize(7);
        headers.forEach((h, i) => {
          doc.text(h, x, tableTop, { width: colWidths[i], align: i >= 3 ? "right" : "left" });
          x += colWidths[i] + 4;
        });
        doc.moveDown(0.5);
        doc.moveTo(40, doc.y).lineTo(770, doc.y).stroke();
        doc.moveDown(0.3);

        doc.font("Helvetica").fontSize(7);
        for (const row of rows) {
          x = 40;
          const y = doc.y;
          const vals = [row.date, row.asset, row.symbol, row.tokensHeld, row.holdingPercent, row.amount, row.currency, row.autoConverted, row.convertedAmount, row.convertedCurrency];
          vals.forEach((v, i) => {
            doc.text(String(v), x, y, { width: colWidths[i], align: i >= 3 ? "right" : "left" });
            x += colWidths[i] + 4;
          });
          doc.moveDown(0.5);
        }

        doc.moveDown(0.5);
        doc.moveTo(40, doc.y).lineTo(770, doc.y).stroke();
        doc.moveDown(0.5);
        doc.font("Helvetica-Bold").fontSize(8);
        doc.text(`Total Rental Income Received: ${totalIncome.toFixed(2)}  |  Total Payouts: ${rows.length}`, 40);

        doc.end();
      } else {
        const csvHeaders = "Date,Asset,Symbol,Tokens Held,Holding %,Amount,Currency,Auto-Converted,Converted Amount,Converted Currency\n";
        const csvRows = rows.map(r =>
          `${r.date},"${r.asset}","${r.symbol}",${r.tokensHeld},${r.holdingPercent},${r.amount},${r.currency},${r.autoConverted},${r.convertedAmount},${r.convertedCurrency}`
        ).join("\n");
        const footer = `\nTotal,,,,,${totalIncome.toFixed(2)},,,,`;
        res.setHeader("Content-Type", "text/csv");
        res.setHeader("Content-Disposition", "attachment; filename=rental-income-statement.csv");
        res.send(csvHeaders + csvRows + footer);
      }
    } catch (error: any) {
      console.error("Rental income statement error:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/investor/statements/capital-gains", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const format = (req.query.format as string) || "csv";

      const walletTxs = await storage.getWalletTransactionsByUser(userId);
      const [allAssets, portfolioItemsList, holdings] = await Promise.all([
        storage.getAssets(req.tenantId),
        storage.getPortfolioItems(userId, req.tenantId),
        storage.getTokenHoldingsByUser(userId),
      ]);

      const assetById: Record<string, any> = {};
      for (const a of allAssets) assetById[a.id] = a;

      const capitalGainTxs = walletTxs.filter(t =>
        t.type === "CAPITAL_GAIN" || t.type === "CAPITAL_RETURN" ||
        t.type === "TRADE_SELL"
      );

      const rows: any[] = [];
      let totalRealizedGains = 0;

      for (const tx of capitalGainTxs) {
        const meta = tx.metadata as any;
        const assetName = meta?.assetName || meta?.assetSymbol || "Unknown";
        const amount = parseFloat(tx.amount);
        totalRealizedGains += amount;

        rows.push({
          date: tx.createdAt ? new Date(tx.createdAt).toISOString().slice(0, 10) : "N/A",
          type: tx.type === "CAPITAL_GAIN" ? "Capital Gain" : tx.type === "CAPITAL_RETURN" ? "Capital Return" : "Trade Sale",
          asset: assetName,
          amount: amount.toFixed(2),
          currency: tx.currency,
          description: tx.description || "",
          referenceId: tx.referenceId || "",
        });
      }

      const activeHoldings = holdings.filter(h => parseFloat(h.balance) > 0);
      const tokenToAsset: Record<string, any> = {};
      for (const h of activeHoldings) {
        const token = await storage.getToken(h.tokenId);
        if (!token) continue;
        if (token.shareClassId) {
          const sc = await storage.getShareClass(token.shareClassId);
          if (sc && assetById[sc.spvId]) { tokenToAsset[h.tokenId] = assetById[sc.spvId]; continue; }
        }
        for (const a of allAssets) {
          const t = await storage.getTokenByAssetId(a.id);
          if (t && t.id === h.tokenId) { tokenToAsset[h.tokenId] = a; break; }
        }
      }

      let totalUnrealizedGains = 0;
      const unrealizedRows: any[] = [];
      for (const h of activeHoldings) {
        const balance = parseFloat(h.balance);
        if (balance <= 0) continue;
        const asset = tokenToAsset[h.tokenId];
        if (!asset) continue;
        const pricePerToken = parseFloat(asset.pricePerToken || "0");
        const currentValue = balance * pricePerToken;
        const pi = portfolioItemsList.find(p => p.assetId === asset.id);
        const avgCost = pi ? parseFloat(pi.averageCost) : pricePerToken;
        const costBasis = balance * avgCost;
        const unrealizedGain = currentValue - costBasis;
        totalUnrealizedGains += unrealizedGain;

        unrealizedRows.push({
          asset: asset.name,
          symbol: asset.symbol,
          currency: asset.baseCurrency,
          tokens: balance.toFixed(2),
          costBasis: costBasis.toFixed(2),
          currentValue: currentValue.toFixed(2),
          unrealizedGain: unrealizedGain.toFixed(2),
          gainPercent: costBasis > 0 ? ((unrealizedGain / costBasis) * 100).toFixed(2) + "%" : "0.00%",
        });
      }

      rows.sort((a, b) => a.date.localeCompare(b.date));

      if (format === "pdf") {
        const PDFDocument = (await import("pdfkit")).default;
        const doc = new PDFDocument({ size: "A4", layout: "landscape", margin: 40 });
        res.setHeader("Content-Type", "application/pdf");
        res.setHeader("Content-Disposition", "attachment; filename=capital-gains-statement.pdf");
        doc.pipe(res);

        doc.fontSize(18).font("Helvetica-Bold").text("VestBlock - Capital Gains Statement", { align: "center" });
        doc.moveDown(0.3);
        doc.fontSize(9).font("Helvetica").text(`Generated: ${new Date().toLocaleDateString("en-GB")}`, { align: "center" });
        doc.moveDown(1);

        if (rows.length > 0) {
          doc.fontSize(12).font("Helvetica-Bold").text("Realized Gains / Capital Events");
          doc.moveDown(0.5);

          const rHeaders = ["Date", "Type", "Asset", "Amount", "Currency", "Description"];
          const rColWidths = [70, 80, 150, 80, 60, 260];
          let x = 40;
          const tableTop = doc.y;

          doc.font("Helvetica-Bold").fontSize(7);
          rHeaders.forEach((h, i) => {
            doc.text(h, x, tableTop, { width: rColWidths[i], align: i >= 3 ? "right" : "left" });
            x += rColWidths[i] + 4;
          });
          doc.moveDown(0.5);
          doc.moveTo(40, doc.y).lineTo(770, doc.y).stroke();
          doc.moveDown(0.3);

          doc.font("Helvetica").fontSize(7);
          for (const row of rows) {
            x = 40;
            const y = doc.y;
            const vals = [row.date, row.type, row.asset, row.amount, row.currency, row.description];
            vals.forEach((v, i) => {
              doc.text(String(v), x, y, { width: rColWidths[i], align: i >= 3 ? "right" : "left" });
              x += rColWidths[i] + 4;
            });
            doc.moveDown(0.5);
          }
          doc.moveDown(0.3);
          doc.font("Helvetica-Bold").fontSize(8);
          doc.text(`Total Realized: ${totalRealizedGains.toFixed(2)}`, 40);
          doc.moveDown(1);
        }

        if (unrealizedRows.length > 0) {
          doc.fontSize(12).font("Helvetica-Bold").text("Unrealized Gains (Current Holdings)");
          doc.moveDown(0.5);

          const uHeaders = ["Asset", "Symbol", "Currency", "Tokens", "Cost Basis", "Current Value", "Unrealized Gain", "Gain %"];
          const uColWidths = [130, 55, 55, 65, 80, 80, 90, 60];
          let x = 40;
          const tableTop = doc.y;

          doc.font("Helvetica-Bold").fontSize(7);
          uHeaders.forEach((h, i) => {
            doc.text(h, x, tableTop, { width: uColWidths[i], align: i >= 3 ? "right" : "left" });
            x += uColWidths[i] + 4;
          });
          doc.moveDown(0.5);
          doc.moveTo(40, doc.y).lineTo(770, doc.y).stroke();
          doc.moveDown(0.3);

          doc.font("Helvetica").fontSize(7);
          for (const row of unrealizedRows) {
            x = 40;
            const y = doc.y;
            const vals = [row.asset, row.symbol, row.currency, row.tokens, row.costBasis, row.currentValue, row.unrealizedGain, row.gainPercent];
            vals.forEach((v, i) => {
              doc.text(String(v), x, y, { width: uColWidths[i], align: i >= 3 ? "right" : "left" });
              x += uColWidths[i] + 4;
            });
            doc.moveDown(0.5);
          }
          doc.moveDown(0.3);
          doc.font("Helvetica-Bold").fontSize(8);
          doc.text(`Total Unrealized: ${totalUnrealizedGains.toFixed(2)}`, 40);
        }

        doc.end();
      } else {
        let csv = "REALIZED CAPITAL EVENTS\nDate,Type,Asset,Amount,Currency,Description,Reference\n";
        csv += rows.map(r =>
          `${r.date},"${r.type}","${r.asset}",${r.amount},${r.currency},"${r.description}",${r.referenceId}`
        ).join("\n");
        csv += `\nTotal Realized,,,${totalRealizedGains.toFixed(2)},,,\n\n`;
        csv += "UNREALIZED GAINS (CURRENT HOLDINGS)\nAsset,Symbol,Currency,Tokens,Cost Basis,Current Value,Unrealized Gain,Gain %\n";
        csv += unrealizedRows.map(r =>
          `"${r.asset}","${r.symbol}",${r.currency},${r.tokens},${r.costBasis},${r.currentValue},${r.unrealizedGain},${r.gainPercent}`
        ).join("\n");
        csv += `\nTotal Unrealized,,,,,,${totalUnrealizedGains.toFixed(2)},`;
        res.setHeader("Content-Type", "text/csv");
        res.setHeader("Content-Disposition", "attachment; filename=capital-gains-statement.csv");
        res.send(csv);
      }
    } catch (error: any) {
      console.error("Capital gains statement error:", error);
      res.status(500).json({ message: error.message });
    }
  });
}
