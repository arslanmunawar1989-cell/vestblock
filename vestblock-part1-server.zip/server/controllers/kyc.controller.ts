import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { logAuditFromReq } from "../lib/audit-logger";
import { submitKycSchema, insertDocumentSchema, users } from "@shared/schema";
import { z } from "zod";
import { eq } from "drizzle-orm";
import { db } from "../db";
import { getPolicy, getRequiredDocs, getPaymentRails, isIdTypeAllowed, getRiskReviewTemplates, type KycDocRequirement } from "@shared/compliance-policy";
import { countryCodeSchema } from "@shared/constants";
import { documentTypeEnum } from "@shared/schema";

export function registerKycRoutes(app: Express) {
  app.get("/api/compliance/policy", requireAuth, async (req, res) => {
    try {
      const countryCode = req.query.country as string;
      if (!countryCode) {
        const userId = (req as any).user.userId;
        const profiles = await storage.getCountryProfiles(userId);
        const primary = profiles.find(p => p.isPrimary) || profiles[0];
        const code = primary?.countryCode || "AE";
        return res.json(getPolicy(code));
      }
      const parsed = countryCodeSchema.safeParse(countryCode);
      if (!parsed.success) return res.status(400).json({ message: "Invalid country code" });
      res.json(getPolicy(parsed.data));
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch compliance policy" });
    }
  });

  app.get("/api/compliance/required-docs", requireAuth, async (req, res) => {
    try {
      const countryCode = req.query.country as string;
      if (!countryCode) {
        const userId = (req as any).user.userId;
        const profiles = await storage.getCountryProfiles(userId);
        const primary = profiles.find(p => p.isPrimary) || profiles[0];
        const code = primary?.countryCode || "AE";
        return res.json({ countryCode: code, docs: getRequiredDocs(code) });
      }
      const parsed = countryCodeSchema.safeParse(countryCode);
      if (!parsed.success) return res.status(400).json({ message: "Invalid country code" });
      res.json({ countryCode: parsed.data, docs: getRequiredDocs(parsed.data) });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch required docs" });
    }
  });

  app.get("/api/compliance/payment-rails", requireAuth, async (req, res) => {
    try {
      const countryCode = req.query.country as string;
      if (!countryCode) {
        const userId = (req as any).user.userId;
        const profiles = await storage.getCountryProfiles(userId);
        const primary = profiles.find(p => p.isPrimary) || profiles[0];
        const code = primary?.countryCode || "AE";
        const policy = getPolicy(code);
        return res.json({
          countryCode: code,
          countryName: policy.countryName,
          rails: getPaymentRails(code),
          defaultCurrency: policy.riskThresholds.largeDepositCurrency,
        });
      }
      const parsed = countryCodeSchema.safeParse(countryCode);
      if (!parsed.success) return res.status(400).json({ message: "Invalid country code" });
      const policy = getPolicy(parsed.data);
      res.json({
        countryCode: parsed.data,
        countryName: policy.countryName,
        rails: getPaymentRails(parsed.data),
        defaultCurrency: policy.riskThresholds.largeDepositCurrency,
      });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch payment rails" });
    }
  });

  app.get("/api/compliance/required-docs/validate", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const profiles = await storage.getCountryProfiles(userId);
      const primary = profiles.find(p => p.isPrimary) || profiles[0];
      const countryCode = primary?.countryCode || "AE";

      const requiredDocs = getRequiredDocs(countryCode);
      const userDocs = await storage.getDocumentsByOwner(userId);
      const uploadedDocTypes = new Set(userDocs.map(d => d.type));

      const checklist = requiredDocs.map(doc => ({
        ...doc,
        uploaded: uploadedDocTypes.has(doc.docType),
      }));

      const allRequiredUploaded = checklist
        .filter(d => d.required)
        .every(d => d.uploaded);

      res.json({
        countryCode,
        checklist,
        allRequiredUploaded,
        totalRequired: checklist.filter(d => d.required).length,
        totalUploaded: checklist.filter(d => d.uploaded).length,
      });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to validate docs" });
    }
  });

  app.get("/api/kyc", requireAuth, requireRole("investor"), async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const profile = await storage.getKycProfile(userId);
      res.json(profile || { status: "NOT_STARTED" });
    } catch (err: any) {
      console.error("KYC fetch error:", err);
      res.status(500).json({ message: "Failed to fetch KYC profile" });
    }
  });

  app.post("/api/kyc", requireAuth, requireRole("investor"), async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const existing = await storage.getKycProfile(userId);
      if (existing && existing.status === "IN_REVIEW") {
        return res.status(409).json({ message: "KYC application already submitted and under review" });
      }
      if (existing && existing.status === "APPROVED") {
        return res.status(409).json({ message: "KYC already approved" });
      }

      const data = submitKycSchema.parse(req.body);

      const profiles = await storage.getCountryProfiles(userId);
      const primary = profiles.find(p => p.isPrimary) || profiles[0];
      const userCountry = primary?.countryCode || "AE";

      if (!isIdTypeAllowed(userCountry, data.idType)) {
        const policy = getPolicy(userCountry);
        return res.status(400).json({
          message: `ID type "${data.idType}" is not accepted for ${policy.countryName}. Allowed types: ${policy.allowedIdTypes.join(", ")}`,
        });
      }

      const requiredDocs = getRequiredDocs(userCountry);
      const userDocs = await storage.getDocumentsByOwner(userId);
      const uploadedDocTypes = new Set(userDocs.map(d => d.type));

      const missingRequired = requiredDocs
        .filter(d => d.required)
        .filter(d => !uploadedDocTypes.has(d.docType));

      const profile = await storage.createKycProfile(userId, data);

      await db.update(users).set({ kycStatus: "in_review" }).where(eq(users.id, userId));

      const missingDocLabels = missingRequired.map(d => d.label);

      await logAuditFromReq(req, "KYC_SUBMITTED", "kyc_profile", profile.id, {
        reason: `KYC application submitted for review (ID type: ${data.idType}, country: ${userCountry})${missingDocLabels.length > 0 ? `. Missing docs: ${missingDocLabels.join(", ")}` : ""}`,
        afterState: { status: "IN_REVIEW", idType: data.idType, country: userCountry },
      });

      res.status(201).json({
        ...profile,
        missingDocs: missingDocLabels,
        countryCode: userCountry,
      });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("KYC submit error:", err);
      res.status(500).json({ message: "Failed to submit KYC application" });
    }
  });

  app.post("/api/documents", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const data = insertDocumentSchema.parse({ ...req.body, ownerId: userId });
      const doc = await storage.createDocument(data);
      res.status(201).json(doc);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("Document create error:", err);
      res.status(500).json({ message: "Failed to create document" });
    }
  });

  app.get("/api/documents", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const kycProfileId = req.query.kycProfileId as string | undefined;
      if (kycProfileId) {
        const docs = await storage.getDocumentsByKycProfile(kycProfileId);
        return res.json(docs);
      }
      const docs = await storage.getDocumentsByOwner(userId);
      res.json(docs);
    } catch (err: any) {
      console.error("Documents fetch error:", err);
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });

  app.get("/api/notifications", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const notifs = await storage.getNotifications(userId);
      res.json(notifs);
    } catch (err: any) {
      console.error("Notifications fetch error:", err);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.patch("/api/notifications/:id/read", requireAuth, async (req, res) => {
    try {
      const updated = await storage.markNotificationRead(req.params.id as string);
      if (!updated) return res.status(404).json({ message: "Notification not found" });
      res.json(updated);
    } catch (err: any) {
      console.error("Notification read error:", err);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  app.get("/api/admin/kyc", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const profiles = await storage.getAllKycProfiles(req.tenantId);
      const enriched = await Promise.all(profiles.map(async (p) => {
        const user = await storage.getUser(p.userId);
        const docs = await storage.getDocumentsByKycProfile(p.id);
        const countryProfiles = await storage.getCountryProfiles(p.userId);
        const primaryCountry = countryProfiles.find(cp => cp.isPrimary) || countryProfiles[0];
        return {
          ...p,
          user: user ? { id: user.id, username: user.username, email: user.email, fullName: user.fullName } : null,
          documentCount: docs.length,
          countryCode: primaryCountry?.countryCode || null,
        };
      }));
      res.json(enriched);
    } catch (err: any) {
      console.error("Admin KYC list error:", err);
      res.status(500).json({ message: "Failed to fetch KYC profiles" });
    }
  });

  app.get("/api/admin/kyc/:id", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const profile = await storage.getKycProfileById(req.params.id as string);
      if (!profile) return res.status(404).json({ message: "KYC profile not found" });
      const user = await storage.getUser(profile.userId);
      const docs = await storage.getDocumentsByKycProfile(profile.id);
      res.json({ ...profile, user: user ? { id: user.id, username: user.username, email: user.email, fullName: user.fullName } : null, documents: docs });
    } catch (err: any) {
      console.error("Admin KYC detail error:", err);
      res.status(500).json({ message: "Failed to fetch KYC profile" });
    }
  });

  const kycActionSchema = z.object({
    action: z.enum(["approve", "reject", "request_info", "request_doc"]),
    notes: z.string().optional(),
    requestedDocType: z.enum(documentTypeEnum).optional(),
    requestedDocLabel: z.string().optional(),
  }).refine(
    (data) => data.action !== "request_doc" || data.requestedDocType,
    { message: "requestedDocType is required for request_doc action", path: ["requestedDocType"] }
  );

  app.get("/api/admin/kyc/:id/risk-templates", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const profile = await storage.getKycProfileById(req.params.id as string);
      if (!profile) return res.status(404).json({ message: "KYC profile not found" });

      const profiles = await storage.getCountryProfiles(profile.userId);
      const primary = profiles.find(p => p.isPrimary) || profiles[0];
      const countryCode = primary?.countryCode || "AE";

      const templates = getRiskReviewTemplates(countryCode);
      const policy = getPolicy(countryCode);

      res.json({
        countryCode,
        countryName: policy.countryName,
        templates,
        requiredDocs: policy.requiredKycDocs,
        riskThresholds: policy.riskThresholds,
      });
    } catch (err: any) {
      console.error("Risk templates error:", err);
      res.status(500).json({ message: "Failed to fetch risk review templates" });
    }
  });

  app.get("/api/admin/kyc/:id/audit-log", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const result = await storage.searchAuditLogs({
        entityType: "kyc_profile",
        entityId: req.params.id as string,
        limit: 100,
      });
      res.json(result.logs);
    } catch (err: any) {
      console.error("Audit log fetch error:", err);
      res.status(500).json({ message: "Failed to fetch audit logs" });
    }
  });

  app.post("/api/admin/kyc/:id/action", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const profile = await storage.getKycProfileById(req.params.id as string);
      if (!profile) return res.status(404).json({ message: "KYC profile not found" });

      const parsed = kycActionSchema.parse(req.body);
      const { action, notes, requestedDocType, requestedDocLabel } = parsed;
      const adminUser = (req as any).user;
      const adminId = adminUser.userId;

      let newStatus: string;
      let notifTitle: string;
      let notifMessage: string;
      let auditDetails: string;

      if (action === "approve") {
        newStatus = "APPROVED";
        notifTitle = "KYC Approved";
        notifMessage = "Your KYC verification has been approved. You can now access all investment features.";
        auditDetails = `KYC approved by admin ${adminId}${notes ? `. Notes: ${notes}` : ""}`;
      } else if (action === "reject") {
        newStatus = "REJECTED";
        notifTitle = "KYC Rejected";
        notifMessage = notes ? `Your KYC verification was rejected: ${notes}` : "Your KYC verification was rejected. Please resubmit with corrected information.";
        auditDetails = `KYC rejected by admin ${adminId}. Reason: ${notes || "No reason provided"}`;
      } else if (action === "request_doc") {
        newStatus = "INFO_REQUESTED";
        const docLabel = requestedDocLabel || requestedDocType?.replace(/_/g, " ") || "document";
        notifTitle = "Additional Document Required";
        notifMessage = `Your KYC review requires an additional document: ${docLabel}. ${notes ? `Details: ${notes}` : "Please upload the requested document and resubmit."}`;
        auditDetails = `Admin ${adminId} requested additional document: ${docLabel} (${requestedDocType})${notes ? `. Notes: ${notes}` : ""}`;
      } else {
        newStatus = "INFO_REQUESTED";
        notifTitle = "Additional Information Needed";
        notifMessage = notes ? `Additional information requested for your KYC: ${notes}` : "Additional information is needed for your KYC verification.";
        auditDetails = `Admin ${adminId} requested additional info${notes ? `: ${notes}` : ""}`;
      }

      const reviewNotesStored = action === "request_doc"
        ? `[DOC_REQUEST:${requestedDocType}] ${requestedDocLabel || requestedDocType?.replace(/_/g, " ")} - ${notes || "Please upload the requested document."}`
        : notes;

      const updated = await storage.updateKycStatus(profile.id, newStatus, reviewNotesStored);
      await db.update(users).set({ kycStatus: newStatus === "APPROVED" ? "approved" : newStatus === "REJECTED" ? "rejected" : "in_review" }).where(eq(users.id, profile.userId));

      await storage.createNotification({
        userId: profile.userId,
        type: "kyc_update",
        title: notifTitle,
        message: notifMessage,
        relatedEntityId: profile.id,
        relatedEntityType: "kyc_profile",
      });

      await logAuditFromReq(req, `KYC_${action.toUpperCase()}`, "kyc_profile", profile.id, {
        reason: auditDetails,
        beforeState: { status: profile.status },
        afterState: { status: newStatus },
      });

      res.json({ ...updated, notification: { title: notifTitle, message: notifMessage } });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("KYC action error:", err);
      res.status(500).json({ message: "Failed to process KYC action" });
    }
  });
}
