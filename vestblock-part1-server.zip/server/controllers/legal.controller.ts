import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth } from "../auth";
import { logAuditFromReq } from "../lib/audit-logger";
import { z } from "zod";
import { countryCodeSchema } from "@shared/constants";

export function registerLegalRoutes(app: Express) {
  app.get("/api/legal/documents", async (_req, res) => {
    try {
      const docs = await storage.getActiveLegalDocuments();
      res.json(docs);
    } catch (err: any) {
      console.error("Legal docs fetch error:", err);
      res.status(500).json({ message: "Failed to fetch legal documents" });
    }
  });

  app.get("/api/legal/documents/country/:country", async (req, res) => {
    try {
      const country = countryCodeSchema.parse(String(req.params.country));
      const docs = await storage.getActiveLegalDocumentsByCountry(country);
      res.json(docs);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid country code" });
      }
      console.error("Legal docs by country fetch error:", err);
      res.status(500).json({ message: "Failed to fetch legal documents" });
    }
  });

  app.get("/api/legal/documents/:type", async (req, res) => {
    try {
      const doc = await storage.getLegalDocumentByType(String(req.params.type));
      if (!doc) return res.status(404).json({ message: "Legal document not found" });
      res.json(doc);
    } catch (err: any) {
      console.error("Legal doc fetch error:", err);
      res.status(500).json({ message: "Failed to fetch legal document" });
    }
  });

  app.get("/api/legal/acceptance/status", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const activeDocs = await storage.getActiveLegalDocuments();
      const globalDocs = activeDocs.filter(d => !d.country && d.productType === "GENERAL");
      const acceptances = await storage.getUserAcceptances(userId);
      const acceptedDocIds = new Set(acceptances.map(a => a.legalDocumentId));

      const pending = globalDocs.filter(d => !acceptedDocIds.has(d.id));
      const accepted = globalDocs.filter(d => acceptedDocIds.has(d.id));

      res.json({
        allAccepted: pending.length === 0,
        pending: pending.map(d => ({ id: d.id, type: d.type, title: d.title, version: d.version, country: d.country, productType: d.productType })),
        accepted: accepted.map(d => {
          const acc = acceptances.find(a => a.legalDocumentId === d.id);
          return { id: d.id, type: d.type, title: d.title, version: d.version, country: d.country, productType: d.productType, acceptedAt: acc?.acceptedAt };
        }),
      });
    } catch (err: any) {
      console.error("Acceptance status error:", err);
      res.status(500).json({ message: "Failed to fetch acceptance status" });
    }
  });

  app.get("/api/legal/acceptance/country/:country", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const country = countryCodeSchema.parse(String(req.params.country));
      const countryDocs = await storage.getActiveLegalDocumentsByCountry(country);
      const acceptances = await storage.getUserAcceptances(userId);
      const acceptedDocIds = new Set(acceptances.map(a => a.legalDocumentId));

      const pending = countryDocs.filter(d => !acceptedDocIds.has(d.id));
      const accepted = countryDocs.filter(d => acceptedDocIds.has(d.id));

      res.json({
        country,
        allAccepted: pending.length === 0,
        pending: pending.map(d => ({ id: d.id, type: d.type, title: d.title, version: d.version, country: d.country })),
        accepted: accepted.map(d => {
          const acc = acceptances.find(a => a.legalDocumentId === d.id);
          return { id: d.id, type: d.type, title: d.title, version: d.version, country: d.country, acceptedAt: acc?.acceptedAt };
        }),
      });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid country code" });
      }
      console.error("Country acceptance status error:", err);
      res.status(500).json({ message: "Failed to fetch country acceptance status" });
    }
  });

  app.get("/api/legal/documents/jurisdiction/:jurisdiction/product/:productType", async (req, res) => {
    try {
      const jurisdiction = req.params.jurisdiction.toUpperCase();
      const productType = req.params.productType.toUpperCase();
      const docs = await storage.getActiveLegalDocsByJurisdictionProduct(jurisdiction, productType);
      res.json(docs);
    } catch (err: any) {
      console.error("Legal docs by jurisdiction+product error:", err);
      res.status(500).json({ message: "Failed to fetch legal documents" });
    }
  });

  app.get("/api/legal/acceptance/investment-check", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const { country, vehicleType } = req.query as { country?: string; vehicleType?: string };
      if (!country || !vehicleType) {
        return res.status(400).json({ message: "country and vehicleType query params required" });
      }
      const requiredDocs = await storage.getRequiredDocsForInvestment(country.toUpperCase(), vehicleType.toUpperCase());
      const { allAccepted, pending } = await storage.hasAcceptedAllRequiredDocs(userId, requiredDocs);
      res.json({
        allAccepted,
        country: country.toUpperCase(),
        vehicleType: vehicleType.toUpperCase(),
        totalRequired: requiredDocs.length,
        pending: pending.map(d => ({
          id: d.id,
          type: d.type,
          title: d.title,
          version: d.version,
          country: d.country,
          productType: d.productType,
          jurisdictionCode: d.jurisdictionCode,
        })),
      });
    } catch (err: any) {
      console.error("Investment acceptance check error:", err);
      res.status(500).json({ message: "Failed to check legal acceptance for investment" });
    }
  });

  const acceptLegalSchema = z.object({
    documentIds: z.array(z.string().min(1)).min(1),
  });

  app.post("/api/legal/accept", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const { documentIds } = acceptLegalSchema.parse(req.body);

      const results = [];
      for (const docId of documentIds) {
        const doc = await storage.getLegalDocumentById(docId);
        if (!doc) continue;
        const already = await storage.hasUserAcceptedDocument(userId, docId);
        if (already) continue;

        const acceptance = await storage.createLegalAcceptance({
          userId,
          legalDocumentId: docId,
          ipAddress: req.ip || req.socket.remoteAddress || null,
        });
        results.push(acceptance);
      }

      await logAuditFromReq(req, "LEGAL_ACCEPTANCE", "legal_acceptance", userId, {
        reason: `User accepted ${results.length} legal document(s): ${documentIds.join(", ")}`,
        metadata: { documentIds, acceptedCount: results.length },
      });

      res.status(201).json({ accepted: results.length, acceptances: results });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("Legal accept error:", err);
      res.status(500).json({ message: "Failed to record legal acceptance" });
    }
  });
}
