import type { Express, Request, Response } from "express";
import { storage } from "../storage";
import { requireAuth, requireTenantAction, hashPassword, generateToken } from "../auth";
import { logAudit } from "../lib/audit-logger";
import { z } from "zod";
import type { TenantRole } from "@shared/constants";
import { TENANT_ROLES } from "@shared/constants";

function p(val: string | string[]): string {
  return Array.isArray(val) ? val[0] : val;
}

export function registerTenantUsersRoutes(app: Express) {
  app.get("/api/tenant-admin/:tenantId/users", requireAuth, requireTenantAction("tenant_users.view"), async (req: Request, res: Response) => {
    try {
      const members = await storage.getTenantUsers(p(req.params.tenantId));
      const membersWithDetails = await Promise.all(
        members.map(async (m) => {
          const user = await storage.getUser(m.userId);
          return {
            ...m,
            user: user ? {
              id: user.id,
              username: user.username,
              email: user.email,
              fullName: user.fullName,
              isActive: user.isActive,
              avatarUrl: user.avatarUrl,
              role: user.role,
            } : null,
          };
        })
      );
      res.json(membersWithDetails);
    } catch (err: any) {
      console.error("Get tenant users error:", err);
      res.status(500).json({ message: "Failed to fetch tenant users" });
    }
  });

  const inviteSchema = z.object({
    email: z.string().email(),
    fullName: z.string().min(1),
    role: z.enum(TENANT_ROLES as any).default("TENANT_USER"),
  });

  app.post("/api/tenant-admin/:tenantId/invite", requireAuth, requireTenantAction("tenant_users.invite"), async (req: Request, res: Response) => {
    try {
      const data = inviteSchema.parse(req.body);
      const tenantId = p(req.params.tenantId);
      const actor = (req as any).user;

      let user = await storage.getUserByEmail(data.email);

      if (user) {
        const existing = await storage.getTenantUser(tenantId, user.id);
        if (existing) {
          return res.status(409).json({ message: "User is already a member of this agency" });
        }
        const tenantUser = await storage.createTenantUser({
          tenantId,
          userId: user.id,
          role: data.role,
          status: "ACTIVE",
        });

        await logAudit({
          actorId: actor.userId,
          actorRole: actor.role,
          actionType: "TENANT_USER_ADDED",
          entityType: "tenant_user",
          entityId: tenantUser.id,
          reason: `Existing user ${user.email} added to tenant with role ${data.role}`,
          ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
          userAgent: req.headers["user-agent"] || undefined,
        });

        return res.status(201).json({ tenantUser, message: "Existing user added to agency" });
      }

      const tempPassword = Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
      const hashedPw = await hashPassword(tempPassword);
      const username = data.email.split("@")[0] + "_" + Math.random().toString(36).slice(2, 6);

      user = await storage.createUser({
        username,
        password: hashedPw,
        email: data.email,
        fullName: data.fullName,
        role: "investor",
        tenantId,
      });

      const tenantUser = await storage.createTenantUser({
        tenantId,
        userId: user.id,
        role: data.role,
        status: "INVITED",
      });

      await logAudit({
        actorId: actor.userId,
        actorRole: actor.role,
        actionType: "TENANT_USER_INVITED",
        entityType: "tenant_user",
        entityId: tenantUser.id,
        reason: `New user ${data.email} invited to tenant with role ${data.role}`,
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });

      res.status(201).json({ tenantUser, message: "User invited to agency", invited: true });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("Invite user error:", err);
      res.status(500).json({ message: "Failed to invite user" });
    }
  });

  const addTenantUserSchema = z.object({
    email: z.string().email(),
    fullName: z.string().min(1),
    password: z.string().min(6),
    username: z.string().optional(),
    role: z.string().optional(),
  });

  app.post("/api/tenant-admin/:tenantId/add-user", requireAuth, requireTenantAction("tenant_users.manage"), async (req: Request, res: Response) => {
    try {
      const parsed = addTenantUserSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Validation error", errors: parsed.error.flatten() });
      }
      const { username, email, fullName, password, role } = parsed.data;
      const tenantId = p(req.params.tenantId);
      const actor = (req as any).user;

      const existingEmail = await storage.getUserByEmail(email);
      if (existingEmail) {
        const existingMember = await storage.getTenantUser(tenantId, existingEmail.id);
        if (existingMember) {
          return res.status(409).json({ message: "User is already a member of this agency" });
        }
        const tenantUser = await storage.createTenantUser({
          tenantId,
          userId: existingEmail.id,
          role: role || "TENANT_USER",
          status: "ACTIVE",
        });

        await logAudit({
          actorId: actor.userId,
          actorRole: actor.role,
          actionType: "TENANT_USER_ADDED",
          entityType: "tenant_user",
          entityId: tenantUser.id,
          reason: `Existing user ${email} added to tenant with role ${role || "TENANT_USER"}`,
          afterState: { role: role || "TENANT_USER", status: "ACTIVE" },
          ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
          userAgent: req.headers["user-agent"] || undefined,
        });

        return res.status(201).json({ tenantUser, message: "Existing user added to agency" });
      }

      const hashedPw = await hashPassword(password);
      const finalUsername = username || email.split("@")[0] + "_" + Math.random().toString(36).slice(2, 6);

      const existingUsername = await storage.getUserByUsername(finalUsername);
      if (existingUsername) {
        return res.status(409).json({ message: "Username already taken" });
      }

      const user = await storage.createUser({
        username: finalUsername,
        password: hashedPw,
        email,
        fullName,
        role: "investor",
        tenantId,
      });

      const tenantUser = await storage.createTenantUser({
        tenantId,
        userId: user.id,
        role: role || "TENANT_USER",
        status: "ACTIVE",
      });

      await logAudit({
        actorId: actor.userId,
        actorRole: actor.role,
        actionType: "TENANT_USER_CREATED",
        entityType: "tenant_user",
        entityId: tenantUser.id,
        reason: `User ${email} created and added to tenant with role ${role || "TENANT_USER"}`,
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });

      res.status(201).json({ tenantUser, user: { id: user.id, username: user.username, email: user.email, fullName: user.fullName }, message: "User created and added to agency" });
    } catch (err: any) {
      console.error("Add user error:", err);
      res.status(500).json({ message: "Failed to add user" });
    }
  });

  app.patch("/api/tenant-admin/:tenantId/users/:userId/role", requireAuth, requireTenantAction("tenant_users.manage"), async (req: Request, res: Response) => {
    try {
      const { role } = req.body;
      if (!role || !TENANT_ROLES.includes(role)) {
        return res.status(400).json({ message: "Valid tenant role required" });
      }
      const updated = await storage.updateTenantUser(p(req.params.tenantId), p(req.params.userId), { role });
      if (!updated) {
        return res.status(404).json({ message: "Tenant user not found" });
      }
      const actor = (req as any).user;
      await logAudit({
        actorId: actor.userId,
        actorRole: actor.role,
        actionType: "TENANT_USER_ROLE_CHANGED",
        entityType: "tenant_user",
        entityId: updated.id,
        reason: `User role changed to ${role} in tenant`,
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });
      res.json(updated);
    } catch (err: any) {
      console.error("Update role error:", err);
      res.status(500).json({ message: "Failed to update role" });
    }
  });

  app.patch("/api/tenant-admin/:tenantId/users/:userId/status", requireAuth, requireTenantAction("tenant_users.manage"), async (req: Request, res: Response) => {
    try {
      const { status } = req.body;
      if (!["ACTIVE", "DISABLED"].includes(status)) {
        return res.status(400).json({ message: "Status must be ACTIVE or DISABLED" });
      }
      const updated = await storage.updateTenantUser(p(req.params.tenantId), p(req.params.userId), { status });
      if (!updated) {
        return res.status(404).json({ message: "Tenant user not found" });
      }
      const actor = (req as any).user;
      await logAudit({
        actorId: actor.userId,
        actorRole: actor.role,
        actionType: "TENANT_USER_STATUS_CHANGED",
        entityType: "tenant_user",
        entityId: updated.id,
        reason: `User status changed to ${status} in tenant`,
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });
      res.json(updated);
    } catch (err: any) {
      console.error("Update status error:", err);
      res.status(500).json({ message: "Failed to update status" });
    }
  });

  app.delete("/api/tenant-admin/:tenantId/users/:userId", requireAuth, requireTenantAction("tenant_users.remove"), async (req: Request, res: Response) => {
    try {
      await storage.removeTenantUser(p(req.params.tenantId), p(req.params.userId));
      const actor = (req as any).user;
      await logAudit({
        actorId: actor.userId,
        actorRole: actor.role,
        actionType: "TENANT_USER_REMOVED",
        entityType: "tenant_user",
        reason: `User ${p(req.params.userId)} removed from tenant ${p(req.params.tenantId)}`,
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });
      res.json({ message: "User removed from agency" });
    } catch (err: any) {
      console.error("Remove user error:", err);
      res.status(500).json({ message: "Failed to remove user" });
    }
  });

  app.post("/api/tenant-admin/:tenantId/users/:userId/force-logout", requireAuth, requireTenantAction("tenant_users.force_logout"), async (req: Request, res: Response) => {
    try {
      const user = await storage.getUser(p(req.params.userId));
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      const actor = (req as any).user;
      await logAudit({
        actorId: actor.userId,
        actorRole: actor.role,
        actionType: "TENANT_USER_FORCE_LOGOUT",
        entityType: "tenant_user",
        reason: `Force logout for user ${user.username} in tenant ${p(req.params.tenantId)}`,
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });
      res.json({ message: "Force logout initiated" });
    } catch (err: any) {
      console.error("Force logout error:", err);
      res.status(500).json({ message: "Failed to force logout" });
    }
  });
}
