import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { createTicketSchema, updateTicketSchema } from "@shared/schema";

export function registerTicketRoutes(app: Express) {
  app.post("/api/tickets", requireAuth, async (req, res) => {
    try {
      const jwtUser = (req as any).user;
      const parsed = createTicketSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Validation failed", errors: parsed.error.flatten().fieldErrors });
      }

      const ticket = await storage.createSupportTicket({
        userId: jwtUser.userId,
        ...parsed.data,
      });

      await storage.createNotification({
        userId: jwtUser.userId,
        type: "ticket_created",
        title: "Support Ticket Created",
        message: `Your ticket "${parsed.data.subject}" has been submitted. We'll get back to you soon.`,
        relatedEntityId: ticket.id,
        relatedEntityType: "support_ticket",
      });

      res.status(201).json(ticket);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tickets", requireAuth, async (req, res) => {
    try {
      const jwtUser = (req as any).user;
      const tickets = await storage.getSupportTicketsByUser(jwtUser.userId);
      res.json(tickets);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/tickets/:id", requireAuth, async (req, res) => {
    try {
      const ticket = await storage.getSupportTicketById(String(req.params.id));
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }
      const jwtUser = (req as any).user;
      if (ticket.userId !== jwtUser.userId && jwtUser.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      res.json(ticket);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/tickets", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const allTickets = await storage.getAllSupportTickets(req.tenantId);

      const { countryCode, currency, category, priority, status } = req.query;

      let filtered = allTickets;
      if (countryCode && typeof countryCode === "string") {
        filtered = filtered.filter(t => t.countryCode === countryCode);
      }
      if (currency && typeof currency === "string") {
        filtered = filtered.filter(t => t.currency === currency);
      }
      if (category && typeof category === "string") {
        filtered = filtered.filter(t => t.category === category);
      }
      if (priority && typeof priority === "string") {
        filtered = filtered.filter(t => t.priority === priority);
      }
      if (status && typeof status === "string") {
        filtered = filtered.filter(t => t.status === status);
      }

      const userIds = [...new Set(filtered.map(t => t.userId))];
      const usersMap: Record<string, string> = {};
      for (const uid of userIds) {
        const user = await storage.getUser(uid);
        if (user) usersMap[uid] = user.fullName;
      }

      const enriched = filtered.map(t => ({
        ...t,
        userName: usersMap[t.userId] || "Unknown",
      }));

      res.json(enriched);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/admin/tickets/:id", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const ticket = await storage.getSupportTicketById(String(req.params.id));
      if (!ticket) {
        return res.status(404).json({ message: "Ticket not found" });
      }

      const parsed = updateTicketSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Validation failed", errors: parsed.error.flatten().fieldErrors });
      }

      const adminId = (req as any).user.userId;
      const updateData: any = { ...parsed.data };

      if (parsed.data.status === "resolved" || parsed.data.status === "closed") {
        updateData.resolvedBy = adminId;
        updateData.resolvedAt = new Date().toISOString();
      }

      const updated = await storage.updateSupportTicket(String(req.params.id), updateData);

      if (parsed.data.status && parsed.data.status !== ticket.status) {
        const statusLabel = parsed.data.status.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
        await storage.createNotification({
          userId: ticket.userId,
          type: "ticket_update",
          title: "Ticket Status Updated",
          message: `Your ticket "${ticket.subject}" status changed to ${statusLabel}.`,
          relatedEntityId: ticket.id,
          relatedEntityType: "support_ticket",
        });
      }

      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
}
