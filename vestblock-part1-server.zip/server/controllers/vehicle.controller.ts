import type { Express } from "express";
import { requireAuth, requireRole } from "../auth";
import { storage } from "../storage";
import {
  createVehicleSchema,
  updateVehicleSchema,
  vehicleStatusTransitionSchema,
  attachAssetToVehicleSchema,
  vehicleStatusEnum,
} from "@shared/schema";

function normalizeOptionals(data: Record<string, any>): Record<string, any> {
  const nullableFields = [
    "platformFee", "trusteeFee", "propertyMgmtFee", "legalFee", "reservePercent",
    "bankAccountConfigId", "targetAum", "currentNav", "strategy", "fundManager",
    "inceptionDate", "regNumber", "registeredAgent", "incorporationDate",
  ];
  const result = { ...data };
  for (const field of nullableFields) {
    if (result[field] === "" || result[field] === undefined) {
      result[field] = null;
    }
  }
  return result;
}

const VALID_TRANSITIONS: Record<string, string[]> = {
  DRAFT: ["REVIEW"],
  REVIEW: ["ACTIVE", "DRAFT"],
  ACTIVE: ["SUSPENDED", "CLOSED"],
  SUSPENDED: ["ACTIVE", "CLOSED"],
  CLOSED: [],
};

export function registerVehicleRoutes(app: Express) {
  app.post("/api/admin/vehicles", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const parsed = createVehicleSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Validation failed", details: parsed.error.flatten() });
      }
      const user = (req as any).user;
      const data = normalizeOptionals(parsed.data);
      const vehicle = await storage.createInvestmentVehicle({
        ...data,
        createdBy: user.userId,
        status: "DRAFT",
      });
      res.status(201).json(vehicle);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/vehicles", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const vehicles = await storage.getAllInvestmentVehicles(req.tenantId);
      res.json(vehicles);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/vehicles/:id", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const vehicle = await storage.getInvestmentVehicle(String(req.params.id));
      if (!vehicle) return res.status(404).json({ message: "Vehicle not found" });
      const linkedAssets = await storage.getAssetsByVehicle(vehicle.id);
      res.json({ ...vehicle, assets: linkedAssets });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/admin/vehicles/:id", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const parsed = updateVehicleSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Validation failed", details: parsed.error.flatten() });
      }
      const vehicle = await storage.getInvestmentVehicle(String(req.params.id));
      if (!vehicle) return res.status(404).json({ message: "Vehicle not found" });
      const data = normalizeOptionals(parsed.data);
      const updated = await storage.updateInvestmentVehicle(String(req.params.id), data as any);
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.patch("/api/admin/vehicles/:id/status", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const parsed = vehicleStatusTransitionSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Validation failed", details: parsed.error.flatten() });
      }
      const vehicle = await storage.getInvestmentVehicle(String(req.params.id));
      if (!vehicle) return res.status(404).json({ message: "Vehicle not found" });

      const allowedNext = VALID_TRANSITIONS[vehicle.status] || [];
      if (!allowedNext.includes(parsed.data.status)) {
        return res.status(400).json({
          message: `Cannot transition from ${vehicle.status} to ${parsed.data.status}. Allowed: ${allowedNext.join(", ") || "none"}`,
        });
      }

      const updated = await storage.updateInvestmentVehicleStatus(String(req.params.id), parsed.data.status);
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/vehicles/:id/attach-asset", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const parsed = attachAssetToVehicleSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Validation failed", details: parsed.error.flatten() });
      }
      const vehicle = await storage.getInvestmentVehicle(String(req.params.id));
      if (!vehicle) return res.status(404).json({ message: "Not found" });

      const asset = await storage.getAsset(parsed.data.assetId);
      if (!asset) return res.status(404).json({ message: "Property not found" });

      if (asset.vehicleId && asset.vehicleId !== vehicle.id) {
        return res.status(400).json({ message: "Property is already attached to another Fund or SPV" });
      }

      if (vehicle.type === "SPV") {
        const existingAssets = await storage.getAssetsByVehicle(vehicle.id);
        if (existingAssets.length > 0 && !existingAssets.some(a => a.id === parsed.data.assetId)) {
          return res.status(400).json({ message: "An SPV can only hold one property. Detach the existing property first." });
        }
      }

      const updated = await storage.attachAssetToVehicle(parsed.data.assetId, vehicle.id);
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/vehicles/:id/detach-asset", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const parsed = attachAssetToVehicleSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Validation failed", details: parsed.error.flatten() });
      }
      const vehicle = await storage.getInvestmentVehicle(String(req.params.id));
      if (!vehicle) return res.status(404).json({ message: "Vehicle not found" });

      const asset = await storage.getAsset(parsed.data.assetId);
      if (!asset) return res.status(404).json({ message: "Asset not found" });
      if (asset.vehicleId !== vehicle.id) {
        return res.status(400).json({ message: "Asset is not attached to this vehicle" });
      }

      const updated = await storage.detachAssetFromVehicle(parsed.data.assetId);
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
}
