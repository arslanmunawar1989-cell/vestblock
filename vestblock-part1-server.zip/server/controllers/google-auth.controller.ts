import type { Express, Request } from "express";
import passport from "passport";
import { Strategy as GoogleStrategy, type VerifyCallback } from "passport-google-oauth20";
import { storage } from "../storage";
import { generateToken } from "../auth";
import { hashPassword } from "../auth";
import { logAudit } from "../lib/audit-logger";

const cookieOptions = {
  httpOnly: true,
  secure: process.env.NODE_ENV === "production",
  sameSite: "lax" as const,
  maxAge: 7 * 24 * 60 * 60 * 1000,
  path: "/",
};

export function registerGoogleAuthRoutes(app: Express) {
  const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
  const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;

  if (!GOOGLE_CLIENT_ID || !GOOGLE_CLIENT_SECRET) {
    console.log("[auth] Google OAuth not configured — GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET missing");
    app.get("/api/auth/google", (_req, res) => {
      res.status(503).json({ message: "Google OAuth is not configured" });
    });
    return;
  }

  const callbackURL = process.env.GOOGLE_CALLBACK_URL || "/api/auth/google/callback";

  passport.use(
    new GoogleStrategy(
      {
        clientID: GOOGLE_CLIENT_ID,
        clientSecret: GOOGLE_CLIENT_SECRET,
        callbackURL,
        passReqToCallback: true,
      },
      async (req: Request, _accessToken: string, _refreshToken: string, profile: any, done: VerifyCallback) => {
        try {
          const tenantId = (req as any).tenantId as string | undefined;
          const googleId = profile.id;
          const email = profile.emails?.[0]?.value;
          const fullName = profile.displayName || `${profile.name?.givenName || ""} ${profile.name?.familyName || ""}`.trim() || "Google User";
          const avatarUrl = profile.photos?.[0]?.value || null;

          let user = await storage.getUserByGoogleId(googleId);

          if (!user && email) {
            user = await storage.getUserByEmail(email);
            if (user) {
              const { db } = await import("../db");
              const { users } = await import("@shared/schema");
              const { eq } = await import("drizzle-orm");
              await db.update(users).set({ googleId, authProvider: "google" }).where(eq(users.id, user.id));
              user = { ...user, googleId, authProvider: "google" };
            }
          }

          if (!user) {
            if (!email) {
              return done(new Error("Google account has no email"));
            }
            const username = email.split("@")[0] + "_g" + googleId.slice(-4);
            const randomPass = await hashPassword(Math.random().toString(36).slice(2) + Date.now());
            user = await storage.createUser({
              username,
              password: randomPass,
              email,
              fullName,
              avatarUrl,
              role: "investor",
              googleId,
              authProvider: "google",
              tenantId: tenantId || undefined,
            });

            if (tenantId) {
              try {
                await storage.createTenantUser({ tenantId, userId: user.id, role: "investor" });
              } catch (_e) {}
            }

            await logAudit({
              actorId: user.id,
              actorRole: user.role,
              actionType: "USER_REGISTERED",
              entityType: "user",
              entityId: user.id,
              reason: `New user registered via Google: ${email}`,
            });
          } else {
            if (user.accountStatus === "DISABLED") {
              return done(new Error("account_disabled"));
            }
            if (user.accountStatus === "ARCHIVED") {
              return done(new Error("account_archived"));
            }
            if (!user.isActive) {
              return done(new Error("account_deactivated"));
            }

            if (tenantId && tenantId !== user.tenantId) {
              const tenantUser = await storage.getTenantUser(tenantId, user.id);
              if (!tenantUser) {
                return done(new Error("no_tenant_access"));
              }
            }
          }

          (req as any)._googleTenantId = tenantId;
          done(null, user);
        } catch (err: any) {
          done(err);
        }
      }
    )
  );

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: string, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user || null);
    } catch (err) {
      done(err);
    }
  });

  app.use(passport.initialize());

  app.get("/api/auth/google", passport.authenticate("google", { session: false, scope: ["profile", "email"] }));

  app.get(
    "/api/auth/google/callback",
    passport.authenticate("google", { session: false, failureRedirect: "/login?error=google_auth_failed" }),
    async (req, res) => {
      try {
        const user = req.user as any;
        if (!user) {
          return res.redirect("/login?error=no_user");
        }

        const tenantId = (req as any)._googleTenantId || (req as any).tenantId;
        const token = generateToken(user, tenantId);

        res.cookie("token", token, cookieOptions);

        const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
        await storage.createSession({
          userId: user.id,
          token,
          ipAddress: req.ip || req.headers["x-forwarded-for"] as string || null,
          userAgent: req.headers["user-agent"] || null,
          provider: "google",
          expiresAt,
        }).catch(() => {});

        await logAudit({
          actorId: user.id,
          actorRole: user.role,
          actionType: "USER_LOGIN",
          entityType: "user",
          entityId: user.id,
          reason: `User logged in via Google: ${user.email}`,
          ipAddress: req.ip || (req.headers["x-forwarded-for"] as string) || undefined,
          userAgent: req.headers["user-agent"] || undefined,
        });

        const role = user.role;
        const redirectPath = role === "admin" ? "/admin" : `/${role}`;
        res.redirect(redirectPath);
      } catch (err) {
        console.error("Google callback error:", err);
        res.redirect("/login?error=callback_failed");
      }
    }
  );
}
