import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { logAuditFromReq } from "../lib/audit-logger";
import { z } from "zod";
import { CURRENCY_DETAILS } from "@shared/constants";
import { createExitWindowSchema, createTradeListingSchema, executeBuySchema, createExitWindowScheduleSchema, exitWindows } from "@shared/schema";
import { db } from "../db";
import { walletTransactions, portfolioItems, tradeListings, transactions, tokenHoldings, tokenTransfers, tokenLedgerEntries } from "@shared/schema";
import { eq, and, or, lte, gte } from "drizzle-orm";
import { createExitWindowRequestSchema, createTradeListingRequestSchema, executeBuyRequestSchema, updateExitWindowRulesRequestSchema } from "@shared/dto/trade.dto";
import { validateBody } from "../middleware/validate";
import { canTransfer } from "../services/transfer-restrictions.service";
import { getOnChainProvider } from "../services/on-chain-provider";
import { buildPolicyContext, canTrade as canTradePolicy } from "../services/policy.service";
import { checkTradeEligibility } from "../services/trade-eligibility.service";
import { paymentLimiter } from "../middleware/rate-limit";

async function resolveTokenForAsset(assetId: string): Promise<string | null> {
  const token = await storage.getTokenByAssetId(assetId);
  if (token) return token.id;
  const vehicleTokens = await storage.getTokensByVehicle(assetId);
  if (vehicleTokens.length > 0) return vehicleTokens[0].id;
  return null;
}

function decimalMul(a: string, b: number): string {
  const aNum = Math.round(parseFloat(a) * 1e6);
  const bNum = Math.round(b * 1e6);
  return (aNum * bNum / 1e12).toFixed(2);
}

function decimalCompare(a: string, b: string): number {
  const diff = parseFloat(a) - parseFloat(b);
  if (Math.abs(diff) < 0.005) return 0;
  return diff;
}

async function generateWindowsFromSchedule(schedule: any, assetName: string) {
  const now = new Date();
  const currentYear = now.getFullYear();
  const created = [];

  const getQuarterStarts = (year: number) => [
    { q: "Q1", date: new Date(year, 2, 1), label: `Q1 (Mar)` },
    { q: "Q2", date: new Date(year, 5, 1), label: `Q2 (Jun)` },
    { q: "Q3", date: new Date(year, 8, 1), label: `Q3 (Sep)` },
    { q: "Q4", date: new Date(year, 11, 1), label: `Q4 (Dec)` },
  ];

  const getMonthStarts = (year: number) => {
    const months = [];
    for (let m = 0; m < 12; m++) {
      months.push({ label: new Date(year, m, 1).toLocaleString("default", { month: "short" }), date: new Date(year, m, 1) });
    }
    return months;
  };

  const getSemiAnnualStarts = (year: number) => [
    { label: "H1 (Jan)", date: new Date(year, 0, 1) },
    { label: "H2 (Jul)", date: new Date(year, 6, 1) },
  ];

  const getAnnualStarts = (year: number) => [
    { label: "Annual (Jan)", date: new Date(year, 0, 1) },
  ];

  let intervals: { label: string; date: Date; quarter?: string }[] = [];

  switch (schedule.frequency) {
    case "quarterly":
      for (const y of [currentYear, currentYear + 1]) {
        intervals.push(...getQuarterStarts(y).map(q => ({ label: `${q.label} ${y}`, date: q.date, quarter: `${y}-${q.q}` })));
      }
      break;
    case "monthly":
      for (const y of [currentYear, currentYear + 1]) {
        intervals.push(...getMonthStarts(y).map(m => ({ label: `${m.label} ${y}`, date: m.date })));
      }
      break;
    case "semi_annual":
      for (const y of [currentYear, currentYear + 1]) {
        intervals.push(...getSemiAnnualStarts(y).map(h => ({ label: `${h.label} ${y}`, date: h.date })));
      }
      break;
    case "annual":
      for (const y of [currentYear, currentYear + 1]) {
        intervals.push(...getAnnualStarts(y).map(a => ({ label: `${a.label} ${y}`, date: a.date })));
      }
      break;
    case "custom": {
      const intervalDays = schedule.customIntervalDays || 30;
      let start = new Date(now);
      start.setDate(start.getDate() + intervalDays);
      for (let i = 0; i < 8; i++) {
        intervals.push({ label: `Window ${i + 1}`, date: new Date(start) });
        start.setDate(start.getDate() + intervalDays);
      }
      break;
    }
  }

  const durationDays = schedule.windowDurationDays || 14;

  const existingWindows = await storage.getExitWindowsByAsset(schedule.assetId);
  const existingQuarters = new Set(existingWindows.map(w => w.quarter).filter(Boolean));
  const existingDates = new Set(existingWindows.map(w => new Date(w.opensAt).toDateString()));

  for (const interval of intervals) {
    if (interval.date < now) continue;

    if (interval.quarter && existingQuarters.has(interval.quarter)) continue;
    if (existingDates.has(interval.date.toDateString())) continue;

    const opensAt = interval.date;
    const closesAt = new Date(opensAt.getTime() + durationDays * 24 * 60 * 60 * 1000);

    let status = "scheduled";
    if (now >= opensAt && now < closesAt) status = "open";

    const ew = await storage.createExitWindow({
      assetId: schedule.assetId,
      name: `${assetName} - ${interval.label}`,
      opensAt: opensAt.toISOString(),
      closesAt: closesAt.toISOString(),
      status,
      exitFeePercent: schedule.exitFeePercent || "1.50",
      quarter: interval.quarter || null,
      eligibleJurisdictions: schedule.eligibleJurisdictions || [],
      lockupDays: schedule.lockupDays ?? 0,
      cooldownHours: schedule.cooldownHours ?? 0,
      maxParticipants: schedule.maxParticipants ?? null,
      minTradeAmount: schedule.minTradeAmount ?? null,
      maxTradeAmount: schedule.maxTradeAmount ?? null,
      createdBy: schedule.createdBy,
    });
    created.push(ew);
  }

  return created;
}

export async function syncExitWindowStatuses() {
  const now = new Date();
  const nowISO = now.toISOString();

  const scheduledToOpen = await db.select().from(exitWindows)
    .where(and(eq(exitWindows.status, "scheduled"), lte(exitWindows.opensAt, nowISO)));

  for (const ew of scheduledToOpen) {
    const closesAt = new Date(ew.closesAt);
    if (now < closesAt) {
      await storage.updateExitWindowStatus(ew.id, "open");
      console.log(`[ExitWindow] Opened: ${ew.name}`);
    } else {
      await storage.updateExitWindowStatus(ew.id, "closed");
      console.log(`[ExitWindow] Closed (past due): ${ew.name}`);
    }
  }

  const openToClose = await db.select().from(exitWindows)
    .where(and(eq(exitWindows.status, "open"), lte(exitWindows.closesAt, nowISO)));

  for (const ew of openToClose) {
    await storage.updateExitWindowStatus(ew.id, "closed");
    console.log(`[ExitWindow] Closed: ${ew.name}`);
  }

  return { opened: scheduledToOpen.filter(w => new Date(w.closesAt) > now).length, closed: openToClose.length + scheduledToOpen.filter(w => new Date(w.closesAt) <= now).length };
}

export function registerTradeRoutes(app: Express) {
  app.get("/api/exit-windows", requireAuth, async (_req, res) => {
    try {
      const windows = await storage.getExitWindows();
      res.json(windows);
    } catch (err: any) {
      console.error("Get exit windows error:", err);
      res.status(500).json({ message: "Failed to fetch exit windows" });
    }
  });

  app.get("/api/exit-windows/:id", requireAuth, async (req, res) => {
    try {
      const ew = await storage.getExitWindowById(req.params.id as string);
      if (!ew) return res.status(404).json({ message: "Exit window not found" });
      res.json(ew);
    } catch (err: any) {
      console.error("Get exit window error:", err);
      res.status(500).json({ message: "Failed to fetch exit window" });
    }
  });

  app.post("/api/admin/exit-windows", requireAuth, requireRole("admin"), validateBody(createExitWindowRequestSchema), async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const data = req.body;

      const asset = await storage.getAsset(data.assetId);
      if (!asset) return res.status(404).json({ message: "Asset not found" });

      const now = new Date();
      const opensAt = new Date(data.opensAt);
      const closesAt = new Date(data.closesAt);
      if (closesAt <= opensAt) return res.status(400).json({ message: "Close date must be after open date" });

      let status = "scheduled";
      if (now >= opensAt && now < closesAt) status = "open";
      if (now >= closesAt) status = "closed";

      const ew = await storage.createExitWindow({
        assetId: data.assetId,
        name: data.name || `Exit Window - ${data.assetId.slice(0, 8)}`,
        opensAt: data.opensAt,
        closesAt: data.closesAt,
        status,
        exitFeePercent: (data.exitFeePercent ?? 1.5).toFixed(2),
        quarter: data.quarter ?? null,
        eligibleJurisdictions: data.eligibleJurisdictions || [],
        lockupDays: data.lockupDays ?? 0,
        cooldownHours: data.cooldownHours ?? 0,
        maxParticipants: data.maxParticipants ?? null,
        minTradeAmount: data.minTradeAmount?.toFixed(6) ?? null,
        maxTradeAmount: data.maxTradeAmount?.toFixed(6) ?? null,
        createdBy: userId,
      });

      res.json(ew);
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Create exit window error:", err);
      res.status(500).json({ message: "Failed to create exit window" });
    }
  });

  app.patch("/api/admin/exit-windows/:id/rules", requireAuth, requireRole("admin"), validateBody(updateExitWindowRulesRequestSchema), async (req, res) => {
    try {
      const data = req.body;
      const ew = await storage.getExitWindowById(req.params.id as string);
      if (!ew) return res.status(404).json({ message: "Exit window not found" });

      const rules: any = {};
      if (data.eligibleJurisdictions !== undefined) rules.eligibleJurisdictions = data.eligibleJurisdictions;
      if (data.lockupDays !== undefined) rules.lockupDays = data.lockupDays;
      if (data.cooldownHours !== undefined) rules.cooldownHours = data.cooldownHours;
      if (data.maxParticipants !== undefined) rules.maxParticipants = data.maxParticipants;
      if (data.minTradeAmount !== undefined) rules.minTradeAmount = data.minTradeAmount.toFixed(6);
      if (data.maxTradeAmount !== undefined) rules.maxTradeAmount = data.maxTradeAmount.toFixed(6);

      const updated = await storage.updateExitWindowRules(req.params.id as string, rules);
      res.json(updated);
    } catch (err: any) {
      console.error("Update exit window rules error:", err);
      res.status(500).json({ message: "Failed to update exit window rules" });
    }
  });

  app.patch("/api/admin/exit-windows/:id/status", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const { status } = req.body;
      if (!["scheduled", "open", "closed", "cancelled"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      const updated = await storage.updateExitWindowStatus(req.params.id as string, status);
      if (!updated) return res.status(404).json({ message: "Exit window not found" });
      res.json(updated);
    } catch (err: any) {
      console.error("Update exit window status error:", err);
      res.status(500).json({ message: "Failed to update exit window" });
    }
  });

  const generateQuarterlySchema = z.object({
    assetId: z.string().min(1),
    year: z.coerce.number().int().min(2024).max(2040),
    exitFeePercent: z.coerce.number().min(0).max(100).optional().default(1.5),
    windowDurationDays: z.coerce.number().int().min(1).max(90).optional().default(14),
    eligibleJurisdictions: z.array(z.string()).optional(),
    lockupDays: z.coerce.number().int().min(0).optional().default(0),
    cooldownHours: z.coerce.number().int().min(0).optional().default(0),
  });

  app.post("/api/admin/exit-windows/generate-quarterly", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const parsed = generateQuarterlySchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Validation failed", errors: parsed.error.errors });
      }
      const { assetId, year: yearNum, exitFeePercent: feePercent, windowDurationDays: durationDays, eligibleJurisdictions, lockupDays, cooldownHours } = parsed.data;

      const asset = await storage.getAsset(assetId);
      if (!asset) return res.status(404).json({ message: "Asset not found" });

      const quarterDefs = [
        { q: "Q1", month: 2, label: "Q1 (Mar)" },
        { q: "Q2", month: 5, label: "Q2 (Jun)" },
        { q: "Q3", month: 8, label: "Q3 (Sep)" },
        { q: "Q4", month: 11, label: "Q4 (Dec)" },
      ];

      const created = [];
      for (const qd of quarterDefs) {
        const opensAt = new Date(yearNum, qd.month, 1);
        const closesAt = new Date(opensAt.getTime() + durationDays * 24 * 60 * 60 * 1000);

        const now = new Date();
        let status = "scheduled";
        if (now >= opensAt && now < closesAt) status = "open";
        if (now >= closesAt) status = "closed";

        const ew = await storage.createExitWindow({
          assetId,
          name: `${asset.name} - ${qd.label} ${yearNum}`,
          opensAt: opensAt.toISOString(),
          closesAt: closesAt.toISOString(),
          status,
          exitFeePercent: feePercent.toFixed(2),
          quarter: `${yearNum}-${qd.q}`,
          eligibleJurisdictions: eligibleJurisdictions || [],
          lockupDays: lockupDays ?? 0,
          cooldownHours: cooldownHours ?? 0,
          maxParticipants: null,
          minTradeAmount: null,
          maxTradeAmount: null,
          createdBy: userId,
        });
        created.push(ew);
      }

      res.json({ message: `Created ${created.length} quarterly exit windows for ${yearNum}`, windows: created });
    } catch (err: any) {
      console.error("Generate quarterly windows error:", err);
      res.status(500).json({ message: "Failed to generate quarterly windows" });
    }
  });

  app.get("/api/exit-window-schedules", requireAuth, async (_req, res) => {
    try {
      const schedules = await storage.getExitWindowSchedules();
      res.json(schedules);
    } catch (err: any) {
      console.error("Get schedules error:", err);
      res.status(500).json({ message: "Failed to fetch schedules" });
    }
  });

  app.get("/api/exit-window-schedules/:assetId", requireAuth, async (req, res) => {
    try {
      const schedules = await storage.getExitWindowSchedulesByAsset(req.params.assetId as string);
      res.json(schedules);
    } catch (err: any) {
      console.error("Get asset schedules error:", err);
      res.status(500).json({ message: "Failed to fetch schedules" });
    }
  });

  app.post("/api/admin/exit-window-schedules", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const parsed = createExitWindowScheduleSchema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ message: "Validation failed", errors: parsed.error.errors });

      const data = parsed.data;
      const asset = await storage.getAsset(data.assetId);
      if (!asset) return res.status(404).json({ message: "Asset not found" });

      const schedule = await storage.createExitWindowSchedule({
        assetId: data.assetId,
        frequency: data.frequency,
        windowDurationDays: data.windowDurationDays,
        exitFeePercent: data.exitFeePercent.toFixed(2),
        lockupDays: data.lockupDays ?? 0,
        cooldownHours: data.cooldownHours ?? 0,
        maxParticipants: data.maxParticipants ?? null,
        minTradeAmount: data.minTradeAmount?.toFixed(6) ?? null,
        maxTradeAmount: data.maxTradeAmount?.toFixed(6) ?? null,
        eligibleJurisdictions: data.eligibleJurisdictions || [],
        customIntervalDays: data.customIntervalDays ?? null,
        autoGenerate: data.autoGenerate ?? true,
        isActive: true,
        createdBy: userId,
      });

      if (data.autoGenerate) {
        const generated = await generateWindowsFromSchedule(schedule, asset.name);
        res.json({ schedule, generatedWindows: generated });
      } else {
        res.json({ schedule, generatedWindows: [] });
      }
    } catch (err: any) {
      console.error("Create schedule error:", err);
      res.status(500).json({ message: "Failed to create schedule" });
    }
  });

  app.patch("/api/admin/exit-window-schedules/:id", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const scheduleId = req.params.id as string;
      const existing = await storage.getExitWindowScheduleById(scheduleId);
      if (!existing) return res.status(404).json({ message: "Schedule not found" });

      const updates: any = {};
      if (req.body.isActive !== undefined) updates.isActive = req.body.isActive;
      if (req.body.frequency !== undefined) updates.frequency = req.body.frequency;
      if (req.body.windowDurationDays !== undefined) updates.windowDurationDays = req.body.windowDurationDays;
      if (req.body.exitFeePercent !== undefined) updates.exitFeePercent = parseFloat(req.body.exitFeePercent).toFixed(2);
      if (req.body.lockupDays !== undefined) updates.lockupDays = req.body.lockupDays;
      if (req.body.cooldownHours !== undefined) updates.cooldownHours = req.body.cooldownHours;
      if (req.body.maxParticipants !== undefined) updates.maxParticipants = req.body.maxParticipants;
      if (req.body.minTradeAmount !== undefined) updates.minTradeAmount = parseFloat(req.body.minTradeAmount).toFixed(6);
      if (req.body.maxTradeAmount !== undefined) updates.maxTradeAmount = parseFloat(req.body.maxTradeAmount).toFixed(6);
      if (req.body.customIntervalDays !== undefined) updates.customIntervalDays = req.body.customIntervalDays;

      const updated = await storage.updateExitWindowSchedule(scheduleId, updates);
      res.json(updated);
    } catch (err: any) {
      console.error("Update schedule error:", err);
      res.status(500).json({ message: "Failed to update schedule" });
    }
  });

  app.delete("/api/admin/exit-window-schedules/:id", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      await storage.deleteExitWindowSchedule(req.params.id as string);
      res.json({ message: "Schedule deleted" });
    } catch (err: any) {
      console.error("Delete schedule error:", err);
      res.status(500).json({ message: "Failed to delete schedule" });
    }
  });

  app.post("/api/admin/exit-window-schedules/:id/generate", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const schedule = await storage.getExitWindowScheduleById(req.params.id as string);
      if (!schedule) return res.status(404).json({ message: "Schedule not found" });

      const asset = await storage.getAsset(schedule.assetId);
      if (!asset) return res.status(404).json({ message: "Asset not found" });

      const generated = await generateWindowsFromSchedule(schedule, asset.name);
      res.json({ message: `Generated ${generated.length} exit windows`, windows: generated });
    } catch (err: any) {
      console.error("Generate from schedule error:", err);
      res.status(500).json({ message: "Failed to generate windows" });
    }
  });

  app.get("/api/exit-windows/:id/listings", requireAuth, async (req, res) => {
    try {
      const listings = await storage.getTradeListings(req.params.id as string);
      const enriched = await Promise.all(listings.map(async (l) => {
        const seller = await storage.getUser(l.sellerId);
        return { ...l, sellerName: seller?.fullName || "Unknown" };
      }));
      res.json(enriched);
    } catch (err: any) {
      console.error("Get listings error:", err);
      res.status(500).json({ message: "Failed to fetch listings" });
    }
  });

  app.post("/api/trade/list", requireAuth, paymentLimiter, validateBody(createTradeListingRequestSchema), async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const data = req.body;

      const tokenId = await resolveTokenForAsset(data.assetId);
      const priceNum = parseFloat(data.pricePerToken);
      const eligibility = await checkTradeEligibility({
        userId,
        exitWindowId: data.exitWindowId,
        assetId: data.assetId,
        side: "sell",
        quantity: data.quantity,
        pricePerToken: priceNum,
        tokenId: tokenId || undefined,
      });

      if (!eligibility.eligible) {
        const failedChecks = eligibility.checks.filter(c => !c.passed);
        const first = failedChecks[0];
        return res.status(403).json({
          message: first.reason || "Trade eligibility check failed",
          code: first.code || "ELIGIBILITY_FAILED",
          checks: failedChecks,
        });
      }

      const exitWindow = await storage.getExitWindowById(data.exitWindowId);
      if (!exitWindow) return res.status(404).json({ message: "Exit window not found" });

      const asset = await storage.getAsset(data.assetId);
      if (!asset) return res.status(404).json({ message: "Asset not found" });
      if (exitWindow.assetId !== data.assetId) return res.status(400).json({ message: "Asset does not match exit window" });

      const tokenDecimals = asset.tokenDecimals ?? 2;
      const multiplier = Math.pow(10, tokenDecimals);
      if (Math.round(data.quantity * multiplier) !== data.quantity * multiplier) {
        return res.status(400).json({
          message: `This asset allows up to ${tokenDecimals} decimal places for token quantities`,
          code: "INVALID_PRECISION",
        });
      }

      const portfolio = await storage.getPortfolioItem(userId, data.assetId);
      const portfolioQty = portfolio ? parseFloat(portfolio.quantity) : 0;

      let tokenBalance = portfolioQty;
      if (tokenId) {
        const holding = await storage.getTokenHolding(userId, tokenId);
        tokenBalance = holding ? parseFloat(holding.balance) : 0;
      }

      const effectiveBalance = tokenId ? tokenBalance : portfolioQty;
      if (effectiveBalance < data.quantity) {
        return res.status(400).json({
          message: `Insufficient tokens. You have ${effectiveBalance} tokens.`,
          code: "INSUFFICIENT_TOKENS",
        });
      }

      const listing = await storage.createTradeListing({
        exitWindowId: data.exitWindowId,
        assetId: data.assetId,
        sellerId: userId,
        quantity: data.quantity.toFixed(6),
        pricePerToken: data.pricePerToken.toFixed(6),
        currency: asset.baseCurrency,
        remainingQuantity: data.quantity.toFixed(6),
      });

      res.json(listing);
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Create listing error:", err);
      res.status(500).json({ message: "Failed to create listing" });
    }
  });

  app.delete("/api/trade/list/:id", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const listing = await storage.getTradeListingById(req.params.id as string);
      if (!listing) return res.status(404).json({ message: "Listing not found" });
      if (listing.sellerId !== userId) return res.status(403).json({ message: "Not your listing" });
      if (listing.status !== "active") return res.status(400).json({ message: "Listing is not active" });

      const updated = await storage.updateTradeListing(req.params.id as string, { status: "cancelled" });
      res.json(updated);
    } catch (err: any) {
      console.error("Cancel listing error:", err);
      res.status(500).json({ message: "Failed to cancel listing" });
    }
  });

  app.get("/api/trade/check/:listingId", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const listing = await storage.getTradeListingById(req.params.listingId as string);
      if (!listing) return res.status(404).json({ message: "Listing not found" });

      const asset = await storage.getAsset(listing.assetId);
      if (!asset) return res.status(404).json({ message: "Asset not found" });

      const baseCurrency = asset.baseCurrency;
      const walletAccount = await storage.getWalletAccountByUserAndCurrency(userId, baseCurrency);
      let availableBalance = "0";
      if (walletAccount) {
        const balance = await storage.getComputedBalance(walletAccount.id);
        availableBalance = balance.available;
      }

      const userAccounts = await storage.getWalletAccountsByUser(userId);
      const otherBalances: { currency: string; available: string }[] = [];
      for (const acc of userAccounts) {
        if (acc.currency !== baseCurrency) {
          const bal = await storage.getComputedBalance(acc.id);
          if (decimalCompare(bal.available, "0") > 0) {
            otherBalances.push({ currency: acc.currency, available: bal.available });
          }
        }
      }

      res.json({
        baseCurrency,
        availableBalance: parseFloat(availableBalance),
        hasWallet: !!walletAccount,
        pricePerToken: parseFloat(listing.pricePerToken),
        remainingQuantity: parseFloat(listing.remainingQuantity),
        otherBalances: otherBalances.map(b => ({ currency: b.currency, available: parseFloat(b.available) })),
      });
    } catch (err: any) {
      console.error("Trade check error:", err);
      res.status(500).json({ message: "Failed to check trade eligibility" });
    }
  });

  app.post("/api/trade/buy", requireAuth, paymentLimiter, validateBody(executeBuyRequestSchema), async (req, res) => {
    try {
      const buyerId = (req as any).user.userId;
      const data = req.body;

      const listing = await storage.getTradeListingById(data.listingId);
      if (!listing) return res.status(404).json({ message: "Listing not found" });
      if (listing.status !== "active") return res.status(400).json({ message: "Listing is no longer active" });
      if (listing.sellerId === buyerId) return res.status(400).json({ message: "Cannot buy your own listing" });

      const buyTokenId = await resolveTokenForAsset(listing.assetId);
      const buyEligibility = await checkTradeEligibility({
        userId: buyerId,
        exitWindowId: listing.exitWindowId,
        assetId: listing.assetId,
        side: "buy",
        quantity: data.quantity,
        pricePerToken: parseFloat(listing.pricePerToken),
        tokenId: buyTokenId || undefined,
        counterpartyId: listing.sellerId,
      });

      if (!buyEligibility.eligible) {
        const failedChecks = buyEligibility.checks.filter(c => !c.passed);
        const first = failedChecks[0];
        return res.status(403).json({
          message: first.reason || "Trade eligibility check failed",
          code: first.code || "ELIGIBILITY_FAILED",
          checks: failedChecks,
        });
      }

      const exitWindow = await storage.getExitWindowById(listing.exitWindowId);
      if (!exitWindow || exitWindow.status !== "open") {
        return res.status(400).json({ message: "Exit window is not open for trading" });
      }

      const remainingQty = parseFloat(listing.remainingQuantity);
      if (data.quantity > remainingQty) {
        return res.status(400).json({
          message: `Only ${remainingQty} tokens available. Requested ${data.quantity}.`,
          code: "EXCEEDS_AVAILABLE",
        });
      }

      const asset = await storage.getAsset(listing.assetId);
      if (!asset) return res.status(404).json({ message: "Asset not found" });

      const tokenDecimals = asset.tokenDecimals ?? 2;
      const multiplier = Math.pow(10, tokenDecimals);
      if (Math.round(data.quantity * multiplier) !== data.quantity * multiplier) {
        return res.status(400).json({
          message: `This asset allows up to ${tokenDecimals} decimal places for token quantities`,
          code: "INVALID_PRECISION",
        });
      }

      const tokenId = await resolveTokenForAsset(listing.assetId);

      if (tokenId) {
        const restrictionResult = await canTransfer(listing.sellerId, buyerId, tokenId, data.quantity);
        if (!restrictionResult.allowed) {
          return res.status(403).json({
            message: "Trade blocked by transfer restrictions",
            violations: restrictionResult.violations,
          });
        }

        const sellerHolding = await storage.getTokenHolding(listing.sellerId, tokenId);
        const sellerTokenBalance = sellerHolding ? parseFloat(sellerHolding.balance) : 0;
        if (sellerTokenBalance < data.quantity) {
          return res.status(400).json({
            message: `Seller has insufficient token balance. Available: ${sellerTokenBalance}`,
            code: "INSUFFICIENT_TOKEN_BALANCE",
          });
        }
      }

      const baseCurrency = asset.baseCurrency;
      const totalCost = decimalMul(listing.pricePerToken, data.quantity);
      const currencyDetail = CURRENCY_DETAILS[baseCurrency as keyof typeof CURRENCY_DETAILS];
      const currencySymbol = currencyDetail?.symbol || baseCurrency;

      const buyerWallet = await storage.getWalletAccountByUserAndCurrency(buyerId, baseCurrency);
      if (!buyerWallet) {
        const userAccounts = await storage.getWalletAccountsByUser(buyerId);
        const otherBalances: { currency: string; available: string }[] = [];
        for (const acc of userAccounts) {
          if (acc.currency !== baseCurrency) {
            const bal = await storage.getComputedBalance(acc.id);
            if (decimalCompare(bal.available, "0") > 0) {
              otherBalances.push({ currency: acc.currency, available: bal.available });
            }
          }
        }
        return res.status(400).json({
          message: `You need a ${baseCurrency} wallet to buy this asset. Convert funds from another currency first.`,
          code: "NO_WALLET",
          baseCurrency,
          requiredAmount: totalCost,
          otherBalances,
        });
      }

      const buyerBalance = await storage.getComputedBalance(buyerWallet.id);
      if (decimalCompare(buyerBalance.available, totalCost) < 0) {
        const userAccounts = await storage.getWalletAccountsByUser(buyerId);
        const otherBalances: { currency: string; available: string }[] = [];
        for (const acc of userAccounts) {
          if (acc.currency !== baseCurrency) {
            const bal = await storage.getComputedBalance(acc.id);
            if (decimalCompare(bal.available, "0") > 0) {
              otherBalances.push({ currency: acc.currency, available: bal.available });
            }
          }
        }
        return res.status(400).json({
          message: `Insufficient ${baseCurrency} balance. You need ${currencySymbol} ${totalCost} but have ${currencySymbol} ${buyerBalance.available}. Convert funds from another currency first.`,
          code: "INSUFFICIENT_BALANCE",
          baseCurrency,
          requiredAmount: totalCost,
          availableAmount: buyerBalance.available,
          shortfall: (parseFloat(totalCost) - parseFloat(buyerBalance.available)).toFixed(2),
          otherBalances,
        });
      }

      const sellerWallet = await storage.getOrCreateWallet(listing.sellerId, baseCurrency);
      const refId = `TRD-${Date.now().toString(36).toUpperCase()}`;

      const exitFeePercent = exitWindow.exitFeePercent ? parseFloat(exitWindow.exitFeePercent) : 1.5;
      const exitFeeAmount = (parseFloat(totalCost) * exitFeePercent / 100).toFixed(2);
      const sellerProceeds = (parseFloat(totalCost) - parseFloat(exitFeeAmount)).toFixed(2);

      const result = await db.transaction(async (tx) => {
        await tx.insert(walletTransactions).values({
          walletAccountId: buyerWallet.id,
          type: "TRADE_BUY",
          amount: totalCost,
          currency: baseCurrency,
          status: "COMPLETED",
          referenceId: refId,
          description: `Bought ${data.quantity} ${asset.symbol} tokens at ${currencySymbol} ${parseFloat(listing.pricePerToken).toFixed(2)}/token`,
          metadata: { assetId: asset.id, assetSymbol: asset.symbol, tokens: data.quantity, pricePerToken: listing.pricePerToken, sellerId: listing.sellerId },
        });

        await tx.insert(walletTransactions).values({
          walletAccountId: sellerWallet.id,
          type: "TRADE_SELL",
          amount: sellerProceeds,
          currency: baseCurrency,
          status: "COMPLETED",
          referenceId: refId,
          description: `Sold ${data.quantity} ${asset.symbol} tokens at ${currencySymbol} ${parseFloat(listing.pricePerToken).toFixed(2)}/token (exit fee: ${exitFeePercent}% = ${currencySymbol} ${exitFeeAmount})`,
          metadata: { assetId: asset.id, assetSymbol: asset.symbol, tokens: data.quantity, pricePerToken: listing.pricePerToken, buyerId, exitFeePercent, exitFeeAmount },
        });

        if (parseFloat(exitFeeAmount) > 0) {
          await tx.insert(walletTransactions).values({
            walletAccountId: sellerWallet.id,
            type: "EXIT_FEE",
            amount: exitFeeAmount,
            currency: baseCurrency,
            status: "COMPLETED",
            referenceId: refId,
            description: `Exit fee ${exitFeePercent}% on sale of ${data.quantity} ${asset.symbol} tokens`,
            metadata: { assetId: asset.id, exitWindowId: exitWindow.id, feePercent: exitFeePercent, tradeAmount: totalCost },
          });
        }

        const [sellerPortfolio] = await tx.select().from(portfolioItems)
          .where(and(eq(portfolioItems.userId, listing.sellerId), eq(portfolioItems.assetId, asset.id)));

        if (sellerPortfolio) {
          const newQty = Math.max(0, parseFloat(sellerPortfolio.quantity) - data.quantity);
          await tx.update(portfolioItems)
            .set({ quantity: newQty.toFixed(6) })
            .where(eq(portfolioItems.id, sellerPortfolio.id));
        }

        const [buyerPortfolio] = await tx.select().from(portfolioItems)
          .where(and(eq(portfolioItems.userId, buyerId), eq(portfolioItems.assetId, asset.id)));

        if (buyerPortfolio) {
          const oldQty = parseFloat(buyerPortfolio.quantity);
          const oldCost = parseFloat(buyerPortfolio.averageCost);
          const newQty = data.quantity;
          const newCost = parseFloat(listing.pricePerToken);
          const totalQty = oldQty + newQty;
          const weightedAvgCost = totalQty > 0 ? ((oldQty * oldCost + newQty * newCost) / totalQty) : newCost;
          await tx.update(portfolioItems)
            .set({
              quantity: totalQty.toFixed(6),
              averageCost: weightedAvgCost.toFixed(6),
            })
            .where(eq(portfolioItems.id, buyerPortfolio.id));
        } else {
          await tx.insert(portfolioItems).values({
            userId: buyerId,
            assetId: asset.id,
            quantity: data.quantity.toFixed(6),
            averageCost: listing.pricePerToken,
          });
        }

        if (tokenId) {
          const [sellerTokenHolding] = await tx.select().from(tokenHoldings)
            .where(and(eq(tokenHoldings.userId, listing.sellerId), eq(tokenHoldings.tokenId, tokenId)));

          if (sellerTokenHolding) {
            const newBalance = Math.max(0, parseFloat(sellerTokenHolding.balance) - data.quantity);
            await tx.update(tokenHoldings)
              .set({ balance: newBalance.toFixed(6), updatedAt: new Date() })
              .where(eq(tokenHoldings.id, sellerTokenHolding.id));
          }

          const [buyerTokenHolding] = await tx.select().from(tokenHoldings)
            .where(and(eq(tokenHoldings.userId, buyerId), eq(tokenHoldings.tokenId, tokenId)));

          if (buyerTokenHolding) {
            const newBalance = parseFloat(buyerTokenHolding.balance) + data.quantity;
            await tx.update(tokenHoldings)
              .set({ balance: newBalance.toFixed(6), updatedAt: new Date() })
              .where(eq(tokenHoldings.id, buyerTokenHolding.id));
          } else {
            await tx.insert(tokenHoldings).values({
              userId: buyerId,
              tokenId,
              balance: data.quantity.toFixed(6),
            });
          }

          await tx.insert(tokenTransfers).values({
            fromUserId: listing.sellerId,
            toUserId: buyerId,
            tokenId,
            amount: data.quantity.toFixed(6),
            status: "completed",
            reason: `Secondary market trade — listing ${listing.id} at ${currencySymbol} ${parseFloat(listing.pricePerToken).toFixed(2)}/token`,
          });

          await tx.insert(tokenLedgerEntries).values({
            tokenId,
            fromUserId: listing.sellerId,
            toUserId: buyerId,
            amount: data.quantity.toFixed(6),
            reason: "trade",
            refId: refId,
          });

          const onChain = getOnChainProvider();
          if (onChain.enabled) {
            await onChain.transfer({
              tokenSymbol: asset.symbol,
              fromAddress: listing.sellerId,
              toAddress: buyerId,
              amount: data.quantity.toFixed(6),
              tokenId,
              metadata: { listingId: listing.id, tradeType: "secondary" },
            });
          }
        }

        const newRemaining = remainingQty - data.quantity;
        const listingUpdate: any = { remainingQuantity: newRemaining.toFixed(6) };
        if (newRemaining <= 0) {
          listingUpdate.status = "filled";
          listingUpdate.buyerId = buyerId;
          listingUpdate.filledAt = new Date().toISOString();
        }
        await tx.update(tradeListings)
          .set(listingUpdate)
          .where(eq(tradeListings.id, listing.id));

        await tx.insert(transactions).values({
          userId: buyerId,
          assetId: asset.id,
          type: "trade_buy",
          amount: totalCost,
          status: "completed",
          description: `Bought ${data.quantity} tokens of ${asset.name} at ${currencySymbol} ${parseFloat(listing.pricePerToken).toFixed(2)}/token (secondary market)`,
        });

        await tx.insert(transactions).values({
          userId: listing.sellerId,
          assetId: asset.id,
          type: "trade_sell",
          amount: totalCost,
          status: "completed",
          description: `Sold ${data.quantity} tokens of ${asset.name} at ${currencySymbol} ${parseFloat(listing.pricePerToken).toFixed(2)}/token (secondary market)`,
        });

        return { newRemaining, tokenId };
      });

      await logAuditFromReq(req, "TRADE_BUY", "trade_listing", listing.id, {
        reason: `Bought ${data.quantity} tokens of ${asset.name} for ${currencySymbol} ${totalCost} in ${baseCurrency} (exit fee: ${exitFeePercent}% = ${currencySymbol} ${exitFeeAmount})`,
        metadata: { quantity: data.quantity, assetName: asset.name, totalCost, currency: baseCurrency, exitFeePercent, exitFeeAmount, sellerProceeds },
      });

      res.json({
        success: true,
        trade: {
          listingId: listing.id,
          assetId: asset.id,
          assetName: asset.name,
          assetSymbol: asset.symbol,
          quantity: data.quantity,
          pricePerToken: parseFloat(listing.pricePerToken),
          totalCost: parseFloat(totalCost),
          exitFeePercent,
          exitFeeAmount: parseFloat(exitFeeAmount),
          sellerProceeds: parseFloat(sellerProceeds),
          currency: baseCurrency,
          referenceId: refId,
          remainingInListing: result.newRemaining,
          tokenLedgerUpdated: !!result.tokenId,
        },
      });
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: "Validation failed", errors: err.errors });
      console.error("Trade buy error:", err);
      res.status(500).json({ message: "Failed to process trade" });
    }
  });

  app.get("/api/trade/my-listings", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const listings = await storage.getTradeListingsBySeller(userId);
      res.json(listings);
    } catch (err: any) {
      console.error("Get my listings error:", err);
      res.status(500).json({ message: "Failed to fetch your listings" });
    }
  });

  app.get("/api/trade/eligibility", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const { exitWindowId, assetId, side, quantity, pricePerToken } = req.query;

      if (!exitWindowId || !assetId) {
        return res.status(400).json({ message: "exitWindowId and assetId are required" });
      }

      const tokenId = await resolveTokenForAsset(assetId as string);

      const result = await checkTradeEligibility({
        userId,
        exitWindowId: exitWindowId as string,
        assetId: assetId as string,
        side: (side as "sell" | "buy") || "buy",
        quantity: quantity ? parseFloat(quantity as string) : undefined,
        pricePerToken: pricePerToken ? parseFloat(pricePerToken as string) : undefined,
        tokenId: tokenId || undefined,
      });

      res.json(result);
    } catch (err: any) {
      console.error("Trade eligibility check error:", err);
      res.status(500).json({ message: "Failed to check trade eligibility" });
    }
  });

  app.get("/api/exit-windows/:id/rules", requireAuth, async (req, res) => {
    try {
      const ew = await storage.getExitWindowById(req.params.id as string);
      if (!ew) return res.status(404).json({ message: "Exit window not found" });

      const traderCount = await storage.getUniqueTraderCount(ew.id);

      res.json({
        exitWindowId: ew.id,
        assetId: ew.assetId,
        status: ew.status,
        opensAt: ew.opensAt,
        closesAt: ew.closesAt,
        eligibleJurisdictions: ew.eligibleJurisdictions || [],
        lockupDays: ew.lockupDays || 0,
        cooldownHours: ew.cooldownHours || 0,
        maxParticipants: ew.maxParticipants,
        minTradeAmount: ew.minTradeAmount,
        maxTradeAmount: ew.maxTradeAmount,
        currentTraderCount: traderCount,
      });
    } catch (err: any) {
      console.error("Get exit window rules error:", err);
      res.status(500).json({ message: "Failed to fetch exit window rules" });
    }
  });
}
