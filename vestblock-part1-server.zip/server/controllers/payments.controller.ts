import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { logAuditFromReq } from "../lib/audit-logger";
import { createPaymentIntentSchema, type PaymentIntentStatus } from "@shared/schema";
import { calculateFee } from "../fees";
import { applyFee } from "../services/fee-engine.service";
import { getPaymentProvider } from "../payment-provider";
import { z } from "zod";
import { getAllowedFundingRails, getPolicy, getPaymentRails, isLargeDeposit } from "@shared/compliance-policy";
import { getPakistanPaymentInstructions } from "../services/payments/providers/pakistan";
import { NotificationTemplates } from "../services/notification-templates";
import { isStripeConfigured } from "../services/payments/providers/stripe";
import {
  achProvider,
  type AchBankDetails,
  type AchIntentStatus,
  ACH_RETURN_CODES,
} from "../services/payments/providers/ach";
import Stripe from "stripe";
import { createPaymentIntentRequestSchema } from "@shared/dto/payments.dto";
import { paymentLimiter, webhookLimiter } from "../middleware/rate-limit";
import { validateBody } from "../middleware/validate";

export function registerPaymentsRoutes(app: Express) {
  app.get("/api/payment-providers/instructions/:provider", requireAuth, async (req, res) => {
    try {
      const providerName = String(String(req.params.provider));

      if (providerName === "ach") {
        return res.json({
          title: "ACH Bank Transfer (USA)",
          steps: [
            "Provide your US bank account details (routing number and account number)",
            "Two micro-deposits (under $0.10 each) will be sent to verify your account",
            "Verify the micro-deposit amounts within 3 business days",
            "Once verified, VestBlock will initiate the ACH debit from your account",
            "Funds typically settle in 2-3 business days after initiation",
            "Your wallet will be credited once the transfer clears",
          ],
          details: {
            provider: "ACH (Automated Clearing House)",
            network: "NACHA / Federal Reserve",
            transferType: "ACH Debit",
            processingTime: "2-3 business days",
            cutoffTime: "4:00 PM ET (same-day ACH) / 8:00 PM ET (next-day)",
            note: "ACH transfers are subject to NACHA rules. Returns may occur within 2 business days for unauthorized debits or up to 60 days for consumer accounts.",
          },
        });
      }

      const instructions = getPakistanPaymentInstructions(providerName);
      if (!instructions) {
        return res.status(404).json({ message: "No instructions found for this provider" });
      }
      res.json(instructions);
    } catch (err: any) {
      res.status(500).json({ message: "Failed to fetch instructions" });
    }
  });

  app.get("/api/payment-providers/stripe/status", requireAuth, async (_req, res) => {
    res.json({ configured: isStripeConfigured() });
  });

  app.post("/api/payment-intents", requireAuth, paymentLimiter, validateBody(createPaymentIntentRequestSchema), async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const data = req.body;

      const countryProfiles = await storage.getCountryProfiles(userId);
      const primary = countryProfiles.find(p => p.isPrimary) || countryProfiles[0];
      const userCountry = primary?.countryCode || "AE";

      const allowedRails = getAllowedFundingRails(userCountry);
      if (!allowedRails.includes(data.paymentMethod)) {
        const policy = getPolicy(userCountry);
        return res.status(403).json({
          message: `Payment method "${data.paymentMethod}" is not available in ${policy.countryName}. Allowed methods: ${allowedRails.join(", ")}`,
        });
      }

      const rails = getPaymentRails(userCountry);
      let providerName = "manual";
      if (data.provider) {
        const matchingRail = rails.find(r => r.provider === data.provider && r.status === "active");
        if (matchingRail) {
          providerName = data.provider;
        } else {
          return res.status(403).json({
            message: `Payment provider "${data.provider}" is not available for your region. Available providers: ${rails.filter(r => r.status === "active").map(r => r.provider).join(", ") || "manual"}`,
          });
        }
      } else {
        const matchingRail = rails.find(r => r.method === data.paymentMethod && r.status === "active");
        providerName = matchingRail?.provider || "manual";
      }

      if (isLargeDeposit(userCountry, data.amount)) {
        const policy = getPolicy(userCountry);
        console.log(`[compliance] Large deposit flagged for user ${userId} in ${userCountry}: ${data.currency} ${data.amount} (threshold: ${policy.riskThresholds.largeDepositAmount})`);
      }

      let walletAccount = await storage.getWalletAccountByUserAndCurrency(userId, data.currency);
      if (!walletAccount) {
        walletAccount = await storage.createWalletAccount({ userId, currency: data.currency });
      }

      const { calculation: feeResult } = await applyFee({
        feeType: "investment",
        amount: data.amount,
        currency: data.currency,
        userId,
        referenceEntityType: "payment_intent",
        description: `Investment deposit fee`,
      });

      let bankAccountConfigId: string | undefined;
      if (data.paymentMethod === "bank_transfer" && providerName === "manual") {
        const receivingBank = await storage.getReceivingBankAccountByCountryAndCurrency(userCountry, data.currency)
          || await storage.getReceivingBankAccountByCurrency(data.currency);
        if (receivingBank) {
          bankAccountConfigId = receivingBank.id;
        }
      }

      const intent = await storage.createPaymentIntent({
        userId,
        walletAccountId: walletAccount.id,
        amount: data.amount.toString(),
        currency: data.currency,
        countryCode: userCountry,
        paymentMethod: data.paymentMethod,
        provider: providerName,
        fee: feeResult.fee.toString(),
        netAmount: feeResult.netAmount.toString(),
        reference: data.reference || null,
        metadata: data.metadata || null,
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
        bankAccountConfigId: bankAccountConfigId || null,
      });

      const provider = getPaymentProvider(providerName);
      const result = await provider.createIntent(intent);

      const updated = await storage.updatePaymentIntentStatus(intent.id, result.status, {
        providerIntentId: result.providerIntentId,
        providerSessionUrl: result.sessionUrl,
        providerResponse: result.providerResponse,
      });

      await logAuditFromReq(req, "PAYMENT_INTENT_CREATED", "payment_intent", intent.id, {
        reason: `Payment intent created: ${data.currency} ${data.amount} via ${data.paymentMethod} (${providerName})`,
        metadata: { currency: data.currency, amount: data.amount, paymentMethod: data.paymentMethod, provider: providerName },
      });

      res.status(201).json(updated);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("Create payment intent error:", err);
      res.status(500).json({ message: "Failed to create payment intent" });
    }
  });

  app.get("/api/payment-intents", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const intents = await storage.getPaymentIntentsByUser(userId);
      res.json(intents);
    } catch (err: any) {
      console.error("Get payment intents error:", err);
      res.status(500).json({ message: "Failed to fetch payment intents" });
    }
  });

  app.get("/api/payment-intents/:id", requireAuth, async (req, res) => {
    try {
      const jwtUser = (req as any).user;
      const intent = await storage.getPaymentIntent(String(String(req.params.id)));
      if (!intent) return res.status(404).json({ message: "Payment intent not found" });
      if (intent.userId !== jwtUser.userId && jwtUser.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      res.json(intent);
    } catch (err: any) {
      console.error("Get payment intent error:", err);
      res.status(500).json({ message: "Failed to fetch payment intent" });
    }
  });

  const proofUploadSchema = z.object({
    proofDocumentUrl: z.string().refine(val => val.startsWith("/objects/"), { message: "Invalid proof document path" }),
  });

  app.patch("/api/payment-intents/:id/proof", requireAuth, async (req, res) => {
    try {
      const jwtUser = (req as any).user;
      const intent = await storage.getPaymentIntent(String(String(req.params.id)));
      if (!intent) return res.status(404).json({ message: "Payment intent not found" });
      if (intent.userId !== jwtUser.userId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      if (intent.status !== "CREATED" && intent.status !== "PENDING") {
        return res.status(400).json({ message: "Cannot upload proof for this payment intent" });
      }
      const parsed = proofUploadSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: parsed.error.issues[0]?.message || "Invalid payload" });
      }
      const updated = await storage.updatePaymentIntentStatus(intent.id, "PENDING" as PaymentIntentStatus, { proofDocumentUrl: parsed.data.proofDocumentUrl });
      res.json(updated);
    } catch (err: any) {
      console.error("Upload proof error:", err);
      res.status(500).json({ message: "Failed to upload proof" });
    }
  });

  app.get("/api/admin/payment-intents", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const intents = await storage.getAllPaymentIntents(req.tenantId);
      const users = await storage.getUsers(req.tenantId);
      const userMap = new Map(users.map(u => [u.id, u]));
      const enriched = intents.map(i => ({
        ...i,
        user: userMap.get(i.userId) ? { fullName: userMap.get(i.userId)!.fullName, username: userMap.get(i.userId)!.username, email: userMap.get(i.userId)!.email } : null,
      }));
      res.json(enriched);
    } catch (err: any) {
      console.error("Admin get payment intents error:", err);
      res.status(500).json({ message: "Failed to fetch payment intents" });
    }
  });

  app.post("/api/admin/payment-intents/:id/confirm", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const adminId = (req as any).user.userId;
      const intent = await storage.getPaymentIntent(String(String(req.params.id)));
      if (!intent) return res.status(404).json({ message: "Payment intent not found" });
      if (intent.status !== "CREATED" && intent.status !== "PENDING") {
        return res.status(400).json({ message: `Cannot confirm intent with status ${intent.status}` });
      }

      const { reconciliationId, notes } = req.body || {};
      const provider = getPaymentProvider(intent.provider);
      const result = await provider.confirmIntent(intent, { confirmedBy: adminId, reconciliationId, notes });

      let walletAccount = intent.walletAccountId
        ? await storage.getWalletAccount(intent.walletAccountId)
        : null;

      if (!walletAccount) {
        walletAccount = await storage.getWalletAccountByUserAndCurrency(intent.userId, intent.currency);
        if (!walletAccount) {
          walletAccount = await storage.createWalletAccount({ userId: intent.userId, currency: intent.currency });
        }
      }

      const ledgerTxId = `ltx_pi_${intent.id.slice(0, 12)}_${Date.now()}`;
      const ledgerEntriesToPost: Array<{
        ledgerTxId: string;
        walletAccountId: string;
        currency: string;
        amount: string;
        direction: "DEBIT" | "CREDIT";
        status: "POSTED";
        entryType: string;
        description: string;
      }> = [
        {
          ledgerTxId,
          walletAccountId: walletAccount.id,
          currency: intent.currency,
          amount: parseFloat(intent.netAmount).toFixed(6),
          direction: "CREDIT",
          status: "POSTED",
          entryType: "DEPOSIT",
          description: `Funds deposit via ${intent.paymentMethod} (PI-${intent.id.slice(0, 8).toUpperCase()})`,
        },
      ];

      if (parseFloat(intent.fee) > 0) {
        ledgerEntriesToPost.push({
          ledgerTxId,
          walletAccountId: walletAccount.id,
          currency: intent.currency,
          amount: parseFloat(intent.fee).toFixed(6),
          direction: "DEBIT",
          status: "POSTED",
          entryType: "FEE",
          description: `Deposit fee for PI-${intent.id.slice(0, 8).toUpperCase()}`,
        });
      }

      await storage.createLedgerEntries(ledgerEntriesToPost);

      const providerReceipt = {
        ...result.providerResponse,
        confirmedBy: adminId,
        confirmMethod: "admin_manual_reconciliation",
        reconciliationId: reconciliationId || null,
        notes: notes || null,
        bankAccountConfigId: intent.bankAccountConfigId || null,
        proofDocumentUrl: intent.proofDocumentUrl || null,
        ledgerTxId,
        timestamp: new Date().toISOString(),
      };

      const updated = await storage.updatePaymentIntentStatus(intent.id, "CONFIRMED", {
        providerResponse: providerReceipt,
        reconciliationId: reconciliationId || null,
        reconciledAt: new Date().toISOString(),
        reconciledBy: adminId,
        confirmedAt: new Date().toISOString(),
        ledgerTxId,
      });

      await storage.createWalletTransaction({
        walletAccountId: walletAccount.id,
        type: "DEPOSIT",
        amount: intent.netAmount,
        currency: intent.currency,
        status: "COMPLETED",
        referenceId: intent.id,
        description: `Funds deposit via ${intent.paymentMethod} (PI-${intent.id.slice(0, 8).toUpperCase()})`,
        metadata: { paymentIntentId: intent.id, reconciliationId, ledgerTxId },
      });

      if (parseFloat(intent.fee) > 0) {
        await storage.createWalletTransaction({
          walletAccountId: walletAccount.id,
          type: "FEE",
          amount: `-${intent.fee}`,
          currency: intent.currency,
          status: "COMPLETED",
          referenceId: intent.id,
          description: `Deposit fee for PI-${intent.id.slice(0, 8).toUpperCase()}`,
          metadata: { paymentIntentId: intent.id, ledgerTxId },
        });
      }

      await logAuditFromReq(req, "PAYMENT_INTENT_CONFIRMED", "payment_intent", intent.id, {
        reason: `Payment intent confirmed: ${intent.currency} ${intent.amount}, net ${intent.netAmount}. Reconciliation: ${reconciliationId || "N/A"}. LedgerTx: ${ledgerTxId}`,
        beforeState: { status: intent.status },
        afterState: { status: "CONFIRMED" },
        metadata: { ledgerTxId, reconciliationId },
      });

      const depNotif = NotificationTemplates.deposit.confirmed(intent.currency, intent.netAmount);
      await storage.createNotification({ userId: intent.userId, ...depNotif, relatedEntityId: intent.id, relatedEntityType: "payment_intent" });

      res.json(updated);
    } catch (err: any) {
      console.error("Confirm payment intent error:", err);
      res.status(500).json({ message: "Failed to confirm payment intent" });
    }
  });

  app.post("/api/admin/payment-intents/:id/fail", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const adminId = (req as any).user.userId;
      const intent = await storage.getPaymentIntent(String(String(req.params.id)));
      if (!intent) return res.status(404).json({ message: "Payment intent not found" });
      if (intent.status === "CONFIRMED" || intent.status === "REVERSED") {
        return res.status(400).json({ message: `Cannot fail intent with status ${intent.status}` });
      }

      const { reason } = req.body || {};
      const updated = await storage.updatePaymentIntentStatus(intent.id, "FAILED", {
        failureReason: reason || "Rejected by admin",
      });

      await logAuditFromReq(req, "PAYMENT_INTENT_FAILED", "payment_intent", intent.id, {
        reason: `Payment intent failed: ${reason || "Rejected by admin"}`,
        beforeState: { status: intent.status },
        afterState: { status: "FAILED" },
      });

      const failNotif = NotificationTemplates.deposit.failed(intent.currency, intent.amount, reason);
      await storage.createNotification({ userId: intent.userId, ...failNotif, relatedEntityId: intent.id, relatedEntityType: "payment_intent" });

      res.json(updated);
    } catch (err: any) {
      console.error("Fail payment intent error:", err);
      res.status(500).json({ message: "Failed to update payment intent" });
    }
  });

  app.post("/api/admin/payment-intents/:id/reverse", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const adminId = (req as any).user.userId;
      const intent = await storage.getPaymentIntent(String(String(req.params.id)));
      if (!intent) return res.status(404).json({ message: "Payment intent not found" });
      if (intent.status !== "CONFIRMED") {
        return res.status(400).json({ message: `Can only reverse CONFIRMED intents, current status: ${intent.status}` });
      }

      const { reason } = req.body || {};
      const provider = getPaymentProvider(intent.provider);
      const providerResult = await provider.reverse(intent, reason);

      if (providerResult.status === "FAILED") {
        return res.status(400).json({
          message: `Provider reversal failed: ${providerResult.failureReason || "Unknown error"}`,
        });
      }

      let reversalLedgerTxId: string | null = null;

      if (intent.ledgerTxId) {
        const reversals = await storage.reverseLedgerEntries(intent.ledgerTxId, reason || "Payment reversal by admin");
        if (reversals.length > 0) {
          reversalLedgerTxId = reversals[0].ledgerTxId;
        }
      }

      let walletAccount = intent.walletAccountId
        ? await storage.getWalletAccount(intent.walletAccountId)
        : null;

      if (!walletAccount) {
        walletAccount = await storage.getWalletAccountByUserAndCurrency(intent.userId, intent.currency);
      }

      if (walletAccount) {
        await storage.createWalletTransaction({
          walletAccountId: walletAccount.id,
          type: "REFUND",
          amount: `-${intent.netAmount}`,
          currency: intent.currency,
          status: "COMPLETED",
          referenceId: intent.id,
          description: `Payment reversal (PI-${intent.id.slice(0, 8).toUpperCase()}): ${reason || "Admin reversal"}`,
          metadata: { paymentIntentId: intent.id, reversalLedgerTxId },
        });

        if (parseFloat(intent.fee) > 0) {
          await storage.createWalletTransaction({
            walletAccountId: walletAccount.id,
            type: "REFUND",
            amount: intent.fee,
            currency: intent.currency,
            status: "COMPLETED",
            referenceId: intent.id,
            description: `Fee reversal for PI-${intent.id.slice(0, 8).toUpperCase()}`,
            metadata: { paymentIntentId: intent.id, reversalLedgerTxId },
          });
        }
      }

      const updated = await storage.updatePaymentIntentStatus(intent.id, "REVERSED", {
        providerResponse: providerResult.providerResponse,
        reversalLedgerTxId,
        reversedAt: new Date().toISOString(),
        reversalReason: reason || "Reversed by admin",
      });

      await logAuditFromReq(req, "PAYMENT_INTENT_REVERSED", "payment_intent", intent.id, {
        reason: `Payment reversed: ${intent.currency} ${intent.amount}. Reason: ${reason || "Admin reversal"}. ReversalLedgerTx: ${reversalLedgerTxId || "N/A"}`,
        beforeState: { status: intent.status },
        afterState: { status: "REVERSED" },
        metadata: { reversalLedgerTxId },
      });

      const revNotif = NotificationTemplates.deposit.failed(intent.currency, intent.amount, reason || "Payment reversed");
      await storage.createNotification({ userId: intent.userId, ...revNotif, relatedEntityId: intent.id, relatedEntityType: "payment_intent" });

      res.json(updated);
    } catch (err: any) {
      console.error("Reverse payment intent error:", err);
      res.status(500).json({ message: "Failed to reverse payment intent" });
    }
  });

  app.post("/api/webhooks/stripe", webhookLimiter, async (req, res) => {
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
    const stripeKey = process.env.STRIPE_SECRET_KEY;
    if (!webhookSecret || !stripeKey) {
      console.warn("[stripe-webhook] Missing STRIPE_WEBHOOK_SECRET or STRIPE_SECRET_KEY");
      return res.status(400).json({ message: "Webhook not configured" });
    }

    const sig = req.headers["stripe-signature"] as string;
    if (!sig) {
      return res.status(400).json({ message: "Missing stripe-signature header" });
    }

    let event: Stripe.Event;
    try {
      const stripe = new Stripe(stripeKey, { apiVersion: "2025-01-27.acacia" as any });
      event = stripe.webhooks.constructEvent(req.rawBody as Buffer, sig, webhookSecret);
    } catch (err: any) {
      console.error("[stripe-webhook] Signature verification failed:", err.message);
      return res.status(400).json({ message: "Webhook signature verification failed" });
    }

    console.log(`[stripe-webhook] Received event: ${event.type}`);

    if (event.type === "checkout.session.completed") {
      const session = event.data.object as Stripe.Checkout.Session;
      const paymentIntentId = session.metadata?.paymentIntentId;

      if (!paymentIntentId) {
        console.warn("[stripe-webhook] No paymentIntentId in session metadata");
        return res.json({ received: true });
      }

      try {
        const intent = await storage.getPaymentIntent(paymentIntentId);
        if (!intent) {
          console.warn(`[stripe-webhook] PaymentIntent not found: ${paymentIntentId}`);
          return res.json({ received: true });
        }

        if (intent.status === "CONFIRMED") {
          console.log(`[stripe-webhook] Intent ${paymentIntentId} already confirmed`);
          return res.json({ received: true });
        }

        const provider = getPaymentProvider("stripe");
        const result = await provider.confirmIntent(intent, {
          stripeSessionId: session.id,
          stripePaymentIntent: session.payment_intent,
          paymentStatus: session.payment_status,
        });

        let walletAccount = intent.walletAccountId
          ? await storage.getWalletAccount(intent.walletAccountId)
          : null;

        if (!walletAccount) {
          walletAccount = await storage.getWalletAccountByUserAndCurrency(intent.userId, intent.currency);
          if (!walletAccount) {
            walletAccount = await storage.createWalletAccount({ userId: intent.userId, currency: intent.currency });
          }
        }

        const ledgerTxId = `ltx_pi_${intent.id.slice(0, 12)}_${Date.now()}`;
        const ledgerEntriesToPost: Array<{
          ledgerTxId: string; walletAccountId: string; currency: string; amount: string;
          direction: "DEBIT" | "CREDIT"; status: "POSTED"; entryType: string; description: string;
        }> = [
          {
            ledgerTxId,
            walletAccountId: walletAccount.id,
            currency: intent.currency,
            amount: parseFloat(intent.netAmount).toFixed(6),
            direction: "CREDIT",
            status: "POSTED",
            entryType: "DEPOSIT",
            description: `Stripe card deposit (PI-${intent.id.slice(0, 8).toUpperCase()})`,
          },
        ];

        if (parseFloat(intent.fee) > 0) {
          ledgerEntriesToPost.push({
            ledgerTxId,
            walletAccountId: walletAccount.id,
            currency: intent.currency,
            amount: parseFloat(intent.fee).toFixed(6),
            direction: "DEBIT",
            status: "POSTED",
            entryType: "FEE",
            description: `Deposit fee for PI-${intent.id.slice(0, 8).toUpperCase()}`,
          });
        }

        await storage.createLedgerEntries(ledgerEntriesToPost);

        await storage.updatePaymentIntentStatus(intent.id, "CONFIRMED", {
          providerResponse: result.providerResponse,
          reconciliationId: `stripe_${session.payment_intent || session.id}`,
          reconciledAt: new Date().toISOString(),
          confirmedAt: new Date().toISOString(),
          ledgerTxId,
        });

        await storage.createWalletTransaction({
          walletAccountId: walletAccount.id,
          type: "DEPOSIT",
          amount: intent.netAmount,
          currency: intent.currency,
          status: "COMPLETED",
          referenceId: intent.id,
          description: `Stripe card deposit (PI-${intent.id.slice(0, 8).toUpperCase()})`,
          metadata: { paymentIntentId: intent.id, stripeSessionId: session.id, ledgerTxId },
        });

        if (parseFloat(intent.fee) > 0) {
          await storage.createWalletTransaction({
            walletAccountId: walletAccount.id,
            type: "FEE",
            amount: `-${intent.fee}`,
            currency: intent.currency,
            status: "COMPLETED",
            referenceId: intent.id,
            description: `Deposit fee for PI-${intent.id.slice(0, 8).toUpperCase()}`,
            metadata: { paymentIntentId: intent.id, ledgerTxId },
          });
        }

        await storage.createNotification({
          userId: intent.userId,
          ...NotificationTemplates.deposit.cardConfirmed(intent.currency, intent.netAmount),
          relatedEntityId: intent.id,
          relatedEntityType: "payment_intent",
        });

        await logAuditFromReq(req, "STRIPE_WEBHOOK_CONFIRM", "payment_intent", intent.id, {
          reason: `Stripe webhook confirmed: ${intent.currency} ${intent.amount}, session ${session.id}. LedgerTx: ${ledgerTxId}`,
          beforeState: { status: intent.status },
          afterState: { status: "CONFIRMED" },
          metadata: { stripeSessionId: session.id, ledgerTxId },
        });

        console.log(`[stripe-webhook] Successfully confirmed intent ${paymentIntentId} and credited wallet (ledger: ${ledgerTxId})`);
      } catch (err: any) {
        console.error(`[stripe-webhook] Error processing checkout.session.completed:`, err);
      }
    }

    if (event.type === "checkout.session.expired") {
      const session = event.data.object as Stripe.Checkout.Session;
      const paymentIntentId = session.metadata?.paymentIntentId;

      if (paymentIntentId) {
        try {
          const intent = await storage.getPaymentIntent(paymentIntentId);
          if (intent && intent.status !== "CONFIRMED" && intent.status !== "FAILED") {
            await storage.updatePaymentIntentStatus(intent.id, "FAILED", {
              failureReason: "Stripe checkout session expired",
            });
            console.log(`[stripe-webhook] Marked intent ${paymentIntentId} as failed (session expired)`);
          }
        } catch (err: any) {
          console.error(`[stripe-webhook] Error handling session expiry:`, err);
        }
      }
    }

    res.json({ received: true });
  });

  const achLinkBankSchema = z.object({
    routingNumber: z.string().regex(/^\d{9}$/, "Routing number must be exactly 9 digits"),
    accountNumber: z.string().min(4, "Account number is required").max(17),
    accountType: z.enum(["checking", "savings"]),
    accountHolderName: z.string().min(2, "Account holder name is required"),
    bankName: z.string().optional(),
  });

  app.post("/api/payment-intents/:id/ach/link-bank", requireAuth, async (req, res) => {
    try {
      const jwtUser = (req as any).user;
      const intent = await storage.getPaymentIntent(String(String(req.params.id)));
      if (!intent) return res.status(404).json({ message: "Payment intent not found" });
      if (intent.userId !== jwtUser.userId && jwtUser.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      if (intent.provider !== "ach") {
        return res.status(400).json({ message: "This endpoint is only for ACH payment intents" });
      }
      if (intent.status !== "CREATED") {
        return res.status(400).json({ message: `Cannot link bank account when intent status is ${intent.status}` });
      }

      const parsed = achLinkBankSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Validation failed", errors: parsed.error.errors });
      }

      const bankDetails: AchBankDetails = parsed.data;
      const result = await achProvider.linkBankAccount(intent, bankDetails);

      const updated = await storage.updatePaymentIntentStatus(intent.id, intent.status as any, {
        providerResponse: result.providerResponse,
      });

      await logAuditFromReq(req, "ACH_LINK_BANK", "payment_intent", intent.id, {
        reason: `ACH bank account linked: ${parsed.data.accountType} account at ${parsed.data.bankName || "US Bank"}`,
      });

      res.json(updated);
    } catch (err: any) {
      console.error("ACH link bank error:", err);
      res.status(500).json({ message: "Failed to link bank account" });
    }
  });

  app.post("/api/payment-intents/:id/ach/verify-bank", requireAuth, async (req, res) => {
    try {
      const jwtUser = (req as any).user;
      const intent = await storage.getPaymentIntent(String(String(req.params.id)));
      if (!intent) return res.status(404).json({ message: "Payment intent not found" });
      if (intent.userId !== jwtUser.userId && jwtUser.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      if (intent.provider !== "ach") {
        return res.status(400).json({ message: "This endpoint is only for ACH payment intents" });
      }
      const achMeta = (intent.providerResponse as any)?.achMetadata;
      if (!achMeta || achMeta.achBankVerificationStatus !== "pending_micro_deposits") {
        return res.status(400).json({ message: "Bank account must be linked and awaiting micro-deposit verification before calling this endpoint" });
      }

      const microDepositSchema = z.object({
        amount1: z.number().positive().max(0.99, "Micro-deposit amount must be under $1.00"),
        amount2: z.number().positive().max(0.99, "Micro-deposit amount must be under $1.00"),
      });

      const parsed = microDepositSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Validation failed", errors: parsed.error.errors });
      }

      const result = await achProvider.verifyBankAccount(intent, [parsed.data.amount1, parsed.data.amount2]);

      if (result.failureReason) {
        return res.status(400).json({ message: result.failureReason });
      }

      const updated = await storage.updatePaymentIntentStatus(intent.id, intent.status as any, {
        providerResponse: result.providerResponse,
      });

      await logAuditFromReq(req, "ACH_VERIFY_BANK", "payment_intent", intent.id, {
        reason: `ACH bank account verified via micro-deposits`,
      });

      res.json(updated);
    } catch (err: any) {
      console.error("ACH verify bank error:", err);
      res.status(500).json({ message: "Failed to verify bank account" });
    }
  });

  app.post("/api/payment-intents/:id/ach/initiate-transfer", requireAuth, async (req, res) => {
    try {
      const jwtUser = (req as any).user;
      const intent = await storage.getPaymentIntent(String(String(req.params.id)));
      if (!intent) return res.status(404).json({ message: "Payment intent not found" });
      if (intent.userId !== jwtUser.userId && jwtUser.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      if (intent.provider !== "ach") {
        return res.status(400).json({ message: "This endpoint is only for ACH payment intents" });
      }
      const achMeta = (intent.providerResponse as any)?.achMetadata;
      if (!achMeta || achMeta.achBankVerificationStatus !== "verified") {
        return res.status(400).json({ message: "Bank account must be verified before initiating ACH transfer" });
      }
      if (intent.status !== "CREATED") {
        return res.status(400).json({ message: `Cannot initiate transfer when intent status is ${intent.status}` });
      }

      const result = await achProvider.initiateTransfer(intent);

      if (result.failureReason) {
        return res.status(400).json({ message: result.failureReason });
      }

      const updated = await storage.updatePaymentIntentStatus(intent.id, result.status, {
        providerResponse: result.providerResponse,
      });

      await logAuditFromReq(req, "ACH_INITIATE_TRANSFER", "payment_intent", intent.id, {
        reason: `ACH transfer initiated: ${intent.currency} ${intent.amount}`,
        metadata: { currency: intent.currency, amount: intent.amount },
      });

      res.json(updated);
    } catch (err: any) {
      console.error("ACH initiate transfer error:", err);
      res.status(500).json({ message: "Failed to initiate ACH transfer" });
    }
  });

  app.get("/api/payment-intents/:id/ach/status", requireAuth, async (req, res) => {
    try {
      const jwtUser = (req as any).user;
      const intent = await storage.getPaymentIntent(String(String(req.params.id)));
      if (!intent) return res.status(404).json({ message: "Payment intent not found" });
      if (intent.userId !== jwtUser.userId && jwtUser.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      if (intent.provider !== "ach") {
        return res.status(400).json({ message: "This endpoint is only for ACH payment intents" });
      }

      const result = await achProvider.getStatus(intent);
      res.json({
        intentId: intent.id,
        intentStatus: intent.status,
        achStatus: result.providerResponse,
      });
    } catch (err: any) {
      console.error("ACH status error:", err);
      res.status(500).json({ message: "Failed to get ACH status" });
    }
  });

  app.post("/api/admin/payment-intents/:id/ach/return", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const adminId = (req as any).user.userId;
      const intent = await storage.getPaymentIntent(String(String(req.params.id)));
      if (!intent) return res.status(404).json({ message: "Payment intent not found" });
      if (intent.provider !== "ach") {
        return res.status(400).json({ message: "This endpoint is only for ACH payment intents" });
      }

      const returnSchema = z.object({
        returnCode: z.string().min(2, "Return code is required"),
        returnReason: z.string().optional(),
      });

      const parsed = returnSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Validation failed", errors: parsed.error.errors });
      }

      const reasonFromCode = ACH_RETURN_CODES[parsed.data.returnCode];
      const returnReason = parsed.data.returnReason || reasonFromCode || "Unknown return reason";

      const result = await achProvider.returnTransfer(intent, parsed.data.returnCode, returnReason);

      const updated = await storage.updatePaymentIntentStatus(intent.id, result.status, {
        providerResponse: result.providerResponse,
        failureReason: result.failureReason,
      });

      await logAuditFromReq(req, "ACH_RETURN", "payment_intent", intent.id, {
        reason: `ACH return processed: ${parsed.data.returnCode} - ${returnReason}`,
        beforeState: { status: intent.status },
        afterState: { status: result.status },
        metadata: { returnCode: parsed.data.returnCode },
      });

      const achNotif = NotificationTemplates.deposit.achReturned(intent.currency, intent.amount, parsed.data.returnCode, returnReason);
      await storage.createNotification({ userId: intent.userId, ...achNotif, relatedEntityId: intent.id, relatedEntityType: "payment_intent" });

      res.json(updated);
    } catch (err: any) {
      console.error("ACH return error:", err);
      res.status(500).json({ message: "Failed to process ACH return" });
    }
  });

  app.get("/api/ach/return-codes", requireAuth, async (_req, res) => {
    res.json(ACH_RETURN_CODES);
  });
}
