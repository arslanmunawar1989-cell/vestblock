import type { Express } from "express";
import { storage } from "../storage";
import { hashPassword, verifyPassword, generateToken, verifyToken, requireAuth, getUserPermissions, resolveEffectivePlatformRole } from "../auth";
import { z } from "zod";
import { registerRequestSchema, loginRequestSchema } from "@shared/dto/auth.dto";
import { validateBody } from "../middleware/validate";
import { authLimiter } from "../middleware/rate-limit";
import { logAudit } from "../lib/audit-logger";
import type { TenantRole } from "@shared/constants";
import { PLATFORM_TENANT_ID } from "@shared/constants";

export function registerAuthRoutes(app: Express) {
  const stripPassword = (user: any) => {
    const { password, ...safe } = user;
    return safe;
  };

  const cookieOptions = {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax" as const,
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: "/",
  };

  app.post("/api/auth/register", authLimiter, validateBody(registerRequestSchema), async (req, res) => {
    try {
      const data = req.body;
      const existing = await storage.getUserByUsername(data.username);
      if (existing) {
        return res.status(409).json({ message: "Username already taken" });
      }
      const existingEmail = await storage.getUserByEmail(data.email);
      if (existingEmail) {
        return res.status(409).json({ message: "Email already in use" });
      }
      const passwordHash = await hashPassword(data.password);
      const tenantId = req.tenantId || PLATFORM_TENANT_ID;
      const allowedSelfRegRoles = ["investor", "issuer", "agent"];
      const safeRole = allowedSelfRegRoles.includes(data.role) ? data.role : "investor";
      const user = await storage.createUser({
        username: data.username,
        password: passwordHash,
        email: data.email,
        fullName: data.fullName,
        role: safeRole,
        tenantId,
      });
      let tenantRole: TenantRole | null = null;
      if (tenantId) {
        try {
          const tu = await storage.createTenantUser({ tenantId, userId: user.id, role: "TENANT_USER" });
          tenantRole = tu.role as TenantRole;
        } catch (e) {}
      }
      const token = generateToken(user, tenantId, tenantRole);
      res.cookie("token", token, cookieOptions);

      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
      await storage.createSession({
        userId: user.id,
        token,
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || null,
        userAgent: req.headers["user-agent"] || null,
        provider: "credentials",
        expiresAt,
      }).catch(() => {});

      await logAudit({
        actorId: user.id,
        actorRole: user.role,
        actionType: "USER_REGISTERED",
        entityType: "user",
        entityId: user.id,
        reason: `New user registered: ${user.username}`,
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });

      const platformRole = resolveEffectivePlatformRole(user);
      res.status(201).json({ user: { ...stripPassword(user), platformRole }, token, primaryCountry: "AE", defaultCurrency: "AED", countryName: "United Arab Emirates", tenantRole });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("Register error:", err);
      res.status(500).json({ message: "Registration failed" });
    }
  });

  app.post("/api/auth/login", authLimiter, validateBody(loginRequestSchema), async (req, res) => {
    try {
      const data = req.body;
      const user = await storage.getUserByUsername(data.username);
      if (!user) {
        await logAudit({
          actorId: "anonymous",
          actionType: "USER_LOGIN_FAILED",
          entityType: "user",
          reason: `Login failed: unknown username "${data.username}"`,
          ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
          userAgent: req.headers["user-agent"] || undefined,
        });
        return res.status(401).json({ message: "Invalid credentials" });
      }
      const valid = await verifyPassword(data.password, user.password);
      if (!valid) {
        await logAudit({
          actorId: user.id,
          actionType: "USER_LOGIN_FAILED",
          entityType: "user",
          entityId: user.id,
          reason: `Login failed: bad password for user "${data.username}"`,
          ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
          userAgent: req.headers["user-agent"] || undefined,
        });
        return res.status(401).json({ message: "Invalid credentials" });
      }
      if (user.accountStatus === "DISABLED") {
        return res.status(403).json({ message: "Your account has been disabled. Please contact support." });
      }
      if (user.accountStatus === "ARCHIVED") {
        return res.status(403).json({ message: "Your account has been archived." });
      }
      if (!user.isActive) {
        return res.status(403).json({ message: "Account is deactivated" });
      }

      const tenantId = req.tenantId;
      let tenantRole: TenantRole | null = null;

      if (tenantId) {
        const tenant = await storage.getTenant(tenantId);
        if (!tenant || tenant.status !== "ACTIVE") {
          return res.status(403).json({ message: "This agency is suspended or unavailable" });
        }
        const tenantUser = await storage.getTenantUser(tenantId, user.id);
        if (tenantUser) {
          if (tenantUser.status === "DISABLED" || tenantUser.status === "SUSPENDED") {
            return res.status(403).json({ message: "Your access to this agency has been disabled" });
          }
          tenantRole = tenantUser.role as TenantRole;
        } else if (tenantId !== PLATFORM_TENANT_ID) {
          return res.status(403).json({ message: "You do not have access to this agency" });
        } else {
          try {
            const tu = await storage.createTenantUser({ tenantId, userId: user.id, role: "TENANT_USER" });
            tenantRole = tu.role as TenantRole;
            await logAudit({
              actorId: user.id,
              actorRole: user.role,
              actionType: "TENANT_USER_AUTO_PROVISIONED",
              entityType: "tenant_user",
              entityId: user.id,
              reason: `Auto-provisioned platform tenant membership for user "${user.username}" on login`,
              ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
              userAgent: req.headers["user-agent"] || undefined,
            });
          } catch {}
        }
      }

      const token = generateToken(user, tenantId, tenantRole);
      res.cookie("token", token, cookieOptions);

      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
      await storage.createSession({
        userId: user.id,
        token,
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || null,
        userAgent: req.headers["user-agent"] || null,
        provider: "credentials",
        expiresAt,
      }).catch(() => {});

      const profiles = await storage.getCountryProfiles(user.id);
      const primary = profiles.find(p => p.isPrimary) || profiles[0];
      const primaryCountry = primary?.countryCode || "AE";
      const { COUNTRY_TO_CURRENCY, COUNTRY_DETAILS } = await import("@shared/constants");
      const defaultCurrency = COUNTRY_TO_CURRENCY[primaryCountry as keyof typeof COUNTRY_TO_CURRENCY] || "AED";
      const countryName = COUNTRY_DETAILS[primaryCountry as keyof typeof COUNTRY_DETAILS]?.name || "United Arab Emirates";
      const permissions = await getUserPermissions(user.role);
      const platformRole = resolveEffectivePlatformRole(user);

      await logAudit({
        actorId: user.id,
        actorRole: user.role,
        actionType: "USER_LOGIN",
        entityType: "user",
        entityId: user.id,
        reason: `User logged in: ${user.username}`,
        ipAddress: req.ip || req.headers["x-forwarded-for"] as string || undefined,
        userAgent: req.headers["user-agent"] || undefined,
      });

      res.json({ user: { ...stripPassword(user), platformRole }, token, primaryCountry, defaultCurrency, countryName, permissions, tenantRole });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("Login error:", err);
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.post("/api/auth/logout", async (req, res) => {
    const token = req.cookies?.token || req.headers.authorization?.replace("Bearer ", "");
    if (token) {
      const session = await storage.getSessionByToken(token).catch(() => undefined);
      if (session) {
        await storage.revokeSession(session.id).catch(() => {});
      }
    }
    res.clearCookie("token", { path: "/" });
    res.json({ message: "Logged out" });
  });

  app.get("/api/auth/me", (req, res) => {
    const token = (req as any).cookies?.token || req.headers.authorization?.replace("Bearer ", "");
    if (!token) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    const payload = verifyToken(token);
    if (!payload) {
      return res.status(401).json({ message: "Invalid or expired token" });
    }
    storage.getUser(payload.userId).then(async (user) => {
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      if (user.accountStatus === "DISABLED") {
        res.clearCookie("token", { path: "/" });
        return res.status(403).json({ message: "Account has been disabled. Please contact support." });
      }
      if (user.accountStatus === "ARCHIVED") {
        res.clearCookie("token", { path: "/" });
        return res.status(403).json({ message: "Account has been archived." });
      }
      if (!user.isActive) {
        res.clearCookie("token", { path: "/" });
        return res.status(403).json({ message: "Account is deactivated" });
      }
      if (user.tokenVersion !== undefined && payload.tokenVersion !== undefined && user.tokenVersion !== payload.tokenVersion) {
        res.clearCookie("token", { path: "/" });
        return res.status(401).json({ message: "Session expired. Please log in again." });
      }
      const profiles = await storage.getCountryProfiles(payload.userId);
      const primary = profiles.find(p => p.isPrimary) || profiles[0];
      const primaryCountry = primary?.countryCode || "AE";
      const { COUNTRY_TO_CURRENCY, COUNTRY_DETAILS } = await import("@shared/constants");
      const { getUserPermissions } = await import("../auth");
      const defaultCurrency = COUNTRY_TO_CURRENCY[primaryCountry as keyof typeof COUNTRY_TO_CURRENCY] || "AED";
      const countryName = COUNTRY_DETAILS[primaryCountry as keyof typeof COUNTRY_DETAILS]?.name || "United Arab Emirates";
      const permissions = await getUserPermissions(user.role);
      const platformRole = resolveEffectivePlatformRole(user);

      let tenantRole = payload.tenantRole || null;
      if (payload.tenantId) {
        const tu = await storage.getTenantUser(payload.tenantId, user.id);
        if (tu && tu.status === "ACTIVE") {
          tenantRole = tu.role as TenantRole;
        }
      }

      res.json({
        user: { ...stripPassword(user), platformRole },
        primaryCountry,
        defaultCurrency,
        countryName,
        permissions,
        tenantRole,
        impersonating: payload.impersonatorId ? { impersonatorId: payload.impersonatorId, impersonatorUsername: payload.impersonatorUsername } : null,
      });
    }).catch(() => {
      res.status(500).json({ message: "Failed to fetch user" });
    });
  });

  app.get("/api/auth/sessions", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const activeSessions = await storage.getActiveSessions(userId);
      res.json(activeSessions.map(s => ({
        id: s.id,
        provider: s.provider,
        ipAddress: s.ipAddress,
        userAgent: s.userAgent,
        createdAt: s.createdAt,
        expiresAt: s.expiresAt,
      })));
    } catch (err: any) {
      console.error("Get sessions error:", err);
      res.status(500).json({ message: "Failed to fetch sessions" });
    }
  });

  app.post("/api/auth/sessions/:id/revoke", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const sessionId = req.params.id;
      const activeSessions = await storage.getActiveSessions(userId);
      const session = activeSessions.find(s => s.id === sessionId);
      if (!session) {
        return res.status(404).json({ message: "Session not found" });
      }
      await storage.revokeSession(sessionId);
      await storage.incrementTokenVersion(userId);
      res.json({ message: "Session revoked" });
    } catch (err: any) {
      console.error("Revoke session error:", err);
      res.status(500).json({ message: "Failed to revoke session" });
    }
  });

  app.get("/api/auth/config", (_req, res) => {
    res.json({
      googleEnabled: !!(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET),
      roles: {
        CLIENT: "investor",
        AGENT: "agent",
        MANAGER: "admin",
        WEBSITE_MANAGER: "cms",
        SUPER_ADMIN: "SUPER_ADMIN",
      },
      defaultRole: "investor",
    });
  });

  app.get("/api/users", requireAuth, async (_req, res) => {
    try {
      const users = await storage.getUsers();
      res.json(users.map(stripPassword));
    } catch (err: any) {
      console.error("Get users error:", err);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.get("/api/users/:id", requireAuth, async (req, res) => {
    try {
      const rawId = req.params.id;
      const userId = Array.isArray(rawId) ? rawId[0] : rawId;
      const user = await storage.getUser(userId);
      if (!user) return res.status(404).json({ message: "User not found" });
      res.json(stripPassword(user));
    } catch (err: any) {
      console.error("Get user error:", err);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });
}
