import type { Express, Request, Response } from "express";
import { requireAuth, requirePlatformAction } from "../auth";
import { storage } from "../storage";

export function registerTenantExportRoutes(app: Express) {
  app.get("/api/admin/export/:tenantId/users", requireAuth, requirePlatformAction("tenants.view"), async (req: Request, res: Response) => {
    try {
      const tenantId = String(req.params.tenantId);
      const tenantUsers = await storage.getTenantUsers(tenantId);
      const userIds = tenantUsers.map(tu => tu.userId);
      const users: any[] = [];
      for (const uid of userIds) {
        const user = await storage.getUser(uid);
        if (user) {
          const { password, ...safe } = user;
          users.push({ ...safe, tenantRole: tenantUsers.find(tu => tu.userId === uid)?.role });
        }
      }

      const format = req.query.format || "json";
      if (format === "csv") {
        const csvHeader = "id,username,email,fullName,role,tenantRole,accountStatus\n";
        const csvRows = users.map(u => `${u.id},${u.username},${u.email || ""},${u.fullName || ""},${u.role},${u.tenantRole || ""},${u.accountStatus || "ACTIVE"}`).join("\n");
        res.setHeader("Content-Type", "text/csv");
        res.setHeader("Content-Disposition", `attachment; filename=users-${tenantId}.csv`);
        return res.send(csvHeader + csvRows);
      }
      res.json({ tenantId, exportedAt: new Date().toISOString(), count: users.length, data: users });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/admin/export/:tenantId/projects", requireAuth, requirePlatformAction("tenants.view"), async (req: Request, res: Response) => {
    try {
      const tenantId = String(req.params.tenantId);
      const projects = await storage.getProjectsByTenant(tenantId);

      const format = req.query.format || "json";
      if (format === "csv") {
        const csvHeader = "id,name,description,status,createdBy,createdAt\n";
        const csvRows = projects.map(p => `${p.id},"${(p.name || "").replace(/"/g, '""')}","${(p.description || "").replace(/"/g, '""')}",${p.status || ""},${p.createdBy || ""},${p.createdAt || ""}`).join("\n");
        res.setHeader("Content-Type", "text/csv");
        res.setHeader("Content-Disposition", `attachment; filename=projects-${tenantId}.csv`);
        return res.send(csvHeader + csvRows);
      }
      res.json({ tenantId, exportedAt: new Date().toISOString(), count: projects.length, data: projects });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/admin/export/:tenantId/analytics", requireAuth, requirePlatformAction("tenants.view"), async (req: Request, res: Response) => {
    try {
      const tenantId = String(req.params.tenantId);
      const [tenantUsers, projects, assets] = await Promise.all([
        storage.getTenantUsers(tenantId),
        storage.getProjectsByTenant(tenantId),
        storage.getAssets(tenantId),
      ]);

      const analytics = {
        tenantId,
        exportedAt: new Date().toISOString(),
        summary: {
          totalUsers: tenantUsers.length,
          activeUsers: tenantUsers.filter(u => u.status === "ACTIVE").length,
          totalProjects: projects.length,
          totalAssets: assets.length,
          usersByRole: tenantUsers.reduce((acc: Record<string, number>, u) => {
            acc[u.role] = (acc[u.role] || 0) + 1;
            return acc;
          }, {}),
        },
      };

      res.json(analytics);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/admin/export/:tenantId/audit-logs", requireAuth, requirePlatformAction("tenants.view"), async (req: Request, res: Response) => {
    try {
      const tenantId = String(req.params.tenantId);
      const tenantUsers = await storage.getTenantUsers(tenantId);
      const userIds = tenantUsers.map(tu => tu.userId);

      const allLogs: any[] = [];
      for (const uid of userIds) {
        const logs = await storage.getAuditLogsByEntity("user", uid);
        allLogs.push(...logs);
      }

      allLogs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      res.json({ tenantId, exportedAt: new Date().toISOString(), count: allLogs.length, data: allLogs });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });
}
