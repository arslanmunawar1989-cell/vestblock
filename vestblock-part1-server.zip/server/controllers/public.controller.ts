import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { logAuditFromReq } from "../lib/audit-logger";
import { db } from "../db";
import { dataRoomDocuments } from "@shared/schema";
import { eq, and, desc } from "drizzle-orm";

export function registerPublicRoutes(app: Express) {
  app.get("/api/assets", async (req, res) => {
    try {
      const assets = await storage.getAssets(req.tenantId);
      res.json(assets);
    } catch (err: any) {
      console.error("Get assets error:", err);
      res.status(500).json({ message: "Failed to fetch assets" });
    }
  });

  app.get("/api/assets/:id", async (req, res) => {
    try {
      const asset = await storage.getAsset(String(req.params.id));
      if (!asset) return res.status(404).json({ message: "Asset not found" });
      if (req.tenantId && asset.tenantId && asset.tenantId !== req.tenantId) {
        return res.status(404).json({ message: "Asset not found" });
      }
      res.json(asset);
    } catch (err: any) {
      console.error("Get asset error:", err);
      res.status(500).json({ message: "Failed to fetch asset" });
    }
  });

  app.get("/api/rounds", async (req, res) => {
    try {
      const rounds = await storage.getRounds(req.tenantId);
      res.json(rounds);
    } catch (err: any) {
      console.error("Get rounds error:", err);
      res.status(500).json({ message: "Failed to fetch rounds" });
    }
  });

  app.get("/api/portfolio/:userId", requireAuth, async (req, res) => {
    try {
      const callerId = (req as any).user?.userId;
      const requestedUserId = req.params.userId as string;
      const callerRole = (req as any).user?.role;
      if (callerRole !== "admin" && callerId !== requestedUserId) {
        return res.status(403).json({ message: "You can only view your own portfolio" });
      }
      const items = await storage.getPortfolioItems(requestedUserId, req.tenantId);
      res.json(items);
    } catch (err: any) {
      console.error("Get portfolio error:", err);
      res.status(500).json({ message: "Failed to fetch portfolio" });
    }
  });

  app.get("/api/transactions", requireAuth, async (req, res) => {
    try {
      const callerId = (req as any).user?.userId;
      const callerRole = (req as any).user?.role;
      let userId = req.query.userId as string | undefined;
      if (callerRole !== "admin") {
        userId = callerId;
      }
      const txs = await storage.getTransactions(userId, req.tenantId);
      res.json(txs);
    } catch (err: any) {
      console.error("Get transactions error:", err);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  app.get("/api/distributions", async (req, res) => {
    try {
      const dists = await storage.getDistributions(req.tenantId);
      res.json(dists);
    } catch (err: any) {
      console.error("Get distributions error:", err);
      res.status(500).json({ message: "Failed to fetch distributions" });
    }
  });

  app.get("/api/stats/overview", async (req, res) => {
    try {
      const [users, assets, rounds, distributions] = await Promise.all([
        storage.getUsers(req.tenantId),
        storage.getAssets(req.tenantId),
        storage.getRounds(req.tenantId),
        storage.getDistributions(req.tenantId),
      ]);

      const totalAum = assets.reduce((sum, a) => sum + parseFloat(a.totalSupply) * parseFloat(a.pricePerToken), 0);

      res.json({
        totalUsers: users.length,
        activeAssets: assets.filter(a => a.status === "active").length,
        totalAum,
        openRounds: rounds.filter(r => r.status === "open").length,
        pendingDistributions: distributions.filter(d => d.status === "scheduled").length,
      });
    } catch (err: any) {
      console.error("Stats overview error:", err);
      res.status(500).json({ message: "Failed to fetch overview stats" });
    }
  });

  app.get("/api/public/data-room/:assetId", async (req, res) => {
    try {
      const assetId = req.params.assetId;
      const asset = await storage.getAsset(assetId);
      if (!asset) return res.status(404).json({ message: "Asset not found" });

      const docs = await db.select().from(dataRoomDocuments)
        .where(and(
          eq(dataRoomDocuments.assetId, assetId),
          eq(dataRoomDocuments.scope, "asset"),
          eq(dataRoomDocuments.status, "live"),
          eq(dataRoomDocuments.accessTier, "public"),
        ))
        .orderBy(desc(dataRoomDocuments.createdAt));

      res.json(docs.map(d => ({
        id: d.id,
        title: d.title,
        description: d.description,
        category: d.category,
        docType: d.docType,
        accessTier: d.accessTier,
        createdAt: d.createdAt,
      })));
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/db-health", requireAuth, requireRole("admin"), async (req, res) => {
    const start = Date.now();
    try {
      const [drizzleUsers, drizzleAssets] =
        await Promise.all([
          storage.getUsers(req.tenantId),
          storage.getAssets(req.tenantId),
        ]);

      const latencyMs = Date.now() - start;

      await logAuditFromReq(req, "DB_HEALTH_CHECK", "system", undefined, {
        reason: `Health check passed in ${latencyMs}ms`,
      });

      res.json({
        status: "healthy",
        timestamp: new Date().toISOString(),
        latencyMs,
        drizzle: {
          connected: true,
          userCount: drizzleUsers.length,
          assetCount: drizzleAssets.length,
        },
      });
    } catch (err: any) {
      const latencyMs = Date.now() - start;
      res.status(503).json({
        status: "unhealthy",
        timestamp: new Date().toISOString(),
        latencyMs,
        drizzle: { connected: false, userCount: 0, assetCount: 0 },
        error: err.message,
      });
    }
  });
}
