import type { Express } from "express";
import { storage } from "../storage";
import { requireAuth, requireRole } from "../auth";
import { logAuditFromReq } from "../lib/audit-logger";
import { addBankAccountSchema } from "@shared/schema";
import { z } from "zod";
import { NotificationTemplates } from "../services/notification-templates";

export function registerBankRoutes(app: Express) {
  app.get("/api/bank-accounts", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const accounts = await storage.getBankAccountsByUser(userId);
      res.json(accounts);
    } catch (err: any) {
      console.error("Bank accounts fetch error:", err);
      res.status(500).json({ message: "Failed to fetch bank accounts" });
    }
  });

  app.post("/api/bank-accounts", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const data = addBankAccountSchema.parse(req.body);

      if (data.country === "UAE" && !data.iban) {
        return res.status(400).json({ message: "IBAN is required for UAE bank accounts" });
      }
      if (data.country === "UAE" && data.iban && !data.iban.startsWith("AE")) {
        return res.status(400).json({ message: "UAE IBAN must start with 'AE'" });
      }
      if (data.country === "PK" && !data.accountNumber) {
        return res.status(400).json({ message: "Account number is required for Pakistan bank accounts" });
      }

      if (data.isDefault) {
        const existing = await storage.getBankAccountsByUser(userId);
        for (const acc of existing) {
          if (acc.isDefault && acc.currency === data.currency) {
            await storage.updateBankAccount(acc.id, { isDefault: false });
          }
        }
      }

      const account = await storage.createBankAccount({
        userId,
        country: data.country,
        label: data.label,
        accountHolderName: data.accountHolderName,
        iban: data.iban || null,
        bankName: data.bankName,
        branchCode: data.branchCode || null,
        accountNumber: data.accountNumber || null,
        swiftCode: data.swiftCode || null,
        currency: data.currency,
        isDefault: data.isDefault,
      });

      await logAuditFromReq(req, "BANK_ACCOUNT_CREATED", "bank_account", account.id, {
        reason: `Bank account added: ${data.bankName} (${data.country}/${data.currency})`,
        afterState: { bankName: data.bankName, country: data.country, currency: data.currency, status: "pending" },
      });

      res.status(201).json(account);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("Bank account create error:", err);
      res.status(500).json({ message: "Failed to create bank account" });
    }
  });

  app.patch("/api/bank-accounts/:id", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const account = await storage.getBankAccountById(req.params.id as string);
      if (!account) return res.status(404).json({ message: "Bank account not found" });
      if (account.userId !== userId) return res.status(403).json({ message: "Forbidden" });
      if (account.status === "verified") {
        return res.status(400).json({ message: "Cannot edit a verified bank account. Please add a new one." });
      }

      const data = addBankAccountSchema.partial().parse(req.body);

      if (data.country === "UAE" && data.iban && !data.iban.startsWith("AE")) {
        return res.status(400).json({ message: "UAE IBAN must start with 'AE'" });
      }

      if (data.isDefault) {
        const existing = await storage.getBankAccountsByUser(userId);
        const currency = data.currency || account.currency;
        for (const acc of existing) {
          if (acc.id !== account.id && acc.isDefault && acc.currency === currency) {
            await storage.updateBankAccount(acc.id, { isDefault: false });
          }
        }
      }

      const updated = await storage.updateBankAccount(account.id, {
        ...data,
        iban: data.iban || undefined,
        branchCode: data.branchCode || undefined,
        accountNumber: data.accountNumber || undefined,
        swiftCode: data.swiftCode || undefined,
      });

      await storage.verifyBankAccount(account.id, "", "pending");

      const refreshed = await storage.getBankAccountById(account.id);

      await logAuditFromReq(req, "BANK_ACCOUNT_UPDATED", "bank_account", account.id, {
        reason: `Bank account updated, status reset to pending`,
        beforeState: { status: account.status },
        afterState: { status: "pending" },
      });

      res.json(refreshed);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("Bank account update error:", err);
      res.status(500).json({ message: "Failed to update bank account" });
    }
  });

  app.get("/api/bank-accounts/verified", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const verified = await storage.getVerifiedBankAccountsByUser(userId);
      res.json(verified);
    } catch (err: any) {
      console.error("Verified bank accounts error:", err);
      res.status(500).json({ message: "Failed to fetch verified bank accounts" });
    }
  });

  app.get("/api/admin/bank-accounts", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const accounts = await storage.getAllBankAccounts(req.tenantId);
      const enriched = await Promise.all(accounts.map(async (acc) => {
        const user = await storage.getUser(acc.userId);
        return {
          ...acc,
          user: user ? { id: user.id, username: user.username, email: user.email, fullName: user.fullName } : null,
        };
      }));
      res.json(enriched);
    } catch (err: any) {
      console.error("Admin bank accounts error:", err);
      res.status(500).json({ message: "Failed to fetch bank accounts" });
    }
  });

  const verifyBankAccountSchema = z.object({
    action: z.enum(["verify", "reject"]),
    notes: z.string().optional(),
  });

  app.post("/api/admin/bank-accounts/:id/verify", requireAuth, requireRole("admin"), async (req, res) => {
    try {
      const account = await storage.getBankAccountById(req.params.id as string);
      if (!account) return res.status(404).json({ message: "Bank account not found" });

      const { action, notes } = verifyBankAccountSchema.parse(req.body);
      const adminId = (req as any).user.userId;
      const newStatus = action === "verify" ? "verified" : "rejected";

      const updated = await storage.verifyBankAccount(account.id, adminId, newStatus, notes);

      const bankNotif = action === "verify"
        ? NotificationTemplates.bankAccount.verified(account.label, account.bankName)
        : NotificationTemplates.bankAccount.rejected(account.label, account.bankName, notes);

      await storage.createNotification({
        userId: account.userId,
        ...bankNotif,
        relatedEntityId: account.id,
        relatedEntityType: "bank_account",
      });

      await logAuditFromReq(req, `BANK_ACCOUNT_${action.toUpperCase()}`, "bank_account", account.id, {
        reason: `Bank account ${action}ed by admin ${adminId}${notes ? `: ${notes}` : ""}`,
        beforeState: { status: account.status },
        afterState: { status: newStatus },
      });

      res.json(updated);
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: err.errors });
      }
      console.error("Bank account verify error:", err);
      res.status(500).json({ message: "Failed to verify bank account" });
    }
  });

  app.get("/api/withdrawal-eligibility", requireAuth, async (req, res) => {
    try {
      const userId = (req as any).user.userId;
      const currency = req.query.currency as string | undefined;
      const verifiedAccounts = await storage.getVerifiedBankAccountsByUser(userId);
      const matchingAccounts = currency
        ? verifiedAccounts.filter(a => a.currency === currency)
        : verifiedAccounts;
      res.json({
        eligible: matchingAccounts.length > 0,
        verifiedAccountCount: matchingAccounts.length,
        accounts: matchingAccounts.map(a => ({ id: a.id, label: a.label, bankName: a.bankName, currency: a.currency })),
      });
    } catch (err: any) {
      console.error("Withdrawal eligibility error:", err);
      res.status(500).json({ message: "Failed to check withdrawal eligibility" });
    }
  });
}
