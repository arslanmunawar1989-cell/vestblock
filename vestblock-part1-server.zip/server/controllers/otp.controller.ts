import type { Express, Request, Response, NextFunction } from "express";
import { storage } from "../storage";
import { requireAuth } from "../auth";
import { verifyOtpSchema } from "@shared/schema";
import { db } from "../db";
import { auditLogs } from "@shared/schema";
import { emailService, otpEmail, transactionEmail } from "../services/email.service";
import crypto from "crypto";

function generateOtp(): string {
  return crypto.randomInt(100000, 999999).toString();
}

const otpRateLimit = new Map<string, { count: number; resetAt: number }>();
const OTP_RATE_LIMIT = 5;
const OTP_RATE_WINDOW = 5 * 60 * 1000;

function checkOtpRateLimit(key: string): boolean {
  const now = Date.now();
  const entry = otpRateLimit.get(key);
  if (!entry || now > entry.resetAt) {
    otpRateLimit.set(key, { count: 1, resetAt: now + OTP_RATE_WINDOW });
    return true;
  }
  if (entry.count >= OTP_RATE_LIMIT) return false;
  entry.count++;
  return true;
}

export function registerOtpRoutes(app: Express) {
  app.post("/api/transactions/initiate", requireAuth, async (req, res) => {
    try {
      const { type, amount, currency, description, assetId, metadataJson } = req.body;
      if (!type || !amount) {
        res.status(400).json({ message: "type and amount are required" });
        return;
      }

      const userId = (req as any).user.userId;
      const tenantId = (req as any).user.tenantId || null;

      if (!checkOtpRateLimit(`initiate:${userId}`)) {
        res.status(429).json({ message: "Too many OTP requests. Please wait before trying again." });
        return;
      }

      const transaction = await storage.createTransaction({
        userId,
        tenantId,
        type,
        amount,
        status: "pending_confirmation",
        description: description || null,
        assetId: assetId || null,
        currency: currency || "PKR",
        metadataJson: metadataJson || null,
      });

      await db.insert(auditLogs).values({
        tenantId,
        actorId: userId,
        actorRole: (req as any).user.role,
        actionType: "transaction.initiated_2fa",
        entityType: "transaction",
        entityId: transaction.id,
        afterState: { status: "pending_confirmation" },
        ipAddress: req.ip || null,
        userAgent: req.headers["user-agent"] || null,
      });

      const code = generateOtp();
      const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();

      await storage.createOtpCode({
        userId,
        transactionId: transaction.id,
        code,
        expiresAt,
        attempts: 0,
        maxAttempts: 5,
        verified: false,
      });

      const user = await storage.getUser(userId);
      if (user?.email) {
        emailService.send(otpEmail(user.email, code, { tenantId: tenantId || undefined, transactionId: transaction.id })).catch(() => {});
      }

      res.status(201).json({
        transactionId: transaction.id,
        status: "pending_confirmation",
        message: "OTP sent to your email. Please verify to complete the transaction.",
        expiresAt,
      });
    } catch (err: any) {
      console.error("Initiate transaction error:", err);
      res.status(500).json({ message: "Failed to initiate transaction" });
    }
  });

  app.post("/api/transactions/verify-otp", requireAuth, async (req, res) => {
    try {
      const parsed = verifyOtpSchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({ message: "Invalid payload", errors: parsed.error.flatten().fieldErrors });
        return;
      }

      const { transactionId, code } = parsed.data;
      const userId = (req as any).user.userId;

      if (!checkOtpRateLimit(`verify:${userId}`)) {
        res.status(429).json({ message: "Too many verification attempts. Please wait before trying again." });
        return;
      }

      const transaction = await storage.getTransaction(transactionId);
      if (!transaction) {
        res.status(404).json({ message: "Transaction not found" });
        return;
      }

      if (transaction.userId !== userId) {
        res.status(403).json({ message: "Not authorized" });
        return;
      }

      if (transaction.status !== "pending_confirmation") {
        res.status(400).json({ message: "Transaction is not pending confirmation" });
        return;
      }

      const otpRecord = await storage.getOtpByTransaction(transactionId);
      if (!otpRecord) {
        res.status(400).json({ message: "No OTP found. Please initiate a new transaction." });
        return;
      }

      if (new Date(otpRecord.expiresAt) < new Date()) {
        await storage.updateTransactionStatus(transactionId, "failed");
        await db.insert(auditLogs).values({
          tenantId: transaction.tenantId,
          actorId: userId,
          actorRole: (req as any).user.role,
          actionType: "otp.expired",
          entityType: "transaction",
          entityId: transactionId,
          afterState: { reason: "OTP expired" },
          ipAddress: req.ip || null,
          userAgent: req.headers["user-agent"] || null,
        });
        res.status(400).json({ message: "OTP has expired. Please initiate a new transaction." });
        return;
      }

      if ((otpRecord.attempts || 0) >= (otpRecord.maxAttempts || 5)) {
        await storage.updateTransactionStatus(transactionId, "failed");
        await db.insert(auditLogs).values({
          tenantId: transaction.tenantId,
          actorId: userId,
          actorRole: (req as any).user.role,
          actionType: "otp.max_attempts",
          entityType: "transaction",
          entityId: transactionId,
          afterState: { reason: "Max OTP attempts exceeded" },
          ipAddress: req.ip || null,
          userAgent: req.headers["user-agent"] || null,
        });
        res.status(400).json({ message: "Maximum OTP attempts exceeded. Transaction cancelled." });
        return;
      }

      await storage.incrementOtpAttempts(otpRecord.id);

      if (otpRecord.code !== code) {
        const remaining = (otpRecord.maxAttempts || 5) - (otpRecord.attempts || 0) - 1;
        await db.insert(auditLogs).values({
          tenantId: transaction.tenantId,
          actorId: userId,
          actorRole: (req as any).user.role,
          actionType: "otp.failed",
          entityType: "transaction",
          entityId: transactionId,
          afterState: { attemptsRemaining: remaining },
          ipAddress: req.ip || null,
          userAgent: req.headers["user-agent"] || null,
        });
        res.status(400).json({ message: `Invalid OTP code. ${remaining} attempts remaining.` });
        return;
      }

      await storage.markOtpVerified(otpRecord.id);
      const updated = await storage.updateTransactionStatus(transactionId, "confirmed");

      await db.insert(auditLogs).values({
        tenantId: transaction.tenantId,
        actorId: userId,
        actorRole: (req as any).user.role,
        actionType: "otp.verified",
        entityType: "transaction",
        entityId: transactionId,
        beforeState: { status: "pending_confirmation" },
        afterState: { status: "confirmed" },
        ipAddress: req.ip || null,
        userAgent: req.headers["user-agent"] || null,
      });

      const user = await storage.getUser(userId);
      if (user?.email) {
        emailService.send(transactionEmail(user.email, "pending_confirmation", { amount: transaction.amount, currency: transaction.currency || "PKR", type: transaction.type, description: transaction.description || undefined }, { tenantId: transaction.tenantId || undefined, transactionId })).catch(() => {});
      }

      res.json({
        transaction: updated,
        message: "Transaction verified and confirmed successfully.",
      });
    } catch (err: any) {
      console.error("Verify OTP error:", err);
      res.status(500).json({ message: "Failed to verify OTP" });
    }
  });

  app.post("/api/transactions/resend-otp", requireAuth, async (req, res) => {
    try {
      const { transactionId } = req.body;
      if (!transactionId) {
        res.status(400).json({ message: "transactionId is required" });
        return;
      }

      const userId = (req as any).user.userId;

      if (!checkOtpRateLimit(`resend:${userId}`)) {
        res.status(429).json({ message: "Too many OTP requests. Please wait before trying again." });
        return;
      }

      const transaction = await storage.getTransaction(transactionId);
      if (!transaction || transaction.userId !== userId) {
        res.status(404).json({ message: "Transaction not found" });
        return;
      }

      if (transaction.status !== "pending_confirmation") {
        res.status(400).json({ message: "Transaction is not pending confirmation" });
        return;
      }

      const code = generateOtp();
      const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();

      await storage.createOtpCode({
        userId,
        transactionId,
        code,
        expiresAt,
        attempts: 0,
        maxAttempts: 5,
        verified: false,
      });

      const user = await storage.getUser(userId);
      if (user?.email) {
        emailService.send(otpEmail(user.email, code, { tenantId: transaction.tenantId || undefined, transactionId })).catch(() => {});
      }

      res.json({ message: "New OTP sent to your email.", expiresAt });
    } catch (err: any) {
      console.error("Resend OTP error:", err);
      res.status(500).json({ message: "Failed to resend OTP" });
    }
  });
}
