import { eq, desc, and, sql, gte, inArray } from "drizzle-orm";
import { db } from "./db";
import { CURRENCY_TO_COUNTRY, PLATFORM_TENANT_ID } from "@shared/constants";
import {
  tenants,
  tenantUsers,
  impersonationLogs,
  type Tenant, type InsertTenant,
  type TenantUser, type InsertTenantUser,
  type ImpersonationLog, type InsertImpersonationLog,
  users, assets, rounds, portfolioItems, transactions, distributions, kycProfiles, documents, notifications, amlFlags, legalDocuments, legalAcceptances, walletAccounts, walletTransactions, ledgerEntries, bankAccounts, withdrawalRequests, feeSchedules, appliedFees, userCountryProfiles,
  projects, projectMembers, projectActivityLogs, lockupRules,
  appointments, emailLogs, subscribers, campaigns, otpCodes, sessions,
  type Project, type InsertProject,
  type ProjectMember, type InsertProjectMember,
  type ProjectActivityLog, type InsertProjectActivityLog,
  type LockupRule, type InsertLockupRule,
  type Appointment, type InsertAppointment,
  type EmailLog, type InsertEmailLog,
  type Subscriber, type InsertSubscriber,
  type Campaign, type InsertCampaign,
  type OtpCode, type InsertOtpCode,
  type Session, type InsertSession,
  type User, type InsertUser, type UpdateProfile, type NotificationPreferences,
  type Asset, type InsertAsset,
  type Round, type InsertRound,
  type PortfolioItem, type InsertPortfolioItem,
  type Transaction, type InsertTransaction,
  type Distribution, type InsertDistribution,
  type KycProfile, type SubmitKyc,
  type Document, type InsertDocument,
  type Notification, type InsertNotification,
  type AmlFlag, type InsertAmlFlag,
  type LegalDocument, type InsertLegalDocument,
  type LegalAcceptance, type InsertLegalAcceptance,
  type WalletAccount, type InsertWalletAccount,
  type WalletTransaction, type InsertWalletTransaction,
  type LedgerEntry, type InsertLedgerEntry,
  type BankAccount, type InsertBankAccount,
  type WithdrawalRequest, type InsertWithdrawalRequest,
  type FeeSchedule,
  type FeeType,
  type AppliedFee,
  type InsertAppliedFee,
  paymentIntents,
  type PaymentIntent,
  type InsertPaymentIntent,
  type PaymentIntentStatus,
  fxRates,
  type FxRate,
  type InsertFxRate,
  fxQuotes,
  type FxQuote,
  type InsertFxQuote,
  fxTransactions,
  type FxTransaction,
  type InsertFxTransaction,
  type UserCountryProfile,
  type InsertUserCountryProfile,
  receivingBankAccounts,
  type ReceivingBankAccount,
  type InsertReceivingBankAccount,
  exitWindows,
  type ExitWindow,
  type InsertExitWindow,
  exitWindowSchedules,
  type ExitWindowSchedule,
  type InsertExitWindowSchedule,
  tradeListings,
  type TradeListing,
  type InsertTradeListing,
  marketplaceCountrySettings,
  type MarketplaceCountrySetting,
  type InsertMarketplaceCountrySetting,
  fxSpreadConfigs,
  type FxSpreadConfig,
  type InsertFxSpreadConfig,
  fxConversionRequests,
  type FxConversionRequest,
  type InsertFxConversionRequest,
  cryptoWallets,
  type CryptoWallet,
  type InsertCryptoWallet,
  cryptoDepositIntents,
  type CryptoDepositIntent,
  type InsertCryptoDepositIntent,
  supportTickets,
  type SupportTicket,
  type InsertSupportTicket,
  rolePermissions,
  type RolePermission,
  type InsertRolePermission,
  spvEntities,
  type SpvEntity,
  type InsertSpvEntity,
  shareClasses,
  type ShareClass,
  type InsertShareClass,
  tokens,
  type Token,
  type InsertToken,
  tokenHoldings,
  type TokenHolding,
  type InsertTokenHolding,
  tokenTransfers,
  type TokenTransfer,
  type InsertTokenTransfer,
  tokenLedgerEntries,
  type TokenLedgerEntry,
  type InsertTokenLedgerEntry,
  tokenIssuances,
  type TokenIssuance,
  type InsertTokenIssuance,
  tokenCorporateActions,
  type TokenCorporateAction,
  type InsertTokenCorporateAction,
  rentCollections,
  type RentCollection,
  type InsertRentCollection,
  operatingExpenses,
  type OperatingExpense,
  type InsertOperatingExpense,
  distributionPayouts,
  type DistributionPayout,
  type InsertDistributionPayout,
  waterfallCalculations,
  type WaterfallCalculation,
  type InsertWaterfallCalculation,
  tokenCertificates,
  type TokenCertificate,
  type InsertTokenCertificate,
  documentIngestions,
  type DocumentIngestion,
  type InsertDocumentIngestion,
  investmentVehicles,
  type InvestmentVehicle,
  type InsertInvestmentVehicle,
  offerings,
  type Offering,
  type InsertOffering,
  commitments,
  type Commitment,
  type InsertCommitment,
  valuationUpdates,
  type ValuationUpdate,
  type InsertValuationUpdate,
  settlementJournal,
  type SettlementJournal,
  type InsertSettlementJournal,
  settlementDocuments,
  type SettlementDocument,
  type InsertSettlementDocument,
  propertyMilestones,
  type PropertyMilestone,
  type InsertPropertyMilestone,
  rentalContracts,
  type RentalContract,
  type InsertRentalContract,
  propertyManagers,
  type PropertyManager,
  type InsertPropertyManager,
  propertyExpenseCategories,
  type PropertyExpenseCategory,
  type InsertPropertyExpenseCategory,
  reserveFundEntries,
  type ReserveFundEntry,
  type InsertReserveFundEntry,
  distributionSnapshots,
  type DistributionSnapshot,
  type InsertDistributionSnapshot,
  auditLogs,
  type AuditLog,
  type InsertAuditLog,
  pushSubscriptions,
  type PushSubscription,
  type InsertPushSubscription,
  propertyAcquisitions,
  propertyUnits,
  propertyUnitLedger,
  type PropertyAcquisition,
  type InsertPropertyAcquisition,
  type PropertyUnit,
  type InsertPropertyUnit,
  type PropertyUnitLedger,
  type InsertPropertyUnitLedger,
  developerPaymentSchedule,
  type DeveloperPayment,
  type InsertDeveloperPayment,
  propertySaleEvents,
  type PropertySaleEvent,
  type InsertPropertySaleEvent,
  propertySalePayouts,
  type PropertySalePayout,
  type InsertPropertySalePayout,
} from "@shared/schema";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByGoogleId(googleId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserProfile(id: string, data: UpdateProfile): Promise<User | undefined>;
  updateNotificationPreferences(id: string, prefs: NotificationPreferences): Promise<User | undefined>;
  getUsers(tenantId?: string): Promise<User[]>;

  hasFinancialRecords(userId: string): Promise<boolean>;
  updateAccountStatus(userId: string, status: string, changedBy: string): Promise<User | undefined>;
  incrementTokenVersion(userId: string): Promise<User | undefined>;
  transferProjectOwnership(fromUserId: string, toUserId: string): Promise<number>;
  getActiveAdminUsers(): Promise<User[]>;
  getProjectsByCreator(userId: string): Promise<any[]>;
  getAuditLogsByEntity(entityType: string, entityId: string): Promise<any[]>;

  getAssets(tenantId?: string): Promise<Asset[]>;
  getAsset(id: string): Promise<Asset | undefined>;
  getAssetsByIssuer(issuerId: string): Promise<Asset[]>;
  createAsset(asset: InsertAsset): Promise<Asset>;
  updateAsset(id: string, data: Partial<InsertAsset>): Promise<Asset | undefined>;

  getRounds(tenantId?: string): Promise<Round[]>;
  getRoundsByAsset(assetId: string): Promise<Round[]>;
  createRound(round: InsertRound): Promise<Round>;
  updateRoundRaisedAmount(roundId: string, additionalAmount: string): Promise<Round | undefined>;

  getPortfolioItems(userId: string, tenantId?: string): Promise<PortfolioItem[]>;
  getPortfolioItem(userId: string, assetId: string): Promise<PortfolioItem | undefined>;
  createPortfolioItem(item: InsertPortfolioItem): Promise<PortfolioItem>;
  upsertPortfolioItem(userId: string, assetId: string, quantity: string, averageCost: string): Promise<PortfolioItem>;

  getTransactions(userId?: string, tenantId?: string): Promise<Transaction[]>;
  createTransaction(tx: InsertTransaction): Promise<Transaction>;

  getDistribution(id: string): Promise<Distribution | undefined>;
  getDistributions(tenantId?: string): Promise<Distribution[]>;
  getDistributionsByAsset(assetId: string): Promise<Distribution[]>;
  createDistribution(dist: InsertDistribution): Promise<Distribution>;

  createRentCollection(data: InsertRentCollection): Promise<RentCollection>;
  getRentCollectionsByAsset(assetId: string): Promise<RentCollection[]>;
  getRentCollectionsByPeriod(assetId: string, period: string): Promise<RentCollection[]>;
  getAllRentCollections(tenantId?: string): Promise<RentCollection[]>;

  createOperatingExpense(data: InsertOperatingExpense): Promise<OperatingExpense>;
  getOperatingExpensesByAsset(assetId: string): Promise<OperatingExpense[]>;
  getOperatingExpensesByPeriod(assetId: string, period: string): Promise<OperatingExpense[]>;
  getAllOperatingExpenses(tenantId?: string): Promise<OperatingExpense[]>;

  createDistributionSnapshot(data: InsertDistributionSnapshot): Promise<DistributionSnapshot>;
  getDistributionSnapshot(id: string): Promise<DistributionSnapshot | undefined>;
  getDistributionSnapshotsByAsset(assetId: string): Promise<DistributionSnapshot[]>;

  createDistributionPayout(data: InsertDistributionPayout): Promise<DistributionPayout>;
  getDistributionPayoutsByDistribution(distributionId: string): Promise<DistributionPayout[]>;
  getDistributionPayoutsByUser(userId: string): Promise<DistributionPayout[]>;

  createWaterfallCalculation(data: InsertWaterfallCalculation): Promise<WaterfallCalculation>;
  getWaterfallCalculation(id: string): Promise<WaterfallCalculation | undefined>;
  getWaterfallCalculationsByAsset(assetId: string): Promise<WaterfallCalculation[]>;
  getWaterfallCalculationsByPeriod(assetId: string, period: string): Promise<WaterfallCalculation[]>;

  createReserveFundEntry(data: InsertReserveFundEntry): Promise<ReserveFundEntry>;
  getReserveFundEntriesByAsset(assetId: string): Promise<ReserveFundEntry[]>;
  getReserveFundBalance(assetId: string): Promise<string>;

  createPropertyMilestone(data: InsertPropertyMilestone): Promise<PropertyMilestone>;
  getPropertyMilestonesByAsset(assetId: string): Promise<PropertyMilestone[]>;
  updatePropertyMilestone(id: string, data: Partial<InsertPropertyMilestone>): Promise<PropertyMilestone | undefined>;
  deletePropertyMilestone(id: string): Promise<boolean>;

  createRentalContract(data: InsertRentalContract): Promise<RentalContract>;
  getRentalContractsByAsset(assetId: string): Promise<RentalContract[]>;
  getAllRentalContracts(tenantId?: string): Promise<RentalContract[]>;
  updateRentalContract(id: string, data: Partial<InsertRentalContract>): Promise<RentalContract | undefined>;
  deleteRentalContract(id: string): Promise<boolean>;

  createPropertyManager(data: InsertPropertyManager): Promise<PropertyManager>;
  getAllPropertyManagers(tenantId?: string): Promise<PropertyManager[]>;
  updatePropertyManager(id: string, data: Partial<InsertPropertyManager>): Promise<PropertyManager | undefined>;
  deletePropertyManager(id: string): Promise<boolean>;

  createPropertyExpenseCategory(data: InsertPropertyExpenseCategory): Promise<PropertyExpenseCategory>;
  getAllPropertyExpenseCategories(tenantId?: string): Promise<PropertyExpenseCategory[]>;
  updatePropertyExpenseCategory(id: string, data: Partial<InsertPropertyExpenseCategory>): Promise<PropertyExpenseCategory | undefined>;
  deletePropertyExpenseCategory(id: string): Promise<boolean>;

  getKycProfile(userId: string): Promise<KycProfile | undefined>;
  getKycProfileById(id: string): Promise<KycProfile | undefined>;
  getAllKycProfiles(tenantId?: string): Promise<KycProfile[]>;
  createKycProfile(userId: string, data: SubmitKyc): Promise<KycProfile>;
  updateKycStatus(id: string, status: string, reviewNotes?: string): Promise<KycProfile | undefined>;

  createDocument(doc: InsertDocument): Promise<Document>;
  getDocumentsByKycProfile(kycProfileId: string): Promise<Document[]>;
  getDocumentsByOwner(ownerId: string): Promise<Document[]>;

  createNotification(notif: InsertNotification): Promise<Notification>;
  getNotifications(userId: string): Promise<Notification[]>;
  markNotificationRead(id: string): Promise<Notification | undefined>;
  markAllNotificationsRead(userId: string): Promise<void>;
  getUnreadNotificationCount(userId: string): Promise<number>;

  createPushSubscription(sub: InsertPushSubscription): Promise<PushSubscription>;
  getPushSubscriptionsByUser(userId: string): Promise<PushSubscription[]>;
  deletePushSubscription(endpoint: string): Promise<void>;
  deletePushSubscriptionsByUser(userId: string): Promise<void>;

  createAmlFlag(flag: InsertAmlFlag): Promise<AmlFlag>;
  getAmlFlagsByUser(userId: string): Promise<AmlFlag[]>;
  getActiveAmlFlagsByUser(userId: string): Promise<AmlFlag[]>;
  getAllAmlFlags(tenantId?: string): Promise<AmlFlag[]>;
  getAmlFlagById(id: string): Promise<AmlFlag | undefined>;
  resolveAmlFlag(id: string, resolvedBy: string, notes: string): Promise<AmlFlag | undefined>;
  updateUserEddStatus(userId: string, eddStatus: string): Promise<User | undefined>;

  getWalletAccountsByUser(userId: string): Promise<WalletAccount[]>;
  getWalletAccount(id: string): Promise<WalletAccount | undefined>;
  getWalletAccountByUserAndCurrency(userId: string, currency: string): Promise<WalletAccount | undefined>;
  createWalletAccount(account: InsertWalletAccount): Promise<WalletAccount>;
  getWalletTransactions(walletAccountId: string): Promise<WalletTransaction[]>;
  getWalletTransactionsByUser(userId: string): Promise<WalletTransaction[]>;
  getWalletTransactionById(id: string): Promise<WalletTransaction | undefined>;
  createWalletTransaction(tx: InsertWalletTransaction): Promise<WalletTransaction>;
  getComputedBalance(walletAccountId: string): Promise<{ available: string; pending: string }>;

  createLedgerEntries(entries: InsertLedgerEntry[]): Promise<LedgerEntry[]>;
  reverseLedgerEntries(ledgerTxId: string, reason: string): Promise<LedgerEntry[]>;
  getLedgerEntriesByAccount(walletAccountId: string): Promise<LedgerEntry[]>;
  getLedgerEntriesByTxId(ledgerTxId: string): Promise<LedgerEntry[]>;
  getLedgerEntriesByUser(userId: string): Promise<LedgerEntry[]>;
  getLedgerBalance(walletAccountId: string): Promise<{ available: string; pending: string; total: string }>;

  getBankAccountsByUser(userId: string): Promise<BankAccount[]>;
  getBankAccountById(id: string): Promise<BankAccount | undefined>;
  getAllBankAccounts(tenantId?: string): Promise<BankAccount[]>;
  createBankAccount(account: InsertBankAccount): Promise<BankAccount>;
  updateBankAccount(id: string, data: Partial<InsertBankAccount>): Promise<BankAccount | undefined>;
  verifyBankAccount(id: string, verifiedBy: string, status: string, notes?: string): Promise<BankAccount | undefined>;
  getVerifiedBankAccountsByUser(userId: string): Promise<BankAccount[]>;

  getActiveLegalDocuments(): Promise<LegalDocument[]>;
  getActiveLegalDocumentsByCountry(country: string): Promise<LegalDocument[]>;
  getActiveLegalDocsByJurisdictionProduct(jurisdiction: string, productType: string): Promise<LegalDocument[]>;
  getRequiredDocsForInvestment(assetCountry: string, vehicleType: string): Promise<LegalDocument[]>;
  hasAcceptedAllRequiredDocs(userId: string, docs: LegalDocument[]): Promise<{ allAccepted: boolean; pending: LegalDocument[] }>;
  getLegalDocumentById(id: string): Promise<LegalDocument | undefined>;
  getLegalDocumentByType(type: string): Promise<LegalDocument | undefined>;
  createLegalDocument(doc: InsertLegalDocument): Promise<LegalDocument>;
  getUserAcceptances(userId: string): Promise<LegalAcceptance[]>;
  createLegalAcceptance(acceptance: InsertLegalAcceptance): Promise<LegalAcceptance>;
  hasUserAcceptedDocument(userId: string, documentId: string): Promise<boolean>;

  createPaymentIntent(intent: InsertPaymentIntent): Promise<PaymentIntent>;
  getPaymentIntent(id: string): Promise<PaymentIntent | undefined>;
  getPaymentIntentsByUser(userId: string): Promise<PaymentIntent[]>;
  getAllPaymentIntents(tenantId?: string): Promise<PaymentIntent[]>;
  updatePaymentIntentStatus(id: string, status: PaymentIntentStatus, data?: Partial<PaymentIntent>): Promise<PaymentIntent | undefined>;

  getActiveFeeSchedule(feeType: FeeType, currency?: string, vehicleId?: string): Promise<FeeSchedule | undefined>;
  getAllFeeSchedules(): Promise<FeeSchedule[]>;
  getFeeScheduleById(id: string): Promise<FeeSchedule | undefined>;
  getFeeScheduleHistory(feeType: FeeType, currency?: string, vehicleId?: string): Promise<FeeSchedule[]>;
  getFeeSchedulesByVehicle(vehicleId: string): Promise<FeeSchedule[]>;
  createFeeSchedule(schedule: Partial<FeeSchedule>, createdBy: string): Promise<FeeSchedule>;
  deactivateFeeSchedule(id: string): Promise<FeeSchedule | undefined>;
  createAppliedFee(fee: InsertAppliedFee): Promise<AppliedFee>;
  getAppliedFeesByEntity(entityType: string, entityId: string): Promise<AppliedFee[]>;
  getAppliedFeesByVehicle(vehicleId: string): Promise<AppliedFee[]>;
  getAppliedFeesByUser(userId: string): Promise<AppliedFee[]>;
  getAllAppliedFees(limit?: number): Promise<AppliedFee[]>;

  getPropertyAcquisition(assetId: string): Promise<PropertyAcquisition | undefined>;
  createPropertyAcquisition(data: InsertPropertyAcquisition): Promise<PropertyAcquisition>;
  updatePropertyAcquisition(assetId: string, data: Partial<InsertPropertyAcquisition>): Promise<PropertyAcquisition | undefined>;
  getAllPropertyAcquisitions(tenantId?: string): Promise<PropertyAcquisition[]>;

  getPropertyUnit(assetId: string): Promise<PropertyUnit | undefined>;
  createPropertyUnit(data: InsertPropertyUnit): Promise<PropertyUnit>;
  updatePropertyUnit(assetId: string, data: Partial<InsertPropertyUnit>): Promise<PropertyUnit | undefined>;
  getAllPropertyUnits(tenantId?: string): Promise<PropertyUnit[]>;
  getPropertyUnitLedger(assetId: string): Promise<PropertyUnitLedger[]>;
  getPropertyUnitLedgerByUser(userId: string): Promise<PropertyUnitLedger[]>;
  createPropertyUnitLedgerEntry(data: InsertPropertyUnitLedger): Promise<PropertyUnitLedger>;

  getPropertySaleEvent(id: string): Promise<PropertySaleEvent | undefined>;
  getPropertySaleEventByAsset(assetId: string): Promise<PropertySaleEvent | undefined>;
  getAllPropertySaleEvents(tenantId?: string): Promise<PropertySaleEvent[]>;
  createPropertySaleEvent(data: InsertPropertySaleEvent): Promise<PropertySaleEvent>;
  updatePropertySaleEvent(id: string, data: Partial<InsertPropertySaleEvent>): Promise<PropertySaleEvent | undefined>;
  getPropertySalePayouts(saleEventId: string): Promise<PropertySalePayout[]>;
  getPropertySalePayoutsByUser(userId: string): Promise<PropertySalePayout[]>;
  createPropertySalePayout(data: InsertPropertySalePayout): Promise<PropertySalePayout>;

  getDeveloperPaymentsByAsset(assetId: string): Promise<DeveloperPayment[]>;
  createDeveloperPayment(data: InsertDeveloperPayment): Promise<DeveloperPayment>;
  updateDeveloperPayment(id: string, data: Partial<InsertDeveloperPayment>): Promise<DeveloperPayment | undefined>;
  deleteDeveloperPayment(id: string): Promise<boolean>;

  getActiveFxRate(fromCurrency: string, toCurrency: string): Promise<FxRate | undefined>;
  getAllFxRates(): Promise<FxRate[]>;
  getFxRateById(id: string): Promise<FxRate | undefined>;
  createFxRate(rate: InsertFxRate): Promise<FxRate>;
  updateFxRate(id: string, data: Partial<InsertFxRate>): Promise<FxRate | undefined>;
  getOrCreateWallet(userId: string, currency: string): Promise<WalletAccount>;
  deactivateFxRate(id: string): Promise<FxRate | undefined>;
  createFxQuote(quote: InsertFxQuote): Promise<FxQuote>;
  getFxQuoteById(id: string): Promise<FxQuote | undefined>;
  getAllFxQuotes(): Promise<FxQuote[]>;
  expireFxQuote(id: string): Promise<FxQuote | undefined>;
  createFxTransaction(tx: InsertFxTransaction): Promise<FxTransaction>;
  getFxTransactionById(id: string): Promise<FxTransaction | undefined>;
  getFxTransactionsByUser(userId: string): Promise<FxTransaction[]>;
  updateFxTransactionStatus(id: string, status: string): Promise<FxTransaction | undefined>;

  getCountryProfiles(userId: string): Promise<UserCountryProfile[]>;
  getCountryProfile(userId: string, countryCode: string): Promise<UserCountryProfile | undefined>;
  upsertCountryProfile(userId: string, data: InsertUserCountryProfile): Promise<UserCountryProfile>;
  deleteCountryProfile(userId: string, countryCode: string): Promise<boolean>;
  setPrimaryCountry(userId: string, countryCode: string): Promise<void>;

  getActiveReceivingBankAccounts(): Promise<ReceivingBankAccount[]>;
  getReceivingBankAccountByCurrency(currency: string): Promise<ReceivingBankAccount | undefined>;
  getReceivingBankAccountByCountryAndCurrency(countryCode: string, currency: string): Promise<ReceivingBankAccount | undefined>;
  getReceivingBankAccountById(id: string): Promise<ReceivingBankAccount | undefined>;
  getAllReceivingBankAccounts(): Promise<ReceivingBankAccount[]>;
  createReceivingBankAccount(account: InsertReceivingBankAccount): Promise<ReceivingBankAccount>;
  updateReceivingBankAccount(id: string, data: Partial<InsertReceivingBankAccount>): Promise<ReceivingBankAccount | undefined>;
  deactivateReceivingBankAccount(id: string): Promise<ReceivingBankAccount | undefined>;

  getExitWindows(): Promise<ExitWindow[]>;
  getExitWindowsByAsset(assetId: string): Promise<ExitWindow[]>;
  getExitWindowById(id: string): Promise<ExitWindow | undefined>;
  createExitWindow(ew: InsertExitWindow): Promise<ExitWindow>;
  updateExitWindowStatus(id: string, status: string): Promise<ExitWindow | undefined>;
  updateExitWindowRules(id: string, rules: { eligibleJurisdictions?: string[]; lockupDays?: number; cooldownHours?: number; maxParticipants?: number; minTradeAmount?: string; maxTradeAmount?: string }): Promise<ExitWindow | undefined>;
  getUniqueTraderCount(exitWindowId: string): Promise<number>;
  getLastTradeTimestamp(userId: string, exitWindowId: string): Promise<string | null>;

  getExitWindowSchedules(): Promise<ExitWindowSchedule[]>;
  getExitWindowSchedulesByAsset(assetId: string): Promise<ExitWindowSchedule[]>;
  getExitWindowScheduleById(id: string): Promise<ExitWindowSchedule | undefined>;
  createExitWindowSchedule(s: InsertExitWindowSchedule): Promise<ExitWindowSchedule>;
  updateExitWindowSchedule(id: string, data: Partial<InsertExitWindowSchedule>): Promise<ExitWindowSchedule | undefined>;
  deleteExitWindowSchedule(id: string): Promise<boolean>;

  getTradeListings(exitWindowId: string): Promise<TradeListing[]>;
  getActiveTradeListings(exitWindowId: string): Promise<TradeListing[]>;
  getTradeListingById(id: string): Promise<TradeListing | undefined>;
  getTradeListingsBySeller(sellerId: string): Promise<TradeListing[]>;
  createTradeListing(listing: InsertTradeListing): Promise<TradeListing>;
  updateTradeListing(id: string, data: Partial<TradeListing>): Promise<TradeListing | undefined>;

  getAllFxTransactions(tenantId?: string): Promise<FxTransaction[]>;

  getMarketplaceCountrySettings(): Promise<MarketplaceCountrySetting[]>;
  getVisibleMarketplaceCountries(): Promise<MarketplaceCountrySetting[]>;
  upsertMarketplaceCountrySetting(countryCode: string, isVisible: boolean, displayOrder?: number): Promise<MarketplaceCountrySetting>;

  getFxSpreadConfigs(): Promise<FxSpreadConfig[]>;
  getActiveFxSpreadConfig(fromCurrency: string, toCurrency: string): Promise<FxSpreadConfig | undefined>;
  getFxSpreadConfigById(id: string): Promise<FxSpreadConfig | undefined>;
  createFxSpreadConfig(config: InsertFxSpreadConfig): Promise<FxSpreadConfig>;
  updateFxSpreadConfig(id: string, data: Partial<InsertFxSpreadConfig>): Promise<FxSpreadConfig | undefined>;
  deactivateFxSpreadConfig(id: string): Promise<FxSpreadConfig | undefined>;

  createFxConversionRequest(req: InsertFxConversionRequest): Promise<FxConversionRequest>;
  getFxConversionRequests(status?: string): Promise<FxConversionRequest[]>;
  getFxConversionRequestById(id: string): Promise<FxConversionRequest | undefined>;
  getFxConversionRequestByQuoteId(quoteId: string): Promise<FxConversionRequest | undefined>;
  updateFxConversionRequestStatus(id: string, status: string, reviewedBy: string, reviewNotes?: string): Promise<FxConversionRequest | undefined>;

  updateUserTier(userId: string, tier: string): Promise<User | undefined>;
  updateUser(userId: string, data: Partial<Record<string, string | null>>): Promise<User | undefined>;

  getCryptoWalletsByUser(userId: string): Promise<CryptoWallet[]>;
  getAllCryptoWallets(tenantId?: string): Promise<CryptoWallet[]>;
  getCryptoWalletById(id: string): Promise<CryptoWallet | undefined>;
  createCryptoWallet(wallet: InsertCryptoWallet): Promise<CryptoWallet>;
  deleteCryptoWallet(id: string): Promise<boolean>;
  blacklistCryptoWallet(id: string, blacklistedBy: string, reason: string): Promise<CryptoWallet | undefined>;
  unblacklistCryptoWallet(id: string): Promise<CryptoWallet | undefined>;
  updateCryptoWalletAdminNotes(id: string, notes: string): Promise<CryptoWallet | undefined>;

  createCryptoDepositIntent(intent: InsertCryptoDepositIntent): Promise<CryptoDepositIntent>;
  getCryptoDepositIntentsByUser(userId: string): Promise<CryptoDepositIntent[]>;
  getAllCryptoDepositIntents(tenantId?: string): Promise<CryptoDepositIntent[]>;
  getCryptoDepositIntentById(id: string): Promise<CryptoDepositIntent | undefined>;
  updateCryptoDepositIntent(id: string, data: Partial<CryptoDepositIntent>): Promise<CryptoDepositIntent | undefined>;
  getRecentCryptoDeposits(userId: string, since: string): Promise<CryptoDepositIntent[]>;

  createSupportTicket(ticket: InsertSupportTicket): Promise<SupportTicket>;
  getSupportTicketsByUser(userId: string): Promise<SupportTicket[]>;
  getAllSupportTickets(tenantId?: string): Promise<SupportTicket[]>;
  getSupportTicketById(id: string): Promise<SupportTicket | undefined>;
  updateSupportTicket(id: string, data: Partial<SupportTicket>): Promise<SupportTicket | undefined>;

  getRolePermissions(role: string): Promise<RolePermission[]>;
  getAllRolePermissions(): Promise<RolePermission[]>;
  setRolePermissions(role: string, permissions: string[], grantedBy: string): Promise<RolePermission[]>;
  addRolePermission(data: InsertRolePermission): Promise<RolePermission>;
  removeRolePermission(role: string, permission: string): Promise<boolean>;
  hasPermission(role: string, permission: string): Promise<boolean>;

  createSpvEntity(data: InsertSpvEntity): Promise<SpvEntity>;
  getSpvEntity(id: string): Promise<SpvEntity | undefined>;
  getSpvEntitiesByAsset(assetId: string): Promise<SpvEntity[]>;
  getAllSpvEntities(tenantId?: string): Promise<SpvEntity[]>;

  createShareClass(data: InsertShareClass): Promise<ShareClass>;
  getShareClass(id: string): Promise<ShareClass | undefined>;
  getShareClassesBySpv(spvId: string): Promise<ShareClass[]>;
  getAllShareClasses(tenantId?: string): Promise<ShareClass[]>;

  createToken(data: InsertToken): Promise<Token>;
  getToken(id: string): Promise<Token | undefined>;
  getTokensByShareClass(shareClassId: string): Promise<Token[]>;
  getAllTokens(tenantId?: string): Promise<Token[]>;
  updateTokenFrozen(id: string, frozen: boolean): Promise<Token | undefined>;
  getTokenByAssetId(assetId: string): Promise<Token | undefined>;
  getTokensByVehicle(vehicleId: string): Promise<Token[]>;

  getTokenHolding(userId: string, tokenId: string): Promise<TokenHolding | undefined>;
  getTokenHoldingsByUser(userId: string): Promise<TokenHolding[]>;
  getTokenHoldingsByToken(tokenId: string): Promise<TokenHolding[]>;
  upsertTokenHolding(userId: string, tokenId: string, balance: string): Promise<TokenHolding>;

  createTokenTransfer(data: InsertTokenTransfer): Promise<TokenTransfer>;
  getTokenTransfer(id: string): Promise<TokenTransfer | undefined>;
  getTokenTransfersByUser(userId: string): Promise<TokenTransfer[]>;
  getTokenTransfersByToken(tokenId: string): Promise<TokenTransfer[]>;
  updateTokenTransferStatus(id: string, status: string): Promise<TokenTransfer | undefined>;

  createTokenLedgerEntry(data: InsertTokenLedgerEntry): Promise<TokenLedgerEntry>;
  getTokenLedgerEntriesByToken(tokenId: string): Promise<TokenLedgerEntry[]>;
  getTokenLedgerEntriesByUser(userId: string): Promise<TokenLedgerEntry[]>;
  computeTokenBalanceFromLedger(userId: string, tokenId: string): Promise<string>;
  getTokenIssuancesByOffering(offeringId: string): Promise<TokenIssuance[]>;

  updateTokenTotalSupply(id: string, totalSupply: string): Promise<Token | undefined>;
  updateToken(id: string, data: Partial<{ frozen: boolean; transferRestrictions: any }>): Promise<Token | undefined>;

  updateRoundStatus(roundId: string, status: string): Promise<Round | undefined>;
  updateShareClassTotalSupply(id: string, totalSupply: string): Promise<ShareClass | undefined>;

  createTokenIssuance(data: InsertTokenIssuance): Promise<TokenIssuance>;
  getTokenIssuancesByRound(roundId: string): Promise<TokenIssuance[]>;
  getTokenIssuancesByAsset(assetId: string): Promise<TokenIssuance[]>;
  getAllTokenIssuances(tenantId?: string): Promise<TokenIssuance[]>;

  createTokenCorporateAction(data: InsertTokenCorporateAction): Promise<TokenCorporateAction>;
  getTokenCorporateActionsByToken(tokenId: string): Promise<TokenCorporateAction[]>;
  getAllTokenCorporateActions(tenantId?: string): Promise<TokenCorporateAction[]>;

  createTokenCertificate(data: InsertTokenCertificate): Promise<TokenCertificate>;
  getTokenCertificatesByUser(userId: string): Promise<TokenCertificate[]>;
  getTokenCertificate(id: string): Promise<TokenCertificate | undefined>;

  createDocumentIngestion(data: InsertDocumentIngestion): Promise<DocumentIngestion>;
  getDocumentIngestion(id: string): Promise<DocumentIngestion | undefined>;
  getDocumentIngestionsByUser(userId: string): Promise<DocumentIngestion[]>;
  getDocumentIngestionsByDocument(documentId: string): Promise<DocumentIngestion[]>;
  getAllDocumentIngestions(tenantId?: string): Promise<DocumentIngestion[]>;
  updateDocumentIngestion(id: string, data: Partial<DocumentIngestion>): Promise<DocumentIngestion | undefined>;

  createInvestmentVehicle(data: InsertInvestmentVehicle): Promise<InvestmentVehicle>;
  getInvestmentVehicle(id: string): Promise<InvestmentVehicle | undefined>;
  getAllInvestmentVehicles(tenantId?: string): Promise<InvestmentVehicle[]>;
  updateInvestmentVehicle(id: string, data: Partial<InsertInvestmentVehicle>): Promise<InvestmentVehicle | undefined>;
  updateInvestmentVehicleStatus(id: string, status: string): Promise<InvestmentVehicle | undefined>;
  getAssetsByVehicle(vehicleId: string): Promise<Asset[]>;
  attachAssetToVehicle(assetId: string, vehicleId: string): Promise<Asset | undefined>;
  detachAssetFromVehicle(assetId: string): Promise<Asset | undefined>;

  createOffering(data: InsertOffering): Promise<Offering>;
  getOffering(id: string): Promise<Offering | undefined>;
  getAllOfferings(tenantId?: string): Promise<Offering[]>;
  getOfferingsByVehicle(vehicleId: string): Promise<Offering[]>;
  updateOffering(id: string, data: Partial<InsertOffering>): Promise<Offering | undefined>;
  updateOfferingStatus(id: string, status: string): Promise<Offering | undefined>;
  updateOfferingTotalCommitted(id: string, additionalAmount: string): Promise<Offering | undefined>;
  atomicAddToOfferingCommitted(id: string, additionalAmount: string, targetAmount: string): Promise<Offering | undefined>;
  getOpenOfferings(): Promise<Offering[]>;

  createCommitment(data: InsertCommitment): Promise<Commitment>;
  getCommitment(id: string): Promise<Commitment | undefined>;
  getCommitmentsByOffering(offeringId: string): Promise<Commitment[]>;
  getCommitmentsByUser(userId: string): Promise<Commitment[]>;
  updateCommitmentStatus(id: string, status: string): Promise<Commitment | undefined>;
  updateCommitment(id: string, data: Partial<InsertCommitment>): Promise<Commitment | undefined>;
  getActiveCommitmentsByOffering(offeringId: string): Promise<Commitment[]>;

  createValuationUpdate(data: InsertValuationUpdate): Promise<ValuationUpdate>;
  getValuationUpdate(id: string): Promise<ValuationUpdate | undefined>;
  getValuationsByAsset(assetId: string): Promise<ValuationUpdate[]>;
  getLatestValuation(assetId: string): Promise<ValuationUpdate | undefined>;

  createSettlementEntry(data: InsertSettlementJournal): Promise<SettlementJournal>;
  getSettlementEntry(id: string): Promise<SettlementJournal | undefined>;
  getSettlementsByAsset(assetId: string): Promise<SettlementJournal[]>;
  getSettlementsByUser(userId: string): Promise<SettlementJournal[]>;
  getSettlementsByState(state: string): Promise<SettlementJournal[]>;
  getAllSettlements(tenantId?: string): Promise<SettlementJournal[]>;
  getSettlementsByReference(referenceId: string): Promise<SettlementJournal[]>;
  advanceSettlement(id: string, data: { state: string; previousState: string; notes?: string; proofDocumentUrl?: string; advancedBy: string; advancedAt: string }): Promise<SettlementJournal | undefined>;
  createSettlementDocument(data: InsertSettlementDocument): Promise<SettlementDocument>;
  getSettlementDocuments(settlementJournalId: string): Promise<SettlementDocument[]>;

  checkDatabaseHealth(): Promise<{
    drizzleConnected: boolean;
    prismaConnected: boolean;
    userCount: number;
    assetCount: number;
    tableCount: number;
  }>;

  createAuditLog(data: InsertAuditLog): Promise<AuditLog>;
  searchAuditLogs(filters: {
    actorId?: string;
    actionType?: string;
    entityType?: string;
    entityId?: string;
    from?: string;
    to?: string;
    search?: string;
    limit?: number;
    offset?: number;
  }): Promise<{ logs: AuditLog[]; total: number }>;

  getTenants(): Promise<Tenant[]>;
  getActiveTenants(): Promise<Tenant[]>;
  getTenant(id: string): Promise<Tenant | undefined>;
  getTenantBySlug(slug: string): Promise<Tenant | undefined>;
  createTenant(data: InsertTenant): Promise<Tenant>;
  updateTenant(id: string, data: Partial<InsertTenant>): Promise<Tenant | undefined>;

  getTenantUsers(tenantId: string): Promise<TenantUser[]>;
  getTenantUser(tenantId: string, userId: string): Promise<TenantUser | undefined>;
  createTenantUser(data: InsertTenantUser): Promise<TenantUser>;
  updateTenantUser(tenantId: string, userId: string, data: Partial<{ role: string; status: string }>): Promise<TenantUser | undefined>;
  removeTenantUser(tenantId: string, userId: string): Promise<boolean>;
  getUserTenants(userId: string): Promise<TenantUser[]>;

  createImpersonationLog(data: InsertImpersonationLog): Promise<ImpersonationLog>;
  getImpersonationLogs(limit?: number): Promise<ImpersonationLog[]>;
  getTenantUserCount(tenantId: string): Promise<number>;

  getLockupRules(tenantId?: string): Promise<LockupRule[]>;
  getLockupRuleByAsset(assetId: string): Promise<LockupRule | undefined>;
  createLockupRule(data: InsertLockupRule): Promise<LockupRule>;
  updateLockupRule(id: string, data: Partial<InsertLockupRule>): Promise<LockupRule | undefined>;
  deleteLockupRule(id: string): Promise<boolean>;

  createSession(data: InsertSession): Promise<Session>;
  getSessionByToken(token: string): Promise<Session | undefined>;
  revokeSession(id: string): Promise<void>;
  revokeUserSessions(userId: string): Promise<void>;
  getActiveSessions(userId: string): Promise<Session[]>;
  cleanExpiredSessions(): Promise<number>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async getUserByGoogleId(googleId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.googleId, googleId));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [created] = await db.insert(users).values(user).returning();
    return created;
  }

  async updateUserProfile(id: string, data: UpdateProfile): Promise<User | undefined> {
    const [updated] = await db.update(users).set(data).where(eq(users.id, id)).returning();
    return updated;
  }

  async updateNotificationPreferences(id: string, prefs: NotificationPreferences): Promise<User | undefined> {
    const [updated] = await db.update(users).set({ notificationPreferences: prefs }).where(eq(users.id, id)).returning();
    return updated;
  }

  async getUsers(tenantId?: string): Promise<User[]> {
    if (tenantId) {
      return db.select().from(users).where(eq(users.tenantId, tenantId));
    }
    return db.select().from(users);
  }

  async getAssets(tenantId?: string): Promise<Asset[]> {
    if (tenantId) {
      return db.select().from(assets).where(eq(assets.tenantId, tenantId));
    }
    return db.select().from(assets);
  }

  async getAsset(id: string): Promise<Asset | undefined> {
    const [asset] = await db.select().from(assets).where(eq(assets.id, id));
    return asset;
  }

  async getAssetsByIssuer(issuerId: string): Promise<Asset[]> {
    return db.select().from(assets).where(eq(assets.issuerId, issuerId));
  }

  async createAsset(asset: InsertAsset): Promise<Asset> {
    const data = { ...asset };
    if (!data.country && data.baseCurrency) {
      data.country = CURRENCY_TO_COUNTRY[data.baseCurrency as keyof typeof CURRENCY_TO_COUNTRY] || "AE";
    }
    const [created] = await db.insert(assets).values(data).returning();
    return created;
  }

  async updateAsset(id: string, data: Partial<InsertAsset>): Promise<Asset | undefined> {
    const [updated] = await db.update(assets).set(data).where(eq(assets.id, id)).returning();
    return updated;
  }

  async getRounds(tenantId?: string): Promise<Round[]> {
    if (tenantId) {
      return db.select().from(rounds).where(eq(rounds.tenantId, tenantId));
    }
    return db.select().from(rounds);
  }

  async getRoundsByAsset(assetId: string): Promise<Round[]> {
    return db.select().from(rounds).where(eq(rounds.assetId, assetId));
  }

  async createRound(round: InsertRound): Promise<Round> {
    const [created] = await db.insert(rounds).values(round).returning();
    return created;
  }

  async updateRoundRaisedAmount(roundId: string, additionalAmount: string): Promise<Round | undefined> {
    const [existing] = await db.select().from(rounds).where(eq(rounds.id, roundId));
    if (!existing) return undefined;
    const newRaised = (parseFloat(existing.raisedAmount) + parseFloat(additionalAmount)).toFixed(2);
    const [updated] = await db.update(rounds)
      .set({ raisedAmount: newRaised })
      .where(eq(rounds.id, roundId))
      .returning();
    return updated;
  }

  async getPortfolioItems(userId: string, tenantId?: string): Promise<PortfolioItem[]> {
    const conditions = [eq(portfolioItems.userId, userId)];
    if (tenantId) conditions.push(eq(portfolioItems.tenantId, tenantId));
    return db.select().from(portfolioItems).where(and(...conditions));
  }

  async getPortfolioItem(userId: string, assetId: string): Promise<PortfolioItem | undefined> {
    const [item] = await db.select().from(portfolioItems)
      .where(and(eq(portfolioItems.userId, userId), eq(portfolioItems.assetId, assetId)));
    return item;
  }

  async createPortfolioItem(item: InsertPortfolioItem): Promise<PortfolioItem> {
    const [created] = await db.insert(portfolioItems).values(item).returning();
    return created;
  }

  async upsertPortfolioItem(userId: string, assetId: string, quantity: string, averageCost: string): Promise<PortfolioItem> {
    const existing = await this.getPortfolioItem(userId, assetId);
    if (existing) {
      const oldQty = parseFloat(existing.quantity);
      const oldCost = parseFloat(existing.averageCost);
      const newQty = parseFloat(quantity);
      const newCost = parseFloat(averageCost);
      const totalQty = oldQty + newQty;
      const weightedAvgCost = totalQty > 0 ? ((oldQty * oldCost + newQty * newCost) / totalQty) : newCost;
      const [updated] = await db.update(portfolioItems)
        .set({
          quantity: totalQty.toFixed(6),
          averageCost: weightedAvgCost.toFixed(6),
        })
        .where(eq(portfolioItems.id, existing.id))
        .returning();
      return updated;
    }
    return this.createPortfolioItem({ userId, assetId, quantity, averageCost });
  }

  async getTransactions(userId?: string, tenantId?: string): Promise<Transaction[]> {
    const conditions = [];
    if (userId) conditions.push(eq(transactions.userId, userId));
    if (tenantId) conditions.push(eq(transactions.tenantId, tenantId));
    if (conditions.length > 0) {
      return db.select().from(transactions).where(and(...conditions));
    }
    return db.select().from(transactions);
  }

  async createTransaction(tx: InsertTransaction): Promise<Transaction> {
    const [created] = await db.insert(transactions).values(tx).returning();
    return created;
  }

  async getTransaction(id: string): Promise<Transaction | undefined> {
    const [tx] = await db.select().from(transactions).where(eq(transactions.id, id));
    return tx;
  }

  async getDistribution(id: string): Promise<Distribution | undefined> {
    const [dist] = await db.select().from(distributions).where(eq(distributions.id, id));
    return dist;
  }

  async getDistributions(tenantId?: string): Promise<Distribution[]> {
    if (tenantId) {
      return db.select().from(distributions).where(eq(distributions.tenantId, tenantId));
    }
    return db.select().from(distributions);
  }

  async getDistributionsByAsset(assetId: string): Promise<Distribution[]> {
    return db.select().from(distributions).where(eq(distributions.assetId, assetId)).orderBy(desc(distributions.distributionDate));
  }

  async createDistribution(dist: InsertDistribution): Promise<Distribution> {
    const [created] = await db.insert(distributions).values(dist).returning();
    return created;
  }

  async createRentCollection(data: InsertRentCollection): Promise<RentCollection> {
    const [created] = await db.insert(rentCollections).values(data).returning();
    return created;
  }

  async getRentCollectionsByAsset(assetId: string): Promise<RentCollection[]> {
    return db.select().from(rentCollections)
      .where(eq(rentCollections.assetId, assetId))
      .orderBy(desc(rentCollections.createdAt));
  }

  async getRentCollectionsByPeriod(assetId: string, period: string): Promise<RentCollection[]> {
    return db.select().from(rentCollections)
      .where(and(eq(rentCollections.assetId, assetId), eq(rentCollections.period, period)))
      .orderBy(desc(rentCollections.createdAt));
  }

  async getAllRentCollections(tenantId?: string): Promise<RentCollection[]> {
    if (tenantId) {
      return db.select().from(rentCollections).where(eq(rentCollections.tenantId, tenantId)).orderBy(desc(rentCollections.createdAt));
    }
    return db.select().from(rentCollections).orderBy(desc(rentCollections.createdAt));
  }

  async createOperatingExpense(data: InsertOperatingExpense): Promise<OperatingExpense> {
    const [created] = await db.insert(operatingExpenses).values(data).returning();
    return created;
  }

  async getOperatingExpensesByAsset(assetId: string): Promise<OperatingExpense[]> {
    return db.select().from(operatingExpenses)
      .where(eq(operatingExpenses.assetId, assetId))
      .orderBy(desc(operatingExpenses.createdAt));
  }

  async getOperatingExpensesByPeriod(assetId: string, period: string): Promise<OperatingExpense[]> {
    return db.select().from(operatingExpenses)
      .where(and(eq(operatingExpenses.assetId, assetId), eq(operatingExpenses.period, period)))
      .orderBy(desc(operatingExpenses.createdAt));
  }

  async getAllOperatingExpenses(tenantId?: string): Promise<OperatingExpense[]> {
    if (tenantId) {
      return db.select().from(operatingExpenses).where(eq(operatingExpenses.tenantId, tenantId)).orderBy(desc(operatingExpenses.createdAt));
    }
    return db.select().from(operatingExpenses).orderBy(desc(operatingExpenses.createdAt));
  }

  async createDistributionSnapshot(data: InsertDistributionSnapshot): Promise<DistributionSnapshot> {
    const [created] = await db.insert(distributionSnapshots).values(data).returning();
    return created;
  }

  async getDistributionSnapshot(id: string): Promise<DistributionSnapshot | undefined> {
    const [snap] = await db.select().from(distributionSnapshots).where(eq(distributionSnapshots.id, id));
    return snap;
  }

  async getDistributionSnapshotsByAsset(assetId: string): Promise<DistributionSnapshot[]> {
    return db.select().from(distributionSnapshots)
      .where(eq(distributionSnapshots.assetId, assetId))
      .orderBy(desc(distributionSnapshots.createdAt));
  }

  async createDistributionPayout(data: InsertDistributionPayout): Promise<DistributionPayout> {
    const [created] = await db.insert(distributionPayouts).values(data).returning();
    return created;
  }

  async getDistributionPayoutsByDistribution(distributionId: string): Promise<DistributionPayout[]> {
    return db.select().from(distributionPayouts)
      .where(eq(distributionPayouts.distributionId, distributionId))
      .orderBy(desc(distributionPayouts.createdAt));
  }

  async getDistributionPayoutsByUser(userId: string): Promise<DistributionPayout[]> {
    return db.select().from(distributionPayouts)
      .where(eq(distributionPayouts.userId, userId))
      .orderBy(desc(distributionPayouts.createdAt));
  }

  async createWaterfallCalculation(data: InsertWaterfallCalculation): Promise<WaterfallCalculation> {
    const [created] = await db.insert(waterfallCalculations).values(data).returning();
    return created;
  }

  async getWaterfallCalculation(id: string): Promise<WaterfallCalculation | undefined> {
    const [calc] = await db.select().from(waterfallCalculations).where(eq(waterfallCalculations.id, id));
    return calc;
  }

  async getWaterfallCalculationsByAsset(assetId: string): Promise<WaterfallCalculation[]> {
    return db.select().from(waterfallCalculations)
      .where(eq(waterfallCalculations.assetId, assetId))
      .orderBy(desc(waterfallCalculations.createdAt));
  }

  async getWaterfallCalculationsByPeriod(assetId: string, period: string): Promise<WaterfallCalculation[]> {
    return db.select().from(waterfallCalculations)
      .where(and(eq(waterfallCalculations.assetId, assetId), eq(waterfallCalculations.period, period)))
      .orderBy(desc(waterfallCalculations.createdAt));
  }

  async createReserveFundEntry(data: InsertReserveFundEntry): Promise<ReserveFundEntry> {
    const [created] = await db.insert(reserveFundEntries).values(data).returning();
    return created;
  }

  async getReserveFundEntriesByAsset(assetId: string): Promise<ReserveFundEntry[]> {
    return db.select().from(reserveFundEntries)
      .where(eq(reserveFundEntries.assetId, assetId))
      .orderBy(desc(reserveFundEntries.createdAt));
  }

  async getReserveFundBalance(assetId: string): Promise<string> {
    const entries = await db.select().from(reserveFundEntries)
      .where(eq(reserveFundEntries.assetId, assetId));
    const balance = entries.reduce((sum, e) => {
      const amount = parseFloat(e.amount);
      return e.entryType === "CREDIT" ? sum + amount : sum - amount;
    }, 0);
    return balance.toFixed(2);
  }

  async createPropertyMilestone(data: InsertPropertyMilestone): Promise<PropertyMilestone> {
    const [created] = await db.insert(propertyMilestones).values(data).returning();
    return created;
  }

  async getPropertyMilestonesByAsset(assetId: string): Promise<PropertyMilestone[]> {
    return db.select().from(propertyMilestones)
      .where(eq(propertyMilestones.assetId, assetId))
      .orderBy(propertyMilestones.sortOrder);
  }

  async updatePropertyMilestone(id: string, data: Partial<InsertPropertyMilestone>): Promise<PropertyMilestone | undefined> {
    const [updated] = await db.update(propertyMilestones)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(propertyMilestones.id, id))
      .returning();
    return updated;
  }

  async deletePropertyMilestone(id: string): Promise<boolean> {
    const [deleted] = await db.delete(propertyMilestones).where(eq(propertyMilestones.id, id)).returning();
    return !!deleted;
  }

  async createRentalContract(data: InsertRentalContract): Promise<RentalContract> {
    const [created] = await db.insert(rentalContracts).values(data).returning();
    return created;
  }

  async getRentalContractsByAsset(assetId: string): Promise<RentalContract[]> {
    return db.select().from(rentalContracts)
      .where(eq(rentalContracts.assetId, assetId))
      .orderBy(desc(rentalContracts.createdAt));
  }

  async getAllRentalContracts(tenantId?: string): Promise<RentalContract[]> {
    if (tenantId) {
      return db.select().from(rentalContracts).where(eq(rentalContracts.tenantId, tenantId)).orderBy(desc(rentalContracts.createdAt));
    }
    return db.select().from(rentalContracts).orderBy(desc(rentalContracts.createdAt));
  }

  async updateRentalContract(id: string, data: Partial<InsertRentalContract>): Promise<RentalContract | undefined> {
    const [updated] = await db.update(rentalContracts)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(rentalContracts.id, id))
      .returning();
    return updated;
  }

  async deleteRentalContract(id: string): Promise<boolean> {
    const [deleted] = await db.delete(rentalContracts).where(eq(rentalContracts.id, id)).returning();
    return !!deleted;
  }

  async createPropertyManager(data: InsertPropertyManager): Promise<PropertyManager> {
    const [created] = await db.insert(propertyManagers).values(data).returning();
    return created;
  }

  async getAllPropertyManagers(tenantId?: string): Promise<PropertyManager[]> {
    if (tenantId) {
      return db.select().from(propertyManagers).where(eq(propertyManagers.tenantId, tenantId)).orderBy(desc(propertyManagers.createdAt));
    }
    return db.select().from(propertyManagers).orderBy(desc(propertyManagers.createdAt));
  }

  async updatePropertyManager(id: string, data: Partial<InsertPropertyManager>): Promise<PropertyManager | undefined> {
    const [updated] = await db.update(propertyManagers)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(propertyManagers.id, id))
      .returning();
    return updated;
  }

  async deletePropertyManager(id: string): Promise<boolean> {
    const [deleted] = await db.delete(propertyManagers).where(eq(propertyManagers.id, id)).returning();
    return !!deleted;
  }

  async createPropertyExpenseCategory(data: InsertPropertyExpenseCategory): Promise<PropertyExpenseCategory> {
    const [created] = await db.insert(propertyExpenseCategories).values(data).returning();
    return created;
  }

  async getAllPropertyExpenseCategories(tenantId?: string): Promise<PropertyExpenseCategory[]> {
    if (tenantId) {
      return db.select().from(propertyExpenseCategories).where(eq(propertyExpenseCategories.tenantId, tenantId)).orderBy(propertyExpenseCategories.name);
    }
    return db.select().from(propertyExpenseCategories).orderBy(propertyExpenseCategories.name);
  }

  async updatePropertyExpenseCategory(id: string, data: Partial<InsertPropertyExpenseCategory>): Promise<PropertyExpenseCategory | undefined> {
    const [updated] = await db.update(propertyExpenseCategories)
      .set(data)
      .where(eq(propertyExpenseCategories.id, id))
      .returning();
    return updated;
  }

  async deletePropertyExpenseCategory(id: string): Promise<boolean> {
    const [deleted] = await db.delete(propertyExpenseCategories).where(eq(propertyExpenseCategories.id, id)).returning();
    return !!deleted;
  }

  async getKycProfile(userId: string): Promise<KycProfile | undefined> {
    const [profile] = await db.select().from(kycProfiles).where(eq(kycProfiles.userId, userId)).orderBy(desc(kycProfiles.submittedAt)).limit(1);
    return profile;
  }

  async createKycProfile(userId: string, data: SubmitKyc): Promise<KycProfile> {
    const [created] = await db.insert(kycProfiles).values({
      userId,
      legalName: data.legalName,
      dob: data.dob,
      address: data.address,
      idType: data.idType,
      idNumber: data.idNumber,
      emiratesIdFlag: data.emiratesIdFlag,
      sourceOfWealth: data.sourceOfWealth,
      sourceOfFunds: data.sourceOfFunds,
      pepFlag: data.pepFlag,
      status: "IN_REVIEW",
      submittedAt: new Date().toISOString(),
    }).returning();
    return created;
  }

  async getKycProfileById(id: string): Promise<KycProfile | undefined> {
    const [profile] = await db.select().from(kycProfiles).where(eq(kycProfiles.id, id));
    return profile;
  }

  async getAllKycProfiles(tenantId?: string): Promise<KycProfile[]> {
    if (tenantId) {
      return db.select().from(kycProfiles).where(eq(kycProfiles.tenantId, tenantId)).orderBy(desc(kycProfiles.submittedAt));
    }
    return db.select().from(kycProfiles).orderBy(desc(kycProfiles.submittedAt));
  }

  async updateKycStatus(id: string, status: string, reviewNotes?: string): Promise<KycProfile | undefined> {
    const [updated] = await db.update(kycProfiles).set({
      status,
      reviewedAt: new Date().toISOString(),
      reviewNotes: reviewNotes || null,
    }).where(eq(kycProfiles.id, id)).returning();
    return updated;
  }

  async createDocument(doc: InsertDocument): Promise<Document> {
    const [created] = await db.insert(documents).values(doc).returning();
    return created;
  }

  async getDocumentsByKycProfile(kycProfileId: string): Promise<Document[]> {
    return db.select().from(documents).where(eq(documents.kycProfileId, kycProfileId)).orderBy(desc(documents.createdAt));
  }

  async getDocumentsByOwner(ownerId: string): Promise<Document[]> {
    return db.select().from(documents).where(eq(documents.ownerId, ownerId)).orderBy(desc(documents.createdAt));
  }

  async createNotification(notif: InsertNotification): Promise<Notification> {
    const [created] = await db.insert(notifications).values(notif).returning();
    return created;
  }

  async getNotifications(userId: string): Promise<Notification[]> {
    return db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.createdAt));
  }

  async markNotificationRead(id: string): Promise<Notification | undefined> {
    const [updated] = await db.update(notifications).set({ read: true }).where(eq(notifications.id, id)).returning();
    return updated;
  }

  async markAllNotificationsRead(userId: string): Promise<void> {
    await db.update(notifications).set({ read: true }).where(and(eq(notifications.userId, userId), eq(notifications.read, false)));
  }

  async getUnreadNotificationCount(userId: string): Promise<number> {
    const result = await db.select().from(notifications).where(eq(notifications.userId, userId));
    return result.filter(n => !n.read).length;
  }

  async createPushSubscription(sub: InsertPushSubscription): Promise<PushSubscription> {
    await db.delete(pushSubscriptions).where(eq(pushSubscriptions.endpoint, sub.endpoint));
    const [created] = await db.insert(pushSubscriptions).values(sub).returning();
    return created;
  }

  async getPushSubscriptionsByUser(userId: string): Promise<PushSubscription[]> {
    return db.select().from(pushSubscriptions).where(eq(pushSubscriptions.userId, userId));
  }

  async deletePushSubscription(endpoint: string): Promise<void> {
    await db.delete(pushSubscriptions).where(eq(pushSubscriptions.endpoint, endpoint));
  }

  async deletePushSubscriptionsByUser(userId: string): Promise<void> {
    await db.delete(pushSubscriptions).where(eq(pushSubscriptions.userId, userId));
  }

  async createAmlFlag(flag: InsertAmlFlag): Promise<AmlFlag> {
    const [created] = await db.insert(amlFlags).values(flag).returning();
    return created;
  }

  async getAmlFlagsByUser(userId: string): Promise<AmlFlag[]> {
    return db.select().from(amlFlags).where(eq(amlFlags.userId, userId)).orderBy(desc(amlFlags.createdAt));
  }

  async getActiveAmlFlagsByUser(userId: string): Promise<AmlFlag[]> {
    const all = await db.select().from(amlFlags).where(eq(amlFlags.userId, userId)).orderBy(desc(amlFlags.createdAt));
    return all.filter(f => f.status === "active");
  }

  async getAllAmlFlags(tenantId?: string): Promise<AmlFlag[]> {
    if (tenantId) {
      return db.select().from(amlFlags).where(eq(amlFlags.tenantId, tenantId)).orderBy(desc(amlFlags.createdAt));
    }
    return db.select().from(amlFlags).orderBy(desc(amlFlags.createdAt));
  }

  async getAmlFlagById(id: string): Promise<AmlFlag | undefined> {
    const [flag] = await db.select().from(amlFlags).where(eq(amlFlags.id, id));
    return flag;
  }

  async resolveAmlFlag(id: string, resolvedBy: string, notes: string): Promise<AmlFlag | undefined> {
    const [updated] = await db.update(amlFlags).set({
      status: "cleared",
      resolvedBy,
      resolvedAt: new Date().toISOString(),
      resolutionNotes: notes,
    }).where(eq(amlFlags.id, id)).returning();
    return updated;
  }

  async updateUserEddStatus(userId: string, eddStatus: string): Promise<User | undefined> {
    const [updated] = await db.update(users).set({ eddStatus }).where(eq(users.id, userId)).returning();
    return updated;
  }

  async getActiveLegalDocuments(): Promise<LegalDocument[]> {
    return db.select().from(legalDocuments).where(eq(legalDocuments.isActive, true)).orderBy(legalDocuments.type);
  }

  async getActiveLegalDocumentsByCountry(country: string): Promise<LegalDocument[]> {
    return db.select().from(legalDocuments)
      .where(and(eq(legalDocuments.isActive, true), eq(legalDocuments.country, country)))
      .orderBy(legalDocuments.type);
  }

  async getActiveLegalDocsByJurisdictionProduct(jurisdiction: string, productType: string): Promise<LegalDocument[]> {
    const allActive = await db.select().from(legalDocuments)
      .where(eq(legalDocuments.isActive, true))
      .orderBy(legalDocuments.type);
    return allActive.filter(d => {
      const countryMatch = !d.country || d.country === jurisdiction || (d.jurisdictionCode && d.jurisdictionCode === jurisdiction);
      const ptMatch = d.productType === "GENERAL" || d.productType === productType;
      return countryMatch && ptMatch;
    });
  }

  async getRequiredDocsForInvestment(assetCountry: string, vehicleType: string): Promise<LegalDocument[]> {
    const allActive = await db.select().from(legalDocuments)
      .where(eq(legalDocuments.isActive, true))
      .orderBy(legalDocuments.type);
    return allActive.filter(d => {
      const jurisdictionMatch = !d.country && !d.jurisdictionCode
        || d.country === assetCountry
        || (d.jurisdictionCode && d.jurisdictionCode === assetCountry);
      const ptMatch = d.productType === "GENERAL" || d.productType === vehicleType;
      return jurisdictionMatch && ptMatch;
    });
  }

  async hasAcceptedAllRequiredDocs(userId: string, docs: LegalDocument[]): Promise<{ allAccepted: boolean; pending: LegalDocument[] }> {
    if (docs.length === 0) return { allAccepted: true, pending: [] };
    const acceptances = await db.select().from(legalAcceptances)
      .where(eq(legalAcceptances.userId, userId));
    const acceptedDocIds = new Set(acceptances.map(a => a.legalDocumentId));
    const pending = docs.filter(d => !acceptedDocIds.has(d.id));
    return { allAccepted: pending.length === 0, pending };
  }

  async getLegalDocumentById(id: string): Promise<LegalDocument | undefined> {
    const [doc] = await db.select().from(legalDocuments).where(eq(legalDocuments.id, id));
    return doc;
  }

  async getLegalDocumentByType(type: string): Promise<LegalDocument | undefined> {
    const docs = await db.select().from(legalDocuments).where(eq(legalDocuments.type, type)).orderBy(desc(legalDocuments.version));
    return docs.find(d => d.isActive);
  }

  async createLegalDocument(doc: InsertLegalDocument): Promise<LegalDocument> {
    const [created] = await db.insert(legalDocuments).values(doc).returning();
    return created;
  }

  async getUserAcceptances(userId: string): Promise<LegalAcceptance[]> {
    return db.select().from(legalAcceptances).where(eq(legalAcceptances.userId, userId)).orderBy(desc(legalAcceptances.acceptedAt));
  }

  async createLegalAcceptance(acceptance: InsertLegalAcceptance): Promise<LegalAcceptance> {
    const [created] = await db.insert(legalAcceptances).values(acceptance).returning();
    return created;
  }

  async hasUserAcceptedDocument(userId: string, documentId: string): Promise<boolean> {
    const acceptances = await db.select().from(legalAcceptances)
      .where(eq(legalAcceptances.userId, userId));
    return acceptances.some(a => a.legalDocumentId === documentId);
  }

  async getBankAccountsByUser(userId: string): Promise<BankAccount[]> {
    return db.select().from(bankAccounts).where(eq(bankAccounts.userId, userId)).orderBy(desc(bankAccounts.createdAt));
  }

  async getBankAccountById(id: string): Promise<BankAccount | undefined> {
    const [account] = await db.select().from(bankAccounts).where(eq(bankAccounts.id, id));
    return account;
  }

  async getAllBankAccounts(tenantId?: string): Promise<BankAccount[]> {
    if (tenantId) {
      return db.select().from(bankAccounts).where(eq(bankAccounts.tenantId, tenantId)).orderBy(desc(bankAccounts.createdAt));
    }
    return db.select().from(bankAccounts).orderBy(desc(bankAccounts.createdAt));
  }

  async createBankAccount(account: InsertBankAccount): Promise<BankAccount> {
    const [created] = await db.insert(bankAccounts).values(account).returning();
    return created;
  }

  async updateBankAccount(id: string, data: Partial<InsertBankAccount>): Promise<BankAccount | undefined> {
    const [updated] = await db.update(bankAccounts).set(data).where(eq(bankAccounts.id, id)).returning();
    return updated;
  }

  async verifyBankAccount(id: string, verifiedBy: string, status: string, notes?: string): Promise<BankAccount | undefined> {
    const [updated] = await db.update(bankAccounts).set({
      status,
      verifiedBy,
      verifiedAt: new Date().toISOString(),
      verificationNotes: notes || null,
    }).where(eq(bankAccounts.id, id)).returning();
    return updated;
  }

  async getVerifiedBankAccountsByUser(userId: string): Promise<BankAccount[]> {
    const all = await db.select().from(bankAccounts).where(eq(bankAccounts.userId, userId));
    return all.filter(a => a.status === "verified");
  }

  async getWalletAccountsByUser(userId: string): Promise<WalletAccount[]> {
    return db.select().from(walletAccounts).where(eq(walletAccounts.userId, userId));
  }

  async getWalletAccount(id: string): Promise<WalletAccount | undefined> {
    const [account] = await db.select().from(walletAccounts).where(eq(walletAccounts.id, id));
    return account;
  }

  async getWalletAccountByUserAndCurrency(userId: string, currency: string): Promise<WalletAccount | undefined> {
    const [account] = await db.select().from(walletAccounts)
      .where(and(eq(walletAccounts.userId, userId), eq(walletAccounts.currency, currency)));
    return account;
  }

  async createWalletAccount(account: InsertWalletAccount): Promise<WalletAccount> {
    const [created] = await db.insert(walletAccounts).values(account).returning();
    return created;
  }

  async getWalletTransactions(walletAccountId: string): Promise<WalletTransaction[]> {
    return db.select().from(walletTransactions)
      .where(eq(walletTransactions.walletAccountId, walletAccountId))
      .orderBy(desc(walletTransactions.createdAt));
  }

  async getWalletTransactionsByUser(userId: string): Promise<WalletTransaction[]> {
    const accounts = await this.getWalletAccountsByUser(userId);
    if (accounts.length === 0) return [];
    const allTxs: WalletTransaction[] = [];
    for (const acc of accounts) {
      const txs = await db.select().from(walletTransactions)
        .where(eq(walletTransactions.walletAccountId, acc.id))
        .orderBy(desc(walletTransactions.createdAt));
      allTxs.push(...txs);
    }
    allTxs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return allTxs;
  }

  async getWalletTransactionById(id: string): Promise<WalletTransaction | undefined> {
    const [tx] = await db.select().from(walletTransactions).where(eq(walletTransactions.id, id));
    return tx;
  }

  async createWalletTransaction(tx: InsertWalletTransaction): Promise<WalletTransaction> {
    const [created] = await db.insert(walletTransactions).values(tx).returning();
    return created;
  }

  async getComputedBalance(walletAccountId: string): Promise<{ available: string; pending: string }> {
    const creditTypes = ["DEPOSIT", "REFUND", "DIVIDEND", "TRADE_SELL", "CRYPTO_DEPOSIT", "CAPITAL_RETURN", "CAPITAL_GAIN"];
    const debitTypes = ["WITHDRAW", "INVEST_CAPTURE", "FEE", "TRADE_BUY"];

    const txs = await db.select().from(walletTransactions)
      .where(eq(walletTransactions.walletAccountId, walletAccountId));

    let available = 0;
    let pending = 0;

    for (const tx of txs) {
      const amt = parseFloat(tx.amount);
      const isCredit = creditTypes.includes(tx.type);
      const isDebit = debitTypes.includes(tx.type);

      if (tx.type === "FX_CONVERT") {
        if (tx.status === "COMPLETED") {
          available += amt;
        }
        continue;
      }

      if (tx.type === "INVEST_RESERVE") {
        if (tx.status === "PENDING") {
          pending -= amt;
        }
        continue;
      }

      if (tx.status === "COMPLETED") {
        if (isCredit) available += amt;
        else if (isDebit) available -= amt;
      } else if (tx.status === "PENDING") {
        if (isCredit) pending += amt;
        else if (isDebit) pending -= amt;
      }
    }

    return {
      available: available.toFixed(2),
      pending: pending.toFixed(2),
    };
  }

  async createLedgerEntries(entries: InsertLedgerEntry[]): Promise<LedgerEntry[]> {
    if (entries.length === 0) return [];
    const created = await db.insert(ledgerEntries).values(entries).returning();
    return created;
  }

  async reverseLedgerEntries(ledgerTxId: string, reason: string): Promise<LedgerEntry[]> {
    const original = await db.select().from(ledgerEntries)
      .where(and(
        eq(ledgerEntries.ledgerTxId, ledgerTxId),
        sql`${ledgerEntries.status} IN ('POSTED', 'PENDING')`
      ));
    if (original.length === 0) return [];

    await db.update(ledgerEntries)
      .set({ status: "REVERSED" })
      .where(and(
        eq(ledgerEntries.ledgerTxId, ledgerTxId),
        sql`${ledgerEntries.status} IN ('POSTED', 'PENDING')`
      ));

    const reversalTxId = `rev_${ledgerTxId}_${Date.now()}`;
    const reversals: InsertLedgerEntry[] = original.map(entry => ({
      ledgerTxId: reversalTxId,
      walletAccountId: entry.walletAccountId,
      currency: entry.currency,
      amount: entry.amount,
      direction: entry.direction === "DEBIT" ? "CREDIT" : "DEBIT",
      status: entry.status === "PENDING" ? "PENDING" : "POSTED",
      entryType: "REVERSAL",
      referenceId: entry.referenceId,
      reversalOfEntryId: entry.id,
      description: reason,
      metadata: { originalLedgerTxId: ledgerTxId, originalEntryId: entry.id, originalStatus: entry.status },
    }));

    const created = await db.insert(ledgerEntries).values(reversals).returning();
    return created;
  }

  async getLedgerEntriesByAccount(walletAccountId: string): Promise<LedgerEntry[]> {
    return db.select().from(ledgerEntries)
      .where(eq(ledgerEntries.walletAccountId, walletAccountId))
      .orderBy(desc(ledgerEntries.createdAt));
  }

  async getLedgerEntriesByTxId(ledgerTxId: string): Promise<LedgerEntry[]> {
    return db.select().from(ledgerEntries)
      .where(eq(ledgerEntries.ledgerTxId, ledgerTxId))
      .orderBy(desc(ledgerEntries.createdAt));
  }

  async getLedgerEntriesByUser(userId: string): Promise<LedgerEntry[]> {
    const accounts = await this.getWalletAccountsByUser(userId);
    const allEntries: LedgerEntry[] = [];
    for (const acc of accounts) {
      const entries = await this.getLedgerEntriesByAccount(acc.id);
      allEntries.push(...entries);
    }
    allEntries.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return allEntries;
  }

  async getLedgerBalance(walletAccountId: string): Promise<{ available: string; pending: string; total: string }> {
    const entries = await db.select().from(ledgerEntries)
      .where(eq(ledgerEntries.walletAccountId, walletAccountId));

    let postedCredits = 0;
    let postedDebits = 0;
    let pendingCredits = 0;
    let pendingDebits = 0;

    for (const entry of entries) {
      const amt = parseFloat(entry.amount);
      const isPending = entry.status === "PENDING";
      if (isPending) {
        if (entry.direction === "CREDIT") pendingCredits += amt;
        else pendingDebits += amt;
      } else {
        if (entry.direction === "CREDIT") postedCredits += amt;
        else postedDebits += amt;
      }
    }

    const available = postedCredits - postedDebits;
    const pending = pendingCredits - pendingDebits;
    const total = available + pending;

    return {
      available: available.toFixed(6),
      pending: pending.toFixed(6),
      total: total.toFixed(6),
    };
  }

  async createWithdrawalRequest(data: InsertWithdrawalRequest): Promise<WithdrawalRequest> {
    const [created] = await db.insert(withdrawalRequests).values(data).returning();
    return created;
  }

  async getWithdrawalRequestById(id: string): Promise<WithdrawalRequest | undefined> {
    const [req] = await db.select().from(withdrawalRequests).where(eq(withdrawalRequests.id, id));
    return req;
  }

  async getWithdrawalRequestsByUser(userId: string): Promise<WithdrawalRequest[]> {
    return db.select().from(withdrawalRequests)
      .where(eq(withdrawalRequests.userId, userId))
      .orderBy(desc(withdrawalRequests.requestedAt));
  }

  async getAllWithdrawalRequests(tenantId?: string): Promise<WithdrawalRequest[]> {
    if (tenantId) {
      return db.select().from(withdrawalRequests).where(eq(withdrawalRequests.tenantId, tenantId)).orderBy(desc(withdrawalRequests.requestedAt));
    }
    return db.select().from(withdrawalRequests)
      .orderBy(desc(withdrawalRequests.requestedAt));
  }

  async updateWithdrawalRequestStatus(
    id: string,
    status: string,
    adminId: string,
    notes?: string
  ): Promise<WithdrawalRequest> {
    const updates: any = { status, reviewedBy: adminId, reviewedAt: new Date().toISOString() };
    if (notes) updates.reviewNotes = notes;
    const [updated] = await db.update(withdrawalRequests)
      .set(updates)
      .where(eq(withdrawalRequests.id, id))
      .returning();
    return updated;
  }

  async markWithdrawalPaid(
    id: string,
    adminId: string,
    payoutReference: string
  ): Promise<WithdrawalRequest> {
    const [updated] = await db.update(withdrawalRequests)
      .set({
        status: "PAID",
        paidBy: adminId,
        paidAt: new Date().toISOString(),
        payoutReference,
      })
      .where(eq(withdrawalRequests.id, id))
      .returning();
    return updated;
  }

  async getActiveFeeSchedule(feeType: FeeType, currency?: string, vehicleId?: string): Promise<FeeSchedule | undefined> {
    if (vehicleId) {
      let results = await db.select().from(feeSchedules)
        .where(and(
          eq(feeSchedules.feeType, feeType),
          eq(feeSchedules.isActive, true),
          eq(feeSchedules.vehicleId, vehicleId),
          eq(feeSchedules.currency, currency || "*"),
        ))
        .orderBy(desc(feeSchedules.version));
      if (results.length > 0) return results[0];
      if (currency && currency !== "*") {
        results = await db.select().from(feeSchedules)
          .where(and(
            eq(feeSchedules.feeType, feeType),
            eq(feeSchedules.isActive, true),
            eq(feeSchedules.vehicleId, vehicleId),
            eq(feeSchedules.currency, "*"),
          ))
          .orderBy(desc(feeSchedules.version));
        if (results.length > 0) return results[0];
      }
    }
    let results = await db.select().from(feeSchedules)
      .where(and(
        eq(feeSchedules.feeType, feeType),
        eq(feeSchedules.isActive, true),
        sql`${feeSchedules.vehicleId} IS NULL`,
        eq(feeSchedules.currency, currency || "*"),
      ))
      .orderBy(desc(feeSchedules.version));
    if (results.length > 0) return results[0];
    if (currency && currency !== "*") {
      results = await db.select().from(feeSchedules)
        .where(and(
          eq(feeSchedules.feeType, feeType),
          eq(feeSchedules.isActive, true),
          sql`${feeSchedules.vehicleId} IS NULL`,
          eq(feeSchedules.currency, "*"),
        ))
        .orderBy(desc(feeSchedules.version));
      if (results.length > 0) return results[0];
    }
    return undefined;
  }

  async getAllFeeSchedules(): Promise<FeeSchedule[]> {
    return db.select().from(feeSchedules).orderBy(desc(feeSchedules.createdAt));
  }

  async getFeeScheduleById(id: string): Promise<FeeSchedule | undefined> {
    const [schedule] = await db.select().from(feeSchedules).where(eq(feeSchedules.id, id));
    return schedule;
  }

  async getFeeScheduleHistory(feeType: FeeType, currency?: string, vehicleId?: string): Promise<FeeSchedule[]> {
    const conditions: any[] = [eq(feeSchedules.feeType, feeType)];
    if (currency) conditions.push(eq(feeSchedules.currency, currency));
    if (vehicleId) {
      conditions.push(eq(feeSchedules.vehicleId, vehicleId));
    } else {
      conditions.push(sql`${feeSchedules.vehicleId} IS NULL`);
    }
    return db.select().from(feeSchedules)
      .where(and(...conditions))
      .orderBy(desc(feeSchedules.version));
  }

  async getFeeSchedulesByVehicle(vehicleId: string): Promise<FeeSchedule[]> {
    return db.select().from(feeSchedules)
      .where(eq(feeSchedules.vehicleId, vehicleId))
      .orderBy(desc(feeSchedules.createdAt));
  }

  async createFeeSchedule(data: Partial<FeeSchedule>, createdBy: string): Promise<FeeSchedule> {
    const vehicleCondition = data.vehicleId
      ? eq(feeSchedules.vehicleId, data.vehicleId)
      : sql`${feeSchedules.vehicleId} IS NULL`;

    const existing = await db.select().from(feeSchedules)
      .where(and(
        eq(feeSchedules.feeType, data.feeType!),
        eq(feeSchedules.currency, data.currency || "*"),
        vehicleCondition,
      ))
      .orderBy(desc(feeSchedules.version));

    const nextVersion = existing.length > 0 ? (existing[0].version + 1) : 1;

    const activeOnes = existing.filter(e => e.isActive);
    for (const old of activeOnes) {
      await db.update(feeSchedules)
        .set({ isActive: false, effectiveTo: new Date() })
        .where(eq(feeSchedules.id, old.id));
    }

    const [created] = await db.insert(feeSchedules).values({
      vehicleId: data.vehicleId || null,
      feeType: data.feeType!,
      currency: data.currency || "*",
      method: data.method || "percentage",
      rate: data.rate || "0",
      flatAmount: data.flatAmount || "0",
      tiers: data.tiers || null,
      minFee: data.minFee || null,
      maxFee: data.maxFee || null,
      version: nextVersion,
      isActive: true,
      effectiveFrom: new Date(),
      createdBy,
      notes: data.notes || null,
    }).returning();
    return created;
  }

  async createAppliedFee(fee: InsertAppliedFee): Promise<AppliedFee> {
    const [created] = await db.insert(appliedFees).values(fee).returning();
    return created;
  }

  async getAppliedFeesByEntity(entityType: string, entityId: string): Promise<AppliedFee[]> {
    return db.select().from(appliedFees)
      .where(and(
        eq(appliedFees.referenceEntityType, entityType),
        eq(appliedFees.referenceEntityId, entityId),
      ))
      .orderBy(desc(appliedFees.createdAt));
  }

  async getAppliedFeesByVehicle(vehicleId: string): Promise<AppliedFee[]> {
    return db.select().from(appliedFees)
      .where(eq(appliedFees.vehicleId, vehicleId))
      .orderBy(desc(appliedFees.createdAt));
  }

  async getAppliedFeesByUser(userId: string): Promise<AppliedFee[]> {
    return db.select().from(appliedFees)
      .where(eq(appliedFees.userId, userId))
      .orderBy(desc(appliedFees.createdAt));
  }

  async getAllAppliedFees(limit?: number): Promise<AppliedFee[]> {
    const query = db.select().from(appliedFees).orderBy(desc(appliedFees.createdAt));
    if (limit) return query.limit(limit);
    return query;
  }

  async createPaymentIntent(intent: InsertPaymentIntent): Promise<PaymentIntent> {
    const [created] = await db.insert(paymentIntents).values(intent).returning();
    const referenceCode = `VB-${created.id.slice(0, 8).toUpperCase()}`;
    const [updated] = await db.update(paymentIntents)
      .set({ referenceCode })
      .where(eq(paymentIntents.id, created.id))
      .returning();
    return updated;
  }

  async getPaymentIntent(id: string): Promise<PaymentIntent | undefined> {
    const [intent] = await db.select().from(paymentIntents).where(eq(paymentIntents.id, id));
    return intent;
  }

  async getPaymentIntentsByUser(userId: string): Promise<PaymentIntent[]> {
    return db.select().from(paymentIntents)
      .where(eq(paymentIntents.userId, userId))
      .orderBy(desc(paymentIntents.createdAt));
  }

  async getAllPaymentIntents(tenantId?: string): Promise<PaymentIntent[]> {
    if (tenantId) {
      return db.select().from(paymentIntents).where(eq(paymentIntents.tenantId, tenantId)).orderBy(desc(paymentIntents.createdAt));
    }
    return db.select().from(paymentIntents).orderBy(desc(paymentIntents.createdAt));
  }

  async updatePaymentIntentStatus(id: string, status: PaymentIntentStatus, data?: Partial<PaymentIntent>): Promise<PaymentIntent | undefined> {
    const updateData: any = { status, ...data };
    const [updated] = await db.update(paymentIntents).set(updateData).where(eq(paymentIntents.id, id)).returning();
    return updated;
  }

  async deactivateFeeSchedule(id: string): Promise<FeeSchedule | undefined> {
    const [updated] = await db.update(feeSchedules)
      .set({ isActive: false, effectiveTo: new Date() })
      .where(eq(feeSchedules.id, id))
      .returning();
    return updated;
  }

  async getActiveFxRate(fromCurrency: string, toCurrency: string): Promise<FxRate | undefined> {
    const [rate] = await db.select().from(fxRates)
      .where(and(
        eq(fxRates.fromCurrency, fromCurrency),
        eq(fxRates.toCurrency, toCurrency),
        eq(fxRates.isActive, true),
      ))
      .orderBy(desc(fxRates.effectiveFrom))
      .limit(1);
    return rate;
  }

  async getAllFxRates(): Promise<FxRate[]> {
    return db.select().from(fxRates).orderBy(desc(fxRates.createdAt));
  }

  async getFxRateById(id: string): Promise<FxRate | undefined> {
    const [rate] = await db.select().from(fxRates).where(eq(fxRates.id, id));
    return rate;
  }

  async createFxRate(rate: InsertFxRate): Promise<FxRate> {
    await db.update(fxRates)
      .set({ isActive: false, effectiveTo: new Date() })
      .where(and(
        eq(fxRates.fromCurrency, rate.fromCurrency),
        eq(fxRates.toCurrency, rate.toCurrency),
        eq(fxRates.isActive, true),
      ));
    const [created] = await db.insert(fxRates).values(rate).returning();
    return created;
  }

  async updateFxRate(id: string, data: Partial<InsertFxRate>): Promise<FxRate | undefined> {
    const [updated] = await db.update(fxRates)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(fxRates.id, id))
      .returning();
    return updated;
  }

  async getOrCreateWallet(userId: string, currency: string): Promise<WalletAccount> {
    const existing = await this.getWalletAccountByUserAndCurrency(userId, currency);
    if (existing) return existing;
    return this.createWalletAccount({ userId, currency });
  }

  async deactivateFxRate(id: string): Promise<FxRate | undefined> {
    const [updated] = await db.update(fxRates)
      .set({ isActive: false, effectiveTo: new Date(), updatedAt: new Date() })
      .where(eq(fxRates.id, id))
      .returning();
    return updated;
  }

  async createFxQuote(quote: InsertFxQuote): Promise<FxQuote> {
    const [created] = await db.insert(fxQuotes).values(quote).returning();
    return created;
  }

  async getFxQuoteById(id: string): Promise<FxQuote | undefined> {
    const [quote] = await db.select().from(fxQuotes).where(eq(fxQuotes.id, id));
    return quote;
  }

  async getAllFxQuotes(): Promise<FxQuote[]> {
    return db.select().from(fxQuotes).orderBy(desc(fxQuotes.createdAt));
  }

  async expireFxQuote(id: string): Promise<FxQuote | undefined> {
    const [updated] = await db.update(fxQuotes)
      .set({ status: "expired" })
      .where(eq(fxQuotes.id, id))
      .returning();
    return updated;
  }

  async createFxTransaction(tx: InsertFxTransaction): Promise<FxTransaction> {
    const [created] = await db.insert(fxTransactions).values(tx).returning();
    return created;
  }

  async getFxTransactionById(id: string): Promise<FxTransaction | undefined> {
    const [tx] = await db.select().from(fxTransactions).where(eq(fxTransactions.id, id));
    return tx;
  }

  async getFxTransactionsByUser(userId: string): Promise<FxTransaction[]> {
    return db.select().from(fxTransactions)
      .where(eq(fxTransactions.userId, userId))
      .orderBy(desc(fxTransactions.createdAt));
  }

  async updateFxTransactionStatus(id: string, status: string): Promise<FxTransaction | undefined> {
    const [updated] = await db.update(fxTransactions)
      .set({ status })
      .where(eq(fxTransactions.id, id))
      .returning();
    return updated;
  }

  async getAllFxTransactions(tenantId?: string): Promise<FxTransaction[]> {
    return db.select().from(fxTransactions).orderBy(desc(fxTransactions.createdAt));
  }

  async getCountryProfiles(userId: string): Promise<UserCountryProfile[]> {
    return db.select().from(userCountryProfiles).where(eq(userCountryProfiles.userId, userId));
  }

  async getCountryProfile(userId: string, countryCode: string): Promise<UserCountryProfile | undefined> {
    const [profile] = await db.select().from(userCountryProfiles)
      .where(and(eq(userCountryProfiles.userId, userId), eq(userCountryProfiles.countryCode, countryCode)));
    return profile;
  }

  async upsertCountryProfile(userId: string, data: InsertUserCountryProfile): Promise<UserCountryProfile> {
    const existing = await this.getCountryProfile(userId, data.countryCode);
    if (existing) {
      const [updated] = await db.update(userCountryProfiles)
        .set({ ...data, updatedAt: new Date().toISOString() })
        .where(eq(userCountryProfiles.id, existing.id))
        .returning();
      return updated;
    }
    const [created] = await db.insert(userCountryProfiles).values({ ...data, userId }).returning();
    return created;
  }

  async deleteCountryProfile(userId: string, countryCode: string): Promise<boolean> {
    const result = await db.delete(userCountryProfiles)
      .where(and(eq(userCountryProfiles.userId, userId), eq(userCountryProfiles.countryCode, countryCode)));
    return (result.rowCount ?? 0) > 0;
  }

  async setPrimaryCountry(userId: string, countryCode: string): Promise<void> {
    await db.update(userCountryProfiles)
      .set({ isPrimary: false })
      .where(eq(userCountryProfiles.userId, userId));
    await db.update(userCountryProfiles)
      .set({ isPrimary: true })
      .where(and(eq(userCountryProfiles.userId, userId), eq(userCountryProfiles.countryCode, countryCode)));
  }

  async getActiveReceivingBankAccounts(): Promise<ReceivingBankAccount[]> {
    return db.select().from(receivingBankAccounts).where(eq(receivingBankAccounts.isActive, true)).orderBy(receivingBankAccounts.currency);
  }

  async getReceivingBankAccountByCurrency(currency: string): Promise<ReceivingBankAccount | undefined> {
    const [account] = await db.select().from(receivingBankAccounts)
      .where(and(eq(receivingBankAccounts.currency, currency), eq(receivingBankAccounts.isActive, true)));
    return account;
  }

  async getReceivingBankAccountByCountryAndCurrency(countryCode: string, currency: string): Promise<ReceivingBankAccount | undefined> {
    const [account] = await db.select().from(receivingBankAccounts)
      .where(and(
        eq(receivingBankAccounts.countryCode, countryCode),
        eq(receivingBankAccounts.currency, currency),
        eq(receivingBankAccounts.isActive, true),
      ));
    return account;
  }

  async getReceivingBankAccountById(id: string): Promise<ReceivingBankAccount | undefined> {
    const [account] = await db.select().from(receivingBankAccounts).where(eq(receivingBankAccounts.id, id));
    return account;
  }

  async getAllReceivingBankAccounts(): Promise<ReceivingBankAccount[]> {
    return db.select().from(receivingBankAccounts).orderBy(desc(receivingBankAccounts.createdAt));
  }

  async createReceivingBankAccount(account: InsertReceivingBankAccount): Promise<ReceivingBankAccount> {
    const [created] = await db.insert(receivingBankAccounts).values(account).returning();
    return created;
  }

  async updateReceivingBankAccount(id: string, data: Partial<InsertReceivingBankAccount>): Promise<ReceivingBankAccount | undefined> {
    const [updated] = await db.update(receivingBankAccounts).set(data).where(eq(receivingBankAccounts.id, id)).returning();
    return updated;
  }

  async deactivateReceivingBankAccount(id: string): Promise<ReceivingBankAccount | undefined> {
    const [updated] = await db.update(receivingBankAccounts).set({ isActive: false }).where(eq(receivingBankAccounts.id, id)).returning();
    return updated;
  }

  async getExitWindows(): Promise<ExitWindow[]> {
    return db.select().from(exitWindows).orderBy(desc(exitWindows.createdAt));
  }

  async getExitWindowsByAsset(assetId: string): Promise<ExitWindow[]> {
    return db.select().from(exitWindows).where(eq(exitWindows.assetId, assetId)).orderBy(desc(exitWindows.createdAt));
  }

  async getExitWindowById(id: string): Promise<ExitWindow | undefined> {
    const [ew] = await db.select().from(exitWindows).where(eq(exitWindows.id, id));
    return ew;
  }

  async createExitWindow(ew: InsertExitWindow): Promise<ExitWindow> {
    const [created] = await db.insert(exitWindows).values(ew).returning();
    return created;
  }

  async updateExitWindowStatus(id: string, status: string): Promise<ExitWindow | undefined> {
    const [updated] = await db.update(exitWindows).set({ status }).where(eq(exitWindows.id, id)).returning();
    return updated;
  }

  async updateExitWindowRules(id: string, rules: { eligibleJurisdictions?: string[]; lockupDays?: number; cooldownHours?: number; maxParticipants?: number; minTradeAmount?: string; maxTradeAmount?: string }): Promise<ExitWindow | undefined> {
    const updates: any = {};
    if (rules.eligibleJurisdictions !== undefined) updates.eligibleJurisdictions = rules.eligibleJurisdictions;
    if (rules.lockupDays !== undefined) updates.lockupDays = rules.lockupDays;
    if (rules.cooldownHours !== undefined) updates.cooldownHours = rules.cooldownHours;
    if (rules.maxParticipants !== undefined) updates.maxParticipants = rules.maxParticipants;
    if (rules.minTradeAmount !== undefined) updates.minTradeAmount = rules.minTradeAmount;
    if (rules.maxTradeAmount !== undefined) updates.maxTradeAmount = rules.maxTradeAmount;
    if (Object.keys(updates).length === 0) return this.getExitWindowById(id);
    const [updated] = await db.update(exitWindows).set(updates).where(eq(exitWindows.id, id)).returning();
    return updated;
  }

  async getUniqueTraderCount(exitWindowId: string): Promise<number> {
    const listings = await db.select({ sellerId: tradeListings.sellerId, buyerId: tradeListings.buyerId })
      .from(tradeListings)
      .where(eq(tradeListings.exitWindowId, exitWindowId));
    const traders = new Set<string>();
    for (const l of listings) {
      traders.add(l.sellerId);
      if (l.buyerId) traders.add(l.buyerId);
    }
    return traders.size;
  }

  async getLastTradeTimestamp(userId: string, exitWindowId: string): Promise<string | null> {
    const asSellerListings = await db.select({ createdAt: tradeListings.createdAt })
      .from(tradeListings)
      .where(and(eq(tradeListings.exitWindowId, exitWindowId), eq(tradeListings.sellerId, userId)))
      .orderBy(desc(tradeListings.createdAt))
      .limit(1);

    const asBuyerListings = await db.select({ filledAt: tradeListings.filledAt })
      .from(tradeListings)
      .where(and(eq(tradeListings.exitWindowId, exitWindowId), eq(tradeListings.buyerId, userId), eq(tradeListings.status, "filled")))
      .orderBy(desc(tradeListings.filledAt))
      .limit(1);

    const timestamps: string[] = [];
    if (asSellerListings.length > 0) timestamps.push(asSellerListings[0].createdAt);
    if (asBuyerListings.length > 0 && asBuyerListings[0].filledAt) timestamps.push(asBuyerListings[0].filledAt);

    if (timestamps.length === 0) return null;
    timestamps.sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
    return timestamps[0];
  }

  async getExitWindowSchedules(): Promise<ExitWindowSchedule[]> {
    return db.select().from(exitWindowSchedules).orderBy(desc(exitWindowSchedules.createdAt));
  }

  async getExitWindowSchedulesByAsset(assetId: string): Promise<ExitWindowSchedule[]> {
    return db.select().from(exitWindowSchedules).where(eq(exitWindowSchedules.assetId, assetId)).orderBy(desc(exitWindowSchedules.createdAt));
  }

  async getExitWindowScheduleById(id: string): Promise<ExitWindowSchedule | undefined> {
    const [s] = await db.select().from(exitWindowSchedules).where(eq(exitWindowSchedules.id, id));
    return s;
  }

  async createExitWindowSchedule(s: InsertExitWindowSchedule): Promise<ExitWindowSchedule> {
    const [created] = await db.insert(exitWindowSchedules).values(s).returning();
    return created;
  }

  async updateExitWindowSchedule(id: string, data: Partial<InsertExitWindowSchedule>): Promise<ExitWindowSchedule | undefined> {
    const [updated] = await db.update(exitWindowSchedules).set({ ...data, updatedAt: new Date().toISOString() }).where(eq(exitWindowSchedules.id, id)).returning();
    return updated;
  }

  async deleteExitWindowSchedule(id: string): Promise<boolean> {
    const result = await db.delete(exitWindowSchedules).where(eq(exitWindowSchedules.id, id));
    return true;
  }

  async getTradeListings(exitWindowId: string): Promise<TradeListing[]> {
    return db.select().from(tradeListings).where(eq(tradeListings.exitWindowId, exitWindowId)).orderBy(desc(tradeListings.createdAt));
  }

  async getActiveTradeListings(exitWindowId: string): Promise<TradeListing[]> {
    return db.select().from(tradeListings)
      .where(and(eq(tradeListings.exitWindowId, exitWindowId), eq(tradeListings.status, "active")))
      .orderBy(desc(tradeListings.createdAt));
  }

  async getTradeListingById(id: string): Promise<TradeListing | undefined> {
    const [listing] = await db.select().from(tradeListings).where(eq(tradeListings.id, id));
    return listing;
  }

  async getTradeListingsBySeller(sellerId: string): Promise<TradeListing[]> {
    return db.select().from(tradeListings).where(eq(tradeListings.sellerId, sellerId)).orderBy(desc(tradeListings.createdAt));
  }

  async createTradeListing(listing: InsertTradeListing): Promise<TradeListing> {
    const [created] = await db.insert(tradeListings).values(listing).returning();
    return created;
  }

  async updateTradeListing(id: string, data: Partial<TradeListing>): Promise<TradeListing | undefined> {
    const [updated] = await db.update(tradeListings).set(data).where(eq(tradeListings.id, id)).returning();
    return updated;
  }

  async getMarketplaceCountrySettings(): Promise<MarketplaceCountrySetting[]> {
    return db.select().from(marketplaceCountrySettings).orderBy(marketplaceCountrySettings.displayOrder);
  }

  async getVisibleMarketplaceCountries(): Promise<MarketplaceCountrySetting[]> {
    return db.select().from(marketplaceCountrySettings)
      .where(eq(marketplaceCountrySettings.isVisible, true))
      .orderBy(marketplaceCountrySettings.displayOrder);
  }

  async upsertMarketplaceCountrySetting(countryCode: string, isVisible: boolean, displayOrder?: number): Promise<MarketplaceCountrySetting> {
    const [existing] = await db.select().from(marketplaceCountrySettings)
      .where(eq(marketplaceCountrySettings.countryCode, countryCode));
    if (existing) {
      const updates: any = { isVisible, updatedAt: new Date().toISOString() };
      if (displayOrder !== undefined) updates.displayOrder = displayOrder;
      const [updated] = await db.update(marketplaceCountrySettings)
        .set(updates)
        .where(eq(marketplaceCountrySettings.id, existing.id))
        .returning();
      return updated;
    }
    const [created] = await db.insert(marketplaceCountrySettings).values({
      countryCode,
      isVisible,
      displayOrder: displayOrder ?? 0,
    }).returning();
    return created;
  }

  async getFxSpreadConfigs(): Promise<FxSpreadConfig[]> {
    return db.select().from(fxSpreadConfigs).orderBy(desc(fxSpreadConfigs.createdAt));
  }

  async getActiveFxSpreadConfig(fromCurrency: string, toCurrency: string): Promise<FxSpreadConfig | undefined> {
    const [config] = await db.select().from(fxSpreadConfigs)
      .where(and(
        eq(fxSpreadConfigs.fromCurrency, fromCurrency),
        eq(fxSpreadConfigs.toCurrency, toCurrency),
        eq(fxSpreadConfigs.isActive, true),
      ));
    return config;
  }

  async getFxSpreadConfigById(id: string): Promise<FxSpreadConfig | undefined> {
    const [config] = await db.select().from(fxSpreadConfigs).where(eq(fxSpreadConfigs.id, id));
    return config;
  }

  async createFxSpreadConfig(config: InsertFxSpreadConfig): Promise<FxSpreadConfig> {
    const [created] = await db.insert(fxSpreadConfigs).values(config).returning();
    return created;
  }

  async updateFxSpreadConfig(id: string, data: Partial<InsertFxSpreadConfig>): Promise<FxSpreadConfig | undefined> {
    const [updated] = await db.update(fxSpreadConfigs)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(fxSpreadConfigs.id, id))
      .returning();
    return updated;
  }

  async deactivateFxSpreadConfig(id: string): Promise<FxSpreadConfig | undefined> {
    const [updated] = await db.update(fxSpreadConfigs)
      .set({ isActive: false, updatedAt: new Date() })
      .where(eq(fxSpreadConfigs.id, id))
      .returning();
    return updated;
  }

  async createFxConversionRequest(req: InsertFxConversionRequest): Promise<FxConversionRequest> {
    const [created] = await db.insert(fxConversionRequests).values(req).returning();
    return created;
  }

  async getFxConversionRequests(status?: string): Promise<FxConversionRequest[]> {
    if (status) {
      return db.select().from(fxConversionRequests)
        .where(eq(fxConversionRequests.status, status))
        .orderBy(desc(fxConversionRequests.createdAt));
    }
    return db.select().from(fxConversionRequests).orderBy(desc(fxConversionRequests.createdAt));
  }

  async getFxConversionRequestById(id: string): Promise<FxConversionRequest | undefined> {
    const [req] = await db.select().from(fxConversionRequests).where(eq(fxConversionRequests.id, id));
    return req;
  }

  async getFxConversionRequestByQuoteId(quoteId: string): Promise<FxConversionRequest | undefined> {
    const [req] = await db.select().from(fxConversionRequests)
      .where(eq(fxConversionRequests.quoteId, quoteId));
    return req;
  }

  async updateFxConversionRequestStatus(id: string, status: string, reviewedBy: string, reviewNotes?: string): Promise<FxConversionRequest | undefined> {
    const [updated] = await db.update(fxConversionRequests)
      .set({ status, reviewedBy, reviewedAt: new Date(), reviewNotes: reviewNotes || null })
      .where(eq(fxConversionRequests.id, id))
      .returning();
    return updated;
  }

  async updateUserTier(userId: string, tier: string): Promise<User | undefined> {
    const [updated] = await db.update(users)
      .set({ tier })
      .where(eq(users.id, userId))
      .returning();
    return updated;
  }

  async updateUser(userId: string, data: Partial<Record<string, string | null>>): Promise<User | undefined> {
    const [updated] = await db.update(users)
      .set(data as any)
      .where(eq(users.id, userId))
      .returning();
    return updated;
  }

  async hasFinancialRecords(userId: string): Promise<boolean> {
    const [portfolio] = await db.select({ count: sql<number>`count(*)` }).from(portfolioItems).where(eq(portfolioItems.userId, userId));
    if (portfolio && Number(portfolio.count) > 0) return true;
    const [txn] = await db.select({ count: sql<number>`count(*)` }).from(transactions).where(eq(transactions.userId, userId));
    if (txn && Number(txn.count) > 0) return true;
    const [wallet] = await db.select({ count: sql<number>`count(*)` }).from(walletAccounts).where(eq(walletAccounts.userId, userId));
    if (wallet && Number(wallet.count) > 0) return true;
    const [walletTx] = await db.select({ count: sql<number>`count(*)` }).from(walletTransactions).where(eq(walletTransactions.userId, userId));
    if (walletTx && Number(walletTx.count) > 0) return true;
    return false;
  }

  async updateAccountStatus(userId: string, status: string, changedBy: string): Promise<User | undefined> {
    const now = new Date().toISOString();
    const setData: any = {
      accountStatus: status,
      statusChangedBy: changedBy,
      isActive: status === "ACTIVE",
    };
    if (status === "DISABLED") {
      setData.disabledAt = now;
      setData.archivedAt = null;
    } else if (status === "ARCHIVED") {
      setData.archivedAt = now;
    } else if (status === "ACTIVE") {
      setData.disabledAt = null;
      setData.archivedAt = null;
    }
    const [updated] = await db.update(users).set(setData).where(eq(users.id, userId)).returning();
    return updated;
  }

  async incrementTokenVersion(userId: string): Promise<User | undefined> {
    const [updated] = await db.update(users)
      .set({ tokenVersion: sql`${users.tokenVersion} + 1` })
      .where(eq(users.id, userId))
      .returning();
    return updated;
  }

  async transferProjectOwnership(fromUserId: string, toUserId: string): Promise<number> {
    const userProjects = await db.select().from(projects).where(eq(projects.createdBy, fromUserId));
    if (userProjects.length === 0) return 0;
    const projectIds = userProjects.map(p => p.id);
    await db.update(projects).set({ createdBy: toUserId } as any).where(inArray(projects.id, projectIds));
    return userProjects.length;
  }

  async getActiveAdminUsers(): Promise<User[]> {
    return db.select().from(users)
      .where(and(
        eq(users.accountStatus, "ACTIVE"),
        eq(users.role, "admin")
      ));
  }

  async getProjectsByCreator(userId: string): Promise<any[]> {
    return db.select().from(projects).where(eq(projects.createdBy, userId));
  }

  async getAuditLogsByEntity(entityType: string, entityId: string): Promise<any[]> {
    return db.select().from(auditLogs)
      .where(and(
        eq(auditLogs.entityType, entityType),
        eq(auditLogs.entityId, entityId)
      ))
      .orderBy(desc(auditLogs.createdAt))
      .limit(100);
  }

  async getCryptoWalletsByUser(userId: string): Promise<CryptoWallet[]> {
    return db.select().from(cryptoWallets)
      .where(eq(cryptoWallets.userId, userId))
      .orderBy(desc(cryptoWallets.createdAt));
  }

  async getAllCryptoWallets(tenantId?: string): Promise<CryptoWallet[]> {
    if (tenantId) {
      return db.select().from(cryptoWallets).where(eq(cryptoWallets.tenantId, tenantId)).orderBy(desc(cryptoWallets.createdAt));
    }
    return db.select().from(cryptoWallets).orderBy(desc(cryptoWallets.createdAt));
  }

  async getCryptoWalletById(id: string): Promise<CryptoWallet | undefined> {
    const [wallet] = await db.select().from(cryptoWallets).where(eq(cryptoWallets.id, id));
    return wallet;
  }

  async createCryptoWallet(wallet: InsertCryptoWallet): Promise<CryptoWallet> {
    const [created] = await db.insert(cryptoWallets).values(wallet).returning();
    return created;
  }

  async deleteCryptoWallet(id: string): Promise<boolean> {
    const result = await db.delete(cryptoWallets).where(eq(cryptoWallets.id, id)).returning();
    return result.length > 0;
  }

  async blacklistCryptoWallet(id: string, blacklistedBy: string, reason: string): Promise<CryptoWallet | undefined> {
    const [updated] = await db.update(cryptoWallets)
      .set({ isBlacklisted: true, blacklistReason: reason, blacklistedBy, blacklistedAt: new Date(), updatedAt: new Date() })
      .where(eq(cryptoWallets.id, id))
      .returning();
    return updated;
  }

  async unblacklistCryptoWallet(id: string): Promise<CryptoWallet | undefined> {
    const [updated] = await db.update(cryptoWallets)
      .set({ isBlacklisted: false, blacklistReason: null, blacklistedBy: null, blacklistedAt: null, updatedAt: new Date() })
      .where(eq(cryptoWallets.id, id))
      .returning();
    return updated;
  }

  async updateCryptoWalletAdminNotes(id: string, notes: string): Promise<CryptoWallet | undefined> {
    const [updated] = await db.update(cryptoWallets)
      .set({ adminNotes: notes, updatedAt: new Date() })
      .where(eq(cryptoWallets.id, id))
      .returning();
    return updated;
  }

  async createCryptoDepositIntent(intent: InsertCryptoDepositIntent): Promise<CryptoDepositIntent> {
    const [created] = await db.insert(cryptoDepositIntents).values(intent).returning();
    return created;
  }

  async getCryptoDepositIntentsByUser(userId: string): Promise<CryptoDepositIntent[]> {
    return db.select().from(cryptoDepositIntents)
      .where(eq(cryptoDepositIntents.userId, userId))
      .orderBy(desc(cryptoDepositIntents.createdAt));
  }

  async getAllCryptoDepositIntents(tenantId?: string): Promise<CryptoDepositIntent[]> {
    if (tenantId) {
      return db.select().from(cryptoDepositIntents).where(eq(cryptoDepositIntents.tenantId, tenantId)).orderBy(desc(cryptoDepositIntents.createdAt));
    }
    return db.select().from(cryptoDepositIntents)
      .orderBy(desc(cryptoDepositIntents.createdAt));
  }

  async getCryptoDepositIntentById(id: string): Promise<CryptoDepositIntent | undefined> {
    const [intent] = await db.select().from(cryptoDepositIntents)
      .where(eq(cryptoDepositIntents.id, id));
    return intent;
  }

  async updateCryptoDepositIntent(id: string, data: Partial<CryptoDepositIntent>): Promise<CryptoDepositIntent | undefined> {
    const [updated] = await db.update(cryptoDepositIntents)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(cryptoDepositIntents.id, id))
      .returning();
    return updated;
  }

  async getRecentCryptoDeposits(userId: string, since: string): Promise<CryptoDepositIntent[]> {
    return db.select().from(cryptoDepositIntents)
      .where(and(
        eq(cryptoDepositIntents.userId, userId),
        gte(cryptoDepositIntents.createdAt, new Date(since))
      ))
      .orderBy(desc(cryptoDepositIntents.createdAt));
  }

  async createSupportTicket(ticket: InsertSupportTicket): Promise<SupportTicket> {
    const [created] = await db.insert(supportTickets).values(ticket).returning();
    return created;
  }

  async getSupportTicketsByUser(userId: string): Promise<SupportTicket[]> {
    return db.select().from(supportTickets)
      .where(eq(supportTickets.userId, userId))
      .orderBy(desc(supportTickets.createdAt));
  }

  async getAllSupportTickets(tenantId?: string): Promise<SupportTicket[]> {
    if (tenantId) {
      return db.select().from(supportTickets).where(eq(supportTickets.tenantId, tenantId)).orderBy(desc(supportTickets.createdAt));
    }
    return db.select().from(supportTickets)
      .orderBy(desc(supportTickets.createdAt));
  }

  async getSupportTicketById(id: string): Promise<SupportTicket | undefined> {
    const [ticket] = await db.select().from(supportTickets)
      .where(eq(supportTickets.id, id));
    return ticket;
  }

  async updateSupportTicket(id: string, data: Partial<SupportTicket>): Promise<SupportTicket | undefined> {
    const [updated] = await db.update(supportTickets)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(supportTickets.id, id))
      .returning();
    return updated;
  }

  async getRolePermissions(role: string): Promise<RolePermission[]> {
    return db.select().from(rolePermissions)
      .where(eq(rolePermissions.role, role));
  }

  async getAllRolePermissions(): Promise<RolePermission[]> {
    return db.select().from(rolePermissions);
  }

  async setRolePermissions(role: string, permissions: string[], grantedBy: string): Promise<RolePermission[]> {
    await db.delete(rolePermissions).where(eq(rolePermissions.role, role));
    if (permissions.length === 0) return [];
    const rows = permissions.map(p => ({ role, permission: p, grantedBy }));
    return db.insert(rolePermissions).values(rows).returning();
  }

  async addRolePermission(data: InsertRolePermission): Promise<RolePermission> {
    const [created] = await db.insert(rolePermissions).values(data).returning();
    return created;
  }

  async removeRolePermission(role: string, permission: string): Promise<boolean> {
    const result = await db.delete(rolePermissions)
      .where(and(eq(rolePermissions.role, role), eq(rolePermissions.permission, permission)))
      .returning();
    return result.length > 0;
  }

  async hasPermission(role: string, permission: string): Promise<boolean> {
    const [row] = await db.select().from(rolePermissions)
      .where(and(eq(rolePermissions.role, role), eq(rolePermissions.permission, permission)));
    return !!row;
  }

  async createSpvEntity(data: InsertSpvEntity): Promise<SpvEntity> {
    const [created] = await db.insert(spvEntities).values(data).returning();
    return created;
  }

  async getSpvEntity(id: string): Promise<SpvEntity | undefined> {
    const [row] = await db.select().from(spvEntities).where(eq(spvEntities.id, id));
    return row;
  }

  async getSpvEntitiesByAsset(assetId: string): Promise<SpvEntity[]> {
    return db.select().from(spvEntities).where(eq(spvEntities.assetId, assetId));
  }

  async getAllSpvEntities(tenantId?: string): Promise<SpvEntity[]> {
    if (tenantId) {
      return db.select().from(spvEntities).where(eq(spvEntities.tenantId, tenantId));
    }
    return db.select().from(spvEntities);
  }

  async createShareClass(data: InsertShareClass): Promise<ShareClass> {
    const [created] = await db.insert(shareClasses).values(data).returning();
    return created;
  }

  async getShareClass(id: string): Promise<ShareClass | undefined> {
    const [row] = await db.select().from(shareClasses).where(eq(shareClasses.id, id));
    return row;
  }

  async getShareClassesBySpv(spvId: string): Promise<ShareClass[]> {
    return db.select().from(shareClasses).where(eq(shareClasses.spvId, spvId));
  }

  async getAllShareClasses(tenantId?: string): Promise<ShareClass[]> {
    if (tenantId) {
      return db.select().from(shareClasses).where(eq(shareClasses.tenantId, tenantId));
    }
    return db.select().from(shareClasses);
  }

  async createToken(data: InsertToken): Promise<Token> {
    const [created] = await db.insert(tokens).values(data).returning();
    return created;
  }

  async getToken(id: string): Promise<Token | undefined> {
    const [row] = await db.select().from(tokens).where(eq(tokens.id, id));
    return row;
  }

  async getTokensByShareClass(shareClassId: string): Promise<Token[]> {
    return db.select().from(tokens).where(eq(tokens.shareClassId, shareClassId));
  }

  async getAllTokens(tenantId?: string): Promise<Token[]> {
    if (tenantId) {
      return db.select().from(tokens).where(eq(tokens.tenantId, tenantId));
    }
    return db.select().from(tokens);
  }

  async updateTokenFrozen(id: string, frozen: boolean): Promise<Token | undefined> {
    const [updated] = await db.update(tokens).set({ frozen }).where(eq(tokens.id, id)).returning();
    return updated;
  }

  async getTokensByVehicle(vehicleId: string): Promise<Token[]> {
    return db.select().from(tokens).where(eq(tokens.vehicleId, vehicleId));
  }

  async getTokenByAssetId(assetId: string): Promise<Token | undefined> {
    const directRows = await db.select().from(tokens).where(eq(tokens.assetId, assetId));
    if (directRows.length > 0) {
      if (directRows.length > 1) {
        console.warn(`[tokenization] Asset ${assetId} has ${directRows.length} direct tokens; using first.`);
      }
      return directRows[0];
    }

    const rows = await db
      .select({ token: tokens })
      .from(tokens)
      .innerJoin(shareClasses, eq(tokens.shareClassId, shareClasses.id))
      .innerJoin(spvEntities, eq(shareClasses.spvId, spvEntities.id))
      .where(eq(spvEntities.assetId, assetId));
    if (rows.length === 0) return undefined;
    if (rows.length > 1) {
      console.warn(`[tokenization] Asset ${assetId} has ${rows.length} tokens via SPV; using first.`);
    }
    return rows[0].token;
  }

  async getTokenHolding(userId: string, tokenId: string): Promise<TokenHolding | undefined> {
    const [row] = await db.select().from(tokenHoldings)
      .where(and(eq(tokenHoldings.userId, userId), eq(tokenHoldings.tokenId, tokenId)));
    return row;
  }

  async getTokenHoldingsByUser(userId: string): Promise<TokenHolding[]> {
    return db.select().from(tokenHoldings).where(eq(tokenHoldings.userId, userId));
  }

  async getTokenHoldingsByToken(tokenId: string): Promise<TokenHolding[]> {
    return db.select().from(tokenHoldings).where(eq(tokenHoldings.tokenId, tokenId));
  }

  async upsertTokenHolding(userId: string, tokenId: string, balance: string): Promise<TokenHolding> {
    const balanceNum = parseFloat(balance);
    if (balanceNum < 0) {
      throw new Error(`Token holding balance cannot go negative (attempted: ${balance})`);
    }
    const existing = await this.getTokenHolding(userId, tokenId);
    if (existing) {
      const [updated] = await db.update(tokenHoldings)
        .set({ balance, updatedAt: new Date() })
        .where(eq(tokenHoldings.id, existing.id))
        .returning();
      return updated;
    }
    const [created] = await db.insert(tokenHoldings)
      .values({ userId, tokenId, balance })
      .returning();
    return created;
  }

  async createTokenTransfer(data: InsertTokenTransfer): Promise<TokenTransfer> {
    const [created] = await db.insert(tokenTransfers).values(data).returning();
    return created;
  }

  async getTokenTransfer(id: string): Promise<TokenTransfer | undefined> {
    const [row] = await db.select().from(tokenTransfers).where(eq(tokenTransfers.id, id));
    return row;
  }

  async getTokenTransfersByUser(userId: string): Promise<TokenTransfer[]> {
    return db.select().from(tokenTransfers)
      .where(sql`${tokenTransfers.fromUserId} = ${userId} OR ${tokenTransfers.toUserId} = ${userId}`)
      .orderBy(desc(tokenTransfers.createdAt));
  }

  async getTokenTransfersByToken(tokenId: string): Promise<TokenTransfer[]> {
    return db.select().from(tokenTransfers)
      .where(eq(tokenTransfers.tokenId, tokenId))
      .orderBy(desc(tokenTransfers.createdAt));
  }

  async updateTokenTransferStatus(id: string, status: string): Promise<TokenTransfer | undefined> {
    const [updated] = await db.update(tokenTransfers)
      .set({ status })
      .where(eq(tokenTransfers.id, id))
      .returning();
    return updated;
  }

  async createTokenLedgerEntry(data: InsertTokenLedgerEntry): Promise<TokenLedgerEntry> {
    const [created] = await db.insert(tokenLedgerEntries).values(data).returning();
    return created;
  }

  async getTokenLedgerEntriesByToken(tokenId: string): Promise<TokenLedgerEntry[]> {
    return db.select().from(tokenLedgerEntries)
      .where(eq(tokenLedgerEntries.tokenId, tokenId))
      .orderBy(desc(tokenLedgerEntries.createdAt));
  }

  async getTokenLedgerEntriesByUser(userId: string): Promise<TokenLedgerEntry[]> {
    return db.select().from(tokenLedgerEntries)
      .where(sql`${tokenLedgerEntries.fromUserId} = ${userId} OR ${tokenLedgerEntries.toUserId} = ${userId}`)
      .orderBy(desc(tokenLedgerEntries.createdAt));
  }

  async computeTokenBalanceFromLedger(userId: string, tokenId: string): Promise<string> {
    const entries = await db.select().from(tokenLedgerEntries)
      .where(sql`(${tokenLedgerEntries.toUserId} = ${userId} OR ${tokenLedgerEntries.fromUserId} = ${userId}) AND ${tokenLedgerEntries.tokenId} = ${tokenId}`);
    let balance = 0;
    for (const entry of entries) {
      const amt = parseFloat(entry.amount);
      if (entry.toUserId === userId) balance += amt;
      if (entry.fromUserId === userId) balance -= amt;
    }
    return balance.toFixed(6);
  }

  async getTokenIssuancesByOffering(offeringId: string): Promise<TokenIssuance[]> {
    return db.select().from(tokenIssuances)
      .where(sql`${tokenIssuances.issuanceReport}->>'offeringId' = ${offeringId}`);
  }

  async updateTokenTotalSupply(id: string, totalSupply: string): Promise<Token | undefined> {
    const [updated] = await db.update(tokens)
      .set({ totalSupply })
      .where(eq(tokens.id, id))
      .returning();
    return updated;
  }

  async updateToken(id: string, data: Partial<{ frozen: boolean; transferRestrictions: any }>): Promise<Token | undefined> {
    const [updated] = await db.update(tokens)
      .set(data)
      .where(eq(tokens.id, id))
      .returning();
    return updated;
  }

  async updateRoundStatus(roundId: string, status: string): Promise<Round | undefined> {
    const [updated] = await db.update(rounds)
      .set({ status })
      .where(eq(rounds.id, roundId))
      .returning();
    return updated;
  }

  async updateShareClassTotalSupply(id: string, totalSupply: string): Promise<ShareClass | undefined> {
    const [updated] = await db.update(shareClasses)
      .set({ totalSupply })
      .where(eq(shareClasses.id, id))
      .returning();
    return updated;
  }

  async createTokenIssuance(data: InsertTokenIssuance): Promise<TokenIssuance> {
    const [created] = await db.insert(tokenIssuances).values(data).returning();
    return created;
  }

  async getTokenIssuancesByRound(roundId: string): Promise<TokenIssuance[]> {
    return db.select().from(tokenIssuances).where(eq(tokenIssuances.roundId, roundId));
  }

  async getTokenIssuancesByAsset(assetId: string): Promise<TokenIssuance[]> {
    return db.select().from(tokenIssuances).where(eq(tokenIssuances.assetId, assetId));
  }

  async getAllTokenIssuances(tenantId?: string): Promise<TokenIssuance[]> {
    if (tenantId) {
      return db.select().from(tokenIssuances).where(eq(tokenIssuances.tenantId, tenantId)).orderBy(desc(tokenIssuances.createdAt));
    }
    return db.select().from(tokenIssuances).orderBy(desc(tokenIssuances.createdAt));
  }

  async createTokenCorporateAction(data: InsertTokenCorporateAction): Promise<TokenCorporateAction> {
    const [created] = await db.insert(tokenCorporateActions).values(data).returning();
    return created;
  }

  async getTokenCorporateActionsByToken(tokenId: string): Promise<TokenCorporateAction[]> {
    return db.select().from(tokenCorporateActions)
      .where(eq(tokenCorporateActions.tokenId, tokenId))
      .orderBy(desc(tokenCorporateActions.createdAt));
  }

  async getAllTokenCorporateActions(tenantId?: string): Promise<TokenCorporateAction[]> {
    if (tenantId) {
      return db.select().from(tokenCorporateActions).where(eq(tokenCorporateActions.tenantId, tenantId)).orderBy(desc(tokenCorporateActions.createdAt));
    }
    return db.select().from(tokenCorporateActions).orderBy(desc(tokenCorporateActions.createdAt));
  }

  async createTokenCertificate(data: InsertTokenCertificate): Promise<TokenCertificate> {
    const [created] = await db.insert(tokenCertificates).values(data).returning();
    return created;
  }

  async getTokenCertificatesByUser(userId: string): Promise<TokenCertificate[]> {
    return db.select().from(tokenCertificates)
      .where(eq(tokenCertificates.userId, userId))
      .orderBy(desc(tokenCertificates.createdAt));
  }

  async getTokenCertificate(id: string): Promise<TokenCertificate | undefined> {
    const [row] = await db.select().from(tokenCertificates).where(eq(tokenCertificates.id, id));
    return row;
  }

  async createDocumentIngestion(data: InsertDocumentIngestion): Promise<DocumentIngestion> {
    const [created] = await db.insert(documentIngestions).values(data).returning();
    return created;
  }

  async getDocumentIngestion(id: string): Promise<DocumentIngestion | undefined> {
    const [row] = await db.select().from(documentIngestions).where(eq(documentIngestions.id, id));
    return row;
  }

  async getDocumentIngestionsByUser(userId: string): Promise<DocumentIngestion[]> {
    return db.select().from(documentIngestions).where(eq(documentIngestions.userId, userId)).orderBy(desc(documentIngestions.createdAt));
  }

  async getDocumentIngestionsByDocument(documentId: string): Promise<DocumentIngestion[]> {
    return db.select().from(documentIngestions).where(eq(documentIngestions.documentId, documentId)).orderBy(desc(documentIngestions.createdAt));
  }

  async getAllDocumentIngestions(tenantId?: string): Promise<DocumentIngestion[]> {
    if (tenantId) {
      return db.select().from(documentIngestions).where(eq(documentIngestions.tenantId, tenantId)).orderBy(desc(documentIngestions.createdAt));
    }
    return db.select().from(documentIngestions).orderBy(desc(documentIngestions.createdAt));
  }

  async updateDocumentIngestion(id: string, data: Partial<DocumentIngestion>): Promise<DocumentIngestion | undefined> {
    const [updated] = await db.update(documentIngestions).set({ ...data, updatedAt: new Date().toISOString() }).where(eq(documentIngestions.id, id)).returning();
    return updated;
  }

  async createInvestmentVehicle(data: InsertInvestmentVehicle): Promise<InvestmentVehicle> {
    const [vehicle] = await db.insert(investmentVehicles).values(data).returning();
    return vehicle;
  }

  async getInvestmentVehicle(id: string): Promise<InvestmentVehicle | undefined> {
    const [vehicle] = await db.select().from(investmentVehicles).where(eq(investmentVehicles.id, id));
    return vehicle;
  }

  async getAllInvestmentVehicles(tenantId?: string): Promise<InvestmentVehicle[]> {
    if (tenantId) {
      return db.select().from(investmentVehicles).where(eq(investmentVehicles.tenantId, tenantId)).orderBy(desc(investmentVehicles.createdAt));
    }
    return db.select().from(investmentVehicles).orderBy(desc(investmentVehicles.createdAt));
  }

  async updateInvestmentVehicle(id: string, data: Partial<InsertInvestmentVehicle>): Promise<InvestmentVehicle | undefined> {
    const [vehicle] = await db.update(investmentVehicles)
      .set({ ...data, updatedAt: new Date().toISOString() })
      .where(eq(investmentVehicles.id, id))
      .returning();
    return vehicle;
  }

  async updateInvestmentVehicleStatus(id: string, status: string): Promise<InvestmentVehicle | undefined> {
    const [vehicle] = await db.update(investmentVehicles)
      .set({ status, updatedAt: new Date().toISOString() })
      .where(eq(investmentVehicles.id, id))
      .returning();
    return vehicle;
  }

  async getAssetsByVehicle(vehicleId: string): Promise<Asset[]> {
    return db.select().from(assets).where(eq(assets.vehicleId, vehicleId));
  }

  async attachAssetToVehicle(assetId: string, vehicleId: string): Promise<Asset | undefined> {
    const [asset] = await db.update(assets)
      .set({ vehicleId })
      .where(eq(assets.id, assetId))
      .returning();
    return asset;
  }

  async detachAssetFromVehicle(assetId: string): Promise<Asset | undefined> {
    const [asset] = await db.update(assets)
      .set({ vehicleId: null })
      .where(eq(assets.id, assetId))
      .returning();
    return asset;
  }

  async createOffering(data: InsertOffering): Promise<Offering> {
    const [offering] = await db.insert(offerings).values(data).returning();
    return offering;
  }

  async getOffering(id: string): Promise<Offering | undefined> {
    const [offering] = await db.select().from(offerings).where(eq(offerings.id, id));
    return offering;
  }

  async getAllOfferings(tenantId?: string): Promise<Offering[]> {
    if (tenantId) {
      return db.select().from(offerings).where(eq(offerings.tenantId, tenantId)).orderBy(desc(offerings.createdAt));
    }
    return db.select().from(offerings).orderBy(desc(offerings.createdAt));
  }

  async getOfferingsByVehicle(vehicleId: string): Promise<Offering[]> {
    return db.select().from(offerings).where(eq(offerings.vehicleId, vehicleId)).orderBy(desc(offerings.createdAt));
  }

  async updateOffering(id: string, data: Partial<InsertOffering>): Promise<Offering | undefined> {
    const [offering] = await db.update(offerings)
      .set({ ...data, updatedAt: new Date().toISOString() })
      .where(eq(offerings.id, id))
      .returning();
    return offering;
  }

  async updateOfferingStatus(id: string, status: string): Promise<Offering | undefined> {
    const [offering] = await db.update(offerings)
      .set({ status, updatedAt: new Date().toISOString() })
      .where(eq(offerings.id, id))
      .returning();
    return offering;
  }

  async updateOfferingTotalCommitted(id: string, additionalAmount: string): Promise<Offering | undefined> {
    const [offering] = await db.update(offerings)
      .set({
        totalCommitted: sql`COALESCE(${offerings.totalCommitted}, 0) + ${additionalAmount}::decimal`,
        updatedAt: new Date().toISOString(),
      })
      .where(eq(offerings.id, id))
      .returning();
    return offering;
  }

  async atomicAddToOfferingCommitted(id: string, additionalAmount: string, targetAmount: string): Promise<Offering | undefined> {
    const [offering] = await db.update(offerings)
      .set({
        totalCommitted: sql`COALESCE(${offerings.totalCommitted}, 0) + ${additionalAmount}::decimal`,
        updatedAt: new Date().toISOString(),
      })
      .where(
        and(
          eq(offerings.id, id),
          sql`COALESCE(${offerings.totalCommitted}, 0) + ${additionalAmount}::decimal <= ${targetAmount}::decimal`
        )
      )
      .returning();
    return offering;
  }

  async getOpenOfferings(): Promise<Offering[]> {
    return db.select().from(offerings).where(eq(offerings.status, "OPEN")).orderBy(desc(offerings.createdAt));
  }

  async createCommitment(data: InsertCommitment): Promise<Commitment> {
    const [commitment] = await db.insert(commitments).values(data).returning();
    return commitment;
  }

  async getCommitment(id: string): Promise<Commitment | undefined> {
    const [commitment] = await db.select().from(commitments).where(eq(commitments.id, id));
    return commitment;
  }

  async getCommitmentsByOffering(offeringId: string): Promise<Commitment[]> {
    return db.select().from(commitments).where(eq(commitments.offeringId, offeringId)).orderBy(desc(commitments.createdAt));
  }

  async getCommitmentsByUser(userId: string): Promise<Commitment[]> {
    return db.select().from(commitments).where(eq(commitments.userId, userId)).orderBy(desc(commitments.createdAt));
  }

  async updateCommitmentStatus(id: string, status: string): Promise<Commitment | undefined> {
    const [commitment] = await db.update(commitments)
      .set({ status, updatedAt: new Date().toISOString() })
      .where(eq(commitments.id, id))
      .returning();
    return commitment;
  }

  async updateCommitment(id: string, data: Partial<InsertCommitment>): Promise<Commitment | undefined> {
    const [commitment] = await db.update(commitments)
      .set({ ...data, updatedAt: new Date().toISOString() })
      .where(eq(commitments.id, id))
      .returning();
    return commitment;
  }

  async getActiveCommitmentsByOffering(offeringId: string): Promise<Commitment[]> {
    return db.select().from(commitments)
      .where(and(
        eq(commitments.offeringId, offeringId),
        sql`${commitments.status} IN ('PENDING', 'CONFIRMED', 'COOLING_OFF')`
      ))
      .orderBy(desc(commitments.createdAt));
  }

  async checkDatabaseHealth() {
    let drizzleConnected = false;
    let prismaConnected = false;
    let userCount = 0;
    let assetCount = 0;
    let tableCount = 0;

    try {
      const drizzleUsers = await db.select().from(users);
      const drizzleAssets = await db.select().from(assets);
      drizzleConnected = true;
      userCount = drizzleUsers.length;
      assetCount = drizzleAssets.length;
    } catch {}

    try {
      const { prisma } = await import("./prisma");
      await prisma.$queryRaw`SELECT 1`;
      prismaConnected = true;
      const tables = await prisma.$queryRaw<Array<{ tablename: string }>>`
        SELECT tablename FROM pg_tables WHERE schemaname = 'public'
      `;
      tableCount = (tables as any[]).length;
    } catch {}

    return { drizzleConnected, prismaConnected, userCount, assetCount, tableCount };
  }

  async createValuationUpdate(data: InsertValuationUpdate): Promise<ValuationUpdate> {
    const [v] = await db.insert(valuationUpdates).values(data).returning();
    return v;
  }

  async getValuationUpdate(id: string): Promise<ValuationUpdate | undefined> {
    const [v] = await db.select().from(valuationUpdates).where(eq(valuationUpdates.id, id));
    return v;
  }

  async getValuationsByAsset(assetId: string): Promise<ValuationUpdate[]> {
    return db.select().from(valuationUpdates)
      .where(eq(valuationUpdates.assetId, assetId))
      .orderBy(desc(valuationUpdates.date));
  }

  async getLatestValuation(assetId: string): Promise<ValuationUpdate | undefined> {
    const [v] = await db.select().from(valuationUpdates)
      .where(eq(valuationUpdates.assetId, assetId))
      .orderBy(desc(valuationUpdates.date))
      .limit(1);
    return v;
  }

  async createSettlementEntry(data: InsertSettlementJournal): Promise<SettlementJournal> {
    const [entry] = await db.insert(settlementJournal).values(data).returning();
    return entry;
  }

  async getSettlementEntry(id: string): Promise<SettlementJournal | undefined> {
    const [entry] = await db.select().from(settlementJournal).where(eq(settlementJournal.id, id));
    return entry;
  }

  async getSettlementsByAsset(assetId: string): Promise<SettlementJournal[]> {
    return db.select().from(settlementJournal)
      .where(eq(settlementJournal.assetId, assetId))
      .orderBy(desc(settlementJournal.createdAt));
  }

  async getSettlementsByUser(userId: string): Promise<SettlementJournal[]> {
    return db.select().from(settlementJournal)
      .where(eq(settlementJournal.userId, userId))
      .orderBy(desc(settlementJournal.createdAt));
  }

  async getSettlementsByState(state: string): Promise<SettlementJournal[]> {
    return db.select().from(settlementJournal)
      .where(eq(settlementJournal.state, state))
      .orderBy(desc(settlementJournal.createdAt));
  }

  async getAllSettlements(tenantId?: string): Promise<SettlementJournal[]> {
    if (tenantId) {
      return db.select().from(settlementJournal).where(eq(settlementJournal.tenantId, tenantId)).orderBy(desc(settlementJournal.createdAt));
    }
    return db.select().from(settlementJournal)
      .orderBy(desc(settlementJournal.createdAt));
  }

  async getSettlementsByReference(referenceId: string): Promise<SettlementJournal[]> {
    return db.select().from(settlementJournal)
      .where(eq(settlementJournal.referenceId, referenceId))
      .orderBy(desc(settlementJournal.createdAt));
  }

  async advanceSettlement(id: string, data: { state: string; previousState: string; notes?: string; proofDocumentUrl?: string; advancedBy: string; advancedAt: string }): Promise<SettlementJournal | undefined> {
    const [updated] = await db.update(settlementJournal)
      .set({
        state: data.state,
        previousState: data.previousState,
        notes: data.notes,
        proofDocumentUrl: data.proofDocumentUrl,
        advancedBy: data.advancedBy,
        advancedAt: data.advancedAt,
      })
      .where(eq(settlementJournal.id, id))
      .returning();
    return updated;
  }

  async createSettlementDocument(data: InsertSettlementDocument): Promise<SettlementDocument> {
    const [doc] = await db.insert(settlementDocuments).values(data).returning();
    return doc;
  }

  async getSettlementDocuments(settlementJournalId: string): Promise<SettlementDocument[]> {
    return db.select().from(settlementDocuments)
      .where(eq(settlementDocuments.settlementJournalId, settlementJournalId))
      .orderBy(desc(settlementDocuments.createdAt));
  }

  async createAuditLog(data: InsertAuditLog): Promise<AuditLog> {
    const [log] = await db.insert(auditLogs).values(data).returning();
    return log;
  }

  async searchAuditLogs(filters: {
    actorId?: string;
    actionType?: string;
    entityType?: string;
    entityId?: string;
    from?: string;
    to?: string;
    search?: string;
    limit?: number;
    offset?: number;
  }): Promise<{ logs: AuditLog[]; total: number }> {
    const conditions: any[] = [];
    if (filters.actorId) conditions.push(eq(auditLogs.actorId, filters.actorId));
    if (filters.actionType) conditions.push(eq(auditLogs.actionType, filters.actionType));
    if (filters.entityType) conditions.push(eq(auditLogs.entityType, filters.entityType));
    if (filters.entityId) conditions.push(eq(auditLogs.entityId, filters.entityId));
    if (filters.from) conditions.push(gte(auditLogs.createdAt, filters.from));
    if (filters.to) conditions.push(sql`${auditLogs.createdAt} < ${filters.to}`);
    if (filters.search) {
      conditions.push(sql`(${auditLogs.reason} ILIKE ${'%' + filters.search + '%'} OR ${auditLogs.actionType} ILIKE ${'%' + filters.search + '%'} OR ${auditLogs.entityType} ILIKE ${'%' + filters.search + '%'})`);
    }

    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const [countResult] = await db.select({ count: sql<number>`count(*)::int` }).from(auditLogs).where(where);
    const total = countResult?.count || 0;

    const lim = filters.limit || 50;
    const off = filters.offset || 0;

    const logs = await db.select().from(auditLogs)
      .where(where)
      .orderBy(desc(auditLogs.createdAt))
      .limit(lim)
      .offset(off);

    return { logs, total };
  }

  async getPropertyAcquisition(assetId: string): Promise<PropertyAcquisition | undefined> {
    const [result] = await db.select().from(propertyAcquisitions).where(eq(propertyAcquisitions.assetId, assetId));
    return result;
  }

  async createPropertyAcquisition(data: InsertPropertyAcquisition): Promise<PropertyAcquisition> {
    const [result] = await db.insert(propertyAcquisitions).values(data).returning();
    return result;
  }

  async updatePropertyAcquisition(assetId: string, data: Partial<InsertPropertyAcquisition>): Promise<PropertyAcquisition | undefined> {
    const [result] = await db.update(propertyAcquisitions)
      .set({ ...data, updatedAt: new Date().toISOString() })
      .where(eq(propertyAcquisitions.assetId, assetId))
      .returning();
    return result;
  }

  async getAllPropertyAcquisitions(tenantId?: string): Promise<PropertyAcquisition[]> {
    if (tenantId) {
      return db.select().from(propertyAcquisitions).where(eq(propertyAcquisitions.tenantId, tenantId)).orderBy(desc(propertyAcquisitions.createdAt));
    }
    return db.select().from(propertyAcquisitions).orderBy(desc(propertyAcquisitions.createdAt));
  }

  async getPropertyUnit(assetId: string): Promise<PropertyUnit | undefined> {
    const [result] = await db.select().from(propertyUnits).where(eq(propertyUnits.assetId, assetId));
    return result;
  }

  async createPropertyUnit(data: InsertPropertyUnit): Promise<PropertyUnit> {
    const [result] = await db.insert(propertyUnits).values(data).returning();
    return result;
  }

  async updatePropertyUnit(assetId: string, data: Partial<InsertPropertyUnit>): Promise<PropertyUnit | undefined> {
    const [result] = await db.update(propertyUnits)
      .set({ ...data, updatedAt: new Date().toISOString() })
      .where(eq(propertyUnits.assetId, assetId))
      .returning();
    return result;
  }

  async getAllPropertyUnits(tenantId?: string): Promise<PropertyUnit[]> {
    if (tenantId) {
      return db.select().from(propertyUnits).where(eq(propertyUnits.tenantId, tenantId)).orderBy(desc(propertyUnits.createdAt));
    }
    return db.select().from(propertyUnits).orderBy(desc(propertyUnits.createdAt));
  }

  async getPropertyUnitLedger(assetId: string): Promise<PropertyUnitLedger[]> {
    return db.select().from(propertyUnitLedger)
      .where(eq(propertyUnitLedger.assetId, assetId))
      .orderBy(desc(propertyUnitLedger.createdAt));
  }

  async getPropertyUnitLedgerByUser(userId: string): Promise<PropertyUnitLedger[]> {
    return db.select().from(propertyUnitLedger)
      .where(eq(propertyUnitLedger.userId, userId))
      .orderBy(desc(propertyUnitLedger.createdAt));
  }

  async createPropertyUnitLedgerEntry(data: InsertPropertyUnitLedger): Promise<PropertyUnitLedger> {
    const [result] = await db.insert(propertyUnitLedger).values(data).returning();
    return result;
  }

  async getDeveloperPaymentsByAsset(assetId: string): Promise<DeveloperPayment[]> {
    return db.select().from(developerPaymentSchedule)
      .where(eq(developerPaymentSchedule.assetId, assetId))
      .orderBy(developerPaymentSchedule.sortOrder, developerPaymentSchedule.dueDate);
  }

  async createDeveloperPayment(data: InsertDeveloperPayment): Promise<DeveloperPayment> {
    const [result] = await db.insert(developerPaymentSchedule).values(data).returning();
    return result;
  }

  async updateDeveloperPayment(id: string, data: Partial<InsertDeveloperPayment>): Promise<DeveloperPayment | undefined> {
    const [result] = await db.update(developerPaymentSchedule)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(developerPaymentSchedule.id, id))
      .returning();
    return result;
  }

  async deleteDeveloperPayment(id: string): Promise<boolean> {
    const [result] = await db.delete(developerPaymentSchedule)
      .where(eq(developerPaymentSchedule.id, id))
      .returning();
    return !!result;
  }

  async getPropertySaleEvent(id: string): Promise<PropertySaleEvent | undefined> {
    const [result] = await db.select().from(propertySaleEvents).where(eq(propertySaleEvents.id, id));
    return result;
  }

  async getPropertySaleEventByAsset(assetId: string): Promise<PropertySaleEvent | undefined> {
    const [result] = await db.select().from(propertySaleEvents)
      .where(and(eq(propertySaleEvents.assetId, assetId), sql`${propertySaleEvents.status} != 'cancelled'`));
    return result;
  }

  async getAllPropertySaleEvents(tenantId?: string): Promise<PropertySaleEvent[]> {
    if (tenantId) {
      return db.select().from(propertySaleEvents).where(eq(propertySaleEvents.tenantId, tenantId)).orderBy(desc(propertySaleEvents.createdAt));
    }
    return db.select().from(propertySaleEvents).orderBy(desc(propertySaleEvents.createdAt));
  }

  async createPropertySaleEvent(data: InsertPropertySaleEvent): Promise<PropertySaleEvent> {
    const [result] = await db.insert(propertySaleEvents).values(data).returning();
    return result;
  }

  async updatePropertySaleEvent(id: string, data: Partial<InsertPropertySaleEvent>): Promise<PropertySaleEvent | undefined> {
    const [result] = await db.update(propertySaleEvents)
      .set({ ...data, updatedAt: new Date().toISOString() })
      .where(eq(propertySaleEvents.id, id))
      .returning();
    return result;
  }

  async getPropertySalePayouts(saleEventId: string): Promise<PropertySalePayout[]> {
    return db.select().from(propertySalePayouts)
      .where(eq(propertySalePayouts.saleEventId, saleEventId))
      .orderBy(desc(propertySalePayouts.totalPayout));
  }

  async getPropertySalePayoutsByUser(userId: string): Promise<PropertySalePayout[]> {
    return db.select().from(propertySalePayouts)
      .where(eq(propertySalePayouts.userId, userId))
      .orderBy(desc(propertySalePayouts.createdAt));
  }

  async createPropertySalePayout(data: InsertPropertySalePayout): Promise<PropertySalePayout> {
    const [result] = await db.insert(propertySalePayouts).values(data).returning();
    return result;
  }

  async getTenants(): Promise<Tenant[]> {
    return db.select().from(tenants);
  }

  async getTenant(id: string): Promise<Tenant | undefined> {
    const [t] = await db.select().from(tenants).where(eq(tenants.id, id));
    return t;
  }

  async getTenantBySlug(slug: string): Promise<Tenant | undefined> {
    const [t] = await db.select().from(tenants).where(eq(tenants.slug, slug));
    return t;
  }

  async createTenant(data: InsertTenant): Promise<Tenant> {
    const [created] = await db.insert(tenants).values(data).returning();
    return created;
  }

  async updateTenant(id: string, data: Partial<InsertTenant>): Promise<Tenant | undefined> {
    const [updated] = await db.update(tenants).set(data).where(eq(tenants.id, id)).returning();
    return updated;
  }

  async getTenantUsers(tenantId: string): Promise<TenantUser[]> {
    return db.select().from(tenantUsers).where(eq(tenantUsers.tenantId, tenantId));
  }

  async getTenantUser(tenantId: string, userId: string): Promise<TenantUser | undefined> {
    const [tu] = await db.select().from(tenantUsers).where(and(eq(tenantUsers.tenantId, tenantId), eq(tenantUsers.userId, userId)));
    return tu;
  }

  async createTenantUser(data: InsertTenantUser): Promise<TenantUser> {
    const [created] = await db.insert(tenantUsers).values(data).returning();
    return created;
  }

  async removeTenantUser(tenantId: string, userId: string): Promise<boolean> {
    const result = await db.delete(tenantUsers).where(and(eq(tenantUsers.tenantId, tenantId), eq(tenantUsers.userId, userId)));
    return true;
  }

  async getActiveTenants(): Promise<Tenant[]> {
    return db.select().from(tenants).where(eq(tenants.status, "ACTIVE"));
  }

  async updateTenantUser(tenantId: string, userId: string, data: Partial<{ role: string; status: string }>): Promise<TenantUser | undefined> {
    const [updated] = await db.update(tenantUsers)
      .set(data)
      .where(and(eq(tenantUsers.tenantId, tenantId), eq(tenantUsers.userId, userId)))
      .returning();
    return updated;
  }

  async getUserTenants(userId: string): Promise<TenantUser[]> {
    return db.select().from(tenantUsers).where(eq(tenantUsers.userId, userId));
  }

  async createImpersonationLog(data: InsertImpersonationLog): Promise<ImpersonationLog> {
    const [created] = await db.insert(impersonationLogs).values(data).returning();
    return created;
  }

  async getImpersonationLogs(limit: number = 50): Promise<ImpersonationLog[]> {
    return db.select().from(impersonationLogs).orderBy(desc(impersonationLogs.startedAt)).limit(limit);
  }

  async getTenantUserCount(tenantId: string): Promise<number> {
    const result = await db.select({ count: sql<number>`count(*)::int` })
      .from(tenantUsers)
      .where(and(eq(tenantUsers.tenantId, tenantId), eq(tenantUsers.status, "ACTIVE")));
    return result[0]?.count || 0;
  }

  async createProject(data: InsertProject): Promise<Project> {
    const [created] = await db.insert(projects).values(data).returning();
    return created;
  }

  async getProjectsByTenant(tenantId: string): Promise<Project[]> {
    return db.select().from(projects).where(eq(projects.tenantId, tenantId)).orderBy(desc(projects.createdAt));
  }

  async getProjectById(id: string): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async updateProject(id: string, data: Partial<InsertProject>): Promise<Project | undefined> {
    const [updated] = await db.update(projects).set({ ...data, updatedAt: new Date().toISOString() }).where(eq(projects.id, id)).returning();
    return updated;
  }

  async deleteProject(id: string): Promise<boolean> {
    await db.delete(projectMembers).where(eq(projectMembers.projectId, id));
    await db.delete(projectActivityLogs).where(eq(projectActivityLogs.projectId, id));
    await db.delete(projects).where(eq(projects.id, id));
    return true;
  }

  async addProjectMember(data: InsertProjectMember): Promise<ProjectMember> {
    const [created] = await db.insert(projectMembers).values(data).returning();
    return created;
  }

  async removeProjectMember(projectId: string, userId: string): Promise<boolean> {
    await db.delete(projectMembers).where(and(eq(projectMembers.projectId, projectId), eq(projectMembers.userId, userId)));
    return true;
  }

  async getProjectMembers(projectId: string): Promise<ProjectMember[]> {
    return db.select().from(projectMembers).where(eq(projectMembers.projectId, projectId));
  }

  async getProjectsForUser(userId: string, tenantId: string): Promise<Project[]> {
    const memberships = await db.select().from(projectMembers).where(eq(projectMembers.userId, userId));
    if (memberships.length === 0) return [];
    const projectIds = memberships.map(m => m.projectId);
    return db.select().from(projects).where(and(inArray(projects.id, projectIds), eq(projects.tenantId, tenantId))).orderBy(desc(projects.createdAt));
  }

  async addProjectActivityLog(data: InsertProjectActivityLog): Promise<ProjectActivityLog> {
    const [created] = await db.insert(projectActivityLogs).values(data).returning();
    return created;
  }

  async getProjectActivityLogs(projectId: string): Promise<ProjectActivityLog[]> {
    return db.select().from(projectActivityLogs).where(eq(projectActivityLogs.projectId, projectId)).orderBy(desc(projectActivityLogs.createdAt));
  }

  async getLockupRules(tenantId?: string): Promise<LockupRule[]> {
    if (tenantId) {
      return db.select().from(lockupRules).where(eq(lockupRules.tenantId, tenantId));
    }
    return db.select().from(lockupRules);
  }

  async getLockupRuleByAsset(assetId: string): Promise<LockupRule | undefined> {
    const [rule] = await db.select().from(lockupRules).where(eq(lockupRules.assetId, assetId));
    return rule;
  }

  async createLockupRule(data: InsertLockupRule): Promise<LockupRule> {
    const [created] = await db.insert(lockupRules).values(data).returning();
    return created;
  }

  async updateLockupRule(id: string, data: Partial<InsertLockupRule>): Promise<LockupRule | undefined> {
    const [updated] = await db.update(lockupRules).set({ ...data, updatedAt: new Date().toISOString() }).where(eq(lockupRules.id, id)).returning();
    return updated;
  }

  async deleteLockupRule(id: string): Promise<boolean> {
    const result = await db.delete(lockupRules).where(eq(lockupRules.id, id)).returning();
    return result.length > 0;
  }

  async createAppointment(data: InsertAppointment): Promise<Appointment> {
    const [created] = await db.insert(appointments).values(data).returning();
    return created;
  }

  async getAppointmentsByUser(userId: string): Promise<Appointment[]> {
    return db.select().from(appointments).where(eq(appointments.userId, userId)).orderBy(desc(appointments.createdAt));
  }

  async getAppointmentsByAgent(agentUserId: string): Promise<Appointment[]> {
    return db.select().from(appointments).where(eq(appointments.assignedToUserId, agentUserId)).orderBy(desc(appointments.createdAt));
  }

  async getAllAppointments(): Promise<Appointment[]> {
    return db.select().from(appointments).orderBy(desc(appointments.createdAt));
  }

  async getAppointmentById(id: string): Promise<Appointment | undefined> {
    const [appt] = await db.select().from(appointments).where(eq(appointments.id, id));
    return appt;
  }

  async updateAppointment(id: string, data: Partial<InsertAppointment> & { updatedAt?: string }): Promise<Appointment | undefined> {
    const [updated] = await db.update(appointments).set({ ...data, updatedAt: new Date().toISOString() }).where(eq(appointments.id, id)).returning();
    return updated;
  }

  async createEmailLog(data: InsertEmailLog): Promise<EmailLog> {
    const [created] = await db.insert(emailLogs).values(data).returning();
    return created;
  }

  async getEmailLogs(filters: { limit?: number; offset?: number; status?: string }): Promise<{ logs: EmailLog[]; total: number }> {
    const limit = filters.limit || 50;
    const offset = filters.offset || 0;

    const conditions = [];
    if (filters.status) {
      conditions.push(eq(emailLogs.status, filters.status));
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    const [countResult] = await db.select({ count: sql<number>`count(*)::int` }).from(emailLogs).where(whereClause);
    const logs = await db.select().from(emailLogs).where(whereClause).orderBy(desc(emailLogs.createdAt)).limit(limit).offset(offset);

    return { logs, total: countResult?.count || 0 };
  }

  async updateTransactionStatus(id: string, status: string): Promise<Transaction | undefined> {
    const [updated] = await db.update(transactions).set({ status }).where(eq(transactions.id, id)).returning();
    return updated;
  }

  async updateEmailLogStatus(id: string, status: string): Promise<void> {
    await db.update(emailLogs).set({ status }).where(eq(emailLogs.id, id));
  }

  async createSubscriber(data: InsertSubscriber): Promise<Subscriber> {
    const [created] = await db.insert(subscribers).values(data).returning();
    return created;
  }

  async getSubscriberByEmail(email: string): Promise<Subscriber | undefined> {
    const [sub] = await db.select().from(subscribers).where(eq(subscribers.email, email));
    return sub;
  }

  async getSubscribers(filters?: { region?: string; isActive?: boolean }): Promise<Subscriber[]> {
    const conditions = [];
    if (filters?.region) conditions.push(eq(subscribers.region, filters.region));
    if (filters?.isActive !== undefined) conditions.push(eq(subscribers.isActive, filters.isActive));
    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;
    return db.select().from(subscribers).where(whereClause).orderBy(desc(subscribers.createdAt));
  }

  async getSubscriberCount(): Promise<number> {
    const [result] = await db.select({ count: sql<number>`count(*)::int` }).from(subscribers);
    return result?.count || 0;
  }

  async createCampaign(data: InsertCampaign): Promise<Campaign> {
    const [created] = await db.insert(campaigns).values(data).returning();
    return created;
  }

  async getCampaigns(): Promise<Campaign[]> {
    return db.select().from(campaigns).orderBy(desc(campaigns.createdAt));
  }

  async updateCampaignStatus(id: string, status: string, recipientCount?: number): Promise<Campaign | undefined> {
    const setData: Record<string, any> = { status };
    if (recipientCount !== undefined) setData.recipientCount = recipientCount;
    const [updated] = await db.update(campaigns).set(setData).where(eq(campaigns.id, id)).returning();
    return updated;
  }

  async createOtpCode(data: InsertOtpCode): Promise<OtpCode> {
    const [created] = await db.insert(otpCodes).values(data).returning();
    return created;
  }

  async getOtpByTransaction(transactionId: string): Promise<OtpCode | undefined> {
    const [otp] = await db.select().from(otpCodes)
      .where(and(eq(otpCodes.transactionId, transactionId), eq(otpCodes.verified, false)))
      .orderBy(desc(otpCodes.createdAt))
      .limit(1);
    return otp;
  }

  async incrementOtpAttempts(id: string): Promise<OtpCode | undefined> {
    const [updated] = await db.update(otpCodes)
      .set({ attempts: sql`${otpCodes.attempts} + 1` })
      .where(eq(otpCodes.id, id))
      .returning();
    return updated;
  }

  async markOtpVerified(id: string): Promise<void> {
    await db.update(otpCodes).set({ verified: true }).where(eq(otpCodes.id, id));
  }

  async createSession(data: InsertSession): Promise<Session> {
    const [session] = await db.insert(sessions).values(data).returning();
    return session;
  }

  async getSessionByToken(token: string): Promise<Session | undefined> {
    const [session] = await db.select().from(sessions)
      .where(and(eq(sessions.token, token), sql`${sessions.revokedAt} IS NULL`));
    return session;
  }

  async revokeSession(id: string): Promise<void> {
    await db.update(sessions).set({ revokedAt: new Date().toISOString() }).where(eq(sessions.id, id));
  }

  async revokeUserSessions(userId: string): Promise<void> {
    await db.update(sessions)
      .set({ revokedAt: new Date().toISOString() })
      .where(and(eq(sessions.userId, userId), sql`${sessions.revokedAt} IS NULL`));
  }

  async getActiveSessions(userId: string): Promise<Session[]> {
    return db.select().from(sessions)
      .where(and(
        eq(sessions.userId, userId),
        sql`${sessions.revokedAt} IS NULL`,
        sql`${sessions.expiresAt}::timestamptz > now()`
      ))
      .orderBy(desc(sessions.createdAt));
  }

  async cleanExpiredSessions(): Promise<number> {
    const result = await db.delete(sessions)
      .where(sql`${sessions.expiresAt}::timestamptz < now()`)
      .returning();
    return result.length;
  }
}

export const storage = new DatabaseStorage();
