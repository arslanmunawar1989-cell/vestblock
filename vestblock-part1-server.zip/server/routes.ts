import type { Express } from "express";
import { createServer, type Server } from "http";
import path from "path";
import fs from "fs";
import { requireAuth, requireRole } from "./auth";
import { requestLogger } from "./middleware/request-logger";
import { registerObjectStorageRoutes } from "./replit_integrations/object_storage";
import {
  registerAuthRoutes,
  registerProfileRoutes,
  registerKycRoutes,
  registerAmlRoutes,
  registerLegalRoutes,
  registerBankRoutes,
  registerWalletRoutes,
  registerFeesRoutes,
  registerPaymentsRoutes,
  registerFxRoutes,
  registerPublicRoutes,
  registerCountryProfileRoutes,
  registerReceivingBanksRoutes,
  registerInvestRoutes,
  registerDistributionRoutes,
  registerTradeRoutes,
  syncExitWindowStatuses,
  registerMarketplaceRoutes,
  registerAdminStatsRoutes,
  registerFxConfigRoutes,
  registerReconciliationRoutes,
  registerReceiptRoutes,
  registerCryptoWalletRoutes,
  registerCryptoDepositRoutes,
  registerTicketRoutes,
  registerIssuerAssetRoutes,
  registerTaxReportRoutes,
  registerRolePermissionsRoutes,
  registerSystemStatusRoutes,
  registerTokenizationRoutes,
  registerDocumentIngestionRoutes,
  registerVehicleRoutes,
  registerOfferingRoutes,
  registerFinanceRoutes,
  registerDataRoomRoutes,
  registerPolicyRoutes,
  registerPropertyRoutes,
  registerFinanceConsoleRoutes,
  registerAuditLogRoutes,
  registerNotificationRoutes,
  registerTenantRoutes,
  registerTenantUsersRoutes,
  registerGoogleAuthRoutes,
  registerProjectRoutes,
  registerAnalyticsRoutes,
  registerAccountLifecycleRoutes,
  registerTenantExportRoutes,
  registerLockupRulesRoutes,
  registerCmsRoutes,
  registerAiRoutes,
  registerAppointmentRoutes,
  registerEmailOutboxRoutes,
  registerTransactionApiRoutes,
  registerMarketingRoutes,
  registerOtpRoutes,
  registerHealthRoutes,
  registerTestConsoleRoutes,
} from "./controllers";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.use(requestLogger);

  function findZip(): string | null {
    const candidates = [
      path.join(process.cwd(), "vestblock-complete.zip"),
      "/home/runner/workspace/vestblock-complete.zip",
    ];
    try {
      const dirn = path.dirname(new URL(import.meta.url).pathname);
      candidates.push(path.join(dirn, "..", "vestblock-complete.zip"));
      candidates.push(path.join(dirn, "public", "vestblock-complete.zip"));
    } catch {}
    for (const p of candidates) {
      if (fs.existsSync(p)) return p;
    }
    return null;
  }

  app.get("/api/download", (_req, res) => {
    const zipPath = path.join(process.cwd(), "vestblock-project.zip");
    let zipSize = "~40 MB";
    let zipExists = false;
    try {
      const stat = fs.statSync(zipPath);
      zipSize = (stat.size / (1024 * 1024)).toFixed(1) + " MB";
      zipExists = true;
    } catch {}
    res.setHeader("Content-Type", "text/html");
    res.send(`<!DOCTYPE html><html><head><title>Download VestBlock Project</title>
<style>*{margin:0;padding:0;box-sizing:border-box}body{min-height:100vh;display:flex;align-items:center;justify-content:center;background:#050B1A;color:#e2e8f0;font-family:'Plus Jakarta Sans',Inter,system-ui,sans-serif}
.card{background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);border-radius:20px;padding:48px;text-align:center;max-width:560px;width:90%}
h1{font-size:28px;margin-bottom:8px;font-weight:700}
p{font-size:14px;color:#94a3b8;margin-bottom:20px;line-height:1.6}
a.btn{display:inline-flex;align-items:center;gap:8px;padding:16px 40px;background:#1E2BFF;color:#fff;border-radius:14px;text-decoration:none;font-weight:700;font-size:16px;transition:all 0.2s}
a.btn:hover{background:#1825e0;transform:translateY(-1px);box-shadow:0 8px 24px rgba(30,43,255,0.3)}
a.btn svg{width:20px;height:20px}
.info{text-align:left;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:12px;padding:20px;margin:24px 0;font-size:13px;color:#94a3b8;line-height:1.8}
.info strong{color:#e2e8f0}
.info code{color:#93c5fd;font-family:monospace;font-size:12px;background:rgba(147,197,253,0.1);padding:2px 6px;border-radius:4px}
.badge{display:inline-block;padding:4px 12px;border-radius:20px;font-size:11px;font-weight:600;background:rgba(34,211,238,0.1);color:#22D3EE;margin-bottom:16px}
.size{font-size:12px;color:#64748b;margin-top:20px}
.warn{color:#fbbf24;font-size:13px;margin:16px 0}
</style></head>
<body><div class="card">
<div class="badge">COMPLETE PROJECT EXPORT</div>
<h1>VestBlock Project</h1>
<p>Enterprise fractional real estate investment platform — all source code, configs, assets, database schema, and documentation.</p>
${zipExists ?
  `<a href="/api/download/vestblock-project.zip" class="btn" download="vestblock-project.zip">
<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" /></svg>
Download ZIP (${zipSize})</a>` :
  `<p class="warn">Zip file is being prepared. Please refresh in a moment.</p>`}
<div class="info">
<strong>What's included (507 files):</strong><br>
- <code>client/</code> — 295 React/TypeScript frontend files (50+ pages, components, UI library)<br>
- <code>server/</code> — 143 Express backend files (controllers, services, middleware, AI integrations)<br>
- <code>shared/</code> — 20 schema files (40+ database tables, DTOs, policies)<br>
- <code>attached_assets/</code> — 30 image assets<br>
- Config files: <code>package.json</code>, <code>tsconfig.json</code>, <code>vite.config.ts</code>, <code>tailwind.config.ts</code>, <code>drizzle.config.ts</code>, etc.<br><br>
<strong>Setup on new Replit:</strong><br>
1. Upload zip &rarr; Extract all files<br>
2. Run <code>npm install</code> in Shell<br>
3. Create a PostgreSQL database<br>
4. Set secrets: <code>SESSION_SECRET</code>, <code>DATABASE_URL</code><br>
5. Run <code>npm run db:push</code> to create tables<br>
6. Run <code>npm run dev</code> to start
</div>
<p class="size">Excludes node_modules (auto-installed via npm install).</p>
</div></body></html>`);
  });

  app.get("/api/download/vestblock-complete.zip", (_req, res) => {
    const zipPath = findZip();
    if (zipPath) {
      const stat = fs.statSync(zipPath);
      res.setHeader("Content-Type", "application/octet-stream");
      res.setHeader("Content-Disposition", "attachment; filename=vestblock-complete.zip");
      res.setHeader("Content-Length", stat.size.toString());
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("X-Content-Type-Options", "nosniff");
      const stream = fs.createReadStream(zipPath);
      stream.pipe(res);
    } else {
      res.status(404).json({ error: "Zip file not found", cwd: process.cwd() });
    }
  });

  app.get("/api/download/vestblock-project.zip", (_req, res) => {
    const zipPath = path.join(process.cwd(), "vestblock-project.zip");
    if (fs.existsSync(zipPath)) {
      const stat = fs.statSync(zipPath);
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", "attachment; filename=vestblock-project.zip");
      res.setHeader("Content-Length", stat.size.toString());
      res.setHeader("Cache-Control", "no-cache");
      const stream = fs.createReadStream(zipPath);
      stream.pipe(res);
    } else {
      res.status(404).json({ error: "Project zip not found" });
    }
  });

  app.get("/api/download/vestblock-complete.tar.gz", (_req, res) => {
    const tarPath = path.join(process.cwd(), "vestblock-complete.tar.gz");
    if (fs.existsSync(tarPath)) {
      res.setHeader("Content-Type", "application/gzip");
      res.setHeader("Content-Disposition", "attachment; filename=vestblock-complete.tar.gz");
      const stream = fs.createReadStream(tarPath);
      stream.pipe(res);
    } else {
      res.status(404).send("File not found");
    }
  });

  registerAuthRoutes(app);
  registerGoogleAuthRoutes(app);
  registerPublicRoutes(app);
  registerProfileRoutes(app);
  registerKycRoutes(app);
  registerObjectStorageRoutes(app);
  registerAmlRoutes(app);
  registerLegalRoutes(app);
  registerBankRoutes(app);
  registerWalletRoutes(app);
  registerFeesRoutes(app);
  registerPaymentsRoutes(app);
  registerFxRoutes(app);
  registerCountryProfileRoutes(app);
  registerReceivingBanksRoutes(app);
  registerInvestRoutes(app);
  registerDistributionRoutes(app);
  registerTradeRoutes(app);
  registerMarketplaceRoutes(app);
  registerAdminStatsRoutes(app);
  registerFxConfigRoutes(app);
  registerReconciliationRoutes(app);
  registerReceiptRoutes(app);
  registerCryptoWalletRoutes(app);
  registerCryptoDepositRoutes(app);
  registerTicketRoutes(app);
  registerIssuerAssetRoutes(app);
  registerTaxReportRoutes(app);
  registerRolePermissionsRoutes(app);
  registerSystemStatusRoutes(app);
  registerTokenizationRoutes(app);
  registerDocumentIngestionRoutes(app);
  registerVehicleRoutes(app);
  registerOfferingRoutes(app);
  registerFinanceRoutes(app);
  registerDataRoomRoutes(app);
  registerPolicyRoutes(app);
  registerPropertyRoutes(app);
  registerFinanceConsoleRoutes(app);
  registerAuditLogRoutes(app);
  registerNotificationRoutes(app);
  registerTenantRoutes(app);
  registerTenantUsersRoutes(app);
  registerProjectRoutes(app);
  registerAnalyticsRoutes(app);
  registerAccountLifecycleRoutes(app);
  registerTenantExportRoutes(app);
  registerLockupRulesRoutes(app);
  registerCmsRoutes(app);
  registerAiRoutes(app);
  registerAppointmentRoutes(app);
  registerEmailOutboxRoutes(app);
  registerTransactionApiRoutes(app);
  registerMarketingRoutes(app);
  registerOtpRoutes(app);
  registerHealthRoutes(app);
  registerTestConsoleRoutes(app);

  syncExitWindowStatuses().catch(err => console.error("[ExitWindow] Initial sync error:", err));
  setInterval(() => {
    syncExitWindowStatuses().catch(err => console.error("[ExitWindow] Sync error:", err));
  }, 5 * 60 * 1000);

  app.post("/api/admin/exit-windows/sync", requireAuth, requireRole("admin"), async (_req, res) => {
    try {
      const result = await syncExitWindowStatuses();
      res.json({ message: "Exit window statuses synced", ...result });
    } catch (err: any) {
      res.status(500).json({ message: "Failed to sync" });
    }
  });

  app.get("/api/download/:filename", async (req, res) => {
    const fsAsync = await import("fs");
    const allowed = ["vestblock-complete.zip", "vestblock-complete-lean.zip", "vestblock-complete-project.tar.gz"];
    const filename = req.params.filename;
    if (!allowed.includes(filename)) {
      res.status(404).json({ message: "File not found" });
      return;
    }
    const filePath = path.join(process.cwd(), filename);
    if (fsAsync.existsSync(filePath)) {
      const stat = fsAsync.statSync(filePath);
      const contentType = filename.endsWith(".tar.gz") ? "application/gzip" : "application/zip";
      res.setHeader("Content-Type", contentType);
      res.setHeader("Content-Length", stat.size.toString());
      res.setHeader("Content-Disposition", `attachment; filename=${filename}`);
      const stream = fsAsync.createReadStream(filePath);
      stream.pipe(res);
      return;
    }
    res.status(404).json({ message: "Zip file not found." });
  });

  app.get("/api/download", (_req, res) => {
    res.setHeader("Content-Type", "text/html");
    res.send(`<!DOCTYPE html>
<html><head><title>VestBlock Download</title>
<style>body{font-family:system-ui;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;background:#111;color:#fff}
.card{background:#1a1a2e;border-radius:12px;padding:48px;text-align:center;max-width:600px}
h1{margin:0 0 12px}p{color:#aaa;margin:0 0 32px}
.btns{display:flex;flex-direction:column;gap:16px}
a{display:inline-block;padding:16px 48px;background:#4f46e5;color:#fff;text-decoration:none;border-radius:8px;font-size:18px;font-weight:600}
a:hover{background:#4338ca}
a.secondary{background:#374151;font-size:15px;padding:12px 32px}
a.secondary:hover{background:#4b5563}
small{color:#888;display:block;margin-top:6px;font-size:12px}
</style></head>
<body><div class="card"><h1>VestBlock Project</h1><p>Complete source code with all frontend, backend, shared schemas, assets, and configs.</p>
<div class="btns">
<div><a href="/api/download/vestblock-complete-lean.zip">Download Lean ZIP (13 MB)</a><small>All source code, assets, configs. Run "npm install" after extracting.</small></div>
<div><a class="secondary" href="/api/download/vestblock-complete.zip">Download Full ZIP (305 MB)</a><small>Includes node_modules — ready to run immediately.</small></div>
</div>
</div></body></html>`);
  });

  return httpServer;
}
