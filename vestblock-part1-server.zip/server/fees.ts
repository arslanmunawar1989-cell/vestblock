import { previewFee, type FeeCalculation } from "./services/fee-engine.service";
import type { FeeType } from "@shared/schema";

export type { FeeCalculation };

export async function calculateFee(
  feeType: FeeType,
  amount: number,
  currency?: string,
  vehicleId?: string
): Promise<FeeCalculation> {
  return previewFee(feeType, amount, currency, vehicleId);
}

export async function getFeePreview(
  feeType: FeeType,
  amount: number,
  currency?: string,
  vehicleId?: string
): Promise<FeeCalculation> {
  return previewFee(feeType, amount, currency, vehicleId);
}
