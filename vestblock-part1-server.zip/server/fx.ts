import { calculateFee } from "./fees";
import { applyFee } from "./services/fee-engine.service";
import { storage } from "./storage";
import type { FxQuote, FxTransaction, TierLimits, InsertLedgerEntry } from "@shared/schema";
import { fetchBestRate, listProviders } from "./fx-providers";
import type { FxRateResult } from "./fx-providers";
import crypto from "crypto";

function generateLedgerTxId(): string {
  return `ltx_fx_${crypto.randomUUID()}`;
}

const QUOTE_TTL_MINUTES = 5;

async function getEffectiveSpread(fromCurrency: string, toCurrency: string, baseSpread: number): Promise<number> {
  const config = await storage.getActiveFxSpreadConfig(fromCurrency, toCurrency);
  if (config && parseFloat(config.spreadOverride) > 0) {
    return parseFloat(config.spreadOverride);
  }
  return baseSpread;
}

function applySpreadToRate(baseRate: number, spread: number): number {
  return baseRate * (1 - spread);
}

export async function checkTierLimits(
  fromCurrency: string,
  toCurrency: string,
  amount: number,
  userTier: string,
): Promise<{ allowed: boolean; reason?: string }> {
  const config = await storage.getActiveFxSpreadConfig(fromCurrency, toCurrency);
  if (!config) return { allowed: true };

  const tierLimits = config.tierLimits as TierLimits | null;
  if (!tierLimits || !tierLimits[userTier]) return { allowed: true };

  const limits = tierLimits[userTier];
  if (amount < limits.minAmount) {
    return { allowed: false, reason: `Minimum conversion amount for ${userTier} tier is ${limits.minAmount} ${fromCurrency}` };
  }
  if (amount > limits.maxAmount) {
    return { allowed: false, reason: `Maximum conversion amount for ${userTier} tier is ${limits.maxAmount} ${fromCurrency}` };
  }
  return { allowed: true };
}

export async function checkApprovalRequired(
  fromCurrency: string,
  toCurrency: string,
  amount: number,
): Promise<{ required: boolean; threshold?: number }> {
  const config = await storage.getActiveFxSpreadConfig(fromCurrency, toCurrency);
  if (!config || !config.approvalRequired) return { required: false };

  const threshold = config.approvalThreshold ? parseFloat(config.approvalThreshold) : null;
  if (threshold === null) {
    return { required: true };
  }
  if (amount >= threshold) {
    return { required: true, threshold };
  }
  return { required: false };
}

export async function getLiveRate(base: string, quote: string): Promise<{
  rate: number;
  spread: number;
  provider: string;
  sourceLabel: string;
  fetchedAt: string;
  rateId: string;
} | null> {
  const result = await fetchBestRate(base, quote);
  if (!result) return null;

  const effectiveSpread = await getEffectiveSpread(base, quote, result.spread);
  const adjustedRate = effectiveSpread !== result.spread
    ? applySpreadToRate(result.rate / (1 - result.spread), effectiveSpread)
    : result.rate;

  return {
    rate: adjustedRate,
    spread: effectiveSpread,
    provider: result.provider,
    sourceLabel: result.sourceLabel,
    fetchedAt: result.fetchedAt.toISOString(),
    rateId: result.rateId,
  };
}

export function getActiveProviders() {
  return listProviders().filter(p => p.isConfigured()).map(p => ({ name: p.name, configured: true }));
}

export async function createQuote(
  fromCurrency: string,
  toCurrency: string,
  amount: number,
  userId?: string,
): Promise<FxQuote & { requiresApproval?: boolean } | null> {
  if (userId) {
    const user = await storage.getUser(userId);
    const userTier = user?.tier || "standard";
    const tierCheck = await checkTierLimits(fromCurrency, toCurrency, amount, userTier);
    if (!tierCheck.allowed) {
      throw new Error(tierCheck.reason || "Amount exceeds tier limits");
    }
  }

  const rateData = await getLiveRate(fromCurrency, toCurrency);
  if (!rateData) return null;

  const toAmountBeforeFee = parseFloat((amount * rateData.rate).toFixed(2));
  const { calculation: feeResult } = await applyFee({
    feeType: "fx",
    amount: toAmountBeforeFee,
    currency: toCurrency,
    userId: userId || undefined,
    referenceEntityType: "fx_quote",
    description: `FX spread fee: ${fromCurrency} → ${toCurrency}`,
  });

  const expiresAt = new Date(Date.now() + QUOTE_TTL_MINUTES * 60 * 1000);

  const approvalCheck = await checkApprovalRequired(fromCurrency, toCurrency, amount);

  const quoteStatus = approvalCheck.required ? "pending_approval" : "active";

  const quote = await storage.createFxQuote({
    fromCurrency,
    toCurrency,
    amountFrom: amount.toString(),
    rate: rateData.rate.toString(),
    spread: rateData.spread.toString(),
    fees: feeResult.fee.toString(),
    feeRate: feeResult.feeRate.toString(),
    amountTo: feeResult.netAmount.toString(),
    provider: rateData.provider,
    rateId: rateData.rateId,
    userId: userId || null,
    status: quoteStatus,
    expiresAt,
  });

  if (approvalCheck.required && userId) {
    await storage.createFxConversionRequest({
      userId,
      quoteId: quote.id,
      fromCurrency,
      toCurrency,
      amountFrom: amount.toString(),
      amountTo: feeResult.netAmount.toString(),
      thresholdAmount: approvalCheck.threshold?.toString() || null,
      status: "pending",
      reviewedBy: null,
      reviewedAt: null,
      reviewNotes: null,
    });
  }

  return { ...quote, requiresApproval: approvalCheck.required };
}

export async function executeConversion(
  userId: string,
  quoteId: string,
): Promise<{ fxTransaction: FxTransaction; referenceId: string; ledgerTxId: string }> {
  const quote = await storage.getFxQuoteById(quoteId);
  if (!quote) throw new Error("Quote not found");

  if (quote.status === "pending_approval") {
    const request = await storage.getFxConversionRequestByQuoteId(quoteId);
    if (!request || request.status !== "approved") {
      throw new Error("This conversion requires admin approval before it can be executed");
    }
  } else if (quote.status !== "active") {
    throw new Error("Quote is no longer active");
  }

  if (new Date(quote.expiresAt) < new Date()) {
    await storage.expireFxQuote(quoteId);
    throw new Error("Quote has expired");
  }

  if (quote.userId && quote.userId !== userId) {
    throw new Error("Quote does not belong to this user");
  }

  const fromAmount = parseFloat(quote.amountFrom);
  const fee = parseFloat(quote.fees);
  const spread = parseFloat(quote.spread);
  const rate = parseFloat(quote.rate);

  const midRate = spread > 0 ? rate / (1 - spread) : rate;
  const grossConvertedAtMid = fromAmount * midRate;
  const grossConverted = fromAmount * rate;
  const spreadAmount = Math.max(0, parseFloat((grossConvertedAtMid - grossConverted).toFixed(6)));
  const toAmountNet = parseFloat(quote.amountTo);

  const fromAccount = await storage.getOrCreateWallet(userId, quote.fromCurrency);

  const ledgerBalance = await storage.getLedgerBalance(fromAccount.id);
  const availableBalance = parseFloat(ledgerBalance.available);

  if (availableBalance < fromAmount) {
    throw new Error(`Insufficient ${quote.fromCurrency} balance. Available: ${availableBalance.toFixed(2)}`);
  }

  const toAccount = await storage.getOrCreateWallet(userId, quote.toCurrency);

  const referenceId = `fx_${Date.now()}`;
  const ledgerTxId = generateLedgerTxId();

  const ledgerEntries: InsertLedgerEntry[] = [
    {
      ledgerTxId,
      walletAccountId: fromAccount.id,
      currency: quote.fromCurrency,
      amount: fromAmount.toFixed(6),
      direction: "DEBIT",
      status: "POSTED",
      entryType: "FX_DEBIT",
      referenceId,
      description: `FX conversion: ${quote.fromCurrency} ${fromAmount} → ${quote.toCurrency} at rate ${rate}`,
      metadata: { quoteId, fxRate: rate, fromCurrency: quote.fromCurrency, toCurrency: quote.toCurrency },
    },
    {
      ledgerTxId,
      walletAccountId: toAccount.id,
      currency: quote.toCurrency,
      amount: grossConverted.toFixed(6),
      direction: "CREDIT",
      status: "POSTED",
      entryType: "FX_CREDIT",
      referenceId,
      description: `FX conversion: received ${quote.toCurrency} ${grossConverted.toFixed(2)} from ${quote.fromCurrency}`,
      metadata: { quoteId, fxRate: rate, fromCurrency: quote.fromCurrency, toCurrency: quote.toCurrency },
    },
  ];

  if (spreadAmount > 0) {
    ledgerEntries.push({
      ledgerTxId,
      walletAccountId: toAccount.id,
      currency: quote.toCurrency,
      amount: spreadAmount.toFixed(6),
      direction: "DEBIT",
      status: "POSTED",
      entryType: "FX_SPREAD",
      referenceId,
      description: `FX spread cost (${(spread * 100).toFixed(4)}%)`,
      metadata: { quoteId, spreadRate: spread, midRate, effectiveRate: rate },
    });
  }

  if (fee > 0) {
    ledgerEntries.push({
      ledgerTxId,
      walletAccountId: toAccount.id,
      currency: quote.toCurrency,
      amount: fee.toFixed(6),
      direction: "DEBIT",
      status: "POSTED",
      entryType: "FEE",
      referenceId,
      description: `FX conversion fee (${(parseFloat(quote.feeRate) * 100).toFixed(2)}%)`,
      metadata: { quoteId, feeRate: parseFloat(quote.feeRate) },
    });
  }

  await storage.createLedgerEntries(ledgerEntries);

  const fxTransaction = await storage.createFxTransaction({
    userId,
    quoteId,
    fromCurrency: quote.fromCurrency,
    toCurrency: quote.toCurrency,
    amountFrom: quote.amountFrom,
    amountTo: quote.amountTo,
    rateUsed: quote.rate,
    fees: quote.fees,
    spread: quote.spread,
    spreadAmount: spreadAmount.toFixed(6),
    status: "completed",
    referenceId,
    ledgerTxId,
  });

  await storage.createWalletTransaction({
    walletAccountId: fromAccount.id,
    type: "FX_CONVERT",
    amount: `-${fromAmount}`,
    currency: quote.fromCurrency,
    status: "COMPLETED",
    referenceId,
    description: `Converted ${quote.fromCurrency} ${fromAmount} to ${quote.toCurrency} at rate ${quote.rate}`,
    metadata: { fxTransactionId: fxTransaction.id, quoteId, ledgerTxId },
  });

  await storage.createWalletTransaction({
    walletAccountId: toAccount.id,
    type: "FX_CONVERT",
    amount: toAmountNet.toString(),
    currency: quote.toCurrency,
    status: "COMPLETED",
    referenceId,
    description: `Received ${quote.toCurrency} ${toAmountNet} from ${quote.fromCurrency} conversion`,
    metadata: { fxTransactionId: fxTransaction.id, quoteId, ledgerTxId },
  });

  if (fee > 0) {
    await storage.createWalletTransaction({
      walletAccountId: toAccount.id,
      type: "FEE",
      amount: `-${fee}`,
      currency: quote.toCurrency,
      status: "COMPLETED",
      referenceId,
      description: `FX conversion fee (${(parseFloat(quote.feeRate) * 100).toFixed(2)}%)`,
      metadata: { fxTransactionId: fxTransaction.id, quoteId, ledgerTxId },
    });
  }

  await storage.expireFxQuote(quoteId);

  return { fxTransaction, referenceId, ledgerTxId };
}

export async function getExchangeRate(from: string, to: string) {
  return getLiveRate(from, to);
}

export async function getFxQuote(
  fromCurrency: string,
  toCurrency: string,
  fromAmount: number,
) {
  const rateData = await getLiveRate(fromCurrency, toCurrency);
  if (!rateData) return null;

  const toAmountBeforeFee = parseFloat((fromAmount * rateData.rate).toFixed(2));
  const feeResult = await calculateFee("fx", toAmountBeforeFee, toCurrency);

  return {
    fromCurrency,
    toCurrency,
    rate: rateData.rate,
    spread: rateData.spread,
    sourceLabel: rateData.sourceLabel,
    rateUpdatedAt: rateData.fetchedAt,
    fromAmount,
    toAmountBeforeFee,
    fee: feeResult.fee,
    feeRate: feeResult.feeRate,
    toAmountAfterFee: feeResult.netAmount,
  };
}
