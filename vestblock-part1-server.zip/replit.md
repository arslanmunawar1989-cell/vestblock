# VestBlock — Fractional Real Estate Investment Platform

## Overview
Enterprise-grade fractional real estate investment platform supporting tokenized property investments across Pakistan, UAE, UK, USA, and Qatar. Multi-tenant architecture with role-based access, KYC/AML compliance, digital wallets, secondary market trading, and AI-powered tools.

## Tech Stack
- **Frontend**: React 18 + TypeScript + Vite, Tailwind CSS with glassmorphism design
- **Backend**: Express.js 5 (REST API), JWT + Google OAuth authentication
- **Database**: PostgreSQL (Neon) + Drizzle ORM, 95+ tables
- **Styling**: Royal blue palette (#EEF0FF–#1E2BFF), Plus Jakarta Sans font, glassmorphism UI with noise texture

## Architecture
- Multi-tenant: Platform tenant (PLATFORM_TENANT_ID) + user tenants
- Roles: investor, issuer, agent, agency, admin, super_admin
- 100+ frontend pages across marketing, investor, admin, issuer, agent, agency, CMS modules
- 50+ API controllers with rate limiting

## Key Features
- Multi-currency wallets (PKR, AED, GBP, USD, QAR, USDT, USDC)
- FX conversion with spread configs
- Tokenized property investments with SPV entities
- KYC/AML/EDD compliance pipeline
- Secondary market trading via exit windows
- Waterfall distribution calculator
- AI tools: ADT document summarizer, property match, ROI scenarios, Market Pulse
- Appointment scheduling (create/list/update with Zod validation + email notifications)
- Email service: dev mode (log-only) + production (Resend API); all emails logged to email_logs table
- Email marketing: subscriber management, CSV export, campaign send with segment filtering
- Transaction 2FA: OTP-based payment confirmation (6-digit code via email, 5min expiry, rate limiting)
- Transaction lifecycle (create/update-status with audit logging + email notifications)

## Project Structure
```
client/src/
  pages/          — marketing/, investor/, admin/, issuer/, agent/, agency/, cms/
  components/     — ui/ (shadcn), shared components
  lib/            — auth, queryClient, region, utils
server/
  controllers/    — 50+ domain controllers
  services/       — business logic (fee-engine, wallet, fx, etc.)
  middleware/     — auth, tenant-context, rate-limit, rbac
  lib/ai/         — AI providers, RAG pipeline
shared/
  schema.ts       — 100+ Drizzle ORM tables (2900+ lines)
  constants.ts    — platform tenant ID, config
```

## Authentication
- JWT tokens via httpOnly cookies with DB-persisted sessions
- Google OAuth via passport-google-oauth20 (requires GOOGLE_CLIENT_ID + GOOGLE_CLIENT_SECRET)
- Session table tracks active sessions per user (provider, IP, user-agent, expiry)
- Session revocation invalidates both DB session and token version
- Login pages: `/login` (full), `/auth/sign-in` (minimal with Google)
- Role mapping: CLIENT→investor, AGENT→agent, MANAGER→admin, WEBSITE_MANAGER→cms, SUPER_ADMIN→SUPER_ADMIN (platformRole)
- Default role for new users (including Google sign-ups): investor (CLIENT)

## PWA (Progressive Web App)
- Installable via manifest.json with VestBlock branding (theme: #1E2BFF, background: #EEF0FF)
- Service worker (sw.js) with strict caching:
  - Caches: app shell (/, offline.html, icons), static assets, public APIs (/api/properties/public, /api/auth/config, /api/regions)
  - Skips: authenticated APIs (/api/*), authenticated pages (/app/**, /admin/**, /agent/**, /agency/**, /issuer/**, /cms/**)
- Offline fallback: offline.html with VestBlock branding
- Update toast: minimal fixed-position notification when new SW version detected
- Apple meta tags for iOS home screen support
- Push notification support via VAPID (optional)

## Dashboard Pages (under /app/*)
- `/app/appointments` — Client appointment scheduling
- `/app/agent/appointments` — Agent appointment management
- `/app/manager/appointments` — Manager appointment assignment
- `/app/admin/email-outbox` — Admin email log viewer
- `/app/admin/test-console` — Admin-only bug bash test console with scenario runners
- `/app/manager/marketing` — Subscriber management + campaign sender
- `/app/wallet/confirm?txn=ID` — OTP verification for transactions

## Health Endpoints
- `GET /api/health` — System health (DB, auth, email status); public
- `GET /api/health/rbac` — Role mapping and RBAC config; admin-only
- `GET /api/health/pwa` — PWA asset readiness check; public

## Bug Bash System
- 10 QA test users seeded with @vestblock.test emails (password: password123)
- Users: vb_super_admin, vb_web_manager, vb_manager, vb_agent1, vb_agent2, vb_client1-5
- Sample data: 10 appointments, 10 transactions, 30 email logs, 50 subscribers, 2 campaigns, 10 audit logs
- Test console at /app/admin/test-console with 5 scenario runners (client journey, agent journey, manager journey, security/RBAC, email routing)
- All seed data is idempotent and scoped by @vestblock.test markers

## Running
- `npm run dev` starts Express + Vite dev server on port 5000
- `npm run db:push` to sync schema changes
- Seed runs automatically on server start

## Seeded Demo Users (password: password123)
- Agents: `khalid_malik`, `aisha_rahman`
- Investors: `james_wilson`, `lisa_chen`, `robert_kim`, `maria_santos`, `tariq_hussain`
- Admin: `agency_manager` (PLATFORM_ADMIN)
- Super Admin: created via SUPER_ADMIN_EMAIL env var

## Environment
- DATABASE_URL: PostgreSQL connection (auto-configured)
- SESSION_SECRET: Session encryption
- GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET: Optional Google OAuth
- AI_INTEGRATIONS_OPENAI_API_KEY: Optional for AI features
- RESEND_API_KEY / EMAIL_FROM: Optional for production email (Resend); without these, emails are logged only (dev mode)
