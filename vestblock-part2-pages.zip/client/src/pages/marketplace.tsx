import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, MapPin, TrendingUp, Building2, Filter, ArrowRight } from "lucide-react";
import { formatCurrency, formatPercent, formatNumber, getStatusColor } from "@/lib/format";
import type { Asset } from "@shared/schema";
import { useState } from "react";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";

export default function Marketplace() {
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [countryFilter, setCountryFilter] = useState("all");

  const { data: assets, isLoading } = useQuery<Asset[]>({
    queryKey: ["/api/assets"],
  });

  const filtered = assets?.filter((a) => {
    const matchSearch =
      !search ||
      a.name.toLowerCase().includes(search.toLowerCase()) ||
      (a.location || "").toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === "all" || a.assetType === typeFilter;
    const matchCountry = countryFilter === "all" || a.country === countryFilter;
    return matchSearch && matchType && matchCountry;
  });

  const types = assets ? Array.from(new Set(assets.map((a) => a.assetType))) : [];
  const countries = assets ? Array.from(new Set(assets.map((a) => a.country))) : [];

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-page-title">Marketplace</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Browse tokenized real estate investment opportunities
          </p>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <Badge variant="outline" className="self-start sm:self-auto" data-testid="badge-asset-count">
            {filtered?.length || 0} Properties
          </Badge>
          <Link href="/login">
            <Button size="sm" data-testid="button-investor-login">
              Investor Login
            </Button>
          </Link>
        </div>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search properties by name or location..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
                data-testid="input-search"
              />
            </div>
            <div className="flex gap-3 flex-wrap">
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-[140px]" data-testid="select-type">
                  <Filter className="w-3 h-3 mr-1.5" />
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  {types.map((t) => (
                    <SelectItem key={t} value={t}>{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={countryFilter} onValueChange={setCountryFilter}>
                <SelectTrigger className="w-[140px]" data-testid="select-country">
                  <MapPin className="w-3 h-3 mr-1.5" />
                  <SelectValue placeholder="Country" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Countries</SelectItem>
                  {countries.map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-0">
                <Skeleton className="h-40 w-full rounded-t-md" />
                <div className="p-4 space-y-3">
                  <Skeleton className="h-5 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                  <Skeleton className="h-8 w-full" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filtered?.length ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((asset) => {
            const totalSupply = parseFloat(asset.totalSupply) || 0;
            const pricePerToken = parseFloat(asset.pricePerToken) || 0;
            const totalValue = totalSupply * pricePerToken;
            return (
              <Link key={asset.id} href={`/marketplace/${asset.id}`}>
                <Card className="overflow-visible hover-elevate cursor-pointer" data-testid={`card-asset-${asset.id}`}>
                  <CardContent className="p-0">
                    <div className="relative h-40 bg-gradient-to-br from-primary/20 via-primary/5 to-transparent rounded-t-md flex items-center justify-center">
                      {asset.imageUrl ? (
                        <img
                          src={asset.imageUrl}
                          alt={asset.name}
                          className="w-full h-full object-cover rounded-t-md"
                        />
                      ) : (
                        <Building2 className="w-12 h-12 text-primary/30" />
                      )}
                      <div className="absolute top-3 left-3 flex gap-1.5">
                        <Badge className={getStatusColor(asset.status)}>{asset.status}</Badge>
                        <Badge variant="outline" className="bg-background/80 backdrop-blur-sm text-[10px]">
                          {asset.assetType}
                        </Badge>
                      </div>
                    </div>
                    <div className="p-4 space-y-3">
                      <div>
                        <h3 className="font-semibold text-sm truncate">{asset.name}</h3>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground mt-0.5">
                          <MapPin className="w-3 h-3" />
                          <span className="truncate">{asset.location || "—"}, {asset.country}</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-2 text-center">
                        <div>
                          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Value</p>
                          <p className="text-xs font-semibold font-mono mt-0.5">
                            {formatCurrency(totalValue, asset.baseCurrency)}
                          </p>
                        </div>
                        <div>
                          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Token</p>
                          <p className="text-xs font-semibold font-mono mt-0.5">
                            {formatCurrency(pricePerToken, asset.baseCurrency)}
                          </p>
                        </div>
                        <div>
                          <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Yield</p>
                          <p className="text-xs font-semibold font-mono text-emerald-500 mt-0.5">
                            {asset.annualYield ? formatPercent(asset.annualYield) : "—"}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between gap-2">
                        <div className="flex-1">
                          <p className="text-[10px] text-muted-foreground mb-1">
                            {formatNumber(totalSupply)} tokens available
                          </p>
                          <Progress value={0} className="h-1.5" />
                        </div>
                        <ArrowRight className="w-4 h-4 text-muted-foreground shrink-0" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <Building2 className="w-12 h-12 text-muted-foreground/30 mb-3" />
            <p className="text-sm text-muted-foreground">No properties found matching your criteria</p>
            <Button
              variant="outline"
              size="sm"
              className="mt-3"
              onClick={() => {
                setSearch("");
                setTypeFilter("all");
                setCountryFilter("all");
              }}
              data-testid="button-clear-filters"
            >
              Clear filters
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
