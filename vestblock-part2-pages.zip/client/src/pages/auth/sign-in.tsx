import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useAuth } from "@/lib/auth";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { LogIn, Eye, EyeOff } from "lucide-react";
import { SiGoogle } from "react-icons/si";

export default function SignIn() {
  const { login } = useAuth();
  const { toast } = useToast();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const { data: authConfig } = useQuery<{ googleEnabled: boolean }>({
    queryKey: ["/api/auth/config"],
  });

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const error = params.get("error");
    if (error) {
      const messages: Record<string, string> = {
        google_auth_failed: "Google sign-in failed. Please try again.",
        no_user: "Could not retrieve user information.",
        account_deactivated: "Your account has been deactivated.",
        account_disabled: "Your account has been disabled.",
        account_archived: "Your account has been archived.",
        no_tenant_access: "You do not have access to this organization.",
        callback_failed: "Something went wrong during sign-in.",
      };
      toast({
        title: "Sign-in error",
        description: messages[error] || "An error occurred during sign-in.",
        variant: "destructive",
      });
      window.history.replaceState({}, "", "/auth/sign-in");
    }
  }, [toast]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) return;
    setIsLoading(true);
    try {
      await login(username, password);
    } catch (err: any) {
      toast({
        title: "Login failed",
        description: err.message?.includes("401")
          ? "Invalid username or password"
          : "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative flex items-center justify-center p-4">
      <div className="fixed inset-0 gradient-hero opacity-100" />
      <div className="fixed inset-0 bg-gradient-to-b from-transparent via-transparent to-black/20" />

      <Card className="relative z-10 w-full max-w-md p-8 glass-light" data-testid="card-sign-in">
        <div className="flex items-center gap-2 mb-8">
          <div className="w-9 h-9 rounded-md gradient-hero flex items-center justify-center">
            <span className="text-white font-bold text-lg">V</span>
          </div>
          <span className="text-lg font-bold tracking-tight">VestBlock</span>
        </div>

        <h1 className="text-2xl font-bold mb-2" data-testid="heading-sign-in">Sign In</h1>
        <p className="text-sm text-muted-foreground mb-6">
          Sign in to access your account
        </p>

        {authConfig?.googleEnabled && (
          <>
            <Button
              variant="outline"
              className="w-full h-11"
              onClick={() => { window.location.href = "/api/auth/google"; }}
              data-testid="button-google-sign-in"
            >
              <span className="flex items-center gap-2">
                <SiGoogle className="w-4 h-4" />
                Sign in with Google
              </span>
            </Button>

            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-card px-2 text-muted-foreground">or continue with email</span>
              </div>
            </div>
          </>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="username">Username</Label>
            <Input
              id="username"
              type="text"
              placeholder="Enter username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              data-testid="input-username"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <div className="relative">
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                data-testid="input-password"
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-0 top-0"
                onClick={() => setShowPassword(!showPassword)}
                data-testid="button-toggle-password"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </Button>
            </div>
          </div>

          <Button
            type="submit"
            className="w-full"
            disabled={isLoading}
            data-testid="button-sign-in"
          >
            {isLoading ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Signing in...
              </span>
            ) : (
              <span className="flex items-center gap-2">
                <LogIn className="w-4 h-4" />
                Sign In
              </span>
            )}
          </Button>
        </form>

        <div className="mt-6 text-center text-sm">
          <span className="text-muted-foreground">Don't have an account? </span>
          <Link href="/register" className="text-primary font-medium" data-testid="link-register">
            Create one
          </Link>
        </div>
      </Card>
    </div>
  );
}
