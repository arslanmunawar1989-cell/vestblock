import { useParams, useLocation } from "wouter";
import { Sidebar } from "@/components/Sidebar";
import { Editor } from "@/components/Editor";
import { useNote, useUpdateNote, useDeleteNote } from "@/hooks/use-notes";
import { Loader2, FileText } from "lucide-react";

export default function NoteView() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const noteId = id ? parseInt(id) : null;
  
  const { data: note, isLoading, error } = useNote(noteId);
  const { mutate: updateNote, isPending: isSaving } = useUpdateNote();
  const { mutate: deleteNote } = useDeleteNote();

  const handleUpdate = (updates: { title?: string; content?: string }) => {
    if (noteId) {
      updateNote({ id: noteId, ...updates });
    }
  };

  const handleDelete = () => {
    if (noteId) {
      deleteNote(noteId, {
        onSuccess: () => setLocation("/")
      });
    }
  };

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden">
      <Sidebar />
      <main className="flex-1 h-full relative">
        {!noteId ? (
          <div className="h-full flex flex-col items-center justify-center text-muted-foreground p-8 animate-in fade-in duration-500">
            <div className="w-24 h-24 rounded-3xl bg-muted flex items-center justify-center mb-6 shadow-inner">
              <FileText className="w-10 h-10 opacity-20" />
            </div>
            <h2 className="text-2xl font-display font-semibold mb-2 text-foreground">Select a note to view</h2>
            <p className="max-w-md text-center">
              Choose a note from the sidebar or create a new one to get started. 
              Your thoughts are safe here.
            </p>
          </div>
        ) : isLoading ? (
          <div className="h-full flex items-center justify-center">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : error || !note ? (
          <div className="h-full flex flex-col items-center justify-center text-muted-foreground">
            <p className="text-lg">Note not found or deleted.</p>
          </div>
        ) : (
          <Editor 
            key={note.id} // Force re-render on ID change
            note={note} 
            onUpdate={handleUpdate}
            onDelete={handleDelete}
            isSaving={isSaving}
          />
        )}
      </main>
    </div>
  );
}
