import { useQuery } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { GradientHeader } from "@/components/gradient-header";
import { StatTile } from "@/components/stat-tile";
import { Section } from "@/components/section";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/lib/auth";
import { PLATFORM_TENANT_ID } from "@shared/constants";
import {
  FolderKanban, Users, CheckCircle, Clock, AlertTriangle,
  TrendingUp, TrendingDown, Activity, Heart, BarChart3,
} from "lucide-react";
import {
  ResponsiveContainer, LineChart, Line, BarChart, Bar,
  XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell,
} from "recharts";

const COLORS = ["#10b981", "#3b82f6", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4"];
const STATUS_COLORS: Record<string, string> = {
  PLANNING: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  IN_PROGRESS: "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200",
  ON_HOLD: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
  COMPLETED: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200",
  CANCELLED: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
};

interface AgencyAnalytics {
  kpis: {
    totalProjects: number;
    activeProjects: number;
    planningProjects: number;
    completedProjects: number;
    onHoldProjects: number;
    totalMembers: number;
    totalUsers: number;
    onTime: number;
    delayed: number;
    avgHealth: number;
    avgMarket: number;
  };
  charts: {
    projectsByStatus: { name: string; value: number }[];
    projectsByType: { name: string; value: number }[];
    healthDistribution: { name: string; health: number; market: number }[];
    activityTrend: { date: string; value: number }[];
    userGrowth: { date: string; value: number }[];
    onTimeVsDelayed: { name: string; value: number }[];
  };
  milestones: {
    id: string;
    projectId: string;
    action: string;
    details: string | null;
    createdAt: string;
    projectName: string;
  }[];
}

function formatDate(d: string) {
  const date = new Date(d);
  return `${date.getMonth() + 1}/${date.getDate()}`;
}

function ChartSkeleton() {
  return <Skeleton className="h-[260px] w-full" />;
}

function EmptyChart() {
  return (
    <div className="h-[260px] flex items-center justify-center text-sm text-muted-foreground" data-testid="text-no-chart-data">
      No data available
    </div>
  );
}

export default function AgencyDashboard() {
  const { user } = useAuth();
  const tenantId = user?.role === "admin" ? PLATFORM_TENANT_ID : (user as any)?.tenantId || PLATFORM_TENANT_ID;

  const { data, isLoading } = useQuery<AgencyAnalytics>({
    queryKey: ["/api/analytics/agency", tenantId],
    queryFn: async () => {
      const res = await fetch(`/api/analytics/agency/${tenantId}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch analytics");
      return res.json();
    },
    enabled: !!tenantId,
  });

  const kpis = data?.kpis;
  const charts = data?.charts;
  const milestones = data?.milestones || [];

  const healthTrend = (kpis?.avgHealth || 0) >= 70 ? "up" : "down";
  const marketTrend = (kpis?.avgMarket || 0) >= 50 ? "up" : "down";

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <GradientHeader>
          <div>
            <p className="text-white/80 text-sm mb-1">Agency Overview</p>
            <h1 className="text-2xl font-bold text-white">Agency Dashboard</h1>
          </div>
        </GradientHeader>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[...Array(8)].map((_, i) => <Skeleton key={i} className="h-28" />)}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <StatTile label="Total Projects" value={String(kpis?.totalProjects || 0)} icon={<FolderKanban className="w-5 h-5" />} data-testid="stat-total-projects" />
              <StatTile label="Active Projects" value={String(kpis?.activeProjects || 0)} icon={<Activity className="w-5 h-5" />} data-testid="stat-active-projects" />
              <StatTile label="Team Members" value={String(kpis?.totalUsers || 0)} icon={<Users className="w-5 h-5" />} data-testid="stat-team-members" />
              <StatTile label="Project Members" value={String(kpis?.totalMembers || 0)} icon={<Users className="w-5 h-5" />} data-testid="stat-project-members" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <StatTile label="On Time" value={String(kpis?.onTime || 0)} icon={<CheckCircle className="w-5 h-5" />} data-testid="stat-on-time" />
              <StatTile label="Delayed" value={String(kpis?.delayed || 0)} icon={<AlertTriangle className="w-5 h-5" />} data-testid="stat-delayed" />
              <StatTile
                label="Avg Health Score"
                value={String(kpis?.avgHealth || 0)}
                icon={healthTrend === "up" ? <TrendingUp className="w-5 h-5 text-emerald-500" /> : <TrendingDown className="w-5 h-5 text-red-500" />}
                data-testid="stat-avg-health"
              />
              <StatTile
                label="Avg Market Score"
                value={String(kpis?.avgMarket || 0)}
                icon={marketTrend === "up" ? <TrendingUp className="w-5 h-5 text-emerald-500" /> : <TrendingDown className="w-5 h-5 text-red-500" />}
                data-testid="stat-avg-market"
              />
            </div>
          </>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Activity className="w-4 h-4" /> Activity Trend (30 days)
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? <ChartSkeleton /> : (
                <ResponsiveContainer width="100%" height={260}>
                  <LineChart data={charts?.activityTrend}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="date" tickFormatter={formatDate} tick={{ fontSize: 11 }} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                    <Tooltip labelFormatter={v => `Date: ${v}`} contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                    <Line type="monotone" dataKey="value" name="Activities" stroke="#10b981" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Users className="w-4 h-4" /> User Growth (30 days)
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? <ChartSkeleton /> : (
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={charts?.userGrowth}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="date" tickFormatter={formatDate} tick={{ fontSize: 11 }} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                    <Tooltip labelFormatter={v => `Date: ${v}`} contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                    <Bar dataKey="value" name="New Users" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Projects by Status</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? <ChartSkeleton /> : (charts?.projectsByStatus?.length || 0) > 0 ? (
                <ResponsiveContainer width="100%" height={260}>
                  <PieChart>
                    <Pie data={charts?.projectsByStatus} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false}>
                      {charts?.projectsByStatus.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie>
                    <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                  </PieChart>
                </ResponsiveContainer>
              ) : <EmptyChart />}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">On Time vs Delayed</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? <ChartSkeleton /> : (charts?.onTimeVsDelayed?.length || 0) > 0 ? (
                <ResponsiveContainer width="100%" height={260}>
                  <PieChart>
                    <Pie data={charts?.onTimeVsDelayed} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false}>
                      <Cell fill="#10b981" />
                      <Cell fill="#ef4444" />
                    </Pie>
                    <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                  </PieChart>
                </ResponsiveContainer>
              ) : <EmptyChart />}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Projects by Type</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? <ChartSkeleton /> : (charts?.projectsByType?.length || 0) > 0 ? (
                <ResponsiveContainer width="100%" height={260}>
                  <PieChart>
                    <Pie data={charts?.projectsByType} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false}>
                      {charts?.projectsByType.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie>
                    <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                  </PieChart>
                </ResponsiveContainer>
              ) : <EmptyChart />}
            </CardContent>
          </Card>
        </div>

        {(charts?.healthDistribution?.length || 0) > 0 && (
          <Section title="Project Health & Market Scores">
            <Card>
              <CardContent className="pt-4">
                <ResponsiveContainer width="100%" height={Math.max(200, (charts?.healthDistribution?.length || 0) * 40)}>
                  <BarChart data={charts?.healthDistribution} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11 }} />
                    <YAxis type="category" dataKey="name" width={150} tick={{ fontSize: 11 }} />
                    <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                    <Bar dataKey="health" name="Health" fill="#10b981" radius={[0, 4, 4, 0]} />
                    <Bar dataKey="market" name="Market" fill="#3b82f6" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </Section>
        )}

        <Section title="Latest Activity">
          <Card>
            <CardContent className="pt-4">
              {milestones.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-6" data-testid="text-no-milestones">No recent activity</p>
              ) : (
                <div className="space-y-3">
                  {milestones.map((m) => (
                    <div key={m.id} className="flex gap-3 text-sm" data-testid={`milestone-${m.id}`}>
                      <div className="w-2 h-2 rounded-full bg-primary mt-1.5 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge variant="secondary" className="no-default-active-elevate text-xs">{m.action.replace(/_/g, " ")}</Badge>
                          <span className="text-xs text-muted-foreground">{m.projectName}</span>
                          <span className="text-xs text-muted-foreground">{new Date(m.createdAt).toLocaleString()}</span>
                        </div>
                        {m.details && <p className="text-muted-foreground mt-0.5">{m.details}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </Section>
      </div>
    </RoleLayout>
  );
}
