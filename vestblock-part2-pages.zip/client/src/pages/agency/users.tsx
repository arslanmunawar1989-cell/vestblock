import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { DataTable, type Column } from "@/components/data-table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { getTenantRoleColor } from "@/lib/rbac";
import { Search, UserPlus, Users, Mail, Shield, LogOut, ArrowLeft,
} from "lucide-react";
import { useState } from "react";
import { TENANT_ROLES, TENANT_ROLE_LABELS, PLATFORM_TENANT_ID } from "@shared/constants";
import { Link } from "wouter";
interface TenantMember {
  id: string;
  tenantId: string;
  userId: string;
  role: string;
  status: string;
  createdAt: string;
  user: {
    id: string;
    username: string;
    email: string;
    fullName: string;
    isActive: boolean;
    avatarUrl: string | null;
    role: string;
  } | null;
}

export default function AgencyUsers() {
  const [search, setSearch] = useState("");
  const [inviteOpen, setInviteOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteFullName, setInviteFullName] = useState("");
  const [inviteRole, setInviteRole] = useState("TENANT_USER");
  const [addEmail, setAddEmail] = useState("");
  const [addFullName, setAddFullName] = useState("");
  const [addPassword, setAddPassword] = useState("");
  const [addRole, setAddRole] = useState("TENANT_USER");
  const { toast } = useToast();
  const { user, can } = useAuth();

  const tenantId = user?.role === "admin" ? PLATFORM_TENANT_ID : (user as any)?.tenantId || PLATFORM_TENANT_ID;

  const { data: members = [], isLoading } = useQuery<TenantMember[]>({
    queryKey: ["/api/tenant-admin", tenantId, "users"],
    queryFn: async () => {
      const res = await fetch(`/api/tenant-admin/${tenantId}/users`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
  });

  const inviteMutation = useMutation({
    mutationFn: async (data: { email: string; fullName: string; role: string }) => {
      const res = await apiRequest("POST", `/api/tenant-admin/${tenantId}/invite`, data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant-admin", tenantId, "users"] });
      setInviteOpen(false);
      setInviteEmail("");
      setInviteFullName("");
      setInviteRole("TENANT_USER");
      toast({ title: data.invited ? "User invited" : "User added", description: data.message });
    },
    onError: (err: any) => {
      toast({ title: "Failed to invite user", description: err.message, variant: "destructive" });
    },
  });

  const addUserMutation = useMutation({
    mutationFn: async (data: { email: string; fullName: string; password: string; role: string }) => {
      const res = await apiRequest("POST", `/api/tenant-admin/${tenantId}/add-user`, data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant-admin", tenantId, "users"] });
      setAddOpen(false);
      setAddEmail("");
      setAddFullName("");
      setAddPassword("");
      setAddRole("TENANT_USER");
      toast({ title: "User added", description: data.message });
    },
    onError: (err: any) => {
      toast({ title: "Failed to add user", description: err.message, variant: "destructive" });
    },
  });

  const updateRoleMutation = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: string }) => {
      const res = await apiRequest("PATCH", `/api/tenant-admin/${tenantId}/users/${userId}/role`, { role });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant-admin", tenantId, "users"] });
      toast({ title: "Role updated" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to update role", description: err.message, variant: "destructive" });
    },
  });

  const toggleStatusMutation = useMutation({
    mutationFn: async ({ userId, status }: { userId: string; status: string }) => {
      const res = await apiRequest("PATCH", `/api/tenant-admin/${tenantId}/users/${userId}/status`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant-admin", tenantId, "users"] });
      toast({ title: "User status updated" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to update status", description: err.message, variant: "destructive" });
    },
  });

  const removeMutation = useMutation({
    mutationFn: async (userId: string) => {
      const res = await apiRequest("DELETE", `/api/tenant-admin/${tenantId}/users/${userId}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant-admin", tenantId, "users"] });
      toast({ title: "User removed from agency" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to remove user", description: err.message, variant: "destructive" });
    },
  });

  const forceLogoutMutation = useMutation({
    mutationFn: async (userId: string) => {
      const res = await apiRequest("POST", `/api/tenant-admin/${tenantId}/users/${userId}/force-logout`);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Force logout initiated" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to force logout", description: err.message, variant: "destructive" });
    },
  });

  const filtered = members.filter(m => {
    if (!search) return true;
    const s = search.toLowerCase();
    return (
      m.user?.fullName?.toLowerCase().includes(s) ||
      m.user?.email?.toLowerCase().includes(s) ||
      m.user?.username?.toLowerCase().includes(s)
    );
  });

  const activeCount = members.filter(m => m.status === "ACTIVE").length;
  const disabledCount = members.filter(m => m.status === "DISABLED").length;
  const invitedCount = members.filter(m => m.status === "INVITED").length;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "ACTIVE": return <Badge variant="default">Active</Badge>;
      case "DISABLED": return <Badge variant="destructive">Disabled</Badge>;
      case "INVITED": return <Badge variant="secondary">Invited</Badge>;
      case "SUSPENDED": return <Badge variant="destructive">Suspended</Badge>;
      default: return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const columns: Column<TenantMember>[] = [
    {
      header: "User",
      accessor: (row) => (
        <div>
          <span className="font-medium" data-testid={`text-member-name-${row.userId}`}>{row.user?.fullName || "Unknown"}</span>
          <p className="text-xs text-muted-foreground">{row.user?.email}</p>
        </div>
      ),
    },
    {
      header: "Role",
      accessor: (row) => (
        <Select
          value={row.role}
          onValueChange={(val) => updateRoleMutation.mutate({ userId: row.userId, role: val })}
          disabled={updateRoleMutation.isPending}
        >
          <SelectTrigger className="w-[140px]" data-testid={`select-role-${row.userId}`}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {TENANT_ROLES.map((r) => (
              <SelectItem key={r} value={r}>{TENANT_ROLE_LABELS[r]}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      ),
    },
    {
      header: "Status",
      accessor: (row) => getStatusBadge(row.status),
    },
    {
      header: "Enabled",
      accessor: (row) => (
        <Switch
          checked={row.status === "ACTIVE"}
          onCheckedChange={(checked) => {
            toggleStatusMutation.mutate({ userId: row.userId, status: checked ? "ACTIVE" : "DISABLED" });
          }}
          disabled={toggleStatusMutation.isPending}
          data-testid={`switch-user-status-${row.userId}`}
        />
      ),
    },
    {
      header: "Actions",
      accessor: (row) => (
        <div className="flex gap-1 flex-wrap">
          <Button
            size="sm"
            variant="outline"
            onClick={() => forceLogoutMutation.mutate(row.userId)}
            disabled={forceLogoutMutation.isPending}
            data-testid={`button-force-logout-${row.userId}`}
          >
            <LogOut className="w-3 h-3 mr-1" />
            Reset
          </Button>
          <Button
            size="sm"
            variant="destructive"
            onClick={() => {
              if (confirm(`Remove ${row.user?.fullName || "this user"} from the agency?`)) {
                removeMutation.mutate(row.userId);
              }
            }}
            disabled={removeMutation.isPending}
            data-testid={`button-remove-${row.userId}`}
          >
            Remove
          </Button>
        </div>
      ),
    },
  ];

  const roleSelector = (value: string, onChange: (v: string) => void) => (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger data-testid="select-invite-role">
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {TENANT_ROLES.map((r) => (
          <SelectItem key={r} value={r}>{TENANT_ROLE_LABELS[r]}</SelectItem>
        ))}
      </SelectContent>
    </Select>
  );

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/agency/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Team Members"
          description="Manage users within your agency"
          action={
            <div className="flex gap-2 flex-wrap">
              <Dialog open={inviteOpen} onOpenChange={setInviteOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" data-testid="button-invite-user">
                    <Mail className="w-4 h-4 mr-1" /> Invite
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Invite User by Email</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label>Email Address</Label>
                      <Input placeholder="user@example.com" value={inviteEmail} onChange={e => setInviteEmail(e.target.value)} data-testid="input-invite-email" />
                    </div>
                    <div className="space-y-2">
                      <Label>Full Name</Label>
                      <Input placeholder="John Doe" value={inviteFullName} onChange={e => setInviteFullName(e.target.value)} data-testid="input-invite-name" />
                    </div>
                    <div className="space-y-2">
                      <Label>Role</Label>
                      {roleSelector(inviteRole, setInviteRole)}
                    </div>
                    <Button
                      className="w-full"
                      onClick={() => inviteMutation.mutate({ email: inviteEmail, fullName: inviteFullName, role: inviteRole })}
                      disabled={inviteMutation.isPending || !inviteEmail.trim() || !inviteFullName.trim()}
                      data-testid="button-confirm-invite"
                    >
                      {inviteMutation.isPending ? "Inviting..." : "Send Invite"}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>

              <Dialog open={addOpen} onOpenChange={setAddOpen}>
                <DialogTrigger asChild>
                  <Button data-testid="button-add-user">
                    <UserPlus className="w-4 h-4 mr-1" /> Add User
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add User Manually</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label>Email Address</Label>
                      <Input placeholder="user@example.com" value={addEmail} onChange={e => setAddEmail(e.target.value)} data-testid="input-add-email" />
                    </div>
                    <div className="space-y-2">
                      <Label>Full Name</Label>
                      <Input placeholder="John Doe" value={addFullName} onChange={e => setAddFullName(e.target.value)} data-testid="input-add-name" />
                    </div>
                    <div className="space-y-2">
                      <Label>Password</Label>
                      <Input type="password" placeholder="Temporary password" value={addPassword} onChange={e => setAddPassword(e.target.value)} data-testid="input-add-password" />
                    </div>
                    <div className="space-y-2">
                      <Label>Role</Label>
                      {roleSelector(addRole, setAddRole)}
                    </div>
                    <Button
                      className="w-full"
                      onClick={() => addUserMutation.mutate({ email: addEmail, fullName: addFullName, password: addPassword, role: addRole })}
                      disabled={addUserMutation.isPending || !addEmail.trim() || !addFullName.trim() || !addPassword.trim()}
                      data-testid="button-confirm-add"
                    >
                      {addUserMutation.isPending ? "Adding..." : "Add User"}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          }
        />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Members</CardTitle>
              <Users className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-total-members">{members.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active</CardTitle>
              <Shield className="w-4 h-4 text-emerald-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-emerald-600" data-testid="text-active-members">{activeCount}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Disabled</CardTitle>
              <Shield className="w-4 h-4 text-red-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600" data-testid="text-disabled-members">{disabledCount}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending</CardTitle>
              <Mail className="w-4 h-4 text-amber-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-amber-600" data-testid="text-invited-members">{invitedCount}</div>
            </CardContent>
          </Card>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search members..." className="pl-9" value={search} onChange={e => setSearch(e.target.value)} data-testid="input-search-members" />
          </div>
        </div>

        <Section>
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => <Skeleton key={i} className="h-12 w-full" />)}
            </div>
          ) : (
            <DataTable columns={columns} data={filtered} emptyMessage="No team members yet" />
          )}
        </Section>
      </div>
    </RoleLayout>
  );
}
