import { Link } from "wouter";
import { ThemeToggle } from "@/components/theme-toggle";
import { GlassCard } from "@/components/glass-card";
import { GlassButton } from "@/components/glass-button";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";
import {
  TrendingUp,
  Shield,
  Zap,
  ArrowRight,
  BarChart3,
  Lock,
  Globe,
  LogIn,
  UserPlus,
} from "lucide-react";

export default function Home() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen relative">
      <div className="fixed inset-0 gradient-hero opacity-100" />
      <div className="fixed inset-0 bg-gradient-to-b from-transparent via-transparent to-black/20" />

      <div className="relative z-10">
        <header className="flex items-center justify-between gap-4 px-6 py-4 flex-wrap">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-md bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30">
              <span className="text-white font-bold text-lg">V</span>
            </div>
            <span className="text-white font-bold text-lg tracking-tight">VestBlock</span>
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            {user ? (
              <Link href={`/${user.role}`}>
                <Button variant="outline" className="bg-white/15 text-white border-white/25 backdrop-blur-md" data-testid="button-go-dashboard">
                  My Dashboard
                  <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            ) : (
              <>
                <Link href="/login">
                  <Button variant="outline" className="bg-white/15 text-white border-white/25 backdrop-blur-md" data-testid="button-login-nav">
                    <LogIn className="w-4 h-4 mr-1" />
                    Sign In
                  </Button>
                </Link>
                <Link href="/register">
                  <Button className="backdrop-blur-md" data-testid="button-register-nav">
                    <UserPlus className="w-4 h-4 mr-1" />
                    Get Started
                  </Button>
                </Link>
              </>
            )}
            <ThemeToggle />
          </div>
        </header>

        <main className="px-6 pb-16">
          <div className="max-w-5xl mx-auto pt-16 pb-12 text-center">
            <Badge className="mb-6 bg-white/20 text-white border-white/30 backdrop-blur-sm" data-testid="badge-hero">
              Tokenized Investment Platform
            </Badge>

            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white leading-tight tracking-tight mb-6" data-testid="heading-hero">
              Invest in the Future
              <br />
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-white via-emerald-100 to-cyan-100">
                with Confidence
              </span>
            </h1>

            <p className="text-lg text-white/80 max-w-2xl mx-auto mb-10 leading-relaxed" data-testid="text-hero-description">
              VestBlock brings institutional-grade investment infrastructure to everyone.
              Access tokenized assets, real-time portfolio tracking, and compliant distribution management.
            </p>

            <div className="flex items-center justify-center gap-3 flex-wrap mb-16">
              <Link href="/investor">
                <GlassButton variant="primary" size="lg" data-testid="button-investor-dashboard">
                  Investor Dashboard
                  <ArrowRight className="w-4 h-4" />
                </GlassButton>
              </Link>
              <Link href="/admin">
                <GlassButton size="lg" className="bg-white/15 text-white border-white/25 backdrop-blur-md" data-testid="button-admin-dashboard">
                  Admin Panel
                </GlassButton>
              </Link>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 max-w-4xl mx-auto mb-16">
              {[
                { icon: <TrendingUp className="w-5 h-5" />, label: "Total AUM", value: "$12.4M" },
                { icon: <Globe className="w-5 h-5" />, label: "Active Assets", value: "24" },
                { icon: <BarChart3 className="w-5 h-5" />, label: "Investors", value: "1,247" },
                { icon: <Lock className="w-5 h-5" />, label: "Compliance", value: "100%" },
              ].map((stat) => (
                <div
                  key={stat.label}
                  className="bg-white/10 backdrop-blur-md rounded-md p-4 border border-white/15 text-white"
                  data-testid={`stat-hero-${stat.label.toLowerCase().replace(/\s/g, '-')}`}
                >
                  <div className="flex items-center gap-2 mb-2 text-white/70">
                    {stat.icon}
                    <span className="text-xs font-medium">{stat.label}</span>
                  </div>
                  <span className="text-2xl font-bold">{stat.value}</span>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl mx-auto">
              {[
                {
                  icon: <Shield className="w-6 h-6" />,
                  title: "Compliant & Secure",
                  desc: "Full KYC/AML integration with role-based access control for every participant.",
                },
                {
                  icon: <Zap className="w-6 h-6" />,
                  title: "Real-Time Tracking",
                  desc: "Live portfolio valuation, distribution tracking, and transaction history at your fingertips.",
                },
                {
                  icon: <Globe className="w-6 h-6" />,
                  title: "Multi-Role Platform",
                  desc: "Dedicated dashboards for investors, issuers, agents, and administrators.",
                },
              ].map((feature) => (
                <div
                  key={feature.title}
                  className="bg-white/10 backdrop-blur-lg rounded-md p-6 border border-white/15 text-left"
                  data-testid={`feature-card-${feature.title.toLowerCase().replace(/\s/g, '-')}`}
                >
                  <div className="w-10 h-10 rounded-md bg-white/15 flex items-center justify-center text-white mb-4">
                    {feature.icon}
                  </div>
                  <h3 className="text-white font-semibold mb-2">{feature.title}</h3>
                  <p className="text-sm text-white/70 leading-relaxed">{feature.desc}</p>
                </div>
              ))}
            </div>

            <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-3 max-w-3xl mx-auto">
              {[
                { label: "Investor", path: "/investor", color: "bg-emerald-500/20 border-emerald-400/30" },
                { label: "Admin", path: "/admin", color: "bg-red-500/20 border-red-400/30" },
                { label: "Issuer", path: "/issuer", color: "bg-blue-500/20 border-blue-400/30" },
                { label: "Agent", path: "/agent", color: "bg-amber-500/20 border-amber-400/30" },
              ].map((r) => (
                <Link key={r.label} href={r.path}>
                  <div
                    className={`${r.color} backdrop-blur-md rounded-md p-4 border text-white text-center cursor-pointer transition-transform`}
                    data-testid={`link-role-${r.label.toLowerCase()}`}
                  >
                    <span className="text-sm font-semibold">{r.label} Dashboard</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
