import { useState } from "react";
import { useAuth } from "@/lib/auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Calendar, Clock, Plus, ArrowLeft, Video, Phone, MapPin } from "lucide-react";
import { Link } from "wouter";

interface AppointmentItem {
  id: string;
  datetime: string;
  mode: string;
  status: string;
  notes: string | null;
  agentName: string | null;
  createdAt: string;
}

const STATUS_COLORS: Record<string, string> = {
  REQUESTED: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  CONFIRMED: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  RESCHEDULED: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  CANCELLED: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
  COMPLETED: "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400",
};

const MODE_ICONS: Record<string, typeof Video> = {
  virtual: Video,
  phone: Phone,
  in_person: MapPin,
};

export default function ClientAppointments() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [showForm, setShowForm] = useState(false);
  const [datetime, setDatetime] = useState("");
  const [mode, setMode] = useState("virtual");
  const [notes, setNotes] = useState("");

  const { data, isLoading } = useQuery<{ appointments: AppointmentItem[] }>({
    queryKey: ["/api/appointments/my"],
  });

  const createMutation = useMutation({
    mutationFn: async (body: { datetime: string; mode: string; notes?: string }) => {
      const res = await apiRequest("POST", "/api/appointments/create", body);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments/my"] });
      setShowForm(false);
      setDatetime("");
      setMode("virtual");
      setNotes("");
      toast({ title: "Appointment requested", description: "Your appointment has been submitted." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create appointment.", variant: "destructive" });
    },
  });

  const cancelMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("POST", "/api/appointments/update", { id, status: "CANCELLED" });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments/my"] });
      toast({ title: "Appointment cancelled" });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!datetime) return;
    createMutation.mutate({ datetime: new Date(datetime).toISOString(), mode, notes: notes || undefined });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto p-6">
        <div className="flex items-center gap-3 mb-6">
          <Link href={`/${user?.role || "investor"}`}>
            <Button variant="ghost" size="icon" data-testid="button-back">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className="text-2xl font-bold" data-testid="heading-appointments">My Appointments</h1>
            <p className="text-sm text-muted-foreground">Schedule and manage your appointments</p>
          </div>
          <Button onClick={() => setShowForm(!showForm)} data-testid="button-new-appointment">
            <Plus className="w-4 h-4 mr-2" />
            New Appointment
          </Button>
        </div>

        {showForm && (
          <Card className="p-6 mb-6" data-testid="card-new-appointment-form">
            <h2 className="text-lg font-semibold mb-4">Request Appointment</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="datetime">Date & Time</Label>
                  <Input
                    id="datetime"
                    type="datetime-local"
                    value={datetime}
                    onChange={(e) => setDatetime(e.target.value)}
                    required
                    data-testid="input-datetime"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="mode">Mode</Label>
                  <Select value={mode} onValueChange={setMode}>
                    <SelectTrigger data-testid="select-mode">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="virtual">Virtual</SelectItem>
                      <SelectItem value="phone">Phone</SelectItem>
                      <SelectItem value="in_person">In Person</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="notes">Notes (optional)</Label>
                <Textarea
                  id="notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="What would you like to discuss?"
                  data-testid="input-notes"
                />
              </div>
              <div className="flex gap-2">
                <Button type="submit" disabled={createMutation.isPending} data-testid="button-submit-appointment">
                  {createMutation.isPending ? "Submitting..." : "Request Appointment"}
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)} data-testid="button-cancel-form">
                  Cancel
                </Button>
              </div>
            </form>
          </Card>
        )}

        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="w-8 h-8 border-3 border-primary/30 border-t-primary rounded-full animate-spin" />
          </div>
        ) : !data?.appointments?.length ? (
          <Card className="p-12 text-center" data-testid="card-empty-state">
            <Calendar className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
            <h3 className="text-lg font-semibold mb-2">No appointments yet</h3>
            <p className="text-sm text-muted-foreground mb-4">Request your first appointment to get started.</p>
            <Button onClick={() => setShowForm(true)} data-testid="button-first-appointment">
              <Plus className="w-4 h-4 mr-2" /> Request Appointment
            </Button>
          </Card>
        ) : (
          <div className="space-y-3" data-testid="list-appointments">
            {data.appointments.map((appt) => {
              const ModeIcon = MODE_ICONS[appt.mode] || Video;
              return (
                <Card key={appt.id} className="p-4" data-testid={`card-appointment-${appt.id}`}>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                        <ModeIcon className="w-5 h-5 text-primary" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${STATUS_COLORS[appt.status] || STATUS_COLORS.REQUESTED}`} data-testid={`status-${appt.id}`}>
                            {appt.status}
                          </span>
                          <span className="text-xs text-muted-foreground capitalize">{appt.mode.replace("_", " ")}</span>
                        </div>
                        <div className="flex items-center gap-1 text-sm">
                          <Clock className="w-3.5 h-3.5 text-muted-foreground" />
                          <span>{new Date(appt.datetime).toLocaleString()}</span>
                        </div>
                        {appt.agentName && (
                          <p className="text-xs text-muted-foreground mt-1">Agent: {appt.agentName}</p>
                        )}
                        {appt.notes && (
                          <p className="text-xs text-muted-foreground mt-1 truncate max-w-md">{appt.notes}</p>
                        )}
                      </div>
                    </div>
                    {(appt.status === "REQUESTED" || appt.status === "CONFIRMED" || appt.status === "RESCHEDULED") && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => cancelMutation.mutate(appt.id)}
                        disabled={cancelMutation.isPending}
                        data-testid={`button-cancel-${appt.id}`}
                      >
                        Cancel
                      </Button>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
