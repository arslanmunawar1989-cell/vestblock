import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Mail, Clock, CheckCircle, XCircle, AlertCircle } from "lucide-react";
import { Link } from "wouter";

interface EmailLogItem {
  id: string;
  toAddress: string;
  subject: string;
  body: string;
  status: string;
  relatedEntityType: string | null;
  relatedEntityId: string | null;
  createdAt: string;
}

const STATUS_ICONS: Record<string, typeof Mail> = {
  queued: Clock,
  sent: CheckCircle,
  failed: XCircle,
  bounced: AlertCircle,
};

const STATUS_COLORS: Record<string, string> = {
  queued: "text-yellow-600",
  sent: "text-green-600",
  failed: "text-red-600",
  bounced: "text-orange-600",
};

export default function AdminEmailOutbox() {
  const [statusFilter, setStatusFilter] = useState("all");
  const [page, setPage] = useState(0);
  const limit = 20;

  const queryParams = new URLSearchParams({ limit: String(limit), offset: String(page * limit) });
  if (statusFilter !== "all") queryParams.set("status", statusFilter);

  const { data, isLoading } = useQuery<{ logs: EmailLogItem[]; total: number }>({
    queryKey: [`/api/admin/email-outbox?${queryParams.toString()}`],
  });

  const totalPages = Math.ceil((data?.total || 0) / limit);

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto p-6">
        <div className="flex items-center gap-3 mb-6">
          <Link href="/admin">
            <Button variant="ghost" size="icon" data-testid="button-back">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className="text-2xl font-bold" data-testid="heading-email-outbox">Email Outbox</h1>
            <p className="text-sm text-muted-foreground">
              {data?.total || 0} total emails logged
            </p>
          </div>
          <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPage(0); }}>
            <SelectTrigger className="w-36" data-testid="select-status-filter">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="queued">Queued</SelectItem>
              <SelectItem value="sent">Sent</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
              <SelectItem value="bounced">Bounced</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="w-8 h-8 border-3 border-primary/30 border-t-primary rounded-full animate-spin" />
          </div>
        ) : !data?.logs?.length ? (
          <Card className="p-12 text-center" data-testid="card-empty-state">
            <Mail className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
            <h3 className="text-lg font-semibold mb-2">No emails logged</h3>
            <p className="text-sm text-muted-foreground">Emails will appear here as they are triggered.</p>
          </Card>
        ) : (
          <>
            <div className="space-y-2" data-testid="list-email-logs">
              {data.logs.map((log) => {
                const StatusIcon = STATUS_ICONS[log.status] || Mail;
                const statusColor = STATUS_COLORS[log.status] || "text-gray-600";
                return (
                  <Card key={log.id} className="p-4" data-testid={`card-email-${log.id}`}>
                    <div className="flex items-start gap-3">
                      <StatusIcon className={`w-5 h-5 mt-0.5 shrink-0 ${statusColor}`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm truncate">{log.subject}</span>
                          <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                            log.status === "sent" ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400" :
                            log.status === "failed" ? "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400" :
                            log.status === "bounced" ? "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400" :
                            "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400"
                          }`} data-testid={`status-${log.id}`}>
                            {log.status}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground">To: {log.toAddress}</p>
                        <div className="flex items-center gap-3 mt-1">
                          <span className="text-xs text-muted-foreground">{new Date(log.createdAt).toLocaleString()}</span>
                          {log.relatedEntityType && (
                            <span className="text-xs text-muted-foreground">
                              {log.relatedEntityType} {log.relatedEntityId ? `#${log.relatedEntityId.slice(0, 8)}` : ""}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>

            {totalPages > 1 && (
              <div className="flex justify-center gap-2 mt-6" data-testid="pagination">
                <Button variant="outline" size="sm" disabled={page === 0} onClick={() => setPage(p => p - 1)} data-testid="button-prev">
                  Previous
                </Button>
                <span className="text-sm text-muted-foreground self-center">
                  Page {page + 1} of {totalPages}
                </span>
                <Button variant="outline" size="sm" disabled={page >= totalPages - 1} onClick={() => setPage(p => p + 1)} data-testid="button-next">
                  Next
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
