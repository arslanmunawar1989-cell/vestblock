import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Play, CheckCircle2, XCircle, Users, Shield, Mail, Activity, FlaskConical } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface StepResult {
  name: string;
  pass: boolean;
  detail: string;
}

interface ScenarioResult {
  scenario: string;
  steps: StepResult[];
  pass: boolean;
  timestamp: string;
}

interface TestUser {
  id: string;
  username: string;
  email: string;
  fullName: string;
  role: string;
  platformRole: string | null;
}

const SCENARIOS = [
  { key: "client-journey", label: "Client Journey (E2E)", description: "Appointment creation, transaction with OTP, email logging", icon: Users },
  { key: "agent-journey", label: "Agent Journey", description: "Appointment assignment and confirmation, RBAC check", icon: Activity },
  { key: "manager-journey", label: "Manager Journey", description: "Appointment assignment, subscriber/campaign access", icon: Shield },
  { key: "security-tests", label: "Security & RBAC", description: "Client denied admin endpoints, OTP rate limiting", icon: Shield },
  { key: "email-routing", label: "Email Routing", description: "Email log distribution, entity linking", icon: Mail },
] as const;

export default function TestConsole() {
  const [results, setResults] = useState<Record<string, ScenarioResult>>({});
  const [runningScenario, setRunningScenario] = useState<string | null>(null);

  const usersQuery = useQuery<{ users: TestUser[] }>({
    queryKey: ["/api/admin/test-console/users"],
  });

  const runScenario = useMutation({
    mutationFn: async (scenarioKey: string) => {
      setRunningScenario(scenarioKey);
      const res = await apiRequest("POST", `/api/admin/test-console/run/${scenarioKey}`);
      return res.json() as Promise<ScenarioResult>;
    },
    onSuccess: (data, scenarioKey) => {
      setResults(prev => ({ ...prev, [scenarioKey]: data }));
      setRunningScenario(null);
    },
    onError: (_err, scenarioKey) => {
      setResults(prev => ({
        ...prev,
        [scenarioKey]: {
          scenario: scenarioKey,
          steps: [{ name: "Request failed", pass: false, detail: "Network or server error" }],
          pass: false,
          timestamp: new Date().toISOString(),
        },
      }));
      setRunningScenario(null);
    },
  });

  const runAll = async () => {
    for (const s of SCENARIOS) {
      await runScenario.mutateAsync(s.key).catch(() => {});
    }
  };

  const totalSteps = Object.values(results).flatMap(r => r.steps);
  const passed = totalSteps.filter(s => s.pass).length;
  const failed = totalSteps.filter(s => !s.pass).length;
  const bugBashUsers = usersQuery.data?.users || [];

  return (
    <div className="min-h-screen bg-[#050B1A] text-white p-6 md:p-10">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <FlaskConical className="w-8 h-8 text-[#1E2BFF]" />
              <h1 className="text-3xl font-bold tracking-tight" data-testid="text-page-title">Test Console</h1>
            </div>
            <p className="text-sm text-gray-400">Admin-only bug bash and scenario runner</p>
          </div>
          <div className="flex items-center gap-3">
            {totalSteps.length > 0 && (
              <div className="flex items-center gap-2 text-sm">
                <Badge variant="outline" className="bg-green-500/10 text-green-400 border-green-500/30" data-testid="badge-passed">
                  {passed} passed
                </Badge>
                {failed > 0 && (
                  <Badge variant="outline" className="bg-red-500/10 text-red-400 border-red-500/30" data-testid="badge-failed">
                    {failed} failed
                  </Badge>
                )}
              </div>
            )}
            <Button
              onClick={runAll}
              disabled={!!runningScenario}
              className="bg-[#1E2BFF] hover:bg-[#1825e0] text-white"
              data-testid="button-run-all"
            >
              {runningScenario ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Play className="w-4 h-4 mr-2" />}
              Run All Scenarios
            </Button>
          </div>
        </div>

        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="text-lg text-white">Bug Bash Test Users</CardTitle>
            <CardDescription className="text-gray-400">
              {bugBashUsers.length} users seeded with @vestblock.test emails (password: password123)
            </CardDescription>
          </CardHeader>
          <CardContent>
            {usersQuery.isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin text-gray-400" />
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                {bugBashUsers.map(u => (
                  <div key={u.id} className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/5 text-sm" data-testid={`user-card-${u.username}`}>
                    <Badge variant="outline" className="text-xs border-[#1E2BFF]/50 text-[#93a0ff]">
                      {u.role}
                    </Badge>
                    <span className="text-gray-300 truncate">{u.username}</span>
                    {u.platformRole && (
                      <Badge variant="outline" className="text-xs border-yellow-500/50 text-yellow-400 ml-auto">
                        {u.platformRole}
                      </Badge>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-white">Scenario Runners</h2>
          {SCENARIOS.map(s => {
            const result = results[s.key];
            const isRunning = runningScenario === s.key;
            const Icon = s.icon;

            return (
              <Card key={s.key} className="bg-white/5 border-white/10" data-testid={`scenario-card-${s.key}`}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Icon className="w-5 h-5 text-[#1E2BFF]" />
                      <div>
                        <CardTitle className="text-base text-white">{s.label}</CardTitle>
                        <CardDescription className="text-gray-400 text-xs">{s.description}</CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {result && (
                        <Badge
                          variant="outline"
                          className={result.pass
                            ? "bg-green-500/10 text-green-400 border-green-500/30"
                            : "bg-red-500/10 text-red-400 border-red-500/30"}
                          data-testid={`badge-result-${s.key}`}
                        >
                          {result.pass ? "PASS" : "FAIL"}
                        </Badge>
                      )}
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => runScenario.mutate(s.key)}
                        disabled={isRunning}
                        className="border-white/20 text-gray-300 hover:text-white hover:bg-white/10"
                        data-testid={`button-run-${s.key}`}
                      >
                        {isRunning ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                {result && (
                  <CardContent className="pt-0">
                    <div className="space-y-1">
                      {result.steps.map((step, i) => (
                        <div
                          key={i}
                          className={`flex items-start gap-2 px-3 py-2 rounded text-sm ${
                            step.pass ? "bg-green-500/5" : "bg-red-500/5"
                          }`}
                          data-testid={`step-${s.key}-${i}`}
                        >
                          {step.pass ? (
                            <CheckCircle2 className="w-4 h-4 text-green-400 mt-0.5 shrink-0" />
                          ) : (
                            <XCircle className="w-4 h-4 text-red-400 mt-0.5 shrink-0" />
                          )}
                          <div>
                            <span className="text-gray-300 font-medium">{step.name}</span>
                            <span className="text-gray-500 ml-2">{step.detail}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      Ran at {new Date(result.timestamp).toLocaleString()}
                    </p>
                  </CardContent>
                )}
              </Card>
            );
          })}
        </div>

        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="text-lg text-white">Health Endpoints</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-3">
              <HealthCheck url="/api/health" label="System Health" />
              <HealthCheck url="/api/health/pwa" label="PWA Assets" />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function HealthCheck({ url, label }: { url: string; label: string }) {
  const query = useQuery({
    queryKey: [url],
    refetchInterval: 30000,
  });

  const data = query.data as any;
  const status = data?.status || "loading";
  const isOk = status === "healthy" || status === "ok" || status === "ready";

  return (
    <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/5 text-sm" data-testid={`health-${label.toLowerCase().replace(/\s/g, "-")}`}>
      {query.isLoading ? (
        <Loader2 className="w-4 h-4 animate-spin text-gray-400" />
      ) : isOk ? (
        <CheckCircle2 className="w-4 h-4 text-green-400" />
      ) : (
        <XCircle className="w-4 h-4 text-red-400" />
      )}
      <span className="text-gray-300">{label}</span>
      <Badge variant="outline" className={`text-xs ${isOk ? "text-green-400 border-green-500/30" : "text-red-400 border-red-500/30"}`}>
        {status}
      </Badge>
    </div>
  );
}
