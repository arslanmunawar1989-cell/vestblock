import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Users, Download, Send, Mail, Plus } from "lucide-react";
import { Link } from "wouter";

interface SubscriberItem {
  id: string;
  email: string;
  region: string | null;
  source: string | null;
  createdAt: string;
}

interface CampaignItem {
  id: string;
  subject: string;
  body: string;
  segment: string | null;
  recipientCount: number | null;
  status: string;
  createdAt: string;
}

export default function ManagerMarketing() {
  const { toast } = useToast();
  const [showCampaignForm, setShowCampaignForm] = useState(false);
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [segment, setSegment] = useState("");
  const [tab, setTab] = useState<"subscribers" | "campaigns">("subscribers");

  const { data: subsData, isLoading: subsLoading } = useQuery<{ subscribers: SubscriberItem[]; total: number }>({
    queryKey: ["/api/admin/marketing/subscribers"],
  });

  const { data: campaignsData, isLoading: campaignsLoading } = useQuery<{ campaigns: CampaignItem[] }>({
    queryKey: ["/api/admin/marketing/campaigns"],
  });

  const sendMutation = useMutation({
    mutationFn: async (data: { subject: string; body: string; segment?: string }) => {
      const res = await apiRequest("POST", "/api/admin/marketing/campaigns/send", data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/marketing/campaigns"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/email-outbox"] });
      setShowCampaignForm(false);
      setSubject("");
      setBody("");
      setSegment("");
      toast({ title: "Campaign sent", description: `Sent to ${data.sent} subscribers.` });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to send campaign.", variant: "destructive" });
    },
  });

  const handleExport = () => {
    window.open("/api/admin/marketing/subscribers/export", "_blank");
  };

  const handleSendCampaign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject || !body) return;
    sendMutation.mutate({ subject, body, segment: segment || undefined });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto p-6">
        <div className="flex items-center gap-3 mb-6">
          <Link href="/admin">
            <Button variant="ghost" size="icon" data-testid="button-back">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className="text-2xl font-bold" data-testid="heading-marketing">Email Marketing</h1>
            <p className="text-sm text-muted-foreground">Manage subscribers and campaigns</p>
          </div>
        </div>

        <div className="flex gap-2 mb-6" data-testid="tab-buttons">
          <Button variant={tab === "subscribers" ? "default" : "outline"} size="sm" onClick={() => setTab("subscribers")} data-testid="tab-subscribers">
            <Users className="w-4 h-4 mr-1" /> Subscribers ({subsData?.total || 0})
          </Button>
          <Button variant={tab === "campaigns" ? "default" : "outline"} size="sm" onClick={() => setTab("campaigns")} data-testid="tab-campaigns">
            <Mail className="w-4 h-4 mr-1" /> Campaigns ({campaignsData?.campaigns?.length || 0})
          </Button>
        </div>

        {tab === "subscribers" && (
          <>
            <div className="flex justify-end mb-4">
              <Button variant="outline" size="sm" onClick={handleExport} data-testid="button-export-csv">
                <Download className="w-4 h-4 mr-1" /> Export CSV
              </Button>
            </div>

            {subsLoading ? (
              <div className="flex justify-center py-12">
                <div className="w-8 h-8 border-3 border-primary/30 border-t-primary rounded-full animate-spin" />
              </div>
            ) : !subsData?.subscribers?.length ? (
              <Card className="p-12 text-center" data-testid="card-no-subscribers">
                <Users className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
                <h3 className="text-lg font-semibold mb-2">No subscribers yet</h3>
                <p className="text-sm text-muted-foreground">Subscribers will appear here when users sign up.</p>
              </Card>
            ) : (
              <div className="border rounded-lg overflow-hidden" data-testid="table-subscribers">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-muted/50">
                      <th className="text-left p-3 font-medium">Email</th>
                      <th className="text-left p-3 font-medium">Region</th>
                      <th className="text-left p-3 font-medium">Source</th>
                      <th className="text-left p-3 font-medium">Subscribed</th>
                    </tr>
                  </thead>
                  <tbody>
                    {subsData.subscribers.map(sub => (
                      <tr key={sub.id} className="border-t" data-testid={`row-subscriber-${sub.id}`}>
                        <td className="p-3">{sub.email}</td>
                        <td className="p-3 text-muted-foreground">{sub.region || "—"}</td>
                        <td className="p-3 text-muted-foreground">{sub.source || "—"}</td>
                        <td className="p-3 text-muted-foreground">{new Date(sub.createdAt).toLocaleDateString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}

        {tab === "campaigns" && (
          <>
            <div className="flex justify-end mb-4">
              <Button size="sm" onClick={() => setShowCampaignForm(!showCampaignForm)} data-testid="button-new-campaign">
                <Plus className="w-4 h-4 mr-1" /> New Campaign
              </Button>
            </div>

            {showCampaignForm && (
              <Card className="p-6 mb-6" data-testid="card-campaign-form">
                <h2 className="text-lg font-semibold mb-4">Send Campaign</h2>
                <form onSubmit={handleSendCampaign} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject</Label>
                    <Input id="subject" value={subject} onChange={e => setSubject(e.target.value)} placeholder="Campaign subject line" required data-testid="input-campaign-subject" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="body">Body (HTML)</Label>
                    <Textarea id="body" value={body} onChange={e => setBody(e.target.value)} placeholder="Email content (HTML supported)" rows={6} required data-testid="input-campaign-body" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="segment">Region Segment (optional)</Label>
                    <Input id="segment" value={segment} onChange={e => setSegment(e.target.value)} placeholder="e.g., PK, AE, GB, US, QA (leave blank for all)" data-testid="input-campaign-segment" />
                  </div>
                  <div className="flex gap-2">
                    <Button type="submit" disabled={sendMutation.isPending} data-testid="button-send-campaign">
                      <Send className="w-4 h-4 mr-1" /> {sendMutation.isPending ? "Sending..." : "Send Campaign"}
                    </Button>
                    <Button type="button" variant="outline" onClick={() => setShowCampaignForm(false)} data-testid="button-cancel-campaign">
                      Cancel
                    </Button>
                  </div>
                </form>
              </Card>
            )}

            {campaignsLoading ? (
              <div className="flex justify-center py-12">
                <div className="w-8 h-8 border-3 border-primary/30 border-t-primary rounded-full animate-spin" />
              </div>
            ) : !campaignsData?.campaigns?.length ? (
              <Card className="p-12 text-center" data-testid="card-no-campaigns">
                <Send className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
                <h3 className="text-lg font-semibold mb-2">No campaigns sent</h3>
                <p className="text-sm text-muted-foreground">Create and send your first campaign.</p>
              </Card>
            ) : (
              <div className="space-y-3" data-testid="list-campaigns">
                {campaignsData.campaigns.map(c => (
                  <Card key={c.id} className="p-4" data-testid={`card-campaign-${c.id}`}>
                    <div className="flex items-start justify-between gap-4">
                      <div className="min-w-0">
                        <p className="font-medium text-sm">{c.subject}</p>
                        <div className="flex items-center gap-3 mt-1">
                          <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                            c.status === "sent" ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400" :
                            c.status === "sending" ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400" :
                            "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400"
                          }`}>
                            {c.status}
                          </span>
                          {c.recipientCount !== null && <span className="text-xs text-muted-foreground">{c.recipientCount} recipients</span>}
                          {c.segment && <span className="text-xs text-muted-foreground">Segment: {c.segment}</span>}
                          <span className="text-xs text-muted-foreground">{new Date(c.createdAt).toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
