import { useState } from "react";
import { useAuth } from "@/lib/auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Calendar, Clock, ArrowLeft, Video, Phone, MapPin, UserPlus } from "lucide-react";
import { Link } from "wouter";

interface AppointmentItem {
  id: string;
  datetime: string;
  mode: string;
  status: string;
  notes: string | null;
  clientName: string;
  clientEmail: string;
  agentName: string | null;
  agentEmail: string | null;
  assignedToUserId: string | null;
  createdAt: string;
}

interface AgentOption {
  id: string;
  fullName: string;
  email: string;
}

const STATUS_COLORS: Record<string, string> = {
  REQUESTED: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  CONFIRMED: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  RESCHEDULED: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  CANCELLED: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
  COMPLETED: "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400",
};

const MODE_ICONS: Record<string, typeof Video> = {
  virtual: Video,
  phone: Phone,
  in_person: MapPin,
};

export default function ManagerAppointments() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [assigningId, setAssigningId] = useState<string | null>(null);
  const [selectedAgent, setSelectedAgent] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const { data, isLoading } = useQuery<{ appointments: AppointmentItem[] }>({
    queryKey: ["/api/appointments/all"],
  });

  const { data: agentsData } = useQuery<{ agents: AgentOption[] }>({
    queryKey: ["/api/appointments/agents"],
  });

  const assignMutation = useMutation({
    mutationFn: async (body: { id: string; assignedToUserId: string }) => {
      const res = await apiRequest("POST", "/api/appointments/assign", body);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments/all"] });
      setAssigningId(null);
      setSelectedAgent("");
      toast({ title: "Agent assigned", description: "The appointment has been assigned to the agent." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to assign agent.", variant: "destructive" });
    },
  });

  const filtered = data?.appointments?.filter(a => statusFilter === "all" || a.status === statusFilter) || [];
  const unassigned = filtered.filter(a => !a.assignedToUserId && a.status === "REQUESTED");
  const assigned = filtered.filter(a => a.assignedToUserId || a.status !== "REQUESTED");

  const counts: Record<string, number> = {};
  data?.appointments?.forEach(a => { counts[a.status] = (counts[a.status] || 0) + 1; });

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto p-6">
        <div className="flex items-center gap-3 mb-6">
          <Link href="/admin">
            <Button variant="ghost" size="icon" data-testid="button-back">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className="text-2xl font-bold" data-testid="heading-manager-appointments">Appointment Management</h1>
            <p className="text-sm text-muted-foreground">Assign and manage all appointments</p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 mb-6" data-testid="status-filters">
          {["all", "REQUESTED", "CONFIRMED", "RESCHEDULED", "CANCELLED", "COMPLETED"].map(s => (
            <Button
              key={s}
              variant={statusFilter === s ? "default" : "outline"}
              size="sm"
              onClick={() => setStatusFilter(s)}
              data-testid={`filter-${s}`}
            >
              {s === "all" ? "All" : s} {s !== "all" && counts[s] ? `(${counts[s]})` : ""}
            </Button>
          ))}
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="w-8 h-8 border-3 border-primary/30 border-t-primary rounded-full animate-spin" />
          </div>
        ) : !filtered.length ? (
          <Card className="p-12 text-center" data-testid="card-empty-state">
            <Calendar className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
            <h3 className="text-lg font-semibold mb-2">No appointments found</h3>
            <p className="text-sm text-muted-foreground">No appointments match the current filter.</p>
          </Card>
        ) : (
          <div className="space-y-6">
            {unassigned.length > 0 && (
              <div>
                <h2 className="text-sm font-semibold text-yellow-700 dark:text-yellow-400 uppercase tracking-wider mb-3" data-testid="heading-unassigned">
                  Needs Assignment ({unassigned.length})
                </h2>
                <div className="space-y-3">
                  {unassigned.map((appt) => {
                    const ModeIcon = MODE_ICONS[appt.mode] || Video;
                    return (
                      <Card key={appt.id} className="p-4 border-yellow-200 dark:border-yellow-800" data-testid={`card-appointment-${appt.id}`}>
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex items-start gap-3 min-w-0">
                            <div className="w-10 h-10 rounded-lg bg-yellow-100 dark:bg-yellow-900/30 flex items-center justify-center shrink-0">
                              <ModeIcon className="w-5 h-5 text-yellow-700 dark:text-yellow-400" />
                            </div>
                            <div className="min-w-0">
                              <p className="font-medium text-sm">{appt.clientName}</p>
                              <p className="text-xs text-muted-foreground">{appt.clientEmail}</p>
                              <div className="flex items-center gap-1 text-sm mt-1">
                                <Clock className="w-3.5 h-3.5 text-muted-foreground" />
                                <span>{new Date(appt.datetime).toLocaleString()}</span>
                              </div>
                              <span className="text-xs text-muted-foreground capitalize">{appt.mode.replace("_", " ")}</span>
                              {appt.notes && <p className="text-xs text-muted-foreground mt-1">{appt.notes}</p>}
                            </div>
                          </div>
                          <div className="shrink-0">
                            {assigningId === appt.id ? (
                              <div className="flex flex-col gap-2">
                                <Select value={selectedAgent} onValueChange={setSelectedAgent}>
                                  <SelectTrigger className="w-48" data-testid={`select-agent-${appt.id}`}>
                                    <SelectValue placeholder="Select agent" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {agentsData?.agents?.map(ag => (
                                      <SelectItem key={ag.id} value={ag.id}>{ag.fullName}</SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                <div className="flex gap-1">
                                  <Button size="sm" disabled={!selectedAgent || assignMutation.isPending} onClick={() => assignMutation.mutate({ id: appt.id, assignedToUserId: selectedAgent })} data-testid={`button-confirm-assign-${appt.id}`}>
                                    Assign
                                  </Button>
                                  <Button size="sm" variant="outline" onClick={() => { setAssigningId(null); setSelectedAgent(""); }} data-testid={`button-cancel-assign-${appt.id}`}>
                                    Cancel
                                  </Button>
                                </div>
                              </div>
                            ) : (
                              <Button size="sm" onClick={() => setAssigningId(appt.id)} data-testid={`button-assign-${appt.id}`}>
                                <UserPlus className="w-3.5 h-3.5 mr-1" /> Assign Agent
                              </Button>
                            )}
                          </div>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              </div>
            )}

            {assigned.length > 0 && (
              <div>
                <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3" data-testid="heading-assigned">
                  All Appointments ({assigned.length})
                </h2>
                <div className="space-y-3">
                  {assigned.map((appt) => {
                    const ModeIcon = MODE_ICONS[appt.mode] || Video;
                    return (
                      <Card key={appt.id} className="p-4" data-testid={`card-appointment-${appt.id}`}>
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex items-start gap-3 min-w-0">
                            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                              <ModeIcon className="w-5 h-5 text-primary" />
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${STATUS_COLORS[appt.status] || STATUS_COLORS.REQUESTED}`}>
                                  {appt.status}
                                </span>
                              </div>
                              <p className="font-medium text-sm">{appt.clientName}</p>
                              <p className="text-xs text-muted-foreground">{appt.clientEmail}</p>
                              <div className="flex items-center gap-1 text-sm mt-1">
                                <Clock className="w-3.5 h-3.5 text-muted-foreground" />
                                <span>{new Date(appt.datetime).toLocaleString()}</span>
                              </div>
                              {appt.agentName && (
                                <p className="text-xs mt-1">
                                  <span className="text-muted-foreground">Agent:</span>{" "}
                                  <span className="font-medium">{appt.agentName}</span>
                                </p>
                              )}
                              {appt.notes && <p className="text-xs text-muted-foreground mt-1 truncate max-w-md">{appt.notes}</p>}
                            </div>
                          </div>
                          {!appt.assignedToUserId && appt.status === "REQUESTED" && (
                            <Button size="sm" variant="outline" onClick={() => setAssigningId(appt.id)} data-testid={`button-assign-${appt.id}`}>
                              <UserPlus className="w-3.5 h-3.5 mr-1" /> Assign
                            </Button>
                          )}
                        </div>
                      </Card>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
