import { useAuth } from "@/lib/auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Calendar, Clock, ArrowLeft, Video, Phone, MapPin, Check, RefreshCw, X } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";

interface AppointmentItem {
  id: string;
  datetime: string;
  mode: string;
  status: string;
  notes: string | null;
  clientName: string;
  clientEmail: string;
  createdAt: string;
}

const STATUS_COLORS: Record<string, string> = {
  REQUESTED: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  CONFIRMED: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
  RESCHEDULED: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  CANCELLED: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
  COMPLETED: "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400",
};

const MODE_ICONS: Record<string, typeof Video> = {
  virtual: Video,
  phone: Phone,
  in_person: MapPin,
};

export default function AgentAppointments() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [rescheduleId, setRescheduleId] = useState<string | null>(null);
  const [newDatetime, setNewDatetime] = useState("");

  const { data, isLoading } = useQuery<{ appointments: AppointmentItem[] }>({
    queryKey: ["/api/appointments/my"],
  });

  const respondMutation = useMutation({
    mutationFn: async (body: { id: string; action: string; datetime?: string; notes?: string }) => {
      const res = await apiRequest("POST", "/api/appointments/respond", body);
      return res.json();
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments/my"] });
      setRescheduleId(null);
      setNewDatetime("");
      const actions: Record<string, string> = { accept: "accepted", reschedule: "rescheduled", cancel: "cancelled" };
      toast({ title: `Appointment ${actions[variables.action] || "updated"}` });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update appointment.", variant: "destructive" });
    },
  });

  const completeMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("POST", "/api/appointments/complete", { id });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/appointments/my"] });
      toast({ title: "Appointment marked as completed" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to complete appointment.", variant: "destructive" });
    },
  });

  const pending = data?.appointments?.filter(a => a.status === "REQUESTED") || [];
  const active = data?.appointments?.filter(a => ["CONFIRMED", "RESCHEDULED"].includes(a.status)) || [];
  const past = data?.appointments?.filter(a => ["COMPLETED", "CANCELLED"].includes(a.status)) || [];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto p-6">
        <div className="flex items-center gap-3 mb-6">
          <Link href={`/${user?.role || "agent"}`}>
            <Button variant="ghost" size="icon" data-testid="button-back">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold" data-testid="heading-agent-appointments">My Assigned Appointments</h1>
            <p className="text-sm text-muted-foreground">Manage appointments assigned to you</p>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="w-8 h-8 border-3 border-primary/30 border-t-primary rounded-full animate-spin" />
          </div>
        ) : !data?.appointments?.length ? (
          <Card className="p-12 text-center" data-testid="card-empty-state">
            <Calendar className="w-12 h-12 mx-auto mb-4 text-muted-foreground/50" />
            <h3 className="text-lg font-semibold mb-2">No assigned appointments</h3>
            <p className="text-sm text-muted-foreground">You don't have any appointments assigned to you yet.</p>
          </Card>
        ) : (
          <div className="space-y-6">
            {pending.length > 0 && (
              <div>
                <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3" data-testid="heading-pending">
                  Pending Response ({pending.length})
                </h2>
                <div className="space-y-3">
                  {pending.map((appt) => {
                    const ModeIcon = MODE_ICONS[appt.mode] || Video;
                    return (
                      <Card key={appt.id} className="p-4 border-yellow-200 dark:border-yellow-800" data-testid={`card-appointment-${appt.id}`}>
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex items-start gap-3 min-w-0">
                            <div className="w-10 h-10 rounded-lg bg-yellow-100 dark:bg-yellow-900/30 flex items-center justify-center shrink-0">
                              <ModeIcon className="w-5 h-5 text-yellow-700 dark:text-yellow-400" />
                            </div>
                            <div className="min-w-0">
                              <p className="font-medium text-sm">{appt.clientName}</p>
                              <p className="text-xs text-muted-foreground">{appt.clientEmail}</p>
                              <div className="flex items-center gap-1 text-sm mt-1">
                                <Clock className="w-3.5 h-3.5 text-muted-foreground" />
                                <span>{new Date(appt.datetime).toLocaleString()}</span>
                              </div>
                              <span className="text-xs text-muted-foreground capitalize">{appt.mode.replace("_", " ")}</span>
                              {appt.notes && <p className="text-xs text-muted-foreground mt-1">{appt.notes}</p>}
                            </div>
                          </div>
                          <div className="flex flex-col gap-2 shrink-0">
                            <Button size="sm" onClick={() => respondMutation.mutate({ id: appt.id, action: "accept" })} disabled={respondMutation.isPending} data-testid={`button-accept-${appt.id}`}>
                              <Check className="w-3.5 h-3.5 mr-1" /> Accept
                            </Button>
                            {rescheduleId === appt.id ? (
                              <div className="flex gap-1">
                                <Input type="datetime-local" value={newDatetime} onChange={e => setNewDatetime(e.target.value)} className="text-xs h-8 w-40" data-testid={`input-reschedule-${appt.id}`} />
                                <Button size="sm" variant="outline" disabled={!newDatetime || respondMutation.isPending} onClick={() => respondMutation.mutate({ id: appt.id, action: "reschedule", datetime: new Date(newDatetime).toISOString() })} data-testid={`button-confirm-reschedule-${appt.id}`}>
                                  OK
                                </Button>
                              </div>
                            ) : (
                              <Button size="sm" variant="outline" onClick={() => setRescheduleId(appt.id)} data-testid={`button-reschedule-${appt.id}`}>
                                <RefreshCw className="w-3.5 h-3.5 mr-1" /> Reschedule
                              </Button>
                            )}
                            <Button size="sm" variant="outline" className="text-red-600" onClick={() => respondMutation.mutate({ id: appt.id, action: "cancel" })} disabled={respondMutation.isPending} data-testid={`button-decline-${appt.id}`}>
                              <X className="w-3.5 h-3.5 mr-1" /> Decline
                            </Button>
                          </div>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              </div>
            )}

            {active.length > 0 && (
              <div>
                <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3" data-testid="heading-active">
                  Active ({active.length})
                </h2>
                <div className="space-y-3">
                  {active.map((appt) => {
                    const ModeIcon = MODE_ICONS[appt.mode] || Video;
                    return (
                      <Card key={appt.id} className="p-4" data-testid={`card-appointment-${appt.id}`}>
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex items-start gap-3 min-w-0">
                            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                              <ModeIcon className="w-5 h-5 text-primary" />
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${STATUS_COLORS[appt.status]}`}>
                                  {appt.status}
                                </span>
                              </div>
                              <p className="font-medium text-sm">{appt.clientName}</p>
                              <div className="flex items-center gap-1 text-sm mt-1">
                                <Clock className="w-3.5 h-3.5 text-muted-foreground" />
                                <span>{new Date(appt.datetime).toLocaleString()}</span>
                              </div>
                            </div>
                          </div>
                          {appt.status === "CONFIRMED" && (
                            <Button size="sm" variant="outline" onClick={() => completeMutation.mutate(appt.id)} disabled={completeMutation.isPending} data-testid={`button-complete-${appt.id}`}>
                              <Check className="w-3.5 h-3.5 mr-1" /> Complete
                            </Button>
                          )}
                        </div>
                      </Card>
                    );
                  })}
                </div>
              </div>
            )}

            {past.length > 0 && (
              <div>
                <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3" data-testid="heading-past">
                  Past ({past.length})
                </h2>
                <div className="space-y-3">
                  {past.map((appt) => {
                    const ModeIcon = MODE_ICONS[appt.mode] || Video;
                    return (
                      <Card key={appt.id} className="p-4 opacity-70" data-testid={`card-appointment-${appt.id}`}>
                        <div className="flex items-start gap-3">
                          <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center shrink-0">
                            <ModeIcon className="w-5 h-5 text-muted-foreground" />
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${STATUS_COLORS[appt.status]}`}>
                                {appt.status}
                              </span>
                            </div>
                            <p className="font-medium text-sm">{appt.clientName}</p>
                            <div className="flex items-center gap-1 text-sm mt-1">
                              <Clock className="w-3.5 h-3.5 text-muted-foreground" />
                              <span>{new Date(appt.datetime).toLocaleString()}</span>
                            </div>
                          </div>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
