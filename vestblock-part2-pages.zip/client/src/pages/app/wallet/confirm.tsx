import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Shield, CheckCircle, XCircle, RefreshCw } from "lucide-react";
import { Link, useSearch, useLocation } from "wouter";

export default function WalletConfirm() {
  const { toast } = useToast();
  const search = useSearch();
  const [, setLocation] = useLocation();
  const params = new URLSearchParams(search);
  const transactionId = params.get("txn") || "";

  const [code, setCode] = useState("");
  const [verified, setVerified] = useState(false);
  const [failed, setFailed] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [timeLeft, setTimeLeft] = useState(300);

  useEffect(() => {
    if (timeLeft <= 0 || verified || failed) return;
    const timer = setInterval(() => setTimeLeft(t => t - 1), 1000);
    return () => clearInterval(timer);
  }, [timeLeft, verified, failed]);

  const verifyMutation = useMutation({
    mutationFn: async (data: { transactionId: string; code: string }) => {
      const res = await apiRequest("POST", "/api/transactions/verify-otp", data);
      return res.json();
    },
    onSuccess: () => {
      setVerified(true);
      setErrorMsg("");
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({ title: "Transaction verified", description: "Your transaction has been confirmed." });
    },
    onError: async (err: any) => {
      try {
        const raw = err?.message || "";
        const jsonPart = raw.includes(": {") ? raw.slice(raw.indexOf(": {") + 2) : raw.includes(": ") ? raw.slice(raw.indexOf(": ") + 2) : raw;
        const data = JSON.parse(jsonPart);
        const msg = data.message || "Invalid OTP code.";
        setErrorMsg(msg);
        if (msg.includes("Maximum") || msg.includes("expired")) {
          setFailed(true);
        }
      } catch {
        const msg = err?.message || "Invalid OTP code. Please try again.";
        const cleanMsg = msg.includes(": ") ? msg.slice(msg.indexOf(": ") + 2) : msg;
        setErrorMsg(cleanMsg);
        if (cleanMsg.includes("Maximum") || cleanMsg.includes("expired")) {
          setFailed(true);
        }
      }
    },
  });

  const resendMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/transactions/resend-otp", { transactionId });
      return res.json();
    },
    onSuccess: () => {
      setTimeLeft(300);
      setCode("");
      setErrorMsg("");
      toast({ title: "OTP resent", description: "A new code has been sent to your email." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to resend OTP.", variant: "destructive" });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code || code.length !== 6 || !transactionId) return;
    verifyMutation.mutate({ transactionId, code });
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, "0")}`;
  };

  if (!transactionId) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="p-8 max-w-md w-full text-center">
          <XCircle className="w-12 h-12 mx-auto mb-4 text-red-500" />
          <h2 className="text-lg font-semibold mb-2">No Transaction</h2>
          <p className="text-sm text-muted-foreground mb-4">No transaction ID provided.</p>
          <Link href="/investor/wallet">
            <Button data-testid="button-back-wallet">Go to Wallet</Button>
          </Link>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="p-8 max-w-md w-full" data-testid="card-otp-verification">
        <div className="flex items-center gap-2 mb-6">
          <Link href="/investor/wallet">
            <Button variant="ghost" size="icon" data-testid="button-back">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <Shield className="w-6 h-6 text-primary" />
          <h1 className="text-xl font-bold" data-testid="heading-verify">Verify Transaction</h1>
        </div>

        {verified ? (
          <div className="text-center py-8" data-testid="section-success">
            <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-500" />
            <h2 className="text-xl font-semibold mb-2">Transaction Verified</h2>
            <p className="text-sm text-muted-foreground mb-6">Your transaction has been confirmed and is being processed.</p>
            <Link href="/investor/wallet">
              <Button data-testid="button-done">Back to Wallet</Button>
            </Link>
          </div>
        ) : failed ? (
          <div className="text-center py-8" data-testid="section-failed">
            <XCircle className="w-16 h-16 mx-auto mb-4 text-red-500" />
            <h2 className="text-xl font-semibold mb-2">Verification Failed</h2>
            <p className="text-sm text-muted-foreground mb-6">{errorMsg}</p>
            <Link href="/investor/wallet">
              <Button variant="outline" data-testid="button-failed-back">Back to Wallet</Button>
            </Link>
          </div>
        ) : (
          <>
            <p className="text-sm text-muted-foreground mb-6">
              A 6-digit verification code has been sent to your email. Enter the code below to confirm your transaction.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-center">
                  <Input
                    type="text"
                    maxLength={6}
                    value={code}
                    onChange={e => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                    className="text-center text-2xl tracking-[0.5em] font-mono w-56 h-14"
                    placeholder="000000"
                    autoFocus
                    data-testid="input-otp-code"
                  />
                </div>

                {errorMsg && !failed && (
                  <p className="text-xs text-red-600 text-center" data-testid="text-error">{errorMsg}</p>
                )}
              </div>

              <div className="text-center">
                {timeLeft > 0 ? (
                  <p className="text-xs text-muted-foreground" data-testid="text-timer">
                    Code expires in {formatTime(timeLeft)}
                  </p>
                ) : (
                  <p className="text-xs text-red-600" data-testid="text-expired">Code expired</p>
                )}
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={code.length !== 6 || verifyMutation.isPending || timeLeft <= 0}
                data-testid="button-verify"
              >
                {verifyMutation.isPending ? "Verifying..." : "Verify & Confirm"}
              </Button>
            </form>

            <div className="text-center mt-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => resendMutation.mutate()}
                disabled={resendMutation.isPending}
                data-testid="button-resend"
              >
                <RefreshCw className="w-3.5 h-3.5 mr-1" />
                {resendMutation.isPending ? "Sending..." : "Resend Code"}
              </Button>
            </div>
          </>
        )}
      </Card>
    </div>
  );
}
