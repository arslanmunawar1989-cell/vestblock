import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { GlassCard } from "@/components/glass-card";
import { GlassButton } from "@/components/glass-button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, FileText, Shield, AlertTriangle, Loader2 } from "lucide-react";

interface LegalDoc {
  id: string;
  type: string;
  title: string;
  content: string;
  version: number;
  effectiveDate: string;
  isActive: boolean;
}

const typeIcons: Record<string, typeof FileText> = {
  terms_of_service: FileText,
  privacy_policy: Shield,
  risk_disclosure: AlertTriangle,
};

const typeLabels: Record<string, string> = {
  terms_of_service: "Terms of Service",
  privacy_policy: "Privacy Policy",
  risk_disclosure: "Risk Disclosure",
};

function LegalDocPage() {
  const [, params] = useRoute("/legal/:type");
  const docType = params?.type || "";

  const { data: doc, isLoading, error } = useQuery<LegalDoc>({
    queryKey: ["/api/legal/documents", docType],
    queryFn: async () => {
      const res = await fetch(`/api/legal/documents/${docType}`);
      if (!res.ok) throw new Error("Failed to fetch document");
      return res.json();
    },
    enabled: !!docType,
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="gradient-hero text-white px-6 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl font-bold">VestBlock Legal</h1>
        </div>
      </div>
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Link href="/legal" data-testid="link-back-legal">
          <GlassButton className="mb-6">
            <ArrowLeft className="w-4 h-4" />
            Back to Legal
          </GlassButton>
        </Link>

        {isLoading && (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        )}

        {error && (
          <GlassCard>
            <p className="text-destructive text-center">Failed to load document. Please try again later.</p>
          </GlassCard>
        )}

        {doc && (
          <GlassCard>
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-3 flex-wrap">
                <h1 className="text-2xl font-bold" data-testid="legal-doc-title">{doc.title}</h1>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="text-xs">Version {doc.version}</Badge>
                  <Badge variant="outline" className="text-xs">Effective: {doc.effectiveDate}</Badge>
                </div>
              </div>
              <div className="prose prose-sm dark:prose-invert max-w-none" data-testid="legal-doc-content">
                {doc.content.split("\n").map((line, i) => {
                  if (line.startsWith("# ")) return <h1 key={i} className="text-xl font-bold mt-6 mb-3">{line.replace("# ", "")}</h1>;
                  if (line.startsWith("## ")) return <h2 key={i} className="text-lg font-semibold mt-5 mb-2">{line.replace("## ", "")}</h2>;
                  if (line.startsWith("- ")) return <li key={i} className="ml-4 text-sm text-muted-foreground">{line.replace("- ", "")}</li>;
                  if (line.trim() === "") return <br key={i} />;
                  return <p key={i} className="text-sm text-muted-foreground leading-relaxed">{line}</p>;
                })}
              </div>
            </div>
          </GlassCard>
        )}
      </div>
    </div>
  );
}

function LegalIndex() {
  const { data: docs, isLoading } = useQuery<LegalDoc[]>({
    queryKey: ["/api/legal/documents"],
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="gradient-hero text-white px-6 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl font-bold">VestBlock Legal</h1>
        </div>
      </div>
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Link href="/" data-testid="link-back-home">
          <GlassButton className="mb-6">
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </GlassButton>
        </Link>

        <h1 className="text-3xl font-bold mb-2" data-testid="legal-page-title">Legal Documents</h1>
        <p className="text-muted-foreground mb-8">Review our legal policies and terms governing the VestBlock platform.</p>

        {isLoading && (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        )}

        <div className="grid gap-4">
          {docs?.map((doc) => {
            const Icon = typeIcons[doc.type] || FileText;
            return (
              <Link key={doc.id} href={`/legal/${doc.type}`} data-testid={`link-legal-${doc.type}`}>
                <GlassCard className="hover-elevate cursor-pointer">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-md gradient-hero flex items-center justify-center flex-shrink-0">
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold" data-testid={`legal-title-${doc.type}`}>{doc.title}</p>
                      <p className="text-sm text-muted-foreground">
                        Version {doc.version} &middot; Effective {doc.effectiveDate}
                      </p>
                    </div>
                    <Badge variant="secondary" className="flex-shrink-0">View</Badge>
                  </div>
                </GlassCard>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export { LegalIndex, LegalDocPage };
