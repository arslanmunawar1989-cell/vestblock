import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  FolderOpen,
  FileText,
  Building2,
  MapPin,
  Download,
  ExternalLink,
  ArrowLeft,
  Shield,
  ScrollText,
  FileCheck2,
  Home,
  Wrench,
  Receipt,
  BarChart3,
  Lock,
  Loader2,
} from "lucide-react";
import { DATA_ROOM_DOC_TYPE_LABELS, DATA_ROOM_ACCESS_TIER_LABELS, DATA_ROOM_ACCESS_TIER_ORDER } from "@shared/schema";
import type { DataRoomDocType, DataRoomAccessTier } from "@shared/schema";

interface InvestorProperty {
  id: string;
  name: string;
  symbol: string;
  country: string;
  status: string;
  imageUrl: string | null;
  documentCount: number;
  lockedCount: number;
  totalDocuments: number;
  investorTier: string;
  investedAmount: number;
  baseCurrency: string;
}

interface DataRoomDoc {
  id: string;
  title: string;
  category: string;
  docType: string | null;
  fileName: string;
  url: string;
  status: string;
  accessTier: string;
  description: string | null;
  createdAt: string;
  fileSize: number | null;
  mimeType: string | null;
}

interface LockedDoc {
  id: string;
  title: string;
  accessTier: string;
  category: string;
  docType: string | null;
}

interface DataRoomResponse {
  docs: DataRoomDoc[];
  lockedDocs: LockedDoc[];
  investorTier: string;
  investedAmount: number;
  thresholds: Record<string, number>;
}

const DOC_TYPE_ICONS: Record<string, typeof FileText> = {
  title_deed: ScrollText,
  valuation_report: BarChart3,
  lease_agreement: FileCheck2,
  insurance_policy: Shield,
  rental_contract: Home,
  construction_update: Wrench,
  expense_invoice: Receipt,
  annual_financial_statement: BarChart3,
  other: FileText,
};

function getDocTypeIcon(docType: string | null) {
  const Icon = DOC_TYPE_ICONS[docType || "other"] || FileText;
  return Icon;
}

function formatFileSize(bytes: number | null): string {
  if (!bytes) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function getCountryFlag(code: string): string {
  const flags: Record<string, string> = { PK: "PK", AE: "AE", GB: "GB", US: "US", QA: "QA" };
  return flags[code] || code;
}

export default function InvestorDataRoom() {
  const [selectedPropertyId, setSelectedPropertyId] = useState<string | null>(null);
  const [selectedDoc, setSelectedDoc] = useState<DataRoomDoc | null>(null);

  const { data: properties = [], isLoading: propertiesLoading } = useQuery<InvestorProperty[]>({
    queryKey: ["/api/data-room/investor/properties"],
  });

  const { data: dataRoomResponse, isLoading: docsLoading } = useQuery<DataRoomResponse>({
    queryKey: [`/api/data-room/assets/${selectedPropertyId}/docs`],
    enabled: !!selectedPropertyId,
  });

  const docs = dataRoomResponse?.docs || [];
  const lockedDocs = dataRoomResponse?.lockedDocs || [];
  const investorTier = dataRoomResponse?.investorTier || "public";
  const investedAmount = dataRoomResponse?.investedAmount || 0;
  const thresholds = dataRoomResponse?.thresholds || {};

  const selectedProperty = properties.find(p => p.id === selectedPropertyId);

  const groupedByType: Record<string, DataRoomDoc[]> = {};
  docs.forEach(d => {
    const type = d.docType || "other";
    if (!groupedByType[type]) groupedByType[type] = [];
    groupedByType[type].push(d);
  });

  const docTypeOrder: DataRoomDocType[] = [
    "title_deed",
    "valuation_report",
    "lease_agreement",
    "insurance_policy",
    "rental_contract",
    "construction_update",
    "expense_invoice",
    "annual_financial_statement",
    "other",
  ];

  const sortedTypes = docTypeOrder.filter(t => groupedByType[t]?.length > 0);

  if (selectedPropertyId && selectedProperty) {
    return (
      <RoleLayout role="investor">
        <div className="space-y-6">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSelectedPropertyId(null)}
              data-testid="button-back-properties"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <PageTitle
              title={`${selectedProperty.name} - Data Room`}
              description="View property documents available to you as an investor"
            />
          </div>

          <Card className="p-4">
            <div className="flex items-center gap-3 flex-wrap">
              <Building2 className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium" data-testid="text-property-name">{selectedProperty.name}</p>
                <p className="text-xs text-muted-foreground">
                  {selectedProperty.symbol} / {getCountryFlag(selectedProperty.country)}
                </p>
              </div>
              <div className="ml-auto flex items-center gap-2 flex-wrap">
                <Badge variant="default" data-testid="badge-investor-tier">
                  {DATA_ROOM_ACCESS_TIER_LABELS[(investorTier as DataRoomAccessTier)] || investorTier} Access
                </Badge>
                <Badge variant="outline">{docs.length} accessible</Badge>
                {lockedDocs.length > 0 && (
                  <Badge variant="secondary" data-testid="badge-locked-count">
                    <Lock className="w-3 h-3 mr-1" />
                    {lockedDocs.length} locked
                  </Badge>
                )}
              </div>
            </div>
            {investedAmount > 0 && (
              <p className="text-xs text-muted-foreground mt-2" data-testid="text-invested-amount">
                Your investment: {investedAmount.toLocaleString()} {selectedProperty.baseCurrency || ""}
              </p>
            )}
          </Card>

          {docsLoading ? (
            <div className="space-y-3">
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
            </div>
          ) : docs.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center gap-3 py-8 text-center">
                <FolderOpen className="w-10 h-10 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium" data-testid="text-no-docs">No documents available</p>
                  <p className="text-xs text-muted-foreground mt-1">Documents will appear here once the issuer publishes them</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-5">
              {sortedTypes.map(docType => {
                const typeDocs = groupedByType[docType];
                const Icon = getDocTypeIcon(docType);
                const label = DATA_ROOM_DOC_TYPE_LABELS[docType as DataRoomDocType] || docType;
                return (
                  <Card key={docType}>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm flex items-center gap-2">
                        <Icon className="w-4 h-4" />
                        {label}
                        <Badge variant="secondary" className="ml-1">{typeDocs.length}</Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {typeDocs.map(doc => (
                        <div
                          key={doc.id}
                          className="flex items-center gap-3 p-3 rounded-md bg-muted/50 hover-elevate cursor-pointer"
                          onClick={() => setSelectedDoc(doc)}
                          data-testid={`doc-item-${doc.id}`}
                        >
                          <FileText className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">{doc.title}</p>
                            <p className="text-xs text-muted-foreground truncate">
                              {doc.fileName}
                              {doc.fileSize ? ` - ${formatFileSize(doc.fileSize)}` : ""}
                              {" - "}
                              {new Date(doc.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => {
                              e.stopPropagation();
                              window.open(doc.url, "_blank");
                            }}
                            data-testid={`button-view-doc-${doc.id}`}
                          >
                            <ExternalLink className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}

          {lockedDocs.length > 0 && (
            <Card data-testid="card-locked-docs">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  Restricted Documents
                  <Badge variant="secondary" className="ml-1">{lockedDocs.length}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <p className="text-xs text-muted-foreground mb-3">
                  Increase your investment to unlock access to these documents
                </p>
                {lockedDocs.map(doc => {
                  const requiredAmount = thresholds[(doc.accessTier as DataRoomAccessTier) || "public"] || 0;
                  return (
                    <div
                      key={doc.id}
                      className="flex items-center gap-3 p-3 rounded-md bg-muted/30 opacity-60"
                      data-testid={`locked-doc-${doc.id}`}
                    >
                      <Lock className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{doc.title}</p>
                        <p className="text-xs text-muted-foreground">
                          Requires {DATA_ROOM_ACCESS_TIER_LABELS[(doc.accessTier as DataRoomAccessTier)] || doc.accessTier} tier
                          {requiredAmount > investedAmount && (
                            <span> (min. {requiredAmount.toLocaleString()} invested)</span>
                          )}
                        </p>
                      </div>
                      <Badge variant="outline" className="text-xs flex-shrink-0">
                        {DATA_ROOM_ACCESS_TIER_LABELS[(doc.accessTier as DataRoomAccessTier)] || doc.accessTier}
                      </Badge>
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          )}
        </div>

        <Dialog open={!!selectedDoc} onOpenChange={() => setSelectedDoc(null)}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="text-base">{selectedDoc?.title}</DialogTitle>
            </DialogHeader>
            {selectedDoc && (
              <div className="space-y-4 py-2">
                {selectedDoc.description && (
                  <p className="text-sm text-muted-foreground">{selectedDoc.description}</p>
                )}
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-xs text-muted-foreground">Document Type</p>
                    <p className="font-medium capitalize" data-testid="text-doc-type">
                      {DATA_ROOM_DOC_TYPE_LABELS[(selectedDoc.docType || "other") as DataRoomDocType] || selectedDoc.docType || "Other"}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Category</p>
                    <p className="font-medium capitalize" data-testid="text-doc-category">{selectedDoc.category}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">File Name</p>
                    <p className="font-medium truncate" data-testid="text-doc-filename">{selectedDoc.fileName}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Uploaded</p>
                    <p className="font-medium">{new Date(selectedDoc.createdAt).toLocaleDateString()}</p>
                  </div>
                  {selectedDoc.fileSize && (
                    <div>
                      <p className="text-xs text-muted-foreground">File Size</p>
                      <p className="font-medium">{formatFileSize(selectedDoc.fileSize)}</p>
                    </div>
                  )}
                  {selectedDoc.mimeType && (
                    <div>
                      <p className="text-xs text-muted-foreground">File Type</p>
                      <p className="font-medium">{selectedDoc.mimeType}</p>
                    </div>
                  )}
                </div>
                <Button
                  className="w-full"
                  onClick={() => window.open(selectedDoc.url, "_blank")}
                  data-testid="button-open-doc"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Open Document
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </RoleLayout>
    );
  }

  return (
    <RoleLayout role="investor">
      <div className="space-y-6">
        <PageTitle
          title="Data Room"
          description="Access property documents for your investments. Only properties you have invested in are shown."
        />

        <Card className="p-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Lock className="w-4 h-4 flex-shrink-0" />
            <span data-testid="text-access-notice">You can only view documents for properties where you hold an active investment position.</span>
          </div>
        </Card>

        {propertiesLoading ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <Skeleton className="h-40" />
            <Skeleton className="h-40" />
            <Skeleton className="h-40" />
          </div>
        ) : properties.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center gap-3 py-12 text-center">
              <FolderOpen className="w-12 h-12 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium" data-testid="text-no-properties">No property data rooms available</p>
                <p className="text-xs text-muted-foreground mt-1">
                  You need to invest in a property to access its data room documents
                </p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {properties.map(property => (
              <Card
                key={property.id}
                className="hover-elevate cursor-pointer overflow-visible"
                onClick={() => setSelectedPropertyId(property.id)}
                data-testid={`property-card-${property.id}`}
              >
                <CardContent className="p-5">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center flex-shrink-0">
                      <Building2 className="w-5 h-5 text-muted-foreground" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium truncate" data-testid={`text-property-name-${property.id}`}>
                        {property.name}
                      </p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {property.symbol}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mt-4 flex-wrap">
                    <Badge variant="outline" className="text-xs">{getCountryFlag(property.country)}</Badge>
                    <Badge variant="secondary" className="text-xs">
                      <FileText className="w-3 h-3 mr-1" />
                      {property.documentCount} doc{property.documentCount !== 1 ? "s" : ""}
                    </Badge>
                    {property.lockedCount > 0 && (
                      <Badge variant="secondary" className="text-xs">
                        <Lock className="w-3 h-3 mr-1" />
                        {property.lockedCount} locked
                      </Badge>
                    )}
                    <Badge variant="outline" className="text-xs" data-testid={`badge-tier-${property.id}`}>
                      {DATA_ROOM_ACCESS_TIER_LABELS[(property.investorTier as DataRoomAccessTier)] || property.investorTier}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </RoleLayout>
  );
}
