import { useQuery } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Shield, FileText, Info, Scale, CheckCircle, AlertCircle, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
interface FeeItem {
  feeType: string;
  label: string;
  legalLabel: string;
  description: string;
  rateRange: string;
  currentRate: string;
  method: string;
  isActive: boolean;
}

interface FeeCategory {
  category: string;
  categoryLabel: string;
  categoryDescription: string;
  fees: FeeItem[];
}

interface FeeDisclosureResponse {
  categories: FeeCategory[];
  lastUpdated: string;
}

export default function InvestorFeeDisclosure() {
  const { data, isLoading } = useQuery<FeeDisclosureResponse>({
    queryKey: ["/api/fees/disclosure"],
  });

  return (
    <RoleLayout role="investor">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/investor/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Fee Schedule & Disclosures"
          description="Complete transparency into all platform fees. All fees are versioned, auditable, and disclosed before any transaction."
        />
        </div>

        <Card data-testid="notice-card">
          <CardContent className="flex items-start gap-3 p-4">
            <Shield className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
            <p className="text-sm text-muted-foreground">
              VestBlock is committed to transparent and legally compliant fee structures. All fees listed below are disclosed prior to transactions and subject to regulatory requirements in each jurisdiction.
            </p>
          </CardContent>
        </Card>

        {isLoading ? (
          <div className="space-y-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="space-y-3">
                <Skeleton className="h-6 w-48 rounded-md" />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {[...Array(4)].map((_, j) => (
                    <Skeleton key={j} className="h-40 rounded-md" />
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <>
            {(data?.categories || []).map((cat) => (
              <Section
                key={cat.category}
                title={cat.categoryLabel}
                description={cat.categoryDescription}
              >
                <div
                  className="grid grid-cols-1 md:grid-cols-2 gap-3"
                  data-testid={`category-grid-${cat.category}`}
                >
                  {cat.fees.map((fee) => (
                    <GlassCard
                      key={fee.feeType}
                      padding="md"
                      data-testid={`fee-card-${fee.feeType}`}
                    >
                      <div className="space-y-3">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-start gap-2 min-w-0">
                            <FileText className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                            <div className="min-w-0">
                              <p
                                className="text-sm font-bold"
                                data-testid={`fee-legal-label-${fee.feeType}`}
                              >
                                {fee.legalLabel}
                              </p>
                              <Badge
                                variant="secondary"
                                className="no-default-hover-elevate mt-1"
                                data-testid={`fee-label-badge-${fee.feeType}`}
                              >
                                {fee.label}
                              </Badge>
                            </div>
                          </div>
                          <Badge
                            variant={fee.isActive ? "default" : "outline"}
                            className="no-default-hover-elevate flex-shrink-0"
                            data-testid={`fee-status-badge-${fee.feeType}`}
                          >
                            {fee.isActive ? (
                              <span className="flex items-center gap-1">
                                <CheckCircle className="w-3 h-3" />
                                Active
                              </span>
                            ) : (
                              <span className="flex items-center gap-1">
                                <AlertCircle className="w-3 h-3" />
                                Inactive
                              </span>
                            )}
                          </Badge>
                        </div>

                        <p
                          className="text-xs text-muted-foreground"
                          data-testid={`fee-description-${fee.feeType}`}
                        >
                          {fee.description}
                        </p>

                        <div className="flex items-center gap-4 pt-2 border-t flex-wrap">
                          <div>
                            <p className="text-xs text-muted-foreground">Current Rate</p>
                            <p
                              className="text-sm font-semibold"
                              data-testid={`fee-current-rate-${fee.feeType}`}
                            >
                              {fee.method === "flat" ? "Fixed Amount" : fee.currentRate}
                              {fee.method === "flat" && (
                                <span className="text-xs text-muted-foreground ml-1">
                                  ({fee.currentRate})
                                </span>
                              )}
                            </p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Range</p>
                            <p
                              className="text-sm font-semibold"
                              data-testid={`fee-range-${fee.feeType}`}
                            >
                              {fee.rateRange}
                            </p>
                          </div>
                        </div>
                      </div>
                    </GlassCard>
                  ))}
                </div>
              </Section>
            ))}

            <Section title="Regulatory Compliance">
              <GlassCard padding="md" data-testid="regulatory-compliance-card">
                <div className="flex items-start gap-3">
                  <Scale className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                  <div className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      All fees are structured in accordance with applicable securities regulations across our operating jurisdictions: Pakistan (SECP), UAE (DFSA/SCA), UK (FCA), US (SEC), and Qatar (QFCRA).
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Fee schedules are subject to periodic review and may be adjusted. Investors will be notified of any material changes.
                    </p>
                    {data?.lastUpdated && (
                      <div className="flex items-center gap-2 pt-2 border-t">
                        <Info className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                        <p
                          className="text-xs text-muted-foreground"
                          data-testid="text-last-updated"
                        >
                          Last Updated: {new Date(data.lastUpdated).toLocaleDateString("en-US", {
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                          })}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </GlassCard>
            </Section>
          </>
        )}
      </div>
    </RoleLayout>
  );
}