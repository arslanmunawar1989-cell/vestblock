import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate, formatCurrency } from "@/lib/format";
import { SUPPORTED_CURRENCIES, DEFAULT_CURRENCY } from "@/lib/currencies";
import {
  Loader2,
  Target,
  Calendar,
  Banknote,
  XCircle,
  ArrowRightLeft,
  Landmark,
  Clock,
  Building2,
  MapPin,
  Layers,
  Globe, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface Property {
  id: string;
  name: string;
  symbol: string;
  location?: string;
  country: string;
  baseCurrency: string;
  propertyType?: string;
  imageUrl?: string;
  annualYield?: string;
  occupancyRate?: string;
}

interface PropertyUnit {
  totalUnits: string;
  unitPrice: string;
  unitDecimals: number;
  currency: string;
  status: string;
  unitsIssued: string;
}

interface PropertyAcquisition {
  totalAcquisitionCost: string;
  currency: string;
}

interface Offering {
  id: string;
  vehicleId: string;
  name: string;
  targetAmount: string;
  minInvest: string;
  maxInvest: string | null;
  startDate: string;
  endDate: string;
  status: string;
  totalCommitted: string;
  createdAt: string;
  vehicle?: {
    id: string;
    name: string;
    type: string;
    baseCurrency: string;
  };
  property?: Property | null;
  propertyUnit?: PropertyUnit | null;
  propertyAcquisition?: PropertyAcquisition | null;
}

interface Commitment {
  id: string;
  userId: string;
  offeringId: string;
  amount: string;
  currency: string;
  convertedAmount: string | null;
  baseCurrency: string | null;
  fxRate: string | null;
  status: string;
  coolingOffEndsAt: string | null;
  createdAt: string;
  offering?: Offering;
  property?: Property | null;
}


function commitmentStatusVariant(status: string): "default" | "secondary" | "destructive" | "outline" {
  switch (status) {
    case "CONFIRMED":
    case "SETTLED":
      return "default";
    case "COOLING_OFF":
    case "PENDING":
      return "secondary";
    case "CANCELLED":
    case "REJECTED":
      return "destructive";
    default:
      return "outline";
  }
}

const COUNTRY_NAMES: Record<string, string> = {
  PK: "Pakistan",
  AE: "UAE",
  GB: "United Kingdom",
  US: "United States",
  QA: "Qatar",
};

export default function InvestorOfferings() {
  const { toast } = useToast();
  const [commitOffering, setCommitOffering] = useState<Offering | null>(null);
  const [commitAmount, setCommitAmount] = useState("");
  const [commitCurrency, setCommitCurrency] = useState(DEFAULT_CURRENCY);

  const { data: offerings = [], isLoading: offeringsLoading } = useQuery<Offering[]>({
    queryKey: ["/api/offerings/open"],
  });

  const { data: commitments = [], isLoading: commitmentsLoading } = useQuery<Commitment[]>({
    queryKey: ["/api/my/commitments"],
  });

  const commitMutation = useMutation({
    mutationFn: async (data: { offeringId: string; amount: string; currency: string }) => {
      const res = await apiRequest("POST", `/api/offerings/${data.offeringId}/commit`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/offerings/open"] });
      queryClient.invalidateQueries({ queryKey: ["/api/my/commitments"] });
      setCommitOffering(null);
      setCommitAmount("");
      toast({ title: "Investment Committed", description: "Your investment commitment has been submitted. Funds have been reserved from your wallet." });
    },
    onError: (err: any) => {
      toast({ title: "Commitment Failed", description: err.message || "Could not submit commitment", variant: "destructive" });
    },
  });

  const cancelMutation = useMutation({
    mutationFn: async (commitmentId: string) => {
      const res = await apiRequest("POST", `/api/my/commitments/${commitmentId}/cancel`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/my/commitments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/offerings/open"] });
      toast({ title: "Commitment Cancelled", description: "Your commitment has been cancelled and funds released." });
    },
    onError: (err: any) => {
      toast({ title: "Cancellation Failed", description: err.message || "Could not cancel commitment", variant: "destructive" });
    },
  });

  const openCommitDialog = (offering: Offering) => {
    setCommitOffering(offering);
    setCommitAmount("");
    setCommitCurrency((offering.vehicle?.baseCurrency || DEFAULT_CURRENCY) as typeof commitCurrency);
  };

  const handleSubmitCommit = () => {
    if (!commitOffering) return;
    const amount = parseFloat(commitAmount);
    if (isNaN(amount) || amount <= 0) {
      toast({ title: "Invalid Amount", description: "Please enter a valid amount.", variant: "destructive" });
      return;
    }
    commitMutation.mutate({
      offeringId: commitOffering.id,
      amount: amount.toString(),
      currency: commitCurrency,
    });
  };

  if (offeringsLoading) {
    return (
      <RoleLayout role="investor">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </RoleLayout>
    );
  }

  return (
    <RoleLayout role="investor">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/investor/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Property Investments"
          description="Browse available properties and invest directly. Each property is independent — your funds go to a specific property."
        />
        </div>

        <Tabs defaultValue="offerings">
          <TabsList>
            <TabsTrigger value="offerings" data-testid="tab-offerings">Available Properties</TabsTrigger>
            <TabsTrigger value="commitments" data-testid="tab-commitments">My Commitments</TabsTrigger>
          </TabsList>

          <TabsContent value="offerings" className="mt-4">
            <Section title="Open Property Offerings">
              {offerings.length === 0 ? (
                <GlassCard className="text-center py-12">
                  <Target className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
                  <p className="text-muted-foreground" data-testid="text-no-offerings">No open property offerings available at this time.</p>
                </GlassCard>
              ) : (
                <div className="grid gap-4 md:grid-cols-2">
                  {offerings.map((offering) => {
                    const target = parseFloat(offering.targetAmount) || 0;
                    const committed = parseFloat(offering.totalCommitted) || 0;
                    const progress = target > 0 ? Math.min((committed / target) * 100, 100) : 0;
                    const vehicleCurrency = offering.vehicle?.baseCurrency || DEFAULT_CURRENCY;
                    const prop = offering.property;
                    const unit = offering.propertyUnit;

                    return (
                      <Card
                        key={offering.id}
                        data-testid={`card-offering-${offering.id}`}
                      >
                        <CardContent className="pt-4 space-y-3">
                          <div className="flex items-start justify-between gap-3 flex-wrap">
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <Building2 className="h-4 w-4 text-primary shrink-0" />
                                <p className="font-semibold" data-testid={`text-offering-name-${offering.id}`}>
                                  {prop ? prop.name : offering.name}
                                </p>
                              </div>
                              {prop && (
                                <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground flex-wrap">
                                  {prop.location && (
                                    <span className="flex items-center gap-1">
                                      <MapPin className="h-3 w-3" />
                                      {prop.location}
                                    </span>
                                  )}
                                  <span className="flex items-center gap-1">
                                    <Globe className="h-3 w-3" />
                                    {COUNTRY_NAMES[prop.country] || prop.country}
                                  </span>
                                  {prop.propertyType && (
                                    <Badge variant="outline" className="no-default-hover-elevate text-[10px]">{prop.propertyType}</Badge>
                                  )}
                                  <Badge variant="outline" className="no-default-hover-elevate text-[10px]">{prop.symbol}</Badge>
                                </div>
                              )}
                              {!prop && offering.vehicle && (
                                <div className="flex items-center gap-2 mt-1 flex-wrap">
                                  <Badge variant="outline" className="no-default-hover-elevate">{offering.vehicle.type}</Badge>
                                  <span className="text-sm text-muted-foreground">{offering.vehicle.name}</span>
                                </div>
                              )}
                            </div>
                            <Button
                              data-testid={`button-commit-${offering.id}`}
                              onClick={() => openCommitDialog(offering)}
                            >
                              <Banknote className="h-4 w-4 mr-1" />
                              Invest
                            </Button>
                          </div>

                          <div className="grid grid-cols-2 gap-3 text-sm">
                            <div>
                              <span className="text-muted-foreground">Target Raise</span>
                              <p className="font-medium">{formatCurrency(target, vehicleCurrency)}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Min Investment</span>
                              <p className="font-medium">{formatCurrency(offering.minInvest, vehicleCurrency)}</p>
                            </div>
                            {unit && (
                              <>
                                <div>
                                  <span className="text-muted-foreground flex items-center gap-1"><Layers className="h-3 w-3" /> Unit Price</span>
                                  <p className="font-medium">{formatCurrency(unit.unitPrice, unit.currency)}</p>
                                </div>
                                <div>
                                  <span className="text-muted-foreground">Total Units</span>
                                  <p className="font-medium">{parseFloat(unit.totalUnits).toLocaleString()}</p>
                                </div>
                              </>
                            )}
                            {prop?.annualYield && parseFloat(prop.annualYield) > 0 && (
                              <div>
                                <span className="text-muted-foreground">Est. Annual Yield</span>
                                <p className="font-medium">{parseFloat(prop.annualYield).toFixed(2)}%</p>
                              </div>
                            )}
                          </div>

                          <div className="space-y-1">
                            <div className="flex items-center justify-between gap-2 text-xs text-muted-foreground">
                              <span>{progress.toFixed(1)}% funded</span>
                              <span>{formatCurrency(committed, vehicleCurrency)} / {formatCurrency(target, vehicleCurrency)}</span>
                            </div>
                            <Progress value={progress} className="h-2" />
                          </div>

                          <div className="flex items-center gap-4 text-xs text-muted-foreground flex-wrap">
                            <div className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              <span>Opens: {formatDate(offering.startDate, "short")}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              <span>Closes: {formatDate(offering.endDate, "short")}</span>
                            </div>
                            <span>Accepts: PKR, AED, GBP, USD</span>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </Section>
          </TabsContent>

          <TabsContent value="commitments" className="mt-4">
            <Section title="My Commitments">
              {commitmentsLoading ? (
                <div className="flex items-center justify-center h-32">
                  <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                </div>
              ) : commitments.length === 0 ? (
                <GlassCard className="text-center py-12">
                  <Landmark className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
                  <p className="text-muted-foreground" data-testid="text-no-commitments">You have no commitments yet. Browse available properties to invest.</p>
                </GlassCard>
              ) : (
                <div className="grid gap-3">
                  {commitments.map((commitment) => {
                    const canCancel = commitment.status === "COOLING_OFF" || commitment.status === "PENDING";
                    const hasFx = commitment.fxRate && commitment.convertedAmount && commitment.baseCurrency && commitment.currency !== commitment.baseCurrency;
                    const prop = commitment.property;

                    return (
                      <GlassCard
                        key={commitment.id}
                        data-testid={`card-commitment-${commitment.id}`}
                        padding="md"
                      >
                        <div className="flex items-start justify-between gap-4 flex-wrap">
                          <div className="space-y-2 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              {prop && <Building2 className="h-4 w-4 text-primary shrink-0" />}
                              <p className="font-semibold">
                                {prop ? prop.name : (commitment.offering?.name || "Offering")}
                              </p>
                              <Badge
                                variant={commitmentStatusVariant(commitment.status)}
                                data-testid={`badge-commitment-status-${commitment.id}`}
                              >
                                {commitment.status}
                              </Badge>
                            </div>

                            {prop && (
                              <div className="flex items-center gap-2 text-xs text-muted-foreground flex-wrap">
                                {prop.location && (
                                  <span className="flex items-center gap-1">
                                    <MapPin className="h-3 w-3" />
                                    {prop.location}
                                  </span>
                                )}
                                <span>{COUNTRY_NAMES[prop.country] || prop.country}</span>
                                <Badge variant="outline" className="no-default-hover-elevate text-[10px]">{prop.symbol}</Badge>
                              </div>
                            )}

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
                              <div>
                                <span className="text-muted-foreground">Amount: </span>
                                <span className="font-medium">
                                  {formatCurrency(commitment.amount, commitment.currency)}
                                </span>
                              </div>
                              {hasFx && (
                                <>
                                  <div>
                                    <span className="text-muted-foreground">Converted: </span>
                                    <span className="font-medium">
                                      {formatCurrency(commitment.convertedAmount!, commitment.baseCurrency!)}
                                    </span>
                                  </div>
                                  <div className="flex items-center gap-1">
                                    <ArrowRightLeft className="h-3 w-3 text-muted-foreground" />
                                    <span className="text-muted-foreground">FX Rate: </span>
                                    <span className="font-medium">{parseFloat(commitment.fxRate!).toFixed(4)}</span>
                                  </div>
                                </>
                              )}
                              {commitment.coolingOffEndsAt && (
                                <div className="flex items-center gap-1">
                                  <Clock className="h-3 w-3 text-muted-foreground" />
                                  <span className="text-muted-foreground">Cooling off ends: </span>
                                  <span>{formatDate(commitment.coolingOffEndsAt, "short")}</span>
                                </div>
                              )}
                            </div>
                          </div>

                          {canCancel && (
                            <Button
                              variant="outline"
                              size="sm"
                              data-testid={`button-cancel-commitment-${commitment.id}`}
                              onClick={() => cancelMutation.mutate(commitment.id)}
                              disabled={cancelMutation.isPending}
                            >
                              {cancelMutation.isPending ? (
                                <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                              ) : (
                                <XCircle className="h-4 w-4 mr-1" />
                              )}
                              Cancel
                            </Button>
                          )}
                        </div>
                      </GlassCard>
                    );
                  })}
                </div>
              )}
            </Section>
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={!!commitOffering} onOpenChange={(open) => { if (!open) setCommitOffering(null); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Invest in Property
            </DialogTitle>
            <DialogDescription>
              {commitOffering?.property ? (
                <span className="flex items-center gap-1.5 flex-wrap">
                  {commitOffering.property.name}
                  {commitOffering.property.location && (
                    <>
                      <MapPin className="h-3 w-3" />
                      {commitOffering.property.location}
                    </>
                  )}
                </span>
              ) : (
                commitOffering?.name
              )}
            </DialogDescription>
          </DialogHeader>

          {commitOffering && (
            <div className="space-y-4">
              <Card>
                <CardContent className="pt-3 pb-3">
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <span className="text-muted-foreground">Min Investment</span>
                      <p className="font-medium">
                        {formatCurrency(commitOffering.minInvest, commitOffering.vehicle?.baseCurrency || DEFAULT_CURRENCY)}
                      </p>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Max Investment</span>
                      <p className="font-medium">
                        {commitOffering.maxInvest
                          ? formatCurrency(commitOffering.maxInvest, commitOffering.vehicle?.baseCurrency || DEFAULT_CURRENCY)
                          : "No limit"}
                      </p>
                    </div>
                    {commitOffering.propertyUnit && (
                      <>
                        <div>
                          <span className="text-muted-foreground">Unit Price</span>
                          <p className="font-medium">{formatCurrency(commitOffering.propertyUnit.unitPrice, commitOffering.propertyUnit.currency)}</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Available Units</span>
                          <p className="font-medium">{(parseFloat(commitOffering.propertyUnit.totalUnits) - parseFloat(commitOffering.propertyUnit.unitsIssued)).toLocaleString()}</p>
                        </div>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>

              <div>
                <Label>Investment Amount</Label>
                <Input
                  data-testid="input-commit-amount"
                  type="number"
                  step="0.01"
                  placeholder="Enter amount"
                  value={commitAmount}
                  onChange={(e) => setCommitAmount(e.target.value)}
                />
              </div>

              <div>
                <Label>Payment Currency</Label>
                <Select
                  value={commitCurrency}
                  onValueChange={(v: string) => setCommitCurrency(v as typeof commitCurrency)}
                >
                  <SelectTrigger data-testid="select-commit-currency">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[...SUPPORTED_CURRENCIES].map((c) => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {commitCurrency !== (commitOffering.vehicle?.baseCurrency || DEFAULT_CURRENCY) && (
                  <p className="text-xs text-muted-foreground mt-1">
                    Your {commitCurrency} will be converted to {commitOffering.vehicle?.baseCurrency || DEFAULT_CURRENCY} at the current FX rate.
                  </p>
                )}
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setCommitOffering(null)}>
              Cancel
            </Button>
            <Button
              data-testid="button-submit-commit"
              onClick={handleSubmitCommit}
              disabled={commitMutation.isPending || !commitAmount}
            >
              {commitMutation.isPending && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
              Commit Investment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </RoleLayout>
  );
}
