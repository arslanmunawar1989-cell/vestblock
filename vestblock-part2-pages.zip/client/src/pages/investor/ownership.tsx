import { useQuery } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { GlassCard } from "@/components/glass-card";
import { StatTile } from "@/components/stat-tile";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Building2, MapPin, Percent, Layers, DollarSign, ArrowLeft,
} from "lucide-react";
import { formatCurrency } from "@/lib/format";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
interface OwnershipEntry {
  assetId: string;
  propertyName: string;
  propertySymbol: string;
  location: string | null;
  country: string | null;
  propertyType: string | null;
  unitsOwned: string;
  totalUnits: string;
  percentageOwned: string;
  unitPrice: string;
  currentValue: string;
  currency: string;
  totalCapitalRequired: string;
  ledgerEntries: Array<{
    id: string;
    direction: string;
    units: string;
    unitPriceAtTime: string;
    totalValue: string;
    reason: string;
    notes: string | null;
    createdAt: string;
  }>;
}

interface OwnershipData {
  ownership: OwnershipEntry[];
}

export default function InvestorOwnership() {
  const { data, isLoading } = useQuery<OwnershipData>({
    queryKey: ["/api/investor/ownership"],
  });

  const ownership = data?.ownership || [];
  const totalProperties = ownership.length;
  const totalValue = ownership.reduce((sum, o) => sum + parseFloat(o.currentValue), 0);
  const totalUnitsOwned = ownership.reduce((sum, o) => sum + parseFloat(o.unitsOwned), 0);
  const primaryCurrency = ownership[0]?.currency || "USD";

  return (
    <RoleLayout role="investor">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/investor/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="My Properties"
          description="View your property ownership, units allocated, and investment value"
        />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {isLoading ? (
            <>
              {[1, 2, 3].map(i => <Skeleton key={i} className="h-20 w-full" />)}
            </>
          ) : (
            <>
              <StatTile
                label="Properties Owned"
                value={String(totalProperties)}
                icon={<Building2 className="w-5 h-5" />}
              />
              <StatTile
                label="Total Units"
                value={totalUnitsOwned.toFixed(2)}
                icon={<Layers className="w-5 h-5" />}
              />
              <StatTile
                label="Total Value"
                value={totalValue > 0 ? formatCurrency(totalValue, primaryCurrency) : "$0.00"}
                icon={<DollarSign className="w-5 h-5" />}
              />
            </>
          )}
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2].map(i => <Skeleton key={i} className="h-48 w-full" />)}
          </div>
        ) : ownership.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Building2 className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-lg font-medium" data-testid="text-no-ownership">No property ownership yet</p>
              <p className="text-sm text-muted-foreground mt-1">
                Invest in property offerings to receive unit allocations
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {ownership.map((prop) => {
              const unitsOwned = parseFloat(prop.unitsOwned);
              const totalUnits = parseFloat(prop.totalUnits);
              const pctOwned = parseFloat(prop.percentageOwned);

              return (
                <GlassCard key={prop.assetId} padding="md" data-testid={`ownership-card-${prop.assetId}`}>
                  <div className="flex items-start justify-between gap-4 flex-wrap mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Building2 className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="text-base font-semibold" data-testid={`text-property-name-${prop.assetId}`}>
                            {prop.propertyName}
                          </h3>
                          <Badge variant="outline" className="no-default-hover-elevate">{prop.propertySymbol}</Badge>
                          {prop.propertyType && (
                            <Badge variant="secondary" className="no-default-hover-elevate">{prop.propertyType}</Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5 flex-wrap">
                          {prop.location && (
                            <span className="flex items-center gap-0.5">
                              <MapPin className="w-3 h-3" />
                              {prop.location}
                            </span>
                          )}
                          {prop.country && <span>{prop.country}</span>}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold" data-testid={`text-ownership-value-${prop.assetId}`}>
                        {formatCurrency(prop.currentValue, prop.currency)}
                      </p>
                      <p className="text-xs text-muted-foreground">Current Value</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
                    <div className="text-center p-2 rounded-md bg-muted/40">
                      <p className="text-xs text-muted-foreground">Units Owned</p>
                      <p className="text-sm font-semibold" data-testid={`text-units-owned-${prop.assetId}`}>
                        {unitsOwned.toFixed(2)} / {totalUnits.toFixed(0)}
                      </p>
                    </div>
                    <div className="text-center p-2 rounded-md bg-muted/40">
                      <p className="text-xs text-muted-foreground flex items-center justify-center gap-0.5">
                        <Percent className="w-3 h-3" /> Ownership
                      </p>
                      <p className="text-sm font-semibold" data-testid={`text-ownership-pct-${prop.assetId}`}>
                        {pctOwned.toFixed(2)}%
                      </p>
                    </div>
                    <div className="text-center p-2 rounded-md bg-muted/40">
                      <p className="text-xs text-muted-foreground">Unit Price</p>
                      <p className="text-sm font-semibold" data-testid={`text-unit-price-${prop.assetId}`}>
                        {formatCurrency(prop.unitPrice, prop.currency)}
                      </p>
                    </div>
                    <div className="text-center p-2 rounded-md bg-muted/40">
                      <p className="text-xs text-muted-foreground">Property Value</p>
                      <p className="text-sm font-semibold" data-testid={`text-total-capital-${prop.assetId}`}>
                        {formatCurrency(prop.totalCapitalRequired, prop.currency)}
                      </p>
                    </div>
                  </div>

                  {prop.ledgerEntries.length > 0 && (
                    <div>
                      <h4 className="text-xs font-medium text-muted-foreground mb-2">Ownership Ledger</h4>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="text-xs">Date</TableHead>
                              <TableHead className="text-xs">Type</TableHead>
                              <TableHead className="text-xs text-right">Units</TableHead>
                              <TableHead className="text-xs text-right">Value</TableHead>
                              <TableHead className="text-xs">Notes</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {prop.ledgerEntries.map((entry) => (
                              <TableRow key={entry.id}>
                                <TableCell className="text-xs">
                                  {new Date(entry.createdAt).toLocaleDateString()}
                                </TableCell>
                                <TableCell>
                                  <Badge
                                    variant={entry.direction === "CREDIT" ? "default" : "secondary"}
                                    className="no-default-hover-elevate text-xs"
                                  >
                                    {entry.reason}
                                  </Badge>
                                </TableCell>
                                <TableCell className="text-xs text-right font-medium">
                                  {entry.direction === "CREDIT" ? "+" : "-"}{parseFloat(entry.units).toFixed(2)}
                                </TableCell>
                                <TableCell className="text-xs text-right">
                                  {formatCurrency(entry.totalValue, prop.currency)}
                                </TableCell>
                                <TableCell className="text-xs text-muted-foreground max-w-[200px] truncate">
                                  {entry.notes || "-"}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  )}
                </GlassCard>
              );
            })}
          </div>
        )}
      </div>
    </RoleLayout>
  );
}
