import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { StatTile } from "@/components/stat-tile";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery } from "@tanstack/react-query";
import {
  TrendingUp,
  PieChart,
  DollarSign,
  BarChart3,
  Percent,
  ArrowUpRight,
  ArrowDownRight,
  Banknote,
  Receipt,
  Wallet,
  Info, ArrowLeft,
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
interface AnalyticsData {
  overview: {
    totalInvested: string;
    currentPortfolioValue: string;
    totalDistributionsReceived: string;
    unrealizedGain: string;
    totalReturn: string;
    roiPercent: string;
    rentalYieldPercent: string;
    totalFees: string;
    holdingsCount: number;
  };
  holdings: Array<{
    tokenId: string;
    assetId: string;
    assetName: string;
    assetSymbol: string;
    baseCurrency: string;
    balance: string;
    pricePerToken: string;
    currentValue: string;
    costBasis: string;
    unrealizedGain: string;
    unrealizedGainPercent: string;
    annualYield: string | null;
    propertyType: string | null;
    location: string | null;
  }>;
  payoutHistory: Array<{
    id: string;
    distributionId: string;
    assetName: string;
    assetSymbol: string;
    payoutAmount: string;
    payoutCurrency: string;
    holdingBalance: string;
    holdingPercent: string;
    autoConverted: boolean;
    convertedAmount: string | null;
    convertedCurrency: string | null;
    date: string;
  }>;
  monthlyPayouts: Array<{
    month: string;
    amount: string;
  }>;
  feeSummary: Array<{
    id: string;
    amount: string;
    currency: string;
    description: string;
    date: string;
  }>;
  walletBalances: Array<{
    id: string;
    currency: string;
    available: string;
    pending: string;
  }>;
}

function formatCurrency(amount: string | number, currency?: string): string {
  const num = typeof amount === "string" ? parseFloat(amount) : amount;
  if (isNaN(num)) return "0.00";
  const formatted = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(Math.abs(num));
  const sign = num < 0 ? "-" : "";
  return currency ? `${sign}${formatted} ${currency}` : `${sign}${formatted}`;
}

function formatPercent(value: string | number): string {
  const num = typeof value === "string" ? parseFloat(value) : value;
  if (isNaN(num)) return "0.00%";
  return `${num >= 0 ? "+" : ""}${num.toFixed(2)}%`;
}

function InfoTip({ text }: { text: string }) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Info className="w-3.5 h-3.5 text-muted-foreground inline-block ml-1 cursor-help" />
      </TooltipTrigger>
      <TooltipContent side="top" className="max-w-xs text-xs">
        {text}
      </TooltipContent>
    </Tooltip>
  );
}

function LoadingSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <GlassCard key={i}>
            <Skeleton className="h-4 w-24 mb-3" />
            <Skeleton className="h-8 w-32" />
          </GlassCard>
        ))}
      </div>
      <GlassCard>
        <Skeleton className="h-6 w-32 mb-4" />
        <Skeleton className="h-20 w-full" />
      </GlassCard>
    </div>
  );
}

function EmptyState() {
  return (
    <GlassCard>
      <div className="text-center py-8">
        <PieChart className="w-10 h-10 mx-auto text-muted-foreground mb-3" />
        <p className="text-sm font-medium text-muted-foreground">
          No investment data available yet
        </p>
        <p className="text-xs text-muted-foreground mt-1">
          Start investing in tokenized assets to see your returns here
        </p>
      </div>
    </GlassCard>
  );
}

export default function InvestorReturns() {
  const { data, isLoading, error } = useQuery<AnalyticsData>({
    queryKey: ["/api/investor/analytics"],
  });

  if (isLoading) {
    return (
      <RoleLayout role="investor">
        <div className="space-y-6">
          <div className="flex items-center gap-3">
            <Link href="/investor/dashboard">
              <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <PageTitle
            title="Returns & Analytics"
            description="Track your investment performance, yields, and distributions"
          />
          </div>
          <LoadingSkeleton />
        </div>
      </RoleLayout>
    );
  }

  if (error) {
    return (
      <RoleLayout role="investor">
        <div className="space-y-6">
          <PageTitle
            title="Returns & Analytics"
            description="Track your investment performance, yields, and distributions"
          />
          <GlassCard>
            <p className="text-sm text-destructive" data-testid="text-error">
              Failed to load analytics data. Please try again later.
            </p>
          </GlassCard>
        </div>
      </RoleLayout>
    );
  }

  const o = data?.overview;
  const hasHoldings = (o?.holdingsCount ?? 0) > 0;
  const totalInvested = parseFloat(o?.totalInvested || "0");
  const currentValue = parseFloat(o?.currentPortfolioValue || "0");
  const unrealizedGain = parseFloat(o?.unrealizedGain || "0");
  const roiPercent = parseFloat(o?.roiPercent || "0");
  const rentalYield = parseFloat(o?.rentalYieldPercent || "0");
  const totalDistributions = parseFloat(o?.totalDistributionsReceived || "0");
  const totalFees = parseFloat(o?.totalFees || "0");

  return (
    <RoleLayout role="investor">
      <div className="space-y-6">
        <PageTitle
          title="Returns & Analytics"
          description="Track your investment performance, yields, and distributions"
        />

        {!hasHoldings && !totalDistributions ? (
          <EmptyState />
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <StatTile
                label="Total Invested"
                value={formatCurrency(totalInvested)}
                trend="neutral"
                icon={<DollarSign className="w-5 h-5" />}
              />
              <StatTile
                label="Portfolio Value"
                value={formatCurrency(currentValue)}
                change={formatPercent(roiPercent)}
                trend={currentValue >= totalInvested ? "up" : "down"}
                icon={<PieChart className="w-5 h-5" />}
              />
              <StatTile
                label="Distributions Received"
                value={formatCurrency(totalDistributions)}
                trend={totalDistributions > 0 ? "up" : "neutral"}
                icon={<Banknote className="w-5 h-5" />}
              />
              <StatTile
                label="ROI"
                value={formatPercent(roiPercent)}
                change={`${formatCurrency(unrealizedGain)} unrealized`}
                trend={roiPercent >= 0 ? "up" : "down"}
                icon={<TrendingUp className="w-5 h-5" />}
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <GlassCard>
                <div className="flex items-center gap-2 mb-3">
                  <Percent className="w-4 h-4 text-primary" />
                  <span className="text-sm font-semibold">
                    Rental Yield
                    <InfoTip text="Total distributions received divided by total amount invested. This is your income-based return." />
                  </span>
                </div>
                <p
                  className="text-3xl font-bold tracking-tight"
                  data-testid="text-rental-yield"
                >
                  {rentalYield.toFixed(2)}%
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Based on distributions received
                </p>
              </GlassCard>

              <GlassCard>
                <div className="flex items-center gap-2 mb-3">
                  <BarChart3 className="w-4 h-4 text-primary" />
                  <span className="text-sm font-semibold">
                    Total Return
                    <InfoTip text="Distributions received plus unrealized gains on your holdings, as a total monetary value." />
                  </span>
                </div>
                <p
                  className="text-3xl font-bold tracking-tight"
                  data-testid="text-total-return"
                >
                  {formatCurrency(o?.totalReturn || "0")}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Income + unrealized gains
                </p>
              </GlassCard>

              <GlassCard>
                <div className="flex items-center gap-2 mb-3">
                  <Receipt className="w-4 h-4 text-primary" />
                  <span className="text-sm font-semibold">
                    Total Fees
                    <InfoTip text="Sum of all fee charges across your transactions." />
                  </span>
                </div>
                <p
                  className="text-3xl font-bold tracking-tight"
                  data-testid="text-total-fees"
                >
                  {formatCurrency(totalFees)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Cumulative fee charges
                </p>
              </GlassCard>
            </div>

            {data && data.holdings.length > 0 && (
              <Section title="Holdings Value Breakdown">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {data.holdings.map((h, i) => {
                    const gain = parseFloat(h.unrealizedGain);
                    const gainPct = parseFloat(h.unrealizedGainPercent);
                    const isPositive = gain >= 0;
                    return (
                      <GlassCard key={h.tokenId}>
                        <div className="flex items-start justify-between gap-3 mb-3">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-md gradient-hero flex items-center justify-center flex-shrink-0">
                              <span className="text-white font-bold text-sm">
                                {h.assetSymbol.slice(0, 2)}
                              </span>
                            </div>
                            <div>
                              <p
                                className="font-semibold text-sm"
                                data-testid={`text-holding-name-${i}`}
                              >
                                {h.assetName}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {parseFloat(h.balance).toLocaleString()} tokens
                                {h.location && ` · ${h.location}`}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <div
                              className={`flex items-center gap-1 text-xs font-semibold ${isPositive ? "text-emerald-600 dark:text-emerald-400" : "text-red-500 dark:text-red-400"}`}
                            >
                              {isPositive ? (
                                <ArrowUpRight className="w-3 h-3" />
                              ) : (
                                <ArrowDownRight className="w-3 h-3" />
                              )}
                              <span data-testid={`text-holding-gain-${i}`}>
                                {formatPercent(gainPct)}
                              </span>
                            </div>
                            {h.annualYield && (
                              <Badge
                                variant="secondary"
                                className="text-[10px] mt-1"
                              >
                                {parseFloat(h.annualYield).toFixed(1)}% yield
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="grid grid-cols-3 gap-2 text-sm">
                          <div>
                            <p className="text-xs text-muted-foreground">
                              Cost Basis
                            </p>
                            <p className="font-medium">
                              {formatCurrency(h.costBasis)}
                            </p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">
                              Current Value
                            </p>
                            <p className="font-semibold">
                              {formatCurrency(h.currentValue)}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-xs text-muted-foreground">
                              Gain/Loss
                            </p>
                            <p
                              className={`font-semibold ${isPositive ? "text-emerald-600 dark:text-emerald-400" : "text-red-500 dark:text-red-400"}`}
                            >
                              {formatCurrency(h.unrealizedGain)}{" "}
                              {h.baseCurrency}
                            </p>
                          </div>
                        </div>
                      </GlassCard>
                    );
                  })}
                </div>
              </Section>
            )}

            {data && data.payoutHistory.length > 0 && (
              <Section title="Payout History">
                <GlassCard>
                  <div className="space-y-0">
                    <div className="grid grid-cols-5 gap-3 text-xs font-medium text-muted-foreground pb-2 border-b">
                      <span>Asset</span>
                      <span>Date</span>
                      <span className="text-right">Tokens Held</span>
                      <span className="text-right">Share</span>
                      <span className="text-right">Payout</span>
                    </div>
                    {data.payoutHistory.map((p, i) => (
                      <div
                        key={p.id}
                        className="grid grid-cols-5 gap-3 py-2.5 border-b border-border/30 last:border-0 text-sm items-center"
                        data-testid={`row-payout-${i}`}
                      >
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-md gradient-hero flex items-center justify-center flex-shrink-0">
                            <span className="text-white text-[10px] font-bold">
                              {p.assetSymbol.slice(0, 2)}
                            </span>
                          </div>
                          <span className="font-medium truncate">
                            {p.assetName}
                          </span>
                        </div>
                        <span className="text-muted-foreground text-xs">
                          {p.date
                            ? new Date(p.date).toLocaleDateString()
                            : "-"}
                        </span>
                        <span className="text-right">
                          {parseFloat(p.holdingBalance).toLocaleString()}
                        </span>
                        <span className="text-right">
                          {parseFloat(p.holdingPercent).toFixed(2)}%
                        </span>
                        <div className="text-right">
                          <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                            {formatCurrency(p.payoutAmount, p.payoutCurrency)}
                          </span>
                          {p.autoConverted && p.convertedAmount && (
                            <p className="text-[10px] text-muted-foreground">
                              Converted to{" "}
                              {formatCurrency(
                                p.convertedAmount,
                                p.convertedCurrency || "",
                              )}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </GlassCard>
              </Section>
            )}

            {data && data.monthlyPayouts.length > 0 && (
              <Section title="Monthly Distribution Trend">
                <GlassCard>
                  <div className="flex items-end gap-1.5 h-32">
                    {data.monthlyPayouts.map((m, i) => {
                      const maxAmount = Math.max(
                        ...data.monthlyPayouts.map((mp) =>
                          parseFloat(mp.amount),
                        ),
                      );
                      const height =
                        maxAmount > 0
                          ? (parseFloat(m.amount) / maxAmount) * 100
                          : 0;
                      return (
                        <Tooltip key={m.month}>
                          <TooltipTrigger asChild>
                            <div className="flex-1 flex flex-col items-center gap-1">
                              <div
                                className="w-full bg-primary/20 rounded-sm relative overflow-visible"
                                style={{ height: `${Math.max(height, 4)}%` }}
                              >
                                <div
                                  className="absolute bottom-0 left-0 right-0 bg-primary rounded-sm"
                                  style={{ height: "100%" }}
                                />
                              </div>
                              <span className="text-[9px] text-muted-foreground">
                                {m.month.slice(5)}
                              </span>
                            </div>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="text-xs">
                              {m.month}: {formatCurrency(m.amount)}
                            </p>
                          </TooltipContent>
                        </Tooltip>
                      );
                    })}
                  </div>
                </GlassCard>
              </Section>
            )}

            {data && data.feeSummary.length > 0 && (
              <Section title="Fee Summary">
                <GlassCard>
                  <div className="space-y-0">
                    <div className="grid grid-cols-3 gap-3 text-xs font-medium text-muted-foreground pb-2 border-b">
                      <span>Description</span>
                      <span>Date</span>
                      <span className="text-right">Amount</span>
                    </div>
                    {data.feeSummary.map((f, i) => (
                      <div
                        key={f.id}
                        className="grid grid-cols-3 gap-3 py-2.5 border-b border-border/30 last:border-0 text-sm items-center"
                        data-testid={`row-fee-${i}`}
                      >
                        <span className="font-medium truncate">
                          {f.description || "Fee charge"}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {f.date
                            ? new Date(f.date).toLocaleDateString()
                            : "-"}
                        </span>
                        <span className="text-right font-medium text-red-500 dark:text-red-400">
                          -{formatCurrency(f.amount, f.currency)}
                        </span>
                      </div>
                    ))}
                  </div>
                </GlassCard>
              </Section>
            )}

            {data && data.walletBalances.length > 0 && (
              <Section title="Wallet Balances">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {data.walletBalances.map((w) => (
                    <GlassCard key={w.id}>
                      <div className="flex items-center gap-2 mb-2">
                        <Wallet className="w-4 h-4 text-primary" />
                        <span className="text-sm font-semibold">
                          {w.currency}
                        </span>
                      </div>
                      <p
                        className="text-xl font-bold"
                        data-testid={`text-wallet-balance-${w.currency}`}
                      >
                        {formatCurrency(w.available)}
                      </p>
                      {parseFloat(w.pending) > 0 && (
                        <p className="text-xs text-muted-foreground mt-1">
                          {formatCurrency(w.pending)} pending
                        </p>
                      )}
                    </GlassCard>
                  ))}
                </div>
              </Section>
            )}
          </>
        )}
      </div>
    </RoleLayout>
  );
}
