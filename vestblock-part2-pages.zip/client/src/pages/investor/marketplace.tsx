import { useState, useMemo, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { GlassCard } from "@/components/glass-card";
import { GlassButton } from "@/components/glass-button";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { LegalAcceptanceModal, useLegalAcceptance } from "@/components/legal-acceptance-modal";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Search,
  ShieldAlert,
  FileText,
  ArrowRightLeft,
  AlertTriangle,
  CheckCircle2,
  Coins,
  Globe,
  TrendingUp,
  MapPin,
  Building2,
  Shield,
  ArrowUpDown,
  SlidersHorizontal,
  Eye,
  Home,
  BarChart3, ArrowLeft,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import { formatCurrency } from "@/lib/format";
import { CURRENCY_DETAILS, CURRENCY_TO_COUNTRY, COUNTRY_DETAILS } from "@shared/constants";
import { DEFAULT_CURRENCY } from "@/lib/currencies";
import { Link, useLocation } from "wouter";
import { WhatsAppShareIcon } from "@/components/whatsapp-share";

interface MarketplaceCountry {
  id: string | null;
  countryCode: string;
  name: string;
  isVisible: boolean;
  displayOrder: number;
}

interface AssetData {
  id: string;
  name: string;
  symbol: string;
  assetType: string;
  description: string | null;
  totalSupply: string;
  pricePerToken: string;
  baseCurrency: string;
  country: string;
  status: string;
  issuerId: string;
  imageUrl: string | null;
  propertyType: string | null;
  location: string | null;
  annualYield: string | null;
  occupancyRate: string | null;
  totalPropertyValue: string | null;
  managementFee: string | null;
  distributionFrequency: string | null;
  minInvestment: string | null;
  riskRating: string | null;
  constructionStatus: string | null;
  navPerToken: string | null;
  irr: string | null;
  issuerName: string | null;
  propertyClass: string | null;
}

interface RoundData {
  id: string;
  assetId: string;
  name: string;
  targetAmount: string;
  raisedAmount: string;
  status: string;
  startDate: string;
  endDate: string | null;
}

interface InvestCheckResponse {
  baseCurrency: string;
  availableBalance: number;
  hasWallet: boolean;
  pricePerToken: number;
  otherBalances: { currency: string; available: number }[];
}

interface EddStatusResponse {
  eddStatus: string;
  isBlocked: boolean;
  activeFlagCount: number;
}

type SortOption = "name" | "yield-high" | "yield-low" | "price-high" | "price-low" | "risk";

function riskColor(risk: string | null) {
  if (!risk) return "outline" as const;
  const r = risk.toLowerCase();
  if (r === "low" || r === "medium-low") return "default" as const;
  if (r === "medium") return "secondary" as const;
  return "destructive" as const;
}

export default function InvestorMarketplace() {
  const { toast } = useToast();
  const { defaultCurrency, primaryCountry } = useAuth();
  const [, setLocation] = useLocation();
  const [showLegalModal, setShowLegalModal] = useState(false);
  const [legalContext, setLegalContext] = useState<{ country?: string; vehicleType?: string }>({});
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedAsset, setSelectedAsset] = useState<AssetData | null>(null);
  const [investQuantity, setInvestQuantity] = useState("");
  const [showInvestModal, setShowInvestModal] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [filterPropertyType, setFilterPropertyType] = useState<string>("all");
  const [filterRiskRating, setFilterRiskRating] = useState<string>("all");
  const [filterYieldMin, setFilterYieldMin] = useState<string>("");
  const [sortBy, setSortBy] = useState<SortOption>("name");

  const { data: marketplaceCountries, isLoading: countriesLoading } = useQuery<MarketplaceCountry[]>({
    queryKey: ["/api/marketplace/countries"],
  });

  useEffect(() => {
    if (marketplaceCountries && marketplaceCountries.length > 0 && selectedCountry === null) {
      const userCountry = primaryCountry || (defaultCurrency ? CURRENCY_TO_COUNTRY[defaultCurrency as keyof typeof CURRENCY_TO_COUNTRY] : null);
      const match = marketplaceCountries.find(c => c.countryCode === userCountry);
      setSelectedCountry(match ? match.countryCode : "ALL");
    }
  }, [marketplaceCountries, primaryCountry, defaultCurrency, selectedCountry]);

  const { data: eddData } = useQuery<EddStatusResponse>({
    queryKey: ["/api/edd-status"],
  });

  const { data: assetsData, isLoading: assetsLoading } = useQuery<AssetData[]>({
    queryKey: ["/api/marketplace/assets", selectedCountry],
    queryFn: async () => {
      const url = selectedCountry && selectedCountry !== "ALL"
        ? `/api/marketplace/assets?country=${selectedCountry}`
        : "/api/marketplace/assets";
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch assets");
      return res.json();
    },
    enabled: !!selectedCountry,
  });

  const { data: roundsData } = useQuery<RoundData[]>({
    queryKey: ["/api/rounds"],
  });

  const { data: investCheck, isLoading: checkLoading } = useQuery<InvestCheckResponse>({
    queryKey: [`/api/invest/check/${selectedAsset?.id}`],
    enabled: !!selectedAsset && showInvestModal,
  });

  const investMutation = useMutation({
    mutationFn: async (data: { assetId: string; roundId: string; quantity: number }) => {
      const csrf = document.cookie.match(/(?:^|;\s*)csrf-token=([^;]*)/)?.[1];
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (csrf) headers["x-csrf-token"] = decodeURIComponent(csrf);
      const res = await fetch("/api/invest", {
        method: "POST",
        headers,
        body: JSON.stringify(data),
        credentials: "include",
      });
      const body = await res.json();
      if (!res.ok) {
        const err: any = new Error(body.message || "Investment failed");
        err.code = body.code;
        err.details = body.details;
        throw err;
      }
      return body;
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["/api/wallet/accounts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/wallet/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/rounds"] });
      queryClient.invalidateQueries({ queryKey: ["/api/assets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/marketplace/assets"] });
      queryClient.invalidateQueries({ queryKey: [`/api/invest/check/${selectedAsset?.id}`] });
      setShowInvestModal(false);
      setInvestQuantity("");
      setSelectedAsset(null);
      toast({
        title: "Investment Successful",
        description: `You invested ${formatCurrency(result.investment.totalCost, result.investment.currency)} in ${result.investment.assetName} (${result.investment.quantity} tokens)`,
      });
    },
    onError: (err: any) => {
      if (err.code === "LEGAL_NOT_ACCEPTED" && err.details) {
        setLegalContext({
          country: err.details.country,
          vehicleType: err.details.vehicleType,
        });
        setShowLegalModal(true);
        return;
      }
      toast({
        title: "Investment Failed",
        description: err.message || "Could not process investment",
        variant: "destructive",
      });
    },
  });

  const { allAccepted, pendingCount } = useLegalAcceptance();
  const isEddBlocked = eddData?.isBlocked ?? false;
  const isLegalBlocked = !allAccepted && pendingCount > 0;
  const isBlocked = isEddBlocked || isLegalBlocked;

  const roundsByAsset = useMemo(() => {
    const map: Record<string, RoundData[]> = {};
    if (roundsData) {
      for (const r of roundsData) {
        if (!map[r.assetId]) map[r.assetId] = [];
        map[r.assetId].push(r);
      }
    }
    return map;
  }, [roundsData]);

  const propertyTypes = useMemo(() => {
    if (!assetsData) return [];
    const types = new Set<string>();
    assetsData.forEach(a => { if (a.assetType) types.add(a.assetType); });
    return Array.from(types).sort();
  }, [assetsData]);

  const filteredAssets = useMemo(() => {
    if (!assetsData) return [];
    let result = [...assetsData];

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(a =>
        a.name.toLowerCase().includes(q) ||
        a.symbol.toLowerCase().includes(q) ||
        a.assetType.toLowerCase().includes(q) ||
        (a.location && a.location.toLowerCase().includes(q)) ||
        (a.propertyType && a.propertyType.toLowerCase().includes(q))
      );
    }

    if (filterPropertyType !== "all") {
      result = result.filter(a => a.assetType === filterPropertyType);
    }

    if (filterRiskRating !== "all") {
      result = result.filter(a => a.riskRating === filterRiskRating);
    }

    if (filterYieldMin) {
      const minYield = parseFloat(filterYieldMin);
      if (!isNaN(minYield)) {
        result = result.filter(a => a.annualYield && parseFloat(a.annualYield) >= minYield);
      }
    }

    switch (sortBy) {
      case "yield-high":
        result.sort((a, b) => (parseFloat(b.annualYield || "0") - parseFloat(a.annualYield || "0")));
        break;
      case "yield-low":
        result.sort((a, b) => (parseFloat(a.annualYield || "0") - parseFloat(b.annualYield || "0")));
        break;
      case "price-high":
        result.sort((a, b) => (parseFloat(b.pricePerToken) - parseFloat(a.pricePerToken)));
        break;
      case "price-low":
        result.sort((a, b) => (parseFloat(a.pricePerToken) - parseFloat(b.pricePerToken)));
        break;
      case "risk":
        const riskOrder: Record<string, number> = { "Low": 1, "Medium-Low": 2, "Medium": 3, "Medium-High": 4, "High": 5 };
        result.sort((a, b) => (riskOrder[a.riskRating || ""] || 6) - (riskOrder[b.riskRating || ""] || 6));
        break;
      default:
        result.sort((a, b) => a.name.localeCompare(b.name));
    }

    return result;
  }, [assetsData, searchQuery, filterPropertyType, filterRiskRating, filterYieldMin, sortBy]);

  const handleInvestClick = (asset: AssetData) => {
    if (isLegalBlocked) {
      setShowLegalModal(true);
      return;
    }
    setSelectedAsset(asset);
    setInvestQuantity("");
    setShowInvestModal(true);
  };

  const qty = parseFloat(investQuantity) || 0;
  const pricePerToken = selectedAsset ? parseFloat(selectedAsset.pricePerToken) : 0;
  const totalCost = qty * pricePerToken;
  const baseCurrency = selectedAsset?.baseCurrency || DEFAULT_CURRENCY;
  const userCurrency = defaultCurrency || DEFAULT_CURRENCY;
  const needsFxConvert = baseCurrency !== userCurrency;
  const hasEnoughBalance = investCheck ? investCheck.availableBalance >= totalCost : false;
  const shortfall = investCheck ? Math.max(0, totalCost - investCheck.availableBalance) : 0;

  const openRound = selectedAsset
    ? (roundsByAsset[selectedAsset.id] || []).find((r) => r.status === "open")
    : null;

  const handleConfirmInvest = () => {
    if (!selectedAsset || !openRound || qty <= 0) return;
    investMutation.mutate({
      assetId: selectedAsset.id,
      roundId: openRound.id,
      quantity: qty,
    });
  };

  const activeFilterCount = [
    filterPropertyType !== "all",
    filterRiskRating !== "all",
    !!filterYieldMin,
  ].filter(Boolean).length;

  return (
    <RoleLayout role="investor">
      <div className="space-y-6">
        {isEddBlocked && (
          <GlassCard className="bg-destructive/5 border-destructive/20" data-testid="edd-block-banner">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-md bg-destructive/10 flex items-center justify-center flex-shrink-0">
                <ShieldAlert className="w-5 h-5 text-destructive" />
              </div>
              <div>
                <p className="font-semibold text-sm" data-testid="edd-block-title">Investment Actions Restricted</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Your account is under enhanced due diligence (EDD) review. You cannot invest in new assets until the review is complete.
                </p>
              </div>
            </div>
          </GlassCard>
        )}

        {isLegalBlocked && !isEddBlocked && (
          <GlassCard className="bg-amber-500/5 border-amber-500/20" data-testid="legal-block-banner">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-md bg-amber-500/10 flex items-center justify-center flex-shrink-0">
                <FileText className="w-5 h-5 text-amber-600 dark:text-amber-400" />
              </div>
              <div>
                <p className="font-semibold text-sm" data-testid="legal-block-title">Legal Agreements Required</p>
                <p className="text-sm text-muted-foreground mt-1">
                  You must accept our latest legal documents before investing. {pendingCount} document(s) require your acceptance.
                </p>
                <GlassButton
                  variant="primary"
                  className="mt-3"
                  onClick={() => setShowLegalModal(true)}
                  data-testid="button-review-legal-marketplace"
                >
                  Review & Accept Documents
                </GlassButton>
              </div>
            </div>
          </GlassCard>
        )}

        <div className="flex items-center gap-3">
          <Link href="/investor/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle title="Marketplace" description="Discover and invest in tokenized real estate, REITs, and infrastructure assets across global markets" />
        </div>

        {countriesLoading ? (
          <div className="flex gap-2">
            {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-9 w-28 rounded-md" />)}
          </div>
        ) : marketplaceCountries && marketplaceCountries.length > 0 ? (
          <div className="flex items-center gap-2 flex-wrap" data-testid="country-tabs">
            <Button
              variant={selectedCountry === "ALL" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCountry("ALL")}
              data-testid="country-tab-ALL"
              className="gap-1.5"
            >
              <Globe className="w-3.5 h-3.5" />
              All Markets
            </Button>
            {marketplaceCountries.map(c => (
              <Button
                key={c.countryCode}
                variant={selectedCountry === c.countryCode ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCountry(c.countryCode)}
                data-testid={`country-tab-${c.countryCode}`}
                className="gap-1.5"
              >
                <Globe className="w-3.5 h-3.5" />
                {c.name}
              </Button>
            ))}
          </div>
        ) : null}

        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by name, type, location..."
              className="pl-9"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              data-testid="input-search-marketplace"
            />
          </div>
          <Button
            variant={showFilters ? "default" : "outline"}
            size="sm"
            onClick={() => setShowFilters(!showFilters)}
            data-testid="button-toggle-filters"
            className="gap-1.5"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            Filters
            {activeFilterCount > 0 && (
              <Badge variant="secondary" className="ml-1 text-xs">{activeFilterCount}</Badge>
            )}
          </Button>
          <Select value={sortBy} onValueChange={(v) => setSortBy(v as SortOption)}>
            <SelectTrigger className="w-[180px]" data-testid="select-sort">
              <ArrowUpDown className="w-3.5 h-3.5 mr-1.5" />
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="name">Name (A-Z)</SelectItem>
              <SelectItem value="yield-high">Yield (High to Low)</SelectItem>
              <SelectItem value="yield-low">Yield (Low to High)</SelectItem>
              <SelectItem value="price-high">Price (High to Low)</SelectItem>
              <SelectItem value="price-low">Price (Low to High)</SelectItem>
              <SelectItem value="risk">Risk (Low to High)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {showFilters && (
          <div className="flex items-end gap-4 flex-wrap border rounded-md p-4 bg-muted/30" data-testid="filter-panel">
            <div className="space-y-1.5 min-w-[160px]">
              <Label className="text-xs">Asset Type</Label>
              <Select value={filterPropertyType} onValueChange={setFilterPropertyType}>
                <SelectTrigger data-testid="filter-property-type">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  {propertyTypes.map(t => (
                    <SelectItem key={t} value={t}>{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5 min-w-[160px]">
              <Label className="text-xs">Risk Rating</Label>
              <Select value={filterRiskRating} onValueChange={setFilterRiskRating}>
                <SelectTrigger data-testid="filter-risk-rating">
                  <SelectValue placeholder="All Ratings" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Ratings</SelectItem>
                  <SelectItem value="Low">Low</SelectItem>
                  <SelectItem value="Medium-Low">Medium-Low</SelectItem>
                  <SelectItem value="Medium">Medium</SelectItem>
                  <SelectItem value="Medium-High">Medium-High</SelectItem>
                  <SelectItem value="High">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5 min-w-[140px]">
              <Label className="text-xs">Min Yield (%)</Label>
              <Input
                type="number"
                placeholder="e.g. 6"
                value={filterYieldMin}
                onChange={(e) => setFilterYieldMin(e.target.value)}
                data-testid="filter-yield-min"
              />
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => { setFilterPropertyType("all"); setFilterRiskRating("all"); setFilterYieldMin(""); }}
              data-testid="button-clear-filters"
            >
              Clear Filters
            </Button>
          </div>
        )}

        <div className="flex items-center justify-between gap-2 text-sm text-muted-foreground">
          <span data-testid="text-results-count">{filteredAssets.length} asset{filteredAssets.length !== 1 ? "s" : ""} found</span>
        </div>

        {assetsLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[...Array(6)].map((_, i) => (
              <Skeleton key={i} className="h-72 rounded-md" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredAssets.map((asset) => {
              const assetRounds = roundsByAsset[asset.id] || [];
              const openRnd = assetRounds.find((r) => r.status === "open");
              const closingRnd = assetRounds.find((r) => r.status === "closing");
              const activeRound = openRnd || closingRnd;
              const raised = activeRound
                ? parseFloat(activeRound.raisedAmount) / parseFloat(activeRound.targetAmount)
                : 0;
              const raisedPct = Math.min(100, Math.round(raised * 100));
              const currencyDetail = CURRENCY_DETAILS[asset.baseCurrency as keyof typeof CURRENCY_DETAILS];
              const currencySymbol = currencyDetail?.symbol || asset.baseCurrency;
              const roundStatus = openRnd ? "Open" : closingRnd ? "Closing Soon" : "Closed";

              return (
                <GlassCard key={asset.id} data-testid={`asset-card-${asset.id}`}>
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-10 h-10 rounded-md gradient-hero flex items-center justify-center flex-shrink-0">
                          <span className="text-white font-bold">{asset.name[0]}</span>
                        </div>
                        <div className="min-w-0">
                          <p className="font-semibold text-sm truncate" data-testid={`asset-name-${asset.id}`}>{asset.name}</p>
                          <p className="text-xs text-muted-foreground truncate">
                            {asset.symbol} - {asset.assetType}
                          </p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-1 flex-shrink-0">
                        <Badge
                          variant={roundStatus === "Open" ? "default" : roundStatus === "Closing Soon" ? "secondary" : "outline"}
                          className="text-xs"
                          data-testid={`asset-status-${asset.id}`}
                        >
                          {roundStatus}
                        </Badge>
                        {asset.riskRating && (
                          <Badge variant={riskColor(asset.riskRating)} className="text-xs" data-testid={`asset-risk-${asset.id}`}>
                            {asset.riskRating}
                          </Badge>
                        )}
                      </div>
                    </div>

                    {asset.location && (
                      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <MapPin className="w-3 h-3 flex-shrink-0" />
                        <span className="truncate" data-testid={`asset-location-${asset.id}`}>{asset.location}</span>
                      </div>
                    )}

                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div>
                        <p className="text-xs text-muted-foreground">Price/Token</p>
                        <p className="text-sm font-semibold" data-testid={`asset-price-${asset.id}`}>
                          {formatCurrency(asset.pricePerToken, asset.baseCurrency)}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Yield</p>
                        <p className="text-sm font-semibold text-emerald-600 dark:text-emerald-400" data-testid={`asset-yield-${asset.id}`}>
                          {asset.annualYield ? `${parseFloat(asset.annualYield).toFixed(1)}%` : "N/A"}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Occupancy</p>
                        <p className="text-sm font-semibold" data-testid={`asset-occupancy-${asset.id}`}>
                          {asset.occupancyRate ? `${parseFloat(asset.occupancyRate).toFixed(0)}%` : "N/A"}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-center">
                      <div>
                        <p className="text-xs text-muted-foreground">Currency</p>
                        <Badge variant="outline" className="text-xs no-default-hover-elevate" data-testid={`asset-currency-${asset.id}`}>{asset.baseCurrency}</Badge>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Raised</p>
                        <p className="text-sm font-semibold" data-testid={`asset-raised-${asset.id}`}>{raisedPct}%</p>
                      </div>
                    </div>

                    <div className="w-full bg-muted rounded-sm h-1.5">
                      <div
                        className="gradient-hero h-1.5 rounded-sm transition-all"
                        style={{ width: `${raisedPct}%` }}
                      />
                    </div>

                    {asset.distributionFrequency && (
                      <p className="text-xs text-muted-foreground text-center">
                        {asset.distributionFrequency} distributions
                      </p>
                    )}

                    <div className="flex gap-2 items-center">
                      <Link href={`/investor/marketplace/${asset.id}`} className="flex-1">
                        <Button variant="outline" className="w-full gap-1.5" data-testid={`button-view-${asset.id}`}>
                          <Eye className="w-3.5 h-3.5" />
                          View Details
                        </Button>
                      </Link>
                      <GlassButton
                        variant="primary"
                        className="flex-1"
                        disabled={isBlocked || roundStatus === "Closed"}
                        onClick={() => handleInvestClick(asset)}
                        data-testid={`button-invest-${asset.id}`}
                      >
                        {isEddBlocked
                          ? "Restricted"
                          : isLegalBlocked
                          ? "Accept Terms"
                          : roundStatus === "Closed"
                          ? "Closed"
                          : "Invest"}
                      </GlassButton>
                      <WhatsAppShareIcon
                        assetName={asset.name}
                        assetSymbol={asset.symbol}
                        pricePerToken={asset.pricePerToken}
                        baseCurrency={asset.baseCurrency}
                        annualYield={asset.annualYield}
                        assetType={asset.assetType}
                        location={asset.location}
                        assetId={asset.id}
                      />
                    </div>
                  </div>
                </GlassCard>
              );
            })}
          </div>
        )}

        {!assetsLoading && filteredAssets.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <Building2 className="w-10 h-10 mx-auto mb-3 opacity-50" />
            <p className="text-sm">No assets found matching your criteria.</p>
            {activeFilterCount > 0 && (
              <Button
                variant="ghost"
                size="sm"
                className="mt-2"
                onClick={() => { setFilterPropertyType("all"); setFilterRiskRating("all"); setFilterYieldMin(""); setSearchQuery(""); }}
                data-testid="button-reset-all"
              >
                Clear all filters
              </Button>
            )}
          </div>
        )}
      </div>

      <Dialog open={showInvestModal} onOpenChange={(open) => { if (!open) { setShowInvestModal(false); setSelectedAsset(null); } }}>
        <DialogContent className="sm:max-w-md" data-testid="invest-modal">
          <DialogHeader>
            <DialogTitle data-testid="invest-modal-title">
              Invest in {selectedAsset?.name}
            </DialogTitle>
            <DialogDescription>
              {selectedAsset?.symbol} - {selectedAsset?.assetType}
            </DialogDescription>
          </DialogHeader>

          {checkLoading ? (
            <div className="space-y-3">
              <Skeleton className="h-10 rounded-md" />
              <Skeleton className="h-20 rounded-md" />
            </div>
          ) : investCheck && selectedAsset ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-2 text-sm">
                <span className="text-muted-foreground">Price per token</span>
                <span className="font-semibold" data-testid="invest-price-per-token">
                  {formatCurrency(pricePerToken, baseCurrency)}
                </span>
              </div>

              <div className="flex items-center justify-between gap-2 text-sm">
                <span className="text-muted-foreground">Your {baseCurrency} balance</span>
                <span className={`font-semibold ${investCheck.availableBalance <= 0 ? "text-destructive" : ""}`} data-testid="invest-available-balance">
                  {formatCurrency(Math.max(0, investCheck.availableBalance), baseCurrency)}
                </span>
              </div>

              {needsFxConvert && (
                <div className="rounded-md border border-amber-500/30 bg-amber-500/5 p-3" data-testid="fx-convert-notice">
                  <div className="flex items-start gap-2">
                    <ArrowRightLeft className="w-4 h-4 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-amber-700 dark:text-amber-300" data-testid="fx-convert-message">
                        This asset requires {baseCurrency} to invest
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Your default currency is {userCurrency}. Convert funds to {baseCurrency} in your wallet before investing.
                      </p>
                      {investCheck.otherBalances.length > 0 && (
                        <div className="mt-2 space-y-1">
                          <p className="text-xs text-muted-foreground font-medium">Your other balances:</p>
                          {investCheck.otherBalances.map((b) => (
                            <p key={b.currency} className="text-xs" data-testid={`other-balance-${b.currency}`}>
                              {formatCurrency(b.available, b.currency)}
                            </p>
                          ))}
                        </div>
                      )}
                      <Link href="/investor/wallet">
                        <Button variant="outline" size="sm" className="mt-2" data-testid="button-go-to-wallet">
                          <ArrowRightLeft className="w-3.5 h-3.5 mr-1" />
                          Go to Wallet to Convert
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="invest-qty">Number of tokens</Label>
                <Input
                  id="invest-qty"
                  type="number"
                  min="1"
                  step="1"
                  placeholder="Enter quantity"
                  value={investQuantity}
                  onChange={(e) => setInvestQuantity(e.target.value)}
                  data-testid="input-invest-quantity"
                />
              </div>

              {qty > 0 && (
                <div className="rounded-md border p-3 space-y-2">
                  <div className="flex items-center justify-between gap-2 text-sm">
                    <span className="text-muted-foreground">Total cost</span>
                    <span className="font-bold" data-testid="invest-total-cost">
                      {formatCurrency(totalCost, baseCurrency)}
                    </span>
                  </div>
                  {!hasEnoughBalance && totalCost > 0 && (
                    <div className="flex items-start gap-2 text-sm" data-testid="invest-shortfall-warning">
                      <AlertTriangle className="w-4 h-4 text-destructive mt-0.5 flex-shrink-0" />
                      <span className="text-destructive">
                        You need {formatCurrency(shortfall, baseCurrency)} more in {baseCurrency}.
                        {investCheck.otherBalances.length > 0
                          ? " Convert from another currency in your wallet first."
                          : " Add funds to your wallet first."}
                      </span>
                    </div>
                  )}
                  {hasEnoughBalance && totalCost > 0 && (
                    <div className="flex items-center gap-2 text-sm text-emerald-600 dark:text-emerald-400" data-testid="invest-balance-ok">
                      <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                      <span>Sufficient balance available</span>
                    </div>
                  )}
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => { setShowInvestModal(false); setSelectedAsset(null); }}
                  data-testid="button-cancel-invest"
                >
                  Cancel
                </Button>
                <GlassButton
                  variant="primary"
                  className="flex-1"
                  disabled={
                    qty <= 0 ||
                    !hasEnoughBalance ||
                    !openRound ||
                    investMutation.isPending
                  }
                  onClick={handleConfirmInvest}
                  data-testid="button-confirm-invest"
                >
                  {investMutation.isPending ? "Processing..." : "Confirm Investment"}
                </GlassButton>
              </div>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>

      <LegalAcceptanceModal
        open={showLegalModal}
        onClose={() => { setShowLegalModal(false); setLegalContext({}); }}
        onAccepted={() => { setShowLegalModal(false); setLegalContext({}); }}
        country={legalContext.country}
        vehicleType={legalContext.vehicleType}
      />
    </RoleLayout>
  );
}
