import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileSpreadsheet, Download, Building2, Banknote, TrendingUp, AlertTriangle, ArrowLeft,
} from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
async function downloadCsv(endpoint: string, fallbackFilename: string) {
  const resp = await fetch(endpoint, { credentials: "include" });
  if (!resp.ok) {
    throw new Error(`Export failed (${resp.status})`);
  }
  const blob = await resp.blob();
  const disposition = resp.headers.get("Content-Disposition");
  let filename = fallbackFilename;
  if (disposition) {
    const match = disposition.match(/filename="?([^";\n]+)"?/);
    if (match) filename = match[1];
  }
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

interface ExportCard {
  id: string;
  title: string;
  description: string;
  icon: typeof FileSpreadsheet;
  endpoint: string;
  filename: string;
  placeholder?: boolean;
}

const exports: ExportCard[] = [
  {
    id: "holdings",
    title: "Investment Holdings by Country",
    description: "Current portfolio positions grouped by country with cost basis, current market value, and unrealized gains/losses per asset.",
    icon: Building2,
    endpoint: "/api/tax-reports/holdings",
    filename: "holdings_by_country.csv",
  },
  {
    id: "distributions",
    title: "Distribution Summary",
    description: "All dividend and distribution income received, organized by date and asset. Includes currency, gross amount, and reference details.",
    icon: Banknote,
    endpoint: "/api/tax-reports/distributions",
    filename: "distribution_summary.csv",
  },
  {
    id: "capital-gains",
    title: "Capital Gains Report",
    description: "Secondary market sale transactions with proceeds. Cost basis and gain/loss calculations are placeholder values pending full implementation.",
    icon: TrendingUp,
    endpoint: "/api/tax-reports/capital-gains",
    filename: "capital_gains.csv",
    placeholder: true,
  },
];

export default function InvestorTaxReports() {
  const [downloading, setDownloading] = useState<string | null>(null);
  const { toast } = useToast();

  const handleDownload = async (exp: ExportCard) => {
    setDownloading(exp.id);
    try {
      await downloadCsv(exp.endpoint, exp.filename);
      toast({ title: "Export complete", description: `${exp.title} downloaded successfully.` });
    } catch {
      toast({ title: "Export failed", description: "Could not generate the report. Please try again.", variant: "destructive" });
    } finally {
      setDownloading(null);
    }
  };

  return (
    <RoleLayout role="investor">
      <div className="p-6 space-y-6 max-w-4xl mx-auto">
        <div className="flex items-center gap-3">
          <Link href="/investor/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Tax & Reporting"
          description="Export CSV reports for your accountant"
        />
        </div>

        <Section>
          <div className="flex items-center gap-2 mb-4">
            <FileSpreadsheet className="h-5 w-5 text-muted-foreground" />
            <h2 className="text-lg font-semibold" data-testid="text-section-title">For Accountant Export</h2>
          </div>

          <div className="grid gap-4 md:grid-cols-1">
            {exports.map((exp) => {
              const Icon = exp.icon;
              return (
                <Card key={exp.id} data-testid={`card-export-${exp.id}`}>
                  <CardHeader className="flex flex-row items-start justify-between gap-4 space-y-0 pb-2">
                    <div className="flex items-start gap-3 flex-1">
                      <div className="rounded-md bg-muted p-2 mt-0.5">
                        <Icon className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div className="space-y-1">
                        <CardTitle className="text-base flex items-center gap-2 flex-wrap" data-testid={`text-export-title-${exp.id}`}>
                          {exp.title}
                          {exp.placeholder && (
                            <Badge variant="secondary" className="text-xs" data-testid={`badge-placeholder-${exp.id}`}>
                              <AlertTriangle className="h-3 w-3 mr-1" />
                              Placeholder
                            </Badge>
                          )}
                        </CardTitle>
                        <CardDescription data-testid={`text-export-desc-${exp.id}`}>
                          {exp.description}
                        </CardDescription>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => handleDownload(exp)}
                      disabled={downloading === exp.id}
                      data-testid={`button-download-${exp.id}`}
                    >
                      <Download className="h-4 w-4 mr-2" />
                      {downloading === exp.id ? "Downloading..." : "Export CSV"}
                    </Button>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground" data-testid={`text-export-format-${exp.id}`}>
                      <FileSpreadsheet className="h-3 w-3" />
                      CSV format &middot; Ready for spreadsheet import
                      {exp.placeholder && " \u00b7 Some fields require manual completion"}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </Section>

        <Card>
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground" data-testid="text-disclaimer">
              These reports are generated from your VestBlock account data and are intended to assist with tax preparation. 
              They do not constitute tax advice. Please consult with a qualified tax professional for guidance specific to your jurisdiction.
              All files are labeled "for accountant export" for easy identification.
            </p>
          </CardContent>
        </Card>
      </div>
    </RoleLayout>
  );
}
