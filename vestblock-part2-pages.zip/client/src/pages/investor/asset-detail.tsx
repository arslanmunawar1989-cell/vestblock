import { useState, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { GlassCard } from "@/components/glass-card";
import { GlassButton } from "@/components/glass-button";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  ArrowLeft,
  Building2,
  MapPin,
  TrendingUp,
  Shield,
  Coins,
  Calendar,
  FileText,
  Scale,
  BarChart3,
  Users,
  Landmark,
  ArrowRightLeft,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Target,
  DollarSign,
  Percent,
  Home,
  Layers,
  Activity,
  Award,
  Info,
  Car,
  Ruler,
  Hash,
  Star,
  HardHat,
  CircleDot,
  Loader2,
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import { formatCurrency, formatDate } from "@/lib/format";
import { CURRENCY_DETAILS, COUNTRY_DETAILS } from "@shared/constants";
import { DEFAULT_CURRENCY } from "@/lib/currencies";
import { LegalAcceptanceModal, useLegalAcceptance } from "@/components/legal-acceptance-modal";
import { WhatsAppShareButton } from "@/components/whatsapp-share";
import { TOKEN_LEGAL_DISCLAIMERS, TOKEN_LEGAL_CLASSIFICATION } from "@shared/token-legal";

interface AssetDetailData {
  id: string;
  name: string;
  symbol: string;
  assetType: string;
  description: string | null;
  totalSupply: string;
  pricePerToken: string;
  baseCurrency: string;
  country: string;
  status: string;
  issuerId: string;
  imageUrl: string | null;
  propertyType: string | null;
  location: string | null;
  annualYield: string | null;
  occupancyRate: string | null;
  totalPropertyValue: string | null;
  managementFee: string | null;
  distributionFrequency: string | null;
  minInvestment: string | null;
  maxInvestment: string | null;
  maxOwnershipPercent: string | null;
  riskRating: string | null;
  maturityDate: string | null;
  legalStructure: string | null;
  regulatoryBody: string | null;
  propertyClass: string | null;
  tenantProfile: string | null;
  leverageRatio: string | null;
  appraisedValue: string | null;
  tokenizationStructure: string | null;
  highlights: string | null;
  documentUrls: string | null;
  navPerToken: string | null;
  irr: string | null;
  constructionStatus: string | null;
  yearBuilt: string | null;
  totalArea: string | null;
  tokenDecimals: number;
  numberOfUnits: number | null;
  parkingSpaces: number | null;
  amenities: string | null;
  nearbyLandmarks: string | null;
  expectedCompletionDate: string | null;
  issuerName: string | null;
  expectedRentalYield: string | null;
  projectedCapitalAppreciation: string | null;
  holdingPeriodYears: number | null;
  projectedTotalReturn: string | null;
  rounds: {
    id: string;
    assetId: string;
    name: string;
    targetAmount: string;
    raisedAmount: string;
    status: string;
    startDate: string;
    endDate: string | null;
  }[];
  distributions: {
    id: string;
    assetId: string;
    amount: string;
    distributionDate: string;
    status: string;
  }[];
  metrics: {
    totalRaised: number;
    totalTarget: number;
    raisePercentage: number;
    totalDistributed: number;
    distributionCount: number;
    nextDistributionDate: string | null;
    nextDistributionAmount: string | null;
    hasOpenRound: boolean;
    tokensAvailable: number;
  };
}

interface InvestCheckResponse {
  baseCurrency: string;
  availableBalance: number;
  hasWallet: boolean;
  pricePerToken: number;
  tokenDecimals: number;
  totalSupply: number;
  totalPropertyValue: number | null;
  minInvestment: number | null;
  maxInvestment: number | null;
  minTokens: number | null;
  maxTokens: number | null;
  maxOwnershipPercent: number | null;
  currentOwnershipPercent: number | null;
  maxOwnershipTokens: number | null;
  remainingOwnershipCapacity: number | null;
  otherBalances: { currency: string; available: number; fxRate?: number; fxSpread?: number; fxProvider?: string }[];
}

interface FxQuoteResponse {
  id: string;
  fromCurrency: string;
  toCurrency: string;
  amountFrom: string;
  amountTo: string;
  rate: string;
  spread: string;
  fees: string;
  feeRate: string;
  expiresAt: string;
  status: string;
}

interface EddStatusResponse {
  eddStatus: string;
  isBlocked: boolean;
  activeFlagCount: number;
}

function riskColor(risk: string | null) {
  if (!risk) return "outline";
  const r = risk.toLowerCase();
  if (r === "low") return "default" as const;
  if (r === "medium-low") return "default" as const;
  if (r === "medium") return "secondary" as const;
  if (r === "medium-high") return "secondary" as const;
  if (r === "high") return "destructive" as const;
  return "outline" as const;
}

function StatusBadge({ status }: { status: string }) {
  const variant = status === "open" ? "default" : status === "closing" ? "secondary" : "outline";
  return <Badge variant={variant} className="capitalize" data-testid={`badge-status-${status}`}>{status}</Badge>;
}

interface DataRoomDocItem {
  id: string;
  title: string;
  category: string;
  docType: string | null;
  fileName: string;
  url: string;
  status: string;
  createdAt: string;
  description: string | null;
}

interface ConstructionMilestone {
  id: string;
  name: string;
  description: string | null;
  status: string;
  progressPercent: number;
  startDate: string | null;
  expectedDate: string | null;
  completionDate: string | null;
  sortOrder: number;
}

interface ConstructionData {
  assetId: string;
  assetName: string;
  constructionStatus: string | null;
  expectedCompletionDate: string | null;
  projectedRentalYield: string | null;
  overallProgress: number;
  completedMilestones: number;
  totalMilestones: number;
  milestones: ConstructionMilestone[];
}

function milestoneStatusColor(status: string): string {
  switch (status) {
    case "completed": return "text-emerald-600 dark:text-emerald-400";
    case "in_progress": return "text-blue-600 dark:text-blue-400";
    case "delayed": return "text-amber-600 dark:text-amber-400";
    case "cancelled": return "text-red-500 dark:text-red-400";
    default: return "text-muted-foreground";
  }
}

function milestoneStatusLabel(status: string): string {
  const labels: Record<string, string> = {
    planned: "Planned",
    in_progress: "In Progress",
    completed: "Completed",
    delayed: "Delayed",
    cancelled: "Cancelled",
  };
  return labels[status] || status;
}

function ConstructionProgressTab({ assetId }: { assetId: string }) {
  const { data, isLoading } = useQuery<ConstructionData>({
    queryKey: ["/api/investor/properties", assetId, "construction"],
    enabled: !!assetId,
  });

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <Skeleton className="h-40 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (!data) {
    return (
      <Card>
        <CardContent className="p-6 text-center text-muted-foreground text-sm">
          No construction data available
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <HardHat className="w-4 h-4" />
            Construction Overview
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Status</p>
              <Badge variant="outline" className="mt-1 text-xs" data-testid="text-construction-status">
                {milestoneStatusLabel(data.constructionStatus || "planned")}
              </Badge>
            </div>
            <div>
              <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Expected Completion</p>
              <p className="text-sm font-medium mt-1" data-testid="text-expected-completion">
                {data.expectedCompletionDate || "TBD"}
              </p>
            </div>
            <div>
              <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Projected Yield</p>
              <p className="text-sm font-medium mt-1 text-emerald-600 dark:text-emerald-400" data-testid="text-projected-yield">
                {data.projectedRentalYield ? `${data.projectedRentalYield}%` : "TBD"}
              </p>
            </div>
            <div>
              <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Milestones</p>
              <p className="text-sm font-medium mt-1" data-testid="text-milestone-count">
                {data.completedMilestones} / {data.totalMilestones}
              </p>
            </div>
          </div>

          <div className="space-y-1">
            <div className="flex items-center justify-between gap-2 text-xs">
              <span className="text-muted-foreground">Overall Progress</span>
              <span className="font-medium">{data.overallProgress}%</span>
            </div>
            <Progress value={data.overallProgress} className="h-2" />
          </div>

          <div className="rounded-md bg-amber-50 dark:bg-amber-900/20 p-3">
            <p className="text-xs text-amber-700 dark:text-amber-300 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 shrink-0" />
              Rental distributions will begin after construction is complete
            </p>
          </div>
        </CardContent>
      </Card>

      {data.milestones.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Target className="w-4 h-4" />
              Construction Milestones
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {data.milestones.map((m, idx) => (
                <div key={m.id} className="flex gap-3" data-testid={`milestone-row-${m.id}`}>
                  <div className="flex flex-col items-center">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${
                      m.status === "completed" ? "bg-emerald-100 dark:bg-emerald-900/30" :
                      m.status === "in_progress" ? "bg-blue-100 dark:bg-blue-900/30" :
                      m.status === "delayed" ? "bg-amber-100 dark:bg-amber-900/30" :
                      "bg-muted"
                    }`}>
                      {m.status === "completed" ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                      ) : m.status === "in_progress" ? (
                        <Activity className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                      ) : (
                        <CircleDot className="w-3 h-3 text-muted-foreground" />
                      )}
                    </div>
                    {idx < data.milestones.length - 1 && (
                      <div className="w-px flex-1 bg-border mt-1" />
                    )}
                  </div>
                  <div className="flex-1 pb-4 min-w-0">
                    <div className="flex items-start justify-between gap-2 flex-wrap">
                      <div>
                        <p className="text-sm font-medium" data-testid={`text-milestone-name-${m.id}`}>{m.name}</p>
                        {m.description && (
                          <p className="text-xs text-muted-foreground mt-0.5">{m.description}</p>
                        )}
                      </div>
                      <Badge variant="outline" className={`text-[10px] shrink-0 ${milestoneStatusColor(m.status)}`}>
                        {milestoneStatusLabel(m.status)}
                      </Badge>
                    </div>
                    <div className="mt-2 space-y-1">
                      <Progress value={m.progressPercent} className="h-1" />
                      <div className="flex items-center gap-3 text-[11px] text-muted-foreground flex-wrap">
                        <span>{m.progressPercent}%</span>
                        {m.expectedDate && (
                          <span className="flex items-center gap-0.5">
                            <Calendar className="w-3 h-3" />
                            Due: {m.expectedDate}
                          </span>
                        )}
                        {m.completionDate && (
                          <span className="flex items-center gap-0.5">
                            <CheckCircle2 className="w-3 h-3" />
                            Completed: {m.completionDate}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

const DOC_TYPE_LABELS: Record<string, string> = {
  title_deed: "Title Deed",
  valuation_report: "Valuation Report",
  lease_agreement: "Lease Agreement",
  insurance_policy: "Insurance Policy",
  rental_contract: "Rental Contract",
  construction_update: "Construction Update",
  expense_invoice: "Expense Invoice",
  annual_financial_statement: "Annual Financial Statement",
  other: "Other",
};

function DataRoomTab({ assetId }: { assetId: string }) {
  const { data: docs = [], isLoading, error } = useQuery<DataRoomDocItem[]>({
    queryKey: ["/api/data-room/assets", assetId, "docs"],
    enabled: !!assetId,
    retry: false,
  });

  if (isLoading) {
    return (
      <div className="space-y-3">
        <Skeleton className="h-16 w-full" />
        <Skeleton className="h-16 w-full" />
        <Skeleton className="h-16 w-full" />
      </div>
    );
  }

  if (error) {
    const is403 = (error as any)?.message?.includes("403") || (error as any)?.status === 403;
    return (
      <Card>
        <CardContent className="flex flex-col items-center gap-3 py-8 text-center">
          <Shield className="w-10 h-10 text-muted-foreground" />
          <div>
            <p className="text-sm font-medium" data-testid="text-dataroom-restricted">
              {is403 ? "Access Restricted" : "Unable to Load Documents"}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {is403
                ? "You must be an investor in this property to view its data room documents"
                : "There was an error loading the data room. Please try again later."}
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (docs.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center gap-3 py-8 text-center">
          <FileText className="w-10 h-10 text-muted-foreground" />
          <div>
            <p className="text-sm font-medium">No documents available</p>
            <p className="text-xs text-muted-foreground mt-1">Documents will appear here once the issuer publishes them</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const grouped: Record<string, DataRoomDocItem[]> = {};
  docs.forEach(d => {
    const type = d.docType || "other";
    if (!grouped[type]) grouped[type] = [];
    grouped[type].push(d);
  });

  const typeOrder = ["title_deed", "valuation_report", "lease_agreement", "insurance_policy", "rental_contract", "construction_update", "expense_invoice", "annual_financial_statement", "other"];
  const sortedTypes = typeOrder.filter(t => grouped[t]?.length > 0);
  const extraTypes = Object.keys(grouped).filter(t => !typeOrder.includes(t));
  const allTypes = [...sortedTypes, ...extraTypes];

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <FileText className="w-4 h-4" /> Data Room
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-xs text-muted-foreground">
            {docs.length} document{docs.length !== 1 ? "s" : ""} available for review
          </p>
          {allTypes.map(docType => {
            const typeDocs = grouped[docType];
            const label = DOC_TYPE_LABELS[docType] || docType;
            return (
              <div key={docType} className="space-y-2">
                <h4 className="text-sm font-medium" data-testid={`dataroom-type-${docType}`}>{label}</h4>
                {typeDocs.map(doc => (
                  <div key={doc.id} className="flex items-center gap-3 p-3 rounded-md bg-muted/50" data-testid={`dataroom-doc-${doc.id}`}>
                    <FileText className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate" data-testid={`dataroom-doc-title-${doc.id}`}>{doc.title}</p>
                      <p className="text-xs text-muted-foreground">{doc.fileName} &middot; {new Date(doc.createdAt).toLocaleDateString()}</p>
                    </div>
                    <Badge variant="outline" className="text-xs capitalize flex-shrink-0">{doc.category}</Badge>
                  </div>
                ))}
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}

export default function AssetDetailPage() {
  const params = useParams<{ id: string }>();
  const assetId = params.id;
  const { toast } = useToast();
  const { defaultCurrency } = useAuth();
  const [showInvestModal, setShowInvestModal] = useState(false);
  const [investQuantity, setInvestQuantity] = useState("");
  const [showLegalModal, setShowLegalModal] = useState(false);
  const [legalContext, setLegalContext] = useState<{ country?: string; vehicleType?: string }>({});
  const [payWithCurrency, setPayWithCurrency] = useState<string | null>(null);
  const [fxQuote, setFxQuote] = useState<FxQuoteResponse | null>(null);
  const [fxQuoteLoading, setFxQuoteLoading] = useState(false);

  const { data: asset, isLoading } = useQuery<AssetDetailData>({
    queryKey: ["/api/marketplace/assets", assetId],
    queryFn: async () => {
      const res = await fetch(`/api/marketplace/assets/${assetId}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch asset");
      return res.json();
    },
    enabled: !!assetId,
  });

  const { data: eddData } = useQuery<EddStatusResponse>({
    queryKey: ["/api/edd-status"],
  });

  const { data: valuations } = useQuery<{
    id: string;
    date: string;
    valuationAmount: string;
    currency: string;
    method: string;
    impliedTokenPrice: string | null;
    notes: string | null;
  }[]>({
    queryKey: ["/api/assets", assetId, "valuations"],
    queryFn: async () => {
      const res = await fetch(`/api/assets/${assetId}/valuations`, { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!assetId,
  });

  const { data: investCheck, isLoading: checkLoading } = useQuery<InvestCheckResponse>({
    queryKey: [`/api/invest/check/${assetId}`],
    enabled: !!assetId && showInvestModal,
  });

  interface EligibilityCheck {
    check: string;
    passed: boolean;
    reason?: string;
    code?: string;
    details?: Record<string, unknown>;
  }
  interface EligibilityResponse {
    eligible: boolean;
    checks: EligibilityCheck[];
    summary: {
      assetName: string;
      assetCountry: string;
      investorCountry: string | null;
      investorType: string;
      kycStatus: string;
      eddStatus: string;
      countryPolicyNotes: string[];
    };
  }

  const { data: eligibility, isLoading: eligibilityLoading } = useQuery<EligibilityResponse>({
    queryKey: [`/api/investor/eligibility/${assetId}`],
    enabled: !!assetId,
  });

  const investMutation = useMutation({
    mutationFn: async (data: { assetId: string; roundId: string; quantity: number; sourceCurrency?: string; fxQuoteId?: string }) => {
      const csrf = document.cookie.match(/(?:^|;\s*)csrf-token=([^;]*)/)?.[1];
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (csrf) headers["x-csrf-token"] = decodeURIComponent(csrf);
      const res = await fetch("/api/invest", {
        method: "POST",
        headers,
        body: JSON.stringify(data),
        credentials: "include",
      });
      const body = await res.json();
      if (!res.ok) {
        const err: any = new Error(body.message || "Investment failed");
        err.code = body.code;
        err.details = body.details;
        throw err;
      }
      return body;
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["/api/wallet/accounts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/marketplace/assets", assetId] });
      queryClient.invalidateQueries({ queryKey: [`/api/invest/check/${assetId}`] });
      setShowInvestModal(false);
      setInvestQuantity("");
      setPayWithCurrency(null);
      setFxQuote(null);
      const fxInfo = result.investment.fxConversion
        ? ` (converted from ${result.investment.fxConversion.sourceCurrency})`
        : "";
      toast({
        title: "Investment Successful",
        description: `You invested ${formatCurrency(result.investment.totalCost, result.investment.currency)} in ${result.investment.assetName}${fxInfo}`,
      });
    },
    onError: (err: any) => {
      if (err.code === "LEGAL_NOT_ACCEPTED" && err.details) {
        setLegalContext({ country: err.details.country, vehicleType: err.details.vehicleType });
        setShowLegalModal(true);
        return;
      }
      toast({ title: "Investment Failed", description: err.message || "Could not process investment", variant: "destructive" });
    },
  });

  const { allAccepted, pendingCount } = useLegalAcceptance();
  const isEddBlocked = eddData?.isBlocked ?? false;
  const isLegalBlocked = !allAccepted && pendingCount > 0;
  const isBlocked = isEddBlocked || isLegalBlocked;

  const qty = parseFloat(investQuantity) || 0;
  const pricePerToken = asset ? parseFloat(asset.pricePerToken) : 0;
  const totalCost = qty * pricePerToken;
  const baseCurrency = asset?.baseCurrency || DEFAULT_CURRENCY;
  const userCurrency = defaultCurrency || DEFAULT_CURRENCY;
  const isPayingWithOtherCurrency = payWithCurrency !== null && payWithCurrency !== baseCurrency;
  const needsFxConvert = baseCurrency !== userCurrency && !isPayingWithOtherCurrency;
  const hasEnoughBalance = isPayingWithOtherCurrency
    ? fxQuote ? true : false
    : investCheck ? investCheck.availableBalance >= totalCost : false;
  const shortfall = isPayingWithOtherCurrency
    ? 0
    : investCheck ? Math.max(0, totalCost - investCheck.availableBalance) : 0;

  const selectedOtherBalance = investCheck?.otherBalances.find(b => b.currency === payWithCurrency);

  const fetchFxQuote = async (fromCurrency: string, amount: number) => {
    if (amount <= 0) { setFxQuote(null); return; }
    setFxQuoteLoading(true);
    try {
      const csrf = document.cookie.match(/(?:^|;\s*)csrf-token=([^;]*)/)?.[1];
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (csrf) headers["x-csrf-token"] = decodeURIComponent(csrf);
      const res = await fetch("/api/fx/quote", {
        method: "POST",
        headers,
        body: JSON.stringify({ fromCurrency, toCurrency: baseCurrency, amount }),
        credentials: "include",
      });
      if (!res.ok) { setFxQuote(null); return; }
      const quote = await res.json();
      setFxQuote(quote);
    } catch {
      setFxQuote(null);
    } finally {
      setFxQuoteLoading(false);
    }
  };

  const openRound = asset?.rounds.find(r => r.status === "open") || null;

  const highlightsList = useMemo(() => {
    if (!asset?.highlights) return [];
    return asset.highlights.split("|").filter(Boolean);
  }, [asset?.highlights]);

  const docsList = useMemo(() => {
    if (!asset?.documentUrls) return [];
    return asset.documentUrls.split("|").filter(Boolean);
  }, [asset?.documentUrls]);

  const amenitiesList = useMemo(() => {
    if (!asset?.amenities) return [];
    return asset.amenities.split("|").filter(Boolean);
  }, [asset?.amenities]);

  const landmarksList = useMemo(() => {
    if (!asset?.nearbyLandmarks) return [];
    return asset.nearbyLandmarks.split("|").filter(Boolean);
  }, [asset?.nearbyLandmarks]);

  const handleInvestClick = () => {
    if (isLegalBlocked) {
      setShowLegalModal(true);
      return;
    }
    setInvestQuantity("");
    setShowInvestModal(true);
  };

  const isBelowMinimum = investCheck?.minTokens != null && qty > 0 && qty < investCheck.minTokens;
  const isAboveMaximum = investCheck?.maxTokens != null && qty > 0 && qty > investCheck.maxTokens;
  const exceedsOwnershipLimit = investCheck?.maxOwnershipPercent != null && investCheck.remainingOwnershipCapacity != null && qty > 0 && qty > investCheck.remainingOwnershipCapacity;

  const handleConfirmInvest = () => {
    if (!asset || !openRound || qty <= 0 || isBelowMinimum || isAboveMaximum || exceedsOwnershipLimit) return;
    const payload: { assetId: string; roundId: string; quantity: number; sourceCurrency?: string; fxQuoteId?: string } = {
      assetId: asset.id,
      roundId: openRound.id,
      quantity: qty,
    };
    if (isPayingWithOtherCurrency && fxQuote) {
      payload.sourceCurrency = payWithCurrency!;
      payload.fxQuoteId = fxQuote.id;
    }
    investMutation.mutate(payload);
  };

  const currencyDetail = asset ? CURRENCY_DETAILS[asset.baseCurrency as keyof typeof CURRENCY_DETAILS] : null;
  const currencySymbol = currencyDetail?.symbol || baseCurrency;
  const countryName = asset ? (COUNTRY_DETAILS[asset.country as keyof typeof COUNTRY_DETAILS]?.name || asset.country) : "";

  if (isLoading) {
    return (
      <RoleLayout role="investor">
        <div className="space-y-6">
          <Skeleton className="h-8 w-48" />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-4">
              <Skeleton className="h-48" />
              <Skeleton className="h-64" />
            </div>
            <div className="space-y-4">
              <Skeleton className="h-48" />
              <Skeleton className="h-32" />
            </div>
          </div>
        </div>
      </RoleLayout>
    );
  }

  if (!asset) {
    return (
      <RoleLayout role="investor">
        <div className="text-center py-12">
          <Building2 className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-50" />
          <p className="text-muted-foreground">Asset not found</p>
          <Link href="/investor/marketplace">
            <Button variant="outline" className="mt-4" data-testid="button-back-marketplace">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Marketplace
            </Button>
          </Link>
        </div>
      </RoleLayout>
    );
  }

  return (
    <RoleLayout role="investor">
      <div className="space-y-6">
        <div className="flex items-center gap-3 flex-wrap">
          <Link href="/investor/marketplace">
            <Button variant="ghost" size="icon" data-testid="button-back">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 flex-wrap">
              <div className="w-12 h-12 rounded-md gradient-hero flex items-center justify-center flex-shrink-0">
                <span className="text-white font-bold text-lg">{asset.name[0]}</span>
              </div>
              <div>
                <h1 className="text-xl font-bold" data-testid="text-asset-name">{asset.name}</h1>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm text-muted-foreground">{asset.symbol}</span>
                  <Badge variant="outline" className="text-xs no-default-hover-elevate">{asset.assetType}</Badge>
                  <Badge variant={riskColor(asset.riskRating)} className="text-xs">{asset.riskRating || "Unrated"}</Badge>
                  {asset.constructionStatus && (
                    <Badge variant={asset.constructionStatus === "Operational" ? "default" : "secondary"} className="text-xs">
                      {asset.constructionStatus}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <WhatsAppShareButton
              assetName={asset.name}
              assetSymbol={asset.symbol}
              pricePerToken={asset.pricePerToken}
              baseCurrency={asset.baseCurrency}
              annualYield={asset.annualYield}
              assetType={asset.assetType}
              location={asset.location}
              assetId={asset.id}
            />
            <GlassButton
              variant="primary"
              disabled={isBlocked || !openRound}
              onClick={handleInvestClick}
              data-testid="button-invest-header"
            >
              {!openRound ? "No Open Round" : isBlocked ? "Investing Restricted" : "Invest Now"}
            </GlassButton>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          <StatTile icon={DollarSign} label="Token Price" value={`${currencySymbol} ${parseFloat(asset.pricePerToken).toFixed(2)}`} testId="stat-price" />
          {asset.expectedRentalYield && parseFloat(asset.expectedRentalYield) > 0 && <StatTile icon={TrendingUp} label="Rental Yield" value={`${parseFloat(asset.expectedRentalYield).toFixed(2)}%`} testId="stat-rental-yield" />}
          {asset.projectedCapitalAppreciation && parseFloat(asset.projectedCapitalAppreciation) > 0 && <StatTile icon={Activity} label="Capital Growth" value={`${parseFloat(asset.projectedCapitalAppreciation).toFixed(2)}%`} testId="stat-capital-growth" />}
          {asset.navPerToken && <StatTile icon={BarChart3} label="NAV/Token" value={`${currencySymbol} ${parseFloat(asset.navPerToken).toFixed(2)}`} testId="stat-nav" />}
          {asset.projectedTotalReturn && parseFloat(asset.projectedTotalReturn) > 0 && <StatTile icon={Target} label="Total Return" value={`${parseFloat(asset.projectedTotalReturn).toFixed(2)}%`} testId="stat-total-return" />}
          {asset.occupancyRate && <StatTile icon={Home} label="Occupancy" value={`${parseFloat(asset.occupancyRate).toFixed(1)}%`} testId="stat-occupancy" />}
          <StatTile icon={Target} label="Raised" value={`${asset.metrics.raisePercentage}%`} testId="stat-raised" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="w-full justify-start flex-wrap h-auto gap-1 bg-transparent p-0">
                <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
                <TabsTrigger value="property" data-testid="tab-property">Property</TabsTrigger>
                <TabsTrigger value="tokenization" data-testid="tab-tokenization">Tokenization</TabsTrigger>
                <TabsTrigger value="financials" data-testid="tab-financials">Financials</TabsTrigger>
                <TabsTrigger value="rounds" data-testid="tab-rounds">Rounds</TabsTrigger>
                <TabsTrigger value="distributions" data-testid="tab-distributions">Distributions</TabsTrigger>
                <TabsTrigger value="legal" data-testid="tab-legal">Legal</TabsTrigger>
                <TabsTrigger value="risk" data-testid="tab-risk">Risk</TabsTrigger>
                <TabsTrigger value="compliance" data-testid="tab-compliance">Compliance</TabsTrigger>
                <TabsTrigger value="data-room" data-testid="tab-data-room">Data Room</TabsTrigger>
                {asset.constructionStatus && asset.constructionStatus !== "completed" && (
                  <TabsTrigger value="construction" data-testid="tab-construction">Construction</TabsTrigger>
                )}
              </TabsList>

              <TabsContent value="overview" className="space-y-4 mt-4">
                {asset.description && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base flex items-center gap-2"><Info className="w-4 h-4" /> About This Investment</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground leading-relaxed" data-testid="text-description">{asset.description}</p>
                    </CardContent>
                  </Card>
                )}

                {highlightsList.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base flex items-center gap-2"><Star className="w-4 h-4" /> Investment Highlights</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {highlightsList.map((h, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm" data-testid={`highlight-${i}`}>
                            <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />
                            <span>{h}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                )}

                {asset.location && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base flex items-center gap-2"><MapPin className="w-4 h-4" /> Location</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <p className="text-sm font-medium" data-testid="text-location">{asset.location}</p>
                      <p className="text-sm text-muted-foreground">{countryName}</p>
                      {landmarksList.length > 0 && (
                        <div className="space-y-1">
                          <p className="text-xs font-medium text-muted-foreground">Nearby Landmarks</p>
                          <div className="flex flex-wrap gap-2">
                            {landmarksList.map((l, i) => (
                              <Badge key={i} variant="outline" className="text-xs no-default-hover-elevate">{l}</Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="property" className="space-y-4 mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2"><Building2 className="w-4 h-4" /> Property Details</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      <DetailRow icon={Building2} label="Property Type" value={asset.propertyType} testId="detail-property-type" />
                      <DetailRow icon={Award} label="Property Class" value={asset.propertyClass} testId="detail-property-class" />
                      <DetailRow icon={Ruler} label="Total Area" value={asset.totalArea} testId="detail-total-area" />
                      <DetailRow icon={Hash} label="Number of Units" value={asset.numberOfUnits?.toString()} testId="detail-units" />
                      <DetailRow icon={Car} label="Parking Spaces" value={asset.parkingSpaces?.toString()} testId="detail-parking" />
                      <DetailRow icon={Calendar} label="Year Built" value={asset.yearBuilt} testId="detail-year-built" />
                      <DetailRow icon={Activity} label="Construction Status" value={asset.constructionStatus} testId="detail-construction" />
                      {asset.expectedCompletionDate && (
                        <DetailRow icon={Calendar} label="Expected Completion" value={asset.expectedCompletionDate} testId="detail-completion" />
                      )}
                      <DetailRow icon={Users} label="Tenant Profile" value={asset.tenantProfile} testId="detail-tenants" />
                      <DetailRow icon={Home} label="Occupancy Rate" value={asset.occupancyRate ? `${parseFloat(asset.occupancyRate).toFixed(1)}%` : null} testId="detail-occupancy" />
                    </div>
                  </CardContent>
                </Card>

                {amenitiesList.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base flex items-center gap-2"><Star className="w-4 h-4" /> Amenities & Facilities</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2">
                        {amenitiesList.map((a, i) => (
                          <Badge key={i} variant="outline" className="text-xs no-default-hover-elevate" data-testid={`amenity-${i}`}>{a}</Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="tokenization" className="space-y-4 mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2"><Coins className="w-4 h-4" /> Token Structure</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      <DetailRow icon={Coins} label="Token Symbol" value={asset.symbol} testId="detail-symbol" />
                      <DetailRow icon={Layers} label="Total Supply" value={`${parseFloat(asset.totalSupply).toLocaleString()} tokens`} testId="detail-supply" />
                      <DetailRow icon={Layers} label="Token Precision" value={`${asset.tokenDecimals} decimals (min ${(1 / Math.pow(10, asset.tokenDecimals)).toFixed(asset.tokenDecimals)} tokens)`} testId="detail-token-decimals" />
                      <DetailRow icon={DollarSign} label="Price per Token" value={`${currencySymbol} ${parseFloat(asset.pricePerToken).toFixed(2)}`} testId="detail-token-price" />
                      <DetailRow icon={BarChart3} label="NAV per Token" value={asset.navPerToken ? `${currencySymbol} ${parseFloat(asset.navPerToken).toFixed(2)}` : null} testId="detail-nav" />
                      <DetailRow icon={DollarSign} label="Total Property Value" value={asset.totalPropertyValue ? formatCurrency(parseFloat(asset.totalPropertyValue), baseCurrency) : null} testId="detail-total-value" />
                      <DetailRow icon={DollarSign} label="Appraised Value" value={asset.appraisedValue ? formatCurrency(parseFloat(asset.appraisedValue), baseCurrency) : null} testId="detail-appraised" />
                      <DetailRow icon={DollarSign} label="Min Investment" value={asset.minInvestment ? `${currencySymbol} ${parseFloat(asset.minInvestment).toLocaleString()}` : null} testId="detail-min-invest" />
                      <DetailRow icon={DollarSign} label="Max Investment" value={asset.maxInvestment ? `${currencySymbol} ${parseFloat(asset.maxInvestment).toLocaleString()}` : null} testId="detail-max-invest" />
                      <DetailRow icon={Layers} label="Max Ownership" value={asset.maxOwnershipPercent ? `${parseFloat(asset.maxOwnershipPercent)}% per investor` : null} testId="detail-max-ownership" />
                    </div>
                  </CardContent>
                </Card>

                {asset.tokenizationStructure && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base flex items-center gap-2"><Layers className="w-4 h-4" /> Tokenization Model</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground leading-relaxed" data-testid="text-tokenization-structure">{asset.tokenizationStructure}</p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="financials" className="space-y-4 mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2"><BarChart3 className="w-4 h-4" /> Financial Metrics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      <DetailRow icon={TrendingUp} label="Expected Rental Yield" value={asset.expectedRentalYield && parseFloat(asset.expectedRentalYield) > 0 ? `${parseFloat(asset.expectedRentalYield).toFixed(2)}% p.a.` : null} testId="detail-rental-yield" />
                      <DetailRow icon={Activity} label="Projected Capital Growth" value={asset.projectedCapitalAppreciation && parseFloat(asset.projectedCapitalAppreciation) > 0 ? `${parseFloat(asset.projectedCapitalAppreciation).toFixed(2)}% p.a.` : null} testId="detail-capital-growth" />
                      <DetailRow icon={Target} label="Projected Total Return" value={asset.projectedTotalReturn && parseFloat(asset.projectedTotalReturn) > 0 ? `${parseFloat(asset.projectedTotalReturn).toFixed(2)}% p.a.` : null} testId="detail-total-return" />
                      <DetailRow icon={Activity} label="Target IRR" value={asset.irr ? `${parseFloat(asset.irr).toFixed(1)}%` : null} testId="detail-irr" />
                      <DetailRow icon={Percent} label="Management Fee" value={asset.managementFee ? `${parseFloat(asset.managementFee).toFixed(2)}%` : null} testId="detail-mgmt-fee" />
                      <DetailRow icon={Percent} label="Leverage Ratio" value={asset.leverageRatio ? `${parseFloat(asset.leverageRatio).toFixed(0)}%` : null} testId="detail-leverage" />
                      <DetailRow icon={Calendar} label="Distribution Frequency" value={asset.distributionFrequency} testId="detail-dist-freq" />
                      <DetailRow icon={Calendar} label="Maturity Date" value={asset.maturityDate} testId="detail-maturity" />
                      <DetailRow icon={DollarSign} label="Total Distributed" value={asset.metrics.totalDistributed > 0 ? formatCurrency(asset.metrics.totalDistributed, baseCurrency) : "N/A"} testId="detail-total-dist" />
                      <DetailRow icon={Calendar} label="Next Distribution" value={asset.metrics.nextDistributionDate || "TBD"} testId="detail-next-dist" />
                    </div>
                  </CardContent>
                </Card>

                {[asset.expectedRentalYield, asset.projectedCapitalAppreciation, asset.projectedTotalReturn].some(v => v && parseFloat(v) > 0) && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base flex items-center gap-2"><TrendingUp className="w-4 h-4" /> Expected Returns & Projections</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                        {asset.expectedRentalYield && parseFloat(asset.expectedRentalYield) > 0 && (
                          <div className="rounded-md border p-3 text-center" data-testid="roi-rental-yield">
                            <p className="text-xs text-muted-foreground mb-1">Expected Rental Yield</p>
                            <p className="text-xl font-bold text-emerald-600 dark:text-emerald-400">{parseFloat(asset.expectedRentalYield).toFixed(2)}%</p>
                            <p className="text-[10px] text-muted-foreground mt-1">per annum</p>
                          </div>
                        )}
                        {asset.projectedCapitalAppreciation && parseFloat(asset.projectedCapitalAppreciation) > 0 && (
                          <div className="rounded-md border p-3 text-center" data-testid="roi-capital-appreciation">
                            <p className="text-xs text-muted-foreground mb-1">Projected Capital Growth</p>
                            <p className="text-xl font-bold text-blue-600 dark:text-blue-400">{parseFloat(asset.projectedCapitalAppreciation).toFixed(2)}%</p>
                            <p className="text-[10px] text-muted-foreground mt-1">per annum</p>
                          </div>
                        )}
                        {asset.projectedTotalReturn && parseFloat(asset.projectedTotalReturn) > 0 && (
                          <div className="rounded-md border p-3 text-center" data-testid="roi-total-return">
                            <p className="text-xs text-muted-foreground mb-1">Projected Total Return</p>
                            <p className="text-xl font-bold text-amber-600 dark:text-amber-400">{parseFloat(asset.projectedTotalReturn).toFixed(2)}%</p>
                            <p className="text-[10px] text-muted-foreground mt-1">per annum</p>
                          </div>
                        )}
                      </div>
                      {asset.holdingPeriodYears && (
                        <div className="flex items-center gap-2 text-xs text-muted-foreground border-t pt-3" data-testid="roi-holding-period">
                          <Calendar className="w-3 h-3" />
                          <span>Projected holding period: {asset.holdingPeriodYears} year{asset.holdingPeriodYears > 1 ? "s" : ""}</span>
                        </div>
                      )}
                      <p className="text-[10px] text-muted-foreground italic">
                        Projections are estimates based on current market conditions and historical performance. Actual returns may vary. Past performance does not guarantee future results.
                      </p>
                    </CardContent>
                  </Card>
                )}

                {valuations && valuations.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base flex items-center gap-2"><TrendingUp className="w-4 h-4" /> Valuation History</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {valuations.map((v, i) => (
                          <div key={v.id} className="flex items-center justify-between gap-3 border rounded-md p-3" data-testid={`valuation-row-${i}`}>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-sm font-medium" data-testid={`valuation-date-${i}`}>{formatDate(v.date)}</span>
                                <Badge variant="secondary" className="text-xs">{v.method}</Badge>
                              </div>
                              {v.notes && <p className="text-xs text-muted-foreground mt-0.5">{v.notes}</p>}
                            </div>
                            <div className="text-right">
                              <p className="text-sm font-semibold" data-testid={`valuation-amount-${i}`}>
                                {formatCurrency(v.valuationAmount, v.currency)}
                              </p>
                              <p className="text-xs text-muted-foreground" data-testid={`valuation-implied-${i}`}>
                                Token: {v.impliedTokenPrice ? formatCurrency(v.impliedTokenPrice, v.currency) : "—"}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="rounds" className="space-y-4 mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2"><Target className="w-4 h-4" /> Investment Rounds</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {asset.rounds.length === 0 ? (
                      <p className="text-sm text-muted-foreground">No investment rounds available.</p>
                    ) : (
                      asset.rounds.map(round => {
                        const raised = parseFloat(round.raisedAmount);
                        const target = parseFloat(round.targetAmount);
                        const pct = target > 0 ? Math.min(100, Math.round((raised / target) * 100)) : 0;
                        return (
                          <div key={round.id} className="border rounded-md p-4 space-y-3" data-testid={`round-${round.id}`}>
                            <div className="flex items-center justify-between gap-2 flex-wrap">
                              <div>
                                <p className="font-medium text-sm">{round.name}</p>
                                <p className="text-xs text-muted-foreground">Started {round.startDate}{round.endDate ? ` - Ends ${round.endDate}` : ""}</p>
                              </div>
                              <StatusBadge status={round.status} />
                            </div>
                            <div className="flex items-center justify-between gap-2 text-sm">
                              <span className="text-muted-foreground">Raised</span>
                              <span className="font-medium">{formatCurrency(raised, baseCurrency)} / {formatCurrency(target, baseCurrency)}</span>
                            </div>
                            <div className="w-full bg-muted rounded-sm h-2">
                              <div className="gradient-hero h-2 rounded-sm transition-all" style={{ width: `${pct}%` }} />
                            </div>
                            <p className="text-xs text-muted-foreground text-right">{pct}% funded</p>
                          </div>
                        );
                      })
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="distributions" className="space-y-4 mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2"><Coins className="w-4 h-4" /> Distribution History & Schedule</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {asset.distributions.length === 0 ? (
                      <p className="text-sm text-muted-foreground">No distributions recorded yet.</p>
                    ) : (
                      <div className="space-y-3">
                        {asset.distributions.map(d => (
                          <div key={d.id} className="flex items-center justify-between gap-3 border-b pb-3 last:border-0 last:pb-0" data-testid={`distribution-${d.id}`}>
                            <div className="flex items-center gap-3">
                              {d.status === "completed" ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                              ) : (
                                <Clock className="w-4 h-4 text-amber-500 flex-shrink-0" />
                              )}
                              <div>
                                <p className="text-sm font-medium">{formatCurrency(parseFloat(d.amount), baseCurrency)}</p>
                                <p className="text-xs text-muted-foreground">{d.distributionDate}</p>
                              </div>
                            </div>
                            <Badge variant={d.status === "completed" ? "default" : "secondary"} className="text-xs capitalize">{d.status}</Badge>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="legal" className="space-y-4 mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2"><Scale className="w-4 h-4" /> Legal & Regulatory</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <DetailRow icon={Scale} label="Legal Structure" value={asset.legalStructure} testId="detail-legal-structure" />
                      <DetailRow icon={Landmark} label="Regulatory Body" value={asset.regulatoryBody} testId="detail-regulatory" />
                      <DetailRow icon={Building2} label="Issuer" value={asset.issuerName} testId="detail-issuer" />
                      <DetailRow icon={MapPin} label="Jurisdiction" value={countryName} testId="detail-jurisdiction" />
                    </div>
                  </CardContent>
                </Card>

                <Card data-testid="card-token-classification">
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2"><Info className="w-4 h-4" /> Token Classification</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="no-default-hover-elevate text-xs" data-testid="badge-token-classification">{TOKEN_LEGAL_CLASSIFICATION.positiveDescriptor}</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground leading-relaxed" data-testid="text-asset-disclaimer">{TOKEN_LEGAL_DISCLAIMERS.assetDetailDisclaimer}</p>
                      <p className="text-xs text-muted-foreground leading-relaxed" data-testid="text-secondary-market-notice">{TOKEN_LEGAL_CLASSIFICATION.secondaryMarketNotice}</p>
                    </div>
                  </CardContent>
                </Card>

                {docsList.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base flex items-center gap-2"><FileText className="w-4 h-4" /> Available Documents</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {docsList.map((doc, i) => (
                          <div key={i} className="flex items-center gap-2 text-sm" data-testid={`doc-${i}`}>
                            <FileText className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                            <span>{doc}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="risk" className="space-y-4 mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2"><Shield className="w-4 h-4" /> Risk Assessment</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center gap-3">
                      <span className="text-sm text-muted-foreground">Risk Rating:</span>
                      <Badge variant={riskColor(asset.riskRating)} data-testid="detail-risk-rating">{asset.riskRating || "Unrated"}</Badge>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <DetailRow icon={Percent} label="Leverage Ratio" value={asset.leverageRatio ? `${parseFloat(asset.leverageRatio).toFixed(0)}%` : "N/A"} testId="risk-leverage" />
                      <DetailRow icon={Home} label="Occupancy Rate" value={asset.occupancyRate ? `${parseFloat(asset.occupancyRate).toFixed(1)}%` : "N/A"} testId="risk-occupancy" />
                      <DetailRow icon={Calendar} label="Maturity Date" value={asset.maturityDate || "N/A"} testId="risk-maturity" />
                      <DetailRow icon={Activity} label="Construction Status" value={asset.constructionStatus || "N/A"} testId="risk-construction" />
                    </div>

                    <div className="border rounded-md p-3 bg-muted/30">
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        Investment in tokenized real estate carries inherent risks including market fluctuation, liquidity constraints, regulatory changes, and property-specific risks. Past performance does not guarantee future returns. Please review all offering documents carefully before investing.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="compliance" className="space-y-4 mt-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between gap-2 flex-wrap">
                    <CardTitle className="text-base flex items-center gap-2"><Shield className="w-4 h-4" /> Investment Eligibility</CardTitle>
                    {eligibility && (
                      <Badge
                        variant={eligibility.eligible ? "secondary" : "destructive"}
                        data-testid="badge-eligibility-status"
                      >
                        {eligibility.eligible ? "Eligible" : "Not Eligible"}
                      </Badge>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {eligibilityLoading ? (
                      <div className="space-y-2">
                        {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-8 w-full" />)}
                      </div>
                    ) : eligibility ? (
                      <>
                        <div className="space-y-2">
                          {eligibility.checks.map((c, i) => {
                            const checkLabels: Record<string, string> = {
                              kyc_status: "KYC Verification",
                              sanctions_screening: "Sanctions Screening",
                              nationality_screening: "Nationality Screening",
                              asset_geo_eligible: "Geographic Eligibility",
                              investment_policy: "Investment Policy",
                              edd_status: "Enhanced Due Diligence",
                              legal_documents: "Legal Documents",
                              asset_status: "Asset Status",
                            };
                            return (
                              <div
                                key={i}
                                className="flex items-start gap-3 p-2 rounded-md border"
                                data-testid={`eligibility-check-${c.check}`}
                              >
                                {c.passed ? (
                                  <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />
                                ) : (
                                  <AlertTriangle className="w-4 h-4 text-destructive mt-0.5 flex-shrink-0" />
                                )}
                                <div className="flex-1 min-w-0">
                                  <p className="text-sm font-medium" data-testid={`text-check-label-${c.check}`}>
                                    {checkLabels[c.check] || c.check}
                                  </p>
                                  {!c.passed && c.reason && (
                                    <p className="text-xs text-muted-foreground mt-0.5" data-testid={`text-check-reason-${c.check}`}>
                                      {c.reason}
                                    </p>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>

                        <div className="border rounded-md p-3 bg-muted/30 space-y-1">
                          <p className="text-xs font-medium text-muted-foreground">Investor Profile</p>
                          <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
                            <span className="text-muted-foreground">Country:</span>
                            <span data-testid="text-investor-country">{eligibility.summary.investorCountry ? ((COUNTRY_DETAILS as any)[eligibility.summary.investorCountry]?.name || eligibility.summary.investorCountry) : "Not set"}</span>
                            <span className="text-muted-foreground">Investor Type:</span>
                            <span className="capitalize" data-testid="text-investor-type">{eligibility.summary.investorType}</span>
                            <span className="text-muted-foreground">KYC Status:</span>
                            <span className="capitalize" data-testid="text-kyc-status">{eligibility.summary.kycStatus}</span>
                            <span className="text-muted-foreground">EDD Status:</span>
                            <span className="capitalize" data-testid="text-edd-status">{eligibility.summary.eddStatus}</span>
                          </div>
                        </div>

                        {eligibility.summary.countryPolicyNotes.length > 0 && (
                          <div className="border rounded-md p-3 bg-muted/30">
                            <p className="text-xs font-medium text-muted-foreground mb-1">Regulatory Notes</p>
                            <ul className="space-y-0.5">
                              {eligibility.summary.countryPolicyNotes.map((note, i) => (
                                <li key={i} className="text-xs text-muted-foreground flex items-start gap-1.5" data-testid={`text-policy-note-${i}`}>
                                  <Info className="w-3 h-3 mt-0.5 flex-shrink-0" />
                                  {note}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </>
                    ) : (
                      <p className="text-sm text-muted-foreground" data-testid="text-eligibility-error">Unable to load eligibility data.</p>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="data-room" className="space-y-4 mt-4">
                <DataRoomTab assetId={params.id || ""} />
              </TabsContent>

              {asset.constructionStatus && asset.constructionStatus !== "completed" && (
                <TabsContent value="construction" className="space-y-4 mt-4">
                  <ConstructionProgressTab assetId={params.id || ""} />
                </TabsContent>
              )}
            </Tabs>
          </div>

          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Investment Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between gap-2 text-sm">
                  <span className="text-muted-foreground">Token Price</span>
                  <span className="font-semibold" data-testid="sidebar-price">{currencySymbol} {parseFloat(asset.pricePerToken).toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between gap-2 text-sm">
                  <span className="text-muted-foreground">Currency</span>
                  <Badge variant="outline" className="text-xs no-default-hover-elevate">{baseCurrency}</Badge>
                </div>
                {asset.expectedRentalYield && parseFloat(asset.expectedRentalYield) > 0 && (
                  <div className="flex items-center justify-between gap-2 text-sm">
                    <span className="text-muted-foreground">Rental Yield</span>
                    <span className="font-semibold text-emerald-600 dark:text-emerald-400" data-testid="sidebar-rental-yield">{parseFloat(asset.expectedRentalYield).toFixed(2)}% p.a.</span>
                  </div>
                )}
                {asset.projectedCapitalAppreciation && parseFloat(asset.projectedCapitalAppreciation) > 0 && (
                  <div className="flex items-center justify-between gap-2 text-sm">
                    <span className="text-muted-foreground">Capital Growth</span>
                    <span className="font-semibold text-blue-600 dark:text-blue-400" data-testid="sidebar-capital-growth">{parseFloat(asset.projectedCapitalAppreciation).toFixed(2)}% p.a.</span>
                  </div>
                )}
                {asset.projectedTotalReturn && parseFloat(asset.projectedTotalReturn) > 0 && (
                  <div className="flex items-center justify-between gap-2 text-sm">
                    <span className="text-muted-foreground">Total Return</span>
                    <span className="font-semibold text-amber-600 dark:text-amber-400" data-testid="sidebar-total-return">{parseFloat(asset.projectedTotalReturn).toFixed(2)}% p.a.</span>
                  </div>
                )}
                {asset.distributionFrequency && (
                  <div className="flex items-center justify-between gap-2 text-sm">
                    <span className="text-muted-foreground">Distributions</span>
                    <span className="font-medium">{asset.distributionFrequency}</span>
                  </div>
                )}
                {asset.minInvestment && (
                  <div className="flex items-center justify-between gap-2 text-sm">
                    <span className="text-muted-foreground">Min Investment</span>
                    <span className="font-medium">{currencySymbol} {parseFloat(asset.minInvestment).toLocaleString()}</span>
                  </div>
                )}
                <div className="flex items-center justify-between gap-2 text-sm">
                  <span className="text-muted-foreground">Status</span>
                  <StatusBadge status={openRound?.status || "closed"} />
                </div>

                <div className="pt-2">
                  <GlassButton
                    variant="primary"
                    className="w-full"
                    disabled={isBlocked || !openRound}
                    onClick={handleInvestClick}
                    data-testid="button-invest-sidebar"
                  >
                    {!openRound ? "No Open Round" : isBlocked ? "Investing Restricted" : "Invest Now"}
                  </GlassButton>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Offering Progress</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between gap-2 text-sm">
                  <span className="text-muted-foreground">Total Raised</span>
                  <span className="font-semibold">{formatCurrency(asset.metrics.totalRaised, baseCurrency)}</span>
                </div>
                <div className="flex items-center justify-between gap-2 text-sm">
                  <span className="text-muted-foreground">Target</span>
                  <span className="font-medium">{formatCurrency(asset.metrics.totalTarget, baseCurrency)}</span>
                </div>
                <div className="w-full bg-muted rounded-sm h-2">
                  <div className="gradient-hero h-2 rounded-sm transition-all" style={{ width: `${asset.metrics.raisePercentage}%` }} />
                </div>
                <p className="text-xs text-muted-foreground text-center">{asset.metrics.raisePercentage}% funded</p>
              </CardContent>
            </Card>

            {asset.metrics.nextDistributionDate && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Next Distribution</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex items-center justify-between gap-2 text-sm">
                    <span className="text-muted-foreground">Date</span>
                    <span className="font-medium">{asset.metrics.nextDistributionDate}</span>
                  </div>
                  {asset.metrics.nextDistributionAmount && (
                    <div className="flex items-center justify-between gap-2 text-sm">
                      <span className="text-muted-foreground">Amount</span>
                      <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                        {formatCurrency(parseFloat(asset.metrics.nextDistributionAmount), baseCurrency)}
                      </span>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {asset.issuerName && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Issuer</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <p className="text-sm font-medium" data-testid="sidebar-issuer">{asset.issuerName}</p>
                  {asset.regulatoryBody && (
                    <p className="text-xs text-muted-foreground">Regulated by {asset.regulatoryBody}</p>
                  )}
                  {asset.legalStructure && (
                    <Badge variant="outline" className="text-xs no-default-hover-elevate">{asset.legalStructure}</Badge>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>

      <Dialog open={showInvestModal} onOpenChange={(open) => { if (!open) { setShowInvestModal(false); setPayWithCurrency(null); setFxQuote(null); } }}>
        <DialogContent className="sm:max-w-lg" data-testid="invest-modal">
          <DialogHeader>
            <DialogTitle>Invest in {asset.name}</DialogTitle>
            <DialogDescription>{asset.symbol} - {asset.assetType}</DialogDescription>
          </DialogHeader>

          {checkLoading ? (
            <div className="space-y-3">
              <Skeleton className="h-10 rounded-md" />
              <Skeleton className="h-20 rounded-md" />
            </div>
          ) : investCheck ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-2 text-sm">
                <span className="text-muted-foreground">Price per token</span>
                <span className="font-semibold" data-testid="text-price-per-token">{formatCurrency(pricePerToken, baseCurrency)}</span>
              </div>

              <div className="space-y-2">
                <Label>Pay with</Label>
                <div className="flex gap-2 flex-wrap">
                  <Button
                    variant={!isPayingWithOtherCurrency ? "default" : "outline"}
                    size="sm"
                    onClick={() => { setPayWithCurrency(null); setFxQuote(null); }}
                    data-testid="button-pay-base-currency"
                  >
                    {baseCurrency} ({formatCurrency(Math.max(0, investCheck.availableBalance), baseCurrency)})
                  </Button>
                  {investCheck.otherBalances.map(b => {
                    const detail = CURRENCY_DETAILS[b.currency as keyof typeof CURRENCY_DETAILS];
                    return (
                      <Button
                        key={b.currency}
                        variant={payWithCurrency === b.currency ? "default" : "outline"}
                        size="sm"
                        onClick={() => {
                          setPayWithCurrency(b.currency);
                          setFxQuote(null);
                          if (totalCost > 0 && b.fxRate) {
                            const neededInSource = totalCost / b.fxRate;
                            fetchFxQuote(b.currency, parseFloat(neededInSource.toFixed(2)));
                          }
                        }}
                        data-testid={`button-pay-${b.currency}`}
                      >
                        {b.currency} ({detail?.symbol || ""}{b.available.toFixed(2)})
                        {b.fxRate ? <ArrowRightLeft className="w-3 h-3 ml-1" /> : null}
                      </Button>
                    );
                  })}
                </div>
              </div>

              {isPayingWithOtherCurrency && selectedOtherBalance?.fxRate && (
                <div className="rounded-md border p-3 space-y-1.5 text-sm">
                  <div className="flex items-center gap-2 mb-1">
                    <ArrowRightLeft className="w-4 h-4 text-muted-foreground" />
                    <span className="font-medium" data-testid="text-fx-conversion-title">Currency Conversion</span>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-muted-foreground">Exchange rate</span>
                    <span data-testid="text-fx-rate">1 {payWithCurrency} = {selectedOtherBalance.fxRate.toFixed(4)} {baseCurrency}</span>
                  </div>
                  {selectedOtherBalance.fxSpread != null && selectedOtherBalance.fxSpread > 0 && (
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-muted-foreground">Spread</span>
                      <span data-testid="text-fx-spread">{(selectedOtherBalance.fxSpread * 100).toFixed(2)}%</span>
                    </div>
                  )}
                  {selectedOtherBalance.fxProvider && (
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-muted-foreground">Rate source</span>
                      <span className="text-xs" data-testid="text-fx-provider">{selectedOtherBalance.fxProvider}</span>
                    </div>
                  )}
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="invest-qty-detail">Number of tokens</Label>
                <Input
                  id="invest-qty-detail"
                  type="number"
                  min={investCheck?.minTokens != null ? investCheck.minTokens.toString() : (asset?.tokenDecimals != null ? (1 / Math.pow(10, asset.tokenDecimals)).toString() : "0.01")}
                  step={asset?.tokenDecimals != null ? (1 / Math.pow(10, asset.tokenDecimals)).toString() : "0.01"}
                  placeholder={investCheck?.minTokens != null ? `Min: ${investCheck.minTokens} tokens` : "e.g. 1, 0.5, 0.25"}
                  value={investQuantity}
                  onChange={(e) => {
                    setInvestQuantity(e.target.value);
                    const newQty = parseFloat(e.target.value) || 0;
                    const newCost = newQty * pricePerToken;
                    if (isPayingWithOtherCurrency && selectedOtherBalance?.fxRate && newCost > 0) {
                      const neededInSource = newCost / selectedOtherBalance.fxRate;
                      fetchFxQuote(payWithCurrency!, parseFloat(neededInSource.toFixed(2)));
                    } else if (isPayingWithOtherCurrency) {
                      setFxQuote(null);
                    }
                  }}
                  data-testid="input-invest-quantity"
                />
                <div className="space-y-1">
                  {investCheck?.minTokens != null && (
                    <p className="text-xs text-muted-foreground" data-testid="text-min-investment">
                      Min: {investCheck.minTokens} tokens ({formatCurrency(investCheck.minInvestment!, baseCurrency)})
                    </p>
                  )}
                  {investCheck?.maxTokens != null && (
                    <p className="text-xs text-muted-foreground" data-testid="text-max-investment">
                      Max: {investCheck.maxTokens} tokens ({formatCurrency(investCheck.maxInvestment!, baseCurrency)})
                    </p>
                  )}
                  {investCheck?.maxOwnershipPercent != null && (
                    <p className="text-xs text-muted-foreground" data-testid="text-max-ownership-limit">
                      Ownership limit: {investCheck.maxOwnershipPercent}% (up to {investCheck.remainingOwnershipCapacity} tokens remaining)
                    </p>
                  )}
                  {!investCheck?.minTokens && asset?.tokenDecimals != null && (
                    <p className="text-xs text-muted-foreground">
                      Minimum increment: {(1 / Math.pow(10, asset.tokenDecimals)).toFixed(asset.tokenDecimals)} tokens
                    </p>
                  )}
                </div>
              </div>

              {qty > 0 && (
                <div className="rounded-md border p-3 space-y-2">
                  <div className="flex items-center justify-between gap-2 text-sm">
                    <span className="text-muted-foreground">Total cost</span>
                    <span className="font-bold" data-testid="text-total-cost">{formatCurrency(totalCost, baseCurrency)}</span>
                  </div>

                  {isPayingWithOtherCurrency && fxQuoteLoading && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Getting conversion quote...</span>
                    </div>
                  )}

                  {isPayingWithOtherCurrency && fxQuote && !fxQuoteLoading && (
                    <div className="space-y-1.5 border-t pt-2 mt-1">
                      <div className="flex items-center justify-between gap-2 text-sm">
                        <span className="text-muted-foreground">You pay ({payWithCurrency})</span>
                        <span className="font-semibold" data-testid="text-fx-you-pay">{formatCurrency(parseFloat(fxQuote.amountFrom), payWithCurrency!)}</span>
                      </div>
                      <div className="flex items-center justify-between gap-2 text-sm">
                        <span className="text-muted-foreground">Converted to ({baseCurrency})</span>
                        <span data-testid="text-fx-converted">{formatCurrency(parseFloat(fxQuote.amountTo), baseCurrency)}</span>
                      </div>
                      {parseFloat(fxQuote.fees) > 0 && (
                        <div className="flex items-center justify-between gap-2 text-sm">
                          <span className="text-muted-foreground">Conversion fee ({(parseFloat(fxQuote.feeRate) * 100).toFixed(2)}%)</span>
                          <span data-testid="text-fx-fee">{formatCurrency(parseFloat(fxQuote.fees), baseCurrency)}</span>
                        </div>
                      )}
                      <div className="flex items-center justify-between gap-2 text-sm">
                        <span className="text-muted-foreground">Rate</span>
                        <span className="text-xs" data-testid="text-fx-applied-rate">1 {payWithCurrency} = {parseFloat(fxQuote.rate).toFixed(4)} {baseCurrency}</span>
                      </div>
                      {selectedOtherBalance && parseFloat(fxQuote.amountFrom) > selectedOtherBalance.available && (
                        <div className="flex items-start gap-2 text-sm mt-1">
                          <AlertTriangle className="w-4 h-4 text-destructive mt-0.5 flex-shrink-0" />
                          <span className="text-destructive" data-testid="warning-insufficient-source">
                            Insufficient {payWithCurrency} balance. You need {formatCurrency(parseFloat(fxQuote.amountFrom), payWithCurrency!)} but have {formatCurrency(selectedOtherBalance.available, payWithCurrency!)}.
                          </span>
                        </div>
                      )}
                      {selectedOtherBalance && parseFloat(fxQuote.amountFrom) <= selectedOtherBalance.available && (
                        <div className="flex items-center gap-2 text-sm text-emerald-600 dark:text-emerald-400 mt-1">
                          <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                          <span data-testid="text-fx-sufficient">Sufficient {payWithCurrency} balance for conversion</span>
                        </div>
                      )}
                    </div>
                  )}

                  {!isPayingWithOtherCurrency && (
                    <>
                      {isBelowMinimum && (
                        <div className="flex items-start gap-2 text-sm" data-testid="warning-below-minimum">
                          <AlertTriangle className="w-4 h-4 text-destructive mt-0.5 flex-shrink-0" />
                          <span className="text-destructive">
                            Below minimum investment. You need at least {investCheck!.minTokens} tokens ({formatCurrency(investCheck!.minInvestment!, baseCurrency)}).
                          </span>
                        </div>
                      )}
                      {isAboveMaximum && (
                        <div className="flex items-start gap-2 text-sm" data-testid="warning-above-maximum">
                          <AlertTriangle className="w-4 h-4 text-destructive mt-0.5 flex-shrink-0" />
                          <span className="text-destructive">
                            Above maximum investment. Maximum is {investCheck!.maxTokens} tokens ({formatCurrency(investCheck!.maxInvestment!, baseCurrency)}).
                          </span>
                        </div>
                      )}
                      {exceedsOwnershipLimit && (
                        <div className="flex items-start gap-2 text-sm" data-testid="warning-ownership-exceeded">
                          <AlertTriangle className="w-4 h-4 text-destructive mt-0.5 flex-shrink-0" />
                          <span className="text-destructive">
                            Exceeds {investCheck!.maxOwnershipPercent}% ownership limit. You can purchase up to {investCheck!.remainingOwnershipCapacity} more tokens.
                          </span>
                        </div>
                      )}
                      {!isBelowMinimum && !isAboveMaximum && !exceedsOwnershipLimit && !hasEnoughBalance && totalCost > 0 && (
                        <div className="flex items-start gap-2 text-sm">
                          <AlertTriangle className="w-4 h-4 text-destructive mt-0.5 flex-shrink-0" />
                          <span className="text-destructive">
                            You need {formatCurrency(shortfall, baseCurrency)} more in {baseCurrency}.
                            {investCheck!.otherBalances.length > 0 && " Try paying with another currency above."}
                          </span>
                        </div>
                      )}
                      {!isBelowMinimum && !isAboveMaximum && !exceedsOwnershipLimit && hasEnoughBalance && totalCost > 0 && (
                        <div className="flex items-center gap-2 text-sm text-emerald-600 dark:text-emerald-400">
                          <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                          <span>Sufficient balance available</span>
                        </div>
                      )}
                    </>
                  )}
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <Button variant="outline" className="flex-1" onClick={() => { setShowInvestModal(false); setPayWithCurrency(null); setFxQuote(null); }}>Cancel</Button>
                <GlassButton
                  variant="primary"
                  className="flex-1"
                  disabled={
                    qty <= 0 || !openRound || isBelowMinimum || isAboveMaximum || exceedsOwnershipLimit || investMutation.isPending || fxQuoteLoading ||
                    (isPayingWithOtherCurrency ? (!fxQuote || (selectedOtherBalance ? parseFloat(fxQuote.amountFrom) > selectedOtherBalance.available : true)) : !hasEnoughBalance)
                  }
                  onClick={handleConfirmInvest}
                  data-testid="button-confirm-invest"
                >
                  {investMutation.isPending ? "Processing..." : isPayingWithOtherCurrency ? `Convert & Invest` : "Confirm Investment"}
                </GlassButton>
              </div>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>

      <LegalAcceptanceModal
        open={showLegalModal}
        onClose={() => { setShowLegalModal(false); setLegalContext({}); }}
        onAccepted={() => { setShowLegalModal(false); setLegalContext({}); }}
        country={legalContext.country}
        vehicleType={legalContext.vehicleType}
      />
    </RoleLayout>
  );
}

function StatTile({ icon: Icon, label, value, testId }: { icon: any; label: string; value: string; testId: string }) {
  return (
    <Card>
      <CardContent className="p-3 text-center space-y-1">
        <Icon className="w-4 h-4 mx-auto text-muted-foreground" />
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-sm font-semibold" data-testid={testId}>{value}</p>
      </CardContent>
    </Card>
  );
}

function DetailRow({ icon: Icon, label, value, testId }: { icon: any; label: string; value: string | null | undefined; testId: string }) {
  if (!value) return null;
  return (
    <div className="flex items-start gap-2" data-testid={testId}>
      <Icon className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-sm font-medium break-words">{value}</p>
      </div>
    </div>
  );
}
