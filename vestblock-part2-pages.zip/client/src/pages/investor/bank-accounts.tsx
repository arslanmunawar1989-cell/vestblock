import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { addBankAccountSchema, type AddBankAccount, type BankAccount } from "@shared/schema";
import { DEFAULT_CURRENCY } from "@/lib/currencies";
import {
  Plus,
  Building2,
  CheckCircle2,
  Clock,
  XCircle,
  Pencil,
  Star, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
const STATUS_CONFIG: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline"; icon: typeof CheckCircle2 }> = {
  pending: { label: "Pending Verification", variant: "outline", icon: Clock },
  verified: { label: "Verified", variant: "default", icon: CheckCircle2 },
  rejected: { label: "Rejected", variant: "destructive", icon: XCircle },
};

const UAE_BANKS = [
  "Emirates NBD", "First Abu Dhabi Bank (FAB)", "Abu Dhabi Commercial Bank (ADCB)",
  "Dubai Islamic Bank", "Mashreq Bank", "RAKBANK", "Commercial Bank of Dubai",
  "Abu Dhabi Islamic Bank", "Sharjah Islamic Bank", "National Bank of Fujairah",
];

const PK_BANKS = [
  "Habib Bank Limited (HBL)", "United Bank Limited (UBL)", "MCB Bank",
  "Allied Bank", "Bank Alfalah", "Meezan Bank", "Faysal Bank",
  "Standard Chartered Pakistan", "Bank Al Habib", "Askari Bank",
];

export default function InvestorBankAccounts() {
  const { toast } = useToast();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingAccount, setEditingAccount] = useState<BankAccount | null>(null);

  const { data: accounts, isLoading } = useQuery<BankAccount[]>({
    queryKey: ["/api/bank-accounts"],
  });

  const form = useForm<AddBankAccount>({
    resolver: zodResolver(addBankAccountSchema),
    defaultValues: {
      country: "UAE",
      label: "",
      accountHolderName: "",
      iban: "",
      bankName: "",
      branchCode: "",
      accountNumber: "",
      swiftCode: "",
      currency: DEFAULT_CURRENCY,
      isDefault: false,
    },
  });

  const selectedCountry = form.watch("country");

  const createMutation = useMutation({
    mutationFn: async (data: AddBankAccount) => {
      const res = await apiRequest("POST", "/api/bank-accounts", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bank-accounts"] });
      setShowAddDialog(false);
      form.reset();
      toast({ title: "Bank account added", description: "Your bank account has been submitted for verification." });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to add bank account", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<AddBankAccount> }) => {
      const res = await apiRequest("PATCH", `/api/bank-accounts/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bank-accounts"] });
      setEditingAccount(null);
      form.reset();
      toast({ title: "Bank account updated", description: "Changes saved. Account status reset to pending verification." });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to update bank account", variant: "destructive" });
    },
  });

  const handleAdd = () => {
    form.reset({
      country: "UAE",
      label: "",
      accountHolderName: "",
      iban: "",
      bankName: "",
      branchCode: "",
      accountNumber: "",
      swiftCode: "",
      currency: DEFAULT_CURRENCY,
      isDefault: false,
    });
    setShowAddDialog(true);
  };

  const handleEdit = (account: BankAccount) => {
    form.reset({
      country: account.country as "UAE" | "PK",
      label: account.label,
      accountHolderName: account.accountHolderName,
      iban: account.iban || "",
      bankName: account.bankName,
      branchCode: account.branchCode || "",
      accountNumber: account.accountNumber || "",
      swiftCode: account.swiftCode || "",
      currency: account.currency as "AED" | "PKR",
      isDefault: account.isDefault,
    });
    setEditingAccount(account);
  };

  const onSubmit = (data: AddBankAccount) => {
    if (editingAccount) {
      updateMutation.mutate({ id: editingAccount.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const isDialogOpen = showAddDialog || !!editingAccount;
  const setDialogOpen = (open: boolean) => {
    if (!open) {
      setShowAddDialog(false);
      setEditingAccount(null);
    }
  };

  const bankList = selectedCountry === "UAE" ? UAE_BANKS : PK_BANKS;

  return (
    <RoleLayout role="investor">
      <div className="space-y-6">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <Link href="/investor/dashboard">
              <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <PageTitle
              title="Bank Accounts"
              description="Manage your bank accounts for withdrawals"
            />
          </div>
          <Button onClick={handleAdd} data-testid="button-add-bank-account">
            <Plus className="w-4 h-4 mr-1" />
            Add Bank Account
          </Button>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[...Array(2)].map((_, i) => (
              <Skeleton key={i} className="h-40 rounded-md" />
            ))}
          </div>
        ) : !accounts || accounts.length === 0 ? (
          <GlassCard data-testid="empty-bank-accounts">
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="w-14 h-14 rounded-md bg-muted flex items-center justify-center mb-4">
                <Building2 className="w-7 h-7 text-muted-foreground" />
              </div>
              <p className="text-lg font-semibold mb-1">No Bank Accounts</p>
              <p className="text-sm text-muted-foreground mb-4 max-w-md">
                Add a bank account to enable withdrawals from your wallet. You can add UAE (IBAN) or Pakistan bank accounts.
              </p>
              <Button onClick={handleAdd} data-testid="button-add-bank-account-empty">
                <Plus className="w-4 h-4 mr-1" />
                Add Your First Bank Account
              </Button>
            </div>
          </GlassCard>
        ) : (
          <Section title={`Your Bank Accounts (${accounts.length})`}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {accounts.map((account) => {
                const statusCfg = STATUS_CONFIG[account.status] || STATUS_CONFIG.pending;
                const StatusIcon = statusCfg.icon;
                return (
                  <GlassCard key={account.id} padding="md" data-testid={`bank-account-card-${account.id}`}>
                    <div className="flex items-start justify-between gap-2 flex-wrap mb-3">
                      <div className="flex items-center gap-2">
                        <div className="w-9 h-9 rounded-md bg-primary/10 flex items-center justify-center">
                          <Building2 className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <p className="text-sm font-semibold" data-testid={`bank-label-${account.id}`}>{account.label}</p>
                            {account.isDefault && (
                              <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground">{account.bankName}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <Badge variant={statusCfg.variant} className="no-default-hover-elevate" data-testid={`bank-status-${account.id}`}>
                          <StatusIcon className="w-3 h-3 mr-1" />
                          {statusCfg.label}
                        </Badge>
                      </div>
                    </div>

                    <div className="space-y-1.5 text-sm">
                      <DetailLine label="Country" value={account.country === "UAE" ? "United Arab Emirates" : "Pakistan"} />
                      <DetailLine label="Account Holder" value={account.accountHolderName} />
                      {account.iban && <DetailLine label="IBAN" value={account.iban} testId={`bank-iban-${account.id}`} />}
                      {account.accountNumber && <DetailLine label="Account Number" value={account.accountNumber} testId={`bank-accnum-${account.id}`} />}
                      {account.branchCode && <DetailLine label="Branch Code" value={account.branchCode} />}
                      {account.swiftCode && <DetailLine label="SWIFT Code" value={account.swiftCode} />}
                      <DetailLine label="Currency" value={account.currency} />
                    </div>

                    {account.status === "rejected" && account.verificationNotes && (
                      <div className="mt-3 p-2 rounded bg-destructive/5 border border-destructive/20">
                        <p className="text-xs text-destructive font-medium">Rejection Reason:</p>
                        <p className="text-xs text-muted-foreground mt-0.5" data-testid={`bank-rejection-${account.id}`}>{account.verificationNotes}</p>
                      </div>
                    )}

                    {account.status !== "verified" && (
                      <div className="mt-3 pt-3 border-t">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(account)}
                          data-testid={`button-edit-bank-${account.id}`}
                        >
                          <Pencil className="w-3.5 h-3.5 mr-1" />
                          Edit
                        </Button>
                      </div>
                    )}
                  </GlassCard>
                );
              })}
            </div>
          </Section>
        )}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" data-testid="bank-account-dialog">
          <DialogHeader>
            <DialogTitle>{editingAccount ? "Edit Bank Account" : "Add Bank Account"}</DialogTitle>
            <DialogDescription>
              {editingAccount
                ? "Update your bank account details. Editing will reset verification status."
                : "Add a UAE or Pakistan bank account for withdrawals."}
            </DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="country"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Country</FormLabel>
                    <Select
                      value={field.value}
                      onValueChange={(v) => {
                        field.onChange(v);
                        form.setValue("currency", v === "UAE" ? "AED" : "PKR");
                        form.setValue("bankName", "");
                        form.setValue("iban", "");
                        form.setValue("accountNumber", "");
                        form.setValue("branchCode", "");
                      }}
                    >
                      <FormControl>
                        <SelectTrigger data-testid="select-country">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="UAE">United Arab Emirates</SelectItem>
                        <SelectItem value="PK">Pakistan</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="label"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Label</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. My Savings Account" {...field} data-testid="input-label" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="accountHolderName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Account Holder Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Full name as on bank account" {...field} data-testid="input-holder-name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="bankName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Bank Name</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger data-testid="select-bank-name">
                          <SelectValue placeholder="Select bank" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {bankList.map((bank) => (
                          <SelectItem key={bank} value={bank}>{bank}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {selectedCountry === "UAE" && (
                <FormField
                  control={form.control}
                  name="iban"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>IBAN</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="AE07 0331 0000 0012 3456 789"
                          {...field}
                          value={field.value || ""}
                          data-testid="input-iban"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              {selectedCountry === "PK" && (
                <>
                  <FormField
                    control={form.control}
                    name="accountNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Account Number</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="e.g. 1234567890123"
                            {...field}
                            value={field.value || ""}
                            data-testid="input-account-number"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="branchCode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Branch Code</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="e.g. 0001"
                            {...field}
                            value={field.value || ""}
                            data-testid="input-branch-code"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </>
              )}

              <FormField
                control={form.control}
                name="swiftCode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>SWIFT/BIC Code (Optional)</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="e.g. EABORAEXXX"
                        {...field}
                        value={field.value || ""}
                        data-testid="input-swift-code"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="currency"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Currency</FormLabel>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <FormControl>
                        <SelectTrigger data-testid="select-currency">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="AED">AED - UAE Dirham</SelectItem>
                        <SelectItem value="PKR">PKR - Pakistani Rupee</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="isDefault"
                render={({ field }) => (
                  <FormItem className="flex items-center gap-2 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        data-testid="checkbox-default"
                      />
                    </FormControl>
                    <FormLabel className="text-sm font-normal cursor-pointer">
                      Set as default for this currency
                    </FormLabel>
                  </FormItem>
                )}
              />

              <div className="flex justify-end gap-2 pt-2">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)} data-testid="button-cancel-bank">
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  data-testid="button-submit-bank"
                >
                  {(createMutation.isPending || updateMutation.isPending) ? "Saving..." : editingAccount ? "Update Account" : "Add Account"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </RoleLayout>
  );
}

function DetailLine({ label, value, testId }: { label: string; value: string; testId?: string }) {
  return (
    <div className="flex items-center justify-between gap-2">
      <span className="text-muted-foreground text-xs">{label}</span>
      <span className="font-medium text-xs" data-testid={testId}>{value}</span>
    </div>
  );
}
