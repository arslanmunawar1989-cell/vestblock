import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { StatTile } from "@/components/stat-tile";
import { Section } from "@/components/section";
import { DataTable, type Column } from "@/components/data-table";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Banknote, Calendar, TrendingUp, ArrowRightLeft, Loader2, ArrowLeft,
} from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency, formatDate } from "@/lib/format";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
interface DistTx {
  id: string;
  amount: string;
  currency: string;
  status: string;
  description: string;
  date: string;
  metadata: any;
  referenceId: string;
}

const columns: Column<DistTx>[] = [
  {
    header: "Date",
    accessor: (row) => formatDate(row.date),
  },
  {
    header: "Asset",
    accessor: (row) => {
      const meta = row.metadata as any;
      return meta?.assetSymbol || "N/A";
    },
  },
  {
    header: "Amount",
    accessor: (row) => formatCurrency(row.amount, row.currency),
  },
  {
    header: "Currency",
    accessor: (row) => <Badge variant="outline" className="text-xs" data-testid={`badge-dist-currency-${row.id}`}>{row.currency}</Badge>,
  },
  {
    header: "Status",
    accessor: (row) => (
      <Badge
        variant={row.status === "COMPLETED" ? "default" : "secondary"}
        className="text-xs"
        data-testid={`badge-dist-status-${row.id}`}
      >
        {row.status === "COMPLETED" ? "Paid" : row.status}
      </Badge>
    ),
  },
];

export default function InvestorDistributions() {
  const { toast } = useToast();

  const { data: distTxs, isLoading } = useQuery<DistTx[]>({
    queryKey: ["/api/distributions/my"],
  });

  const { data: prefData } = useQuery<{ autoConvertDistributions: boolean }>({
    queryKey: ["/api/distributions/preference"],
  });

  const prefMutation = useMutation({
    mutationFn: async (autoConvert: boolean) => {
      const res = await apiRequest("PATCH", "/api/distributions/preference", {
        autoConvertDistributions: autoConvert,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/distributions/preference"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({ title: "Preference updated", description: "Your distribution auto-convert preference has been saved." });
    },
    onError: () => {
      toast({ title: "Update failed", description: "Could not save preference.", variant: "destructive" });
    },
  });

  const latestDist = distTxs?.[0];

  const totalsByCurrency: Record<string, number> = {};
  if (distTxs) {
    for (const t of distTxs) {
      totalsByCurrency[t.currency] = (totalsByCurrency[t.currency] || 0) + parseFloat(t.amount);
    }
  }
  const totalLines = Object.entries(totalsByCurrency).map(([cur, total]) => {
    return formatCurrency(total, cur);
  });
  const totalDisplay = totalLines.length > 0 ? totalLines.join(" + ") : "0.00";

  const distCount = distTxs?.length ?? 0;

  return (
    <RoleLayout role="investor">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/investor/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle title="Distributions" description="Track your earnings and payouts" />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <StatTile
            label="Total Received"
            value={totalDisplay}
            trend="up"
            icon={<Banknote className="w-5 h-5" />}
          />
          <StatTile
            label="Last Distribution"
            value={latestDist ? formatDate(latestDist.date, "short") : "None"}
            trend="neutral"
            icon={<Calendar className="w-5 h-5" />}
          />
          <StatTile
            label="Distributions"
            value={distCount.toString()}
            trend="up"
            icon={<TrendingUp className="w-5 h-5" />}
          />
        </div>

        <Card className="p-4" data-testid="card-auto-convert-preference">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-start gap-3">
              <ArrowRightLeft className="w-5 h-5 text-muted-foreground mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-medium" data-testid="text-auto-convert-label">
                  Auto-convert distributions to my primary currency
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Automatically convert distributions received in foreign currencies to your primary wallet currency at the current exchange rate
                </p>
              </div>
            </div>
            <Switch
              checked={prefData?.autoConvertDistributions ?? false}
              onCheckedChange={(v) => prefMutation.mutate(v)}
              disabled={prefMutation.isPending}
              data-testid="switch-auto-convert-distributions"
            />
          </div>
        </Card>

        <Section title="Distribution History">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
            </div>
          ) : distTxs && distTxs.length > 0 ? (
            <DataTable columns={columns} data={distTxs} />
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Banknote className="w-10 h-10 mx-auto mb-2 opacity-40" />
              <p className="text-sm">No distributions received yet</p>
              <p className="text-xs mt-1">Distributions from your investments will appear here</p>
            </div>
          )}
        </Section>
      </div>
    </RoleLayout>
  );
}
