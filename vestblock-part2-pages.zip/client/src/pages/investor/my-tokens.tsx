import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Coins, ArrowUpRight, ArrowDownLeft, Download, Loader2, Award, Clock, CheckCircle2, XCircle, AlertCircle, Info, ArrowLeft,
} from "lucide-react";
import { TOKEN_LEGAL_DISCLAIMERS, TOKEN_LEGAL_CLASSIFICATION } from "@shared/token-legal";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { Link } from "wouter";
interface TokenHolding {
  id: string;
  userId: string;
  tokenId: string;
  balance: string;
  updatedAt: string;
}

interface Token {
  id: string;
  tokenSymbol: string;
  shareClassId: string;
  decimals: number;
}

interface TokenTransfer {
  id: string;
  fromUserId: string;
  toUserId: string;
  tokenId: string;
  amount: string;
  status: string;
  reason: string | null;
  createdAt: string;
}

interface Certificate {
  id: string;
  tokenSymbol: string;
  investorName: string;
  balance: string;
  snapshotDate: string;
  verificationHash: string;
  createdAt: string;
  propertyTitle: string | null;
  propertyLocation: string | null;
  ownershipPercentage: string | null;
  spvName: string | null;
}

async function downloadPdf(certId: string, filename: string) {
  const resp = await fetch(`/api/tokenization/certificates/${certId}/download`, { credentials: "include" });
  if (!resp.ok) throw new Error(`Download failed (${resp.status})`);
  const blob = await resp.blob();
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

const statusConfig: Record<string, { label: string; icon: typeof CheckCircle2; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  pending: { label: "Pending", icon: Clock, variant: "secondary" },
  approved: { label: "Approved", icon: CheckCircle2, variant: "default" },
  completed: { label: "Completed", icon: CheckCircle2, variant: "default" },
  rejected: { label: "Rejected", icon: XCircle, variant: "destructive" },
};

export default function InvestorMyTokens() {
  const { toast } = useToast();
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [generatingTokenId, setGeneratingTokenId] = useState<string | null>(null);

  const { data: holdings = [], isLoading: holdingsLoading } = useQuery<TokenHolding[]>({
    queryKey: ["/api/tokenization/holdings"],
  });

  const { data: allTokens = [] } = useQuery<Token[]>({
    queryKey: ["/api/tokenization/tokens"],
  });

  const { data: transfers = [], isLoading: transfersLoading } = useQuery<TokenTransfer[]>({
    queryKey: ["/api/tokenization/transfers"],
  });

  const { data: certificates = [], isLoading: certsLoading } = useQuery<Certificate[]>({
    queryKey: ["/api/tokenization/certificates"],
  });

  const generateCertMutation = useMutation({
    mutationFn: async (tokenId: string) => {
      const res = await apiRequest("POST", "/api/tokenization/certificates/generate", { tokenId });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tokenization/certificates"] });
      toast({ title: "Certificate Generated", description: "Your ownership certificate is ready for download." });
      setGeneratingTokenId(null);
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
      setGeneratingTokenId(null);
    },
  });

  const tokenMap = new Map(allTokens.map((t) => [t.id, t]));

  const getTokenSymbol = (tokenId: string) => tokenMap.get(tokenId)?.tokenSymbol || tokenId.slice(0, 8);

  const activeHoldings = holdings.filter((h) => parseFloat(h.balance) > 0);

  const totalTokenValue = activeHoldings.reduce((sum, h) => sum + parseFloat(h.balance), 0);

  const handleGenerateCert = (tokenId: string) => {
    setGeneratingTokenId(tokenId);
    generateCertMutation.mutate(tokenId);
  };

  const handleDownload = async (cert: Certificate) => {
    setDownloadingId(cert.id);
    try {
      await downloadPdf(cert.id, `certificate_${cert.tokenSymbol}_${cert.snapshotDate}.pdf`);
    } catch {
      toast({ title: "Download Failed", description: "Could not download certificate.", variant: "destructive" });
    } finally {
      setDownloadingId(null);
    }
  };

  return (
    <RoleLayout role="investor">
      <div className="flex items-center gap-3">
        <Link href="/investor/dashboard">
          <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <PageTitle title="My Tokens" />
      </div>
      <Section>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <Card data-testid="card-total-tokens">
            <CardContent className="pt-6">
              <div className="text-sm text-muted-foreground">Total Token Types</div>
              <div className="text-2xl font-bold mt-1" data-testid="text-total-token-types">{activeHoldings.length}</div>
            </CardContent>
          </Card>
          <Card data-testid="card-total-balance">
            <CardContent className="pt-6">
              <div className="text-sm text-muted-foreground">Total Token Balance</div>
              <div className="text-2xl font-bold mt-1" data-testid="text-total-balance">{totalTokenValue.toFixed(2)}</div>
            </CardContent>
          </Card>
          <Card data-testid="card-certificates-count">
            <CardContent className="pt-6">
              <div className="text-sm text-muted-foreground">Certificates Issued</div>
              <div className="text-2xl font-bold mt-1" data-testid="text-certificates-count">{certificates.length}</div>
            </CardContent>
          </Card>
        </div>

        <div className="flex items-start gap-3 p-4 border rounded-md bg-muted/30 mb-6" data-testid="notice-token-legal">
          <Info className="w-4 h-4 mt-0.5 text-muted-foreground flex-shrink-0" />
          <div className="space-y-1">
            <p className="text-xs font-medium text-muted-foreground">{TOKEN_LEGAL_CLASSIFICATION.positiveDescriptor}s</p>
            <p className="text-xs text-muted-foreground">{TOKEN_LEGAL_DISCLAIMERS.investorFacing}</p>
          </div>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Coins className="w-5 h-5" />
              Ownership Units
            </CardTitle>
          </CardHeader>
          <CardContent>
            {holdingsLoading ? (
              <div className="flex items-center gap-2 text-muted-foreground" data-testid="loading-holdings">
                <Loader2 className="w-4 h-4 animate-spin" />
                Loading token balances...
              </div>
            ) : activeHoldings.length === 0 ? (
              <p className="text-muted-foreground" data-testid="text-no-holdings">
                You don't hold any tokens yet. Invest in assets to receive token allocations.
              </p>
            ) : (
              <div className="space-y-3">
                {activeHoldings.map((holding) => {
                  const symbol = getTokenSymbol(holding.tokenId);
                  return (
                    <div
                      key={holding.id}
                      className="flex items-center justify-between gap-4 p-4 border rounded-md flex-wrap"
                      data-testid={`holding-row-${holding.tokenId}`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <Coins className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <div className="font-medium" data-testid={`holding-symbol-${holding.tokenId}`}>
                            {symbol}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            Updated: {holding.updatedAt ? new Date(holding.updatedAt).toLocaleDateString() : "N/A"}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 flex-wrap">
                        <div className="text-right">
                          <div className="text-lg font-bold" data-testid={`holding-balance-${holding.tokenId}`}>
                            {parseFloat(holding.balance).toFixed(2)}
                          </div>
                          <div className="text-xs text-muted-foreground">tokens</div>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleGenerateCert(holding.tokenId)}
                          disabled={generatingTokenId === holding.tokenId}
                          data-testid={`button-gen-cert-${holding.tokenId}`}
                        >
                          {generatingTokenId === holding.tokenId ? (
                            <Loader2 className="w-4 h-4 animate-spin mr-1" />
                          ) : (
                            <Award className="w-4 h-4 mr-1" />
                          )}
                          Certificate
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ArrowUpRight className="w-5 h-5" />
              Transfer History
            </CardTitle>
          </CardHeader>
          <CardContent>
            {transfersLoading ? (
              <div className="flex items-center gap-2 text-muted-foreground" data-testid="loading-transfers">
                <Loader2 className="w-4 h-4 animate-spin" />
                Loading transfer history...
              </div>
            ) : transfers.length === 0 ? (
              <p className="text-muted-foreground" data-testid="text-no-transfers">
                No token transfers yet.
              </p>
            ) : (
              <div className="space-y-3">
                {transfers.map((transfer) => {
                  const symbol = getTokenSymbol(transfer.tokenId);
                  const isSender = transfer.fromUserId !== transfer.toUserId;
                  const statusCfg = statusConfig[transfer.status] || statusConfig.pending;
                  const StatusIcon = statusCfg.icon;
                  return (
                    <div
                      key={transfer.id}
                      className="flex items-center justify-between gap-4 p-4 border rounded-md flex-wrap"
                      data-testid={`transfer-row-${transfer.id}`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center flex-shrink-0">
                          {isSender ? (
                            <ArrowUpRight className="w-5 h-5 text-orange-500" />
                          ) : (
                            <ArrowDownLeft className="w-5 h-5 text-green-500" />
                          )}
                        </div>
                        <div>
                          <div className="font-medium" data-testid={`transfer-symbol-${transfer.id}`}>
                            {symbol}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {transfer.createdAt ? new Date(transfer.createdAt).toLocaleString() : "N/A"}
                          </div>
                          {transfer.reason && (
                            <div className="text-xs text-muted-foreground mt-1">
                              {transfer.reason}
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-3 flex-wrap">
                        <div className="text-right">
                          <div className="text-lg font-bold" data-testid={`transfer-amount-${transfer.id}`}>
                            {parseFloat(transfer.amount).toFixed(2)}
                          </div>
                          <div className="text-xs text-muted-foreground">tokens</div>
                        </div>
                        <Badge variant={statusCfg.variant} data-testid={`transfer-status-${transfer.id}`}>
                          <StatusIcon className="w-3 h-3 mr-1" />
                          {statusCfg.label}
                        </Badge>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="w-5 h-5" />
              Ownership Certificates
            </CardTitle>
          </CardHeader>
          <CardContent>
            {certsLoading ? (
              <div className="flex items-center gap-2 text-muted-foreground" data-testid="loading-certificates">
                <Loader2 className="w-4 h-4 animate-spin" />
                Loading certificates...
              </div>
            ) : certificates.length === 0 ? (
              <p className="text-muted-foreground" data-testid="text-no-certificates">
                No certificates generated yet. Click "Certificate" next to a token balance above.
              </p>
            ) : (
              <div className="space-y-3">
                {certificates.map((cert) => (
                  <div
                    key={cert.id}
                    className="flex items-center justify-between gap-4 p-4 border rounded-md flex-wrap"
                    data-testid={`cert-row-${cert.id}`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Award className="w-5 h-5 text-primary" />
                      </div>
                      <div className="min-w-0">
                        <div className="font-medium flex items-center gap-2 flex-wrap" data-testid={`cert-symbol-${cert.id}`}>
                          {cert.tokenSymbol}
                          <Badge variant="secondary">{parseFloat(cert.balance).toFixed(2)} tokens</Badge>
                          {cert.ownershipPercentage && (
                            <Badge variant="outline">{parseFloat(cert.ownershipPercentage).toFixed(2)}% ownership</Badge>
                          )}
                        </div>
                        {cert.propertyTitle && (
                          <div className="text-sm font-medium mt-0.5">
                            {cert.propertyTitle}
                            {cert.propertyLocation && <span className="text-muted-foreground"> - {cert.propertyLocation}</span>}
                          </div>
                        )}
                        <div className="text-sm text-muted-foreground" data-testid={`cert-date-${cert.id}`}>
                          Snapshot: {cert.snapshotDate}
                        </div>
                        <div className="text-xs text-muted-foreground font-mono truncate max-w-[300px]" data-testid={`cert-hash-${cert.id}`}>
                          Hash: {cert.verificationHash.substring(0, 24)}...
                        </div>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => handleDownload(cert)}
                      disabled={downloadingId === cert.id}
                      data-testid={`button-download-${cert.id}`}
                    >
                      {downloadingId === cert.id ? (
                        <Loader2 className="w-4 h-4 animate-spin mr-1" />
                      ) : (
                        <Download className="w-4 h-4 mr-1" />
                      )}
                      Download PDF
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </Section>
    </RoleLayout>
  );
}
