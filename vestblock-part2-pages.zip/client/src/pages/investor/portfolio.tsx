import { useQuery } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { StatTile } from "@/components/stat-tile";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Link } from "wouter";
import {
  PieChart,
  BarChart3,
  ArrowUpRight,
  TrendingUp,
  TrendingDown,
  Download,
  FileText,
  Banknote,
  DollarSign,
  Percent, ArrowLeft,
} from "lucide-react";
import { formatCurrency } from "@/lib/format";
import { DEFAULT_CURRENCY } from "@/lib/currencies";

interface AnalyticsData {
  overview: {
    totalInvested: string;
    currentPortfolioValue: string;
    totalDistributionsReceived: string;
    unrealizedGain: string;
    totalReturn: string;
    roiPercent: string;
    rentalYieldPercent?: string;
    totalFees?: string;
    holdingsCount: number;
  };
  holdings: {
    tokenId: string;
    assetId: string;
    assetName: string;
    assetSymbol: string;
    baseCurrency: string;
    balance: string;
    pricePerToken: string;
    currentValue: string;
    costBasis: string;
    unrealizedGain: string;
    unrealizedGainPercent: string;
    propertyType: string | null;
    location: string | null;
  }[];
}

async function downloadStatement(type: string, format: string) {
  try {
    const url = `/api/investor/statements/${type}?format=${format}`;
    const res = await fetch(url, { credentials: "include" });
    if (!res.ok) throw new Error("Download failed");
    const blob = await res.blob();
    const blobUrl = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = blobUrl;
    a.download = `${type}-statement.${format}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(blobUrl);
  } catch {
    alert("Failed to download statement. Please try again.");
  }
}

function StatementDownloadButton({ type, label }: { type: string; label: string }) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" data-testid={`button-download-${type}`}>
          <Download className="w-3.5 h-3.5 mr-1.5" />
          {label}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => downloadStatement(type, "csv")} data-testid={`button-download-${type}-csv`}>
          <FileText className="w-3.5 h-3.5 mr-2" />
          Download CSV
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => downloadStatement(type, "pdf")} data-testid={`button-download-${type}-pdf`}>
          <FileText className="w-3.5 h-3.5 mr-2" />
          Download PDF
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export default function InvestorPortfolio() {
  const { data, isLoading } = useQuery<AnalyticsData>({
    queryKey: ["/api/investor/analytics"],
  });

  const overview = data?.overview;
  const holdings = data?.holdings || [];

  const totalValue = overview ? parseFloat(overview.currentPortfolioValue) : 0;
  const totalInvested = overview ? parseFloat(overview.totalInvested) : 0;
  const totalGain = overview ? parseFloat(overview.unrealizedGain) : 0;
  const gainPercent = overview ? parseFloat(overview.roiPercent) : 0;
  const totalDistributions = overview ? parseFloat(overview.totalDistributionsReceived) : 0;
  const totalReturn = overview ? parseFloat(overview.totalReturn) : 0;
  const holdingsCount = overview?.holdingsCount || 0;
  const rentalYield = overview?.rentalYieldPercent ? parseFloat(overview.rentalYieldPercent) : 0;
  const baseCur = holdings[0]?.baseCurrency || DEFAULT_CURRENCY;

  return (
    <RoleLayout role="investor">
      <div className="space-y-6">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <Link href="/investor/dashboard">
              <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <PageTitle title="Portfolio Analytics" description="Track your investments, income, and capital performance" />
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <StatementDownloadButton type="holdings" label="Holdings" />
            <StatementDownloadButton type="rental-income" label="Rental Income" />
            <StatementDownloadButton type="capital-gains" label="Capital Gains" />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {isLoading ? (
            <>
              {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-20 w-full" />)}
            </>
          ) : (
            <>
              <StatTile
                label="Total Invested"
                value={totalInvested > 0 ? formatCurrency(totalInvested, baseCur) : formatCurrency(0, baseCur)}
                trend="neutral"
                icon={<DollarSign className="w-5 h-5" />}
              />
              <StatTile
                label="Portfolio Value"
                value={totalValue > 0 ? formatCurrency(totalValue, baseCur) : formatCurrency(0, baseCur)}
                change={gainPercent !== 0 ? `${gainPercent >= 0 ? "+" : ""}${gainPercent.toFixed(1)}%` : undefined}
                trend={gainPercent > 0 ? "up" : gainPercent < 0 ? "down" : "neutral"}
                icon={<PieChart className="w-5 h-5" />}
              />
              <StatTile
                label="Total Return"
                value={totalReturn !== 0 ? formatCurrency(totalReturn, baseCur) : formatCurrency(0, baseCur)}
                change={gainPercent !== 0 ? `${gainPercent >= 0 ? "+" : ""}${gainPercent.toFixed(1)}% ROI` : undefined}
                trend={totalReturn > 0 ? "up" : totalReturn < 0 ? "down" : "neutral"}
                icon={<TrendingUp className="w-5 h-5" />}
              />
              <StatTile
                label="Distributions"
                value={totalDistributions > 0 ? formatCurrency(totalDistributions, baseCur) : formatCurrency(0, baseCur)}
                change={rentalYield > 0 ? `${rentalYield.toFixed(1)}% yield` : undefined}
                trend={totalDistributions > 0 ? "up" : "neutral"}
                icon={<Banknote className="w-5 h-5" />}
              />
            </>
          )}
        </div>

        {!isLoading && holdingsCount > 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <Card>
              <CardContent className="pt-4">
                <div className="flex items-center gap-2 mb-2">
                  <BarChart3 className="w-4 h-4 text-muted-foreground" />
                  <span className="text-xs font-medium text-muted-foreground">Unrealized Gain/Loss</span>
                </div>
                <p className={`text-2xl font-bold tracking-tight ${totalGain >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-red-500 dark:text-red-400"}`} data-testid="text-unrealized-gain">
                  {totalGain >= 0 ? "+" : ""}{formatCurrency(totalGain, baseCur)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {gainPercent >= 0 ? "+" : ""}{gainPercent.toFixed(2)}% on invested capital
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-4">
                <div className="flex items-center gap-2 mb-2">
                  <Percent className="w-4 h-4 text-muted-foreground" />
                  <span className="text-xs font-medium text-muted-foreground">Rental Yield</span>
                </div>
                <p className="text-2xl font-bold tracking-tight" data-testid="text-rental-yield">
                  {rentalYield.toFixed(2)}%
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Based on distributions received
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-4">
                <div className="flex items-center gap-2 mb-2">
                  <ArrowUpRight className="w-4 h-4 text-muted-foreground" />
                  <span className="text-xs font-medium text-muted-foreground">Assets Held</span>
                </div>
                <p className="text-2xl font-bold tracking-tight" data-testid="text-holdings-count">
                  {holdingsCount}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Across your portfolio
                </p>
              </CardContent>
            </Card>
          </div>
        )}

        <Section title="Holdings">
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => <Skeleton key={i} className="h-24 w-full" />)}
            </div>
          ) : holdings.length === 0 ? (
            <div className="text-center py-12">
              <PieChart className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground">No holdings yet</p>
              <p className="text-sm text-muted-foreground mt-1">
                Visit the <Link href="/investor/marketplace" className="underline">marketplace</Link> to start investing
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {holdings.map((item, i) => {
                const gain = parseFloat(item.unrealizedGain);
                const gainPct = parseFloat(item.unrealizedGainPercent);
                const isPositive = gain >= 0;

                return (
                  <Link key={item.tokenId} href={`/investor/marketplace/${item.assetId}`}>
                    <GlassCard className="hover-elevate cursor-pointer">
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-md gradient-hero flex items-center justify-center flex-shrink-0">
                            <span className="text-white font-bold">{item.assetName[0]}</span>
                          </div>
                          <div>
                            <p className="font-semibold text-sm" data-testid={`portfolio-name-${i}`}>{item.assetName}</p>
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-xs text-muted-foreground">{parseFloat(item.balance).toLocaleString()} tokens</span>
                              <Badge variant="secondary" className="text-xs">{item.assetSymbol}</Badge>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          {isPositive ? (
                            <TrendingUp className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                          ) : (
                            <TrendingDown className="w-3.5 h-3.5 text-red-600 dark:text-red-400" />
                          )}
                          <span className={`text-xs font-semibold ${isPositive ? "text-emerald-600 dark:text-emerald-400" : "text-red-600 dark:text-red-400"}`} data-testid={`portfolio-change-${i}`}>
                            {isPositive ? "+" : ""}{gainPct.toFixed(1)}%
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between gap-2 text-sm">
                        <div>
                          <p className="text-xs text-muted-foreground">Cost Basis</p>
                          <p className="font-medium" data-testid={`portfolio-cost-${i}`}>{formatCurrency(item.costBasis, item.baseCurrency)}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Token Price</p>
                          <p className="font-medium" data-testid={`portfolio-price-${i}`}>{formatCurrency(item.pricePerToken, item.baseCurrency)}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground">Current Value</p>
                          <p className="font-semibold" data-testid={`portfolio-value-${i}`}>{formatCurrency(item.currentValue, item.baseCurrency)}</p>
                        </div>
                      </div>
                    </GlassCard>
                  </Link>
                );
              })}
            </div>
          )}
        </Section>
      </div>
    </RoleLayout>
  );
}
