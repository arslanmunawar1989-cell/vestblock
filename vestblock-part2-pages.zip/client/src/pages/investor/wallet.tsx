import { useState, useMemo, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { GlassButton } from "@/components/glass-button";
import { LegalAcceptanceModal, useLegalAcceptance } from "@/components/legal-acceptance-modal";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { WALLET_CURRENCIES, CURRENCY_DETAILS } from "@shared/constants";
import type { WalletCurrency } from "@shared/constants";
import { DEFAULT_CURRENCY } from "@/lib/currencies";
import {
  Wallet as WalletIcon,
  Plus,
  ShieldAlert,
  FileText,
  Download,
  Clock,
  Search,
  ChevronLeft,
  ChevronRight,
  Building2,
  Send,
  ArrowRightLeft, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/lib/auth";
import { formatCurrency, formatDate } from "@/lib/format";

interface WalletAccountWithBalance {
  id: string;
  userId: string;
  currency: string;
  createdAt: string;
  available: string;
  pending: string;
}

interface WalletTx {
  id: string;
  walletAccountId: string;
  type: string;
  amount: string;
  currency: string;
  status: string;
  referenceId: string | null;
  description: string | null;
  metadata: Record<string, any> | null;
  createdAt: string;
}

interface EddStatusResponse {
  eddStatus: string;
  isBlocked: boolean;
  activeFlagCount: number;
}

interface WithdrawalEligibility {
  eligible: boolean;
  verifiedAccountCount: number;
  accounts: { id: string; label: string; bankName: string; currency: string }[];
}

interface WithdrawalRequestItem {
  id: string;
  amount: string;
  currency: string;
  reason: string;
  fee: string;
  netAmount: string;
  status: string;
  requestedAt: string;
  reviewNotes: string | null;
  payoutReference: string | null;
  paidAt: string | null;
  bankAccount: { id: string; label: string; bankName: string; currency: string } | null;
}

const WITHDRAWAL_STATUS_VARIANT: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
  REQUESTED: "outline",
  APPROVED: "default",
  DECLINED: "destructive",
  PAID: "secondary",
};

const TX_TYPE_LABELS: Record<string, string> = {
  DEPOSIT: "Deposit",
  WITHDRAW: "Withdrawal",
  INVEST_RESERVE: "Investment Reserve",
  INVEST_CAPTURE: "Investment Capture",
  REFUND: "Refund",
  DIVIDEND: "Dividend",
  FEE: "Fee",
  FX_CONVERT: "FX Conversion",
  TRADE_BUY: "Trade Buy",
  TRADE_SELL: "Trade Sell",
  CRYPTO_DEPOSIT: "Crypto Deposit",
};

const TX_TYPE_COLORS: Record<string, string> = {
  DEPOSIT: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400",
  WITHDRAW: "bg-red-500/10 text-red-700 dark:text-red-400",
  INVEST_RESERVE: "bg-blue-500/10 text-blue-700 dark:text-blue-400",
  INVEST_CAPTURE: "bg-blue-500/10 text-blue-700 dark:text-blue-400",
  REFUND: "bg-amber-500/10 text-amber-700 dark:text-amber-400",
  DIVIDEND: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400",
  FEE: "bg-red-500/10 text-red-700 dark:text-red-400",
  FX_CONVERT: "bg-purple-500/10 text-purple-700 dark:text-purple-400",
  TRADE_BUY: "bg-blue-500/10 text-blue-700 dark:text-blue-400",
  TRADE_SELL: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400",
  CRYPTO_DEPOSIT: "bg-orange-500/10 text-orange-700 dark:text-orange-400",
};

const CREDIT_TYPES = ["DEPOSIT", "REFUND", "DIVIDEND", "TRADE_SELL", "CRYPTO_DEPOSIT"];

const STATUS_VARIANT: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
  COMPLETED: "default",
  PENDING: "outline",
  FAILED: "destructive",
  CANCELLED: "secondary",
};

const PAGE_SIZE = 10;

export default function InvestorWallet() {
  const { toast } = useToast();
  const { defaultCurrency } = useAuth();
  const userCurrency = (defaultCurrency || DEFAULT_CURRENCY) as WalletCurrency;
  const [showLegalModal, setShowLegalModal] = useState(false);
  const [selectedTx, setSelectedTx] = useState<WalletTx | null>(null);
  const [typeFilter, setTypeFilter] = useState("ALL");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [currencyFilter, setCurrencyFilter] = useState("ALL");
  const [searchQuery, setSearchQuery] = useState("");
  const [page, setPage] = useState(1);
  const [activeTab, setActiveTab] = useState<string>(userCurrency);
  const [showWithdrawDialog, setShowWithdrawDialog] = useState(false);
  const [withdrawCurrency, setWithdrawCurrency] = useState<string>(userCurrency);
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [withdrawBankId, setWithdrawBankId] = useState("");
  const [withdrawReason, setWithdrawReason] = useState<"PROFIT" | "CAPITAL">("PROFIT");
  const [showConvertDialog, setShowConvertDialog] = useState(false);
  const [convertFrom, setConvertFrom] = useState<string>(userCurrency);
  const [convertTo, setConvertTo] = useState<string>(userCurrency === "PKR" ? DEFAULT_CURRENCY : "PKR");
  const [convertAmount, setConvertAmount] = useState("");
  const [currencyInitialized, setCurrencyInitialized] = useState(false);

  useEffect(() => {
    if (defaultCurrency && !currencyInitialized) {
      const cur = defaultCurrency as WalletCurrency;
      setActiveTab(cur);
      setWithdrawCurrency(cur);
      setConvertFrom(cur);
      setConvertTo(cur === "PKR" ? DEFAULT_CURRENCY : "PKR");
      setCurrencyInitialized(true);
    }
  }, [defaultCurrency, currencyInitialized]);

  const { data: eddData } = useQuery<EddStatusResponse>({
    queryKey: ["/api/edd-status"],
  });

  const { data: accounts, isLoading: accountsLoading } = useQuery<WalletAccountWithBalance[]>({
    queryKey: ["/api/wallet/accounts"],
  });

  const { data: allTransactions, isLoading: txLoading } = useQuery<WalletTx[]>({
    queryKey: ["/api/wallet/transactions"],
  });

  const { data: withdrawalEligibility } = useQuery<WithdrawalEligibility>({
    queryKey: ["/api/withdrawal-eligibility"],
  });

  const { data: withdrawalRequests } = useQuery<WithdrawalRequestItem[]>({
    queryKey: ["/api/withdrawals"],
  });

  interface WithdrawalAvailability {
    currency: string;
    walletBalance: string;
    profit: {
      total: string;
      unlocked: string;
      locked: string;
      pendingWithdrawals: string;
      available: string;
      lockDays: number;
      nextUnlockDate: string | null;
    };
    capital: {
      total: string;
      unlocked: string;
      locked: string;
      pendingWithdrawals: string;
      available: string;
      lockDays: number;
      nextUnlockDate: string | null;
    };
    rules: {
      profitLockDays: number;
      capitalLockDays: number;
    };
  }

  const { data: withdrawAvailability } = useQuery<WithdrawalAvailability>({
    queryKey: ["/api/wallet/withdrawal-availability", withdrawCurrency],
    enabled: showWithdrawDialog,
    queryFn: async () => {
      const res = await fetch(`/api/wallet/withdrawal-availability?currency=${withdrawCurrency}`);
      if (!res.ok) throw new Error("Failed to fetch availability");
      return res.json();
    },
  });

  interface FxTransactionItem {
    id: string;
    userId: string;
    quoteId: string;
    fromCurrency: string;
    toCurrency: string;
    amountFrom: string;
    amountTo: string;
    rateUsed: string;
    spread: string;
    fees: string;
    status: string;
    referenceId: string | null;
    createdAt: string;
  }

  const { data: fxHistory } = useQuery<FxTransactionItem[]>({
    queryKey: ["/api/fx/transactions"],
  });

  interface FeePreview {
    grossAmount: number;
    fee: number;
    netAmount: number;
    feeRate: number;
    method: string;
  }

  const withdrawAmountNum = parseFloat(withdrawAmount);
  const { data: feePreview } = useQuery<FeePreview>({
    queryKey: ["/api/fees/preview", "withdrawal", withdrawAmountNum, withdrawCurrency],
    enabled: !isNaN(withdrawAmountNum) && withdrawAmountNum > 0 && showWithdrawDialog,
    queryFn: async () => {
      const res = await fetch(`/api/fees/preview?feeType=withdrawal&amount=${withdrawAmountNum}&currency=${withdrawCurrency}`);
      if (!res.ok) throw new Error("Failed to preview fee");
      return res.json();
    },
  });

  const withdrawMutation = useMutation({
    mutationFn: async (data: { bankAccountId: string; amount: number; currency: string; reason: "PROFIT" | "CAPITAL" }) => {
      const res = await apiRequest("POST", "/api/withdrawals", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/withdrawals"] });
      queryClient.invalidateQueries({ queryKey: ["/api/wallet/accounts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/wallet/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/wallet/withdrawal-availability"] });
      setShowWithdrawDialog(false);
      setWithdrawAmount("");
      setWithdrawBankId("");
      setWithdrawReason("PROFIT");
      toast({ title: "Withdrawal Requested", description: "Your withdrawal request has been submitted for review." });
    },
    onError: (err: any) => {
      toast({ title: "Withdrawal Failed", description: err.message || "Could not process withdrawal request", variant: "destructive" });
    },
  });

  interface FxQuoteResponse {
    id: string;
    fromCurrency: string;
    toCurrency: string;
    amountFrom: string;
    rate: string;
    spread: string;
    fees: string;
    feeRate: string;
    amountTo: string;
    provider: string;
    status: string;
    expiresAt: string;
  }

  const convertAmountNum = parseFloat(convertAmount);
  const { data: fxQuote, isLoading: fxQuoteLoading } = useQuery<FxQuoteResponse>({
    queryKey: ["/api/fx/quote", convertFrom, convertTo, convertAmountNum],
    enabled: !isNaN(convertAmountNum) && convertAmountNum > 0 && showConvertDialog && convertFrom !== convertTo,
    queryFn: async () => {
      const res = await apiRequest("POST", "/api/fx/quote", {
        fromCurrency: convertFrom,
        toCurrency: convertTo,
        amount: convertAmountNum,
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ message: "Failed to get quote" }));
        throw new Error(err.message || "Failed to get FX quote");
      }
      return res.json();
    },
  });

  const convertMutation = useMutation({
    mutationFn: async (data: { quoteId: string }) => {
      const res = await apiRequest("POST", "/api/fx/convert", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/wallet/accounts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/wallet/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/fx/transactions"] });
      setShowConvertDialog(false);
      setConvertAmount("");
      toast({ title: "Conversion Complete", description: `Your ${convertFrom} has been converted to ${convertTo} successfully.` });
    },
    onError: (err: any) => {
      toast({ title: "Conversion Failed", description: err.message || "Could not complete currency conversion", variant: "destructive" });
    },
  });

  const { allAccepted, pendingCount } = useLegalAcceptance();
  const isEddBlocked = eddData?.isBlocked ?? false;
  const isLegalBlocked = !allAccepted && pendingCount > 0;
  const isBlocked = isEddBlocked || isLegalBlocked;
  const hasVerifiedBank = withdrawalEligibility?.eligible ?? false;

  const accountsByCurrency = useMemo(() => {
    const map: Record<string, WalletAccountWithBalance | undefined> = {};
    for (const cur of WALLET_CURRENCIES) {
      map[cur] = accounts?.find((a) => a.currency === cur);
    }
    return map;
  }, [accounts]);

  const currenciesWithBalance = useMemo(() => {
    return WALLET_CURRENCIES.filter(cur => {
      const acc = accountsByCurrency[cur];
      return acc && (parseFloat(acc.available) !== 0 || parseFloat(acc.pending) !== 0);
    });
  }, [accountsByCurrency]);

  const displayCurrencies = useMemo(() => {
    const withBalance = new Set(currenciesWithBalance);
    withBalance.add(userCurrency);
    return WALLET_CURRENCIES.filter(c => withBalance.has(c));
  }, [currenciesWithBalance, userCurrency]);

  const filteredTransactions = useMemo(() => {
    if (!allTransactions) return [];
    let filtered = allTransactions;
    if (activeTab !== "ALL") {
      filtered = filtered.filter((tx) => tx.currency === activeTab);
    }
    if (typeFilter !== "ALL") {
      filtered = filtered.filter((tx) => tx.type === typeFilter);
    }
    if (statusFilter !== "ALL") {
      filtered = filtered.filter((tx) => tx.status === statusFilter);
    }
    if (currencyFilter !== "ALL") {
      filtered = filtered.filter((tx) => tx.currency === currencyFilter);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (tx) =>
          (tx.description?.toLowerCase().includes(q)) ||
          (tx.referenceId?.toLowerCase().includes(q)) ||
          tx.type.toLowerCase().includes(q)
      );
    }
    return filtered;
  }, [allTransactions, activeTab, typeFilter, statusFilter, currencyFilter, searchQuery]);

  const totalPages = Math.max(1, Math.ceil(filteredTransactions.length / PAGE_SIZE));
  const paginatedTxs = filteredTransactions.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const handleDepositClick = () => {
    if (isLegalBlocked) {
      setShowLegalModal(true);
      return;
    }
  };

  const handleExportCSV = () => {
    window.open("/api/wallet/export", "_blank");
  };

  const isCredit = (type: string, amount: string): boolean => {
    if (type === "FX_CONVERT") return parseFloat(amount) > 0;
    return CREDIT_TYPES.includes(type);
  };

  const convertFromAccount = accountsByCurrency[convertFrom];
  const otherCurrencies = WALLET_CURRENCIES.filter(c => c !== convertFrom);

  return (
    <RoleLayout role="investor">
      <div className="space-y-6">
        {isEddBlocked && (
          <GlassCard className="bg-destructive/5 border-destructive/20" data-testid="edd-block-banner">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-md bg-destructive/10 flex items-center justify-center flex-shrink-0">
                <ShieldAlert className="w-5 h-5 text-destructive" />
              </div>
              <div>
                <p className="font-semibold text-sm" data-testid="edd-block-title">Account Under Enhanced Due Diligence Review</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Your account has been flagged for enhanced due diligence (EDD) review. Deposits, withdrawals, and investment actions are temporarily restricted until the review is complete. Please contact support if you have questions.
                </p>
              </div>
            </div>
          </GlassCard>
        )}

        {isLegalBlocked && !isEddBlocked && (
          <GlassCard className="bg-amber-500/5 border-amber-500/20" data-testid="legal-block-banner">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-md bg-amber-500/10 flex items-center justify-center flex-shrink-0">
                <FileText className="w-5 h-5 text-amber-600 dark:text-amber-400" />
              </div>
              <div>
                <p className="font-semibold text-sm" data-testid="legal-block-title">Legal Agreements Required</p>
                <p className="text-sm text-muted-foreground mt-1">
                  You must review and accept our latest legal documents before performing financial actions. {pendingCount} document(s) require your acceptance.
                </p>
                <GlassButton
                  variant="primary"
                  className="mt-3"
                  onClick={() => setShowLegalModal(true)}
                  data-testid="button-review-legal-wallet"
                >
                  Review & Accept Documents
                </GlassButton>
              </div>
            </div>
          </GlassCard>
        )}

        {!hasVerifiedBank && !isEddBlocked && !isLegalBlocked && (
          <GlassCard className="bg-blue-500/5 border-blue-500/20" data-testid="bank-account-notice">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-md bg-blue-500/10 flex items-center justify-center flex-shrink-0">
                <Building2 className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <p className="font-semibold text-sm">Bank Account Required for Withdrawals</p>
                <p className="text-sm text-muted-foreground mt-1">
                  You need a verified bank account to withdraw funds. Add and verify your bank account to enable withdrawals.
                </p>
                <Link href="/investor/bank-accounts">
                  <Button variant="outline" size="sm" className="mt-3" data-testid="link-add-bank-account">
                    <Building2 className="w-3.5 h-3.5 mr-1" />
                    Manage Bank Accounts
                  </Button>
                </Link>
              </div>
            </div>
          </GlassCard>
        )}

        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <Link href="/investor/dashboard">
              <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <PageTitle
              title="Wallet"
              description="Manage your funds across multiple currencies"
            />
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Button
              variant="outline"
              onClick={() => setShowConvertDialog(true)}
              disabled={isBlocked}
              data-testid="button-convert-currency"
            >
              <ArrowRightLeft className="w-4 h-4 mr-1" />
              Convert
            </Button>
            <Button
              variant="outline"
              onClick={handleExportCSV}
              data-testid="button-export-csv"
            >
              <Download className="w-4 h-4 mr-1" />
              Export CSV
            </Button>
            <Button
              variant="outline"
              disabled={isBlocked || !hasVerifiedBank}
              onClick={() => {
                if (isLegalBlocked) { setShowLegalModal(true); return; }
                setShowWithdrawDialog(true);
              }}
              data-testid="button-withdraw"
            >
              <Send className="w-4 h-4 mr-1" />
              Withdraw
            </Button>
            <GlassButton
              variant="primary"
              disabled={isBlocked}
              onClick={handleDepositClick}
              data-testid="button-deposit"
            >
              <Plus className="w-4 h-4" />
              {isLegalBlocked && !isEddBlocked ? "Accept Terms First" : "Deposit"}
            </GlassButton>
          </div>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1" data-testid="currency-tabs">
          <Button
            variant={activeTab === "ALL" ? "default" : "outline"}
            size="sm"
            onClick={() => { setActiveTab("ALL"); setPage(1); }}
            data-testid="tab-all"
          >
            All Currencies
          </Button>
          {displayCurrencies.map(cur => {
            const details = CURRENCY_DETAILS[cur];
            return (
              <Button
                key={cur}
                variant={activeTab === cur ? "default" : "outline"}
                size="sm"
                onClick={() => { setActiveTab(cur); setPage(1); }}
                data-testid={`tab-${cur.toLowerCase()}`}
              >
                {details.symbol} {cur}
              </Button>
            );
          })}
        </div>

        {accountsLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[...Array(3)].map((_, i) => (
              <Skeleton key={i} className="h-32 rounded-md" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {(activeTab === "ALL" ? displayCurrencies : [activeTab]).map(cur => {
              const acc = accountsByCurrency[cur];
              const details = CURRENCY_DETAILS[cur as keyof typeof CURRENCY_DETAILS];
              const available = acc ? parseFloat(acc.available) : 0;
              const pending = acc ? parseFloat(acc.pending) : 0;
              return (
                <GlassCard padding="md" key={cur} data-testid={`balance-card-${cur.toLowerCase()}`}>
                  <div className="flex items-center justify-between gap-2 flex-wrap mb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-9 h-9 rounded-md bg-primary/10 flex items-center justify-center">
                        <WalletIcon className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground font-medium">{cur} Wallet</p>
                        <p className="text-xs text-muted-foreground">{details?.name || cur}</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="no-default-hover-elevate" data-testid={`badge-currency-${cur.toLowerCase()}`}>{cur}</Badge>
                  </div>
                  <div className="space-y-1">
                    <p className="text-2xl font-bold tracking-tight" data-testid={`balance-${cur.toLowerCase()}-available`}>
                      {formatCurrency(available, cur)}
                    </p>
                    <p className="text-xs text-muted-foreground">Available Balance</p>
                  </div>
                  {pending !== 0 && (
                    <div className="mt-2 flex items-center gap-1.5">
                      <Clock className="w-3 h-3 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground" data-testid={`balance-${cur.toLowerCase()}-pending`}>
                        {formatCurrency(pending, cur)} pending
                      </span>
                    </div>
                  )}
                </GlassCard>
              );
            })}
          </div>
        )}

        <Section title="Transaction History">
          <div className="flex flex-col gap-4">
            <div className="flex flex-wrap items-center gap-3">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search transactions..."
                  value={searchQuery}
                  onChange={(e) => { setSearchQuery(e.target.value); setPage(1); }}
                  className="pl-9"
                  data-testid="input-search-transactions"
                />
              </div>
              <Select value={typeFilter} onValueChange={(v) => { setTypeFilter(v); setPage(1); }}>
                <SelectTrigger className="w-[160px]" data-testid="filter-type">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">All Types</SelectItem>
                  <SelectItem value="DEPOSIT">Deposit</SelectItem>
                  <SelectItem value="WITHDRAW">Withdrawal</SelectItem>
                  <SelectItem value="INVEST_RESERVE">Investment Reserve</SelectItem>
                  <SelectItem value="INVEST_CAPTURE">Investment Capture</SelectItem>
                  <SelectItem value="REFUND">Refund</SelectItem>
                  <SelectItem value="DIVIDEND">Dividend</SelectItem>
                  <SelectItem value="FEE">Fee</SelectItem>
                  <SelectItem value="FX_CONVERT">FX Conversion</SelectItem>
                  <SelectItem value="TRADE_BUY">Trade Buy</SelectItem>
                  <SelectItem value="TRADE_SELL">Trade Sell</SelectItem>
                  <SelectItem value="CRYPTO_DEPOSIT">Crypto Deposit</SelectItem>
                </SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPage(1); }}>
                <SelectTrigger className="w-[140px]" data-testid="filter-status">
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">All Status</SelectItem>
                  <SelectItem value="COMPLETED">Completed</SelectItem>
                  <SelectItem value="PENDING">Pending</SelectItem>
                  <SelectItem value="FAILED">Failed</SelectItem>
                  <SelectItem value="CANCELLED">Cancelled</SelectItem>
                </SelectContent>
              </Select>
              <Select value={currencyFilter} onValueChange={(v) => { setCurrencyFilter(v); setPage(1); }}>
                <SelectTrigger className="w-[130px]" data-testid="filter-currency">
                  <SelectValue placeholder="All Currencies" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">All Currencies</SelectItem>
                  {WALLET_CURRENCIES.map(cur => (
                    <SelectItem key={cur} value={cur}>{cur}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {txLoading ? (
              <div className="space-y-2">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-12 rounded-md" />
                ))}
              </div>
            ) : (
              <GlassCard className="p-0 overflow-hidden" data-testid="transactions-table">
                <Table>
                  <TableHeader>
                    <TableRow className="border-b border-border/50">
                      <TableHead className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Date</TableHead>
                      <TableHead className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Type</TableHead>
                      <TableHead className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Description</TableHead>
                      <TableHead className="text-xs font-semibold uppercase tracking-wider text-muted-foreground text-right">Amount</TableHead>
                      <TableHead className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Currency</TableHead>
                      <TableHead className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedTxs.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                          No transactions found
                        </TableCell>
                      </TableRow>
                    ) : (
                      paginatedTxs.map((tx) => {
                        const credit = isCredit(tx.type, tx.amount);
                        return (
                          <TableRow
                            key={tx.id}
                            className="border-b border-border/30 cursor-pointer hover-elevate"
                            onClick={() => setSelectedTx(tx)}
                            data-testid={`tx-row-${tx.id}`}
                          >
                            <TableCell className="text-sm">{formatDate(tx.createdAt)}</TableCell>
                            <TableCell>
                              <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${TX_TYPE_COLORS[tx.type] || "bg-muted text-muted-foreground"}`} data-testid={`tx-type-${tx.id}`}>
                                {TX_TYPE_LABELS[tx.type] || tx.type}
                              </span>
                            </TableCell>
                            <TableCell className="text-sm text-muted-foreground max-w-[250px] truncate" data-testid={`tx-desc-${tx.id}`}>
                              {tx.description || "--"}
                            </TableCell>
                            <TableCell className={`text-sm font-medium text-right ${credit ? "text-emerald-600 dark:text-emerald-400" : "text-red-600 dark:text-red-400"}`} data-testid={`tx-amount-${tx.id}`}>
                              {credit ? "+" : "-"}{formatCurrency(tx.amount, tx.currency)}
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="no-default-hover-elevate text-xs">{tx.currency}</Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant={STATUS_VARIANT[tx.status] || "secondary"} className="no-default-hover-elevate" data-testid={`tx-status-${tx.id}`}>
                                {tx.status}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </GlassCard>
            )}

            {filteredTransactions.length > PAGE_SIZE && (
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <p className="text-sm text-muted-foreground" data-testid="text-pagination-info">
                  Showing {(page - 1) * PAGE_SIZE + 1}-{Math.min(page * PAGE_SIZE, filteredTransactions.length)} of {filteredTransactions.length} transactions
                </p>
                <div className="flex items-center gap-1">
                  <Button
                    variant="outline"
                    size="icon"
                    disabled={page <= 1}
                    onClick={() => setPage(page - 1)}
                    data-testid="button-prev-page"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <span className="text-sm px-3 text-muted-foreground">Page {page} of {totalPages}</span>
                  <Button
                    variant="outline"
                    size="icon"
                    disabled={page >= totalPages}
                    onClick={() => setPage(page + 1)}
                    data-testid="button-next-page"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            )}
          </div>
        </Section>
      </div>

      <LegalAcceptanceModal
        open={showLegalModal}
        onClose={() => setShowLegalModal(false)}
        onAccepted={() => setShowLegalModal(false)}
      />

      <Section title="Liquidity Rules" data-testid="liquidity-rules-section">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <GlassCard className="p-4">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-md bg-emerald-500/10">
                <ShieldAlert className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              </div>
              <div>
                <p className="text-sm font-semibold" data-testid="text-profit-rule-title">Profit Withdrawals</p>
                <p className="text-xs text-muted-foreground mt-1" data-testid="text-profit-rule-desc">
                  Distribution profits can be withdrawn 30 days after payout date. This ensures settlement finality.
                </p>
              </div>
            </div>
          </GlassCard>
          <GlassCard className="p-4">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-md bg-blue-500/10">
                <Clock className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <p className="text-sm font-semibold" data-testid="text-capital-rule-title">Capital Withdrawals</p>
                <p className="text-xs text-muted-foreground mt-1" data-testid="text-capital-rule-desc">
                  Invested capital can be withdrawn 90 days after investment capture, unless an admin redemption event is executed.
                </p>
              </div>
            </div>
          </GlassCard>
        </div>
      </Section>

      {withdrawalRequests && withdrawalRequests.length > 0 && (
        <Section title="Withdrawal Requests" data-testid="withdrawal-requests-section">
          <GlassCard>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Fee</TableHead>
                  <TableHead>Net Payout</TableHead>
                  <TableHead>Bank</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Reference</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {withdrawalRequests.map((wr) => (
                  <TableRow key={wr.id} data-testid={`withdrawal-row-${wr.id}`}>
                    <TableCell className="text-sm">{formatDate(wr.requestedAt)}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="no-default-hover-elevate text-xs" data-testid={`withdrawal-reason-${wr.id}`}>
                        {wr.reason || "PROFIT"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm font-medium">{formatCurrency(wr.amount, wr.currency)}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{formatCurrency(wr.fee, wr.currency)}</TableCell>
                    <TableCell className="text-sm font-medium">{formatCurrency(wr.netAmount, wr.currency)}</TableCell>
                    <TableCell className="text-sm">{wr.bankAccount?.label || "N/A"}</TableCell>
                    <TableCell>
                      <Badge variant={WITHDRAWAL_STATUS_VARIANT[wr.status] || "secondary"} className="no-default-hover-elevate" data-testid={`withdrawal-status-${wr.id}`}>
                        {wr.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">{wr.payoutReference || "--"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </GlassCard>
        </Section>
      )}

      {fxHistory && fxHistory.length > 0 && (
        <Section title="FX Conversion History" data-testid="fx-history-section">
          <GlassCard className="p-0 overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>From</TableHead>
                  <TableHead>To</TableHead>
                  <TableHead>Rate</TableHead>
                  <TableHead>Fee</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {fxHistory.map((fx) => (
                  <TableRow key={fx.id} data-testid={`fx-row-${fx.id}`}>
                    <TableCell className="text-sm">{formatDate(fx.createdAt)}</TableCell>
                    <TableCell className="text-sm font-medium text-red-600 dark:text-red-400" data-testid={`fx-from-${fx.id}`}>
                      -{formatCurrency(fx.amountFrom, fx.fromCurrency)}
                    </TableCell>
                    <TableCell className="text-sm font-medium text-emerald-600 dark:text-emerald-400" data-testid={`fx-to-${fx.id}`}>
                      +{formatCurrency(fx.amountTo, fx.toCurrency)}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground" data-testid={`fx-rate-${fx.id}`}>
                      1 {fx.fromCurrency} = {parseFloat(fx.rateUsed).toFixed(4)} {fx.toCurrency}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">{formatCurrency(fx.fees, fx.toCurrency)}</TableCell>
                    <TableCell>
                      <Badge variant={STATUS_VARIANT[fx.status] || "secondary"} className="no-default-hover-elevate" data-testid={`fx-status-${fx.id}`}>
                        {fx.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </GlassCard>
        </Section>
      )}

      <Dialog open={showWithdrawDialog} onOpenChange={setShowWithdrawDialog}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Request Withdrawal</DialogTitle>
            <DialogDescription>
              Withdraw funds to a verified bank account. Liquidity rules apply.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="space-y-2">
              <Label>Withdrawal Type</Label>
              <Select value={withdrawReason} onValueChange={(v) => { setWithdrawReason(v as "PROFIT" | "CAPITAL"); setWithdrawAmount(""); }}>
                <SelectTrigger data-testid="select-withdraw-reason">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="PROFIT">Profit (Distribution Income)</SelectItem>
                  <SelectItem value="CAPITAL">Capital (Invested Funds)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {withdrawAvailability && (
              <GlassCard className="p-3" data-testid="card-lockup-rules">
                <p className="text-xs font-semibold text-muted-foreground mb-2">Liquidity Rules</p>
                <div className="space-y-2 text-sm">
                  {withdrawReason === "PROFIT" ? (
                    <>
                      <div className="flex justify-between gap-2">
                        <span className="text-muted-foreground">Lock Period</span>
                        <span className="font-medium" data-testid="text-profit-lock-days">{withdrawAvailability.rules.profitLockDays} days after distribution</span>
                      </div>
                      <div className="flex justify-between gap-2">
                        <span className="text-muted-foreground">Total Profit</span>
                        <span className="font-medium" data-testid="text-total-profit">{formatCurrency(withdrawAvailability.profit.total, withdrawCurrency)}</span>
                      </div>
                      <div className="flex justify-between gap-2">
                        <span className="text-muted-foreground">Unlocked</span>
                        <span className="font-medium text-emerald-600 dark:text-emerald-400" data-testid="text-unlocked-profit">{formatCurrency(withdrawAvailability.profit.unlocked, withdrawCurrency)}</span>
                      </div>
                      {parseFloat(withdrawAvailability.profit.locked) > 0 && (
                        <div className="flex justify-between gap-2">
                          <span className="text-muted-foreground">Still Locked</span>
                          <span className="font-medium text-amber-600 dark:text-amber-400" data-testid="text-locked-profit">{formatCurrency(withdrawAvailability.profit.locked, withdrawCurrency)}</span>
                        </div>
                      )}
                      {parseFloat(withdrawAvailability.profit.pendingWithdrawals) > 0 && (
                        <div className="flex justify-between gap-2">
                          <span className="text-muted-foreground">Pending Withdrawals</span>
                          <span className="font-medium text-red-600 dark:text-red-400">-{formatCurrency(withdrawAvailability.profit.pendingWithdrawals, withdrawCurrency)}</span>
                        </div>
                      )}
                      <div className="flex justify-between gap-2 border-t pt-1">
                        <span className="font-medium">Available to Withdraw</span>
                        <span className="font-semibold text-emerald-600 dark:text-emerald-400" data-testid="text-profit-available">{formatCurrency(withdrawAvailability.profit.available, withdrawCurrency)}</span>
                      </div>
                      {withdrawAvailability.profit.nextUnlockDate && (
                        <p className="text-xs text-muted-foreground" data-testid="text-next-profit-unlock">
                          Next unlock: {formatDate(withdrawAvailability.profit.nextUnlockDate)}
                        </p>
                      )}
                    </>
                  ) : (
                    <>
                      <div className="flex justify-between gap-2">
                        <span className="text-muted-foreground">Lock Period</span>
                        <span className="font-medium" data-testid="text-capital-lock-days">{withdrawAvailability.rules.capitalLockDays} days after investment</span>
                      </div>
                      <div className="flex justify-between gap-2">
                        <span className="text-muted-foreground">Total Capital Invested</span>
                        <span className="font-medium" data-testid="text-total-capital">{formatCurrency(withdrawAvailability.capital.total, withdrawCurrency)}</span>
                      </div>
                      <div className="flex justify-between gap-2">
                        <span className="text-muted-foreground">Unlocked</span>
                        <span className="font-medium text-emerald-600 dark:text-emerald-400" data-testid="text-unlocked-capital">{formatCurrency(withdrawAvailability.capital.unlocked, withdrawCurrency)}</span>
                      </div>
                      {parseFloat(withdrawAvailability.capital.locked) > 0 && (
                        <div className="flex justify-between gap-2">
                          <span className="text-muted-foreground">Still Locked</span>
                          <span className="font-medium text-amber-600 dark:text-amber-400" data-testid="text-locked-capital">{formatCurrency(withdrawAvailability.capital.locked, withdrawCurrency)}</span>
                        </div>
                      )}
                      {parseFloat(withdrawAvailability.capital.pendingWithdrawals) > 0 && (
                        <div className="flex justify-between gap-2">
                          <span className="text-muted-foreground">Pending Withdrawals</span>
                          <span className="font-medium text-red-600 dark:text-red-400">-{formatCurrency(withdrawAvailability.capital.pendingWithdrawals, withdrawCurrency)}</span>
                        </div>
                      )}
                      <div className="flex justify-between gap-2 border-t pt-1">
                        <span className="font-medium">Available to Withdraw</span>
                        <span className="font-semibold text-emerald-600 dark:text-emerald-400" data-testid="text-capital-available">{formatCurrency(withdrawAvailability.capital.available, withdrawCurrency)}</span>
                      </div>
                      {withdrawAvailability.capital.nextUnlockDate && (
                        <p className="text-xs text-muted-foreground" data-testid="text-next-capital-unlock">
                          Next unlock: {formatDate(withdrawAvailability.capital.nextUnlockDate)}
                        </p>
                      )}
                    </>
                  )}
                </div>
              </GlassCard>
            )}

            <div className="space-y-2">
              <Label>Currency</Label>
              <Select
                value={withdrawCurrency}
                onValueChange={(v) => {
                  setWithdrawCurrency(v);
                  setWithdrawBankId("");
                  setWithdrawAmount("");
                }}
              >
                <SelectTrigger data-testid="select-withdraw-currency">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {WALLET_CURRENCIES.map(cur => {
                    const details = CURRENCY_DETAILS[cur];
                    return (
                      <SelectItem key={cur} value={cur}>{cur} - {details.name}</SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Bank Account</Label>
              <Select value={withdrawBankId} onValueChange={setWithdrawBankId}>
                <SelectTrigger data-testid="select-withdraw-bank">
                  <SelectValue placeholder="Select a verified bank account" />
                </SelectTrigger>
                <SelectContent>
                  {(withdrawalEligibility?.accounts || [])
                    .filter(a => a.currency === withdrawCurrency)
                    .map((acc) => (
                      <SelectItem key={acc.id} value={acc.id}>
                        {acc.label} ({acc.bankName})
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
              {(withdrawalEligibility?.accounts || []).filter(a => a.currency === withdrawCurrency).length === 0 && (
                <p className="text-xs text-muted-foreground">No verified {withdrawCurrency} bank accounts available.</p>
              )}
            </div>

            <div className="space-y-2">
              <Label>Amount ({withdrawCurrency})</Label>
              <Input
                type="number"
                step="0.01"
                min="1"
                placeholder="Enter amount"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
                data-testid="input-withdraw-amount"
              />
              {withdrawAvailability && (
                <div className="flex items-center justify-between gap-2">
                  <p className="text-xs text-muted-foreground">
                    Max withdrawable: {formatCurrency(
                      withdrawReason === "PROFIT" ? withdrawAvailability.profit.available : withdrawAvailability.capital.available,
                      withdrawCurrency
                    )}
                  </p>
                  {parseFloat(withdrawReason === "PROFIT" ? withdrawAvailability.profit.available : withdrawAvailability.capital.available) > 0 && (
                    <span
                      className="text-xs text-primary cursor-pointer hover-elevate"
                      onClick={() => setWithdrawAmount(
                        parseFloat(withdrawReason === "PROFIT" ? withdrawAvailability.profit.available : withdrawAvailability.capital.available).toFixed(2)
                      )}
                      data-testid="button-withdraw-max"
                    >
                      Use max
                    </span>
                  )}
                </div>
              )}
            </div>

            {withdrawAmount && parseFloat(withdrawAmount) > 0 && feePreview && (
              <GlassCard className="p-3">
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between gap-2">
                    <span className="text-muted-foreground">Withdrawal Amount</span>
                    <span className="font-medium">{formatCurrency(withdrawAmount, withdrawCurrency)}</span>
                  </div>
                  <div className="flex justify-between gap-2">
                    <span className="text-muted-foreground">
                      Fee {feePreview.method === "percentage" ? `(${(feePreview.feeRate * 100).toFixed(2)}%)` : "(flat)"}
                    </span>
                    <span className="font-medium text-red-600 dark:text-red-400">
                      -{formatCurrency(feePreview.fee.toFixed(2), withdrawCurrency)}
                    </span>
                  </div>
                  <div className="flex justify-between gap-2 border-t pt-1">
                    <span className="font-medium">Net Payout</span>
                    <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                      {formatCurrency(feePreview.netAmount.toFixed(2), withdrawCurrency)}
                    </span>
                  </div>
                </div>
              </GlassCard>
            )}

            {(() => {
              const maxAvailable = withdrawAvailability
                ? parseFloat(withdrawReason === "PROFIT" ? withdrawAvailability.profit.available : withdrawAvailability.capital.available)
                : 0;
              const requestedAmount = parseFloat(withdrawAmount) || 0;
              const exceedsAvailable = requestedAmount > maxAvailable && maxAvailable >= 0;
              return (
                <>
                  {exceedsAvailable && requestedAmount > 0 && (
                    <p className="text-xs text-destructive" data-testid="text-lockup-warning">
                      {withdrawReason === "PROFIT"
                        ? `Amount exceeds unlocked profit. Profits are locked for ${withdrawAvailability?.rules.profitLockDays} days after distribution.`
                        : `Amount exceeds unlocked capital. Capital is locked for ${withdrawAvailability?.rules.capitalLockDays} days after investment.`}
                    </p>
                  )}
                  <Button
                    className="w-full"
                    disabled={
                      !withdrawBankId ||
                      !withdrawAmount ||
                      requestedAmount <= 0 ||
                      exceedsAvailable ||
                      withdrawMutation.isPending
                    }
                    onClick={() => {
                      withdrawMutation.mutate({
                        bankAccountId: withdrawBankId,
                        amount: requestedAmount,
                        currency: withdrawCurrency,
                        reason: withdrawReason,
                      });
                    }}
                    data-testid="button-submit-withdrawal"
                  >
                    {withdrawMutation.isPending ? "Processing..." : `Submit ${withdrawReason === "PROFIT" ? "Profit" : "Capital"} Withdrawal`}
                  </Button>
                </>
              );
            })()}
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showConvertDialog} onOpenChange={(open) => { if (!open) { setShowConvertDialog(false); setConvertAmount(""); } }}>
        <DialogContent className="sm:max-w-md" data-testid="dialog-convert-currency">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ArrowRightLeft className="w-5 h-5" />
              Convert Currency
            </DialogTitle>
            <DialogDescription>
              Convert between any supported wallet currency.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">From</Label>
                <Select value={convertFrom} onValueChange={(v) => {
                  setConvertFrom(v);
                  if (v === convertTo) {
                    const alt = WALLET_CURRENCIES.find(c => c !== v);
                    if (alt) setConvertTo(alt);
                  }
                  setConvertAmount("");
                }}>
                  <SelectTrigger data-testid="select-convert-from">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {WALLET_CURRENCIES.map(cur => (
                      <SelectItem key={cur} value={cur}>{CURRENCY_DETAILS[cur].symbol} {cur}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm font-medium">To</Label>
                <Select value={convertTo} onValueChange={setConvertTo}>
                  <SelectTrigger data-testid="select-convert-to">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {otherCurrencies.map(cur => (
                      <SelectItem key={cur} value={cur}>{CURRENCY_DETAILS[cur].symbol} {cur}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label className="text-sm font-medium">Available {convertFrom} Balance</Label>
              <p className="text-lg font-semibold mt-1" data-testid="text-convert-available">
                {convertFromAccount ? formatCurrency(convertFromAccount.available, convertFrom) : formatCurrency(0, convertFrom)}
              </p>
            </div>

            <div>
              <Label htmlFor="convert-amount" className="text-sm font-medium">Amount to Convert ({convertFrom})</Label>
              <Input
                id="convert-amount"
                type="number"
                placeholder={`Enter amount in ${convertFrom}`}
                value={convertAmount}
                onChange={(e) => setConvertAmount(e.target.value)}
                min="1"
                max={convertFromAccount ? parseFloat(convertFromAccount.available) : 0}
                data-testid="input-convert-amount"
                className="mt-1"
              />
              {convertFromAccount && parseFloat(convertFromAccount.available) > 0 && (
                <span
                  className="text-xs text-primary cursor-pointer mt-1 inline-block hover-elevate"
                  onClick={() => setConvertAmount(parseFloat(convertFromAccount.available).toString())}
                  data-testid="button-convert-max"
                >
                  Use max: {formatCurrency(convertFromAccount.available, convertFrom)}
                </span>
              )}
            </div>

            {fxQuoteLoading && convertAmountNum > 0 && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="w-3.5 h-3.5 animate-spin" />
                Calculating quote...
              </div>
            )}

            {fxQuote && !fxQuoteLoading && (
              <GlassCard padding="sm" data-testid="card-fx-quote">
                <p className="text-xs font-semibold text-muted-foreground mb-2">Conversion Quote</p>
                <div className="space-y-1.5 text-sm">
                  <div className="flex justify-between gap-2">
                    <span className="text-muted-foreground">Exchange Rate</span>
                    <span className="font-medium" data-testid="text-fx-rate">1 {convertFrom} = {parseFloat(fxQuote.rate).toFixed(6)} {convertTo}</span>
                  </div>
                  {parseFloat(fxQuote.spread) > 0 && (
                    <div className="flex justify-between gap-2">
                      <span className="text-muted-foreground">Spread</span>
                      <span className="font-medium text-muted-foreground" data-testid="text-fx-spread">{(parseFloat(fxQuote.spread) * 100).toFixed(2)}%</span>
                    </div>
                  )}
                  <div className="flex justify-between gap-2">
                    <span className="text-muted-foreground">Provider</span>
                    <span className="font-medium text-muted-foreground capitalize" data-testid="text-fx-provider">{fxQuote.provider}</span>
                  </div>
                  <div className="border-t pt-1.5" />
                  <div className="flex justify-between gap-2">
                    <span className="text-muted-foreground">You Send</span>
                    <span className="font-medium" data-testid="text-fx-from">{formatCurrency(fxQuote.amountFrom, convertFrom)}</span>
                  </div>
                  {parseFloat(fxQuote.fees) > 0 && (
                    <div className="flex justify-between gap-2">
                      <span className="text-muted-foreground">
                        Fee {parseFloat(fxQuote.feeRate) > 0 ? `(${(parseFloat(fxQuote.feeRate) * 100).toFixed(2)}%)` : ""}
                      </span>
                      <span className="font-medium text-red-600 dark:text-red-400" data-testid="text-fx-fee">
                        -{formatCurrency(fxQuote.fees, convertTo)}
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between gap-2 border-t pt-1.5">
                    <span className="font-medium">You Receive</span>
                    <span className="font-semibold text-emerald-600 dark:text-emerald-400" data-testid="text-fx-receive">
                      {formatCurrency(fxQuote.amountTo, convertTo)}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Quote expires at {new Date(fxQuote.expiresAt).toLocaleTimeString()}
                  </p>
                </div>
              </GlassCard>
            )}

            <Button
              className="w-full"
              disabled={
                !convertAmount ||
                convertAmountNum <= 0 ||
                convertAmountNum > (convertFromAccount ? parseFloat(convertFromAccount.available) : 0) ||
                !fxQuote ||
                convertMutation.isPending
              }
              onClick={() => {
                if (fxQuote) {
                  convertMutation.mutate({ quoteId: fxQuote.id });
                }
              }}
              data-testid="button-submit-convert"
            >
              {convertMutation.isPending ? "Converting..." : `Convert ${convertFrom} to ${convertTo}`}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Sheet open={!!selectedTx} onOpenChange={(open) => !open && setSelectedTx(null)}>
        <SheetContent side="right" className="overflow-y-auto" data-testid="tx-detail-drawer">
          {selectedTx && (
            <>
              <SheetHeader>
                <SheetTitle data-testid="tx-detail-title">Transaction Details</SheetTitle>
                <SheetDescription data-testid="tx-detail-ref">
                  {selectedTx.referenceId ? `Ref: ${selectedTx.referenceId}` : "No reference ID"}
                </SheetDescription>
              </SheetHeader>
              <div className="mt-6 space-y-5">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className={`inline-flex items-center px-2.5 py-1 rounded text-sm font-medium ${TX_TYPE_COLORS[selectedTx.type] || "bg-muted text-muted-foreground"}`}>
                    {TX_TYPE_LABELS[selectedTx.type] || selectedTx.type}
                  </span>
                  <Badge variant={STATUS_VARIANT[selectedTx.status] || "secondary"} className="no-default-hover-elevate">
                    {selectedTx.status}
                  </Badge>
                </div>

                <div className="text-center py-4">
                  <p className={`text-3xl font-bold ${isCredit(selectedTx.type, selectedTx.amount) ? "text-emerald-600 dark:text-emerald-400" : "text-red-600 dark:text-red-400"}`} data-testid="tx-detail-amount">
                    {isCredit(selectedTx.type, selectedTx.amount) ? "+" : "-"}{formatCurrency(selectedTx.amount, selectedTx.currency)}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">{selectedTx.currency}</p>
                </div>

                <div className="space-y-3 border-t pt-4">
                  <DetailRow label="Date & Time" value={formatDate(selectedTx.createdAt, "long")} testId="tx-detail-date" />
                  <DetailRow label="Description" value={selectedTx.description || "--"} testId="tx-detail-description" />
                  <DetailRow label="Reference ID" value={selectedTx.referenceId || "--"} testId="tx-detail-refid" />
                  <DetailRow label="Transaction ID" value={selectedTx.id} testId="tx-detail-id" />
                </div>

                {selectedTx.metadata && Object.keys(selectedTx.metadata).length > 0 && (
                  <div className="border-t pt-4">
                    <p className="text-sm font-semibold mb-3">Metadata</p>
                    <div className="space-y-2">
                      {Object.entries(selectedTx.metadata).map(([key, value]) => (
                        <DetailRow
                          key={key}
                          label={key.replace(/([A-Z])/g, " $1").replace(/^./, s => s.toUpperCase())}
                          value={String(value)}
                          testId={`tx-meta-${key}`}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </RoleLayout>
  );
}

function DetailRow({ label, value, testId }: { label: string; value: string; testId?: string }) {
  return (
    <div className="flex items-start justify-between gap-3">
      <span className="text-sm text-muted-foreground shrink-0">{label}</span>
      <span className="text-sm font-medium text-right break-all" data-testid={testId}>{value}</span>
    </div>
  );
}
