import { RoleLayout } from "@/components/role-layout";
import { StatTile } from "@/components/stat-tile";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { GradientHeader } from "@/components/gradient-header";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery } from "@tanstack/react-query";
import {
  Wallet,
  PieChart,
  TrendingUp,
  TrendingDown,
  Banknote,
  Building2,
  ArrowUpRight,
  ArrowDownRight,
  Coins,
  MapPin,
  HardHat,
  Calendar,
  Clock,
} from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface PropertyHolding {
  assetId: string;
  assetName: string;
  assetSymbol: string;
  propertyType: string | null;
  location: string | null;
  country: string;
  baseCurrency: string;
  initialInvestment: string;
  currentUnits: string;
  totalRentalReceived: string;
  currentImpliedUnitPrice: string;
  currentMarketValue: string;
  unrealizedGain: string;
  totalReturn: string;
  roiPercent: string;
  annualYield: string | null;
  occupancyRate: string | null;
  constructionStatus: string | null;
  expectedCompletionDate: string | null;
  projectedRentalYield: string | null;
  isOffPlan: boolean;
}

interface DashboardROI {
  summary: {
    totalInvested: string;
    totalCurrentValue: string;
    totalRentalReceived: string;
    totalUnrealizedGain: string;
    overallTotalReturn: string;
    overallRoiPercent: string;
    holdingsCount: number;
    totalWalletBalance: string;
  };
  properties: PropertyHolding[];
  walletBalances: { id: string; currency: string; available: string; pending: string }[];
}

function fmt(value: string | number, currency?: string): string {
  const num = typeof value === "string" ? parseFloat(value) : value;
  if (isNaN(num)) return "$0.00";
  const symbol = currency === "AED" ? "AED " : currency === "PKR" ? "PKR " : currency === "GBP" ? "\u00A3" : currency === "QAR" ? "QAR " : "$";
  return `${num < 0 ? "-" : ""}${symbol}${Math.abs(num).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function fmtPercent(value: string | number): string {
  const num = typeof value === "string" ? parseFloat(value) : value;
  if (isNaN(num)) return "0.00%";
  return `${num >= 0 ? "+" : ""}${num.toFixed(2)}%`;
}

function fmtUnits(value: string | number): string {
  const num = typeof value === "string" ? parseFloat(value) : value;
  if (isNaN(num)) return "0";
  if (num === Math.floor(num)) return num.toLocaleString("en-US");
  return num.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 6 });
}

function LoadingSkeleton() {
  return (
    <div className="space-y-6">
      <Skeleton className="h-28 w-full rounded-md" />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <GlassCard key={i}>
            <Skeleton className="h-4 w-24 mb-3" />
            <Skeleton className="h-8 w-32" />
          </GlassCard>
        ))}
      </div>
      <Skeleton className="h-6 w-48" />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {[1, 2].map((i) => (
          <GlassCard key={i}>
            <Skeleton className="h-40 w-full" />
          </GlassCard>
        ))}
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <GlassCard>
      <div className="text-center py-10">
        <Building2 className="w-10 h-10 mx-auto text-muted-foreground mb-3" />
        <p className="text-sm font-medium text-muted-foreground" data-testid="text-empty-state">
          No investments yet
        </p>
        <p className="text-xs text-muted-foreground mt-1">
          Start investing in tokenized properties to track your returns here
        </p>
      </div>
    </GlassCard>
  );
}

function constructionLabel(status: string | null): string {
  if (!status) return "Unknown";
  const labels: Record<string, string> = {
    planned: "Planning Phase",
    in_progress: "Under Construction",
    completed: "Completed",
    delayed: "Delayed",
    cancelled: "Cancelled",
  };
  return labels[status] || status;
}

function constructionProgress(status: string | null): number {
  if (!status) return 0;
  const map: Record<string, number> = { planned: 10, in_progress: 50, delayed: 40, completed: 100, cancelled: 0 };
  return map[status] ?? 0;
}

function PropertyROICard({ property }: { property: PropertyHolding }) {
  const roi = parseFloat(property.roiPercent);
  const unrealized = parseFloat(property.unrealizedGain);
  const isPositive = roi >= 0;
  const TrendIcon = isPositive ? ArrowUpRight : ArrowDownRight;
  const trendColor = isPositive
    ? "text-emerald-600 dark:text-emerald-400"
    : "text-red-500 dark:text-red-400";

  return (
    <GlassCard className="flex flex-col gap-4" data-testid={`property-roi-card-${property.assetId}`}>
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-md flex items-center justify-center shrink-0 ${property.isOffPlan ? "bg-amber-500/20 dark:bg-amber-400/20" : "gradient-hero"}`}>
            {property.isOffPlan ? (
              <HardHat className="w-5 h-5 text-amber-600 dark:text-amber-400" />
            ) : (
              <Building2 className="w-5 h-5 text-white" />
            )}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-semibold truncate" data-testid={`text-property-name-${property.assetId}`}>
              {property.assetName}
            </p>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground flex-wrap">
              {property.location && (
                <span className="flex items-center gap-0.5">
                  <MapPin className="w-3 h-3" />
                  {property.location}
                </span>
              )}
              {property.propertyType && (
                <Badge variant="secondary" className="text-[10px] px-1.5 py-0">{property.propertyType}</Badge>
              )}
              {property.isOffPlan && (
                <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-amber-500/50 text-amber-600 dark:text-amber-400" data-testid={`badge-offplan-${property.assetId}`}>
                  Off-Plan
                </Badge>
              )}
            </div>
          </div>
        </div>
        <div className={`flex items-center gap-1 text-sm font-bold ${trendColor}`} data-testid={`text-roi-percent-${property.assetId}`}>
          <TrendIcon className="w-4 h-4" />
          {fmtPercent(roi)}
        </div>
      </div>

      {property.isOffPlan && (
        <div className="rounded-md bg-amber-50 dark:bg-amber-900/20 p-3 space-y-2" data-testid={`offplan-info-${property.assetId}`}>
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <span className="text-xs font-medium text-amber-700 dark:text-amber-300 flex items-center gap-1">
              <HardHat className="w-3.5 h-3.5" />
              {constructionLabel(property.constructionStatus)}
            </span>
            {property.expectedCompletionDate && (
              <span className="text-[11px] text-amber-600 dark:text-amber-400 flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                Est. {property.expectedCompletionDate}
              </span>
            )}
          </div>
          <Progress value={constructionProgress(property.constructionStatus)} className="h-1.5" />
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <span className="text-[10px] text-amber-600/80 dark:text-amber-400/80 flex items-center gap-1">
              <Clock className="w-3 h-3" />
              Rental income begins after completion
            </span>
            {property.projectedRentalYield && (
              <span className="text-[10px] font-medium text-amber-700 dark:text-amber-300">
                Projected yield: {property.projectedRentalYield}%
              </span>
            )}
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-x-4 gap-y-3">
        <div>
          <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Initial Investment</p>
          <p className="text-sm font-semibold mt-0.5" data-testid={`text-initial-investment-${property.assetId}`}>
            {fmt(property.initialInvestment, property.baseCurrency)}
          </p>
        </div>
        <div>
          <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Current Units</p>
          <p className="text-sm font-semibold mt-0.5" data-testid={`text-current-units-${property.assetId}`}>
            {fmtUnits(property.currentUnits)}
          </p>
        </div>
        {property.isOffPlan ? (
          <>
            <div>
              <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Projected Rental Yield</p>
              <p className="text-sm font-semibold mt-0.5 text-amber-600 dark:text-amber-400" data-testid={`text-projected-yield-${property.assetId}`}>
                {property.projectedRentalYield ? `${property.projectedRentalYield}%` : "TBD"}
              </p>
            </div>
            <div>
              <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Rental Status</p>
              <p className="text-sm font-semibold mt-0.5 text-muted-foreground" data-testid={`text-rental-status-${property.assetId}`}>
                Not yet active
              </p>
            </div>
          </>
        ) : (
          <>
            <div>
              <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Total Rental Received</p>
              <p className="text-sm font-semibold mt-0.5" data-testid={`text-rental-received-${property.assetId}`}>
                {fmt(property.totalRentalReceived, property.baseCurrency)}
              </p>
            </div>
            <div>
              <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Implied Unit Price</p>
              <p className="text-sm font-semibold mt-0.5" data-testid={`text-implied-price-${property.assetId}`}>
                {fmt(property.currentImpliedUnitPrice, property.baseCurrency)}
              </p>
            </div>
          </>
        )}
        <div>
          <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Unrealized Gain</p>
          <p className={`text-sm font-semibold mt-0.5 ${unrealized >= 0 ? trendColor : "text-red-500 dark:text-red-400"}`} data-testid={`text-unrealized-gain-${property.assetId}`}>
            {fmt(unrealized, property.baseCurrency)}
          </p>
        </div>
        <div>
          <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Total ROI</p>
          <p className={`text-sm font-bold mt-0.5 ${trendColor}`} data-testid={`text-total-roi-${property.assetId}`}>
            {fmtPercent(roi)}
          </p>
        </div>
      </div>
    </GlassCard>
  );
}

export default function InvestorDashboard() {
  const { data, isLoading, error } = useQuery<DashboardROI>({
    queryKey: ["/api/investor/dashboard-roi"],
  });

  if (isLoading) {
    return (
      <RoleLayout role="investor">
        <LoadingSkeleton />
      </RoleLayout>
    );
  }

  if (error) {
    return (
      <RoleLayout role="investor">
        <div className="space-y-6">
          <GradientHeader>
            <h1 className="text-2xl font-bold text-white">Your Investment Overview</h1>
          </GradientHeader>
          <GlassCard>
            <p className="text-sm text-destructive" data-testid="text-error">
              Failed to load dashboard data. Please try again later.
            </p>
          </GlassCard>
        </div>
      </RoleLayout>
    );
  }

  const s = data?.summary;
  const properties = data?.properties || [];
  const walletBalances = data?.walletBalances || [];

  const totalInvested = parseFloat(s?.totalInvested || "0");
  const totalCurrentValue = parseFloat(s?.totalCurrentValue || "0");
  const totalRentalReceived = parseFloat(s?.totalRentalReceived || "0");
  const overallRoi = parseFloat(s?.overallRoiPercent || "0");
  const totalUnrealizedGain = parseFloat(s?.totalUnrealizedGain || "0");
  const totalWalletBalance = parseFloat(s?.totalWalletBalance || "0");
  const holdingsCount = s?.holdingsCount || 0;
  const hasData = holdingsCount > 0 || totalRentalReceived > 0;

  return (
    <RoleLayout role="investor">
      <div className="space-y-6">
        <GradientHeader>
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div>
              <p className="text-white/80 text-sm mb-1">Welcome back</p>
              <h1 className="text-2xl font-bold text-white" data-testid="text-dashboard-title">
                Your Investment Overview
              </h1>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <Badge className="bg-white/20 text-white border-white/30" data-testid="badge-holdings-count">
                {holdingsCount} {holdingsCount === 1 ? "Property" : "Properties"}
              </Badge>
            </div>
          </div>
        </GradientHeader>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatTile
            label="Total Invested"
            value={fmt(totalInvested)}
            trend="neutral"
            icon={<Coins className="w-5 h-5" />}
          />
          <StatTile
            label="Portfolio Value"
            value={fmt(totalCurrentValue)}
            change={fmtPercent(overallRoi)}
            trend={totalCurrentValue >= totalInvested ? "up" : "down"}
            icon={<PieChart className="w-5 h-5" />}
          />
          <StatTile
            label="Rental Income"
            value={fmt(totalRentalReceived)}
            trend={totalRentalReceived > 0 ? "up" : "neutral"}
            icon={<Banknote className="w-5 h-5" />}
          />
          <StatTile
            label="Wallet Balance"
            value={fmt(totalWalletBalance)}
            trend="neutral"
            icon={<Wallet className="w-5 h-5" />}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <GlassCard className="flex flex-col items-center justify-center text-center gap-1" padding="md">
            <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Unrealized Gain</p>
            <p className={`text-lg font-bold ${totalUnrealizedGain >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-red-500 dark:text-red-400"}`} data-testid="text-total-unrealized-gain">
              {fmt(totalUnrealizedGain)}
            </p>
          </GlassCard>
          <GlassCard className="flex flex-col items-center justify-center text-center gap-1" padding="md">
            <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Total Return</p>
            <p className={`text-lg font-bold ${overallRoi >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-red-500 dark:text-red-400"}`} data-testid="text-overall-total-return">
              {fmt(s?.overallTotalReturn || "0")}
            </p>
          </GlassCard>
          <GlassCard className="flex flex-col items-center justify-center text-center gap-1" padding="md">
            <p className="text-[11px] text-muted-foreground uppercase tracking-wide">Overall ROI</p>
            <p className={`text-lg font-bold ${overallRoi >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-red-500 dark:text-red-400"}`} data-testid="text-overall-roi-percent">
              {fmtPercent(overallRoi)}
            </p>
          </GlassCard>
        </div>

        {!hasData ? (
          <EmptyState />
        ) : (
          <Section
            title="Property ROI Breakdown"
            description="Per-property returns including rental income and capital appreciation"
          >
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {properties.map((prop) => (
                <PropertyROICard key={prop.assetId} property={prop} />
              ))}
            </div>
          </Section>
        )}

        {walletBalances.length > 0 && (
          <Section title="Wallet Balances">
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {walletBalances.map((wb) => {
                const avail = parseFloat(wb.available);
                const pend = parseFloat(wb.pending);
                return (
                  <GlassCard key={wb.id} padding="sm" data-testid={`wallet-balance-${wb.currency}`}>
                    <p className="text-[11px] text-muted-foreground uppercase tracking-wide">{wb.currency}</p>
                    <p className="text-base font-bold mt-1">{fmt(avail, wb.currency)}</p>
                    {pend > 0 && (
                      <p className="text-[10px] text-muted-foreground mt-0.5">
                        {fmt(pend, wb.currency)} pending
                      </p>
                    )}
                  </GlassCard>
                );
              })}
            </div>
          </Section>
        )}
      </div>
    </RoleLayout>
  );
}
