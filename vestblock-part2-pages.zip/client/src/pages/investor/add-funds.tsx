import { useState, useRef, useEffect, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Plus,
  ArrowDownLeft,
  Clock,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Copy,
  Upload,
  Building2,
  FileCheck,
  Loader2,
  CreditCard,
  Banknote,
  Globe,
  Info,
  Smartphone,
  Zap,
  Send,
  ExternalLink,
  Download, ArrowLeft,
} from "lucide-react";
import type { PaymentRail, PaymentRailStatus } from "@shared/compliance-policy";
import { useAuth } from "@/lib/auth";
import { formatCurrency, formatDate } from "@/lib/format";
import { SUPPORTED_COUNTRIES, COUNTRY_DETAILS, CURRENCY_DETAILS, LAUNCH_COUNTRIES, SUPPORTED_CURRENCIES } from "@shared/constants";
import type { CountryCode } from "@shared/constants";
import { Link } from "wouter";
interface PaymentIntent {
  id: string;
  userId: string;
  walletAccountId: string | null;
  amount: string;
  currency: string;
  countryCode: string | null;
  referenceCode: string | null;
  status: string;
  paymentMethod: string;
  provider: string;
  providerIntentId: string | null;
  providerSessionUrl: string | null;
  providerResponse: Record<string, any> | null;
  fee: string;
  netAmount: string;
  reference: string | null;
  reconciliationId: string | null;
  proofDocumentUrl: string | null;
  failureReason: string | null;
  expiresAt: string | null;
  confirmedAt: string | null;
  createdAt: string;
}

interface FeePreview {
  grossAmount: number;
  fee: number;
  netAmount: number;
  feeRate: number;
  method: string;
}

interface PaymentRailsResponse {
  countryCode: string;
  countryName: string;
  rails: PaymentRail[];
  defaultCurrency: string;
}

interface ProviderInstructions {
  title: string;
  steps: string[];
  details: Record<string, string>;
}

interface ReceivingBankInfo {
  id: string;
  countryCode: string;
  currency: string;
  bankName: string;
  accountName: string;
  iban: string | null;
  swiftCode: string | null;
  sortCode: string | null;
  routingNumber: string | null;
  branch: string | null;
  accountNumber: string | null;
  isActive: boolean;
}

const COUNTRY_TITLES: Record<string, string> = {
  AE: "UAE Bank Transfer Details",
  PK: "Pakistan Bank Transfer Details",
  GB: "UK Bank Transfer Details",
  US: "US Bank Transfer Details",
  QA: "Qatar Bank Transfer Details",
};

const STATUS_CONFIG: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline"; icon: typeof Clock }> = {
  CREATED: { label: "Awaiting Action", variant: "outline", icon: Clock },
  PENDING: { label: "Under Review", variant: "secondary", icon: Clock },
  CONFIRMED: { label: "Confirmed", variant: "default", icon: CheckCircle2 },
  FAILED: { label: "Rejected", variant: "destructive", icon: XCircle },
  REVERSED: { label: "Reversed", variant: "secondary", icon: RotateCcw },
};

const METHOD_LABELS: Record<string, string> = {
  bank_transfer: "Bank Transfer",
  card: "Card Payment",
  crypto: "Crypto",
  manual: "Manual",
  mobile_wallet: "Mobile Wallet",
  remittance: "Remittance",
  instant_transfer: "Instant Transfer",
  international_wire: "International Wire",
};

const PROVIDER_LABELS: Record<string, string> = {
  manual: "Bank Transfer",
  stripe: "Stripe",
  jazzcash: "JazzCash",
  easypaisa: "Easypaisa",
  raast: "Raast",
  taptap_send: "TapTap Send",
  pk_international_wire: "International Wire",
  ach: "ACH Bank Transfer",
};

const RAIL_STATUS_CONFIG: Record<PaymentRailStatus, { label: string; variant: "default" | "secondary" | "outline" }> = {
  active: { label: "Available", variant: "default" },
  coming_soon: { label: "Coming Soon", variant: "secondary" },
  placeholder: { label: "Planned", variant: "outline" },
};

function getRailIcon(method: string, provider?: string) {
  if (provider === "stripe") return CreditCard;
  if (provider === "jazzcash" || provider === "easypaisa") return Smartphone;
  if (provider === "raast") return Zap;
  if (provider === "taptap_send") return Send;
  if (provider === "pk_international_wire") return Globe;
  if (method === "card") return CreditCard;
  if (method === "mobile_wallet") return Smartphone;
  if (method === "instant_transfer") return Zap;
  if (method === "remittance") return Send;
  if (method === "international_wire") return Globe;
  return Banknote;
}


function getReferenceCode(intent: PaymentIntent): string {
  return intent.referenceCode || `VB-${intent.id.slice(0, 8).toUpperCase()}`;
}

function isManualProvider(provider: string): boolean {
  return provider !== "stripe";
}

export default function InvestorAddFunds() {
  const { toast } = useToast();
  const { primaryCountry } = useAuth();
  const defaultCountry = primaryCountry && LAUNCH_COUNTRIES.includes(primaryCountry as any) ? primaryCountry : "AE";
  const [selectedCountry, setSelectedCountry] = useState<string>(defaultCountry);
  const [showCreate, setShowCreate] = useState(false);
  const [showDetail, setShowDetail] = useState<PaymentIntent | null>(null);
  const [amount, setAmount] = useState("");
  const [currency, setCurrency] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("");
  const [selectedRail, setSelectedRail] = useState<PaymentRail | null>(null);
  const [uploading, setUploading] = useState(false);
  const [depositCurrencyFilter, setDepositCurrencyFilter] = useState<string>("ALL");
  const [countryInitialized, setCountryInitialized] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (primaryCountry && !countryInitialized) {
      setSelectedCountry(primaryCountry);
      setCountryInitialized(true);
    }
  }, [primaryCountry, countryInitialized]);

  const { data: railsData, isLoading: railsLoading } = useQuery<PaymentRailsResponse>({
    queryKey: ["/api/compliance/payment-rails", selectedCountry],
    queryFn: async () => {
      const res = await fetch(`/api/compliance/payment-rails?country=${selectedCountry}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch payment rails");
      return res.json();
    },
  });

  const { data: intents, isLoading } = useQuery<PaymentIntent[]>({
    queryKey: ["/api/payment-intents"],
  });

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const stripeResult = params.get("stripe");
    const intentId = params.get("intent");

    if (stripeResult && intentId) {
      if (stripeResult === "success") {
        toast({ title: "Payment Processing", description: "Your Stripe payment is being processed. Your wallet will be credited shortly." });
      } else if (stripeResult === "cancelled") {
        toast({ title: "Payment Cancelled", description: "Your card payment was cancelled.", variant: "destructive" });
      }
      window.history.replaceState({}, "", window.location.pathname);
    }
  }, [toast]);

  const feeAmount = parseFloat(amount) || 0;
  const { data: feePreview } = useQuery<FeePreview>({
    queryKey: ["/api/fees/preview", "investment", feeAmount, currency],
    queryFn: async () => {
      if (feeAmount <= 0) return null;
      const res = await fetch(`/api/fees/preview?feeType=investment&amount=${feeAmount}&currency=${currency}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch fee");
      return res.json();
    },
    enabled: feeAmount > 0 && !!currency,
  });

  const otherCurrencies = SUPPORTED_CURRENCIES.filter(c => c !== currency);
  const { data: fxEquivalents, isLoading: fxEquivLoading } = useQuery<Record<string, { rate: number; equivalent: number; spread: number; provider: string }>>({
    queryKey: ["/api/fx/equivalents", currency, feeAmount],
    queryFn: async () => {
      const results: Record<string, { rate: number; equivalent: number; spread: number; provider: string }> = {};
      const promises = otherCurrencies.map(async (target) => {
        try {
          const res = await fetch(`/api/fx/rate?from=${currency}&to=${target}`, { credentials: "include" });
          if (!res.ok) return;
          const data = await res.json();
          results[target] = {
            rate: data.rate,
            equivalent: feeAmount * data.rate,
            spread: data.spread,
            provider: data.provider,
          };
        } catch {}
      });
      await Promise.all(promises);
      return results;
    },
    enabled: feeAmount > 0 && !!currency && showCreate,
    staleTime: 30000,
  });

  const createMutation = useMutation({
    mutationFn: async (data: { amount: number; currency: string; paymentMethod: string; provider?: string }) => {
      const res = await apiRequest("POST", "/api/payment-intents", data);
      return res.json();
    },
    onSuccess: (intent: PaymentIntent) => {
      queryClient.invalidateQueries({ queryKey: ["/api/payment-intents"] });

      if (intent.provider === "stripe" && intent.providerSessionUrl) {
        toast({ title: "Redirecting to Stripe", description: "You'll be redirected to complete your card payment..." });
        setShowCreate(false);
        setAmount("");
        window.location.href = intent.providerSessionUrl;
        return;
      }

      toast({ title: "Deposit Request Created", description: `Reference: ${getReferenceCode(intent)}` });
      setShowCreate(false);
      setAmount("");
      setShowDetail(intent);
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to create deposit request", variant: "destructive" });
    },
  });

  const handleRailSelect = (rail: PaymentRail) => {
    if (rail.status !== "active") return;
    setSelectedRail(rail);
    setPaymentMethod(rail.method);
    setCurrency(rail.currencies[0]);
    setAmount("");
    setShowCreate(true);
  };

  const handleCreate = () => {
    const num = parseFloat(amount);
    if (!num || num <= 0) {
      toast({ title: "Invalid Amount", description: "Please enter a valid amount", variant: "destructive" });
      return;
    }
    if (selectedRail?.minAmount && num < selectedRail.minAmount) {
      toast({ title: "Below Minimum", description: `Minimum deposit is ${formatCurrency(selectedRail.minAmount, currency)}`, variant: "destructive" });
      return;
    }
    if (selectedRail?.maxAmount && num > selectedRail.maxAmount) {
      toast({ title: "Above Maximum", description: `Maximum deposit is ${formatCurrency(selectedRail.maxAmount, currency)}`, variant: "destructive" });
      return;
    }
    createMutation.mutate({
      amount: num,
      currency,
      paymentMethod,
      provider: selectedRail?.provider,
    });
  };

  const handleUploadProof = async (intentId: string, file: File) => {
    setUploading(true);
    try {
      const urlRes = await apiRequest("POST", "/api/uploads/request-url", {
        name: file.name,
        size: file.size,
        contentType: file.type,
      });
      const { uploadURL, objectPath } = await urlRes.json();

      await fetch(uploadURL, {
        method: "PUT",
        body: file,
        headers: { "Content-Type": file.type },
      });

      const proofRes = await apiRequest("PATCH", `/api/payment-intents/${intentId}/proof`, {
        proofDocumentUrl: objectPath,
      });
      const updated = await proofRes.json();

      toast({ title: "Proof Uploaded", description: "Your transfer receipt has been uploaded and is now under review." });
      queryClient.invalidateQueries({ queryKey: ["/api/payment-intents"] });
      setShowDetail(updated);
    } catch (err: any) {
      toast({ title: "Upload Failed", description: err.message || "Failed to upload proof", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied", description: `${label} copied to clipboard` });
  };

  const activeIntents = intents?.filter(i => i.status === "CREATED" || i.status === "PENDING") || [];
  const activeRails = railsData?.rails.filter(r => r.status === "active") || [];
  const upcomingRails = railsData?.rails.filter(r => r.status !== "active") || [];

  const depositCurrencies = Array.from(new Set(intents?.map(i => i.currency) || []));
  const filteredIntents = depositCurrencyFilter === "ALL"
    ? intents || []
    : (intents || []).filter(i => i.currency === depositCurrencyFilter);

  return (
    <RoleLayout role="investor">
      <div className="space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-3">
            <Link href="/investor/dashboard">
              <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <PageTitle title="Add Funds" />
          </div>
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-muted-foreground" />
            <Select value={selectedCountry} onValueChange={setSelectedCountry}>
              <SelectTrigger className="w-[200px]" data-testid="select-country">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {LAUNCH_COUNTRIES.map(code => (
                  <SelectItem key={code} value={code} data-testid={`option-country-${code}`}>
                    {COUNTRY_DETAILS[code].name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {railsLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-32 w-full" />
          </div>
        ) : (
          <>
            <Section title="Available Payment Methods" description="Select a payment method to deposit funds into your wallet">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {activeRails.map((rail) => {
                  const Icon = getRailIcon(rail.method, rail.provider);
                  return (
                    <Card
                      key={`${rail.method}-${rail.provider}`}
                      className="hover-elevate cursor-pointer"
                      onClick={() => handleRailSelect(rail)}
                      data-testid={`card-rail-${rail.method}-${rail.provider}`}
                    >
                      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                        <div className="flex items-center gap-2">
                          <Icon className="w-5 h-5 text-muted-foreground" />
                          <CardTitle className="text-sm font-medium">
                            {rail.label}
                          </CardTitle>
                        </div>
                        <Badge variant="default" className="no-default-hover-elevate" data-testid={`badge-status-${rail.method}-${rail.provider}`}>
                          {RAIL_STATUS_CONFIG[rail.status].label}
                        </Badge>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground mb-3" data-testid={`text-rail-desc-${rail.method}-${rail.provider}`}>
                          {rail.description}
                        </p>
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <div className="flex items-center gap-1 flex-wrap">
                            {rail.currencies.map(c => (
                              <Badge key={c} variant="outline" className="no-default-hover-elevate" data-testid={`badge-currency-${rail.method}-${c}`}>
                                {c}
                              </Badge>
                            ))}
                          </div>
                          <span className="text-xs text-muted-foreground">{rail.processingTime}</span>
                        </div>
                        {(rail.minAmount || rail.maxAmount) && (
                          <p className="text-xs text-muted-foreground mt-2">
                            {rail.minAmount && `Min: ${formatCurrency(rail.minAmount, rail.currencies[0])}`}
                            {rail.minAmount && rail.maxAmount && " · "}
                            {rail.maxAmount && `Max: ${formatCurrency(rail.maxAmount, rail.currencies[0])}`}
                          </p>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}

                {upcomingRails.map((rail) => {
                  const Icon = getRailIcon(rail.method, rail.provider);
                  const statusCfg = RAIL_STATUS_CONFIG[rail.status];
                  return (
                    <Card
                      key={`${rail.method}-${rail.provider}`}
                      className="opacity-60"
                      data-testid={`card-rail-${rail.method}-${rail.provider}`}
                    >
                      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                        <div className="flex items-center gap-2">
                          <Icon className="w-5 h-5 text-muted-foreground" />
                          <CardTitle className="text-sm font-medium">
                            {rail.label}
                          </CardTitle>
                        </div>
                        <Badge variant={statusCfg.variant} className="no-default-hover-elevate" data-testid={`badge-status-${rail.method}-${rail.provider}`}>
                          {statusCfg.label}
                        </Badge>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground mb-3">
                          {rail.description}
                        </p>
                        <div className="flex items-center gap-1 flex-wrap">
                          {rail.currencies.map(c => (
                            <Badge key={c} variant="outline" className="no-default-hover-elevate">
                              {c}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}

                {(!railsData || railsData.rails.length === 0) && (
                  <Card className="md:col-span-2 lg:col-span-3">
                    <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                      <Info className="w-12 h-12 text-muted-foreground mb-4" />
                      <h3 className="text-lg font-medium mb-2">No payment methods available</h3>
                      <p className="text-muted-foreground">
                        Please set up your country profile in Settings to see available payment methods.
                      </p>
                    </CardContent>
                  </Card>
                )}
              </div>
            </Section>

            {activeIntents.length > 0 && (
              <Section title="Pending Deposits" description="Complete these deposits by uploading proof of transfer">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {activeIntents.map(intent => {
                    const config = STATUS_CONFIG[intent.status] || STATUS_CONFIG.CREATED;
                    const StatusIcon = config.icon;
                    const needsProof = intent.status === "CREATED" && !intent.proofDocumentUrl && isManualProvider(intent.provider);
                    const isStripeIntent = intent.provider === "stripe";
                    const hasSessionUrl = !!intent.providerSessionUrl;
                    return (
                      <Card
                        key={intent.id}
                        className="hover-elevate cursor-pointer"
                        onClick={() => setShowDetail(intent)}
                        data-testid={`card-intent-${intent.id}`}
                      >
                        <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                          <div className="flex items-center gap-2">
                            <StatusIcon className="w-4 h-4 text-muted-foreground" />
                            <CardTitle className="text-sm font-medium font-mono">
                              {getReferenceCode(intent)}
                            </CardTitle>
                          </div>
                          <Badge variant={config.variant}>{config.label}</Badge>
                        </CardHeader>
                        <CardContent>
                          <div className="text-2xl font-bold" data-testid={`text-amount-${intent.id}`}>
                            {formatCurrency(intent.amount, intent.currency)}
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            {PROVIDER_LABELS[intent.provider] || METHOD_LABELS[intent.paymentMethod] || intent.paymentMethod} · {formatDate(intent.createdAt, "long")}
                          </p>
                          {needsProof && (
                            <div className="flex items-center gap-1 mt-2 text-xs font-medium text-amber-600 dark:text-amber-400">
                              <Upload className="w-3 h-3" />
                              Upload proof required
                            </div>
                          )}
                          {isStripeIntent && intent.status === "PENDING" && (
                            <div className="flex items-center gap-1 mt-2 text-xs font-medium text-blue-600 dark:text-blue-400">
                              <CreditCard className="w-3 h-3" />
                              {hasSessionUrl ? "Complete payment on Stripe" : "Processing payment..."}
                            </div>
                          )}
                          {!isStripeIntent && intent.proofDocumentUrl && intent.status === "PENDING" && (
                            <div className="flex items-center gap-1 mt-2 text-xs font-medium text-blue-600 dark:text-blue-400">
                              <FileCheck className="w-3 h-3" />
                              Proof uploaded - under review
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </Section>
            )}

            <Section title="Deposit History" description="All your deposit requests across currencies">
              {depositCurrencies.length > 1 && (
                <div className="flex items-center gap-2 overflow-x-auto pb-2 mb-2" data-testid="deposit-currency-tabs">
                  <Button
                    variant={depositCurrencyFilter === "ALL" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setDepositCurrencyFilter("ALL")}
                    data-testid="deposit-tab-all"
                  >
                    All Currencies
                  </Button>
                  {depositCurrencies.map(cur => {
                    const details = CURRENCY_DETAILS[cur as keyof typeof CURRENCY_DETAILS];
                    return (
                      <Button
                        key={cur}
                        variant={depositCurrencyFilter === cur ? "default" : "outline"}
                        size="sm"
                        onClick={() => setDepositCurrencyFilter(cur)}
                        data-testid={`deposit-tab-${cur.toLowerCase()}`}
                      >
                        {details?.symbol || ""} {cur}
                      </Button>
                    );
                  })}
                </div>
              )}
              {filteredIntents.length === 0 ? (
                <GlassCard>
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <ArrowDownLeft className="w-12 h-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">No deposits yet</h3>
                    <p className="text-muted-foreground mb-4">
                      {depositCurrencyFilter !== "ALL"
                        ? `No deposits found in ${depositCurrencyFilter}. Try another currency or create a new deposit.`
                        : "Select a payment method above to create your first deposit."}
                    </p>
                  </div>
                </GlassCard>
              ) : (
                <GlassCard>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Reference</TableHead>
                        <TableHead>Currency</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Fee</TableHead>
                        <TableHead>Net</TableHead>
                        <TableHead>Provider</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredIntents.map(intent => {
                        const config = STATUS_CONFIG[intent.status] || STATUS_CONFIG.CREATED;
                        return (
                          <TableRow
                            key={intent.id}
                            className="cursor-pointer"
                            onClick={() => setShowDetail(intent)}
                            data-testid={`row-intent-${intent.id}`}
                          >
                            <TableCell className="font-mono text-sm" data-testid={`text-ref-${intent.id}`}>
                              {getReferenceCode(intent)}
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="no-default-hover-elevate" data-testid={`badge-cur-${intent.id}`}>{intent.currency}</Badge>
                            </TableCell>
                            <TableCell className="font-medium">
                              {formatCurrency(intent.amount, intent.currency)}
                            </TableCell>
                            <TableCell className="text-muted-foreground">
                              {formatCurrency(intent.fee, intent.currency)}
                            </TableCell>
                            <TableCell className="font-medium">
                              {formatCurrency(intent.netAmount, intent.currency)}
                            </TableCell>
                            <TableCell>
                              <span className="text-sm">{PROVIDER_LABELS[intent.provider] || intent.provider}</span>
                            </TableCell>
                            <TableCell>
                              <Badge variant={config.variant}>{config.label}</Badge>
                            </TableCell>
                            <TableCell className="text-muted-foreground">
                              {formatDate(intent.createdAt)}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </GlassCard>
              )}
            </Section>
          </>
        )}

        <Dialog open={showCreate} onOpenChange={(open) => { if (!open) { setShowCreate(false); setAmount(""); } }}>
          <DialogContent className="sm:max-w-md" data-testid="dialog-create-deposit">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                {selectedRail && (() => { const Icon = getRailIcon(selectedRail.method, selectedRail.provider); return <Icon className="w-5 h-5" />; })()}
                New Deposit
              </DialogTitle>
              <DialogDescription>
                {selectedRail
                  ? `${selectedRail.label} · ${selectedRail.processingTime}`
                  : "Create a deposit request"}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Amount</Label>
                <Input
                  type="number"
                  step="0.01"
                  min={selectedRail?.minAmount || 1}
                  max={selectedRail?.maxAmount}
                  placeholder={selectedRail?.minAmount ? `Min ${selectedRail.minAmount}` : "Enter amount"}
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  data-testid="input-deposit-amount"
                />
              </div>
              {selectedRail && selectedRail.currencies.length > 1 && (
                <div className="space-y-2">
                  <Label>Currency</Label>
                  <Select value={currency} onValueChange={setCurrency}>
                    <SelectTrigger data-testid="select-deposit-currency">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {selectedRail.currencies.map(c => (
                        <SelectItem key={c} value={c}>{c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
              {(!selectedRail || selectedRail.currencies.length === 1) && currency && (
                <div className="space-y-2">
                  <Label>Currency</Label>
                  <div className="flex items-center gap-2 h-9 px-3 border rounded-md bg-muted/30">
                    <span className="text-sm font-medium" data-testid="text-deposit-currency">{currency}</span>
                  </div>
                </div>
              )}
              <div className="space-y-2">
                <Label>Payment Method</Label>
                <div className="flex items-center gap-2 h-9 px-3 border rounded-md bg-muted/30">
                  <span className="text-sm font-medium" data-testid="text-deposit-method">
                    {selectedRail?.label || METHOD_LABELS[paymentMethod] || paymentMethod}
                  </span>
                </div>
              </div>

              {feePreview && feeAmount > 0 && (
                <Card data-testid="card-fee-preview">
                  <CardContent className="pt-4 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Amount</span>
                      <span>{formatCurrency(feePreview.grossAmount, currency)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Fee ({(feePreview.feeRate * 100).toFixed(2)}%)</span>
                      <span className="text-muted-foreground">-{formatCurrency(feePreview.fee, currency)}</span>
                    </div>
                    <div className="border-t pt-2 flex justify-between font-medium">
                      <span>Net Credit</span>
                      <span data-testid="text-net-credit">{formatCurrency(feePreview.netAmount, currency)}</span>
                    </div>
                  </CardContent>
                </Card>
              )}

              {feeAmount > 0 && (fxEquivLoading || (fxEquivalents && Object.keys(fxEquivalents).length > 0)) && (
                <Card data-testid="card-fx-equivalents">
                  <CardContent className="pt-4 space-y-2">
                    <div className="flex items-center gap-1.5 mb-2">
                      <Globe className="w-3.5 h-3.5 text-muted-foreground" />
                      <span className="text-xs font-medium text-muted-foreground">Equivalent Value in Other Currencies</span>
                    </div>
                    {fxEquivLoading ? (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground py-1">
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Fetching exchange rates...</span>
                      </div>
                    ) : fxEquivalents && Object.entries(fxEquivalents).map(([cur, data]) => (
                      <div key={cur} className="flex justify-between text-sm" data-testid={`fx-equivalent-${cur}`}>
                        <span className="text-muted-foreground">{cur}</span>
                        <div className="text-right">
                          <span className="font-medium">{formatCurrency(data.equivalent, cur)}</span>
                          <span className="text-xs text-muted-foreground ml-1.5">@ {data.rate.toFixed(4)}</span>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              )}

              {selectedRail?.provider === "stripe" && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <CreditCard className="w-4 h-4" />
                  <span>You'll be redirected to Stripe to complete payment securely</span>
                </div>
              )}

              <Button
                className="w-full"
                onClick={handleCreate}
                disabled={createMutation.isPending || !amount || parseFloat(amount) <= 0}
                data-testid="button-submit-deposit"
              >
                {createMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    {selectedRail?.provider === "stripe" ? "Redirecting to Stripe..." : "Creating..."}
                  </>
                ) : selectedRail?.provider === "stripe" ? (
                  <>
                    <CreditCard className="w-4 h-4 mr-2" />
                    Pay with Card
                  </>
                ) : (
                  "Create Deposit Request"
                )}
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        <Dialog open={!!showDetail} onOpenChange={() => setShowDetail(null)}>
          <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto" data-testid="dialog-intent-detail">
            {showDetail && <IntentDetailContent
              intent={showDetail}
              onUploadProof={handleUploadProof}
              uploading={uploading}
              fileInputRef={fileInputRef}
              copyToClipboard={copyToClipboard}
            />}
          </DialogContent>
        </Dialog>
      </div>
    </RoleLayout>
  );
}

function IntentDetailContent({
  intent,
  onUploadProof,
  uploading,
  fileInputRef,
  copyToClipboard,
}: {
  intent: PaymentIntent;
  onUploadProof: (id: string, file: File) => void;
  uploading: boolean;
  fileInputRef: React.RefObject<HTMLInputElement | null>;
  copyToClipboard: (text: string, label: string) => void;
}) {
  const refCode = getReferenceCode(intent);
  const isActive = intent.status === "CREATED" || intent.status === "PENDING";
  const isStripeIntent = intent.provider === "stripe";
  const isManual = isManualProvider(intent.provider);
  const needsProof = (intent.status === "CREATED") && !intent.proofDocumentUrl && isManual;

  const { data: bankInfo } = useQuery<ReceivingBankInfo>({
    queryKey: ["/api/receiving-banks", intent.currency, intent.countryCode],
    queryFn: async () => {
      const countryParam = intent.countryCode ? `?country=${intent.countryCode}` : "";
      const res = await fetch(`/api/receiving-banks/${intent.currency}${countryParam}`, { credentials: "include" });
      if (!res.ok) return null;
      return res.json();
    },
    enabled: isActive && isManual && intent.paymentMethod === "bank_transfer",
  });

  const { data: providerInstructions } = useQuery<ProviderInstructions>({
    queryKey: ["/api/payment-providers/instructions", intent.provider],
    queryFn: async () => {
      const res = await fetch(`/api/payment-providers/instructions/${intent.provider}`, { credentials: "include" });
      if (!res.ok) return null;
      return res.json();
    },
    enabled: isActive && isManual && intent.provider !== "manual",
  });

  return (
    <>
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2 flex-wrap">
          Deposit Detail
          <Badge variant={STATUS_CONFIG[intent.status]?.variant || "outline"}>
            {STATUS_CONFIG[intent.status]?.label || intent.status}
          </Badge>
        </DialogTitle>
        <DialogDescription className="font-mono">
          {refCode}
        </DialogDescription>
      </DialogHeader>
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Amount</p>
            <p className="text-lg font-bold" data-testid="text-detail-amount">
              {formatCurrency(intent.amount, intent.currency)}
            </p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Net Credit</p>
            <p className="text-lg font-bold" data-testid="text-detail-net">
              {formatCurrency(intent.netAmount, intent.currency)}
            </p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Fee</p>
            <p className="font-medium">{formatCurrency(intent.fee, intent.currency)}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Provider</p>
            <p className="font-medium">{PROVIDER_LABELS[intent.provider] || intent.provider}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Created</p>
            <p className="font-medium">{formatDate(intent.createdAt)}</p>
          </div>
          {intent.confirmedAt && (
            <div>
              <p className="text-sm text-muted-foreground">Confirmed</p>
              <p className="font-medium">{formatDate(intent.confirmedAt)}</p>
            </div>
          )}
        </div>

        {isStripeIntent && isActive && intent.providerSessionUrl && (
          <Card data-testid="card-stripe-payment">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <CreditCard className="w-4 h-4" />
                Card Payment
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground">
                Complete your card payment securely via Stripe
              </p>
              <Button
                className="w-full"
                onClick={() => window.location.href = intent.providerSessionUrl!}
                data-testid="button-stripe-pay"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Complete Payment on Stripe
              </Button>
            </CardContent>
          </Card>
        )}

        {isStripeIntent && intent.status === "CONFIRMED" && (
          <Card>
            <CardContent className="pt-4 flex items-center gap-2 text-sm">
              <CheckCircle2 className="w-4 h-4 text-green-600 dark:text-green-400" />
              <span>Card payment confirmed and wallet credited</span>
            </CardContent>
          </Card>
        )}

        {intent.status === "CONFIRMED" && (
          <Button
            variant="outline"
            className="w-full"
            onClick={() => {
              window.open(`/api/payment-intents/${intent.id}/receipt`, "_blank");
            }}
            data-testid="button-download-receipt"
          >
            <Download className="w-4 h-4 mr-2" />
            Download Deposit Receipt
          </Button>
        )}

        {isActive && isManual && intent.paymentMethod === "bank_transfer" && !bankInfo && (
          <Card>
            <CardContent className="pt-4 text-sm text-muted-foreground">
              Bank transfer details for {intent.currency} are not yet configured. Please contact support.
            </CardContent>
          </Card>
        )}

        {isActive && isManual && intent.paymentMethod === "bank_transfer" && bankInfo && (
          <Card data-testid="card-bank-details">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Building2 className="w-4 h-4" />
                {COUNTRY_TITLES[bankInfo.countryCode] || `${bankInfo.currency} Bank Transfer Details`}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Bank</span>
                  <span className="font-medium" data-testid="text-bank-name">{bankInfo.bankName}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Account Name</span>
                  <span className="font-medium" data-testid="text-account-name">{bankInfo.accountName}</span>
                </div>
                {bankInfo.iban && (
                  <div className="flex justify-between items-center gap-2">
                    <span className="text-muted-foreground">IBAN</span>
                    <div className="flex items-center gap-1">
                      <span className="font-mono font-medium" data-testid="text-iban">{bankInfo.iban}</span>
                      <Button size="icon" variant="ghost" onClick={() => copyToClipboard(bankInfo.iban!, "IBAN")} data-testid="button-copy-iban">
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                )}
                {bankInfo.swiftCode && (
                  <div className="flex justify-between items-center gap-2">
                    <span className="text-muted-foreground">SWIFT</span>
                    <div className="flex items-center gap-1">
                      <span className="font-mono font-medium" data-testid="text-swift">{bankInfo.swiftCode}</span>
                      <Button size="icon" variant="ghost" onClick={() => copyToClipboard(bankInfo.swiftCode!, "SWIFT Code")} data-testid="button-copy-swift">
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                )}
                {bankInfo.sortCode && (
                  <div className="flex justify-between items-center gap-2">
                    <span className="text-muted-foreground">Sort Code</span>
                    <div className="flex items-center gap-1">
                      <span className="font-mono font-medium" data-testid="text-sort-code">{bankInfo.sortCode}</span>
                      <Button size="icon" variant="ghost" onClick={() => copyToClipboard(bankInfo.sortCode!, "Sort Code")} data-testid="button-copy-sort-code">
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                )}
                {bankInfo.routingNumber && (
                  <div className="flex justify-between items-center gap-2">
                    <span className="text-muted-foreground">Routing Number</span>
                    <div className="flex items-center gap-1">
                      <span className="font-mono font-medium" data-testid="text-routing">{bankInfo.routingNumber}</span>
                      <Button size="icon" variant="ghost" onClick={() => copyToClipboard(bankInfo.routingNumber!, "Routing Number")} data-testid="button-copy-routing">
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                )}
                {bankInfo.accountNumber && (
                  <div className="flex justify-between items-center gap-2">
                    <span className="text-muted-foreground">Account Number</span>
                    <div className="flex items-center gap-1">
                      <span className="font-mono font-medium" data-testid="text-account-number">{bankInfo.accountNumber}</span>
                      <Button size="icon" variant="ghost" onClick={() => copyToClipboard(bankInfo.accountNumber!, "Account Number")} data-testid="button-copy-account">
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                )}
                {bankInfo.branch && (
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Branch</span>
                    <span className="font-medium">{bankInfo.branch}</span>
                  </div>
                )}
              </div>
              <ReferenceCodeSection refCode={refCode} copyToClipboard={copyToClipboard} />
            </CardContent>
          </Card>
        )}

        {isActive && isManual && providerInstructions && intent.provider !== "manual" && (
          <Card data-testid="card-provider-instructions">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                {(() => { const Icon = getRailIcon(intent.paymentMethod, intent.provider); return <Icon className="w-4 h-4" />; })()}
                {providerInstructions.title}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {Object.entries(providerInstructions.details).filter(([k]) => k !== "note").map(([key, value]) => (
                <div key={key} className="flex justify-between items-center text-sm">
                  <span className="text-muted-foreground capitalize">{key.replace(/([A-Z])/g, " $1").trim()}</span>
                  <div className="flex items-center gap-1">
                    <span className="font-medium">{value}</span>
                    <Button size="icon" variant="ghost" onClick={() => copyToClipboard(value, key)} className="h-6 w-6">
                      <Copy className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              ))}

              <ReferenceCodeSection refCode={refCode} copyToClipboard={copyToClipboard} />

              <div className="border-t pt-3">
                <p className="text-sm font-medium mb-2">Steps to Complete</p>
                <ol className="space-y-1.5">
                  {providerInstructions.steps.map((step, i) => (
                    <li key={i} className="text-sm text-muted-foreground flex gap-2">
                      <span className="font-medium text-foreground min-w-[1.5rem]">{i + 1}.</span>
                      {step}
                    </li>
                  ))}
                </ol>
              </div>

              {providerInstructions.details.note && (
                <div className="flex items-start gap-2 text-xs text-muted-foreground bg-muted/30 rounded-md p-3">
                  <Info className="w-4 h-4 mt-0.5 shrink-0" />
                  <span>{providerInstructions.details.note}</span>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {intent.failureReason && (
          <Card className="border-destructive">
            <CardContent className="pt-4">
              <p className="text-sm font-medium text-destructive">Rejection Reason</p>
              <p className="text-sm text-muted-foreground mt-1">{intent.failureReason}</p>
            </CardContent>
          </Card>
        )}

        {intent.reconciliationId && (
          <div className="text-sm">
            <span className="text-muted-foreground">Reconciliation ID: </span>
            <span className="font-mono">{intent.reconciliationId}</span>
          </div>
        )}

        {needsProof && (
          <div className="space-y-2">
            <Label>Upload Proof of Transfer</Label>
            <p className="text-xs text-muted-foreground">
              Upload a screenshot or PDF of your completed transfer
            </p>
            <input
              ref={fileInputRef as React.RefObject<HTMLInputElement>}
              type="file"
              accept="image/*,.pdf"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) onUploadProof(intent.id, file);
              }}
              data-testid="input-proof-file"
            />
            <Button
              variant="outline"
              className="w-full"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
              data-testid="button-upload-proof"
            >
              {uploading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  Select File
                </>
              )}
            </Button>
          </div>
        )}

        {intent.proofDocumentUrl && (
          <div className="flex items-center gap-2 text-sm">
            <FileCheck className="w-4 h-4 text-green-600 dark:text-green-400" />
            <span className="text-muted-foreground">Proof of transfer uploaded</span>
          </div>
        )}
      </div>
    </>
  );
}

function ReferenceCodeSection({
  refCode,
  copyToClipboard,
}: {
  refCode: string;
  copyToClipboard: (text: string, label: string) => void;
}) {
  return (
    <div className="border-t pt-3">
      <p className="text-sm font-medium mb-1">Your Reference Code</p>
      <div className="flex items-center gap-2">
        <code className="text-lg font-mono font-bold" data-testid="text-ref-code">{refCode}</code>
        <Button size="icon" variant="ghost" onClick={() => copyToClipboard(refCode, "Reference Code")} data-testid="button-copy-ref">
          <Copy className="w-3 h-3" />
        </Button>
      </div>
      <p className="text-xs text-muted-foreground mt-1">
        Include this reference in your transfer description
      </p>
    </div>
  );
}
