import { useState, useEffect, useMemo } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { GlassCard } from "@/components/glass-card";
import { Section } from "@/components/section";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate } from "@/lib/format";
import { submitKycSchema, type SubmitKyc, type KycProfile } from "@shared/schema";
import { KycDocumentUpload } from "@/components/kyc-document-upload";
import type { CompliancePolicy, KycDocRequirement } from "@shared/compliance-policy";
import { SUPPORTED_COUNTRIES, COUNTRY_DETAILS } from "@shared/constants";
import {
  ShieldCheck, Clock, CheckCircle2, XCircle, AlertTriangle,
  ArrowRight, ArrowLeft, User, FileText, Landmark, Send,
  Loader2, Upload, Info, Globe, Circle,
} from "lucide-react";

const KYC_STEPS = [
  { label: "Personal Info", icon: User, description: "Your legal identity" },
  { label: "ID Verification", icon: FileText, description: "Government-issued ID" },
  { label: "Financial Info", icon: Landmark, description: "Source of funds" },
  { label: "Review & Submit", icon: Send, description: "Confirm your details" },
];

const ID_TYPE_LABELS: Record<string, string> = {
  passport: "Passport",
  national_id: "National ID Card",
  drivers_license: "Driver's License",
  emirates_id: "Emirates ID",
};

function KycStatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline"; icon: typeof Clock }> = {
    NOT_STARTED: { label: "Not Started", variant: "secondary", icon: AlertTriangle },
    IN_REVIEW: { label: "In Review", variant: "default", icon: Clock },
    APPROVED: { label: "Approved", variant: "default", icon: CheckCircle2 },
    REJECTED: { label: "Rejected", variant: "destructive", icon: XCircle },
    INFO_REQUESTED: { label: "Info Requested", variant: "outline", icon: AlertTriangle },
    EXPIRED: { label: "Expired", variant: "secondary", icon: AlertTriangle },
  };
  const c = config[status] || config.NOT_STARTED;
  const Icon = c.icon;
  return (
    <Badge variant={c.variant} data-testid="badge-kyc-status">
      <Icon className="w-3 h-3 mr-1" />
      {c.label}
    </Badge>
  );
}

function KycStartView({ onStart }: { onStart: () => void }) {
  return (
    <div className="space-y-6">
      <PageTitle title="KYC Verification" description="Complete your identity verification to start investing" />
      <GlassCard>
        <div className="text-center space-y-4 py-6">
          <div className="w-16 h-16 rounded-md bg-primary/10 flex items-center justify-center mx-auto">
            <ShieldCheck className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-xl font-semibold">Identity Verification Required</h2>
          <p className="text-muted-foreground max-w-md mx-auto text-sm">
            To comply with regulatory requirements, we need to verify your identity
            before you can participate in investment rounds. This process typically
            takes 1-3 business days.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-lg mx-auto pt-4">
            <div className="text-center space-y-1">
              <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center mx-auto">
                <User className="w-5 h-5 text-muted-foreground" />
              </div>
              <p className="text-xs text-muted-foreground">Personal details</p>
            </div>
            <div className="text-center space-y-1">
              <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center mx-auto">
                <FileText className="w-5 h-5 text-muted-foreground" />
              </div>
              <p className="text-xs text-muted-foreground">ID document</p>
            </div>
            <div className="text-center space-y-1">
              <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center mx-auto">
                <Landmark className="w-5 h-5 text-muted-foreground" />
              </div>
              <p className="text-xs text-muted-foreground">Financial info</p>
            </div>
          </div>
          <Button onClick={onStart} className="mt-4" data-testid="button-start-kyc">
            Start Verification
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </GlassCard>
    </div>
  );
}

interface UploadedDoc {
  id: string;
  type: string;
  fileName: string;
  url: string;
  objectPath: string;
}

function KycDocumentChecklist({ policy, uploadedDocs, previewCountry, onCountryChange }: {
  policy: CompliancePolicy;
  uploadedDocs: Record<string, UploadedDoc>;
  previewCountry: string;
  onCountryChange: (country: string) => void;
}) {
  const { data: previewPolicy } = useQuery<CompliancePolicy>({
    queryKey: ["/api/compliance/policy", previewCountry],
    queryFn: async () => {
      const res = await fetch(`/api/compliance/policy?country=${previewCountry}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch policy");
      return res.json();
    },
    enabled: previewCountry !== policy.countryCode,
  });

  const displayPolicy = previewCountry === policy.countryCode ? policy : (previewPolicy || policy);
  const isPreviewing = previewCountry !== policy.countryCode;

  return (
    <GlassCard>
      <div className="flex items-center justify-between gap-4 mb-4 flex-wrap">
        <div className="flex items-center gap-2">
          <FileText className="w-4 h-4 text-muted-foreground" />
          <h3 className="text-sm font-semibold">Document Requirements</h3>
        </div>
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-muted-foreground" />
          <Select value={previewCountry} onValueChange={onCountryChange}>
            <SelectTrigger className="w-[180px]" data-testid="select-kyc-country">
              <SelectValue placeholder="Select country" />
            </SelectTrigger>
            <SelectContent>
              {SUPPORTED_COUNTRIES.map(code => (
                <SelectItem key={code} value={code} data-testid={`option-country-${code}`}>
                  {COUNTRY_DETAILS[code as keyof typeof COUNTRY_DETAILS]?.name || code}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {isPreviewing && (
        <div className="flex items-start gap-2 rounded-md bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900/30 p-2 mb-3">
          <Info className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
          <p className="text-xs text-blue-700 dark:text-blue-300">
            Previewing requirements for <span className="font-medium">{displayPolicy.countryName}</span>. Your submission will use <span className="font-medium">{policy.countryName}</span> requirements.
          </p>
        </div>
      )}

      <div className="space-y-2" data-testid="kyc-document-checklist">
        {displayPolicy.requiredKycDocs.map(doc => {
          const isUploaded = !isPreviewing && !!uploadedDocs[doc.docType];
          return (
            <div
              key={doc.docType}
              className="flex items-start gap-3 p-2 rounded-md border"
              data-testid={`checklist-item-${doc.docType}`}
            >
              {isUploaded ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <Circle className="w-4 h-4 text-muted-foreground shrink-0 mt-0.5" />
              )}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm font-medium">{doc.label}</span>
                  {doc.required ? (
                    <Badge variant="secondary" className="text-[10px]">Required</Badge>
                  ) : (
                    <Badge variant="outline" className="text-[10px]">Optional</Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">{doc.description}</p>
              </div>
            </div>
          );
        })}
      </div>

      {displayPolicy.ssnNotice && (
        <div className="flex items-start gap-2 rounded-md bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/30 p-3 mt-3" data-testid="ssn-notice">
          <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
          <p className="text-xs text-amber-700 dark:text-amber-300">{displayPolicy.ssnNotice}</p>
        </div>
      )}

      <div className="mt-3 pt-3 border-t">
        <p className="text-xs text-muted-foreground">
          {displayPolicy.countryName} compliance: {displayPolicy.notes[0] || "Standard requirements apply"}
        </p>
      </div>
    </GlassCard>
  );
}

function KycFormView({ onSubmitted }: { onSubmitted: () => void }) {
  const { toast } = useToast();
  const { primaryCountry } = useAuth();
  const [step, setStep] = useState(0);
  const [uploadedDocs, setUploadedDocs] = useState<Record<string, UploadedDoc>>({});
  const [previewCountry, setPreviewCountry] = useState<string>(primaryCountry || "AE");

  const { data: policy, isLoading: policyLoading } = useQuery<CompliancePolicy>({
    queryKey: ["/api/compliance/policy"],
  });

  useEffect(() => {
    if (primaryCountry) {
      setPreviewCountry(primaryCountry);
    }
  }, [primaryCountry]);

  const handleDocUploaded = (doc: UploadedDoc) => {
    setUploadedDocs(prev => ({ ...prev, [doc.type]: doc }));
  };

  const form = useForm<SubmitKyc>({
    resolver: zodResolver(submitKycSchema),
    defaultValues: {
      legalName: "",
      dob: "",
      address: "",
      idType: "passport",
      idNumber: "",
      emiratesIdFlag: false,
      sourceOfWealth: "",
      sourceOfFunds: "",
      pepFlag: false,
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: SubmitKyc) => {
      const res = await apiRequest("POST", "/api/kyc", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/kyc"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({ title: "KYC Submitted", description: "Your application is now under review." });
      onSubmitted();
    },
    onError: (err: any) => {
      toast({ title: "Submission Failed", description: err.message || "Please try again.", variant: "destructive" });
    },
  });

  const nextStep = async () => {
    let fieldsToValidate: (keyof SubmitKyc)[] = [];
    if (step === 0) fieldsToValidate = ["legalName", "dob", "address"];
    else if (step === 1) fieldsToValidate = ["idType", "idNumber"];
    else if (step === 2) fieldsToValidate = ["sourceOfWealth", "sourceOfFunds"];

    const valid = await form.trigger(fieldsToValidate);
    if (valid) setStep(s => Math.min(s + 1, 3));
  };

  const prevStep = () => setStep(s => Math.max(s - 1, 0));

  const onSubmit = (data: SubmitKyc) => {
    mutation.mutate(data);
  };

  const allowedIdTypes = policy?.allowedIdTypes || ["passport", "national_id", "drivers_license", "emirates_id"];

  const idVerificationDocs: KycDocRequirement[] = policy?.requiredKycDocs.filter(
    d => d.docType === "id_front" || d.docType === "id_back" || d.docType === "proof_of_address"
  ) || [
    { docType: "id_front", label: "ID Front", description: "Front side of your government-issued ID", required: true },
    { docType: "id_back", label: "ID Back", description: "Back side of your government-issued ID", required: true },
    { docType: "proof_of_address", label: "Proof of Address", description: "Utility bill or bank statement (less than 3 months old)", required: true },
  ];

  const sofDocs = useMemo(() => {
    return policy?.requiredKycDocs.filter(
      d => d.docType === "bank_statement" || d.docType === "source_of_funds"
    ) || [];
  }, [policy]);

  const hasSofRequirement = sofDocs.length > 0;
  const sofRequired = sofDocs.some(d => d.required);

  const showEmiratesIdCheckbox = policy?.requiresEmiratesId ?? true;

  return (
    <div className="space-y-6">
      <PageTitle title="KYC Verification" description="Complete all steps to submit your application" />

      {policy && (
        <div className="flex items-start gap-2 rounded-md bg-muted/50 border p-3" data-testid="compliance-policy-notice">
          <Info className="w-4 h-4 text-muted-foreground shrink-0 mt-0.5" />
          <div className="text-sm text-muted-foreground">
            <span className="font-medium text-foreground">{policy.countryName}</span> compliance requirements apply.
            {policy.notes.length > 0 && (
              <span className="ml-1">{policy.notes[0]}</span>
            )}
          </div>
        </div>
      )}

      {policy && (
        <KycDocumentChecklist
          policy={policy}
          uploadedDocs={uploadedDocs}
          previewCountry={previewCountry}
          onCountryChange={setPreviewCountry}
        />
      )}

      <GlassCard>
        <div className="flex items-center justify-between gap-2 mb-6 flex-wrap">
          {KYC_STEPS.map((s, i) => {
            const Icon = s.icon;
            const isActive = i === step;
            const isCompleted = i < step;
            return (
              <div
                key={i}
                className={`flex items-center gap-2 text-sm ${isActive ? "text-primary font-medium" : isCompleted ? "text-emerald-600 dark:text-emerald-400" : "text-muted-foreground"}`}
                data-testid={`kyc-step-indicator-${i}`}
              >
                <div className={`w-8 h-8 rounded-md flex items-center justify-center text-xs font-medium ${isActive ? "bg-primary text-primary-foreground" : isCompleted ? "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300" : "bg-muted text-muted-foreground"}`}>
                  {isCompleted ? <CheckCircle2 className="w-4 h-4" /> : i + 1}
                </div>
                <span className="hidden sm:inline">{s.label}</span>
              </div>
            );
          })}
        </div>
        <div className="w-full bg-muted rounded-sm h-1.5 mb-6">
          <div className="gradient-hero h-1.5 rounded-sm transition-all" style={{ width: `${((step + 1) / 4) * 100}%` }} />
        </div>
      </GlassCard>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          {step === 0 && (
            <Section title="Personal Information" description="Enter your legal name and address as shown on official documents.">
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="legalName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Legal Full Name</FormLabel>
                      <FormControl>
                        <Input placeholder="As shown on your ID" {...field} data-testid="input-kyc-legal-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="dob"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Date of Birth</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} data-testid="input-kyc-dob" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Residential Address</FormLabel>
                      <FormControl>
                        <Input placeholder="Full street address, city, postal code, country" {...field} data-testid="input-kyc-address" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </Section>
          )}

          {step === 1 && (
            <Section title="Identity Verification" description="Provide details of a valid government-issued ID and upload supporting documents.">
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="idType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ID Document Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-kyc-id-type">
                            <SelectValue placeholder="Select ID type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {allowedIdTypes.map(idType => (
                            <SelectItem key={idType} value={idType}>
                              {ID_TYPE_LABELS[idType] || idType}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {policy && (
                        <FormDescription className="text-xs">
                          Accepted ID types for {policy.countryName}
                        </FormDescription>
                      )}
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="idNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ID Number</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter your document number" {...field} data-testid="input-kyc-id-number" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                {showEmiratesIdCheckbox && (
                  <FormField
                    control={form.control}
                    name="emiratesIdFlag"
                    render={({ field }) => (
                      <FormItem className="flex items-start gap-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            data-testid="checkbox-kyc-emirates-id"
                          />
                        </FormControl>
                        <div>
                          <FormLabel>Emirates ID holder</FormLabel>
                          <FormDescription className="text-xs">Check if you hold a valid UAE Emirates ID</FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                )}

                <div className="pt-2">
                  <h4 className="text-sm font-medium mb-1">Upload Documents</h4>
                  <p className="text-xs text-muted-foreground mb-3">Upload clear photos or scans of your identification documents (JPG, PNG, or PDF).</p>
                  <div className="space-y-3" data-testid="kyc-doc-uploads">
                    {idVerificationDocs.map(doc => (
                      <KycDocumentUpload
                        key={doc.docType}
                        docType={doc.docType}
                        label={`${doc.label}${doc.required ? "" : " (Optional)"}`}
                        description={doc.description}
                        onUploaded={handleDocUploaded}
                        existingDoc={uploadedDocs[doc.docType] || null}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </Section>
          )}

          {step === 2 && (
            <Section title="Financial Information" description="We need this to comply with AML regulations.">
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="sourceOfWealth"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Source of Wealth</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-kyc-source-wealth">
                            <SelectValue placeholder="Select source of wealth" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Employment Income">Employment Income</SelectItem>
                          <SelectItem value="Business Ownership">Business Ownership</SelectItem>
                          <SelectItem value="Investments">Investments</SelectItem>
                          <SelectItem value="Inheritance">Inheritance</SelectItem>
                          <SelectItem value="Real Estate">Real Estate</SelectItem>
                          <SelectItem value="Savings">Savings</SelectItem>
                          <SelectItem value="Other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="sourceOfFunds"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Source of Funds for Investment</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-kyc-source-funds">
                            <SelectValue placeholder="Select source of funds" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Salary">Salary</SelectItem>
                          <SelectItem value="Business Revenue">Business Revenue</SelectItem>
                          <SelectItem value="Investment Returns">Investment Returns</SelectItem>
                          <SelectItem value="Savings">Savings</SelectItem>
                          <SelectItem value="Loan">Loan</SelectItem>
                          <SelectItem value="Gift">Gift</SelectItem>
                          <SelectItem value="Other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="pepFlag"
                  render={({ field }) => (
                    <FormItem className="flex items-start gap-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          data-testid="checkbox-kyc-pep"
                        />
                      </FormControl>
                      <div>
                        <FormLabel>Politically Exposed Person (PEP)</FormLabel>
                        <FormDescription className="text-xs">
                          Check if you, or an immediate family member, currently hold or have recently held a prominent public position
                        </FormDescription>
                      </div>
                    </FormItem>
                  )}
                />

                {hasSofRequirement && (
                  <div className="pt-2">
                    <h4 className="text-sm font-medium mb-1">
                      {sofRequired ? "Required Supporting Documents" : "Supporting Documents (Optional)"}
                    </h4>
                    <p className="text-xs text-muted-foreground mb-3">
                      {sofRequired
                        ? `Source of funds documentation is required per ${policy?.countryName || "your country"}'s compliance policy.`
                        : "Upload supporting documents to verify your source of funds declaration."}
                    </p>
                    <div className="space-y-3">
                      {sofDocs.map(doc => (
                        <KycDocumentUpload
                          key={doc.docType}
                          docType={doc.docType}
                          label={`${doc.label}${doc.required ? "" : " (Optional)"}`}
                          description={doc.description}
                          onUploaded={handleDocUploaded}
                          existingDoc={uploadedDocs[doc.docType] || null}
                        />
                      ))}
                    </div>
                  </div>
                )}

                {policy?.ssnNotice && (
                  <div className="flex items-start gap-2 rounded-md bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/30 p-3" data-testid="ssn-notice-form">
                    <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                    <p className="text-xs text-amber-700 dark:text-amber-300">{policy.ssnNotice}</p>
                  </div>
                )}
              </div>
            </Section>
          )}

          {step === 3 && (
            <Section title="Review & Submit" description="Please review all information before submitting.">
              <div className="space-y-4">
                <GlassCard>
                  <h4 className="font-medium text-sm mb-3">Personal Information</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                    <div>
                      <Label className="text-muted-foreground text-xs">Legal Name</Label>
                      <p data-testid="review-legal-name">{form.getValues("legalName")}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground text-xs">Date of Birth</Label>
                      <p data-testid="review-dob">{form.getValues("dob")}</p>
                    </div>
                    <div className="sm:col-span-2">
                      <Label className="text-muted-foreground text-xs">Address</Label>
                      <p data-testid="review-address">{form.getValues("address")}</p>
                    </div>
                  </div>
                </GlassCard>
                <GlassCard>
                  <h4 className="font-medium text-sm mb-3">ID Verification</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                    <div>
                      <Label className="text-muted-foreground text-xs">ID Type</Label>
                      <p data-testid="review-id-type">{ID_TYPE_LABELS[form.getValues("idType")] || form.getValues("idType")?.replace(/_/g, " ")}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground text-xs">ID Number</Label>
                      <p data-testid="review-id-number">{form.getValues("idNumber")}</p>
                    </div>
                    {showEmiratesIdCheckbox && (
                      <div>
                        <Label className="text-muted-foreground text-xs">Emirates ID</Label>
                        <p>{form.getValues("emiratesIdFlag") ? "Yes" : "No"}</p>
                      </div>
                    )}
                  </div>
                </GlassCard>
                <GlassCard>
                  <h4 className="font-medium text-sm mb-3">Uploaded Documents</h4>
                  <div className="space-y-2">
                    {Object.keys(uploadedDocs).length > 0 ? (
                      Object.entries(uploadedDocs).map(([type, doc]) => (
                        <div key={type} className="flex items-center gap-2 text-sm" data-testid={`review-doc-${type}`}>
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                          <span className="text-muted-foreground capitalize">{type.replace(/_/g, " ")}:</span>
                          <span className="truncate">{doc.fileName}</span>
                        </div>
                      ))
                    ) : (
                      <p className="text-sm text-muted-foreground">No documents uploaded</p>
                    )}
                    {policy && (
                      <div className="mt-2 pt-2 border-t">
                        <p className="text-xs text-muted-foreground" data-testid="review-required-docs-note">
                          {policy.countryName} requires: {policy.requiredKycDocs.filter(d => d.required).map(d => d.label).join(", ")}
                        </p>
                      </div>
                    )}
                  </div>
                </GlassCard>
                <GlassCard>
                  <h4 className="font-medium text-sm mb-3">Financial Information</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                    <div>
                      <Label className="text-muted-foreground text-xs">Source of Wealth</Label>
                      <p data-testid="review-source-wealth">{form.getValues("sourceOfWealth")}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground text-xs">Source of Funds</Label>
                      <p data-testid="review-source-funds">{form.getValues("sourceOfFunds")}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground text-xs">PEP Status</Label>
                      <p>{form.getValues("pepFlag") ? "Yes" : "No"}</p>
                    </div>
                  </div>
                </GlassCard>
              </div>
            </Section>
          )}

          <div className="flex items-center justify-between gap-4 mt-6">
            {step > 0 ? (
              <Button type="button" variant="outline" onClick={prevStep} data-testid="button-kyc-back">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            ) : <div />}
            {step < 3 ? (
              <Button type="button" onClick={nextStep} data-testid="button-kyc-next">
                Next
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            ) : (
              <Button type="submit" disabled={mutation.isPending} data-testid="button-kyc-submit">
                {mutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Send className="w-4 h-4 mr-2" />
                )}
                {mutation.isPending ? "Submitting..." : "Submit Application"}
              </Button>
            )}
          </div>
        </form>
      </Form>
    </div>
  );
}

export default function InvestorKyc() {
  const [showForm, setShowForm] = useState(false);

  const { data: kycData, isLoading } = useQuery<KycProfile | { status: string }>({
    queryKey: ["/api/kyc"],
  });

  if (isLoading) {
    return (
      <RoleLayout role="investor">
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      </RoleLayout>
    );
  }

  const status = kycData?.status || "NOT_STARTED";

  if (status === "NOT_STARTED" && !showForm) {
    return (
      <RoleLayout role="investor">
        <KycStartView onStart={() => setShowForm(true)} />
      </RoleLayout>
    );
  }

  if (showForm || status === "NOT_STARTED" || status === "REJECTED" || status === "INFO_REQUESTED") {
    const profile = kycData as KycProfile | undefined;
    const reviewNotes = profile?.reviewNotes || "";
    const docRequestMatch = reviewNotes.match(/^\[DOC_REQUEST:(\w+)\]\s*(.+)$/);
    const requestedDocType = docRequestMatch ? docRequestMatch[1] : null;
    const requestedDocMessage = docRequestMatch ? docRequestMatch[2] : reviewNotes;

    return (
      <RoleLayout role="investor">
        <div className="space-y-4">
          {status === "INFO_REQUESTED" && reviewNotes && (
            <div className="rounded-md border border-amber-200 dark:border-amber-900/30 bg-amber-50 dark:bg-amber-950/20 p-4" data-testid="doc-request-banner">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-semibold text-amber-800 dark:text-amber-200" data-testid="doc-request-title">
                    {requestedDocType ? "Additional Document Required" : "Additional Information Needed"}
                  </h4>
                  {requestedDocType && (
                    <Badge variant="outline" className="mt-1 mb-2 text-xs" data-testid="doc-request-type">
                      {requestedDocType.replace(/_/g, " ")}
                    </Badge>
                  )}
                  <p className="text-sm text-amber-700 dark:text-amber-300 mt-1" data-testid="doc-request-message">
                    {requestedDocMessage}
                  </p>
                </div>
              </div>
            </div>
          )}
          {status === "REJECTED" && reviewNotes && (
            <div className="rounded-md border border-red-200 dark:border-red-900/30 bg-red-50 dark:bg-red-950/20 p-4" data-testid="rejection-banner">
              <div className="flex items-start gap-3">
                <XCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-semibold text-red-800 dark:text-red-200">Application Rejected</h4>
                  <p className="text-sm text-red-700 dark:text-red-300 mt-1">{reviewNotes}</p>
                </div>
              </div>
            </div>
          )}
          <KycFormView onSubmitted={() => setShowForm(false)} />
        </div>
      </RoleLayout>
    );
  }

  const profile = kycData as KycProfile;

  return (
    <RoleLayout role="investor">
      <div className="space-y-6">
        <PageTitle title="KYC Verification" description="Your identity verification status" />
        <GlassCard>
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-4 flex-wrap">
              <h3 className="text-base font-semibold">Verification Status</h3>
              <KycStatusBadge status={status} />
            </div>
            {status === "IN_REVIEW" && (
              <div className="rounded-md bg-muted/50 border p-3">
                <p className="text-sm text-muted-foreground">
                  Your application is being reviewed. This typically takes 1-3 business days.
                  You will be notified once the review is complete.
                </p>
              </div>
            )}
            {status === "APPROVED" && (
              <div className="rounded-md bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/30 p-3">
                <p className="text-sm text-emerald-700 dark:text-emerald-300">
                  Your identity has been verified. You have full access to all investment features.
                </p>
              </div>
            )}
            {profile && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm mt-4">
                <div>
                  <Label className="text-muted-foreground text-xs">Legal Name</Label>
                  <p>{profile.legalName}</p>
                </div>
                <div>
                  <Label className="text-muted-foreground text-xs">ID Type</Label>
                  <p>{ID_TYPE_LABELS[profile.idType] || profile.idType?.replace(/_/g, " ")}</p>
                </div>
                {profile.submittedAt && (
                  <div>
                    <Label className="text-muted-foreground text-xs">Submitted</Label>
                    <p>{formatDate(profile.submittedAt, "short")}</p>
                  </div>
                )}
                {profile.reviewedAt && (
                  <div>
                    <Label className="text-muted-foreground text-xs">Reviewed</Label>
                    <p>{formatDate(profile.reviewedAt, "short")}</p>
                  </div>
                )}
              </div>
            )}
            {profile?.reviewNotes && (
              <div className="rounded-md bg-muted/50 border p-3 mt-2">
                <Label className="text-muted-foreground text-xs">Review Notes</Label>
                <p className="text-sm mt-1">{profile.reviewNotes}</p>
              </div>
            )}
          </div>
        </GlassCard>
      </div>
    </RoleLayout>
  );
}
