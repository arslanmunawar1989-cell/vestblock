import { useQuery } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import {
  Building2,
  TrendingUp,
  TrendingDown,
  Banknote,
  Eye,
  CheckCircle2,
  ArrowDown,
  ArrowUp,
  Receipt, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
function fmt(val: number | string, decimals = 2): string {
  const n = typeof val === "string" ? parseFloat(val) : val;
  return n.toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
}

interface PayoutWithSale {
  id: string;
  saleEventId: string;
  userId: string;
  units: string;
  capitalReturnAmount: string;
  capitalGainAmount: string;
  totalPayout: string;
  currency: string;
  status: string;
  createdAt: string;
  assetName: string;
  assetId: string | null;
  saleEvent: {
    id: string;
    assetId: string;
    saleAmount: string;
    currency: string;
    totalSellingCosts: string;
    netSaleProceeds: string;
    totalCapitalInvested: string;
    capitalGain: string;
    totalUnitsAtSale: string;
    returnPerUnit: string;
    gainPerUnit: string;
    totalPayoutPerUnit: string;
    executedAt: string | null;
  } | null;
}

export default function InvestorSettlements() {
  const [selectedPayoutId, setSelectedPayoutId] = useState<string | null>(null);

  const { data: payouts, isLoading } = useQuery<PayoutWithSale[]>({
    queryKey: ["/api/investor/property-sales"],
  });

  const selectedPayout = payouts?.find(p => p.id === selectedPayoutId);

  return (
    <RoleLayout role="investor">
      <div className="flex items-center gap-3">
        <Link href="/investor/dashboard">
          <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <PageTitle
        title="Property Sale Settlements"
        subtitle="Final settlement reports from sold properties"
      />
      </div>

      <div className="space-y-4">
        {isLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-20 w-full" />
          </div>
        ) : !payouts || payouts.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Receipt className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground" data-testid="text-no-settlements">No property sale settlements yet</p>
              <p className="text-sm text-muted-foreground mt-1">When a property you invested in is sold, your settlement report will appear here.</p>
            </CardContent>
          </Card>
        ) : (
          payouts.map((payout) => {
            const gainAmount = parseFloat(payout.capitalGainAmount);
            return (
              <Card key={payout.id} data-testid={`card-settlement-${payout.id}`}>
                <CardContent className="py-4">
                  <div className="flex items-center justify-between gap-3 flex-wrap">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Building2 className="w-4 h-4 text-muted-foreground shrink-0" />
                        <h3 className="font-semibold truncate" data-testid={`text-settlement-name-${payout.id}`}>{payout.assetName}</h3>
                        <Badge variant="outline">
                          <CheckCircle2 className="w-3 h-3 mr-1" />
                          Settled
                        </Badge>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3">
                        <div>
                          <span className="text-xs text-muted-foreground block">Your Units</span>
                          <span className="font-medium text-sm" data-testid={`text-units-${payout.id}`}>{fmt(payout.units, 2)}</span>
                        </div>
                        <div>
                          <span className="text-xs text-muted-foreground block">Capital Return</span>
                          <span className="font-medium text-sm flex items-center gap-1" data-testid={`text-capital-return-${payout.id}`}>
                            <ArrowDown className="w-3 h-3 text-green-600 dark:text-green-400" />
                            {payout.currency} {fmt(payout.capitalReturnAmount)}
                          </span>
                        </div>
                        <div>
                          <span className="text-xs text-muted-foreground block">Capital {gainAmount >= 0 ? "Gain" : "Loss"}</span>
                          <span className="font-medium text-sm flex items-center gap-1" data-testid={`text-capital-gain-${payout.id}`}>
                            {gainAmount >= 0 ? (
                              <TrendingUp className="w-3 h-3 text-green-600 dark:text-green-400" />
                            ) : (
                              <TrendingDown className="w-3 h-3 text-destructive" />
                            )}
                            {payout.currency} {fmt(payout.capitalGainAmount)}
                          </span>
                        </div>
                        <div>
                          <span className="text-xs text-muted-foreground block">Total Payout</span>
                          <span className="font-semibold text-sm" data-testid={`text-total-payout-${payout.id}`}>
                            {payout.currency} {fmt(payout.totalPayout)}
                          </span>
                        </div>
                      </div>
                    </div>

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedPayoutId(payout.id)}
                      data-testid={`button-view-settlement-${payout.id}`}
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      Full Report
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      <Dialog open={!!selectedPayoutId} onOpenChange={(open) => { if (!open) setSelectedPayoutId(null); }}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Settlement Report</DialogTitle>
            <DialogDescription>Final settlement details for your investment.</DialogDescription>
          </DialogHeader>
          {selectedPayout && <SettlementReport payout={selectedPayout} />}
        </DialogContent>
      </Dialog>
    </RoleLayout>
  );
}

function SettlementReport({ payout }: { payout: PayoutWithSale }) {
  const sale = payout.saleEvent;
  const gainAmount = parseFloat(payout.capitalGainAmount);

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2 flex-wrap">
            <Building2 className="w-4 h-4" />
            {payout.assetName}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {sale && (
            <div className="space-y-2">
              <h4 className="text-sm font-medium text-muted-foreground">Property Sale Summary</h4>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="flex justify-between gap-1">
                  <span className="text-muted-foreground">Sale Price</span>
                  <span className="font-medium">{sale.currency} {fmt(sale.saleAmount)}</span>
                </div>
                <div className="flex justify-between gap-1">
                  <span className="text-muted-foreground">Selling Costs</span>
                  <span className="text-destructive">- {sale.currency} {fmt(sale.totalSellingCosts)}</span>
                </div>
                <div className="flex justify-between gap-1">
                  <span className="text-muted-foreground">Net Proceeds</span>
                  <span className="font-semibold">{sale.currency} {fmt(sale.netSaleProceeds)}</span>
                </div>
                <div className="flex justify-between gap-1">
                  <span className="text-muted-foreground">Total Invested</span>
                  <span>{sale.currency} {fmt(sale.totalCapitalInvested)}</span>
                </div>
              </div>
              <div className="flex items-center justify-between gap-2 border-t pt-2 flex-wrap">
                <span className="text-sm">Overall Capital {parseFloat(sale.capitalGain) >= 0 ? "Gain" : "Loss"}</span>
                <Badge variant={parseFloat(sale.capitalGain) >= 0 ? "default" : "destructive"}>
                  {parseFloat(sale.capitalGain) >= 0 ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
                  {sale.currency} {fmt(sale.capitalGain)}
                </Badge>
              </div>
            </div>
          )}

          <div className="border-t pt-3 space-y-2">
            <h4 className="text-sm font-medium text-muted-foreground">Your Settlement</h4>
            <div className="grid grid-cols-1 gap-3">
              <div className="flex items-center justify-between gap-2 p-3 rounded-md bg-muted/50">
                <div>
                  <span className="text-xs text-muted-foreground block">Units Held</span>
                  <span className="font-semibold" data-testid="text-report-units">{fmt(payout.units, 2)}</span>
                </div>
                {sale && (
                  <div className="text-right">
                    <span className="text-xs text-muted-foreground block">of {fmt(sale.totalUnitsAtSale, 2)} total</span>
                    <span className="text-sm">
                      {((parseFloat(payout.units) / parseFloat(sale.totalUnitsAtSale)) * 100).toFixed(2)}% ownership
                    </span>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between gap-2 p-3 rounded-md bg-muted/50">
                <div className="flex items-center gap-2">
                  <Banknote className="w-4 h-4 text-muted-foreground" />
                  <div>
                    <span className="text-xs text-muted-foreground block">Return of Capital</span>
                    <span className="font-medium" data-testid="text-report-capital-return">{payout.currency} {fmt(payout.capitalReturnAmount)}</span>
                  </div>
                </div>
                {sale && (
                  <span className="text-xs text-muted-foreground">{fmt(sale.returnPerUnit, 4)}/unit</span>
                )}
              </div>

              <div className="flex items-center justify-between gap-2 p-3 rounded-md bg-muted/50">
                <div className="flex items-center gap-2">
                  {gainAmount >= 0 ? (
                    <TrendingUp className="w-4 h-4 text-green-600 dark:text-green-400" />
                  ) : (
                    <TrendingDown className="w-4 h-4 text-destructive" />
                  )}
                  <div>
                    <span className="text-xs text-muted-foreground block">Capital {gainAmount >= 0 ? "Gain" : "Loss"}</span>
                    <span className="font-medium" data-testid="text-report-capital-gain">{payout.currency} {fmt(payout.capitalGainAmount)}</span>
                  </div>
                </div>
                {sale && (
                  <span className="text-xs text-muted-foreground">{fmt(sale.gainPerUnit, 4)}/unit</span>
                )}
              </div>

              <div className="flex items-center justify-between gap-2 p-3 rounded-md border-2 border-primary/20">
                <div>
                  <span className="text-xs text-muted-foreground block">Total Settlement</span>
                  <span className="text-lg font-bold" data-testid="text-report-total">{payout.currency} {fmt(payout.totalPayout)}</span>
                </div>
                <Badge variant="outline">
                  <CheckCircle2 className="w-3 h-3 mr-1" />
                  Credited to Wallet
                </Badge>
              </div>
            </div>
          </div>

          {sale?.executedAt && (
            <div className="text-xs text-muted-foreground border-t pt-2">
              Settlement date: {new Date(sale.executedAt).toLocaleString()}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
