import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  createTicketSchema,
  type CreateTicket,
  type SupportTicket,
  TICKET_CATEGORIES,
  TICKET_PRIORITIES,
} from "@shared/schema";
import { SUPPORTED_COUNTRIES, SUPPORTED_CURRENCIES, COUNTRY_DETAILS, CURRENCY_DETAILS } from "@shared/constants";
import { DEFAULT_CURRENCY } from "@/lib/currencies";
import {
  Plus,
  MessageSquare,
  Clock,
  CheckCircle2,
  AlertCircle,
  Loader2, ArrowLeft,
} from "lucide-react";
import { formatDate } from "@/lib/format";
import { Link } from "wouter";
const STATUS_CONFIG: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  open: { label: "Open", variant: "outline" },
  in_progress: { label: "In Progress", variant: "secondary" },
  resolved: { label: "Resolved", variant: "default" },
  closed: { label: "Closed", variant: "destructive" },
};

const PRIORITY_CONFIG: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  low: { label: "Low", variant: "outline" },
  medium: { label: "Medium", variant: "secondary" },
  high: { label: "High", variant: "default" },
  urgent: { label: "Urgent", variant: "destructive" },
};

const CATEGORY_LABELS: Record<string, string> = {
  account: "Account",
  kyc: "KYC / Verification",
  deposit: "Deposits",
  withdrawal: "Withdrawals",
  trading: "Trading",
  technical: "Technical Issue",
  other: "Other",
};

export default function InvestorSupportTickets() {
  const { toast } = useToast();
  const [showCreate, setShowCreate] = useState(false);

  const { data: tickets, isLoading } = useQuery<SupportTicket[]>({
    queryKey: ["/api/tickets"],
  });

  const form = useForm<CreateTicket>({
    resolver: zodResolver(createTicketSchema),
    defaultValues: {
      subject: "",
      description: "",
      countryCode: "AE",
      currency: DEFAULT_CURRENCY,
      category: "other",
      priority: "medium",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: CreateTicket) => {
      const res = await apiRequest("POST", "/api/tickets", data);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Ticket submitted successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/tickets"] });
      setShowCreate(false);
      form.reset();
    },
    onError: (err: any) => {
      toast({ title: "Failed to submit ticket", description: err.message, variant: "destructive" });
    },
  });

  return (
    <RoleLayout role="investor">
      <div className="flex items-center gap-3">
        <Link href="/investor/dashboard">
          <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <PageTitle title="Support Tickets" description="Submit and track your support requests" />
      </div>
      <Section>
        <div className="flex items-center justify-between gap-2 mb-4 flex-wrap">
          <h3 className="text-lg font-semibold" data-testid="text-tickets-heading">My Tickets</h3>
          <Button onClick={() => setShowCreate(true)} data-testid="button-create-ticket">
            <Plus className="w-4 h-4 mr-2" />
            New Ticket
          </Button>
        </div>

        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-24 w-full" />)}
          </div>
        ) : !tickets?.length ? (
          <GlassCard>
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <MessageSquare className="w-12 h-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground" data-testid="text-no-tickets">No support tickets yet. Click "New Ticket" to get started.</p>
            </div>
          </GlassCard>
        ) : (
          <div className="space-y-3">
            {tickets.map(ticket => {
              const statusCfg = STATUS_CONFIG[ticket.status] || STATUS_CONFIG.open;
              const priorityCfg = PRIORITY_CONFIG[ticket.priority] || PRIORITY_CONFIG.medium;
              const countryName = COUNTRY_DETAILS[ticket.countryCode as keyof typeof COUNTRY_DETAILS]?.name || ticket.countryCode;
              return (
                <GlassCard key={ticket.id}>
                  <div className="flex flex-col gap-2">
                    <div className="flex items-start justify-between gap-2 flex-wrap">
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium truncate" data-testid={`text-ticket-subject-${ticket.id}`}>{ticket.subject}</h4>
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{ticket.description}</p>
                      </div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant={statusCfg.variant} data-testid={`badge-ticket-status-${ticket.id}`}>{statusCfg.label}</Badge>
                        <Badge variant={priorityCfg.variant} data-testid={`badge-ticket-priority-${ticket.id}`}>{priorityCfg.label}</Badge>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
                      <span data-testid={`text-ticket-category-${ticket.id}`}>{CATEGORY_LABELS[ticket.category] || ticket.category}</span>
                      <span data-testid={`text-ticket-country-${ticket.id}`}>{countryName}</span>
                      <span data-testid={`text-ticket-currency-${ticket.id}`}>{ticket.currency}</span>
                      <span>{formatDate(ticket.createdAt)}</span>
                    </div>
                    {ticket.adminNotes && (
                      <div className="mt-2 p-3 rounded-md bg-muted/50">
                        <p className="text-xs font-medium text-muted-foreground mb-1">Admin Response</p>
                        <p className="text-sm" data-testid={`text-ticket-admin-notes-${ticket.id}`}>{ticket.adminNotes}</p>
                      </div>
                    )}
                  </div>
                </GlassCard>
              );
            })}
          </div>
        )}
      </Section>

      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>New Support Ticket</DialogTitle>
            <DialogDescription>Describe your issue and we'll get back to you as soon as possible.</DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit((data) => createMutation.mutate(data))} className="space-y-4">
              <FormField
                control={form.control}
                name="subject"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subject</FormLabel>
                    <FormControl>
                      <Input placeholder="Brief summary of your issue" {...field} data-testid="input-ticket-subject" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Provide details about your issue..." className="min-h-[100px]" {...field} data-testid="input-ticket-description" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="countryCode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Country</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-ticket-country">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {SUPPORTED_COUNTRIES.map(code => (
                            <SelectItem key={code} value={code}>{COUNTRY_DETAILS[code].name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="currency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Currency</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-ticket-currency">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {SUPPORTED_CURRENCIES.map(code => (
                            <SelectItem key={code} value={code}>{code} - {CURRENCY_DETAILS[code].name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-ticket-category">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {TICKET_CATEGORIES.map(cat => (
                            <SelectItem key={cat} value={cat}>{CATEGORY_LABELS[cat] || cat}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="priority"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Priority</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-ticket-priority">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {TICKET_PRIORITIES.map(p => (
                            <SelectItem key={p} value={p}>{p.charAt(0).toUpperCase() + p.slice(1)}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setShowCreate(false)} data-testid="button-cancel-ticket">
                  Cancel
                </Button>
                <Button type="submit" disabled={createMutation.isPending} data-testid="button-submit-ticket">
                  {createMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                  Submit Ticket
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </RoleLayout>
  );
}
