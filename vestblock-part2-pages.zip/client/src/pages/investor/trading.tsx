import { useState, useMemo, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { GlassCard } from "@/components/glass-card";
import { GlassButton } from "@/components/glass-button";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  ArrowRightLeft,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Tag,
  ShoppingCart,
  ListPlus,
  Timer,
  Lock,
  Percent,
  CalendarClock, ArrowLeft,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import { formatCurrency, formatDate } from "@/lib/format";
import { CURRENCY_DETAILS } from "@shared/constants";
import { DEFAULT_CURRENCY } from "@/lib/currencies";
import { Link } from "wouter";
import { TOKEN_LEGAL_DISCLAIMERS } from "@shared/token-legal";

interface ExitWindowData {
  id: string;
  assetId: string;
  name: string;
  opensAt: string;
  closesAt: string;
  status: string;
  exitFeePercent: string | null;
  quarter: string | null;
  createdAt: string;
}

interface TradeListingData {
  id: string;
  exitWindowId: string;
  assetId: string;
  sellerId: string;
  sellerName: string;
  quantity: string;
  pricePerToken: string;
  currency: string;
  remainingQuantity: string;
  status: string;
  createdAt: string;
}

interface AssetData {
  id: string;
  name: string;
  symbol: string;
  assetType: string;
  pricePerToken: string;
  baseCurrency: string;
  status: string;
}

interface TradeCheckResponse {
  baseCurrency: string;
  availableBalance: number;
  hasWallet: boolean;
  pricePerToken: number;
  remainingQuantity: number;
  otherBalances: { currency: string; available: number }[];
}

interface PortfolioItemData {
  id: string;
  assetId: string;
  quantity: string;
  averageCost: string;
}

function getStatusVariant(status: string) {
  switch (status) {
    case "open": return "default";
    case "scheduled": return "secondary";
    case "closed": return "outline";
    case "cancelled": return "outline";
    default: return "outline";
  }
}

function useCountdown(targetDate: string | null) {
  const [timeLeft, setTimeLeft] = useState("");
  const [isExpired, setIsExpired] = useState(false);

  useEffect(() => {
    if (!targetDate) { setTimeLeft(""); return; }

    function update() {
      const now = Date.now();
      const target = new Date(targetDate!).getTime();
      const diff = target - now;

      if (diff <= 0) {
        setTimeLeft("Now");
        setIsExpired(true);
        return;
      }

      setIsExpired(false);
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      if (days > 0) {
        setTimeLeft(`${days}d ${hours}h ${minutes}m`);
      } else if (hours > 0) {
        setTimeLeft(`${hours}h ${minutes}m ${seconds}s`);
      } else {
        setTimeLeft(`${minutes}m ${seconds}s`);
      }
    }

    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, [targetDate]);

  return { timeLeft, isExpired };
}

export default function InvestorTrading() {
  const { toast } = useToast();
  const { user, defaultCurrency } = useAuth();
  const [selectedWindow, setSelectedWindow] = useState<ExitWindowData | null>(null);
  const [selectedListing, setSelectedListing] = useState<TradeListingData | null>(null);
  const [buyQuantity, setBuyQuantity] = useState("");
  const [showBuyModal, setShowBuyModal] = useState(false);
  const [showSellModal, setShowSellModal] = useState(false);
  const [sellQuantity, setSellQuantity] = useState("");
  const [sellPrice, setSellPrice] = useState("");
  const [sellAssetId, setSellAssetId] = useState("");

  const { data: exitWindows, isLoading: windowsLoading } = useQuery<ExitWindowData[]>({
    queryKey: ["/api/exit-windows"],
  });

  const { data: assets } = useQuery<AssetData[]>({
    queryKey: ["/api/assets"],
  });

  const { data: portfolio } = useQuery<PortfolioItemData[]>({
    queryKey: ["/api/portfolio"],
  });

  const { data: listings, isLoading: listingsLoading } = useQuery<TradeListingData[]>({
    queryKey: ["/api/exit-windows", selectedWindow?.id, "listings"],
    queryFn: async () => {
      if (!selectedWindow) return [];
      const res = await fetch(`/api/exit-windows/${selectedWindow.id}/listings`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch listings");
      return res.json();
    },
    enabled: !!selectedWindow,
  });

  const { data: tradeCheck, isLoading: checkLoading } = useQuery<TradeCheckResponse>({
    queryKey: ["/api/trade/check", selectedListing?.id],
    queryFn: async () => {
      if (!selectedListing) return null;
      const res = await fetch(`/api/trade/check/${selectedListing.id}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: !!selectedListing && showBuyModal,
  });

  const buyMutation = useMutation({
    mutationFn: async (data: { listingId: string; quantity: number }) => {
      const res = await apiRequest("POST", "/api/trade/buy", data);
      return res.json();
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["/api/wallet/accounts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/wallet/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/portfolio"] });
      queryClient.invalidateQueries({ queryKey: ["/api/exit-windows", selectedWindow?.id, "listings"] });
      setShowBuyModal(false);
      setBuyQuantity("");
      setSelectedListing(null);
      toast({
        title: "Trade Successful",
        description: `Bought ${result.trade.quantity} ${result.trade.assetSymbol} tokens for ${formatCurrency(result.trade.totalCost, result.trade.currency)}`,
      });
    },
    onError: (err: any) => {
      toast({
        title: "Trade Failed",
        description: err.message || "Could not process trade",
        variant: "destructive",
      });
    },
  });

  const sellMutation = useMutation({
    mutationFn: async (data: { exitWindowId: string; assetId: string; quantity: number; pricePerToken: number }) => {
      const res = await apiRequest("POST", "/api/trade/list", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/exit-windows", selectedWindow?.id, "listings"] });
      queryClient.invalidateQueries({ queryKey: ["/api/trade/my-listings"] });
      setShowSellModal(false);
      setSellQuantity("");
      setSellPrice("");
      setSellAssetId("");
      toast({ title: "Listing Created", description: "Your tokens are now listed for sale." });
    },
    onError: (err: any) => {
      toast({ title: "Listing Failed", description: err.message || "Could not create listing", variant: "destructive" });
    },
  });

  const assetMap = useMemo(() => {
    const map: Record<string, AssetData> = {};
    if (assets) for (const a of assets) map[a.id] = a;
    return map;
  }, [assets]);

  const sortedWindows = useMemo(() => {
    if (!exitWindows) return [];
    const statusOrder: Record<string, number> = { open: 0, scheduled: 1, closed: 2, cancelled: 3 };
    return [...exitWindows].sort((a, b) => {
      const sa = statusOrder[a.status] ?? 9;
      const sb = statusOrder[b.status] ?? 9;
      if (sa !== sb) return sa - sb;
      return new Date(a.opensAt).getTime() - new Date(b.opensAt).getTime();
    });
  }, [exitWindows]);

  const openWindows = useMemo(() =>
    sortedWindows.filter(w => w.status === "open"),
    [sortedWindows]
  );

  const scheduledWindows = useMemo(() =>
    sortedWindows.filter(w => w.status === "scheduled"),
    [sortedWindows]
  );

  const nextScheduledWindow = scheduledWindows.length > 0 ? scheduledWindows[0] : null;

  const selectedAsset = selectedWindow ? assetMap[selectedWindow.assetId] : null;
  const baseCurrency = selectedAsset?.baseCurrency || DEFAULT_CURRENCY;
  const userCurrency = defaultCurrency || DEFAULT_CURRENCY;

  const exitFeePercent = selectedWindow?.exitFeePercent ? parseFloat(selectedWindow.exitFeePercent) : 1.5;

  const qty = parseFloat(buyQuantity) || 0;
  const listingPrice = selectedListing ? parseFloat(selectedListing.pricePerToken) : 0;
  const totalCost = qty * listingPrice;
  const hasEnoughBalance = tradeCheck ? tradeCheck.availableBalance >= totalCost : false;
  const shortfall = tradeCheck ? Math.max(0, totalCost - tradeCheck.availableBalance) : 0;
  const needsFxConvert = baseCurrency !== userCurrency;

  const sellQty = parseFloat(sellQuantity) || 0;
  const sellPriceNum = parseFloat(sellPrice) || 0;
  const sellTotalValue = sellQty * sellPriceNum;
  const sellExitFee = sellTotalValue * exitFeePercent / 100;
  const sellNetProceeds = sellTotalValue - sellExitFee;

  const activeListings = useMemo(() =>
    (listings || []).filter(l => l.status === "active" && l.sellerId !== user?.id),
    [listings, user?.id]
  );

  const myListings = useMemo(() =>
    (listings || []).filter(l => l.sellerId === user?.id),
    [listings, user?.id]
  );

  const cancelMutation = useMutation({
    mutationFn: async (listingId: string) => {
      const res = await apiRequest("DELETE", `/api/trade/list/${listingId}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/exit-windows", selectedWindow?.id, "listings"] });
      toast({ title: "Listing Cancelled" });
    },
    onError: (err: any) => {
      toast({ title: "Failed", description: err.message, variant: "destructive" });
    },
  });

  const handleBuyClick = (listing: TradeListingData) => {
    setSelectedListing(listing);
    setBuyQuantity("");
    setShowBuyModal(true);
  };

  const handleConfirmBuy = () => {
    if (!selectedListing || qty <= 0) return;
    buyMutation.mutate({ listingId: selectedListing.id, quantity: qty });
  };

  const handleSellClick = () => {
    if (!selectedWindow) return;
    setSellAssetId(selectedWindow.assetId);
    setSellQuantity("");
    setSellPrice(selectedAsset?.pricePerToken || "");
    setShowSellModal(true);
  };

  const handleConfirmSell = () => {
    if (!selectedWindow || !sellAssetId) return;
    const sq = parseFloat(sellQuantity) || 0;
    const sp = parseFloat(sellPrice) || 0;
    if (sq <= 0 || sp <= 0) return;
    sellMutation.mutate({
      exitWindowId: selectedWindow.id,
      assetId: sellAssetId,
      quantity: sq,
      pricePerToken: sp,
    });
  };

  const portfolioForAsset = selectedWindow
    ? (portfolio || []).find(p => p.assetId === selectedWindow.assetId)
    : null;

  return (
    <RoleLayout role="investor">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/investor/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle title="Secondary Market" description="Trade ownership units during scheduled exit windows — restricted to verified investors" />
        </div>

        <div className="flex items-start gap-3 p-4 border rounded-md bg-muted/30" data-testid="notice-trading-legal">
          <AlertTriangle className="w-4 h-4 mt-0.5 text-muted-foreground flex-shrink-0" />
          <p className="text-xs text-muted-foreground" data-testid="text-trading-disclaimer">{TOKEN_LEGAL_DISCLAIMERS.tradingDisclaimer}</p>
        </div>

        {!selectedWindow ? (
          <>
            {openWindows.length === 0 && (
              <TradingClosedBanner nextWindow={nextScheduledWindow} assetMap={assetMap} />
            )}

            {windowsLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[...Array(3)].map((_, i) => (
                  <Skeleton key={i} className="h-36 rounded-md" />
                ))}
              </div>
            ) : (
              <>
                {openWindows.length > 0 && (
                  <div className="space-y-3">
                    <p className="text-sm font-semibold text-emerald-700 dark:text-emerald-400 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      Open Exit Windows
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {openWindows.map(ew => (
                        <ExitWindowCard
                          key={ew.id}
                          ew={ew}
                          asset={assetMap[ew.assetId]}
                          onSelect={() => setSelectedWindow(ew)}
                        />
                      ))}
                    </div>
                  </div>
                )}

                {scheduledWindows.length > 0 && (
                  <div className="space-y-3">
                    <p className="text-sm font-semibold text-muted-foreground flex items-center gap-1.5">
                      <CalendarClock className="w-4 h-4" />
                      Upcoming Exit Windows
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {scheduledWindows.map(ew => (
                        <ExitWindowCard
                          key={ew.id}
                          ew={ew}
                          asset={assetMap[ew.assetId]}
                          onSelect={() => {}}
                        />
                      ))}
                    </div>
                  </div>
                )}

                {openWindows.length === 0 && scheduledWindows.length === 0 && (
                  <Card className="p-8 text-center">
                    <Lock className="w-10 h-10 mx-auto mb-3 text-muted-foreground opacity-50" />
                    <p className="text-sm text-muted-foreground" data-testid="text-no-exit-windows">
                      No exit windows are currently available. Trading is only permitted during quarterly exit windows.
                    </p>
                  </Card>
                )}
              </>
            )}
          </>
        ) : (
          <>
            <div className="flex items-center justify-between gap-4 flex-wrap">
              <div>
                <Button variant="outline" size="sm" onClick={() => { setSelectedWindow(null); }} data-testid="button-back-to-windows">
                  Back to Exit Windows
                </Button>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <Badge variant={getStatusVariant(selectedWindow.status)} data-testid="text-window-status">
                  {selectedWindow.status.charAt(0).toUpperCase() + selectedWindow.status.slice(1)}
                </Badge>
                {selectedWindow.quarter && (
                  <Badge variant="outline" className="no-default-hover-elevate" data-testid="text-window-quarter">
                    {selectedWindow.quarter}
                  </Badge>
                )}
                <Badge variant="outline" className="no-default-hover-elevate" data-testid="text-settlement-currency">
                  Settlement: {baseCurrency}
                </Badge>
                <Badge variant="outline" className="no-default-hover-elevate" data-testid="text-exit-fee">
                  <Percent className="w-3 h-3 mr-0.5" />
                  Exit Fee: {exitFeePercent}%
                </Badge>
              </div>
            </div>

            <Card className="p-4" data-testid="card-window-details">
              <div className="flex items-start justify-between gap-4 flex-wrap">
                <div>
                  <p className="font-semibold" data-testid="text-window-name">{selectedWindow.name}</p>
                  <p className="text-sm text-muted-foreground">{selectedAsset?.name} ({selectedAsset?.symbol})</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {formatDate(selectedWindow.opensAt, "short")} — {formatDate(selectedWindow.closesAt, "short")}
                  </p>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <WindowCountdown closesAt={selectedWindow.closesAt} />
                  {portfolioForAsset && (
                    <p className="text-xs text-muted-foreground" data-testid="text-your-tokens">
                      Your tokens: {parseFloat(portfolioForAsset.quantity).toFixed(0)}
                    </p>
                  )}
                  {needsFxConvert && (
                    <div className="flex items-center gap-1 text-xs text-amber-600 dark:text-amber-400">
                      <ArrowRightLeft className="w-3 h-3" />
                      <span>Requires {baseCurrency}</span>
                    </div>
                  )}
                </div>
              </div>
            </Card>

            <Card className="p-3 border-border bg-muted/30" data-testid="card-exit-fee-info">
              <div className="flex items-start gap-2">
                <Percent className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium">Exit Fee: {exitFeePercent}%</p>
                  <p className="text-xs text-muted-foreground">
                    A {exitFeePercent}% exit fee is deducted from seller proceeds on all trades in this window.
                    Buyers pay the full listing price — sellers receive proceeds minus the fee.
                  </p>
                </div>
              </div>
            </Card>

            {portfolioForAsset && parseFloat(portfolioForAsset.quantity) > 0 && selectedWindow.status === "open" && (
              <GlassButton variant="primary" onClick={handleSellClick} data-testid="button-sell-tokens">
                <ListPlus className="w-4 h-4 mr-1" />
                List Your Tokens for Sale
              </GlassButton>
            )}

            {needsFxConvert && (
              <Card className="p-3 border-amber-500/30 bg-amber-500/5" data-testid="card-fx-notice">
                <div className="flex items-start gap-2">
                  <ArrowRightLeft className="w-4 h-4 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-amber-700 dark:text-amber-300">
                      Trades settle in {baseCurrency}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Your default currency is {userCurrency}. You need {baseCurrency} in your wallet to buy tokens. Convert funds first if needed.
                    </p>
                    <Link href="/investor/wallet">
                      <Button variant="outline" size="sm" className="mt-2" data-testid="button-go-to-wallet-fx">
                        <ArrowRightLeft className="w-3.5 h-3.5 mr-1" />
                        Go to Wallet to Convert
                      </Button>
                    </Link>
                  </div>
                </div>
              </Card>
            )}

            <div>
              <p className="text-sm font-semibold mb-3" data-testid="text-listings-header">
                Available Listings ({activeListings.length})
              </p>

              {listingsLoading ? (
                <div className="space-y-3">
                  {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-16 rounded-md" />)}
                </div>
              ) : activeListings.length === 0 ? (
                <Card className="p-6 text-center">
                  <Tag className="w-8 h-8 mx-auto mb-2 text-muted-foreground opacity-50" />
                  <p className="text-sm text-muted-foreground" data-testid="text-no-listings">No active listings in this exit window.</p>
                </Card>
              ) : (
                <div className="space-y-3">
                  {activeListings.map(listing => {
                    const remaining = parseFloat(listing.remainingQuantity);
                    const price = parseFloat(listing.pricePerToken);
                    return (
                      <Card key={listing.id} className="p-4" data-testid={`listing-${listing.id}`}>
                        <div className="flex items-center justify-between gap-4 flex-wrap">
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-md gradient-hero flex items-center justify-center flex-shrink-0">
                              <Tag className="w-4 h-4 text-white" />
                            </div>
                            <div>
                              <p className="text-sm font-semibold" data-testid={`listing-seller-${listing.id}`}>
                                {listing.sellerName}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {remaining.toFixed(0)} tokens at {formatCurrency(price, listing.currency)} each
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className="text-right">
                              <p className="text-xs text-muted-foreground">Total value</p>
                              <p className="text-sm font-semibold" data-testid={`listing-total-${listing.id}`}>
                                {formatCurrency(remaining * price, listing.currency)}
                              </p>
                            </div>
                            <GlassButton
                              variant="primary"
                              onClick={() => handleBuyClick(listing)}
                              data-testid={`button-buy-${listing.id}`}
                            >
                              <ShoppingCart className="w-4 h-4 mr-1" />
                              Buy
                            </GlassButton>
                          </div>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              )}
            </div>

            {myListings.length > 0 && (
              <div>
                <p className="text-sm font-semibold mb-3" data-testid="text-my-listings-header">
                  Your Listings ({myListings.length})
                </p>
                <div className="space-y-3">
                  {myListings.map(listing => {
                    const remaining = parseFloat(listing.remainingQuantity);
                    const price = parseFloat(listing.pricePerToken);
                    const listingTotal = remaining * price;
                    const listingFee = listingTotal * exitFeePercent / 100;
                    const listingNet = listingTotal - listingFee;
                    return (
                      <Card key={listing.id} className="p-4" data-testid={`my-listing-${listing.id}`}>
                        <div className="flex items-center justify-between gap-4 flex-wrap">
                          <div>
                            <p className="text-sm font-semibold">
                              {remaining.toFixed(0)} tokens at {formatCurrency(price, listing.currency)}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              Total: {formatCurrency(listingTotal, listing.currency)}
                              {" | "}Fee: {formatCurrency(listingFee, listing.currency)}
                              {" | "}You receive: {formatCurrency(listingNet, listing.currency)}
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant={listing.status === "active" ? "default" : "outline"}>
                              {listing.status}
                            </Badge>
                            {listing.status === "active" && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => cancelMutation.mutate(listing.id)}
                                disabled={cancelMutation.isPending}
                                data-testid={`button-cancel-listing-${listing.id}`}
                              >
                                Cancel
                              </Button>
                            )}
                          </div>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              </div>
            )}
          </>
        )}
      </div>

      <Dialog open={showBuyModal} onOpenChange={(open) => { if (!open) { setShowBuyModal(false); setSelectedListing(null); } }}>
        <DialogContent className="sm:max-w-md" data-testid="buy-modal">
          <DialogHeader>
            <DialogTitle data-testid="buy-modal-title">Buy Tokens</DialogTitle>
            <DialogDescription>
              {selectedAsset?.name} ({selectedAsset?.symbol}) — Settlement in {baseCurrency}
            </DialogDescription>
          </DialogHeader>

          {checkLoading ? (
            <div className="space-y-3">
              <Skeleton className="h-10 rounded-md" />
              <Skeleton className="h-20 rounded-md" />
            </div>
          ) : tradeCheck && selectedListing ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-2 text-sm">
                <span className="text-muted-foreground">Price per token</span>
                <span className="font-semibold" data-testid="buy-price-per-token">
                  {formatCurrency(listingPrice, baseCurrency)}
                </span>
              </div>
              <div className="flex items-center justify-between gap-2 text-sm">
                <span className="text-muted-foreground">Available</span>
                <span className="font-semibold" data-testid="buy-available-qty">
                  {tradeCheck.remainingQuantity.toFixed(0)} tokens
                </span>
              </div>
              <div className="flex items-center justify-between gap-2 text-sm">
                <span className="text-muted-foreground">Your {baseCurrency} balance</span>
                <span className={`font-semibold ${tradeCheck.availableBalance <= 0 ? "text-destructive" : ""}`} data-testid="buy-available-balance">
                  {formatCurrency(Math.max(0, tradeCheck.availableBalance), baseCurrency)}
                </span>
              </div>

              {needsFxConvert && tradeCheck.availableBalance <= 0 && (
                <div className="rounded-md border border-amber-500/30 bg-amber-500/5 p-3" data-testid="buy-fx-notice">
                  <div className="flex items-start gap-2">
                    <ArrowRightLeft className="w-4 h-4 text-amber-600 dark:text-amber-400 mt-0.5 flex-shrink-0" />
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-amber-700 dark:text-amber-300">
                        Convert {userCurrency} to {baseCurrency} first
                      </p>
                      {tradeCheck.otherBalances.length > 0 && (
                        <div className="mt-1 space-y-1">
                          {tradeCheck.otherBalances.map(b => (
                            <p key={b.currency} className="text-xs" data-testid={`buy-other-balance-${b.currency}`}>
                              {formatCurrency(b.available, b.currency)}
                            </p>
                          ))}
                        </div>
                      )}
                      <Link href="/investor/wallet">
                        <Button variant="outline" size="sm" className="mt-2" data-testid="button-go-to-wallet-modal">
                          <ArrowRightLeft className="w-3.5 h-3.5 mr-1" />
                          Go to Wallet to Convert
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="buy-qty">Number of tokens</Label>
                <Input
                  id="buy-qty"
                  type="number"
                  min="1"
                  max={tradeCheck.remainingQuantity}
                  step="1"
                  placeholder="Enter quantity"
                  value={buyQuantity}
                  onChange={(e) => setBuyQuantity(e.target.value)}
                  data-testid="input-buy-quantity"
                />
              </div>

              {qty > 0 && (
                <div className="rounded-md border p-3 space-y-2">
                  <div className="flex items-center justify-between gap-2 text-sm">
                    <span className="text-muted-foreground">Total cost (you pay)</span>
                    <span className="font-bold" data-testid="buy-total-cost">
                      {formatCurrency(totalCost, baseCurrency)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-2 text-xs text-muted-foreground">
                    <span>Exit fee ({exitFeePercent}% on seller)</span>
                    <span data-testid="buy-exit-fee">{formatCurrency(totalCost * exitFeePercent / 100, baseCurrency)}</span>
                  </div>
                  {!hasEnoughBalance && totalCost > 0 && (
                    <div className="flex items-start gap-2 text-sm" data-testid="buy-shortfall-warning">
                      <AlertTriangle className="w-4 h-4 text-destructive mt-0.5 flex-shrink-0" />
                      <span className="text-destructive">
                        You need {formatCurrency(shortfall, baseCurrency)} more in {baseCurrency}.
                        Convert from another currency in your wallet first.
                      </span>
                    </div>
                  )}
                  {hasEnoughBalance && totalCost > 0 && (
                    <div className="flex items-center gap-2 text-sm text-emerald-600 dark:text-emerald-400" data-testid="buy-balance-ok">
                      <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                      <span>Sufficient balance available</span>
                    </div>
                  )}
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => { setShowBuyModal(false); setSelectedListing(null); }}
                  data-testid="button-cancel-buy"
                >
                  Cancel
                </Button>
                <GlassButton
                  variant="primary"
                  className="flex-1"
                  disabled={qty <= 0 || !hasEnoughBalance || qty > tradeCheck.remainingQuantity || buyMutation.isPending}
                  onClick={handleConfirmBuy}
                  data-testid="button-confirm-buy"
                >
                  {buyMutation.isPending ? "Processing..." : "Confirm Purchase"}
                </GlassButton>
              </div>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>

      <Dialog open={showSellModal} onOpenChange={(open) => { if (!open) setShowSellModal(false); }}>
        <DialogContent className="sm:max-w-md" data-testid="sell-modal">
          <DialogHeader>
            <DialogTitle data-testid="sell-modal-title">List Tokens for Sale</DialogTitle>
            <DialogDescription>
              {selectedAsset?.name} ({selectedAsset?.symbol}) — Priced in {baseCurrency}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {portfolioForAsset && (
              <div className="flex items-center justify-between gap-2 text-sm">
                <span className="text-muted-foreground">Your tokens</span>
                <span className="font-semibold" data-testid="sell-your-tokens">
                  {parseFloat(portfolioForAsset.quantity).toFixed(0)}
                </span>
              </div>
            )}
            <div className="flex items-center justify-between gap-2 text-sm">
              <span className="text-muted-foreground">Market price</span>
              <span className="font-semibold" data-testid="sell-market-price">
                {selectedAsset ? formatCurrency(parseFloat(selectedAsset.pricePerToken), baseCurrency) : "—"}
              </span>
            </div>

            <div className="space-y-2">
              <Label htmlFor="sell-qty">Quantity to sell</Label>
              <Input
                id="sell-qty"
                type="number"
                min="1"
                max={portfolioForAsset ? parseFloat(portfolioForAsset.quantity) : 0}
                step="1"
                placeholder="Enter quantity"
                value={sellQuantity}
                onChange={(e) => setSellQuantity(e.target.value)}
                data-testid="input-sell-quantity"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="sell-price">Price per token ({baseCurrency})</Label>
              <Input
                id="sell-price"
                type="number"
                min="0.01"
                step="0.01"
                placeholder="Enter price per token"
                value={sellPrice}
                onChange={(e) => setSellPrice(e.target.value)}
                data-testid="input-sell-price"
              />
            </div>

            {sellQty > 0 && sellPriceNum > 0 && (
              <div className="rounded-md border p-3 space-y-2">
                <div className="flex items-center justify-between gap-2 text-sm">
                  <span className="text-muted-foreground">Total listing value</span>
                  <span className="font-semibold" data-testid="sell-total-value">
                    {formatCurrency(sellTotalValue, baseCurrency)}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2 text-sm text-destructive">
                  <span>Exit fee ({exitFeePercent}%)</span>
                  <span data-testid="sell-exit-fee">-{formatCurrency(sellExitFee, baseCurrency)}</span>
                </div>
                <div className="border-t pt-2 flex items-center justify-between gap-2 text-sm">
                  <span className="font-medium">You receive</span>
                  <span className="font-bold text-emerald-600 dark:text-emerald-400" data-testid="sell-net-proceeds">
                    {formatCurrency(sellNetProceeds, baseCurrency)}
                  </span>
                </div>
              </div>
            )}

            <div className="flex gap-2 pt-2">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setShowSellModal(false)}
                data-testid="button-cancel-sell"
              >
                Cancel
              </Button>
              <GlassButton
                variant="primary"
                className="flex-1"
                disabled={
                  sellQty <= 0 ||
                  sellPriceNum <= 0 ||
                  (portfolioForAsset ? sellQty > parseFloat(portfolioForAsset.quantity) : true) ||
                  sellMutation.isPending
                }
                onClick={handleConfirmSell}
                data-testid="button-confirm-sell"
              >
                {sellMutation.isPending ? "Listing..." : "List for Sale"}
              </GlassButton>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </RoleLayout>
  );
}

function TradingClosedBanner({ nextWindow, assetMap }: { nextWindow: ExitWindowData | null; assetMap: Record<string, AssetData> }) {
  const { timeLeft } = useCountdown(nextWindow?.opensAt || null);
  const nextAsset = nextWindow ? assetMap[nextWindow.assetId] : null;

  return (
    <Card className="p-4 border-border" data-testid="card-trading-closed">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center flex-shrink-0">
          <Lock className="w-5 h-5 text-muted-foreground" />
        </div>
        <div className="space-y-1">
          <p className="text-sm font-semibold">Trading is currently closed</p>
          <p className="text-xs text-muted-foreground">
            Token trading is only permitted during quarterly exit windows. All trades outside these windows are restricted to protect asset liquidity.
          </p>
          {nextWindow && (
            <div className="flex items-center gap-2 mt-2">
              <Timer className="w-3.5 h-3.5 text-muted-foreground" />
              <p className="text-xs">
                <span className="text-muted-foreground">Next window: </span>
                <span className="font-medium">{nextWindow.name}</span>
                {nextAsset && <span className="text-muted-foreground"> ({nextAsset.symbol})</span>}
                {timeLeft && (
                  <span className="ml-1 font-semibold text-foreground">
                    — opens in {timeLeft}
                  </span>
                )}
              </p>
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}

function ExitWindowCard({ ew, asset, onSelect }: { ew: ExitWindowData; asset?: AssetData; onSelect: () => void }) {
  const isOpen = ew.status === "open";
  const isScheduled = ew.status === "scheduled";
  const { timeLeft } = useCountdown(isOpen ? ew.closesAt : isScheduled ? ew.opensAt : null);
  const currencyDetail = asset ? CURRENCY_DETAILS[asset.baseCurrency as keyof typeof CURRENCY_DETAILS] : null;
  const feePercent = ew.exitFeePercent ? parseFloat(ew.exitFeePercent) : 1.5;

  return (
    <GlassCard data-testid={`exit-window-${ew.id}`}>
      <div className="space-y-3">
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className="font-semibold text-sm" data-testid={`exit-window-name-${ew.id}`}>{ew.name}</p>
            <p className="text-xs text-muted-foreground">{asset?.name || "Unknown Asset"}</p>
          </div>
          <Badge variant={getStatusVariant(ew.status)} data-testid={`exit-window-status-${ew.id}`}>
            {ew.status.charAt(0).toUpperCase() + ew.status.slice(1)}
          </Badge>
        </div>

        {timeLeft && (
          <div className="flex items-center gap-1.5 text-xs" data-testid={`exit-window-countdown-${ew.id}`}>
            <Timer className="w-3.5 h-3.5 text-muted-foreground" />
            <span className={isOpen ? "text-amber-600 dark:text-amber-400 font-medium" : "text-muted-foreground"}>
              {isOpen ? `Closes in ${timeLeft}` : `Opens in ${timeLeft}`}
            </span>
          </div>
        )}

        <div className="grid grid-cols-2 gap-2 text-xs">
          <div>
            <span className="text-muted-foreground">Opens: </span>
            <span>{formatDate(ew.opensAt, "short")}</span>
          </div>
          <div>
            <span className="text-muted-foreground">Closes: </span>
            <span>{formatDate(ew.closesAt, "short")}</span>
          </div>
          <div>
            <span className="text-muted-foreground">Currency: </span>
            <span>{asset?.baseCurrency || "—"}</span>
          </div>
          <div>
            <span className="text-muted-foreground">Exit Fee: </span>
            <span>{feePercent}%</span>
          </div>
          {ew.quarter && (
            <div>
              <span className="text-muted-foreground">Quarter: </span>
              <span>{ew.quarter}</span>
            </div>
          )}
          <div>
            <span className="text-muted-foreground">Token Price: </span>
            <span>{asset ? `${currencyDetail?.symbol || asset.baseCurrency} ${parseFloat(asset.pricePerToken).toFixed(2)}` : "—"}</span>
          </div>
        </div>

        <GlassButton
          variant="primary"
          className="w-full"
          onClick={onSelect}
          disabled={!isOpen}
          data-testid={`button-view-window-${ew.id}`}
        >
          {isOpen ? "View Listings" : isScheduled ? "Scheduled" : "Closed"}
        </GlassButton>
      </div>
    </GlassCard>
  );
}

function WindowCountdown({ closesAt }: { closesAt: string }) {
  const { timeLeft } = useCountdown(closesAt);

  if (!timeLeft) return null;

  return (
    <div className="flex items-center gap-1 text-xs text-amber-600 dark:text-amber-400" data-testid="text-window-countdown">
      <Clock className="w-3 h-3" />
      <span className="font-medium">Closes in {timeLeft}</span>
    </div>
  );
}
