import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Award, Download, FileCheck, Loader2, ShieldCheck, ArrowLeft,
} from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { Link } from "wouter";
interface TokenHolding {
  id: string;
  tokenId: string;
  balance: string;
  updatedAt: string;
}

interface Token {
  id: string;
  tokenSymbol: string;
  shareClassId: string;
}

interface Certificate {
  id: string;
  tokenSymbol: string;
  investorName: string;
  balance: string;
  snapshotDate: string;
  verificationHash: string;
  createdAt: string;
  propertyTitle: string | null;
  propertyLocation: string | null;
  spvName: string | null;
  spvJurisdiction: string | null;
  ownershipPercentage: string | null;
  totalTokenSupply: string | null;
  propertyValue: string | null;
  currency: string | null;
}

async function downloadPdf(certId: string, filename: string) {
  const resp = await fetch(`/api/tokenization/certificates/${certId}/download`, { credentials: "include" });
  if (!resp.ok) throw new Error(`Download failed (${resp.status})`);
  const blob = await resp.blob();
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export default function InvestorCertificates() {
  const { toast } = useToast();
  const [selectedToken, setSelectedToken] = useState<string>("");
  const [downloadingId, setDownloadingId] = useState<string | null>(null);

  const { data: holdings = [], isLoading: holdingsLoading } = useQuery<TokenHolding[]>({
    queryKey: ["/api/tokenization/holdings"],
  });

  const { data: allTokens = [] } = useQuery<Token[]>({
    queryKey: ["/api/tokenization/tokens"],
  });

  const { data: certificates = [], isLoading: certsLoading } = useQuery<Certificate[]>({
    queryKey: ["/api/tokenization/certificates"],
  });

  const generateMutation = useMutation({
    mutationFn: async (tokenId: string) => {
      const res = await apiRequest("POST", "/api/tokenization/certificates/generate", { tokenId });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tokenization/certificates"] });
      toast({ title: "Certificate Generated", description: "Your ownership certificate has been created." });
      setSelectedToken("");
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const holdingsWithTokens = holdings
    .filter((h) => parseFloat(h.balance) > 0)
    .map((h) => {
      const token = allTokens.find((t) => t.id === h.tokenId);
      return { ...h, tokenSymbol: token?.tokenSymbol || h.tokenId };
    });

  const handleDownload = async (cert: Certificate) => {
    setDownloadingId(cert.id);
    try {
      await downloadPdf(cert.id, `certificate_${cert.tokenSymbol}_${cert.snapshotDate}.pdf`);
    } catch {
      toast({ title: "Download Failed", description: "Could not download certificate.", variant: "destructive" });
    } finally {
      setDownloadingId(null);
    }
  };

  return (
    <RoleLayout role="investor">
      <div className="flex items-center gap-3">
        <Link href="/investor/dashboard">
          <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <PageTitle title="Token Certificates" />
      </div>
      <Section>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileCheck className="w-5 h-5" />
              Generate Ownership Certificate
            </CardTitle>
          </CardHeader>
          <CardContent>
            {holdingsLoading ? (
              <div className="flex items-center gap-2 text-muted-foreground" data-testid="loading-holdings">
                <Loader2 className="w-4 h-4 animate-spin" />
                Loading holdings...
              </div>
            ) : holdingsWithTokens.length === 0 ? (
              <p className="text-muted-foreground" data-testid="text-no-holdings">
                You don't have any token holdings to generate certificates for.
              </p>
            ) : (
              <div className="flex items-center gap-3 flex-wrap">
                <Select value={selectedToken} onValueChange={setSelectedToken}>
                  <SelectTrigger className="w-[240px]" data-testid="select-token">
                    <SelectValue placeholder="Select a token" />
                  </SelectTrigger>
                  <SelectContent>
                    {holdingsWithTokens.map((h) => (
                      <SelectItem key={h.tokenId} value={h.tokenId} data-testid={`select-token-${h.tokenSymbol}`}>
                        {h.tokenSymbol} ({h.balance} tokens)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  onClick={() => selectedToken && generateMutation.mutate(selectedToken)}
                  disabled={!selectedToken || generateMutation.isPending}
                  data-testid="button-generate-certificate"
                >
                  {generateMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin mr-1" />
                  ) : (
                    <Award className="w-4 h-4 mr-1" />
                  )}
                  Generate Certificate
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="mt-4">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5" />
              Certificate History
            </CardTitle>
          </CardHeader>
          <CardContent>
            {certsLoading ? (
              <div className="flex items-center gap-2 text-muted-foreground" data-testid="loading-certificates">
                <Loader2 className="w-4 h-4 animate-spin" />
                Loading certificates...
              </div>
            ) : certificates.length === 0 ? (
              <p className="text-muted-foreground" data-testid="text-no-certificates">
                No certificates generated yet. Select a token above to create your first certificate.
              </p>
            ) : (
              <div className="space-y-3">
                {certificates.map((cert) => (
                  <div
                    key={cert.id}
                    className="flex items-center justify-between gap-4 p-4 border rounded-md flex-wrap"
                    data-testid={`cert-row-${cert.id}`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Award className="w-5 h-5 text-primary" />
                      </div>
                      <div className="min-w-0">
                        <div className="font-medium flex items-center gap-2 flex-wrap" data-testid={`cert-symbol-${cert.id}`}>
                          {cert.tokenSymbol}
                          <Badge variant="secondary">{cert.balance} tokens</Badge>
                          {cert.ownershipPercentage && (
                            <Badge variant="outline" data-testid={`cert-pct-${cert.id}`}>
                              {parseFloat(cert.ownershipPercentage).toFixed(2)}% ownership
                            </Badge>
                          )}
                        </div>
                        {cert.propertyTitle && (
                          <div className="text-sm font-medium mt-0.5" data-testid={`cert-property-${cert.id}`}>
                            {cert.propertyTitle}
                            {cert.propertyLocation && <span className="text-muted-foreground"> - {cert.propertyLocation}</span>}
                          </div>
                        )}
                        {cert.spvName && (
                          <div className="text-xs text-muted-foreground" data-testid={`cert-spv-${cert.id}`}>
                            SPV: {cert.spvName} ({cert.spvJurisdiction || "N/A"})
                          </div>
                        )}
                        <div className="text-sm text-muted-foreground" data-testid={`cert-date-${cert.id}`}>
                          Snapshot: {cert.snapshotDate}
                        </div>
                        <div className="text-xs text-muted-foreground font-mono truncate max-w-[300px]" data-testid={`cert-hash-${cert.id}`}>
                          Hash: {cert.verificationHash.substring(0, 24)}...
                        </div>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => handleDownload(cert)}
                      disabled={downloadingId === cert.id}
                      data-testid={`button-download-${cert.id}`}
                    >
                      {downloadingId === cert.id ? (
                        <Loader2 className="w-4 h-4 animate-spin mr-1" />
                      ) : (
                        <Download className="w-4 h-4 mr-1" />
                      )}
                      Download PDF
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </Section>
    </RoleLayout>
  );
}
