import AdminAdtPage from "@/pages/admin/adt";

export default function InvestorAdtPage() {
  return <AdminAdtPage readOnly />;
}
