import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  attachCryptoWalletSchema,
  type AttachCryptoWallet,
  type CryptoWallet,
} from "@shared/schema";
import {
  Plus,
  Trash2,
  Copy,
  Wallet,
  ShieldAlert,
  ExternalLink, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface ChainInfo {
  id: string;
  name: string;
  symbol: string;
  networkType: string;
  explorerUrl: string;
  addressPattern: string;
}

interface TokenInfo {
  symbol: string;
  name: string;
  chains: readonly string[];
}

interface ChainsResponse {
  chains: ChainInfo[];
  tokens: TokenInfo[];
}

export default function InvestorCryptoWallets() {
  const { toast } = useToast();
  const [showAddDialog, setShowAddDialog] = useState(false);

  const { data: chainsData } = useQuery<ChainsResponse>({
    queryKey: ["/api/crypto/chains"],
  });

  const { data: wallets, isLoading } = useQuery<CryptoWallet[]>({
    queryKey: ["/api/crypto/wallets"],
  });

  const form = useForm<AttachCryptoWallet>({
    resolver: zodResolver(attachCryptoWalletSchema),
    defaultValues: {
      chainId: "",
      address: "",
      label: "",
    },
  });

  const addMutation = useMutation({
    mutationFn: async (data: AttachCryptoWallet) => {
      const res = await apiRequest("POST", "/api/crypto/wallets", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/crypto/wallets"] });
      setShowAddDialog(false);
      form.reset();
      toast({ title: "Wallet attached successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to attach wallet", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/crypto/wallets/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/crypto/wallets"] });
      toast({ title: "Wallet removed" });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to remove wallet", description: error.message, variant: "destructive" });
    },
  });

  function getChain(chainId: string) {
    return chainsData?.chains.find(c => c.id === chainId);
  }

  function getTokensForChain(chainId: string) {
    return chainsData?.tokens.filter(t => t.chains.includes(chainId)) || [];
  }

  function copyAddress(address: string) {
    navigator.clipboard.writeText(address);
    toast({ title: "Address copied to clipboard" });
  }

  function truncateAddress(addr: string) {
    if (addr.length <= 16) return addr;
    return `${addr.slice(0, 8)}...${addr.slice(-6)}`;
  }

  const selectedChainId = form.watch("chainId");
  const selectedChain = selectedChainId ? getChain(selectedChainId) : null;

  return (
    <RoleLayout role="investor">
      <div className="p-6 space-y-6 max-w-5xl mx-auto">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-3">
            <Link href="/investor/dashboard">
              <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <PageTitle title="Crypto Wallets" description="Attach your blockchain wallet addresses for crypto deposits" />
          </div>
          <Button onClick={() => setShowAddDialog(true)} data-testid="button-add-wallet">
            <Plus className="w-4 h-4 mr-2" />
            Attach Wallet
          </Button>
        </div>

        <Section title="Supported Chains & Tokens">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {chainsData?.chains.map(chain => {
              const tokens = getTokensForChain(chain.id);
              return (
                <GlassCard key={chain.id} className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-medium text-sm" data-testid={`text-chain-${chain.id}`}>{chain.name}</span>
                    <Badge variant="secondary">{chain.symbol}</Badge>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {tokens.map(t => (
                      <Badge key={t.symbol} variant="outline" data-testid={`badge-token-${chain.id}-${t.symbol}`}>{t.symbol}</Badge>
                    ))}
                    {tokens.length === 0 && <span className="text-xs text-muted-foreground">No stablecoins</span>}
                  </div>
                </GlassCard>
              );
            })}
          </div>
        </Section>

        <Section title="My Wallets">
          {isLoading ? (
            <div className="space-y-3">
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
            </div>
          ) : !wallets || wallets.length === 0 ? (
            <GlassCard className="p-8 text-center">
              <Wallet className="w-10 h-10 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground">No wallets attached yet. Click "Attach Wallet" to add your first crypto wallet.</p>
            </GlassCard>
          ) : (
            <div className="space-y-3">
              {wallets.map(wallet => {
                const chain = getChain(wallet.chainId);
                const tokens = getTokensForChain(wallet.chainId);
                return (
                  <GlassCard key={wallet.id} className="p-4" data-testid={`card-wallet-${wallet.id}`}>
                    <div className="flex items-start justify-between flex-wrap gap-2">
                      <div className="space-y-1 min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium" data-testid={`text-wallet-chain-${wallet.id}`}>{chain?.name || wallet.chainId}</span>
                          <Badge variant="secondary">{chain?.symbol || wallet.chainId}</Badge>
                          {wallet.isBlacklisted && (
                            <Badge variant="destructive" data-testid={`badge-blacklisted-${wallet.id}`}>
                              <ShieldAlert className="w-3 h-3 mr-1" />
                              Blacklisted
                            </Badge>
                          )}
                        </div>
                        {wallet.label && <p className="text-sm text-muted-foreground" data-testid={`text-wallet-label-${wallet.id}`}>{wallet.label}</p>}
                        <div className="flex items-center gap-2">
                          <code className="text-xs font-mono bg-muted px-2 py-1 rounded-md break-all" data-testid={`text-wallet-address-${wallet.id}`}>
                            {truncateAddress(wallet.address)}
                          </code>
                          <Button size="icon" variant="ghost" onClick={() => copyAddress(wallet.address)} data-testid={`button-copy-${wallet.id}`}>
                            <Copy className="w-3 h-3" />
                          </Button>
                          {chain && (
                            <a href={`${chain.explorerUrl}/address/${wallet.address}`} target="_blank" rel="noopener noreferrer">
                              <Button size="icon" variant="ghost" data-testid={`button-explorer-${wallet.id}`}>
                                <ExternalLink className="w-3 h-3" />
                              </Button>
                            </a>
                          )}
                        </div>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {tokens.map(t => (
                            <Badge key={t.symbol} variant="outline">{t.symbol}</Badge>
                          ))}
                        </div>
                      </div>
                      <div>
                        {!wallet.isBlacklisted && (
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => deleteMutation.mutate(wallet.id)}
                            disabled={deleteMutation.isPending}
                            data-testid={`button-delete-wallet-${wallet.id}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </GlassCard>
                );
              })}
            </div>
          )}
        </Section>

        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Attach Crypto Wallet</DialogTitle>
              <DialogDescription>Link a blockchain wallet address to your account for crypto operations.</DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit((data) => addMutation.mutate(data))} className="space-y-4">
                <FormField
                  control={form.control}
                  name="chainId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Blockchain Network</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-chain">
                            <SelectValue placeholder="Select a chain" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {chainsData?.chains.map(chain => (
                            <SelectItem key={chain.id} value={chain.id} data-testid={`option-chain-${chain.id}`}>
                              {chain.name} ({chain.symbol})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {selectedChain && (
                  <div className="text-xs text-muted-foreground">
                    Supported tokens: {getTokensForChain(selectedChainId).map(t => t.symbol).join(", ") || "None"}
                  </div>
                )}

                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Wallet Address</FormLabel>
                      <FormControl>
                        <Input placeholder={selectedChain?.networkType === "evm" ? "0x..." : "Enter wallet address"} {...field} data-testid="input-address" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="label"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Label (optional)</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., My Main Wallet" {...field} data-testid="input-label" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full" disabled={addMutation.isPending} data-testid="button-submit-wallet">
                  {addMutation.isPending ? "Attaching..." : "Attach Wallet"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </RoleLayout>
  );
}
