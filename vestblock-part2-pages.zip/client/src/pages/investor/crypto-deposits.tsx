import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  createCryptoDepositSchema,
  type CreateCryptoDeposit,
  type CryptoDepositIntent,
} from "@shared/schema";
import {
  Plus,
  Copy,
  ArrowDownLeft,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle, ArrowLeft,
} from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { Link } from "wouter";
interface ChainInfo {
  id: string;
  name: string;
  symbol: string;
  networkType: string;
  explorerUrl: string;
  addressPattern: string;
}

interface TokenInfo {
  symbol: string;
  name: string;
  chains: string[];
}

interface ChainCatalog {
  chains: ChainInfo[];
  tokens: TokenInfo[];
}

const STATUS_CONFIG: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline"; icon: any }> = {
  CREATED: { label: "Awaiting Payment", variant: "outline", icon: Clock },
  PENDING: { label: "Pending", variant: "secondary", icon: AlertCircle },
  CONFIRMED: { label: "Confirmed", variant: "default", icon: CheckCircle2 },
  REJECTED: { label: "Rejected", variant: "destructive", icon: XCircle },
  EXPIRED: { label: "Expired", variant: "secondary", icon: Clock },
  AML_HOLD: { label: "Under Review", variant: "secondary", icon: AlertCircle },
};

export default function InvestorCryptoDeposits() {
  const { toast } = useToast();
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedIntent, setSelectedIntent] = useState<CryptoDepositIntent | null>(null);

  const { data: catalog } = useQuery<ChainCatalog>({
    queryKey: ["/api/crypto/chains"],
  });

  const { data: intents, isLoading } = useQuery<CryptoDepositIntent[]>({
    queryKey: ["/api/crypto/deposit-intents"],
  });

  const form = useForm<CreateCryptoDeposit>({
    resolver: zodResolver(createCryptoDepositSchema),
    defaultValues: {
      chainId: "",
      tokenSymbol: "USDT",
      amount: 0,
    },
  });

  const selectedChainId = form.watch("chainId");
  const selectedToken = form.watch("tokenSymbol");

  const availableTokens = catalog?.tokens.filter(t =>
    t.chains.includes(selectedChainId)
  ) || [];

  const createMutation = useMutation({
    mutationFn: async (data: CreateCryptoDeposit) => {
      const res = await apiRequest("POST", "/api/crypto/deposit-intents", data);
      return res.json();
    },
    onSuccess: (data: CryptoDepositIntent) => {
      queryClient.invalidateQueries({ queryKey: ["/api/crypto/deposit-intents"] });
      setShowCreateDialog(false);
      setSelectedIntent(data);
      form.reset();
      toast({ title: "Deposit intent created", description: "Send the exact amount to the address shown." });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to create deposit intent", variant: "destructive" });
    },
  });

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied", description: "Address copied to clipboard" });
  };

  const getChainName = (chainId: string) => {
    return catalog?.chains.find(c => c.id === chainId)?.name || chainId;
  };

  return (
    <RoleLayout role="investor">
      <div className="p-4 md:p-6 space-y-6">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-3">
            <Link href="/investor/dashboard">
              <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <PageTitle title="Crypto Deposits" description="Deposit stablecoins to your account" />
          </div>
          <Button onClick={() => setShowCreateDialog(true)} data-testid="button-new-deposit">
            <Plus className="w-4 h-4 mr-2" />
            New Deposit
          </Button>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-32 w-full" />)}
          </div>
        ) : intents && intents.length > 0 ? (
          <Section title="Deposit History">
            <div className="grid gap-4">
              {intents.map(intent => {
                const statusCfg = STATUS_CONFIG[intent.status] || STATUS_CONFIG.CREATED;
                const StatusIcon = statusCfg.icon;
                return (
                  <GlassCard key={intent.id} className="p-4">
                    <div className="flex items-start justify-between gap-4 flex-wrap">
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-semibold" data-testid={`text-chain-${intent.id}`}>
                            {getChainName(intent.chainId)}
                          </span>
                          <Badge variant="outline" data-testid={`text-token-${intent.id}`}>
                            {intent.tokenSymbol}
                          </Badge>
                          <Badge variant={statusCfg.variant} data-testid={`text-status-${intent.id}`}>
                            <StatusIcon className="w-3 h-3 mr-1" />
                            {statusCfg.label}
                          </Badge>
                        </div>
                        <p className="text-2xl font-bold" data-testid={`text-amount-${intent.id}`}>
                          {parseFloat(intent.amount).toLocaleString()} {intent.tokenSymbol}
                        </p>
                        <p className="text-sm text-muted-foreground truncate" data-testid={`text-address-${intent.id}`}>
                          To: {intent.invoiceAddress}
                        </p>
                        {intent.txHash && (
                          <p className="text-xs text-muted-foreground">
                            TX: {intent.txHash.slice(0, 16)}...
                          </p>
                        )}
                        <p className="text-xs text-muted-foreground">
                          {new Date(intent.createdAt).toLocaleString()}
                        </p>
                        {intent.confirmations > 0 && (
                          <p className="text-xs text-muted-foreground">
                            Confirmations: {intent.confirmations}/{intent.requiredConfirmations}
                          </p>
                        )}
                        {intent.status === "AML_HOLD" && (
                          <p className="text-xs text-muted-foreground mt-1" data-testid={`text-review-msg-${intent.id}`}>
                            Your deposit is under compliance review. You will be notified once it is cleared.
                          </p>
                        )}
                      </div>
                      <div className="flex gap-2">
                        {intent.status === "CREATED" && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedIntent(intent)}
                            data-testid={`button-view-invoice-${intent.id}`}
                          >
                            View Invoice
                          </Button>
                        )}
                      </div>
                    </div>
                  </GlassCard>
                );
              })}
            </div>
          </Section>
        ) : (
          <GlassCard className="p-8 text-center">
            <ArrowDownLeft className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No Crypto Deposits Yet</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Create a deposit intent to receive stablecoins on any supported chain.
            </p>
            <Button onClick={() => setShowCreateDialog(true)} data-testid="button-new-deposit-empty">
              <Plus className="w-4 h-4 mr-2" />
              New Deposit
            </Button>
          </GlassCard>
        )}

        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>New Crypto Deposit</DialogTitle>
              <DialogDescription>
                Select chain and token, enter the amount you want to deposit.
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit((data) => createMutation.mutate(data))} className="space-y-4">
                <FormField
                  control={form.control}
                  name="chainId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Blockchain</FormLabel>
                      <FormControl>
                        <Select
                          value={field.value}
                          onValueChange={(val) => {
                            field.onChange(val);
                            const tokens = catalog?.tokens.filter(t => t.chains.includes(val)) || [];
                            if (tokens.length > 0 && !tokens.find(t => t.symbol === form.getValues("tokenSymbol"))) {
                              form.setValue("tokenSymbol", tokens[0].symbol as "USDT" | "USDC");
                            }
                          }}
                        >
                          <SelectTrigger data-testid="select-chain">
                            <SelectValue placeholder="Select chain" />
                          </SelectTrigger>
                          <SelectContent>
                            {catalog?.chains.map(chain => (
                              <SelectItem key={chain.id} value={chain.id}>
                                {chain.name} ({chain.symbol})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="tokenSymbol"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Token</FormLabel>
                      <FormControl>
                        <Select value={field.value} onValueChange={field.onChange}>
                          <SelectTrigger data-testid="select-token">
                            <SelectValue placeholder="Select token" />
                          </SelectTrigger>
                          <SelectContent>
                            {availableTokens.map(token => (
                              <SelectItem key={token.symbol} value={token.symbol}>
                                {token.name} ({token.symbol})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Amount</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          min="1"
                          placeholder="Enter amount"
                          data-testid="input-amount"
                          {...field}
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  className="w-full"
                  disabled={createMutation.isPending}
                  data-testid="button-create-deposit"
                >
                  {createMutation.isPending ? "Creating..." : "Create Deposit Intent"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>

        <Dialog open={!!selectedIntent} onOpenChange={() => setSelectedIntent(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Deposit Invoice</DialogTitle>
              <DialogDescription>
                Send exactly {selectedIntent ? parseFloat(selectedIntent.amount).toLocaleString() : ""} {selectedIntent?.tokenSymbol} to the address below.
              </DialogDescription>
            </DialogHeader>
            {selectedIntent && (
              <div className="space-y-4">
                <div className="flex justify-center">
                  <div className="bg-white p-4 rounded-md">
                    <QRCodeSVG
                      value={selectedIntent.qrPayload}
                      size={200}
                      data-testid="qr-code"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Chain</p>
                    <p className="font-medium" data-testid="text-invoice-chain">
                      {getChainName(selectedIntent.chainId)}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Token</p>
                    <p className="font-medium" data-testid="text-invoice-token">{selectedIntent.tokenSymbol}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Amount</p>
                    <p className="font-bold text-lg" data-testid="text-invoice-amount">
                      {parseFloat(selectedIntent.amount).toLocaleString()} {selectedIntent.tokenSymbol}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Send To Address</p>
                    <div className="flex items-center gap-2">
                      <code className="text-xs break-all bg-muted p-2 rounded-md flex-1" data-testid="text-invoice-address">
                        {selectedIntent.invoiceAddress}
                      </code>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => copyToClipboard(selectedIntent.invoiceAddress)}
                        data-testid="button-copy-address"
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  {selectedIntent.memo && (
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Memo / Tag</p>
                      <div className="flex items-center gap-2">
                        <code className="text-xs break-all bg-muted p-2 rounded-md flex-1" data-testid="text-invoice-memo">
                          {selectedIntent.memo}
                        </code>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => copyToClipboard(selectedIntent.memo!)}
                          data-testid="button-copy-memo"
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Required Confirmations</p>
                    <p className="font-medium" data-testid="text-invoice-confirmations">
                      {selectedIntent.requiredConfirmations}
                    </p>
                  </div>
                </div>

                <div className="bg-muted/50 p-3 rounded-md">
                  <p className="text-xs text-muted-foreground">
                    After sending, your deposit will be reviewed and confirmed by our team.
                    The funds will be credited to your USD wallet once confirmed.
                  </p>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </RoleLayout>
  );
}
