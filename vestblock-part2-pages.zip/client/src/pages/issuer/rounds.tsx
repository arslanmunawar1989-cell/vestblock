import { useQuery } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { GlassButton } from "@/components/glass-button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Calendar, Target, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
interface Round {
  id: string;
  assetId: string;
  name: string;
  targetAmount: string;
  raisedAmount: string;
  status: string;
  startDate: string;
  endDate: string | null;
}

interface Asset {
  id: string;
  name: string;
}

export default function IssuerRounds() {
  const { data: allRounds = [], isLoading: roundsLoading } = useQuery<Round[]>({
    queryKey: ["/api/rounds"],
  });

  const { data: assets = [], isLoading: assetsLoading } = useQuery<Asset[]>({
    queryKey: ["/api/issuer/assets"],
  });

  const isLoading = roundsLoading || assetsLoading;

  const assetMap = new Map(assets.map(a => [a.id, a.name]));
  const issuerAssetIds = new Set(assets.map(a => a.id));
  const rounds = allRounds.filter(r => issuerAssetIds.has(r.assetId));

  return (
    <RoleLayout role="issuer">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/issuer/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Investment Rounds"
          description="Manage your fundraising rounds"
          action={
            <GlassButton variant="primary" data-testid="button-create-round">
              <Plus className="w-4 h-4" />
              New Round
            </GlassButton>
          }
        />
        </div>

        <Section>
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-32 w-full" />)}
            </div>
          ) : rounds.length === 0 ? (
            <div className="text-center py-12">
              <Target className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground" data-testid="text-no-rounds">No investment rounds yet. Create your first round to start fundraising.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {rounds.map((round, i) => {
                const target = Number(round.targetAmount);
                const raised = Number(round.raisedAmount);
                const pct = target > 0 ? Math.round((raised / target) * 100) : 0;
                const assetName = assetMap.get(round.assetId) || round.assetId;

                return (
                  <GlassCard key={round.id}>
                    <div className="flex items-start justify-between gap-3 mb-3">
                      <div>
                        <p className="font-semibold text-sm" data-testid={`issuer-round-${i}`}>{round.name}</p>
                        <p className="text-xs text-muted-foreground">{assetName}</p>
                      </div>
                      <Badge variant={round.status === "open" ? "default" : "secondary"} className="text-xs">{round.status}</Badge>
                    </div>
                    <div className="flex items-center justify-between gap-2 text-sm mb-2">
                      <span className="text-muted-foreground">Raised</span>
                      <span className="font-semibold">${raised.toLocaleString()} / ${target.toLocaleString()}</span>
                    </div>
                    <div className="w-full bg-muted rounded-sm h-1.5 mb-3">
                      <div className="gradient-hero h-1.5 rounded-sm" style={{ width: `${pct}%` }} />
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Calendar className="w-3 h-3" />
                      <span>{round.endDate ? `Ends ${round.endDate}` : `Started ${round.startDate}`}</span>
                    </div>
                  </GlassCard>
                );
              })}
            </div>
          )}
        </Section>
      </div>
    </RoleLayout>
  );
}
