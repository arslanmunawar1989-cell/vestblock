import { useState } from "react";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  FileText,
  Upload,
  Trash2,
  Eye,
  CheckCircle,
  Circle,
  FolderOpen,
  Plus,
  AlertCircle, ArrowLeft,
} from "lucide-react";
import type { DataRoomDocument } from "@shared/schema";
import { Link } from "wouter";
const CATEGORIES = ["legal", "financial", "valuation", "compliance", "corporate", "technical", "marketing", "other"] as const;
const STATUSES = ["draft", "live", "archived"] as const;

type Asset = {
  id: string;
  name: string;
  country: string;
};

type ChecklistItemResult = {
  key: string;
  label: string;
  description: string;
  category: string;
  required: boolean;
  uploaded: boolean;
  document: DataRoomDocument | null;
};

type ChecklistResponse = {
  country: string;
  assetId: string;
  items: ChecklistItemResult[];
  totalRequired: number;
  completedRequired: number;
  complete: boolean;
};

function statusBadgeVariant(status: string): "outline" | "default" | "secondary" {
  if (status === "live") return "default";
  if (status === "archived") return "secondary";
  return "outline";
}

function AssetChecklist({ asset }: { asset: Asset }) {
  const { data: checklist, isLoading } = useQuery<ChecklistResponse>({
    queryKey: ["/api/data-room/checklist/asset", asset.id],
  });

  if (isLoading) {
    return (
      <Card className="p-4">
        <div className="animate-pulse space-y-2">
          <div className="h-4 bg-muted rounded w-1/3" />
          <div className="h-3 bg-muted rounded w-1/2" />
        </div>
      </Card>
    );
  }

  if (!checklist || checklist.items.length === 0) return null;

  const requiredItems = checklist.items.filter((i) => i.required);
  const optionalItems = checklist.items.filter((i) => !i.required);

  return (
    <Card className="p-4" data-testid={`checklist-card-${asset.id}`}>
      <div className="flex items-center justify-between gap-4 flex-wrap mb-3">
        <div className="flex items-center gap-2">
          <FolderOpen className="w-4 h-4 text-muted-foreground" />
          <h3 className="font-medium text-sm">{asset.name}</h3>
        </div>
        <Badge variant={checklist.complete ? "default" : "outline"} data-testid={`checklist-progress-${asset.id}`}>
          {checklist.completedRequired}/{checklist.totalRequired} required
        </Badge>
      </div>

      <div className="w-full bg-muted rounded-full h-1.5 mb-3">
        <div
          className="bg-primary h-1.5 rounded-full transition-all"
          style={{
            width: checklist.totalRequired > 0
              ? `${(checklist.completedRequired / checklist.totalRequired) * 100}%`
              : "0%",
          }}
        />
      </div>

      <div className="space-y-1.5">
        {requiredItems.map((item) => (
          <div
            key={item.key}
            className="flex items-center gap-2 text-sm"
            data-testid={`checklist-item-${item.key}`}
          >
            {item.uploaded ? (
              <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
            ) : (
              <Circle className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            )}
            <span className={item.uploaded ? "text-foreground" : "text-muted-foreground"}>
              {item.label}
            </span>
            <Badge variant="outline" className="text-xs ml-auto">
              required
            </Badge>
          </div>
        ))}
        {optionalItems.map((item) => (
          <div
            key={item.key}
            className="flex items-center gap-2 text-sm"
            data-testid={`checklist-item-${item.key}`}
          >
            {item.uploaded ? (
              <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
            ) : (
              <Circle className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            )}
            <span className={item.uploaded ? "text-foreground" : "text-muted-foreground"}>
              {item.label}
            </span>
          </div>
        ))}
      </div>
    </Card>
  );
}

function UploadDialog({ assets }: { assets: Asset[] }) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [selectedAssetId, setSelectedAssetId] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState<string>("legal");
  const [checklistKey, setChecklistKey] = useState("");
  const [fileUrl, setFileUrl] = useState("/uploads/placeholder.pdf");
  const [fileName, setFileName] = useState("");
  const [status, setStatus] = useState<string>("draft");

  const { data: checklist } = useQuery<ChecklistResponse>({
    queryKey: ["/api/data-room/checklist/asset", selectedAssetId],
    enabled: !!selectedAssetId,
  });

  const createMutation = useMutation({
    mutationFn: async (data: Record<string, unknown>) => {
      await apiRequest("POST", "/api/data-room/docs", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/data-room/all"] });
      if (selectedAssetId) {
        queryClient.invalidateQueries({
          queryKey: ["/api/data-room/checklist/asset", selectedAssetId],
        });
      }
      toast({ title: "Document uploaded", description: "Document has been added to the data room." });
      resetForm();
      setOpen(false);
    },
    onError: (err: Error) => {
      toast({ title: "Upload failed", description: err.message, variant: "destructive" });
    },
  });

  function resetForm() {
    setSelectedAssetId("");
    setTitle("");
    setDescription("");
    setCategory("legal");
    setChecklistKey("");
    setFileUrl("/uploads/placeholder.pdf");
    setFileName("");
    setStatus("draft");
  }

  function handleSubmit() {
    if (!selectedAssetId || !title || !fileName || !fileUrl) {
      toast({ title: "Validation error", description: "Please fill all required fields.", variant: "destructive" });
      return;
    }
    createMutation.mutate({
      scope: "asset",
      assetId: selectedAssetId,
      title,
      description: description || undefined,
      category,
      checklistKey: checklistKey || undefined,
      url: fileUrl,
      fileName,
      status,
    });
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button data-testid="button-upload-doc">
          <Plus className="w-4 h-4 mr-1" />
          Upload Document
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" data-testid="upload-dialog">
        <DialogHeader>
          <DialogTitle>Upload Document</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 mt-2">
          <div className="space-y-1.5">
            <Label htmlFor="asset-select">Asset</Label>
            <Select value={selectedAssetId} onValueChange={setSelectedAssetId}>
              <SelectTrigger data-testid="select-asset">
                <SelectValue placeholder="Select asset" />
              </SelectTrigger>
              <SelectContent>
                {assets.map((a) => (
                  <SelectItem key={a.id} value={a.id}>
                    {a.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="doc-title">Title</Label>
            <Input
              id="doc-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Document title"
              data-testid="input-doc-title"
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="doc-description">Description (optional)</Label>
            <Textarea
              id="doc-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief description"
              data-testid="input-doc-description"
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="doc-category">Category</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger data-testid="select-category">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIES.map((c) => (
                  <SelectItem key={c} value={c}>
                    {c.charAt(0).toUpperCase() + c.slice(1)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {checklist && checklist.items.length > 0 && (
            <div className="space-y-1.5">
              <Label htmlFor="doc-checklist-key">Checklist Item (optional)</Label>
              <Select value={checklistKey} onValueChange={setChecklistKey}>
                <SelectTrigger data-testid="select-checklist-key">
                  <SelectValue placeholder="None" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {checklist.items.map((item) => (
                    <SelectItem key={item.key} value={item.key}>
                      {item.label} {item.required ? "(required)" : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="space-y-1.5">
            <Label htmlFor="doc-file-url">File URL</Label>
            <Input
              id="doc-file-url"
              value={fileUrl}
              onChange={(e) => setFileUrl(e.target.value)}
              placeholder="/uploads/document.pdf"
              data-testid="input-file-url"
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="doc-file-name">File Name</Label>
            <Input
              id="doc-file-name"
              value={fileName}
              onChange={(e) => setFileName(e.target.value)}
              placeholder="document.pdf"
              data-testid="input-file-name"
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="doc-status">Status</Label>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger data-testid="select-status">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="live">Live</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button
            className="w-full"
            onClick={handleSubmit}
            disabled={createMutation.isPending}
            data-testid="button-submit-upload"
          >
            {createMutation.isPending ? "Uploading..." : "Upload Document"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function IssuerDocs() {
  const { toast } = useToast();
  const [filterAssetId, setFilterAssetId] = useState("all");

  const { data: assets = [], isLoading: assetsLoading } = useQuery<Asset[]>({
    queryKey: ["/api/assets"],
  });

  const { data: docs = [], isLoading: docsLoading } = useQuery<DataRoomDocument[]>({
    queryKey: ["/api/data-room/all"],
  });

  const assetDocs = docs.filter((d) => d.scope === "asset");
  const filteredDocs =
    filterAssetId === "all"
      ? assetDocs
      : assetDocs.filter((d) => d.assetId === filterAssetId);

  const assetMap = new Map(assets.map((a) => [a.id, a.name]));

  const toggleStatusMutation = useMutation({
    mutationFn: async ({ id, newStatus }: { id: string; newStatus: string }) => {
      await apiRequest("PATCH", `/api/data-room/docs/${id}`, { status: newStatus });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/data-room/all"] });
      toast({ title: "Status updated" });
    },
    onError: (err: Error) => {
      toast({ title: "Update failed", description: err.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/data-room/docs/${id}`);
    },
    onSuccess: (_data, id) => {
      queryClient.invalidateQueries({ queryKey: ["/api/data-room/all"] });
      const doc = docs.find((d) => d.id === id);
      if (doc?.assetId) {
        queryClient.invalidateQueries({
          queryKey: ["/api/data-room/checklist/asset", doc.assetId],
        });
      }
      toast({ title: "Document deleted" });
    },
    onError: (err: Error) => {
      toast({ title: "Delete failed", description: err.message, variant: "destructive" });
    },
  });

  const isLoading = assetsLoading || docsLoading;

  return (
    <RoleLayout role="issuer">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/issuer/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Data Room"
          description="Manage legal, financial, and compliance documents for your assets"
          action={
            !assetsLoading && assets.length > 0 ? (
              <UploadDialog assets={assets} />
            ) : undefined
          }
        />
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="p-4 animate-pulse">
                <div className="h-4 bg-muted rounded w-1/3 mb-2" />
                <div className="h-3 bg-muted rounded w-2/3" />
              </Card>
            ))}
          </div>
        ) : (
          <>
            <Section title="Jurisdiction Checklists" description="Required document status per asset">
              {assets.length === 0 ? (
                <Card className="p-6 text-center">
                  <AlertCircle className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground" data-testid="text-no-assets">
                    No assets found. Create an asset first.
                  </p>
                </Card>
              ) : (
                <div className="grid gap-4 md:grid-cols-2">
                  {assets.map((asset) => (
                    <AssetChecklist key={asset.id} asset={asset} />
                  ))}
                </div>
              )}
            </Section>

            <Section
              title="Documents"
              description="All data room documents"
              action={
                <Select value={filterAssetId} onValueChange={setFilterAssetId}>
                  <SelectTrigger className="w-[200px]" data-testid="select-filter-asset">
                    <SelectValue placeholder="Filter by asset" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Assets</SelectItem>
                    {assets.map((a) => (
                      <SelectItem key={a.id} value={a.id}>
                        {a.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              }
            >
              {filteredDocs.length === 0 ? (
                <Card className="p-6 text-center">
                  <FileText className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground" data-testid="text-no-docs">
                    No documents found. Upload your first document.
                  </p>
                </Card>
              ) : (
                <div className="space-y-3">
                  {filteredDocs.map((doc) => (
                    <Card key={doc.id} className="p-4" data-testid={`doc-card-${doc.id}`}>
                      <div className="flex items-center justify-between gap-3 flex-wrap">
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center flex-shrink-0">
                            <FileText className="w-5 h-5 text-muted-foreground" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-sm font-medium truncate" data-testid={`doc-title-${doc.id}`}>
                              {doc.title}
                            </p>
                            <p className="text-xs text-muted-foreground truncate">
                              {assetMap.get(doc.assetId || "") || "Unknown asset"} &middot; {doc.fileName} &middot;{" "}
                              {doc.createdAt ? new Date(doc.createdAt).toLocaleDateString() : "N/A"}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge variant="outline" className="text-xs" data-testid={`badge-category-${doc.id}`}>
                            {doc.category}
                          </Badge>
                          <Badge
                            variant={statusBadgeVariant(doc.status)}
                            className="text-xs"
                            data-testid={`badge-status-${doc.id}`}
                          >
                            {doc.status}
                          </Badge>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              const newStatus = doc.status === "live" ? "draft" : "live";
                              toggleStatusMutation.mutate({ id: doc.id, newStatus });
                            }}
                            disabled={toggleStatusMutation.isPending}
                            data-testid={`button-toggle-status-${doc.id}`}
                          >
                            <Eye className="w-3.5 h-3.5 mr-1" />
                            {doc.status === "live" ? "Draft" : "Live"}
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => deleteMutation.mutate(doc.id)}
                            disabled={deleteMutation.isPending}
                            data-testid={`button-delete-doc-${doc.id}`}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </Section>
          </>
        )}
      </div>
    </RoleLayout>
  );
}
