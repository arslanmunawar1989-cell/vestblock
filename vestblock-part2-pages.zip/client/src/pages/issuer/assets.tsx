import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  issuerSubmitAssetSchema,
  type IssuerSubmitAsset,
  type Asset,
} from "@shared/schema";
import {
  SUPPORTED_COUNTRIES,
  COUNTRY_DETAILS,
  COUNTRY_TO_CURRENCY,
  JURISDICTION_DOCS,
  ASSET_TYPES,
  ASSET_TYPE_LABELS,
  CURRENCY_DETAILS,
} from "@shared/constants";
import type { CountryCode, CurrencyCode, JurisdictionDoc } from "@shared/constants";
import {
  Plus,
  FileText,
  Clock,
  CheckCircle2,
  AlertCircle,
  Building2,
  ShieldCheck,
  Eye,
  Send, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
const STATUS_STYLES: Record<string, { variant: "default" | "secondary" | "destructive" | "outline"; label: string }> = {
  draft: { variant: "secondary", label: "Draft" },
  submitted: { variant: "default", label: "Submitted" },
  approved: { variant: "default", label: "Approved" },
  rejected: { variant: "destructive", label: "Rejected" },
  changes_requested: { variant: "outline", label: "Changes Requested" },
  pending: { variant: "secondary", label: "Pending" },
  active: { variant: "default", label: "Active" },
};

export default function IssuerAssets() {
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
  const { toast } = useToast();

  const { data: assets, isLoading } = useQuery<Asset[]>({
    queryKey: ["/api/issuer/assets"],
  });

  const handleViewAsset = (asset: Asset) => {
    setSelectedAsset(asset);
    setShowDetailDialog(true);
  };

  const submitted = assets?.filter(a => a.submissionStatus === "submitted").length || 0;
  const approved = assets?.filter(a => a.submissionStatus === "approved").length || 0;
  const drafts = assets?.filter(a => a.submissionStatus === "draft").length || 0;

  return (
    <RoleLayout role="issuer">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/issuer/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="My Assets"
          description="Submit and manage your tokenized asset listings"
          action={
            <Button data-testid="button-create-asset" onClick={() => setShowCreateDialog(true)}>
              <Plus className="w-4 h-4 mr-2" />
              New Asset
            </Button>
          }
        />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <GlassCard>
            <div className="flex items-center gap-3 p-4">
              <FileText className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Drafts</p>
                <p className="text-2xl font-semibold" data-testid="text-draft-count">{drafts}</p>
              </div>
            </div>
          </GlassCard>
          <GlassCard>
            <div className="flex items-center gap-3 p-4">
              <Clock className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Submitted</p>
                <p className="text-2xl font-semibold" data-testid="text-submitted-count">{submitted}</p>
              </div>
            </div>
          </GlassCard>
          <GlassCard>
            <div className="flex items-center gap-3 p-4">
              <CheckCircle2 className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Approved</p>
                <p className="text-2xl font-semibold" data-testid="text-approved-count">{approved}</p>
              </div>
            </div>
          </GlassCard>
        </div>

        <Section>
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => <Skeleton key={i} className="h-20 w-full" />)}
            </div>
          ) : !assets || assets.length === 0 ? (
            <div className="text-center py-12" data-testid="text-no-assets">
              <Building2 className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground">No assets yet. Click "New Asset" to submit your first listing.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {assets.map(asset => {
                const statusInfo = STATUS_STYLES[asset.submissionStatus || "draft"] || STATUS_STYLES.draft;
                const country = asset.country as CountryCode;
                const countryName = COUNTRY_DETAILS[country]?.name || asset.country;
                const currencyInfo = CURRENCY_DETAILS[asset.baseCurrency as CurrencyCode];
                return (
                  <GlassCard key={asset.id}>
                    <div className="flex flex-wrap items-center justify-between gap-3 p-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="font-medium truncate" data-testid={`text-asset-name-${asset.id}`}>{asset.name}</p>
                          <Badge variant="secondary" className="text-xs">{asset.symbol}</Badge>
                          <Badge variant={statusInfo.variant} className="text-xs" data-testid={`badge-asset-status-${asset.id}`}>
                            {statusInfo.label}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-3 mt-1 flex-wrap">
                          <span className="text-xs text-muted-foreground" data-testid={`text-asset-country-${asset.id}`}>{countryName}</span>
                          <span className="text-xs text-muted-foreground" data-testid={`text-asset-currency-${asset.id}`}>{currencyInfo?.symbol || ""} {asset.baseCurrency}</span>
                          <span className="text-xs text-muted-foreground">{ASSET_TYPE_LABELS[asset.assetType as keyof typeof ASSET_TYPE_LABELS] || asset.assetType}</span>
                        </div>
                        {asset.adminReviewNotes && (
                          <p className="text-xs text-muted-foreground mt-1 italic" data-testid={`text-review-notes-${asset.id}`}>
                            Admin notes: {asset.adminReviewNotes}
                          </p>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <Button size="icon" variant="ghost" onClick={() => handleViewAsset(asset)} data-testid={`button-view-asset-${asset.id}`}>
                          <Eye className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </GlassCard>
                );
              })}
            </div>
          )}
        </Section>

        <CreateAssetDialog open={showCreateDialog} onOpenChange={setShowCreateDialog} />
        <AssetDetailDialog asset={selectedAsset} open={showDetailDialog} onOpenChange={setShowDetailDialog} />
      </div>
    </RoleLayout>
  );
}

function CreateAssetDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const { toast } = useToast();
  const [selectedCountry, setSelectedCountry] = useState<CountryCode | "">("");
  const [jurisdictionDocs, setJurisdictionDocs] = useState<JurisdictionDoc[]>([]);
  const [checklist, setChecklist] = useState<Record<string, boolean>>({});

  const form = useForm<IssuerSubmitAsset>({
    resolver: zodResolver(issuerSubmitAssetSchema),
    defaultValues: {
      name: "",
      symbol: "",
      assetType: "",
      description: "",
      totalSupply: "",
      pricePerToken: "",
      baseCurrency: "",
      country: "",
      location: "",
      propertyType: "",
      annualYield: "",
      legalStructure: "",
      regulatoryBody: "",
      tokenDecimals: 2,
      minInvestment: "",
      maxOwnershipPercent: "",
      jurisdictionChecklist: {},
    },
  });

  useEffect(() => {
    if (selectedCountry) {
      const docs = JURISDICTION_DOCS[selectedCountry] || [];
      setJurisdictionDocs(docs);
      const newChecklist: Record<string, boolean> = {};
      docs.forEach(d => { newChecklist[d.key] = checklist[d.key] || false; });
      setChecklist(newChecklist);
      form.setValue("country", selectedCountry);
      form.setValue("baseCurrency", COUNTRY_TO_CURRENCY[selectedCountry]);
    }
  }, [selectedCountry]);

  const createMutation = useMutation({
    mutationFn: async (data: IssuerSubmitAsset) => {
      const res = await apiRequest("POST", "/api/issuer/assets", data);
      return res.json();
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["/api/issuer/assets"] });
      onOpenChange(false);
      form.reset();
      setSelectedCountry("");
      setChecklist({});
      toast({
        title: result.missingRequired?.length > 0 ? "Asset Saved as Draft" : "Asset Submitted",
        description: result.message,
      });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create asset", variant: "destructive" });
    },
  });

  const onSubmit = (data: IssuerSubmitAsset) => {
    data.jurisdictionChecklist = checklist;
    createMutation.mutate(data);
  };

  const handleChecklistChange = (key: string, checked: boolean) => {
    setChecklist(prev => ({ ...prev, [key]: checked }));
  };

  const requiredDocs = jurisdictionDocs.filter(d => d.required);
  const optionalDocs = jurisdictionDocs.filter(d => !d.required);
  const completedRequired = requiredDocs.filter(d => checklist[d.key]).length;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Submit New Asset</DialogTitle>
          <DialogDescription>Enter asset details and complete the jurisdiction-specific document checklist</DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField control={form.control} name="name" render={({ field }) => (
                <FormItem>
                  <FormLabel>Asset Name</FormLabel>
                  <FormControl><Input {...field} placeholder="e.g. Prime Tower Fund" data-testid="input-asset-name" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="symbol" render={({ field }) => (
                <FormItem>
                  <FormLabel>Symbol</FormLabel>
                  <FormControl><Input {...field} placeholder="e.g. PTF" data-testid="input-asset-symbol" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>

            <FormField control={form.control} name="assetType" render={({ field }) => (
              <FormItem>
                <FormLabel>Asset Type</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl><SelectTrigger data-testid="select-asset-type"><SelectValue placeholder="Select type" /></SelectTrigger></FormControl>
                  <SelectContent>
                    {ASSET_TYPES.map(t => (
                      <SelectItem key={t} value={t}>{ASSET_TYPE_LABELS[t]}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )} />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField control={form.control} name="country" render={({ field }) => (
                <FormItem>
                  <FormLabel>Country / Jurisdiction</FormLabel>
                  <Select onValueChange={(v) => { field.onChange(v); setSelectedCountry(v as CountryCode); }} value={field.value}>
                    <FormControl><SelectTrigger data-testid="select-asset-country"><SelectValue placeholder="Select country" /></SelectTrigger></FormControl>
                    <SelectContent>
                      {SUPPORTED_COUNTRIES.map(c => (
                        <SelectItem key={c} value={c}>{COUNTRY_DETAILS[c].name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="baseCurrency" render={({ field }) => (
                <FormItem>
                  <FormLabel>Base Currency</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl><SelectTrigger data-testid="select-asset-currency"><SelectValue placeholder="Auto-set by country" /></SelectTrigger></FormControl>
                    <SelectContent>
                      {Object.entries(CURRENCY_DETAILS).map(([code, info]) => (
                        <SelectItem key={code} value={code}>{info.symbol} {info.name} ({code})</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
            </div>

            <FormField control={form.control} name="description" render={({ field }) => (
              <FormItem>
                <FormLabel>Description</FormLabel>
                <FormControl><Textarea {...field} placeholder="Describe the asset, its value proposition, and investment highlights" data-testid="input-asset-description" /></FormControl>
                <FormMessage />
              </FormItem>
            )} />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField control={form.control} name="totalSupply" render={({ field }) => (
                <FormItem>
                  <FormLabel>Total Token Supply</FormLabel>
                  <FormControl><Input {...field} placeholder="e.g. 10000" data-testid="input-total-supply" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="pricePerToken" render={({ field }) => (
                <FormItem>
                  <FormLabel>Price Per Token</FormLabel>
                  <FormControl><Input {...field} placeholder="e.g. 100.00" data-testid="input-price-per-token" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField control={form.control} name="tokenDecimals" render={({ field }) => (
                <FormItem>
                  <FormLabel>Token Decimal Places</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min="0"
                      max="8"
                      step="1"
                      value={field.value ?? 2}
                      onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                      data-testid="input-token-decimals"
                    />
                  </FormControl>
                  <p className="text-xs text-muted-foreground">
                    Controls fractional token precision. 2 = buy 0.01 tokens minimum. 0 = whole tokens only.
                  </p>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="location" render={({ field }) => (
                <FormItem>
                  <FormLabel>Location (optional)</FormLabel>
                  <FormControl><Input {...field} placeholder="e.g. London, Canary Wharf" data-testid="input-location" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="annualYield" render={({ field }) => (
                <FormItem>
                  <FormLabel>Expected Annual Yield % (optional)</FormLabel>
                  <FormControl><Input {...field} placeholder="e.g. 7.5" data-testid="input-annual-yield" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <FormField control={form.control} name="legalStructure" render={({ field }) => (
                <FormItem>
                  <FormLabel>Legal Structure (optional)</FormLabel>
                  <FormControl><Input {...field} placeholder="e.g. SPV, LLC, Trust" data-testid="input-legal-structure" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="minInvestment" render={({ field }) => (
                <FormItem>
                  <FormLabel>Min Investment (optional)</FormLabel>
                  <FormControl><Input {...field} placeholder="e.g. 500" data-testid="input-min-investment" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="maxOwnershipPercent" render={({ field }) => (
                <FormItem>
                  <FormLabel>Max Ownership % (optional)</FormLabel>
                  <FormControl><Input {...field} type="number" step="0.01" min="0.01" max="100" placeholder="e.g. 10" data-testid="input-max-ownership" /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>

            {selectedCountry && jurisdictionDocs.length > 0 && (
              <div className="space-y-3 border rounded-md p-4" data-testid="section-jurisdiction-checklist">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-muted-foreground" />
                    <h4 className="font-medium text-sm">Jurisdiction Documents - {COUNTRY_DETAILS[selectedCountry].name}</h4>
                  </div>
                  <Badge variant="secondary" className="text-xs" data-testid="badge-checklist-progress">
                    {completedRequired}/{requiredDocs.length} required
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground">
                  Check each document you have prepared. All required documents must be confirmed before submission.
                </p>

                {requiredDocs.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Required</p>
                    {requiredDocs.map(doc => (
                      <label
                        key={doc.key}
                        className="flex items-start gap-3 p-2 rounded-md hover-elevate cursor-pointer"
                        data-testid={`checkbox-doc-${doc.key}`}
                      >
                        <Checkbox
                          checked={checklist[doc.key] || false}
                          onCheckedChange={(v) => handleChecklistChange(doc.key, !!v)}
                          className="mt-0.5"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium">{doc.label}</p>
                          <p className="text-xs text-muted-foreground">{doc.description}</p>
                        </div>
                        <AlertCircle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
                      </label>
                    ))}
                  </div>
                )}

                {optionalDocs.length > 0 && (
                  <div className="space-y-2 pt-2 border-t">
                    <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Optional</p>
                    {optionalDocs.map(doc => (
                      <label
                        key={doc.key}
                        className="flex items-start gap-3 p-2 rounded-md hover-elevate cursor-pointer"
                        data-testid={`checkbox-doc-${doc.key}`}
                      >
                        <Checkbox
                          checked={checklist[doc.key] || false}
                          onCheckedChange={(v) => handleChecklistChange(doc.key, !!v)}
                          className="mt-0.5"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium">{doc.label}</p>
                          <p className="text-xs text-muted-foreground">{doc.description}</p>
                        </div>
                      </label>
                    ))}
                  </div>
                )}
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)} data-testid="button-cancel-asset">
                Cancel
              </Button>
              <Button type="submit" disabled={createMutation.isPending} data-testid="button-submit-asset">
                {createMutation.isPending ? "Submitting..." : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Submit Asset
                  </>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

function AssetDetailDialog({ asset, open, onOpenChange }: { asset: Asset | null; open: boolean; onOpenChange: (v: boolean) => void }) {
  if (!asset) return null;
  const country = asset.country as CountryCode;
  const countryName = COUNTRY_DETAILS[country]?.name || asset.country;
  const jurisdictionDocs = JURISDICTION_DOCS[country] || [];
  const checklist = (asset.jurisdictionChecklist || {}) as Record<string, boolean>;
  const statusInfo = STATUS_STYLES[asset.submissionStatus || "draft"] || STATUS_STYLES.draft;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{asset.name}</DialogTitle>
          <DialogDescription>Asset submission details and jurisdiction checklist</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <p className="text-muted-foreground">Symbol</p>
              <p className="font-medium">{asset.symbol}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Status</p>
              <Badge variant={statusInfo.variant} className="text-xs">{statusInfo.label}</Badge>
            </div>
            <div>
              <p className="text-muted-foreground">Country</p>
              <p className="font-medium" data-testid="text-detail-country">{countryName}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Currency</p>
              <p className="font-medium" data-testid="text-detail-currency">{asset.baseCurrency}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Supply</p>
              <p className="font-medium">{asset.totalSupply}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Price</p>
              <p className="font-medium">{asset.pricePerToken}</p>
            </div>
          </div>

          {asset.description && (
            <div>
              <p className="text-sm text-muted-foreground">Description</p>
              <p className="text-sm">{asset.description}</p>
            </div>
          )}

          {asset.adminReviewNotes && (
            <div className="border rounded-md p-3">
              <p className="text-sm text-muted-foreground">Admin Review Notes</p>
              <p className="text-sm">{asset.adminReviewNotes}</p>
            </div>
          )}

          {jurisdictionDocs.length > 0 && (
            <div className="space-y-2" data-testid="section-detail-checklist">
              <h4 className="text-sm font-medium">Jurisdiction Documents - {countryName}</h4>
              {jurisdictionDocs.map(doc => (
                <div key={doc.key} className="flex items-center gap-2 text-sm">
                  {checklist[doc.key] ? (
                    <CheckCircle2 className="w-4 h-4 text-green-600 shrink-0" />
                  ) : (
                    <AlertCircle className={`w-4 h-4 shrink-0 ${doc.required ? "text-destructive" : "text-muted-foreground"}`} />
                  )}
                  <span className={checklist[doc.key] ? "" : "text-muted-foreground"}>
                    {doc.label}
                    {doc.required && !checklist[doc.key] && <span className="text-destructive ml-1 text-xs">(required)</span>}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
