import { useQuery } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { StatTile } from "@/components/stat-tile";
import { Section } from "@/components/section";
import { DataTable, type Column } from "@/components/data-table";
import { GlassButton } from "@/components/glass-button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Banknote, Calendar, Users, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
interface Distribution {
  id: string;
  assetId: string;
  amount: string;
  currency: string;
  distributionDate: string;
  status: string;
  perTokenAmount: string | null;
  recipientCount: number | null;
}

interface Asset {
  id: string;
  name: string;
}

interface DistRow {
  date: string;
  asset: string;
  amount: string;
  recipients: string;
  status: string;
}

const columns: Column<DistRow>[] = [
  { header: "Date", accessor: "date" },
  { header: "Asset", accessor: "asset" },
  { header: "Total Amount", accessor: "amount" },
  { header: "Recipients", accessor: "recipients" },
  { header: "Status", accessor: (row) => <Badge variant={row.status === "completed" ? "default" : "secondary"} className="text-xs">{row.status}</Badge> },
];

export default function IssuerDistributions() {
  const { data: distributions = [], isLoading: distLoading } = useQuery<Distribution[]>({
    queryKey: ["/api/distributions"],
  });

  const { data: assets = [], isLoading: assetsLoading } = useQuery<Asset[]>({
    queryKey: ["/api/issuer/assets"],
  });

  const isLoading = distLoading || assetsLoading;

  const assetMap = new Map(assets.map(a => [a.id, a.name]));
  const issuerAssetIds = new Set(assets.map(a => a.id));
  const issuerDistributions = distributions.filter(d => issuerAssetIds.has(d.assetId));

  const tableData: DistRow[] = issuerDistributions.map(d => ({
    date: d.distributionDate,
    asset: assetMap.get(d.assetId) || d.assetId,
    amount: `${d.currency} ${Number(d.amount).toLocaleString()}`,
    recipients: String(d.recipientCount || 0),
    status: d.status,
  }));

  const totalDistributed = issuerDistributions.reduce((s, d) => s + Number(d.amount), 0);
  const totalRecipients = issuerDistributions.reduce((s, d) => s + (d.recipientCount || 0), 0);
  const scheduled = issuerDistributions.filter(d => d.status === "scheduled");
  const nextScheduled = scheduled.length > 0
    ? scheduled.sort((a, b) => new Date(a.distributionDate).getTime() - new Date(b.distributionDate).getTime())[0].distributionDate
    : "None";

  return (
    <RoleLayout role="issuer">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/issuer/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Distributions"
          description="Schedule and manage investor payouts"
          action={
            <GlassButton variant="primary" data-testid="button-create-distribution">
              <Plus className="w-4 h-4" />
              New Distribution
            </GlassButton>
          }
        />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {isLoading ? (
            <>{[1, 2, 3].map(i => <Skeleton key={i} className="h-20 w-full" />)}</>
          ) : (
            <>
              <StatTile label="Total Distributed" value={`$${totalDistributed.toLocaleString()}`} trend="neutral" icon={<Banknote className="w-5 h-5" />} />
              <StatTile label="Next Scheduled" value={nextScheduled} trend="neutral" icon={<Calendar className="w-5 h-5" />} />
              <StatTile label="Total Recipients" value={String(totalRecipients)} trend="neutral" icon={<Users className="w-5 h-5" />} />
            </>
          )}
        </div>

        <Section title="Distribution History">
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => <Skeleton key={i} className="h-12 w-full" />)}
            </div>
          ) : tableData.length === 0 ? (
            <div className="text-center py-12">
              <Banknote className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground" data-testid="text-no-distributions">No distributions yet. Create your first payout to get started.</p>
            </div>
          ) : (
            <DataTable columns={columns} data={tableData} />
          )}
        </Section>
      </div>
    </RoleLayout>
  );
}
