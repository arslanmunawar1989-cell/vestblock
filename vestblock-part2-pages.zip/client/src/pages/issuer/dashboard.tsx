import { useQuery } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { GradientHeader } from "@/components/gradient-header";
import { StatTile } from "@/components/stat-tile";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Blocks, DollarSign, Users, TrendingUp } from "lucide-react";

interface IssuerAsset {
  id: string;
  name: string;
  symbol: string;
  status: string;
  totalSupply: string;
  pricePerToken: string;
  baseCurrency: string;
  annualYield: string;
}

export default function IssuerDashboard() {
  const { data: assets = [], isLoading } = useQuery<IssuerAsset[]>({
    queryKey: ["/api/issuer/assets"],
  });

  const activeAssets = assets.filter(a => a.status === "active");
  const totalValue = assets.reduce((s, a) => s + Number(a.totalSupply) * Number(a.pricePerToken), 0);
  const avgYield = assets.length > 0 ? assets.reduce((s, a) => s + Number(a.annualYield || 0), 0) / assets.length : 0;

  return (
    <RoleLayout role="issuer">
      <div className="space-y-6">
        <GradientHeader>
          <div>
            <p className="text-white/80 text-sm mb-1">Issuer Dashboard</p>
            <h1 className="text-2xl font-bold text-white">Asset Management Portal</h1>
          </div>
        </GradientHeader>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {isLoading ? (
            <>{[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-20 w-full" />)}</>
          ) : (
            <>
              <StatTile label="Active Assets" value={String(activeAssets.length)} trend="neutral" icon={<Blocks className="w-5 h-5" />} />
              <StatTile label="Total Asset Value" value={`$${(totalValue / 1000000).toFixed(1)}M`} trend="neutral" icon={<DollarSign className="w-5 h-5" />} />
              <StatTile label="Total Tokens" value={assets.reduce((s, a) => s + Number(a.totalSupply), 0).toLocaleString()} trend="neutral" icon={<Users className="w-5 h-5" />} />
              <StatTile label="Avg. Yield" value={`${avgYield.toFixed(1)}%`} trend="neutral" icon={<TrendingUp className="w-5 h-5" />} />
            </>
          )}
        </div>

        <Section title="Your Assets">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-24 w-full" />)}
            </div>
          ) : assets.length === 0 ? (
            <div className="text-center py-12">
              <Blocks className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground" data-testid="text-no-assets">No assets yet. Create your first offering to get started.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {assets.map((asset, i) => (
                <GlassCard key={asset.id}>
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-md gradient-hero flex items-center justify-center flex-shrink-0">
                        <span className="text-white font-bold">{asset.name[0]}</span>
                      </div>
                      <div>
                        <p className="font-semibold text-sm" data-testid={`issuer-asset-${i}`}>{asset.name}</p>
                        <p className="text-xs text-muted-foreground">{asset.symbol} &middot; {Number(asset.totalSupply).toLocaleString()} tokens</p>
                      </div>
                    </div>
                    <Badge variant={asset.status === "active" ? "default" : "secondary"} className="text-xs">{asset.status}</Badge>
                  </div>
                  <div className="flex items-center justify-between gap-2 text-sm text-muted-foreground">
                    <span>Token Price: {asset.baseCurrency} {Number(asset.pricePerToken).toLocaleString()}</span>
                    <span>Yield: {asset.annualYield}%</span>
                  </div>
                </GlassCard>
              ))}
            </div>
          )}
        </Section>
      </div>
    </RoleLayout>
  );
}
