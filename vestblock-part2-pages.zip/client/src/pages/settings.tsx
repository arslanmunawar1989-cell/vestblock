import { useState, useEffect } from "react";
import { useAuth } from "@/lib/auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { PageTitle } from "@/components/page-title";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  User,
  Bell,
  Save,
  Loader2,
  CheckCircle2,
  Globe,
  Plus,
  Trash2,
  Star,
  MapPin,
  ArrowRightLeft,
  FileText,
  ShieldCheck,
  ScrollText,
  AlertTriangle,
} from "lucide-react";
import { SUPPORTED_COUNTRIES, COUNTRY_DETAILS } from "@/lib/countries";
import type { CountryCode } from "@/lib/countries";
import type { UserCountryProfile } from "@shared/schema";
import { residencyStatusEnum } from "@shared/schema";
import { usePushNotifications } from "@/hooks/use-push-notifications";

interface PendingLegalDoc {
  id: string;
  type: string;
  title: string;
  content: string;
  version: number;
  country: string | null;
}

const LEGAL_DOC_ICONS: Record<string, typeof FileText> = {
  terms_of_service: ScrollText,
  privacy_policy: ShieldCheck,
  risk_disclosure: AlertTriangle,
};

const LEGAL_DOC_TYPE_LABELS: Record<string, string> = {
  terms_of_service: "Terms of Service",
  privacy_policy: "Privacy Policy",
  risk_disclosure: "Risk Disclosure",
};

const TIMEZONES = [
  "UTC",
  "America/New_York",
  "America/Chicago",
  "America/Denver",
  "America/Los_Angeles",
  "America/Anchorage",
  "Pacific/Honolulu",
  "Europe/London",
  "Europe/Paris",
  "Europe/Berlin",
  "Europe/Moscow",
  "Asia/Dubai",
  "Asia/Kolkata",
  "Asia/Shanghai",
  "Asia/Tokyo",
  "Asia/Singapore",
  "Australia/Sydney",
  "Pacific/Auckland",
];

function BrowserPushSection() {
  const { isSupported, isSubscribed, permission, vapidConfigured, subscribe, unsubscribe } = usePushNotifications();

  if (!isSupported) {
    return (
      <div className="rounded-md border p-3 bg-muted/30">
        <p className="text-sm text-muted-foreground">
          Browser push notifications are not supported on this device.
          You will receive notifications via email instead.
        </p>
      </div>
    );
  }

  if (!vapidConfigured) {
    return (
      <div className="rounded-md border p-3 bg-muted/30">
        <p className="text-sm text-muted-foreground">
          Push notifications are not yet configured on this server.
          You will receive notifications via email instead.
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-md border p-3 space-y-2">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <p className="text-sm font-medium">Browser Push</p>
          <p className="text-xs text-muted-foreground">
            {isSubscribed
              ? "This browser is receiving push notifications"
              : permission === "denied"
              ? "Notifications blocked. Please allow in browser settings."
              : "Enable push notifications on this device"}
          </p>
        </div>
        {isSubscribed ? (
          <Button
            size="sm"
            variant="outline"
            onClick={unsubscribe}
            data-testid="button-push-unsubscribe"
          >
            Disable
          </Button>
        ) : (
          <Button
            size="sm"
            onClick={subscribe}
            disabled={permission === "denied"}
            data-testid="button-push-subscribe"
          >
            Enable
          </Button>
        )}
      </div>
    </div>
  );
}

const NATIONALITIES = [
  "United States",
  "United Kingdom",
  "Canada",
  "Australia",
  "Germany",
  "France",
  "Japan",
  "Singapore",
  "India",
  "Brazil",
  "South Korea",
  "Switzerland",
  "Netherlands",
  "Sweden",
  "Norway",
  "Denmark",
  "Ireland",
  "UAE",
  "Pakistan",
  "Qatar",
  "Hong Kong",
  "New Zealand",
  "Other",
];

const RESIDENCY_LABELS: Record<string, string> = {
  citizen: "Citizen",
  permanent_resident: "Permanent Resident",
  temporary_resident: "Temporary Resident",
  non_resident: "Non-Resident",
  visa_holder: "Visa Holder",
};

export default function Settings() {
  const { user } = useAuth();
  const { toast } = useToast();

  const [fullName, setFullName] = useState(user?.fullName || "");
  const [phone, setPhone] = useState(user?.phone || "");
  const [nationality, setNationality] = useState(user?.nationality || "");
  const [address, setAddress] = useState(user?.address || "");
  const [timezone, setTimezone] = useState(user?.timezone || "UTC");

  const defaultNotifs = {
    email: true,
    sms: false,
    push: true,
    marketing: false,
    security: true,
    transactions: true,
    distributions: true,
    autoConvertDistributions: false,
  };
  const currentNotifs = user?.notificationPreferences || defaultNotifs;
  const [notifs, setNotifs] = useState(currentNotifs);

  const { data: countryProfiles, isLoading: profilesLoading } = useQuery<UserCountryProfile[]>({
    queryKey: ["/api/country-profiles"],
  });

  const { data: distPrefData } = useQuery<{ autoConvertDistributions: boolean }>({
    queryKey: ["/api/distributions/preference"],
  });

  const { data: policyData, isLoading: policyLoading } = useQuery<{
    investorType: string;
    country: string | null;
    investorPolicy: {
      label: string;
      description: string;
      minInvestAmount: number;
      maxInvestAmount: number | null;
      maxHoldings: number | null;
      canTrade: boolean;
      fxAllowed: boolean;
      cryptoAllowed: boolean;
      allowedRails: string[];
      coolOffPeriodDays: number;
    } | null;
    checks: {
      canInvest: { allowed: boolean; reason: string | null; code: string };
      canTrade: { allowed: boolean; reason: string | null; code: string };
    };
  }>({
    queryKey: ["/api/policy/me"],
  });

  const [investorType, setInvestorType] = useState((user as any)?.investorType || "retail");
  const [countryOfResidence, setCountryOfResidence] = useState((user as any)?.countryOfResidence || "");
  const [taxResidencyField, setTaxResidencyField] = useState((user as any)?.taxResidency || "");

  const investorTypeMutation = useMutation({
    mutationFn: async (data: { investorType?: string; countryOfResidence?: string; taxResidency?: string }) => {
      const res = await apiRequest("PATCH", "/api/policy/investor-type", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/policy/me"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({
        title: "Investor profile updated",
        description: "Your investor classification has been saved.",
      });
    },
    onError: () => {
      toast({
        title: "Update failed",
        description: "Could not update investor profile.",
        variant: "destructive",
      });
    },
  });

  const distPrefMutation = useMutation({
    mutationFn: async (autoConvert: boolean) => {
      const res = await apiRequest("PATCH", "/api/distributions/preference", { autoConvertDistributions: autoConvert });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/distributions/preference"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({ title: "Preference updated", description: "Your distribution auto-convert preference has been saved." });
    },
    onError: () => {
      toast({ title: "Update failed", description: "Could not save preference.", variant: "destructive" });
    },
  });

  const [showAddCountry, setShowAddCountry] = useState(false);
  const [editingCountry, setEditingCountry] = useState<CountryCode | null>(null);
  const [countryForm, setCountryForm] = useState({
    countryCode: "" as string,
    isPrimary: false,
    residencyStatus: "" as string,
    taxResidency: false,
    addressLine1: "",
    addressLine2: "",
    city: "",
    stateProvince: "",
    postalCode: "",
    phoneCountryCode: "",
    phoneNumber: "",
  });

  const profileMutation = useMutation({
    mutationFn: async (data: {
      fullName?: string;
      phone?: string | null;
      nationality?: string | null;
      address?: string | null;
      timezone?: string | null;
    }) => {
      const res = await apiRequest("PATCH", "/api/profile", data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(["/api/auth/me"], data.user);
      toast({
        title: "Profile updated",
        description: "Your profile information has been saved.",
      });
    },
    onError: () => {
      toast({
        title: "Update failed",
        description: "Could not save profile changes. Please try again.",
        variant: "destructive",
      });
    },
  });

  const notifMutation = useMutation({
    mutationFn: async (prefs: typeof notifs) => {
      const res = await apiRequest("PATCH", "/api/profile/notifications", prefs);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(["/api/auth/me"], data.user);
      toast({
        title: "Preferences updated",
        description: "Your notification preferences have been saved.",
      });
    },
    onError: () => {
      toast({
        title: "Update failed",
        description: "Could not save notification preferences. Please try again.",
        variant: "destructive",
      });
    },
  });

  const [showLegalDialog, setShowLegalDialog] = useState(false);
  const [pendingLegalDocs, setPendingLegalDocs] = useState<PendingLegalDoc[]>([]);
  const [acceptedDocIds, setAcceptedDocIds] = useState<Set<string>>(new Set());
  const [pendingCountryCode, setPendingCountryCode] = useState<string>("");
  const [expandedDoc, setExpandedDoc] = useState<string | null>(null);

  const countryMutation = useMutation({
    mutationFn: async (data: typeof countryForm) => {
      const res = await apiRequest("POST", "/api/country-profiles", {
        ...data,
        residencyStatus: data.residencyStatus || null,
        addressLine1: data.addressLine1 || null,
        addressLine2: data.addressLine2 || null,
        city: data.city || null,
        stateProvince: data.stateProvince || null,
        postalCode: data.postalCode || null,
        phoneCountryCode: data.phoneCountryCode || null,
        phoneNumber: data.phoneNumber || null,
      });
      return res.json();
    },
    onSuccess: (data) => {
      if (data.requiresLegalAcceptance && data.pendingLegalDocs?.length > 0) {
        setPendingLegalDocs(data.pendingLegalDocs);
        setPendingCountryCode(countryForm.countryCode);
        setAcceptedDocIds(new Set());
        setExpandedDoc(null);
        setShowLegalDialog(true);
        queryClient.invalidateQueries({ queryKey: ["/api/country-profiles"] });
      } else {
        queryClient.invalidateQueries({ queryKey: ["/api/country-profiles"] });
        queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
        setShowAddCountry(false);
        setEditingCountry(null);
        resetCountryForm();
        toast({
          title: "Country profile saved",
          description: "Your country profile has been updated.",
        });
      }
    },
    onError: () => {
      toast({
        title: "Save failed",
        description: "Could not save country profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const confirmPrimaryMutation = useMutation({
    mutationFn: async ({ countryCode, acceptedDocumentIds }: { countryCode: string; acceptedDocumentIds: string[] }) => {
      const res = await apiRequest("POST", "/api/country-profiles/confirm-primary", {
        countryCode,
        acceptedDocumentIds,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/country-profiles"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      setShowLegalDialog(false);
      setShowAddCountry(false);
      setEditingCountry(null);
      resetCountryForm();
      setPendingLegalDocs([]);
      setAcceptedDocIds(new Set());
      toast({
        title: "Country updated",
        description: "Your primary country has been changed and legal documents accepted.",
      });
    },
    onError: () => {
      toast({
        title: "Confirmation failed",
        description: "Could not confirm primary country. Please try again.",
        variant: "destructive",
      });
    },
  });

  const toggleDocAccepted = (docId: string) => {
    setAcceptedDocIds(prev => {
      const next = new Set(prev);
      if (next.has(docId)) next.delete(docId);
      else next.add(docId);
      return next;
    });
  };

  const allDocsAccepted = pendingLegalDocs.length > 0 && pendingLegalDocs.every(d => acceptedDocIds.has(d.id));

  const deleteMutation = useMutation({
    mutationFn: async (countryCode: string) => {
      const res = await apiRequest("DELETE", `/api/country-profiles/${countryCode}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/country-profiles"] });
      toast({
        title: "Country profile removed",
        description: "The country profile has been deleted.",
      });
    },
    onError: () => {
      toast({
        title: "Delete failed",
        description: "Could not remove country profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const resetCountryForm = () => {
    setCountryForm({
      countryCode: "",
      isPrimary: false,
      residencyStatus: "",
      taxResidency: false,
      addressLine1: "",
      addressLine2: "",
      city: "",
      stateProvince: "",
      postalCode: "",
      phoneCountryCode: "",
      phoneNumber: "",
    });
  };

  const startEditCountry = (profile: UserCountryProfile) => {
    setEditingCountry(profile.countryCode as CountryCode);
    setCountryForm({
      countryCode: profile.countryCode,
      isPrimary: profile.isPrimary,
      residencyStatus: profile.residencyStatus || "",
      taxResidency: profile.taxResidency,
      addressLine1: profile.addressLine1 || "",
      addressLine2: profile.addressLine2 || "",
      city: profile.city || "",
      stateProvince: profile.stateProvince || "",
      postalCode: profile.postalCode || "",
      phoneCountryCode: profile.phoneCountryCode || "",
      phoneNumber: profile.phoneNumber || "",
    });
    setShowAddCountry(true);
  };

  const startAddCountry = () => {
    setEditingCountry(null);
    resetCountryForm();
    const hasPrimary = countryProfiles?.some((p) => p.isPrimary);
    if (!hasPrimary) {
      setCountryForm((prev) => ({ ...prev, isPrimary: true }));
    }
    setShowAddCountry(true);
  };

  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    profileMutation.mutate({
      fullName,
      phone: phone || null,
      nationality: nationality || null,
      address: address || null,
      timezone: timezone || null,
    });
  };

  const handleNotifSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    notifMutation.mutate(notifs);
  };

  const handleCountrySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!countryForm.countryCode) return;
    countryMutation.mutate(countryForm);
  };

  const toggleNotif = (key: keyof typeof notifs) => {
    setNotifs((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  if (!user) return null;

  const usedCountryCodes = countryProfiles?.map((p) => p.countryCode) || [];
  const availableCountries = SUPPORTED_COUNTRIES.filter(
    (c) => !usedCountryCodes.includes(c) || c === editingCountry
  );

  return (
    <div>
      <PageTitle
        title="Settings"
        description="Manage your profile information, country residency, and notification preferences"
      />

      <Tabs defaultValue="profile" className="mt-6">
        <TabsList data-testid="tabs-settings" className="flex-wrap">
          <TabsTrigger value="profile" data-testid="tab-profile">
            <User className="w-4 h-4 mr-1.5" />
            Profile
          </TabsTrigger>
          <TabsTrigger value="countries" data-testid="tab-countries">
            <Globe className="w-4 h-4 mr-1.5" />
            Countries
          </TabsTrigger>
          <TabsTrigger value="notifications" data-testid="tab-notifications">
            <Bell className="w-4 h-4 mr-1.5" />
            Notifications
          </TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="mt-4">
          <Card className="p-5">
            <form onSubmit={handleProfileSubmit} className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="fullName">Full Name</Label>
                  <Input
                    id="fullName"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    data-testid="input-settings-fullname"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    value={user.email}
                    disabled
                    className="opacity-60"
                    data-testid="input-settings-email"
                  />
                  <p className="text-xs text-muted-foreground">Email cannot be changed</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+1 (555) 000-0000"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    data-testid="input-settings-phone"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="nationality">Nationality</Label>
                  <Select
                    value={nationality}
                    onValueChange={setNationality}
                  >
                    <SelectTrigger id="nationality" data-testid="select-settings-nationality">
                      <SelectValue placeholder="Select nationality" />
                    </SelectTrigger>
                    <SelectContent>
                      {NATIONALITIES.map((n) => (
                        <SelectItem key={n} value={n}>
                          {n}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="address">Address</Label>
                  <Input
                    id="address"
                    placeholder="Street address, city, state, ZIP"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    data-testid="input-settings-address"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="timezone">Timezone</Label>
                  <Select
                    value={timezone}
                    onValueChange={setTimezone}
                  >
                    <SelectTrigger id="timezone" data-testid="select-settings-timezone">
                      <SelectValue placeholder="Select timezone" />
                    </SelectTrigger>
                    <SelectContent>
                      {TIMEZONES.map((tz) => (
                        <SelectItem key={tz} value={tz}>
                          {tz.replace(/_/g, " ")}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Separator />

              <div className="flex justify-end">
                <Button
                  type="submit"
                  disabled={profileMutation.isPending}
                  data-testid="button-save-profile"
                >
                  {profileMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4 mr-1.5" />
                  )}
                  {profileMutation.isPending ? "Saving..." : "Save Profile"}
                </Button>
              </div>
            </form>
          </Card>

          <Card className="p-5 mt-4">
            <h3 className="text-base font-semibold mb-1">Investor Classification</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Your investor type determines what you can invest in, deposit limits, and trading eligibility
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="investorType">Investor Type</Label>
                <Select value={investorType} onValueChange={setInvestorType}>
                  <SelectTrigger id="investorType" data-testid="select-investor-type">
                    <SelectValue placeholder="Select investor type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="retail">Retail</SelectItem>
                    <SelectItem value="sophisticated">Sophisticated</SelectItem>
                    <SelectItem value="accredited">Accredited</SelectItem>
                    <SelectItem value="institutional">Institutional</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="countryOfResidence">Country of Residence</Label>
                <Select value={countryOfResidence} onValueChange={setCountryOfResidence}>
                  <SelectTrigger id="countryOfResidence" data-testid="select-country-of-residence">
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    {SUPPORTED_COUNTRIES.map((c) => (
                      <SelectItem key={c} value={c}>
                        {COUNTRY_DETAILS[c]?.name || c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="taxResidencyField">Tax Residency</Label>
                <Select value={taxResidencyField} onValueChange={setTaxResidencyField}>
                  <SelectTrigger id="taxResidencyField" data-testid="select-tax-residency">
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    {SUPPORTED_COUNTRIES.map((c) => (
                      <SelectItem key={c} value={c}>
                        {COUNTRY_DETAILS[c]?.name || c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex justify-end mt-4">
              <Button
                onClick={() => investorTypeMutation.mutate({
                  investorType,
                  countryOfResidence: countryOfResidence || undefined,
                  taxResidency: taxResidencyField || undefined,
                })}
                disabled={investorTypeMutation.isPending}
                data-testid="button-save-investor-type"
              >
                {investorTypeMutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
                ) : (
                  <Save className="w-4 h-4 mr-1.5" />
                )}
                Save Classification
              </Button>
            </div>

            {policyData?.investorPolicy && (
              <div className="mt-4 pt-4 border-t">
                <h4 className="text-sm font-medium mb-3">Your Policy Summary</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Classification</p>
                    <Badge data-testid="badge-investor-type" variant="secondary">
                      {policyData.investorPolicy.label}
                    </Badge>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Max Investment</p>
                    <p className="text-sm font-medium" data-testid="text-max-invest">
                      {policyData.investorPolicy.maxInvestAmount
                        ? policyData.investorPolicy.maxInvestAmount.toLocaleString()
                        : "Unlimited"}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Trading</p>
                    <Badge
                      variant={policyData.investorPolicy.canTrade ? "default" : "secondary"}
                      data-testid="badge-can-trade"
                    >
                      {policyData.investorPolicy.canTrade ? "Enabled" : "Not Available"}
                    </Badge>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Crypto</p>
                    <Badge
                      variant={policyData.investorPolicy.cryptoAllowed ? "default" : "secondary"}
                      data-testid="badge-crypto"
                    >
                      {policyData.investorPolicy.cryptoAllowed ? "Allowed" : "Not Available"}
                    </Badge>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Cooling Off</p>
                    <p className="text-sm font-medium" data-testid="text-cooloff">
                      {policyData.investorPolicy.coolOffPeriodDays} days
                    </p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Payment Rails</p>
                    <p className="text-sm font-medium" data-testid="text-rails">
                      {policyData.investorPolicy.allowedRails.join(", ")}
                    </p>
                  </div>
                  {!policyData.checks.canInvest.allowed && (
                    <div className="col-span-2 space-y-1">
                      <p className="text-xs text-muted-foreground">Invest Status</p>
                      <p className="text-sm text-destructive" data-testid="text-invest-blocked">
                        {policyData.checks.canInvest.reason}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </Card>
        </TabsContent>

        <TabsContent value="countries" className="mt-4">
          <div className="space-y-4">
            <Card className="p-5">
              <div className="flex items-center justify-between gap-4 flex-wrap mb-4">
                <div>
                  <h3 className="text-base font-semibold">Country Profiles</h3>
                  <p className="text-sm text-muted-foreground">
                    Set your primary country and add secondary countries for residency, tax, and address information
                  </p>
                </div>
                <Button
                  onClick={startAddCountry}
                  disabled={availableCountries.length === 0 && !showAddCountry}
                  data-testid="button-add-country"
                >
                  <Plus className="w-4 h-4 mr-1.5" />
                  Add Country
                </Button>
              </div>

              {profilesLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
                </div>
              ) : countryProfiles && countryProfiles.length > 0 ? (
                <div className="space-y-3">
                  {countryProfiles.map((profile) => {
                    const country = COUNTRY_DETAILS[profile.countryCode as CountryCode];
                    return (
                      <Card
                        key={profile.id}
                        className="p-4"
                        data-testid={`card-country-${profile.countryCode}`}
                      >
                        <div className="flex items-start justify-between gap-4 flex-wrap">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-medium" data-testid={`text-country-name-${profile.countryCode}`}>
                                {country?.name || profile.countryCode}
                              </span>
                              <Badge variant="outline" className="text-xs">
                                {profile.countryCode}
                              </Badge>
                              {profile.isPrimary && (
                                <Badge variant="default" className="text-xs" data-testid={`badge-primary-${profile.countryCode}`}>
                                  <Star className="w-3 h-3 mr-1" />
                                  Primary
                                </Badge>
                              )}
                              {profile.taxResidency && (
                                <Badge variant="secondary" className="text-xs">
                                  Tax Resident
                                </Badge>
                              )}
                            </div>
                            <div className="mt-1 text-sm text-muted-foreground space-y-0.5">
                              {profile.residencyStatus && (
                                <p>{RESIDENCY_LABELS[profile.residencyStatus] || profile.residencyStatus}</p>
                              )}
                              {(profile.addressLine1 || profile.city) && (
                                <p className="flex items-center gap-1">
                                  <MapPin className="w-3 h-3 shrink-0" />
                                  {[profile.addressLine1, profile.city, profile.stateProvince, profile.postalCode]
                                    .filter(Boolean)
                                    .join(", ")}
                                </p>
                              )}
                              {profile.phoneNumber && (
                                <p>
                                  {profile.phoneCountryCode} {profile.phoneNumber}
                                </p>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => startEditCountry(profile)}
                              data-testid={`button-edit-country-${profile.countryCode}`}
                            >
                              <Save className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => deleteMutation.mutate(profile.countryCode)}
                              disabled={deleteMutation.isPending}
                              data-testid={`button-delete-country-${profile.countryCode}`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              ) : !showAddCountry ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Globe className="w-10 h-10 mx-auto mb-2 opacity-40" />
                  <p className="text-sm">No country profiles yet</p>
                  <p className="text-xs mt-1">Add your primary country to get started</p>
                </div>
              ) : null}
            </Card>

            {showAddCountry && (
              <Card className="p-5" data-testid="form-country-profile">
                <h3 className="text-base font-semibold mb-4">
                  {editingCountry ? `Edit ${COUNTRY_DETAILS[editingCountry]?.name || editingCountry}` : "Add Country Profile"}
                </h3>
                <form onSubmit={handleCountrySubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="countryCode">Country</Label>
                      <Select
                        value={countryForm.countryCode}
                        onValueChange={(v) => {
                          setCountryForm((prev) => ({
                            ...prev,
                            countryCode: v,
                            phoneCountryCode: COUNTRY_DETAILS[v as CountryCode]?.phonePrefix || "",
                          }));
                        }}
                        disabled={!!editingCountry}
                      >
                        <SelectTrigger id="countryCode" data-testid="select-country-code">
                          <SelectValue placeholder="Select country" />
                        </SelectTrigger>
                        <SelectContent>
                          {availableCountries.map((code) => (
                            <SelectItem key={code} value={code}>
                              {COUNTRY_DETAILS[code].name} ({code})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="residencyStatus">Residency Status</Label>
                      <Select
                        value={countryForm.residencyStatus}
                        onValueChange={(v) => setCountryForm((prev) => ({ ...prev, residencyStatus: v }))}
                      >
                        <SelectTrigger id="residencyStatus" data-testid="select-residency-status">
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent>
                          {residencyStatusEnum.map((s) => (
                            <SelectItem key={s} value={s}>
                              {RESIDENCY_LABELS[s]}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="addressLine1">Address Line 1</Label>
                      <Input
                        id="addressLine1"
                        placeholder="Street address"
                        value={countryForm.addressLine1}
                        onChange={(e) => setCountryForm((prev) => ({ ...prev, addressLine1: e.target.value }))}
                        data-testid="input-address-line1"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="addressLine2">Address Line 2</Label>
                      <Input
                        id="addressLine2"
                        placeholder="Apt, suite, floor (optional)"
                        value={countryForm.addressLine2}
                        onChange={(e) => setCountryForm((prev) => ({ ...prev, addressLine2: e.target.value }))}
                        data-testid="input-address-line2"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="city">City</Label>
                      <Input
                        id="city"
                        placeholder="City"
                        value={countryForm.city}
                        onChange={(e) => setCountryForm((prev) => ({ ...prev, city: e.target.value }))}
                        data-testid="input-city"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="stateProvince">State / Province</Label>
                      <Input
                        id="stateProvince"
                        placeholder="State or province"
                        value={countryForm.stateProvince}
                        onChange={(e) => setCountryForm((prev) => ({ ...prev, stateProvince: e.target.value }))}
                        data-testid="input-state-province"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="postalCode">Postal Code</Label>
                      <Input
                        id="postalCode"
                        placeholder="ZIP / Postal code"
                        value={countryForm.postalCode}
                        onChange={(e) => setCountryForm((prev) => ({ ...prev, postalCode: e.target.value }))}
                        data-testid="input-postal-code"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phoneNumber">Local Phone</Label>
                      <div className="flex gap-2">
                        <Input
                          className="w-24 shrink-0"
                          value={countryForm.phoneCountryCode}
                          onChange={(e) => setCountryForm((prev) => ({ ...prev, phoneCountryCode: e.target.value }))}
                          placeholder="+1"
                          data-testid="input-phone-country-code"
                        />
                        <Input
                          id="phoneNumber"
                          placeholder="Phone number"
                          value={countryForm.phoneNumber}
                          onChange={(e) => setCountryForm((prev) => ({ ...prev, phoneNumber: e.target.value }))}
                          data-testid="input-phone-number"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-6 flex-wrap">
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={countryForm.isPrimary}
                        onCheckedChange={(v) => setCountryForm((prev) => ({ ...prev, isPrimary: v }))}
                        data-testid="switch-is-primary"
                      />
                      <Label className="cursor-pointer">Primary Country</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={countryForm.taxResidency}
                        onCheckedChange={(v) => setCountryForm((prev) => ({ ...prev, taxResidency: v }))}
                        data-testid="switch-tax-residency"
                      />
                      <Label className="cursor-pointer">Tax Resident</Label>
                    </div>
                  </div>

                  <Separator />

                  <div className="flex justify-end gap-2 flex-wrap">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setShowAddCountry(false);
                        setEditingCountry(null);
                        resetCountryForm();
                      }}
                      data-testid="button-cancel-country"
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={!countryForm.countryCode || countryMutation.isPending}
                      data-testid="button-save-country"
                    >
                      {countryMutation.isPending ? (
                        <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
                      ) : (
                        <Save className="w-4 h-4 mr-1.5" />
                      )}
                      {countryMutation.isPending ? "Saving..." : "Save Country Profile"}
                    </Button>
                  </div>
                </form>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="notifications" className="mt-4">
          <Card className="p-5">
            <form onSubmit={handleNotifSubmit} className="space-y-5">
              <div>
                <h3 className="text-base font-semibold mb-1">Delivery Channels</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Choose how you want to receive notifications
                </p>
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="text-sm font-medium">Email Notifications</p>
                      <p className="text-xs text-muted-foreground">Receive updates via email</p>
                    </div>
                    <Switch
                      checked={notifs.email}
                      onCheckedChange={() => toggleNotif("email")}
                      data-testid="switch-notif-email"
                    />
                  </div>
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="text-sm font-medium">SMS Notifications</p>
                      <p className="text-xs text-muted-foreground">Receive updates via text message</p>
                    </div>
                    <Switch
                      checked={notifs.sms}
                      onCheckedChange={() => toggleNotif("sms")}
                      data-testid="switch-notif-sms"
                    />
                  </div>
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="text-sm font-medium">Push Notifications</p>
                      <p className="text-xs text-muted-foreground">Receive in-app push notifications</p>
                    </div>
                    <Switch
                      checked={notifs.push}
                      onCheckedChange={() => toggleNotif("push")}
                      data-testid="switch-notif-push"
                    />
                  </div>
                </div>
              </div>

              <BrowserPushSection />

              <Separator />

              <div>
                <h3 className="text-base font-semibold mb-1">Notification Types</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Select which types of notifications you want to receive
                </p>
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="text-sm font-medium">Security Alerts</p>
                      <p className="text-xs text-muted-foreground">Login attempts, password changes, 2FA updates</p>
                    </div>
                    <Switch
                      checked={notifs.security}
                      onCheckedChange={() => toggleNotif("security")}
                      data-testid="switch-notif-security"
                    />
                  </div>
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="text-sm font-medium">Transaction Updates</p>
                      <p className="text-xs text-muted-foreground">Buy/sell confirmations, deposits, withdrawals</p>
                    </div>
                    <Switch
                      checked={notifs.transactions}
                      onCheckedChange={() => toggleNotif("transactions")}
                      data-testid="switch-notif-transactions"
                    />
                  </div>
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="text-sm font-medium">Distribution Alerts</p>
                      <p className="text-xs text-muted-foreground">Dividend and distribution notifications</p>
                    </div>
                    <Switch
                      checked={notifs.distributions}
                      onCheckedChange={() => toggleNotif("distributions")}
                      data-testid="switch-notif-distributions"
                    />
                  </div>
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="text-sm font-medium">Marketing Updates</p>
                      <p className="text-xs text-muted-foreground">New features, promotions, and newsletters</p>
                    </div>
                    <Switch
                      checked={notifs.marketing}
                      onCheckedChange={() => toggleNotif("marketing")}
                      data-testid="switch-notif-marketing"
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="text-base font-semibold mb-1 flex items-center gap-2 flex-wrap">
                  <ArrowRightLeft className="w-4 h-4" />
                  Distribution Preferences
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Control how distribution payouts are handled
                </p>
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="text-sm font-medium">Auto-convert distributions to my primary currency</p>
                      <p className="text-xs text-muted-foreground">
                        When enabled, distributions received in a foreign currency will be automatically converted to your primary wallet currency at the current exchange rate
                      </p>
                    </div>
                    <Switch
                      checked={distPrefData?.autoConvertDistributions ?? false}
                      onCheckedChange={(v) => distPrefMutation.mutate(v)}
                      disabled={distPrefMutation.isPending}
                      data-testid="switch-auto-convert-distributions"
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="flex justify-end">
                <Button
                  type="submit"
                  disabled={notifMutation.isPending}
                  data-testid="button-save-notifications"
                >
                  {notifMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4 mr-1.5" />
                  )}
                  {notifMutation.isPending ? "Saving..." : "Save Preferences"}
                </Button>
              </div>
            </form>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={showLegalDialog} onOpenChange={(open) => {
        if (!open) {
          setShowLegalDialog(false);
          setPendingLegalDocs([]);
          setAcceptedDocIds(new Set());
        }
      }}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto" data-testid="dialog-legal-acceptance">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 flex-wrap">
              <FileText className="w-5 h-5" />
              Legal Documents Required
            </DialogTitle>
            <DialogDescription>
              To set {COUNTRY_DETAILS[pendingCountryCode as CountryCode]?.name || pendingCountryCode} as your primary country,
              you must review and accept the following legal documents.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3 mt-2">
            {pendingLegalDocs.map((doc) => {
              const DocIcon = LEGAL_DOC_ICONS[doc.type] || FileText;
              const isExpanded = expandedDoc === doc.id;
              const isChecked = acceptedDocIds.has(doc.id);
              return (
                <Card key={doc.id} className="p-4" data-testid={`card-legal-doc-${doc.type}`}>
                  <div className="flex items-start gap-3">
                    <div className="mt-0.5">
                      <Checkbox
                        checked={isChecked}
                        onCheckedChange={() => toggleDocAccepted(doc.id)}
                        data-testid={`checkbox-accept-${doc.type}`}
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <DocIcon className="w-4 h-4 text-muted-foreground shrink-0" />
                        <span className="font-medium text-sm" data-testid={`text-legal-title-${doc.type}`}>
                          {doc.title}
                        </span>
                        <Badge variant="outline" className="text-xs">
                          v{doc.version}
                        </Badge>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-xs p-0 h-auto"
                        onClick={() => setExpandedDoc(isExpanded ? null : doc.id)}
                        data-testid={`button-expand-${doc.type}`}
                      >
                        {isExpanded ? "Hide full text" : "Read full document"}
                      </Button>
                      {isExpanded && (
                        <div className="mt-2 p-3 bg-muted/50 rounded-md text-xs leading-relaxed max-h-48 overflow-y-auto" data-testid={`text-legal-content-${doc.type}`}>
                          {doc.content}
                        </div>
                      )}
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>

          <div className="flex items-center justify-between gap-4 flex-wrap mt-4">
            <p className="text-xs text-muted-foreground">
              {acceptedDocIds.size} of {pendingLegalDocs.length} documents accepted
            </p>
            <div className="flex gap-2 flex-wrap">
              <Button
                variant="outline"
                onClick={() => {
                  setShowLegalDialog(false);
                  setPendingLegalDocs([]);
                  setAcceptedDocIds(new Set());
                }}
                data-testid="button-cancel-legal"
              >
                Cancel
              </Button>
              <Button
                disabled={!allDocsAccepted || confirmPrimaryMutation.isPending}
                onClick={() => {
                  confirmPrimaryMutation.mutate({
                    countryCode: pendingCountryCode,
                    acceptedDocumentIds: Array.from(acceptedDocIds),
                  });
                }}
                data-testid="button-confirm-legal"
              >
                {confirmPrimaryMutation.isPending ? (
                  <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 mr-1.5" />
                )}
                {confirmPrimaryMutation.isPending ? "Confirming..." : "Accept & Confirm"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
