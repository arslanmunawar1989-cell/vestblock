import { useQuery } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { DataTable, type Column } from "@/components/data-table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Users, ArrowLeft,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
interface ClientRow {
  id: string;
  username: string;
  email: string;
  fullName: string;
  role: string;
  kycStatus: string;
  createdAt: string;
}

export default function AgentClients() {
  const [search, setSearch] = useState("");
  const { data: clients = [], isLoading } = useQuery<ClientRow[]>({
    queryKey: ["/api/users"],
  });

  const investors = clients.filter(c => c.role === "investor");
  const filtered = investors.filter(c =>
    !search || c.fullName?.toLowerCase().includes(search.toLowerCase()) || c.email?.toLowerCase().includes(search.toLowerCase())
  );

  const columns: Column<ClientRow>[] = [
    { header: "Name", accessor: (row) => row.fullName || row.username },
    { header: "Email", accessor: "email" },
    { header: "KYC", accessor: (row) => <Badge variant={row.kycStatus === "verified" ? "default" : "secondary"} className="text-xs">{row.kycStatus}</Badge> },
    { header: "Joined", accessor: (row) => row.createdAt ? new Date(row.createdAt).toLocaleDateString("en-US", { month: "short", year: "numeric" }) : "—" },
  ];

  return (
    <RoleLayout role="agent">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/agent/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle title="Clients" description="Manage your investor clients" />
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search clients..." className="pl-9" value={search} onChange={e => setSearch(e.target.value)} data-testid="input-search-clients" />
          </div>
        </div>
        <Section>
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-12 w-full" />)}
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12">
              <Users className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground" data-testid="text-no-clients">No clients found</p>
            </div>
          ) : (
            <DataTable columns={columns} data={filtered} />
          )}
        </Section>
      </div>
    </RoleLayout>
  );
}
