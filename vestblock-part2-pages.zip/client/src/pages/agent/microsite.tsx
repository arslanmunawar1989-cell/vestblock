import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useState, useMemo } from "react";
import { useQuery, useQueries } from "@tanstack/react-query";
import { formatCurrencyForCountry, formatDateForCountry, formatPercent } from "@/lib/format";
import {
  COUNTRY_DETAILS,
  COUNTRY_TO_CURRENCY,
  SUPPORTED_COUNTRIES,
  type CountryCode,
  type CurrencyCode,
} from "@shared/constants";
import { SiWhatsapp } from "react-icons/si";
import { Phone, Mail, Globe, MapPin, Calendar, TrendingUp, ArrowRightLeft, Loader2, Building2, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface Asset {
  id: string;
  name: string;
  symbol: string;
  baseCurrency: string;
  country: string;
  pricePerToken: string;
  annualYield?: string;
  minInvestment?: string;
  type?: string;
  totalTokens?: string;
  description?: string;
}

interface FxRateResponse {
  from: string;
  to: string;
  rate: number;
}

const WHATSAPP_COUNTRIES: CountryCode[] = ["PK", "AE"];

const REGION_CONTACT: Record<CountryCode, { primary: string; details: string; cta: string }> = {
  PK: {
    primary: "whatsapp",
    details: "+92 300 1234567",
    cta: "Chat on WhatsApp",
  },
  AE: {
    primary: "whatsapp",
    details: "+971 50 1234567",
    cta: "Chat on WhatsApp",
  },
  GB: {
    primary: "phone",
    details: "+44 20 7946 0958",
    cta: "Call Us",
  },
  US: {
    primary: "phone",
    details: "+1 (212) 555-0147",
    cta: "Call Us",
  },
  QA: {
    primary: "phone",
    details: "+974 4412 3456",
    cta: "Call Us",
  },
};

function ContactCTA({ country }: { country: CountryCode }) {
  const contact = REGION_CONTACT[country];
  const isWhatsApp = WHATSAPP_COUNTRIES.includes(country);

  if (isWhatsApp) {
    const whatsappUrl = `https://wa.me/${contact.details.replace(/[\s\-()]/g, "")}`;
    return (
      <div className="space-y-3" data-testid="cta-contact-section">
        <Button
          className="w-full bg-[#25D366] border-[#25D366] text-white"
          onClick={() => window.open(whatsappUrl, "_blank", "noopener,noreferrer")}
          data-testid="button-cta-whatsapp"
        >
          <SiWhatsapp className="w-4 h-4 mr-2" />
          {contact.cta}
        </Button>
        <p className="text-xs text-center text-muted-foreground" data-testid="text-contact-number">
          {contact.details}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3" data-testid="cta-contact-section">
      <Button variant="default" className="w-full" data-testid="button-cta-phone">
        <Phone className="w-4 h-4 mr-2" />
        {contact.cta}
      </Button>
      <p className="text-xs text-center text-muted-foreground" data-testid="text-contact-number">
        {contact.details}
      </p>
      <Button variant="outline" className="w-full" data-testid="button-cta-email">
        <Mail className="w-4 h-4 mr-2" />
        Email Us
      </Button>
    </div>
  );
}

function AssetMicrositeCard({
  asset,
  targetCountry,
  fxRate,
  fxLoading,
}: {
  asset: Asset;
  targetCountry: CountryCode;
  fxRate: FxRateResponse | null;
  fxLoading: boolean;
}) {
  const targetCurrency = COUNTRY_TO_CURRENCY[targetCountry];
  const isSameCurrency = asset.baseCurrency === targetCurrency;
  const priceNum = parseFloat(asset.pricePerToken);
  const convertedPrice = fxRate && !isSameCurrency ? priceNum * fxRate.rate : null;
  const minInvestNum = asset.minInvestment ? parseFloat(asset.minInvestment) : null;
  const convertedMin = fxRate && minInvestNum && !isSameCurrency ? minInvestNum * fxRate.rate : null;

  return (
    <Card data-testid={`card-microsite-asset-${asset.id}`}>
      <CardContent className="p-5 space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Building2 className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="font-semibold text-sm" data-testid={`text-microsite-asset-name-${asset.id}`}>
                {asset.name}
              </p>
              <p className="text-xs text-muted-foreground">{asset.symbol}</p>
            </div>
          </div>
          <Badge variant="secondary" className="text-xs" data-testid={`badge-microsite-country-${asset.id}`}>
            <MapPin className="w-3 h-3 mr-1" />
            {asset.country}
          </Badge>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <p className="text-xs text-muted-foreground mb-1">Token Price</p>
            <p className="font-semibold text-sm" data-testid={`text-microsite-price-base-${asset.id}`}>
              {formatCurrencyForCountry(priceNum, asset.baseCurrency, targetCountry)}
            </p>
            {!isSameCurrency && (
              <div className="mt-1">
                {fxLoading ? (
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Loader2 className="w-3 h-3 animate-spin" /> Converting...
                  </span>
                ) : convertedPrice !== null ? (
                  <p className="text-xs text-muted-foreground flex items-center gap-1" data-testid={`text-microsite-price-converted-${asset.id}`}>
                    <ArrowRightLeft className="w-3 h-3" />
                    ~{formatCurrencyForCountry(convertedPrice, targetCurrency, targetCountry)}
                  </p>
                ) : null}
              </div>
            )}
          </div>

          {asset.annualYield && (
            <div>
              <p className="text-xs text-muted-foreground mb-1">Annual Yield</p>
              <p className="font-semibold text-sm flex items-center gap-1" data-testid={`text-microsite-yield-${asset.id}`}>
                <TrendingUp className="w-3 h-3 text-emerald-500" />
                {formatPercent(parseFloat(asset.annualYield) / 100)}
              </p>
            </div>
          )}

          {minInvestNum && (
            <div>
              <p className="text-xs text-muted-foreground mb-1">Min. Investment</p>
              <p className="font-semibold text-sm" data-testid={`text-microsite-min-invest-${asset.id}`}>
                {formatCurrencyForCountry(minInvestNum, asset.baseCurrency, targetCountry)}
              </p>
              {!isSameCurrency && convertedMin !== null && (
                <p className="text-xs text-muted-foreground" data-testid={`text-microsite-min-converted-${asset.id}`}>
                  ~{formatCurrencyForCountry(convertedMin, targetCurrency, targetCountry)}
                </p>
              )}
            </div>
          )}

          <div>
            <p className="text-xs text-muted-foreground mb-1">Listed Date</p>
            <p className="text-sm flex items-center gap-1" data-testid={`text-microsite-date-${asset.id}`}>
              <Calendar className="w-3 h-3" />
              {formatDateForCountry(new Date(), targetCountry)}
            </p>
          </div>
        </div>

        {!isSameCurrency && convertedPrice !== null && (
          <p className="text-xs text-muted-foreground border-t pt-2" data-testid={`text-microsite-fx-note-${asset.id}`}>
            Prices shown in {asset.baseCurrency} with {targetCurrency} estimates (rate: 1 {asset.baseCurrency} = {fxRate?.rate.toFixed(4)} {targetCurrency}). Settlement in {asset.baseCurrency}.
          </p>
        )}
      </CardContent>
    </Card>
  );
}

export default function AgentMicrosite() {
  const [audienceCountry, setAudienceCountry] = useState<CountryCode>("AE");

  const { data: assetsData, isLoading: assetsLoading } = useQuery<Asset[]>({
    queryKey: ["/api/assets"],
  });

  const assets = assetsData || [];
  const targetCurrency = COUNTRY_TO_CURRENCY[audienceCountry];

  const baseCurrencyKey = assets.map(a => a.baseCurrency).sort().join(",");
  const uniqueBaseCurrencies = useMemo(
    () => Array.from(new Set(assets.map(a => a.baseCurrency))).filter(c => c !== targetCurrency).sort(),
    [baseCurrencyKey, targetCurrency]
  );

  const fxResults = useQueries({
    queries: uniqueBaseCurrencies.map(from => ({
      queryKey: ["/api/fx/rate", from, targetCurrency],
      queryFn: async () => {
        const res = await fetch(`/api/fx/rate?from=${from}&to=${targetCurrency}`, { credentials: "include" });
        if (!res.ok) throw new Error("FX rate unavailable");
        return res.json() as Promise<FxRateResponse>;
      },
      staleTime: 60000,
      retry: 1,
    })),
  });

  const fxRateMap = useMemo(() => {
    const map: Record<string, { rate: FxRateResponse | null; loading: boolean }> = {};
    uniqueBaseCurrencies.forEach((from, i) => {
      const result = fxResults[i];
      map[from] = { rate: result?.data || null, loading: result?.isLoading || false };
    });
    return map;
  }, [uniqueBaseCurrencies, fxResults]);

  const contactInfo = REGION_CONTACT[audienceCountry];
  const countryName = COUNTRY_DETAILS[audienceCountry].name;
  const isWhatsAppRegion = WHATSAPP_COUNTRIES.includes(audienceCountry);

  return (
    <RoleLayout role="agent">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/agent/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Microsites"
          description="Client-facing microsite preview — adapts formatting and contact options to the audience region"
        />
        </div>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-4 space-y-0 pb-3">
            <CardTitle className="text-base">Audience Settings</CardTitle>
            <div className="flex items-center gap-3 flex-wrap">
              <Label className="text-sm text-muted-foreground whitespace-nowrap">Target Country:</Label>
              <Select value={audienceCountry} onValueChange={(v) => setAudienceCountry(v as CountryCode)}>
                <SelectTrigger className="w-[200px]" data-testid="select-audience-country">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SUPPORTED_COUNTRIES.map(code => (
                    <SelectItem key={code} value={code} data-testid={`option-country-${code}`}>
                      {COUNTRY_DETAILS[code].name} ({code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4 flex-wrap text-sm">
              <Badge variant="secondary" data-testid="badge-locale-currency">
                <Globe className="w-3 h-3 mr-1" />
                Currency: {targetCurrency}
              </Badge>
              <Badge variant="secondary" data-testid="badge-locale-date">
                <Calendar className="w-3 h-3 mr-1" />
                Date: {formatDateForCountry(new Date(), audienceCountry)}
              </Badge>
              <Badge variant="secondary" data-testid="badge-locale-cta">
                {isWhatsAppRegion ? (
                  <><SiWhatsapp className="w-3 h-3 mr-1" /> WhatsApp CTA</>
                ) : (
                  <><Phone className="w-3 h-3 mr-1" /> Phone/Email CTA</>
                )}
              </Badge>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <h3 className="font-semibold text-sm text-muted-foreground">
              Asset Listings — Formatted for {countryName}
            </h3>
            {assetsLoading ? (
              <div className="flex items-center justify-center py-12 text-muted-foreground">
                <Loader2 className="w-5 h-5 animate-spin mr-2" />
                Loading assets...
              </div>
            ) : assets.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center text-muted-foreground text-sm">
                  No assets available
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-testid="grid-microsite-assets">
                {assets.map(asset => {
                  const fx = fxRateMap[asset.baseCurrency];
                  return (
                    <AssetMicrositeCard
                      key={asset.id}
                      asset={asset}
                      targetCountry={audienceCountry}
                      fxRate={fx?.rate || null}
                      fxLoading={fx?.loading || false}
                    />
                  );
                })}
              </div>
            )}
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-sm text-muted-foreground">
              Contact — {countryName}
            </h3>
            <Card data-testid="card-contact-cta">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Get in Touch</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <ContactCTA country={audienceCountry} />
                <div className="border-t pt-3 space-y-2">
                  <p className="text-xs text-muted-foreground" data-testid="text-contact-region-label">
                    {countryName} Office
                  </p>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Phone className="w-3 h-3 flex-shrink-0" />
                    <span data-testid="text-contact-phone">{contactInfo.details}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Mail className="w-3 h-3 flex-shrink-0" />
                    <span data-testid="text-contact-email">invest@vestblock.com</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 space-y-2">
                <p className="text-xs font-medium">Localization Info</p>
                <div className="space-y-1 text-xs text-muted-foreground">
                  <p data-testid="text-locale-region">Region: {countryName}</p>
                  <p data-testid="text-locale-currency-label">Display Currency: {targetCurrency}</p>
                  <p data-testid="text-locale-contact-method">
                    Contact Method: {isWhatsAppRegion ? "WhatsApp" : "Phone / Email"}
                  </p>
                  <p data-testid="text-locale-date-format">
                    Date Format: {formatDateForCountry(new Date("2025-12-31"), audienceCountry, "long")}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </RoleLayout>
  );
}
