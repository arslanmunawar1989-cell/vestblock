import { RoleLayout } from "@/components/role-layout";
import { GradientHeader } from "@/components/gradient-header";
import { StatTile } from "@/components/stat-tile";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery } from "@tanstack/react-query";
import { formatCurrency } from "@/lib/format";
import { Users, Handshake, DollarSign, TrendingUp, ShieldCheck, ShieldAlert } from "lucide-react";

interface AgentAnalytics {
  kpis: {
    totalClients: number;
    activeListings: number;
    totalCommission: number;
    totalAum: number;
    kycPending: number;
    kycVerified: number;
    conversionRate: number;
  };
  topClients: {
    id: string;
    name: string;
    email: string;
    kycStatus: string;
    invested: number;
    currentValue: number;
    assets: number;
  }[];
  recentOffers: {
    client: string;
    asset: string;
    symbol: string;
    amount: number;
    currency: string;
    status: string;
  }[];
  notifications: {
    id: string;
    type: string;
    title: string;
    message: string;
    read: boolean;
    createdAt: string;
  }[];
}

export default function AgentDashboard() {
  const { data, isLoading } = useQuery<AgentAnalytics>({
    queryKey: ["/api/analytics/agent"],
  });

  const kpis = data?.kpis;
  const topClients = data?.topClients || [];
  const recentOffers = data?.recentOffers || [];
  const recentNotifications = data?.notifications || [];

  return (
    <RoleLayout role="agent">
      <div className="space-y-6">
        <GradientHeader>
          <div>
            <p className="text-white/80 text-sm mb-1">Agent Dashboard</p>
            <h1 className="text-2xl font-bold text-white">Sales & Client Portal</h1>
          </div>
        </GradientHeader>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-28" />)}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatTile label="Active Clients" value={String(kpis?.totalClients || 0)} change={`${kpis?.kycVerified || 0} verified`} trend="up" icon={<Users className="w-5 h-5" />} data-testid="stat-total-clients" />
            <StatTile label="Open Offers" value={String(kpis?.activeListings || 0)} icon={<Handshake className="w-5 h-5" />} data-testid="stat-active-listings" />
            <StatTile label="Commission Earned" value={formatCurrency(kpis?.totalCommission || 0, "AED")} icon={<DollarSign className="w-5 h-5" />} data-testid="stat-commission" />
            <StatTile label="Client AUM" value={formatCurrency(kpis?.totalAum || 0, "AED")} icon={<TrendingUp className="w-5 h-5" />} data-testid="stat-aum" />
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Section title="Recent Investments">
            <GlassCard>
              {isLoading ? (
                <div className="space-y-3">
                  {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-12" />)}
                </div>
              ) : recentOffers.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-6" data-testid="text-no-offers">No recent investments</p>
              ) : (
                <div className="space-y-3">
                  {recentOffers.map((offer, i) => (
                    <div key={i} className="flex items-center justify-between gap-3 py-2 border-b border-border/30 last:border-0" data-testid={`agent-offer-${i}`}>
                      <div>
                        <p className="text-sm font-medium">{offer.client}</p>
                        <p className="text-xs text-muted-foreground">{offer.asset} ({offer.symbol}) - {formatCurrency(offer.amount, offer.currency)}</p>
                      </div>
                      <Badge variant={offer.status === "Completed" ? "default" : "secondary"} className="text-xs">{offer.status}</Badge>
                    </div>
                  ))}
                </div>
              )}
            </GlassCard>
          </Section>

          <Section title="Top Clients">
            <GlassCard>
              {isLoading ? (
                <div className="space-y-3">
                  {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-12" />)}
                </div>
              ) : topClients.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-6" data-testid="text-no-clients">No clients yet</p>
              ) : (
                <div className="space-y-3">
                  {topClients.map((client, i) => (
                    <div key={client.id} className="flex items-center justify-between gap-3 py-2 border-b border-border/30 last:border-0" data-testid={`agent-client-${i}`}>
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center">
                          <span className="text-primary text-xs font-bold">{client.name[0]}</span>
                        </div>
                        <div>
                          <p className="text-sm font-medium">{client.name}</p>
                          <p className="text-xs text-muted-foreground">{client.assets} assets</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-sm font-semibold">{formatCurrency(client.currentValue, "AED")}</span>
                        <div className="flex items-center gap-1 justify-end">
                          {client.kycStatus === "verified" ? (
                            <ShieldCheck className="w-3 h-3 text-emerald-500" />
                          ) : (
                            <ShieldAlert className="w-3 h-3 text-amber-500" />
                          )}
                          <span className="text-xs text-muted-foreground capitalize">{client.kycStatus}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </GlassCard>
          </Section>
        </div>

        {recentNotifications.length > 0 && (
          <Section title="Recent Notifications">
            <GlassCard>
              <div className="space-y-3">
                {recentNotifications.slice(0, 5).map((n) => (
                  <div key={n.id} className="flex items-start gap-3 py-2 border-b border-border/30 last:border-0" data-testid={`notification-${n.id}`}>
                    <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${n.read ? "bg-muted-foreground/30" : "bg-primary"}`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{n.title}</p>
                      <p className="text-xs text-muted-foreground">{n.message}</p>
                      <p className="text-xs text-muted-foreground mt-1">{new Date(n.createdAt).toLocaleDateString()}</p>
                    </div>
                    <Badge variant="secondary" className="no-default-active-elevate text-xs shrink-0">{n.type}</Badge>
                  </div>
                ))}
              </div>
            </GlassCard>
          </Section>
        )}
      </div>
    </RoleLayout>
  );
}
