import { useQuery } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Building2, ArrowLeft,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
interface AssetRow {
  id: string;
  name: string;
  assetType: string;
  pricePerToken: string;
  baseCurrency: string;
  status: string;
  minInvestment: string;
  annualYield: string;
}

export default function AgentMarketplace() {
  const [search, setSearch] = useState("");
  const { data: assets = [], isLoading } = useQuery<AssetRow[]>({
    queryKey: ["/api/marketplace/assets"],
  });

  const filtered = assets.filter(a =>
    !search || a.name.toLowerCase().includes(search.toLowerCase()) || a.assetType?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <RoleLayout role="agent">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/agent/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle title="Marketplace" description="Browse assets available for client placement" />
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search assets..." className="pl-9" value={search} onChange={e => setSearch(e.target.value)} data-testid="input-search-agent-marketplace" />
          </div>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-32 w-full" />)}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12">
            <Building2 className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
            <p className="text-muted-foreground" data-testid="text-no-assets">No assets available</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filtered.map((asset, i) => (
              <GlassCard key={asset.id}>
                <div className="space-y-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-md gradient-hero flex items-center justify-center flex-shrink-0">
                        <span className="text-white font-bold">{asset.name[0]}</span>
                      </div>
                      <div>
                        <p className="font-semibold text-sm" data-testid={`agent-asset-${i}`}>{asset.name}</p>
                        <p className="text-xs text-muted-foreground">{asset.assetType}</p>
                      </div>
                    </div>
                    <Badge variant={asset.status === "active" ? "default" : "secondary"} className="text-xs">{asset.status}</Badge>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div>
                      <p className="text-xs text-muted-foreground">Token Price</p>
                      <p className="text-sm font-semibold">{asset.baseCurrency} {Number(asset.pricePerToken).toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Yield</p>
                      <p className="text-sm font-semibold text-emerald-600 dark:text-emerald-400">{asset.annualYield}%</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Min. Invest</p>
                      <p className="text-sm font-semibold">{asset.baseCurrency} {Number(asset.minInvestment || 0).toLocaleString()}</p>
                    </div>
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
        )}
      </div>
    </RoleLayout>
  );
}
