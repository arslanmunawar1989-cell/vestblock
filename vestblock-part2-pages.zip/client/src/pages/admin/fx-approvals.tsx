import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { StatTile } from "@/components/stat-tile";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatCurrency, formatDate } from "@/lib/format";
import { Clock, CheckCircle2, XCircle, Hash, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface FxApprovalRequest {
  id: string;
  userId: string;
  quoteId: string;
  fromCurrency: string;
  toCurrency: string;
  amountFrom: string;
  amountTo: string;
  thresholdAmount: string | null;
  status: string;
  reviewedBy: string | null;
  reviewedAt: string | null;
  reviewNotes: string | null;
  createdAt: string;
  user: { id: string; fullName: string; username: string; email: string; tier: string } | null;
}

export default function AdminFxApprovals() {
  const { toast } = useToast();
  const [statusFilter, setStatusFilter] = useState<string>("pending");
  const [reviewDialog, setReviewDialog] = useState<{ request: FxApprovalRequest; action: "approve" | "reject" } | null>(null);
  const [reviewNotes, setReviewNotes] = useState("");

  const queryPath = statusFilter === "all" ? "/api/admin/fx-approvals" : `/api/admin/fx-approvals?status=${statusFilter}`;
  const { data: requests, isLoading } = useQuery<FxApprovalRequest[]>({
    queryKey: [queryPath],
  });

  const approveMutation = useMutation({
    mutationFn: async ({ id, notes }: { id: string; notes: string }) => {
      const res = await apiRequest("POST", `/api/admin/fx-approvals/${id}/approve`, { notes });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryPath] });
      setReviewDialog(null);
      setReviewNotes("");
      toast({ title: "Conversion approved" });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async ({ id, notes }: { id: string; notes: string }) => {
      const res = await apiRequest("POST", `/api/admin/fx-approvals/${id}/reject`, { notes });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryPath] });
      setReviewDialog(null);
      setReviewNotes("");
      toast({ title: "Conversion rejected" });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  function handleReview() {
    if (!reviewDialog) return;
    if (reviewDialog.action === "approve") {
      approveMutation.mutate({ id: reviewDialog.request.id, notes: reviewNotes });
    } else {
      rejectMutation.mutate({ id: reviewDialog.request.id, notes: reviewNotes });
    }
  }

  const all = requests || [];
  const pendingCount = all.filter(r => r.status === "pending").length;
  const approvedCount = all.filter(r => r.status === "approved").length;
  const rejectedCount = all.filter(r => r.status === "rejected").length;

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle title="FX Conversion Approvals" description="Review and approve large or flagged FX conversions" />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatTile label="Pending" value={String(pendingCount)} icon={<Clock className="w-5 h-5" />} />
          <StatTile label="Approved" value={String(approvedCount)} icon={<CheckCircle2 className="w-5 h-5" />} />
          <StatTile label="Rejected" value={String(rejectedCount)} icon={<XCircle className="w-5 h-5" />} />
          <StatTile label="Total" value={String(all.length)} icon={<Hash className="w-5 h-5" />} />
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[160px]" data-testid="select-status-filter">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Section title="Approval Requests">
          <GlassCard>
            {isLoading ? (
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
              </div>
            ) : all.length === 0 ? (
              <p className="text-muted-foreground text-center py-8" data-testid="text-no-approvals">No approval requests found</p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User</TableHead>
                      <TableHead>Tier</TableHead>
                      <TableHead>From</TableHead>
                      <TableHead>To</TableHead>
                      <TableHead>Threshold</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {all.map((req) => (
                      <TableRow key={req.id} data-testid={`row-approval-${req.id}`}>
                        <TableCell className="font-medium">
                          {req.user?.fullName || req.user?.username || "Unknown"}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-xs">{req.user?.tier || "standard"}</Badge>
                        </TableCell>
                        <TableCell>
                          <span className="text-sm">{formatCurrency(req.amountFrom, req.fromCurrency)}</span>
                        </TableCell>
                        <TableCell>
                          <span className="text-sm">{formatCurrency(req.amountTo, req.toCurrency)}</span>
                        </TableCell>
                        <TableCell className="text-sm">
                          {req.thresholdAmount ? formatCurrency(req.thresholdAmount, req.fromCurrency) : "—"}
                        </TableCell>
                        <TableCell className="text-sm">{formatDate(req.createdAt)}</TableCell>
                        <TableCell>
                          <Badge
                            variant={req.status === "pending" ? "secondary" : req.status === "approved" ? "default" : "destructive"}
                            className="text-xs"
                          >
                            {req.status}
                          </Badge>
                          {req.reviewNotes && (
                            <p className="text-xs text-muted-foreground mt-1 max-w-[150px] truncate">{req.reviewNotes}</p>
                          )}
                        </TableCell>
                        <TableCell>
                          {req.status === "pending" ? (
                            <div className="flex items-center gap-1">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => { setReviewDialog({ request: req, action: "approve" }); setReviewNotes(""); }}
                                data-testid={`button-approve-${req.id}`}
                              >
                                <CheckCircle2 className="w-3 h-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => { setReviewDialog({ request: req, action: "reject" }); setReviewNotes(""); }}
                                data-testid={`button-reject-${req.id}`}
                              >
                                <XCircle className="w-3 h-3" />
                              </Button>
                            </div>
                          ) : (
                            <span className="text-xs text-muted-foreground">
                              {req.reviewedAt ? formatDate(req.reviewedAt) : "—"}
                            </span>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </GlassCard>
        </Section>

        <Dialog open={!!reviewDialog} onOpenChange={(open) => { if (!open) setReviewDialog(null); }}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {reviewDialog?.action === "approve" ? "Approve" : "Reject"} Conversion
              </DialogTitle>
              <DialogDescription>
                {reviewDialog?.request.user?.fullName || "User"} wants to convert{" "}
                {reviewDialog?.request ? formatCurrency(reviewDialog.request.amountFrom, reviewDialog.request.fromCurrency) : ""}{" "}
                to {reviewDialog?.request.toCurrency}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Review Notes (optional)</Label>
                <Input
                  value={reviewNotes}
                  onChange={(e) => setReviewNotes(e.target.value)}
                  placeholder="Add a note..."
                  data-testid="input-review-notes"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setReviewDialog(null)}>Cancel</Button>
              <Button
                variant={reviewDialog?.action === "approve" ? "default" : "destructive"}
                onClick={handleReview}
                disabled={approveMutation.isPending || rejectMutation.isPending}
                data-testid="button-confirm-review"
              >
                {approveMutation.isPending || rejectMutation.isPending ? "Processing..." : reviewDialog?.action === "approve" ? "Approve" : "Reject"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </RoleLayout>
  );
}
