import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate } from "@/lib/format";
import { WALLET_CURRENCIES, CURRENCY_DETAILS } from "@shared/constants";
import { USER_TIERS } from "@shared/schema";
import { Plus, Settings, XCircle, CheckCircle2, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface TierLimit {
  minAmount: number;
  maxAmount: number;
}

interface FxSpreadConfig {
  id: string;
  fromCurrency: string;
  toCurrency: string;
  spreadOverride: string;
  tierLimits: Record<string, TierLimit>;
  approvalThreshold: string | null;
  approvalRequired: boolean;
  isActive: boolean;
  createdBy: string | null;
  createdAt: string;
  updatedAt: string;
}

export default function AdminFxConfig() {
  const { toast } = useToast();
  const [showCreate, setShowCreate] = useState(false);
  const [editConfig, setEditConfig] = useState<FxSpreadConfig | null>(null);

  const [fromCurrency, setFromCurrency] = useState("");
  const [toCurrency, setToCurrency] = useState("");
  const [spreadOverride, setSpreadOverride] = useState("0");
  const [approvalRequired, setApprovalRequired] = useState(false);
  const [approvalThreshold, setApprovalThreshold] = useState("");
  const [tierLimits, setTierLimits] = useState<Record<string, TierLimit>>({});

  const { data: configs, isLoading } = useQuery<FxSpreadConfig[]>({
    queryKey: ["/api/admin/fx-configs"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/admin/fx-configs", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/fx-configs"] });
      setShowCreate(false);
      resetForm();
      toast({ title: "FX config created" });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      const res = await apiRequest("PATCH", `/api/admin/fx-configs/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/fx-configs"] });
      setEditConfig(null);
      resetForm();
      toast({ title: "FX config updated" });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const deactivateMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("POST", `/api/admin/fx-configs/${id}/deactivate`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/fx-configs"] });
      toast({ title: "FX config deactivated" });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  function resetForm() {
    setFromCurrency("");
    setToCurrency("");
    setSpreadOverride("0");
    setApprovalRequired(false);
    setApprovalThreshold("");
    setTierLimits({});
  }

  function openEdit(config: FxSpreadConfig) {
    setEditConfig(config);
    setSpreadOverride(config.spreadOverride);
    setApprovalRequired(config.approvalRequired);
    setApprovalThreshold(config.approvalThreshold || "");
    setTierLimits(config.tierLimits || {});
  }

  function handleCreate() {
    const cleanLimits: Record<string, TierLimit> = {};
    for (const [tier, limit] of Object.entries(tierLimits)) {
      if (limit.minAmount >= 0 && limit.maxAmount > 0) {
        cleanLimits[tier] = limit;
      }
    }
    createMutation.mutate({
      fromCurrency,
      toCurrency,
      spreadOverride,
      approvalRequired,
      approvalThreshold: approvalThreshold || null,
      tierLimits: cleanLimits,
    });
  }

  function handleUpdate() {
    if (!editConfig) return;
    const cleanLimits: Record<string, TierLimit> = {};
    for (const [tier, limit] of Object.entries(tierLimits)) {
      if (limit.minAmount >= 0 && limit.maxAmount > 0) {
        cleanLimits[tier] = limit;
      }
    }
    updateMutation.mutate({
      id: editConfig.id,
      data: {
        spreadOverride,
        approvalRequired,
        approvalThreshold: approvalThreshold || null,
        tierLimits: cleanLimits,
      },
    });
  }

  function updateTierLimit(tier: string, field: "minAmount" | "maxAmount", value: string) {
    const num = parseFloat(value) || 0;
    setTierLimits(prev => ({
      ...prev,
      [tier]: { ...prev[tier], [field]: num, ...(field === "minAmount" ? {} : {}), ...(prev[tier] ? {} : { minAmount: 0, maxAmount: 0 }) },
    }));
  }

  const activeConfigs = (configs || []).filter(c => c.isActive);
  const inactiveConfigs = (configs || []).filter(c => !c.isActive);

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <Link href="/admin/dashboard">
              <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <PageTitle title="FX Spread Configuration" description="Manage spread overrides, tier limits, and approval thresholds per currency pair" />
          </div>
          <Button onClick={() => { resetForm(); setShowCreate(true); }} data-testid="button-create-config">
            <Plus className="w-4 h-4 mr-1" /> New Config
          </Button>
        </div>

        <Section title="Active Configurations">
          <GlassCard>
            {isLoading ? (
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
              </div>
            ) : activeConfigs.length === 0 ? (
              <p className="text-muted-foreground text-center py-8" data-testid="text-no-configs">No active FX spread configurations</p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Pair</TableHead>
                      <TableHead>Spread</TableHead>
                      <TableHead>Tier Limits</TableHead>
                      <TableHead>Approval</TableHead>
                      <TableHead>Updated</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {activeConfigs.map((config) => (
                      <TableRow key={config.id} data-testid={`row-config-${config.id}`}>
                        <TableCell className="font-medium">
                          {config.fromCurrency}/{config.toCurrency}
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="text-xs">{(parseFloat(config.spreadOverride) * 100).toFixed(2)}%</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col gap-1">
                            {Object.entries(config.tierLimits || {}).map(([tier, limit]) => (
                              <span key={tier} className="text-xs text-muted-foreground">
                                {tier}: {(limit as TierLimit).minAmount.toLocaleString()} - {(limit as TierLimit).maxAmount.toLocaleString()}
                              </span>
                            ))}
                            {Object.keys(config.tierLimits || {}).length === 0 && (
                              <span className="text-xs text-muted-foreground">No limits</span>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          {config.approvalRequired ? (
                            <div className="flex flex-col gap-1">
                              <Badge variant="default" className="text-xs">Required</Badge>
                              {config.approvalThreshold && (
                                <span className="text-xs text-muted-foreground">
                                  Above {parseFloat(config.approvalThreshold).toLocaleString()}
                                </span>
                              )}
                            </div>
                          ) : (
                            <Badge variant="outline" className="text-xs">Not required</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-sm">{formatDate(config.updatedAt)}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Button size="sm" variant="outline" onClick={() => openEdit(config)} data-testid={`button-edit-config-${config.id}`}>
                              <Settings className="w-3 h-3" />
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => deactivateMutation.mutate(config.id)} data-testid={`button-deactivate-config-${config.id}`}>
                              <XCircle className="w-3 h-3" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </GlassCard>
        </Section>

        {inactiveConfigs.length > 0 && (
          <Section title="Inactive Configurations">
            <GlassCard>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Pair</TableHead>
                      <TableHead>Spread</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Updated</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {inactiveConfigs.map((config) => (
                      <TableRow key={config.id} className="opacity-60">
                        <TableCell>{config.fromCurrency}/{config.toCurrency}</TableCell>
                        <TableCell>{(parseFloat(config.spreadOverride) * 100).toFixed(2)}%</TableCell>
                        <TableCell><Badge variant="secondary" className="text-xs">Inactive</Badge></TableCell>
                        <TableCell className="text-sm">{formatDate(config.updatedAt)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </GlassCard>
          </Section>
        )}

        <Dialog open={showCreate} onOpenChange={setShowCreate}>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>New FX Spread Config</DialogTitle>
              <DialogDescription>Configure spread, tier limits, and approval threshold for a currency pair</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>From Currency</Label>
                  <Select value={fromCurrency} onValueChange={setFromCurrency}>
                    <SelectTrigger data-testid="select-from-currency">
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      {WALLET_CURRENCIES.map(c => (
                        <SelectItem key={c} value={c}>{CURRENCY_DETAILS[c].symbol} {c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>To Currency</Label>
                  <Select value={toCurrency} onValueChange={setToCurrency}>
                    <SelectTrigger data-testid="select-to-currency">
                      <SelectValue placeholder="Select" />
                    </SelectTrigger>
                    <SelectContent>
                      {WALLET_CURRENCIES.map(c => (
                        <SelectItem key={c} value={c}>{CURRENCY_DETAILS[c].symbol} {c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label>Spread Override (decimal, e.g. 0.005 = 0.5%)</Label>
                <Input
                  type="number"
                  step="0.001"
                  min="0"
                  value={spreadOverride}
                  onChange={(e) => setSpreadOverride(e.target.value)}
                  data-testid="input-spread-override"
                />
              </div>
              <div className="flex items-center gap-3">
                <Switch
                  checked={approvalRequired}
                  onCheckedChange={setApprovalRequired}
                  data-testid="switch-approval-required"
                />
                <Label>Approval required above threshold</Label>
              </div>
              {approvalRequired && (
                <div>
                  <Label>Approval Threshold ({fromCurrency || "amount"})</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    value={approvalThreshold}
                    onChange={(e) => setApprovalThreshold(e.target.value)}
                    placeholder="e.g. 10000"
                    data-testid="input-approval-threshold"
                  />
                </div>
              )}
              <div>
                <Label className="mb-2 block">Tier Conversion Limits</Label>
                <div className="space-y-3">
                  {USER_TIERS.map(tier => (
                    <div key={tier} className="flex items-center gap-2 flex-wrap">
                      <Badge variant="outline" className="w-24 justify-center text-xs">{tier}</Badge>
                      <div className="flex-1 min-w-[100px]">
                        <Input
                          type="number"
                          step="1"
                          min="0"
                          placeholder="Min"
                          value={tierLimits[tier]?.minAmount || ""}
                          onChange={(e) => updateTierLimit(tier, "minAmount", e.target.value)}
                          data-testid={`input-tier-min-${tier}`}
                        />
                      </div>
                      <span className="text-muted-foreground text-sm">to</span>
                      <div className="flex-1 min-w-[100px]">
                        <Input
                          type="number"
                          step="1"
                          min="0"
                          placeholder="Max"
                          value={tierLimits[tier]?.maxAmount || ""}
                          onChange={(e) => updateTierLimit(tier, "maxAmount", e.target.value)}
                          data-testid={`input-tier-max-${tier}`}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button>
              <Button
                onClick={handleCreate}
                disabled={!fromCurrency || !toCurrency || fromCurrency === toCurrency || createMutation.isPending}
                data-testid="button-submit-create"
              >
                {createMutation.isPending ? "Creating..." : "Create Config"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <Dialog open={!!editConfig} onOpenChange={(open) => { if (!open) setEditConfig(null); }}>
          <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit FX Config: {editConfig?.fromCurrency}/{editConfig?.toCurrency}</DialogTitle>
              <DialogDescription>Update spread, tier limits, and approval settings</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label>Spread Override (decimal, e.g. 0.005 = 0.5%)</Label>
                <Input
                  type="number"
                  step="0.001"
                  min="0"
                  value={spreadOverride}
                  onChange={(e) => setSpreadOverride(e.target.value)}
                  data-testid="input-edit-spread"
                />
              </div>
              <div className="flex items-center gap-3">
                <Switch
                  checked={approvalRequired}
                  onCheckedChange={setApprovalRequired}
                  data-testid="switch-edit-approval"
                />
                <Label>Approval required above threshold</Label>
              </div>
              {approvalRequired && (
                <div>
                  <Label>Approval Threshold</Label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0"
                    value={approvalThreshold}
                    onChange={(e) => setApprovalThreshold(e.target.value)}
                    placeholder="e.g. 10000"
                    data-testid="input-edit-threshold"
                  />
                </div>
              )}
              <div>
                <Label className="mb-2 block">Tier Conversion Limits</Label>
                <div className="space-y-3">
                  {USER_TIERS.map(tier => (
                    <div key={tier} className="flex items-center gap-2 flex-wrap">
                      <Badge variant="outline" className="w-24 justify-center text-xs">{tier}</Badge>
                      <div className="flex-1 min-w-[100px]">
                        <Input
                          type="number"
                          step="1"
                          min="0"
                          placeholder="Min"
                          value={tierLimits[tier]?.minAmount || ""}
                          onChange={(e) => updateTierLimit(tier, "minAmount", e.target.value)}
                          data-testid={`input-edit-tier-min-${tier}`}
                        />
                      </div>
                      <span className="text-muted-foreground text-sm">to</span>
                      <div className="flex-1 min-w-[100px]">
                        <Input
                          type="number"
                          step="1"
                          min="0"
                          placeholder="Max"
                          value={tierLimits[tier]?.maxAmount || ""}
                          onChange={(e) => updateTierLimit(tier, "maxAmount", e.target.value)}
                          data-testid={`input-edit-tier-max-${tier}`}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditConfig(null)}>Cancel</Button>
              <Button
                onClick={handleUpdate}
                disabled={updateMutation.isPending}
                data-testid="button-submit-update"
              >
                {updateMutation.isPending ? "Updating..." : "Update Config"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </RoleLayout>
  );
}
