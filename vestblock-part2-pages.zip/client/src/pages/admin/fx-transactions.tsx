import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { StatTile } from "@/components/stat-tile";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { WALLET_CURRENCIES, CURRENCY_DETAILS } from "@shared/constants";
import { formatCurrency, formatDate, formatRate } from "@/lib/format";
import { RefreshCcw, DollarSign, Hash, ArrowRightLeft, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
interface FxTransaction {
  id: string;
  userId: string;
  fromCurrency: string;
  toCurrency: string;
  amountFrom: string;
  amountTo: string;
  rate: string;
  fee: string;
  status: string;
  createdAt: string;
  user: { fullName: string; username: string; email: string } | null;
}

export default function AdminFxTransactions() {
  const [currencyFilter, setCurrencyFilter] = useState<string>("all");

  const { data: transactions, isLoading } = useQuery<FxTransaction[]>({
    queryKey: ["/api/admin/fx-transactions"],
  });

  const relevant = currencyFilter === "all"
    ? (transactions || [])
    : (transactions || []).filter(tx => tx.fromCurrency === currencyFilter || tx.toCurrency === currencyFilter);

  const completedTxs = relevant.filter(tx => tx.status === "COMPLETED");
  const totalVolume = completedTxs.reduce((sum, tx) => sum + (parseFloat(tx.amountFrom) || 0), 0);
  const totalFees = completedTxs.reduce((sum, tx) => sum + (parseFloat(tx.fee || "0") || 0), 0);
  const uniquePairs = new Set(completedTxs.map(tx => `${tx.fromCurrency}/${tx.toCurrency}`)).size;

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle title="FX Transactions" description="Foreign exchange conversion history" />
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <Select value={currencyFilter} onValueChange={setCurrencyFilter}>
            <SelectTrigger className="w-[160px]" data-testid="select-currency-filter">
              <SelectValue placeholder="All Currencies" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Currencies</SelectItem>
              {WALLET_CURRENCIES.map(cur => (
                <SelectItem key={cur} value={cur}>{CURRENCY_DETAILS[cur].symbol} {cur}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatTile
            label="Total Conversions"
            value={String(completedTxs.length)}
            icon={<Hash className="w-5 h-5" />}
          />
          <StatTile
            label="Volume"
            value={currencyFilter !== "all" ? formatCurrency(totalVolume, currencyFilter) : String(completedTxs.length)}
            icon={<DollarSign className="w-5 h-5" />}
          />
          <StatTile
            label="Fees Collected"
            value={currencyFilter !== "all" ? formatCurrency(totalFees, currencyFilter) : String(completedTxs.length)}
            icon={<RefreshCcw className="w-5 h-5" />}
          />
          <StatTile
            label="Currency Pairs"
            value={String(uniquePairs)}
            icon={<ArrowRightLeft className="w-5 h-5" />}
          />
        </div>

        <Section title="Transaction History">
          <GlassCard>
            {isLoading ? (
              <div className="space-y-3">
                {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
              </div>
            ) : relevant.length === 0 ? (
              <p className="text-muted-foreground text-center py-8" data-testid="text-no-fx-transactions">No FX transactions found</p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User</TableHead>
                      <TableHead>From</TableHead>
                      <TableHead>To</TableHead>
                      <TableHead>Rate</TableHead>
                      <TableHead>Fee</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {relevant.map((tx) => (
                      <TableRow key={tx.id} data-testid={`row-fx-tx-${tx.id}`}>
                        <TableCell className="font-medium">
                          {tx.user?.fullName || tx.user?.username || "Unknown"}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Badge variant="outline" className="text-xs">{tx.fromCurrency}</Badge>
                            <span className="text-sm">{formatCurrency(tx.amountFrom, tx.fromCurrency)}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Badge variant="outline" className="text-xs">{tx.toCurrency}</Badge>
                            <span className="text-sm">{formatCurrency(tx.amountTo, tx.toCurrency)}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-sm">{formatRate(tx.rate)}</TableCell>
                        <TableCell className="text-sm">{formatCurrency(tx.fee || "0", tx.fromCurrency)}</TableCell>
                        <TableCell className="text-sm">{formatDate(tx.createdAt)}</TableCell>
                        <TableCell>
                          <Badge
                            variant={tx.status === "COMPLETED" ? "default" : "secondary"}
                            className="text-xs"
                          >
                            {tx.status}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </GlassCard>
        </Section>
      </div>
    </RoleLayout>
  );
}
