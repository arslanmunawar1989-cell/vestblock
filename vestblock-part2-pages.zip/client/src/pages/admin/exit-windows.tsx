import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Clock, ArrowRightLeft, CalendarClock, RefreshCw, Settings2, Trash2, Play, Zap, ArrowLeft,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate } from "@/lib/format";
import { DataTable } from "@/components/data-table";
import { CURRENCY_DETAILS } from "@shared/constants";
import { Link } from "wouter";
interface ExitWindowData {
  id: string;
  assetId: string;
  name: string;
  opensAt: string;
  closesAt: string;
  status: string;
  exitFeePercent: string | null;
  quarter: string | null;
  lockupDays: number | null;
  cooldownHours: number | null;
  maxParticipants: number | null;
  minTradeAmount: string | null;
  maxTradeAmount: string | null;
  createdAt: string;
}

interface ScheduleData {
  id: string;
  assetId: string;
  frequency: string;
  windowDurationDays: number;
  exitFeePercent: string;
  lockupDays: number | null;
  cooldownHours: number | null;
  maxParticipants: number | null;
  minTradeAmount: string | null;
  maxTradeAmount: string | null;
  customIntervalDays: number | null;
  autoGenerate: boolean;
  isActive: boolean;
  createdAt: string;
}

interface AssetData {
  id: string;
  name: string;
  symbol: string;
  baseCurrency: string;
}

interface ListingData {
  id: string;
  sellerId: string;
  sellerName: string;
  quantity: string;
  pricePerToken: string;
  currency: string;
  remainingQuantity: string;
  status: string;
  createdAt: string;
}

function getStatusVariant(status: string) {
  switch (status) {
    case "open": return "default";
    case "scheduled": return "secondary";
    case "closed": return "outline";
    case "cancelled": return "outline";
    default: return "outline";
  }
}

function getFrequencyLabel(freq: string) {
  switch (freq) {
    case "quarterly": return "Quarterly";
    case "monthly": return "Monthly";
    case "semi_annual": return "Semi-Annual";
    case "annual": return "Annual";
    case "custom": return "Custom Interval";
    default: return freq;
  }
}

function getTimeRemaining(dateStr: string) {
  const target = new Date(dateStr);
  const now = new Date();
  const diff = target.getTime() - now.getTime();
  if (diff <= 0) return null;
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  if (days > 0) return `${days}d ${hours}h`;
  const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  return `${hours}h ${mins}m`;
}

export default function AdminExitWindows() {
  const { toast } = useToast();
  const [showCreate, setShowCreate] = useState(false);
  const [showScheduleCreate, setShowScheduleCreate] = useState(false);
  const [selectedWindow, setSelectedWindow] = useState<ExitWindowData | null>(null);
  const [form, setForm] = useState({
    assetId: "", name: "", opensAt: "", closesAt: "",
    exitFeePercent: "1.50", lockupDays: "0", cooldownHours: "0",
    maxParticipants: "", minTradeAmount: "", maxTradeAmount: "",
  });
  const [scheduleForm, setScheduleForm] = useState({
    assetId: "", frequency: "quarterly", windowDurationDays: "14",
    exitFeePercent: "1.50", lockupDays: "0", cooldownHours: "0",
    maxParticipants: "", minTradeAmount: "", maxTradeAmount: "",
    customIntervalDays: "30",
  });

  const { data: exitWindows, isLoading } = useQuery<ExitWindowData[]>({
    queryKey: ["/api/exit-windows"],
  });

  const { data: schedules, isLoading: schedulesLoading } = useQuery<ScheduleData[]>({
    queryKey: ["/api/exit-window-schedules"],
  });

  const { data: assets } = useQuery<AssetData[]>({
    queryKey: ["/api/assets"],
  });

  const { data: listings } = useQuery<ListingData[]>({
    queryKey: ["/api/exit-windows", selectedWindow?.id, "listings"],
    queryFn: async () => {
      if (!selectedWindow) return [];
      const res = await fetch(`/api/exit-windows/${selectedWindow.id}/listings`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
    enabled: !!selectedWindow,
  });

  const createMutation = useMutation({
    mutationFn: async (data: typeof form) => {
      const body: any = {
        assetId: data.assetId,
        name: data.name,
        opensAt: data.opensAt,
        closesAt: data.closesAt,
        exitFeePercent: parseFloat(data.exitFeePercent) || 1.5,
        lockupDays: parseInt(data.lockupDays) || 0,
        cooldownHours: parseInt(data.cooldownHours) || 0,
      };
      if (data.maxParticipants) body.maxParticipants = parseInt(data.maxParticipants);
      if (data.minTradeAmount) body.minTradeAmount = parseFloat(data.minTradeAmount);
      if (data.maxTradeAmount) body.maxTradeAmount = parseFloat(data.maxTradeAmount);
      const res = await apiRequest("POST", "/api/admin/exit-windows", body);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/exit-windows"] });
      setShowCreate(false);
      setForm({ assetId: "", name: "", opensAt: "", closesAt: "", exitFeePercent: "1.50", lockupDays: "0", cooldownHours: "0", maxParticipants: "", minTradeAmount: "", maxTradeAmount: "" });
      toast({ title: "Exit Window Created" });
    },
    onError: (err: any) => {
      toast({ title: "Failed", description: err.message, variant: "destructive" });
    },
  });

  const createScheduleMutation = useMutation({
    mutationFn: async (data: typeof scheduleForm) => {
      const body: any = {
        assetId: data.assetId,
        frequency: data.frequency,
        windowDurationDays: parseInt(data.windowDurationDays) || 14,
        exitFeePercent: parseFloat(data.exitFeePercent) || 1.5,
        lockupDays: parseInt(data.lockupDays) || 0,
        cooldownHours: parseInt(data.cooldownHours) || 0,
        autoGenerate: true,
      };
      if (data.maxParticipants) body.maxParticipants = parseInt(data.maxParticipants);
      if (data.minTradeAmount) body.minTradeAmount = parseFloat(data.minTradeAmount);
      if (data.maxTradeAmount) body.maxTradeAmount = parseFloat(data.maxTradeAmount);
      if (data.frequency === "custom") body.customIntervalDays = parseInt(data.customIntervalDays) || 30;
      const res = await apiRequest("POST", "/api/admin/exit-window-schedules", body);
      return res.json();
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/exit-window-schedules"] });
      queryClient.invalidateQueries({ queryKey: ["/api/exit-windows"] });
      setShowScheduleCreate(false);
      setScheduleForm({ assetId: "", frequency: "quarterly", windowDurationDays: "14", exitFeePercent: "1.50", lockupDays: "0", cooldownHours: "0", maxParticipants: "", minTradeAmount: "", maxTradeAmount: "", customIntervalDays: "30" });
      const count = data?.generatedWindows?.length || 0;
      toast({ title: "Schedule Created", description: count > 0 ? `Generated ${count} exit windows` : "Schedule saved" });
    },
    onError: (err: any) => {
      toast({ title: "Failed", description: err.message, variant: "destructive" });
    },
  });

  const statusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const res = await apiRequest("PATCH", `/api/admin/exit-windows/${id}/status`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/exit-windows"] });
      toast({ title: "Status Updated" });
    },
    onError: (err: any) => {
      toast({ title: "Failed", description: err.message, variant: "destructive" });
    },
  });

  const syncMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/admin/exit-windows/sync", {});
      return res.json();
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/exit-windows"] });
      toast({ title: "Synced", description: `Opened: ${data.opened || 0}, Closed: ${data.closed || 0}` });
    },
    onError: (err: any) => {
      toast({ title: "Sync Failed", description: err.message, variant: "destructive" });
    },
  });

  const generateFromScheduleMutation = useMutation({
    mutationFn: async (scheduleId: string) => {
      const res = await apiRequest("POST", `/api/admin/exit-window-schedules/${scheduleId}/generate`, {});
      return res.json();
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/exit-windows"] });
      toast({ title: "Windows Generated", description: data.message });
    },
    onError: (err: any) => {
      toast({ title: "Failed", description: err.message, variant: "destructive" });
    },
  });

  const toggleScheduleMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: string; isActive: boolean }) => {
      const res = await apiRequest("PATCH", `/api/admin/exit-window-schedules/${id}`, { isActive });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/exit-window-schedules"] });
      toast({ title: "Schedule Updated" });
    },
    onError: (err: any) => {
      toast({ title: "Failed", description: err.message, variant: "destructive" });
    },
  });

  const deleteScheduleMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("DELETE", `/api/admin/exit-window-schedules/${id}`, undefined);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/exit-window-schedules"] });
      toast({ title: "Schedule Deleted" });
    },
    onError: (err: any) => {
      toast({ title: "Failed", description: err.message, variant: "destructive" });
    },
  });

  const assetMap: Record<string, AssetData> = {};
  if (assets) for (const a of assets) assetMap[a.id] = a;

  const openWindows = (exitWindows || []).filter(w => w.status === "open");
  const scheduledWindows = (exitWindows || []).filter(w => w.status === "scheduled");
  const closedWindows = (exitWindows || []).filter(w => w.status === "closed" || w.status === "cancelled");

  const windowColumns = [
    {
      header: "Name",
      accessor: "name" as const,
      cell: (row: ExitWindowData) => (
        <button className="text-left font-medium text-sm hover:underline" onClick={() => setSelectedWindow(row)} data-testid={`link-window-${row.id}`}>
          {row.name}
        </button>
      ),
    },
    {
      header: "Asset",
      accessor: "assetId" as const,
      cell: (row: ExitWindowData) => {
        const asset = assetMap[row.assetId];
        return <span className="text-sm">{asset ? `${asset.symbol}` : row.assetId.slice(0, 8)}</span>;
      },
    },
    {
      header: "Opens",
      accessor: "opensAt" as const,
      cell: (row: ExitWindowData) => <span className="text-sm">{formatDate(row.opensAt, "short")}</span>,
    },
    {
      header: "Closes",
      accessor: "closesAt" as const,
      cell: (row: ExitWindowData) => {
        const remaining = row.status === "open" ? getTimeRemaining(row.closesAt) : null;
        return (
          <div>
            <span className="text-sm">{formatDate(row.closesAt, "short")}</span>
            {remaining && <span className="text-xs text-muted-foreground ml-1">({remaining})</span>}
          </div>
        );
      },
    },
    {
      header: "Fee",
      accessor: "exitFeePercent" as const,
      cell: (row: ExitWindowData) => <span className="text-sm">{row.exitFeePercent ? `${parseFloat(row.exitFeePercent).toFixed(2)}%` : "N/A"}</span>,
    },
    {
      header: "Status",
      accessor: "status" as const,
      cell: (row: ExitWindowData) => (
        <Badge variant={getStatusVariant(row.status)} data-testid={`badge-status-${row.id}`}>
          {row.status.charAt(0).toUpperCase() + row.status.slice(1)}
        </Badge>
      ),
    },
    {
      header: "Actions",
      accessor: "id" as const,
      cell: (row: ExitWindowData) => (
        <div className="flex gap-1 flex-wrap">
          {row.status === "scheduled" && (
            <Button size="sm" variant="outline" onClick={() => statusMutation.mutate({ id: row.id, status: "open" })} data-testid={`button-open-${row.id}`}>
              Open
            </Button>
          )}
          {row.status === "open" && (
            <Button size="sm" variant="outline" onClick={() => statusMutation.mutate({ id: row.id, status: "closed" })} data-testid={`button-close-${row.id}`}>
              Close
            </Button>
          )}
          {(row.status === "scheduled" || row.status === "open") && (
            <Button size="sm" variant="outline" onClick={() => statusMutation.mutate({ id: row.id, status: "cancelled" })} data-testid={`button-cancel-${row.id}`}>
              Cancel
            </Button>
          )}
        </div>
      ),
    },
  ];

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <Link href="/admin/dashboard">
              <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <PageTitle title="Exit Windows" description="Configure and manage secondary market trading windows" />
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button variant="outline" onClick={() => syncMutation.mutate()} disabled={syncMutation.isPending} data-testid="button-sync-statuses">
              <RefreshCw className={`w-4 h-4 mr-1 ${syncMutation.isPending ? "animate-spin" : ""}`} />
              Sync Statuses
            </Button>
            <Button variant="outline" onClick={() => setShowScheduleCreate(true)} data-testid="button-create-schedule">
              <CalendarClock className="w-4 h-4 mr-1" />
              New Schedule
            </Button>
            <Button onClick={() => setShowCreate(true)} data-testid="button-create-exit-window">
              <Plus className="w-4 h-4 mr-1" />
              Create Window
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-md bg-emerald-500/10">
                  <Play className="w-4 h-4 text-emerald-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold" data-testid="stat-open-windows">{openWindows.length}</p>
                  <p className="text-xs text-muted-foreground">Open Windows</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-md bg-blue-500/10">
                  <Clock className="w-4 h-4 text-blue-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold" data-testid="stat-scheduled-windows">{scheduledWindows.length}</p>
                  <p className="text-xs text-muted-foreground">Scheduled</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-md bg-amber-500/10">
                  <CalendarClock className="w-4 h-4 text-amber-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold" data-testid="stat-active-schedules">{(schedules || []).filter(s => s.isActive).length}</p>
                  <p className="text-xs text-muted-foreground">Active Schedules</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="windows">
          <TabsList>
            <TabsTrigger value="windows" data-testid="tab-windows">Exit Windows</TabsTrigger>
            <TabsTrigger value="schedules" data-testid="tab-schedules">Schedules</TabsTrigger>
          </TabsList>

          <TabsContent value="windows" className="mt-4">
            {isLoading ? (
              <Skeleton className="h-40 rounded-md" />
            ) : (
              <DataTable columns={windowColumns} data={exitWindows || []} data-testid="table-exit-windows" />
            )}
          </TabsContent>

          <TabsContent value="schedules" className="mt-4 space-y-4">
            {schedulesLoading ? (
              <Skeleton className="h-40 rounded-md" />
            ) : (schedules || []).length === 0 ? (
              <Card>
                <CardContent className="p-6 text-center">
                  <CalendarClock className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground">No schedules configured. Create a schedule to auto-generate exit windows at regular intervals.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {(schedules || []).map((s) => {
                  const asset = assetMap[s.assetId];
                  return (
                    <Card key={s.id} data-testid={`schedule-card-${s.id}`}>
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between gap-2 flex-wrap">
                          <CardTitle className="text-base flex items-center gap-2">
                            <Settings2 className="w-4 h-4" />
                            {asset ? `${asset.name} (${asset.symbol})` : s.assetId.slice(0, 8)}
                          </CardTitle>
                          <Badge variant={s.isActive ? "default" : "outline"} data-testid={`badge-schedule-status-${s.id}`}>
                            {s.isActive ? "Active" : "Paused"}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>
                            <p className="text-muted-foreground text-xs">Frequency</p>
                            <p className="font-medium" data-testid={`text-frequency-${s.id}`}>{getFrequencyLabel(s.frequency)}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground text-xs">Window Duration</p>
                            <p className="font-medium">{s.windowDurationDays} days</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground text-xs">Exit Fee</p>
                            <p className="font-medium">{parseFloat(s.exitFeePercent).toFixed(2)}%</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground text-xs">Lockup</p>
                            <p className="font-medium">{s.lockupDays || 0} days</p>
                          </div>
                          {s.frequency === "custom" && s.customIntervalDays && (
                            <div>
                              <p className="text-muted-foreground text-xs">Interval</p>
                              <p className="font-medium">Every {s.customIntervalDays} days</p>
                            </div>
                          )}
                        </div>
                        <div className="flex gap-2 pt-1 flex-wrap">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => toggleScheduleMutation.mutate({ id: s.id, isActive: !s.isActive })}
                            data-testid={`button-toggle-schedule-${s.id}`}
                          >
                            {s.isActive ? "Pause" : "Activate"}
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => generateFromScheduleMutation.mutate(s.id)}
                            disabled={generateFromScheduleMutation.isPending}
                            data-testid={`button-generate-${s.id}`}
                          >
                            <Zap className="w-3 h-3 mr-1" />
                            Generate
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => deleteScheduleMutation.mutate(s.id)}
                            disabled={deleteScheduleMutation.isPending}
                            data-testid={`button-delete-schedule-${s.id}`}
                          >
                            <Trash2 className="w-3 h-3 mr-1" />
                            Delete
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent data-testid="create-window-modal">
          <DialogHeader>
            <DialogTitle>Create Exit Window</DialogTitle>
            <DialogDescription>Define a one-off trading window for an asset's secondary market</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 max-h-[60vh] overflow-y-auto">
            <div className="space-y-2">
              <Label>Asset</Label>
              <Select value={form.assetId} onValueChange={(v) => setForm({ ...form, assetId: v })}>
                <SelectTrigger data-testid="select-asset">
                  <SelectValue placeholder="Select asset" />
                </SelectTrigger>
                <SelectContent>
                  {(assets || []).map(a => (
                    <SelectItem key={a.id} value={a.id}>{a.name} ({a.baseCurrency})</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Window Name</Label>
              <Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g., Q1 2026 Exit Window" data-testid="input-window-name" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Opens At</Label>
                <Input type="datetime-local" value={form.opensAt} onChange={e => setForm({ ...form, opensAt: e.target.value })} data-testid="input-opens-at" />
              </div>
              <div className="space-y-2">
                <Label>Closes At</Label>
                <Input type="datetime-local" value={form.closesAt} onChange={e => setForm({ ...form, closesAt: e.target.value })} data-testid="input-closes-at" />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Exit Fee %</Label>
                <Input type="number" step="0.01" value={form.exitFeePercent} onChange={e => setForm({ ...form, exitFeePercent: e.target.value })} data-testid="input-exit-fee" />
              </div>
              <div className="space-y-2">
                <Label>Lockup Days</Label>
                <Input type="number" value={form.lockupDays} onChange={e => setForm({ ...form, lockupDays: e.target.value })} data-testid="input-lockup-days" />
              </div>
              <div className="space-y-2">
                <Label>Cooldown Hours</Label>
                <Input type="number" value={form.cooldownHours} onChange={e => setForm({ ...form, cooldownHours: e.target.value })} data-testid="input-cooldown" />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Max Participants</Label>
                <Input type="number" placeholder="Unlimited" value={form.maxParticipants} onChange={e => setForm({ ...form, maxParticipants: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Min Trade</Label>
                <Input type="number" placeholder="No minimum" value={form.minTradeAmount} onChange={e => setForm({ ...form, minTradeAmount: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Max Trade</Label>
                <Input type="number" placeholder="No maximum" value={form.maxTradeAmount} onChange={e => setForm({ ...form, maxTradeAmount: e.target.value })} />
              </div>
            </div>
            <div className="flex gap-2 pt-2">
              <Button variant="outline" className="flex-1" onClick={() => setShowCreate(false)} data-testid="button-cancel-create">Cancel</Button>
              <Button
                className="flex-1"
                disabled={!form.assetId || !form.name || !form.opensAt || !form.closesAt || createMutation.isPending}
                onClick={() => createMutation.mutate(form)}
                data-testid="button-submit-create"
              >
                {createMutation.isPending ? "Creating..." : "Create Window"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showScheduleCreate} onOpenChange={setShowScheduleCreate}>
        <DialogContent data-testid="create-schedule-modal">
          <DialogHeader>
            <DialogTitle>Create Exit Window Schedule</DialogTitle>
            <DialogDescription>Set up recurring exit windows that auto-generate at defined intervals</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 max-h-[60vh] overflow-y-auto">
            <div className="space-y-2">
              <Label>Asset</Label>
              <Select value={scheduleForm.assetId} onValueChange={(v) => setScheduleForm({ ...scheduleForm, assetId: v })}>
                <SelectTrigger data-testid="select-schedule-asset">
                  <SelectValue placeholder="Select asset" />
                </SelectTrigger>
                <SelectContent>
                  {(assets || []).map(a => (
                    <SelectItem key={a.id} value={a.id}>{a.name} ({a.baseCurrency})</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Frequency</Label>
                <Select value={scheduleForm.frequency} onValueChange={(v) => setScheduleForm({ ...scheduleForm, frequency: v })}>
                  <SelectTrigger data-testid="select-frequency">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="quarterly">Quarterly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="semi_annual">Semi-Annual</SelectItem>
                    <SelectItem value="annual">Annual</SelectItem>
                    <SelectItem value="custom">Custom Interval</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Window Duration (days)</Label>
                <Input type="number" min="1" max="90" value={scheduleForm.windowDurationDays} onChange={e => setScheduleForm({ ...scheduleForm, windowDurationDays: e.target.value })} data-testid="input-schedule-duration" />
              </div>
            </div>
            {scheduleForm.frequency === "custom" && (
              <div className="space-y-2">
                <Label>Custom Interval (days between windows)</Label>
                <Input type="number" min="1" value={scheduleForm.customIntervalDays} onChange={e => setScheduleForm({ ...scheduleForm, customIntervalDays: e.target.value })} data-testid="input-custom-interval" />
              </div>
            )}
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Exit Fee %</Label>
                <Input type="number" step="0.01" value={scheduleForm.exitFeePercent} onChange={e => setScheduleForm({ ...scheduleForm, exitFeePercent: e.target.value })} data-testid="input-schedule-fee" />
              </div>
              <div className="space-y-2">
                <Label>Lockup Days</Label>
                <Input type="number" value={scheduleForm.lockupDays} onChange={e => setScheduleForm({ ...scheduleForm, lockupDays: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Cooldown Hours</Label>
                <Input type="number" value={scheduleForm.cooldownHours} onChange={e => setScheduleForm({ ...scheduleForm, cooldownHours: e.target.value })} />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Max Participants</Label>
                <Input type="number" placeholder="Unlimited" value={scheduleForm.maxParticipants} onChange={e => setScheduleForm({ ...scheduleForm, maxParticipants: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Min Trade</Label>
                <Input type="number" placeholder="No minimum" value={scheduleForm.minTradeAmount} onChange={e => setScheduleForm({ ...scheduleForm, minTradeAmount: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Max Trade</Label>
                <Input type="number" placeholder="No maximum" value={scheduleForm.maxTradeAmount} onChange={e => setScheduleForm({ ...scheduleForm, maxTradeAmount: e.target.value })} />
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              Windows will be auto-generated for the current and next year. The system automatically opens and closes windows based on their scheduled times (checked every 5 minutes).
            </p>
            <div className="flex gap-2 pt-2">
              <Button variant="outline" className="flex-1" onClick={() => setShowScheduleCreate(false)} data-testid="button-cancel-schedule">Cancel</Button>
              <Button
                className="flex-1"
                disabled={!scheduleForm.assetId || createScheduleMutation.isPending}
                onClick={() => createScheduleMutation.mutate(scheduleForm)}
                data-testid="button-submit-schedule"
              >
                {createScheduleMutation.isPending ? "Creating..." : "Create Schedule & Generate Windows"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={!!selectedWindow} onOpenChange={(open) => { if (!open) setSelectedWindow(null); }}>
        <DialogContent className="sm:max-w-lg" data-testid="window-details-modal">
          <DialogHeader>
            <DialogTitle>{selectedWindow?.name}</DialogTitle>
            <DialogDescription>
              {selectedWindow && assetMap[selectedWindow.assetId] ? `${assetMap[selectedWindow.assetId].name} — ${assetMap[selectedWindow.assetId].baseCurrency}` : ""}
            </DialogDescription>
          </DialogHeader>
          {selectedWindow && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-muted-foreground text-xs">Status</p>
                  <Badge variant={getStatusVariant(selectedWindow.status)}>{selectedWindow.status}</Badge>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs">Exit Fee</p>
                  <p className="font-medium">{selectedWindow.exitFeePercent ? `${parseFloat(selectedWindow.exitFeePercent).toFixed(2)}%` : "N/A"}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs">Opens</p>
                  <p className="font-medium">{formatDate(selectedWindow.opensAt, "short")}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs">Closes</p>
                  <p className="font-medium">{formatDate(selectedWindow.closesAt, "short")}</p>
                  {selectedWindow.status === "open" && getTimeRemaining(selectedWindow.closesAt) && (
                    <p className="text-xs text-amber-600">{getTimeRemaining(selectedWindow.closesAt)} remaining</p>
                  )}
                </div>
                {selectedWindow.lockupDays != null && selectedWindow.lockupDays > 0 && (
                  <div>
                    <p className="text-muted-foreground text-xs">Lockup</p>
                    <p className="font-medium">{selectedWindow.lockupDays} days</p>
                  </div>
                )}
                {selectedWindow.cooldownHours != null && selectedWindow.cooldownHours > 0 && (
                  <div>
                    <p className="text-muted-foreground text-xs">Cooldown</p>
                    <p className="font-medium">{selectedWindow.cooldownHours} hours</p>
                  </div>
                )}
              </div>

              <div className="border-t pt-3">
                <p className="text-sm font-medium mb-2">Listings ({listings?.length || 0})</p>
                {(listings || []).length === 0 ? (
                  <p className="text-sm text-muted-foreground">No listings yet.</p>
                ) : (
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {(listings || []).map(l => {
                      const cd = CURRENCY_DETAILS[l.currency as keyof typeof CURRENCY_DETAILS];
                      const sym = cd?.symbol || l.currency;
                      return (
                        <Card key={l.id} className="p-3">
                          <div className="flex items-center justify-between gap-2 flex-wrap">
                            <div>
                              <p className="text-sm font-medium">{l.sellerName}</p>
                              <p className="text-xs text-muted-foreground">
                                {parseFloat(l.remainingQuantity).toFixed(0)}/{parseFloat(l.quantity).toFixed(0)} tokens at {sym} {parseFloat(l.pricePerToken).toFixed(2)}
                              </p>
                            </div>
                            <Badge variant={l.status === "active" ? "default" : "outline"}>
                              {l.status}
                            </Badge>
                          </div>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </RoleLayout>
  );
}
