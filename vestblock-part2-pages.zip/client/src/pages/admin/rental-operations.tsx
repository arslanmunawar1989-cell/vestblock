import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate } from "@/lib/format";
import { SUPPORTED_CURRENCIES } from "@/lib/currencies";
import type { RentCollection, OperatingExpense, RENTAL_EXPENSE_CATEGORIES } from "@shared/schema";
import {
  Building2,
  Calendar,
  DollarSign,
  TrendingUp,
  TrendingDown,
  PlusCircle,
  ArrowLeft,
  Home,
  Wrench,
  Shield,
  Landmark,
  Zap,
  Receipt,
  Users,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  BarChart3,
} from "lucide-react";

function formatCurrency(amount: string | number, currency: string): string {
  const num = typeof amount === "string" ? parseFloat(amount) : amount;
  if (isNaN(num)) return `${currency} 0.00`;
  return `${currency} ${num.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

const EXPENSE_CATEGORY_LABELS: Record<string, { label: string; icon: typeof Wrench }> = {
  maintenance: { label: "Maintenance", icon: Wrench },
  management_fee: { label: "Management Fee", icon: Users },
  insurance: { label: "Insurance", icon: Shield },
  property_tax: { label: "Property Tax", icon: Landmark },
  utility_reserve: { label: "Utility Reserve", icon: Zap },
  vacancy_adjustment: { label: "Vacancy Adjustment", icon: Home },
  late_payment: { label: "Late Payment", icon: AlertTriangle },
  other: { label: "Other", icon: Receipt },
};

interface PropertySummary {
  assetId: string;
  assetName: string;
  location: string | null;
  propertyType: string | null;
  baseCurrency: string;
  totalPeriods: number;
  totalGrossRent: string;
  totalExpenses: string;
  netOperatingIncome: string;
  latestPeriod: string | null;
}

interface MonthlyCycle {
  period: string;
  rentCollection: {
    grossRent: string;
    occupancyRate: string;
    vacancyAdjustment: string;
    latePaymentPenalty: string;
    effectiveRent: string;
    entries: RentCollection[];
  };
  operatingExpenses: {
    maintenance: string;
    managementFee: string;
    insurance: string;
    propertyTax: string;
    utilityReserve: string;
    otherExpenses: string;
    totalExpenses: string;
    entries: OperatingExpense[];
  };
  netOperatingIncome: string;
}

interface RentalOperationsDetail {
  assetId: string;
  assetName: string;
  baseCurrency: string;
  currency: string;
  summary: {
    totalPeriods: number;
    totalGrossRent: string;
    totalEffectiveRent: string;
    totalExpenses: string;
    totalNetOperatingIncome: string;
    avgOccupancyRate: string;
  };
  monthlyCycles: MonthlyCycle[];
}

export default function RentalOperationsPage() {
  const [selectedAssetId, setSelectedAssetId] = useState<string | null>(null);

  if (selectedAssetId) {
    return <PropertyRentalDetail assetId={selectedAssetId} onBack={() => setSelectedAssetId(null)} />;
  }

  return <PropertyRentalList onSelect={setSelectedAssetId} />;
}

function PropertyRentalList({ onSelect }: { onSelect: (id: string) => void }) {
  const { data: summaries, isLoading } = useQuery<PropertySummary[]>({
    queryKey: ["/api/admin/rental-operations"],
  });

  return (
    <RoleLayout role="admin">
      <PageTitle title="Rental Operations" description="Monthly rental cycle management for all properties" />
      <Section>
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-24 w-full" />)}
          </div>
        ) : !summaries || summaries.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Building2 className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground">No properties found. Create assets with property types to manage rental operations.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-3">
            {summaries.map(s => (
              <Card key={s.assetId} className="hover-elevate cursor-pointer" onClick={() => onSelect(s.assetId)} data-testid={`property-card-${s.assetId}`}>
                <CardContent className="py-4">
                  <div className="flex items-center justify-between gap-3 flex-wrap">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Building2 className="w-5 h-5 text-primary" />
                      </div>
                      <div className="min-w-0">
                        <h3 className="font-semibold truncate" data-testid={`text-property-name-${s.assetId}`}>{s.assetName}</h3>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground flex-wrap">
                          {s.location && <span>{s.location}</span>}
                          {s.propertyType && <Badge variant="outline" className="no-default-hover-elevate text-[10px]">{s.propertyType}</Badge>}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 flex-wrap">
                      <div className="text-right">
                        <p className="text-xs text-muted-foreground">Gross Rent</p>
                        <p className="text-sm font-semibold" data-testid={`text-gross-rent-${s.assetId}`}>{formatCurrency(s.totalGrossRent, s.baseCurrency)}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-muted-foreground">Expenses</p>
                        <p className="text-sm font-semibold" data-testid={`text-expenses-${s.assetId}`}>{formatCurrency(s.totalExpenses, s.baseCurrency)}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-muted-foreground">NOI</p>
                        <p className={`text-sm font-bold ${parseFloat(s.netOperatingIncome) >= 0 ? "text-green-600" : "text-red-600"}`} data-testid={`text-noi-${s.assetId}`}>
                          {formatCurrency(s.netOperatingIncome, s.baseCurrency)}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-muted-foreground">Periods</p>
                        <p className="text-sm font-medium">{s.totalPeriods}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </Section>
    </RoleLayout>
  );
}

function PropertyRentalDetail({ assetId, onBack }: { assetId: string; onBack: () => void }) {
  const [showRentDialog, setShowRentDialog] = useState(false);
  const [showExpenseDialog, setShowExpenseDialog] = useState(false);
  const { toast } = useToast();

  const { data, isLoading } = useQuery<RentalOperationsDetail>({
    queryKey: ["/api/admin/rental-operations", assetId],
  });

  return (
    <RoleLayout role="admin">
      <div className="flex items-center gap-2 mb-4 flex-wrap">
        <Button variant="ghost" size="sm" onClick={onBack} data-testid="button-back">
          <ArrowLeft className="w-4 h-4 mr-1" />
          Back
        </Button>
        <PageTitle title={data?.assetName || "Property"} description="Monthly rental cycle management" />
      </div>

      {isLoading ? (
        <div className="space-y-3">
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      ) : !data ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">Property data not found</CardContent>
        </Card>
      ) : (
        <>
          <Section>
            <div className="flex items-center justify-between gap-2 mb-4 flex-wrap">
              <h3 className="font-semibold flex items-center gap-1.5">
                <BarChart3 className="w-4 h-4" />
                Summary
              </h3>
              <div className="flex gap-2 flex-wrap">
                <Button size="sm" onClick={() => setShowRentDialog(true)} data-testid="button-add-rent">
                  <PlusCircle className="w-4 h-4 mr-1" />
                  Record Rent
                </Button>
                <Button size="sm" variant="outline" onClick={() => setShowExpenseDialog(true)} data-testid="button-add-expense">
                  <PlusCircle className="w-4 h-4 mr-1" />
                  Add Expense
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
              <SummaryCard label="Total Periods" value={String(data.summary.totalPeriods)} icon={Calendar} />
              <SummaryCard label="Gross Rent" value={formatCurrency(data.summary.totalGrossRent, data.currency)} icon={DollarSign} />
              <SummaryCard label="Effective Rent" value={formatCurrency(data.summary.totalEffectiveRent, data.currency)} icon={TrendingUp} />
              <SummaryCard label="Total Expenses" value={formatCurrency(data.summary.totalExpenses, data.currency)} icon={TrendingDown} />
              <SummaryCard label="Net Operating Income" value={formatCurrency(data.summary.totalNetOperatingIncome, data.currency)} icon={DollarSign} positive={parseFloat(data.summary.totalNetOperatingIncome) >= 0} />
              <SummaryCard label="Avg Occupancy" value={`${data.summary.avgOccupancyRate}%`} icon={Home} />
            </div>
          </Section>

          <Section>
            <h3 className="font-semibold flex items-center gap-1.5 mb-4">
              <Calendar className="w-4 h-4" />
              Monthly Cycles
            </h3>

            {data.monthlyCycles.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center text-muted-foreground">
                  <Calendar className="w-10 h-10 mx-auto mb-2 opacity-50" />
                  <p>No rental data recorded yet. Use the buttons above to record rent collections and expenses.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {data.monthlyCycles.map(cycle => (
                  <MonthlyCycleCard key={cycle.period} cycle={cycle} currency={data.currency} />
                ))}
              </div>
            )}
          </Section>
        </>
      )}

      {showRentDialog && (
        <RentCollectionDialog
          assetId={assetId}
          onClose={() => setShowRentDialog(false)}
        />
      )}
      {showExpenseDialog && (
        <ExpenseDialog
          assetId={assetId}
          onClose={() => setShowExpenseDialog(false)}
        />
      )}
    </RoleLayout>
  );
}

function SummaryCard({ label, value, icon: Icon, positive }: { label: string; value: string; icon: typeof DollarSign; positive?: boolean }) {
  return (
    <Card>
      <CardContent className="py-3">
        <div className="flex items-center gap-2 mb-1">
          <Icon className="w-3.5 h-3.5 text-muted-foreground" />
          <p className="text-xs text-muted-foreground">{label}</p>
        </div>
        <p className={`text-sm font-bold ${positive === true ? "text-green-600" : positive === false ? "text-red-600" : ""}`} data-testid={`text-summary-${label.toLowerCase().replace(/\s+/g, "-")}`}>
          {value}
        </p>
      </CardContent>
    </Card>
  );
}

function MonthlyCycleCard({ cycle, currency }: { cycle: MonthlyCycle; currency: string }) {
  const [expanded, setExpanded] = useState(false);
  const noiPositive = parseFloat(cycle.netOperatingIncome) >= 0;

  return (
    <Card data-testid={`cycle-card-${cycle.period}`}>
      <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2 cursor-pointer" onClick={() => setExpanded(!expanded)}>
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-muted-foreground" />
          <CardTitle className="text-base" data-testid={`text-period-${cycle.period}`}>{cycle.period}</CardTitle>
          <Badge variant={noiPositive ? "default" : "destructive"} className="no-default-hover-elevate">
            NOI: {formatCurrency(cycle.netOperatingIncome, currency)}
          </Badge>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <div className="text-right">
            <p className="text-xs text-muted-foreground">Occupancy</p>
            <p className="text-sm font-semibold">{cycle.rentCollection.occupancyRate}%</p>
          </div>
          <Button variant="ghost" size="icon" data-testid={`button-expand-${cycle.period}`}>
            {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </Button>
        </div>
      </CardHeader>

      {!expanded && (
        <CardContent className="pt-0 pb-3">
          <div className="grid grid-cols-3 gap-3">
            <div>
              <p className="text-xs text-muted-foreground">Gross Rent</p>
              <p className="text-sm font-semibold">{formatCurrency(cycle.rentCollection.grossRent, currency)}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Total Expenses</p>
              <p className="text-sm font-semibold">{formatCurrency(cycle.operatingExpenses.totalExpenses, currency)}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Effective Rent</p>
              <p className="text-sm font-semibold">{formatCurrency(cycle.rentCollection.effectiveRent, currency)}</p>
            </div>
          </div>
        </CardContent>
      )}

      {expanded && (
        <CardContent className="pt-0 space-y-4">
          <div className="border-t pt-3">
            <h4 className="text-sm font-semibold flex items-center gap-1.5 mb-3">
              <DollarSign className="w-4 h-4" />
              Rent Collection
            </h4>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              <LineItem label="Gross Rent" value={formatCurrency(cycle.rentCollection.grossRent, currency)} testId={`rent-gross-${cycle.period}`} />
              <LineItem label="Occupancy Rate" value={`${cycle.rentCollection.occupancyRate}%`} testId={`rent-occupancy-${cycle.period}`} />
              <LineItem label="Vacancy Adjustment" value={formatCurrency(cycle.rentCollection.vacancyAdjustment, currency)} negative testId={`rent-vacancy-${cycle.period}`} />
              <LineItem label="Late Payment Penalty" value={formatCurrency(cycle.rentCollection.latePaymentPenalty, currency)} positive testId={`rent-late-${cycle.period}`} />
              <LineItem label="Effective Rent" value={formatCurrency(cycle.rentCollection.effectiveRent, currency)} bold testId={`rent-effective-${cycle.period}`} />
            </div>

            {cycle.rentCollection.entries.length > 0 && (
              <div className="mt-2 space-y-1">
                {cycle.rentCollection.entries.map(entry => (
                  <div key={entry.id} className="flex items-center justify-between text-xs p-1.5 rounded-md bg-muted/40 gap-2 flex-wrap" data-testid={`rent-entry-${entry.id}`}>
                    <span className="font-medium">{formatCurrency(entry.grossRent, entry.currency)}</span>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <span>Occ: {entry.occupancyRate || "100"}%</span>
                      <span>{entry.receivedDate}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="border-t pt-3">
            <h4 className="text-sm font-semibold flex items-center gap-1.5 mb-3">
              <Receipt className="w-4 h-4" />
              Operating Expenses
            </h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <ExpenseLineItem label="Maintenance" value={cycle.operatingExpenses.maintenance} currency={currency} icon={Wrench} testId={`exp-maintenance-${cycle.period}`} />
              <ExpenseLineItem label="Management Fee" value={cycle.operatingExpenses.managementFee} currency={currency} icon={Users} testId={`exp-mgmt-${cycle.period}`} />
              <ExpenseLineItem label="Insurance" value={cycle.operatingExpenses.insurance} currency={currency} icon={Shield} testId={`exp-insurance-${cycle.period}`} />
              <ExpenseLineItem label="Property Tax" value={cycle.operatingExpenses.propertyTax} currency={currency} icon={Landmark} testId={`exp-tax-${cycle.period}`} />
              <ExpenseLineItem label="Utility Reserve" value={cycle.operatingExpenses.utilityReserve} currency={currency} icon={Zap} testId={`exp-utility-${cycle.period}`} />
              <ExpenseLineItem label="Other" value={cycle.operatingExpenses.otherExpenses} currency={currency} icon={Receipt} testId={`exp-other-${cycle.period}`} />
              <div className="col-span-2 md:col-span-2">
                <div className="p-2 rounded-md bg-muted/60">
                  <p className="text-xs text-muted-foreground">Total Expenses</p>
                  <p className="text-sm font-bold" data-testid={`exp-total-${cycle.period}`}>{formatCurrency(cycle.operatingExpenses.totalExpenses, currency)}</p>
                </div>
              </div>
            </div>

            {cycle.operatingExpenses.entries.length > 0 && (
              <div className="mt-2 space-y-1">
                {cycle.operatingExpenses.entries.map(entry => (
                  <div key={entry.id} className="flex items-center justify-between text-xs p-1.5 rounded-md bg-muted/40 gap-2 flex-wrap" data-testid={`expense-entry-${entry.id}`}>
                    <div className="flex items-center gap-1.5">
                      <Badge variant="outline" className="no-default-hover-elevate text-[10px]">
                        {EXPENSE_CATEGORY_LABELS[entry.category]?.label || entry.category}
                      </Badge>
                      {entry.description && <span className="text-muted-foreground">{entry.description}</span>}
                    </div>
                    <span className="font-medium">{formatCurrency(entry.amount, entry.currency)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="border-t pt-3">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <h4 className="text-sm font-semibold flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4" />
                Net Operating Income
              </h4>
              <p className={`text-lg font-bold ${noiPositive ? "text-green-600" : "text-red-600"}`} data-testid={`noi-${cycle.period}`}>
                {formatCurrency(cycle.netOperatingIncome, currency)}
              </p>
            </div>
          </div>
        </CardContent>
      )}
    </Card>
  );
}

function LineItem({ label, value, positive, negative, bold, testId }: {
  label: string; value: string; positive?: boolean; negative?: boolean; bold?: boolean; testId: string;
}) {
  return (
    <div>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className={`text-sm ${bold ? "font-bold" : "font-medium"} ${positive ? "text-green-600" : negative ? "text-red-600" : ""}`} data-testid={testId}>
        {negative && parseFloat(value.replace(/[^0-9.-]/g, "")) > 0 ? `- ${value}` : value}
      </p>
    </div>
  );
}

function ExpenseLineItem({ label, value, currency, icon: Icon, testId }: {
  label: string; value: string; currency: string; icon: typeof Wrench; testId: string;
}) {
  const numVal = parseFloat(value);
  return (
    <div className="flex items-start gap-2">
      <Icon className="w-3.5 h-3.5 mt-0.5 text-muted-foreground flex-shrink-0" />
      <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className={`text-sm font-medium ${numVal > 0 ? "" : "text-muted-foreground"}`} data-testid={testId}>
          {formatCurrency(value, currency)}
        </p>
      </div>
    </div>
  );
}

function RentCollectionDialog({ assetId, onClose }: { assetId: string; onClose: () => void }) {
  const { toast } = useToast();
  const [form, setForm] = useState({
    period: new Date().toISOString().slice(0, 7),
    grossRent: "",
    occupancyRate: "100",
    vacancyAdjustment: "0",
    latePaymentPenalty: "0",
    currency: "AED",
    receivedDate: new Date().toISOString().slice(0, 10),
    notes: "",
  });

  const mutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/finance/rent-collections", {
        assetId,
        period: form.period,
        grossRent: form.grossRent,
        occupancyRate: form.occupancyRate,
        vacancyAdjustment: form.vacancyAdjustment,
        latePaymentPenalty: form.latePaymentPenalty,
        currency: form.currency,
        receivedDate: form.receivedDate,
        notes: form.notes || undefined,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/rental-operations", assetId] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/rental-operations"] });
      toast({ title: "Rent collection recorded successfully" });
      onClose();
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const updateField = (field: string, value: string) => setForm(prev => ({ ...prev, [field]: value }));

  return (
    <Dialog open onOpenChange={() => onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Record Rent Collection</DialogTitle>
          <DialogDescription>Record monthly rent received for this property</DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Period (YYYY-MM)</label>
              <Input value={form.period} onChange={e => updateField("period", e.target.value)} placeholder="2026-01" data-testid="input-rent-period" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Received Date</label>
              <Input type="date" value={form.receivedDate} onChange={e => updateField("receivedDate", e.target.value)} data-testid="input-rent-received-date" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Gross Rent</label>
              <Input type="number" step="0.01" value={form.grossRent} onChange={e => updateField("grossRent", e.target.value)} placeholder="0.00" data-testid="input-rent-gross" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Currency</label>
              <Select value={form.currency} onValueChange={v => updateField("currency", v)}>
                <SelectTrigger data-testid="select-rent-currency">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SUPPORTED_CURRENCIES.map(c => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Occupancy Rate %</label>
              <Input type="number" step="0.01" min="0" max="100" value={form.occupancyRate} onChange={e => updateField("occupancyRate", e.target.value)} data-testid="input-rent-occupancy" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Vacancy Adj.</label>
              <Input type="number" step="0.01" value={form.vacancyAdjustment} onChange={e => updateField("vacancyAdjustment", e.target.value)} placeholder="0.00" data-testid="input-rent-vacancy" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Late Payment</label>
              <Input type="number" step="0.01" value={form.latePaymentPenalty} onChange={e => updateField("latePaymentPenalty", e.target.value)} placeholder="0.00" data-testid="input-rent-late" />
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-muted-foreground">Notes</label>
            <Textarea value={form.notes} onChange={e => updateField("notes", e.target.value)} placeholder="Optional notes" data-testid="input-rent-notes" />
          </div>

          <div className="p-3 rounded-md bg-muted/50">
            <p className="text-xs text-muted-foreground mb-1">Effective Rent Preview</p>
            <p className="text-sm font-bold" data-testid="text-rent-preview">
              {formatCurrency(
                (parseFloat(form.grossRent || "0") - parseFloat(form.vacancyAdjustment || "0") + parseFloat(form.latePaymentPenalty || "0")).toFixed(2),
                form.currency
              )}
            </p>
          </div>

          <Button className="w-full" onClick={() => mutation.mutate()} disabled={mutation.isPending || !form.grossRent} data-testid="button-submit-rent">
            {mutation.isPending ? "Recording..." : "Record Rent Collection"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ExpenseDialog({ assetId, onClose }: { assetId: string; onClose: () => void }) {
  const { toast } = useToast();
  const [form, setForm] = useState({
    period: new Date().toISOString().slice(0, 7),
    category: "maintenance",
    description: "",
    amount: "",
    currency: "AED",
  });

  const mutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/finance/operating-expenses", {
        assetId,
        period: form.period,
        category: form.category,
        description: form.description || undefined,
        amount: form.amount,
        currency: form.currency,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/rental-operations", assetId] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/rental-operations"] });
      toast({ title: "Operating expense recorded successfully" });
      onClose();
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const updateField = (field: string, value: string) => setForm(prev => ({ ...prev, [field]: value }));

  const expenseCategories = [
    { value: "maintenance", label: "Maintenance" },
    { value: "management_fee", label: "Management Fee" },
    { value: "insurance", label: "Insurance" },
    { value: "property_tax", label: "Property Tax" },
    { value: "utility_reserve", label: "Utility Reserve" },
    { value: "vacancy_adjustment", label: "Vacancy Adjustment" },
    { value: "late_payment", label: "Late Payment Handling" },
    { value: "other", label: "Other" },
  ];

  return (
    <Dialog open onOpenChange={() => onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Add Operating Expense</DialogTitle>
          <DialogDescription>Record an operating expense for this property</DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Period (YYYY-MM)</label>
              <Input value={form.period} onChange={e => updateField("period", e.target.value)} placeholder="2026-01" data-testid="input-expense-period" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Category</label>
              <Select value={form.category} onValueChange={v => updateField("category", v)}>
                <SelectTrigger data-testid="select-expense-category">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {expenseCategories.map(c => (
                    <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Amount</label>
              <Input type="number" step="0.01" value={form.amount} onChange={e => updateField("amount", e.target.value)} placeholder="0.00" data-testid="input-expense-amount" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Currency</label>
              <Select value={form.currency} onValueChange={v => updateField("currency", v)}>
                <SelectTrigger data-testid="select-expense-currency">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SUPPORTED_CURRENCIES.map(c => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-muted-foreground">Description</label>
            <Textarea value={form.description} onChange={e => updateField("description", e.target.value)} placeholder="Optional description" data-testid="input-expense-description" />
          </div>

          <Button className="w-full" onClick={() => mutation.mutate()} disabled={mutation.isPending || !form.amount} data-testid="button-submit-expense">
            {mutation.isPending ? "Recording..." : "Record Expense"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
