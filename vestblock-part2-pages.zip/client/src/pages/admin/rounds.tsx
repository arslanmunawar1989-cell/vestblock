import { useQuery } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { DataTable, type Column } from "@/components/data-table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { CircleDollarSign, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
interface RoundRow {
  id: string;
  name: string;
  assetName?: string;
  targetAmount: string;
  raisedAmount: string;
  status: string;
  startDate?: string;
  endDate?: string;
}

export default function AdminRounds() {
  const { data: rounds = [], isLoading } = useQuery<RoundRow[]>({
    queryKey: ["/api/rounds"],
  });

  const columns: Column<RoundRow>[] = [
    { header: "Round", accessor: "name" },
    { header: "Asset", accessor: (row) => row.assetName || "—" },
    { header: "Target", accessor: (row) => `$${Number(row.targetAmount).toLocaleString()}` },
    { header: "Raised", accessor: (row) => `$${Number(row.raisedAmount).toLocaleString()}` },
    { header: "Progress", accessor: (row) => {
      const pct = Number(row.targetAmount) > 0 ? Math.round((Number(row.raisedAmount) / Number(row.targetAmount)) * 100) : 0;
      return `${pct}%`;
    }},
    { header: "Status", accessor: (row) => <Badge variant={row.status === "open" ? "default" : "secondary"} className="text-xs">{row.status}</Badge> },
  ];

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle title="Investment Rounds" description="Monitor all active and past fundraising rounds" />
        </div>
        <Section>
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-12 w-full" />)}
            </div>
          ) : rounds.length === 0 ? (
            <div className="text-center py-12">
              <CircleDollarSign className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground" data-testid="text-no-rounds">No investment rounds found</p>
            </div>
          ) : (
            <DataTable columns={columns} data={rounds} />
          )}
        </Section>
      </div>
    </RoleLayout>
  );
}