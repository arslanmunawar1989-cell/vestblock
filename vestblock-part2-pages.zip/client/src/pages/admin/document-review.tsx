import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { StatTile } from "@/components/stat-tile";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate } from "@/lib/format";
import {
  FileSearch, CheckCircle2, XCircle, Eye, Loader2, FileText,
  Clock, Search, Filter, ScanLine, Pencil, ArrowRight, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface IngestionUser {
  id: string;
  username: string;
  email: string;
  fullName: string;
}

interface FieldSchema {
  key: string;
  label: string;
  kycField?: string;
}

interface DocumentIngestion {
  id: string;
  documentId: string;
  userId: string;
  docType: string;
  status: string;
  extractedFields: Record<string, string | null> | null;
  reviewedFields: Record<string, string | null> | null;
  confidence: string | null;
  ocrProvider: string | null;
  reviewedBy: string | null;
  reviewNotes: string | null;
  kycAutoFilled: boolean;
  createdAt: string;
  updatedAt: string;
  user: IngestionUser | null;
  fieldSchema: FieldSchema[];
}

const DOC_TYPE_LABELS: Record<string, string> = {
  passport: "Passport",
  national_id: "National ID",
  bank_statement: "Bank Statement",
  title_deed: "Title Deed",
  lease_agreement: "Lease Agreement",
  utility_bill: "Utility Bill",
  tax_return: "Tax Return",
};

const STATUS_CONFIG: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  uploaded: { label: "Uploaded", variant: "secondary" },
  extracting: { label: "Extracting", variant: "outline" },
  extracted: { label: "Extracted", variant: "default" },
  review: { label: "In Review", variant: "outline" },
  approved: { label: "Approved", variant: "default" },
  rejected: { label: "Rejected", variant: "destructive" },
  failed: { label: "Failed", variant: "destructive" },
};

export default function AdminDocumentReview() {
  const { toast } = useToast();
  const [selectedIngestion, setSelectedIngestion] = useState<DocumentIngestion | null>(null);
  const [editingFields, setEditingFields] = useState<Record<string, string | null>>({});
  const [reviewNotes, setReviewNotes] = useState("");
  const [autoFillKyc, setAutoFillKyc] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [filterDocType, setFilterDocType] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");

  const { data: ingestions = [], isLoading } = useQuery<DocumentIngestion[]>({
    queryKey: ["/api/admin/document-ingestion"],
  });

  const updateFieldsMutation = useMutation({
    mutationFn: async ({ id, fields, notes }: { id: string; fields: Record<string, string | null>; notes?: string }) => {
      return apiRequest("PATCH", `/api/admin/document-ingestion/${id}/fields`, {
        reviewedFields: fields,
        reviewNotes: notes,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/document-ingestion"] });
      toast({ title: "Fields updated", description: "Reviewed fields saved successfully." });
    },
  });

  const actionMutation = useMutation({
    mutationFn: async ({ id, action, notes, autoFill }: { id: string; action: string; notes?: string; autoFill?: boolean }) => {
      return apiRequest("POST", `/api/admin/document-ingestion/${id}/action`, {
        action,
        reviewNotes: notes,
        autoFillKyc: autoFill,
      });
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/document-ingestion"] });
      setSelectedIngestion(null);
      toast({
        title: variables.action === "approve" ? "Document Approved" : "Document Rejected",
        description: variables.action === "approve"
          ? "Document ingestion approved and fields stored."
          : "Document ingestion rejected.",
      });
    },
  });

  const openReview = (ingestion: DocumentIngestion) => {
    setSelectedIngestion(ingestion);
    const fields = ingestion.reviewedFields || ingestion.extractedFields || {};
    setEditingFields({ ...fields });
    setReviewNotes(ingestion.reviewNotes || "");
    setAutoFillKyc(false);
  };

  const handleSaveFields = () => {
    if (!selectedIngestion) return;
    updateFieldsMutation.mutate({
      id: selectedIngestion.id,
      fields: editingFields,
      notes: reviewNotes,
    });
  };

  const handleAction = async (action: "approve" | "reject") => {
    if (!selectedIngestion) return;
    if (action === "approve") {
      await apiRequest("PATCH", `/api/admin/document-ingestion/${selectedIngestion.id}/fields`, {
        reviewedFields: editingFields,
        reviewNotes: reviewNotes,
      });
    }
    actionMutation.mutate({
      id: selectedIngestion.id,
      action,
      notes: reviewNotes,
      autoFill: action === "approve" ? autoFillKyc : false,
    });
  };

  const filtered = ingestions.filter(ing => {
    if (filterStatus !== "all" && ing.status !== filterStatus) return false;
    if (filterDocType !== "all" && ing.docType !== filterDocType) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const userName = ing.user?.username?.toLowerCase() || "";
      const userEmail = ing.user?.email?.toLowerCase() || "";
      const fullName = ing.user?.fullName?.toLowerCase() || "";
      if (!userName.includes(q) && !userEmail.includes(q) && !fullName.includes(q)) return false;
    }
    return true;
  });

  const pendingCount = ingestions.filter(i => ["extracted", "review"].includes(i.status)).length;
  const approvedCount = ingestions.filter(i => i.status === "approved").length;
  const rejectedCount = ingestions.filter(i => i.status === "rejected").length;

  const hasKycFields = (ingestion: DocumentIngestion) => {
    return ingestion.fieldSchema.some(f => f.kycField);
  };

  return (
    <RoleLayout role="admin">
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Document Review"
          description="Review extracted document data, verify fields, and approve for KYC auto-fill"
        />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <StatTile
            label="Total"
            value={String(ingestions.length)}
            icon={<FileText className="h-4 w-4" />}
          />
          <StatTile
            label="Pending Review"
            value={String(pendingCount)}
            icon={<Clock className="h-4 w-4" />}
          />
          <StatTile
            label="Approved"
            value={String(approvedCount)}
            icon={<CheckCircle2 className="h-4 w-4" />}
          />
          <StatTile
            label="Rejected"
            value={String(rejectedCount)}
            icon={<XCircle className="h-4 w-4" />}
          />
        </div>

        <Section title="Document Ingestions">
          <div className="flex flex-wrap gap-3 mb-4">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                data-testid="input-search"
                placeholder="Search by user..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger data-testid="select-filter-status" className="w-[160px]">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="extracted">Extracted</SelectItem>
                <SelectItem value="review">In Review</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterDocType} onValueChange={setFilterDocType}>
              <SelectTrigger data-testid="select-filter-doctype" className="w-[180px]">
                <FileSearch className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Doc Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {Object.entries(DOC_TYPE_LABELS).map(([key, label]) => (
                  <SelectItem key={key} value={key}>{label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center p-8 text-muted-foreground" data-testid="text-no-results">
              No document ingestions found.
            </div>
          ) : (
            <div className="space-y-3">
              {filtered.map((ing) => {
                const statusCfg = STATUS_CONFIG[ing.status] || STATUS_CONFIG.uploaded;
                return (
                  <GlassCard key={ing.id} className="p-4">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-3 min-w-0">
                        <ScanLine className="h-5 w-5 text-muted-foreground shrink-0" />
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-medium" data-testid={`text-doctype-${ing.id}`}>
                              {DOC_TYPE_LABELS[ing.docType] || ing.docType}
                            </span>
                            <Badge variant={statusCfg.variant} data-testid={`badge-status-${ing.id}`}>
                              {statusCfg.label}
                            </Badge>
                            {ing.kycAutoFilled && (
                              <Badge variant="outline" data-testid={`badge-autofilled-${ing.id}`}>
                                KYC Auto-filled
                              </Badge>
                            )}
                          </div>
                          <div className="text-sm text-muted-foreground mt-1">
                            {ing.user?.fullName || ing.user?.username || "Unknown user"}
                            {ing.user?.email ? ` (${ing.user.email})` : ""}
                            {" \u00B7 "}
                            {formatDate(ing.createdAt)}
                            {ing.confidence && ` \u00B7 Confidence: ${parseFloat(ing.confidence).toFixed(0)}%`}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {["extracted", "review"].includes(ing.status) && (
                          <Button
                            size="sm"
                            onClick={() => openReview(ing)}
                            data-testid={`button-review-${ing.id}`}
                          >
                            <Pencil className="h-4 w-4 mr-1" />
                            Review
                          </Button>
                        )}
                        {["approved", "rejected"].includes(ing.status) && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => openReview(ing)}
                            data-testid={`button-view-${ing.id}`}
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            View
                          </Button>
                        )}
                      </div>
                    </div>
                  </GlassCard>
                );
              })}
            </div>
          )}
        </Section>
      </div>

      <Dialog open={!!selectedIngestion} onOpenChange={(open) => { if (!open) setSelectedIngestion(null); }}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          {selectedIngestion && (
            <>
              <DialogHeader>
                <DialogTitle className="flex flex-wrap items-center gap-2">
                  <FileSearch className="h-5 w-5" />
                  {DOC_TYPE_LABELS[selectedIngestion.docType] || selectedIngestion.docType} Review
                  <Badge variant={STATUS_CONFIG[selectedIngestion.status]?.variant || "secondary"}>
                    {STATUS_CONFIG[selectedIngestion.status]?.label || selectedIngestion.status}
                  </Badge>
                </DialogTitle>
                <DialogDescription>
                  {selectedIngestion.user?.fullName || selectedIngestion.user?.username}
                  {selectedIngestion.user?.email ? ` \u00B7 ${selectedIngestion.user.email}` : ""}
                  {" \u00B7 "}
                  {selectedIngestion.ocrProvider ? `Provider: ${selectedIngestion.ocrProvider}` : "Manual entry"}
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4 py-4">
                <div className="space-y-3">
                  <Label className="text-sm font-semibold">Extracted Fields</Label>
                  {selectedIngestion.fieldSchema.map((field) => {
                    const extracted = selectedIngestion.extractedFields?.[field.key] || "";
                    const isReadOnly = ["approved", "rejected"].includes(selectedIngestion.status);
                    return (
                      <div key={field.key} className="grid grid-cols-3 gap-2 items-center">
                        <Label className="text-sm text-muted-foreground col-span-1">
                          {field.label}
                          {field.kycField && (
                            <ArrowRight className="inline h-3 w-3 ml-1 text-primary" />
                          )}
                        </Label>
                        <div className="col-span-2">
                          {isReadOnly ? (
                            <div className="text-sm p-2 bg-muted rounded-md" data-testid={`text-field-${field.key}`}>
                              {(selectedIngestion.reviewedFields?.[field.key] || extracted) || "-"}
                            </div>
                          ) : (
                            <Input
                              data-testid={`input-field-${field.key}`}
                              value={editingFields[field.key] || ""}
                              onChange={(e) => setEditingFields({ ...editingFields, [field.key]: e.target.value || null })}
                              placeholder={extracted ? `Extracted: ${extracted}` : `Enter ${field.label.toLowerCase()}`}
                            />
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="space-y-2">
                  <Label className="text-sm font-semibold">Review Notes</Label>
                  {["approved", "rejected"].includes(selectedIngestion.status) ? (
                    <div className="text-sm p-2 bg-muted rounded-md" data-testid="text-review-notes">
                      {selectedIngestion.reviewNotes || "-"}
                    </div>
                  ) : (
                    <Textarea
                      data-testid="input-review-notes"
                      value={reviewNotes}
                      onChange={(e) => setReviewNotes(e.target.value)}
                      placeholder="Add review notes..."
                      className="resize-none"
                      rows={3}
                    />
                  )}
                </div>

                {hasKycFields(selectedIngestion) && !["approved", "rejected"].includes(selectedIngestion.status) && (
                  <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-md">
                    <input
                      type="checkbox"
                      id="autoFillKyc"
                      checked={autoFillKyc}
                      onChange={(e) => setAutoFillKyc(e.target.checked)}
                      className="h-4 w-4"
                      data-testid="checkbox-autofill-kyc"
                    />
                    <Label htmlFor="autoFillKyc" className="text-sm cursor-pointer">
                      Auto-fill KYC profile fields on approval
                      <span className="block text-xs text-muted-foreground">
                        Fields marked with <ArrowRight className="inline h-3 w-3" /> will update the user's KYC profile
                      </span>
                    </Label>
                  </div>
                )}
              </div>

              {!["approved", "rejected"].includes(selectedIngestion.status) && (
                <DialogFooter className="flex flex-wrap gap-2">
                  <Button
                    variant="outline"
                    onClick={handleSaveFields}
                    disabled={updateFieldsMutation.isPending}
                    data-testid="button-save-fields"
                  >
                    {updateFieldsMutation.isPending && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
                    Save Fields
                  </Button>
                  <Button
                    variant="destructive"
                    onClick={() => handleAction("reject")}
                    disabled={actionMutation.isPending}
                    data-testid="button-reject"
                  >
                    {actionMutation.isPending && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
                    <XCircle className="h-4 w-4 mr-1" />
                    Reject
                  </Button>
                  <Button
                    onClick={() => handleAction("approve")}
                    disabled={actionMutation.isPending}
                    data-testid="button-approve"
                  >
                    {actionMutation.isPending && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
                    <CheckCircle2 className="h-4 w-4 mr-1" />
                    Approve
                  </Button>
                </DialogFooter>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
    </RoleLayout>
  );
}
