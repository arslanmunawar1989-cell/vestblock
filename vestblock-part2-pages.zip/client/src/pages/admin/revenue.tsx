import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DollarSign,
  Receipt,
  BarChart3,
  Calculator,
  TrendingUp,
  Building2,
  ArrowRightLeft,
  Globe,
  FileText,
  Layers,
  Crown,
  Users,
  Briefcase, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
interface AnalyticsData {
  totalRevenue: number;
  totalTransactions: number;
  byCategory: Record<string, { total: number; count: number; feeTypes: string[] }>;
  byFeeType: Record<string, { total: number; count: number }>;
  byVehicle: Record<string, { total: number; count: number; name: string }>;
  byMonth: Array<{ month: string; total: number; count: number }>;
  categories: Array<{ key: string; label: string; description: string }>;
}

interface FeeSchedule {
  id: string;
  vehicleId: string | null;
  feeType: string;
  currency: string;
  method: string;
  rate: string;
  flatAmount: string;
  tiers: unknown;
  minFee: string | null;
  maxFee: string | null;
  version: number;
  isActive: boolean;
  effectiveFrom: string;
  effectiveTo: string | null;
  createdBy: string | null;
  createdAt: string;
  notes: string | null;
}

const CATEGORY_ICONS: Record<string, typeof DollarSign> = {
  asset_lifecycle: Building2,
  secondary_market: ArrowRightLeft,
  fx_payment: Globe,
  core: Layers,
};

const FEE_TYPE_LABELS: Record<string, string> = {
  acquisition: "Acquisition / Structuring",
  management: "Annual Management",
  rental_processing: "Rental Processing",
  property_sale: "Property Sale / Disposal",
  performance_fee: "Performance Fee",
  valuation_uplift: "Valuation Uplift Success Fee",
  exit_trade_buyer: "Exit Trade (Buyer)",
  exit_trade_seller: "Exit Trade (Seller)",
  fx: "FX Conversion",
  crypto_deposit: "Crypto Deposit",
  withdrawal: "Withdrawal",
  investment: "Investment",
  trade: "Trade",
  transfer: "Transfer",
  redemption: "Redemption",
  issuer_onboarding: "Institutional Onboarding",
  premium_membership: "Premium Membership",
};

function formatPKR(value: number): string {
  if (value >= 10000000) return `PKR ${(value / 10000000).toFixed(2)} Cr`;
  if (value >= 100000) return `PKR ${(value / 100000).toFixed(2)} Lac`;
  return `PKR ${value.toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
}

function getRateValue(schedules: FeeSchedule[], feeType: string): number {
  const s = schedules.find((x) => x.feeType === feeType && !x.vehicleId);
  if (!s) return 0;
  if (s.method === "percentage") return parseFloat(s.rate || "0");
  return 0;
}

function getFlatValue(schedules: FeeSchedule[], feeType: string): number {
  const s = schedules.find((x) => x.feeType === feeType && !x.vehicleId);
  if (!s) return 0;
  if (s.method === "flat") return parseFloat(s.flatAmount || "0");
  return 0;
}

function simulateRevenue(
  propertyValue: number,
  rentalYield: number,
  occupancy: number,
  tradingVolumePct: number,
  fxConversions: number,
  pmChargeRate: number,
  pmCostRate: number,
  targetYield: number,
  appreciationPct: number,
  holdingYears: number,
  premiumInvestors: number,
  schedules: FeeSchedule[]
) {
  const acquisitionRate = getRateValue(schedules, "acquisition");
  const managementRate = getRateValue(schedules, "management");
  const rentalProcessingRate = getRateValue(schedules, "rental_processing");
  const buyerRate = getRateValue(schedules, "exit_trade_buyer");
  const sellerRate = getRateValue(schedules, "exit_trade_seller");
  const fxRate = getRateValue(schedules, "fx");
  const propertySaleRate = getRateValue(schedules, "property_sale");
  const issuerOnboardingFlat = getFlatValue(schedules, "issuer_onboarding");
  const performanceFeeRate = getRateValue(schedules, "performance_fee");
  const valuationUpliftRate = getRateValue(schedules, "valuation_uplift");
  const premiumMembershipFlat = getFlatValue(schedules, "premium_membership");

  const avgConversionPct = 0.3;

  const grossRent = propertyValue * (rentalYield / 100) * (occupancy / 100);
  const acquisition = propertyValue * acquisitionRate;
  const management = propertyValue * managementRate;
  const rentalProcessing = grossRent * rentalProcessingRate;
  const pmSpreadRate = Math.max(0, (pmChargeRate - pmCostRate) / 100);
  const pmSpread = grossRent * pmSpreadRate;
  const exitTrade = propertyValue * (tradingVolumePct / 100) * (buyerRate + sellerRate);
  const fxSpread = propertyValue * fxConversions * avgConversionPct * fxRate;
  const propertySale = propertyValue * propertySaleRate;
  const issuerOnboarding = issuerOnboardingFlat;

  const actualYield = rentalYield * (occupancy / 100);
  const excessYield = Math.max(0, actualYield - targetYield);
  const excessAmount = propertyValue * (excessYield / 100);
  const performanceFee = excessAmount * performanceFeeRate;

  const salePrice = propertyValue * (1 + appreciationPct / 100);
  const capitalGain = Math.max(0, salePrice - propertyValue);
  const valuationUplift = capitalGain * valuationUpliftRate;
  const annualizedUplift = holdingYears > 0 ? valuationUplift / holdingYears : 0;

  const premiumMembership = premiumInvestors * premiumMembershipFlat;

  const coreLayerA = acquisition;
  const coreLayerB = management;
  const coreLayerC = pmSpread;
  const coreAnnual = coreLayerB + coreLayerC;
  const coreTotal = coreLayerA + coreAnnual;

  const oneTime = acquisition + propertySale + issuerOnboarding + valuationUplift;
  const annual = management + rentalProcessing + exitTrade + fxSpread + pmSpread + performanceFee + premiumMembership;
  const lifecycleAnnual = rentalProcessing + performanceFee;
  const lifecycleOneTime = valuationUplift;
  const year1Total = oneTime + annual;

  return {
    acquisition,
    management,
    rentalProcessing,
    pmSpread,
    grossRent,
    exitTrade,
    fxSpread,
    propertySale,
    issuerOnboarding,
    performanceFee,
    valuationUplift,
    annualizedUplift,
    premiumMembership,
    capitalGain,
    salePrice,
    excessYield,
    excessAmount,
    oneTime,
    annual,
    lifecycleAnnual,
    lifecycleOneTime,
    year1Total,
    coreLayerA,
    coreLayerB,
    coreLayerC,
    coreAnnual,
    coreTotal,
    rates: {
      acquisitionRate,
      managementRate,
      rentalProcessingRate,
      buyerRate,
      sellerRate,
      fxRate,
      propertySaleRate,
      issuerOnboardingFlat,
      pmChargeRate,
      pmCostRate,
      pmSpreadRate,
      performanceFeeRate,
      valuationUpliftRate,
      premiumMembershipFlat,
    },
  };
}

export default function AdminRevenue() {
  const [activeTab, setActiveTab] = useState("analytics");

  const [propertyValue, setPropertyValue] = useState(100000000);
  const [rentalYield, setRentalYield] = useState(6);
  const [occupancy, setOccupancy] = useState(100);
  const [tradingVolumePct, setTradingVolumePct] = useState(15);
  const [fxConversions, setFxConversions] = useState(4);
  const [pmChargeRate, setPmChargeRate] = useState(6);
  const [pmCostRate, setPmCostRate] = useState(5);
  const [targetYield, setTargetYield] = useState(8);
  const [appreciationPct, setAppreciationPct] = useState(20);
  const [holdingYears, setHoldingYears] = useState(5);
  const [premiumInvestors, setPremiumInvestors] = useState(500);

  const [projYear1, setProjYear1] = useState(5);
  const [projYear2, setProjYear2] = useState(15);
  const [projYear3, setProjYear3] = useState(40);
  const [projAvgValue, setProjAvgValue] = useState(100000000);

  const { data: analytics, isLoading: analyticsLoading } = useQuery<AnalyticsData>({
    queryKey: ["/api/admin/revenue/analytics"],
    enabled: activeTab === "analytics",
  });

  const { data: feeSchedules } = useQuery<FeeSchedule[]>({
    queryKey: ["/api/fees/active"],
  });

  const schedules = feeSchedules || [];

  const simResult = useMemo(
    () => simulateRevenue(propertyValue, rentalYield, occupancy, tradingVolumePct, fxConversions, pmChargeRate, pmCostRate, targetYield, appreciationPct, holdingYears, premiumInvestors, schedules),
    [propertyValue, rentalYield, occupancy, tradingVolumePct, fxConversions, pmChargeRate, pmCostRate, targetYield, appreciationPct, holdingYears, premiumInvestors, schedules]
  );

  const projection = useMemo(() => {
    const yearPropertyCounts = [projYear1, projYear2, projYear3];
    const years = [];
    let cumulative = 0;
    let cumulativeRevenue = 0;

    for (let y = 0; y < 3; y++) {
      const newProps = yearPropertyCounts[y];
      cumulative += newProps;
      const aum = cumulative * projAvgValue;

      const projPremiumInvestors = projYear1 > 0 ? Math.round(premiumInvestors * (cumulative / projYear1)) : premiumInvestors;
      const sim = simulateRevenue(projAvgValue, rentalYield, occupancy, tradingVolumePct, fxConversions, pmChargeRate, pmCostRate, targetYield, appreciationPct, holdingYears, projPremiumInvestors, schedules);

      const layerA = newProps * sim.coreLayerA;
      const layerB = cumulative * sim.coreLayerB;
      const layerC = cumulative * sim.coreLayerC;
      const perfFee = cumulative * sim.performanceFee;
      const rentalDist = cumulative * sim.rentalProcessing;
      const upliftAnnualized = cumulative * sim.annualizedUplift;
      const premiumRevenue = sim.premiumMembership;
      const onboardingRevenue = newProps * sim.issuerOnboarding;
      const oneTimeThisYear = newProps * (sim.acquisition + sim.propertySale + sim.issuerOnboarding + sim.valuationUplift);
      const annualThisYear = cumulative * (sim.annual - sim.premiumMembership) + sim.premiumMembership;
      const totalThisYear = oneTimeThisYear + annualThisYear;
      cumulativeRevenue += totalThisYear;

      years.push({
        year: y + 1,
        newProperties: newProps,
        cumulativeProperties: cumulative,
        aum,
        layerA,
        layerB,
        layerC,
        perfFee,
        rentalDist,
        upliftAnnualized,
        premiumRevenue,
        onboardingRevenue,
        premiumInvestors: projPremiumInvestors,
        oneTimeRevenue: oneTimeThisYear,
        annualRevenue: annualThisYear,
        totalRevenue: totalThisYear,
        cumulativeRevenue,
      });
    }

    return years;
  }, [projYear1, projYear2, projYear3, projAvgValue, rentalYield, occupancy, tradingVolumePct, fxConversions, pmChargeRate, pmCostRate, targetYield, appreciationPct, holdingYears, premiumInvestors, schedules]);

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Revenue Dashboard"
          description="Platform revenue analytics, fee simulation, and growth projections"
        />
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList data-testid="revenue-tabs">
            <TabsTrigger value="analytics" data-testid="tab-analytics">Revenue Analytics</TabsTrigger>
            <TabsTrigger value="simulator" data-testid="tab-simulator">Revenue Simulator</TabsTrigger>
            <TabsTrigger value="projection" data-testid="tab-projection">3-Year Projection</TabsTrigger>
          </TabsList>

          <TabsContent value="analytics" className="space-y-6 mt-4">
            {analyticsLoading ? (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-24 rounded-md" />)}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-40 rounded-md" />)}
                </div>
              </div>
            ) : analytics ? (
              <>
                <Section title="Overview">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <Card>
                      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                        <DollarSign className="w-4 h-4 text-muted-foreground" />
                      </CardHeader>
                      <CardContent>
                        <p className="text-2xl font-bold" data-testid="text-total-revenue">
                          {formatPKR(analytics.totalRevenue)}
                        </p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Total Transactions</CardTitle>
                        <Receipt className="w-4 h-4 text-muted-foreground" />
                      </CardHeader>
                      <CardContent>
                        <p className="text-2xl font-bold" data-testid="text-total-transactions">
                          {analytics.totalTransactions.toLocaleString()}
                        </p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">Active Categories</CardTitle>
                        <BarChart3 className="w-4 h-4 text-muted-foreground" />
                      </CardHeader>
                      <CardContent>
                        <p className="text-2xl font-bold" data-testid="text-active-categories">
                          {Object.keys(analytics.byCategory).length}
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                </Section>

                <Section title="Revenue by Category">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {(analytics.categories || []).map((cat) => {
                      const catData = analytics.byCategory[cat.key];
                      const CatIcon = CATEGORY_ICONS[cat.key] || Layers;
                      return (
                        <GlassCard key={cat.key} padding="md" data-testid={`card-category-${cat.key}`}>
                          <div className="flex items-start justify-between gap-2 mb-3">
                            <div className="flex items-center gap-2">
                              <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                                <CatIcon className="w-4 h-4 text-primary" />
                              </div>
                              <div>
                                <p className="text-sm font-semibold">{cat.label}</p>
                                <p className="text-xs text-muted-foreground">{cat.description}</p>
                              </div>
                            </div>
                            <Badge variant="secondary" className="no-default-hover-elevate">
                              {catData ? catData.count : 0} txns
                            </Badge>
                          </div>
                          <p className="text-lg font-bold mb-2" data-testid={`text-category-total-${cat.key}`}>
                            {formatPKR(catData ? catData.total : 0)}
                          </p>
                          {catData && catData.feeTypes.length > 0 && (
                            <div className="space-y-1 pt-2 border-t">
                              {catData.feeTypes.map((ft) => {
                                const ftData = analytics.byFeeType[ft];
                                return (
                                  <div key={ft} className="flex items-center justify-between text-xs">
                                    <span className="text-muted-foreground">{FEE_TYPE_LABELS[ft] || ft}</span>
                                    <span className="font-medium">{ftData ? formatPKR(ftData.total) : "PKR 0"}</span>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </GlassCard>
                      );
                    })}
                  </div>
                </Section>

                {analytics.byMonth.length > 0 && (
                  <Section title="Monthly Revenue">
                    <GlassCard padding="md">
                      <div className="space-y-2">
                        {analytics.byMonth.map((m) => {
                          const maxTotal = Math.max(...analytics.byMonth.map((x) => x.total), 1);
                          const widthPct = (m.total / maxTotal) * 100;
                          return (
                            <div key={m.month} className="flex items-center gap-3" data-testid={`row-month-${m.month}`}>
                              <span className="text-sm font-medium w-20 flex-shrink-0">{m.month}</span>
                              <div className="flex-1 h-6 rounded-md bg-muted overflow-hidden">
                                <div
                                  className="h-full rounded-md bg-primary/70"
                                  style={{ width: `${widthPct}%` }}
                                />
                              </div>
                              <span className="text-sm font-medium w-28 text-right flex-shrink-0">{formatPKR(m.total)}</span>
                              <span className="text-xs text-muted-foreground w-16 text-right flex-shrink-0">{m.count} txns</span>
                            </div>
                          );
                        })}
                      </div>
                    </GlassCard>
                  </Section>
                )}

                {Object.keys(analytics.byVehicle).length > 0 && (
                  <Section title="Revenue by Vehicle">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {Object.entries(analytics.byVehicle).map(([vid, vData]) => (
                        <GlassCard key={vid} padding="md" data-testid={`card-vehicle-${vid}`}>
                          <div className="flex items-start justify-between gap-2 mb-2">
                            <div className="flex items-center gap-2">
                              <Building2 className="w-4 h-4 text-primary" />
                              <p className="text-sm font-semibold truncate max-w-[180px]">{vData.name}</p>
                            </div>
                            <Badge variant="outline" className="no-default-hover-elevate">{vData.count} txns</Badge>
                          </div>
                          <p className="text-lg font-bold" data-testid={`text-vehicle-total-${vid}`}>{formatPKR(vData.total)}</p>
                        </GlassCard>
                      ))}
                    </div>
                  </Section>
                )}
              </>
            ) : (
              <GlassCard>
                <div className="text-center py-8 text-muted-foreground">
                  <BarChart3 className="w-10 h-10 mx-auto mb-3 opacity-50" />
                  <p className="text-sm">No revenue data available</p>
                </div>
              </GlassCard>
            )}
          </TabsContent>

          <TabsContent value="simulator" className="space-y-6 mt-4">
            <Section title="Property Scenario" description="Configure a hypothetical property to model layered platform revenue">
              <GlassCard padding="md">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Property Value (PKR)</label>
                    <Input
                      type="number"
                      value={propertyValue}
                      onChange={(e) => setPropertyValue(Number(e.target.value) || 0)}
                      data-testid="input-property-value"
                    />
                    <p className="text-xs text-muted-foreground mt-1">{formatPKR(propertyValue)}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Annual Rental Yield (%)</label>
                    <Input
                      type="number"
                      value={rentalYield}
                      onChange={(e) => setRentalYield(Number(e.target.value) || 0)}
                      data-testid="input-rental-yield"
                    />
                    <p className="text-xs text-muted-foreground mt-1">Gross rent: {formatPKR(simResult.grossRent)}/yr</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Occupancy Rate (%)</label>
                    <Input
                      type="number"
                      value={occupancy}
                      onChange={(e) => setOccupancy(Number(e.target.value) || 0)}
                      data-testid="input-occupancy"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">PM Charge to Investors (%)</label>
                    <Input
                      type="number"
                      value={pmChargeRate}
                      onChange={(e) => setPmChargeRate(Number(e.target.value) || 0)}
                      data-testid="input-pm-charge"
                    />
                    <p className="text-xs text-muted-foreground mt-1">Rate charged to investors on rent</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Actual PM Cost (%)</label>
                    <Input
                      type="number"
                      value={pmCostRate}
                      onChange={(e) => setPmCostRate(Number(e.target.value) || 0)}
                      data-testid="input-pm-cost"
                    />
                    <p className="text-xs text-muted-foreground mt-1">Cost paid to property manager</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Trading Volume (% of value/yr)</label>
                    <Input
                      type="number"
                      value={tradingVolumePct}
                      onChange={(e) => setTradingVolumePct(Number(e.target.value) || 0)}
                      data-testid="input-trading-volume"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">FX Conversions per Year</label>
                    <Input
                      type="number"
                      value={fxConversions}
                      onChange={(e) => setFxConversions(Number(e.target.value) || 0)}
                      data-testid="input-fx-conversions"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Target Hurdle Yield (%)</label>
                    <Input
                      type="number"
                      value={targetYield}
                      onChange={(e) => setTargetYield(Number(e.target.value) || 0)}
                      data-testid="input-target-yield"
                    />
                    <p className="text-xs text-muted-foreground mt-1">Performance fee kicks in above this</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Expected Appreciation (%)</label>
                    <Input
                      type="number"
                      value={appreciationPct}
                      onChange={(e) => setAppreciationPct(Number(e.target.value) || 0)}
                      data-testid="input-appreciation"
                    />
                    <p className="text-xs text-muted-foreground mt-1">Capital gain over holding period</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Holding Period (Years)</label>
                    <Input
                      type="number"
                      value={holdingYears}
                      onChange={(e) => setHoldingYears(Number(e.target.value) || 1)}
                      data-testid="input-holding-years"
                    />
                  </div>
                </div>
              </GlassCard>
            </Section>

            <Section title="3 Core Revenue Layers" description="Your primary monetization engine - never depend on a single stream">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <GlassCard padding="md" data-testid="card-layer-a">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="default">Layer A</Badge>
                    <p className="text-sm font-semibold">Acquisition / Structuring</p>
                  </div>
                  <p className="text-xs text-muted-foreground mb-3">Upfront fee when property funding closes. Covers legal structuring, SPV formation, due diligence, tokenization setup, and marketing.</p>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Rate</span>
                      <span className="font-medium">{(simResult.rates.acquisitionRate * 100).toFixed(2)}% of raise</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Raise Amount</span>
                      <span className="font-medium">{formatPKR(propertyValue)}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm pt-2 border-t font-semibold">
                      <span>You Earn (Upfront)</span>
                      <span data-testid="text-layer-a-revenue">{formatPKR(simResult.coreLayerA)}</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2 italic">Immediate revenue per property</p>
                </GlassCard>

                <GlassCard padding="md" data-testid="card-layer-b">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="default">Layer B</Badge>
                    <p className="text-sm font-semibold">Annual Management</p>
                  </div>
                  <p className="text-xs text-muted-foreground mb-3">Stable long-term recurring revenue charged annually on Gross Asset Value. This is your business foundation.</p>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Rate</span>
                      <span className="font-medium">{(simResult.rates.managementRate * 100).toFixed(2)}% of GAV/yr</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">GAV</span>
                      <span className="font-medium">{formatPKR(propertyValue)}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm pt-2 border-t font-semibold">
                      <span>You Earn (Per Year)</span>
                      <span data-testid="text-layer-b-revenue">{formatPKR(simResult.coreLayerB)}</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2 italic">Recurring foundation revenue</p>
                </GlassCard>

                <GlassCard padding="md" data-testid="card-layer-c">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="default">Layer C</Badge>
                    <p className="text-sm font-semibold">PM Spread</p>
                  </div>
                  <p className="text-xs text-muted-foreground mb-3">Hidden margin from property management. You charge investors {pmChargeRate}% but the actual PM costs {pmCostRate}%. You keep the {Math.max(0, pmChargeRate - pmCostRate)}% spread.</p>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Gross Rent</span>
                      <span className="font-medium">{formatPKR(simResult.grossRent)}/yr</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Spread</span>
                      <span className="font-medium">{pmChargeRate}% - {pmCostRate}% = {Math.max(0, pmChargeRate - pmCostRate)}%</span>
                    </div>
                    <div className="flex items-center justify-between text-sm pt-2 border-t font-semibold">
                      <span>You Earn (Per Year)</span>
                      <span data-testid="text-layer-c-revenue">{formatPKR(simResult.coreLayerC)}</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2 italic">Hidden margin from operations</p>
                </GlassCard>
              </div>

              <GlassCard padding="md" data-testid="card-core-summary">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <p className="text-xs text-muted-foreground">Core Upfront (Layer A)</p>
                      <p className="text-lg font-bold">{formatPKR(simResult.coreLayerA)}</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <p className="text-xs text-muted-foreground">Core Annual (B + C)</p>
                      <p className="text-lg font-bold">{formatPKR(simResult.coreAnnual)}</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <p className="text-xs text-muted-foreground">Core Year 1 Total</p>
                      <p className="text-lg font-bold" data-testid="text-core-year1">{formatPKR(simResult.coreTotal)}</p>
                    </div>
                  </div>
                </div>
              </GlassCard>
            </Section>

            <Section title="Asset Lifecycle Monetization" description="Revenue earned across the property lifecycle: distributions, outperformance, and capital appreciation">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <GlassCard padding="md" data-testid="card-rental-dist">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline">A. Rental Distribution</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mb-3">Small percentage on every rental distribution payout. Consistent revenue on every property.</p>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Gross Rent</span>
                      <span className="font-medium">{formatPKR(simResult.grossRent)}/yr</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Processing Rate</span>
                      <span className="font-medium">{(simResult.rates.rentalProcessingRate * 100).toFixed(2)}%</span>
                    </div>
                    <div className="flex items-center justify-between text-sm pt-2 border-t font-semibold">
                      <span>You Earn (Per Year)</span>
                      <span data-testid="text-lifecycle-rental">{formatPKR(simResult.rentalProcessing)}</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2 italic">Small but consistent per property</p>
                </GlassCard>

                <GlassCard padding="md" data-testid="card-performance-fee">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline">B. Performance Fee</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mb-3">Charged when actual yield exceeds the target hurdle rate. Aligns your incentives with investor returns.</p>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Target Yield</span>
                      <span className="font-medium">{targetYield}%</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Actual Yield</span>
                      <span className="font-medium">{(rentalYield * occupancy / 100).toFixed(1)}%</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Excess Yield</span>
                      <span className="font-medium">{simResult.excessYield.toFixed(1)}% = {formatPKR(simResult.excessAmount)}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Fee Rate</span>
                      <span className="font-medium">{(simResult.rates.performanceFeeRate * 100).toFixed(0)}% of excess</span>
                    </div>
                    <div className="flex items-center justify-between text-sm pt-2 border-t font-semibold">
                      <span>You Earn (Per Year)</span>
                      <span data-testid="text-lifecycle-performance">{formatPKR(simResult.performanceFee)}</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2 italic">{simResult.excessYield > 0 ? "Incentives aligned with investors" : "No excess — fee only earned on outperformance"}</p>
                </GlassCard>

                <GlassCard padding="md" data-testid="card-valuation-uplift">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline">C. Valuation Uplift</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mb-3">Success fee on capital gains when the property is sold. You only earn this if property value increases.</p>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Original Value</span>
                      <span className="font-medium">{formatPKR(propertyValue)}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Sale Price (+{appreciationPct}%)</span>
                      <span className="font-medium">{formatPKR(simResult.salePrice)}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Capital Gain</span>
                      <span className="font-medium">{formatPKR(simResult.capitalGain)}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Success Fee Rate</span>
                      <span className="font-medium">{(simResult.rates.valuationUpliftRate * 100).toFixed(0)}% of gain</span>
                    </div>
                    <div className="flex items-center justify-between text-sm pt-2 border-t font-semibold">
                      <span>You Earn (At Sale)</span>
                      <span data-testid="text-lifecycle-uplift">{formatPKR(simResult.valuationUplift)}</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2 italic">One-time at sale (annualized: {formatPKR(simResult.annualizedUplift)}/yr over {holdingYears}yr)</p>
                </GlassCard>
              </div>
            </Section>

            <Section title="Premium Revenue Streams" description="High-margin subscription and institutional fees that scale independently of property count">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <GlassCard padding="md" data-testid="card-premium-membership">
                  <div className="flex items-center gap-2 mb-3">
                    <Crown className="w-4 h-4 text-primary" />
                    <p className="text-sm font-semibold">A. Premium Investor Membership</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Annual Fee</span>
                      <span className="font-medium">{formatPKR(simResult.rates.premiumMembershipFlat)}/yr</span>
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">Premium Investors</label>
                      <Input
                        type="number"
                        value={premiumInvestors}
                        onChange={(e) => setPremiumInvestors(Number(e.target.value) || 0)}
                        data-testid="input-premium-investors"
                      />
                    </div>
                    <div className="flex items-center justify-between text-sm pt-2 border-t font-semibold">
                      <span>Annual Revenue</span>
                      <span data-testid="text-premium-revenue">{formatPKR(simResult.premiumMembership)}</span>
                    </div>
                  </div>
                  <div className="mt-3 space-y-1">
                    <p className="text-xs text-muted-foreground font-medium">Includes:</p>
                    <div className="flex flex-col gap-0.5 text-xs text-muted-foreground">
                      <span>Early access to offerings</span>
                      <span>Lower exit fees</span>
                      <span>Higher investment caps</span>
                      <span>Detailed analytics dashboard</span>
                      <span>Dedicated relationship manager</span>
                    </div>
                  </div>
                </GlassCard>

                <GlassCard padding="md" data-testid="card-institutional-onboarding">
                  <div className="flex items-center gap-2 mb-3">
                    <Briefcase className="w-4 h-4 text-primary" />
                    <p className="text-sm font-semibold">B. Institutional Onboarding</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Per Property Fee</span>
                      <span className="font-medium">{formatPKR(simResult.issuerOnboarding)}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm pt-2 border-t font-semibold">
                      <span>Per Property Revenue</span>
                      <span data-testid="text-onboarding-revenue">{formatPKR(simResult.issuerOnboarding)}</span>
                    </div>
                  </div>
                  <div className="mt-3 space-y-1">
                    <p className="text-xs text-muted-foreground font-medium">Covers:</p>
                    <div className="flex flex-col gap-0.5 text-xs text-muted-foreground">
                      <span>Due diligence review</span>
                      <span>Tokenization setup</span>
                      <span>Legal onboarding</span>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2 italic">Typical range: 2-5 lakh PKR per property</p>
                </GlassCard>

                <GlassCard padding="md" data-testid="card-white-label">
                  <div className="flex items-center gap-2 mb-3">
                    <Globe className="w-4 h-4 text-muted-foreground" />
                    <p className="text-sm font-semibold text-muted-foreground">C. White-Label Licensing</p>
                  </div>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p>Future revenue stream: license the VestBlock platform to other developers and real estate firms.</p>
                    <p className="italic text-xs">Coming later as platform matures</p>
                  </div>
                </GlassCard>
              </div>
            </Section>

            <Section title="Supporting Revenue Streams" description="Additional platform fees layered on top of core and lifecycle revenue">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <GlassCard padding="md" data-testid="card-onetime-fees">
                  <div className="flex items-center gap-2 mb-3">
                    <FileText className="w-4 h-4 text-primary" />
                    <p className="text-sm font-semibold">One-Time / Event Fees</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Property Sale ({(simResult.rates.propertySaleRate * 100).toFixed(2)}%)</span>
                      <span className="font-medium" data-testid="text-sim-property-sale">{formatPKR(simResult.propertySale)}</span>
                    </div>
                  </div>
                </GlassCard>

                <GlassCard padding="md" data-testid="card-annual-fees">
                  <div className="flex items-center gap-2 mb-3">
                    <TrendingUp className="w-4 h-4 text-primary" />
                    <p className="text-sm font-semibold">Annual Recurring (Secondary)</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Exit Trade ({((simResult.rates.buyerRate + simResult.rates.sellerRate) * 100).toFixed(2)}%)</span>
                      <span className="font-medium" data-testid="text-sim-exit-trade">{formatPKR(simResult.exitTrade)}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">FX Spread ({(simResult.rates.fxRate * 100).toFixed(2)}%)</span>
                      <span className="font-medium" data-testid="text-sim-fx">{formatPKR(simResult.fxSpread)}</span>
                    </div>
                  </div>
                </GlassCard>
              </div>
            </Section>

            <GlassCard padding="md" data-testid="card-year1-summary">
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <div className="flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-primary" />
                  <div>
                    <p className="text-sm font-semibold">Year 1 Total Revenue (All Layers Combined)</p>
                    <p className="text-xs text-muted-foreground">Core layers + supporting streams for a single property</p>
                  </div>
                </div>
                <p className="text-2xl font-bold" data-testid="text-sim-year1-total">{formatPKR(simResult.year1Total)}</p>
              </div>
            </GlassCard>
          </TabsContent>

          <TabsContent value="projection" className="space-y-6 mt-4">
            <Section title="Growth Parameters" description="Model platform growth over 3 years with custom property counts per year">
              <GlassCard padding="md">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Year 1 Properties</label>
                    <Input
                      type="number"
                      value={projYear1}
                      onChange={(e) => setProjYear1(Number(e.target.value) || 0)}
                      data-testid="input-proj-year1"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Year 2 Properties</label>
                    <Input
                      type="number"
                      value={projYear2}
                      onChange={(e) => setProjYear2(Number(e.target.value) || 0)}
                      data-testid="input-proj-year2"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Year 3 Properties</label>
                    <Input
                      type="number"
                      value={projYear3}
                      onChange={(e) => setProjYear3(Number(e.target.value) || 0)}
                      data-testid="input-proj-year3"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1.5 block">Avg Property Value (PKR)</label>
                    <Input
                      type="number"
                      value={projAvgValue}
                      onChange={(e) => setProjAvgValue(Number(e.target.value) || 0)}
                      data-testid="input-proj-avg-value"
                    />
                    <p className="text-xs text-muted-foreground mt-1">{formatPKR(projAvgValue)}</p>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-3">Cumulative: Year 1 = {projYear1}, Year 2 = {projYear1 + projYear2}, Year 3 = {projYear1 + projYear2 + projYear3} total properties</p>
              </GlassCard>
            </Section>

            <Section title="3-Year Revenue Projection">
              <GlassCard padding="md" data-testid="card-projection-table">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2 pr-4 font-medium text-muted-foreground">Metric</th>
                        {projection.map((y) => (
                          <th key={y.year} className="text-right py-2 px-3 font-medium">Year {y.year}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b">
                        <td className="py-2 pr-4 text-muted-foreground">New Properties</td>
                        {projection.map((y) => (
                          <td key={y.year} className="text-right py-2 px-3 font-medium" data-testid={`text-proj-new-${y.year}`}>
                            {y.newProperties}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="py-2 pr-4 text-muted-foreground">Cumulative Properties</td>
                        {projection.map((y) => (
                          <td key={y.year} className="text-right py-2 px-3 font-medium" data-testid={`text-proj-cumulative-${y.year}`}>
                            {y.cumulativeProperties}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="py-2 pr-4 text-muted-foreground">Total AUM</td>
                        {projection.map((y) => (
                          <td key={y.year} className="text-right py-2 px-3 font-medium" data-testid={`text-proj-aum-${y.year}`}>
                            {formatPKR(y.aum)}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b bg-primary/5">
                        <td className="py-2 pr-4 text-muted-foreground">Layer A: Acquisition</td>
                        {projection.map((y) => (
                          <td key={y.year} className="text-right py-2 px-3 font-medium" data-testid={`text-proj-layera-${y.year}`}>
                            {formatPKR(y.layerA)}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b bg-primary/5">
                        <td className="py-2 pr-4 text-muted-foreground">Layer B: Management</td>
                        {projection.map((y) => (
                          <td key={y.year} className="text-right py-2 px-3 font-medium" data-testid={`text-proj-layerb-${y.year}`}>
                            {formatPKR(y.layerB)}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b bg-primary/5">
                        <td className="py-2 pr-4 text-muted-foreground">Layer C: PM Spread</td>
                        {projection.map((y) => (
                          <td key={y.year} className="text-right py-2 px-3 font-medium" data-testid={`text-proj-layerc-${y.year}`}>
                            {formatPKR(y.layerC)}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b bg-muted/30">
                        <td className="py-2 pr-4 text-muted-foreground">Rental Distribution</td>
                        {projection.map((y) => (
                          <td key={y.year} className="text-right py-2 px-3 font-medium" data-testid={`text-proj-rental-${y.year}`}>
                            {formatPKR(y.rentalDist)}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b bg-muted/30">
                        <td className="py-2 pr-4 text-muted-foreground">Performance Fee</td>
                        {projection.map((y) => (
                          <td key={y.year} className="text-right py-2 px-3 font-medium" data-testid={`text-proj-perf-${y.year}`}>
                            {formatPKR(y.perfFee)}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b bg-muted/30">
                        <td className="py-2 pr-4 text-muted-foreground">Valuation Uplift (at sale, annualized)</td>
                        {projection.map((y) => (
                          <td key={y.year} className="text-right py-2 px-3 font-medium" data-testid={`text-proj-uplift-${y.year}`}>
                            {formatPKR(y.upliftAnnualized)}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b bg-amber-500/5">
                        <td className="py-2 pr-4 text-muted-foreground">Premium Membership</td>
                        {projection.map((y) => (
                          <td key={y.year} className="text-right py-2 px-3 font-medium" data-testid={`text-proj-premium-${y.year}`}>
                            {formatPKR(y.premiumRevenue)}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b bg-amber-500/5">
                        <td className="py-2 pr-4 text-muted-foreground">Institutional Onboarding</td>
                        {projection.map((y) => (
                          <td key={y.year} className="text-right py-2 px-3 font-medium" data-testid={`text-proj-onboarding-${y.year}`}>
                            {formatPKR(y.onboardingRevenue)}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="py-2 pr-4 text-muted-foreground">One-Time Revenue</td>
                        {projection.map((y) => (
                          <td key={y.year} className="text-right py-2 px-3 font-medium" data-testid={`text-proj-onetime-${y.year}`}>
                            {formatPKR(y.oneTimeRevenue)}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="py-2 pr-4 text-muted-foreground">Annual Recurring Revenue</td>
                        {projection.map((y) => (
                          <td key={y.year} className="text-right py-2 px-3 font-medium" data-testid={`text-proj-annual-${y.year}`}>
                            {formatPKR(y.annualRevenue)}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b font-semibold">
                        <td className="py-2 pr-4">Total Year Revenue</td>
                        {projection.map((y) => (
                          <td key={y.year} className="text-right py-2 px-3" data-testid={`text-proj-total-${y.year}`}>
                            {formatPKR(y.totalRevenue)}
                          </td>
                        ))}
                      </tr>
                      <tr className="font-semibold">
                        <td className="py-2 pr-4">Cumulative Revenue</td>
                        {projection.map((y) => (
                          <td key={y.year} className="text-right py-2 px-3" data-testid={`text-proj-cumrev-${y.year}`}>
                            {formatPKR(y.cumulativeRevenue)}
                          </td>
                        ))}
                      </tr>
                    </tbody>
                  </table>
                </div>
              </GlassCard>

              <GlassCard padding="md" data-testid="card-projection-summary">
                <div className="flex items-center justify-between gap-4 flex-wrap">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm font-semibold">3-Year Cumulative Platform Revenue</p>
                      <p className="text-xs text-muted-foreground">
                        {projection.length > 0 ? `${projection[projection.length - 1].cumulativeProperties} total properties` : ""}
                      </p>
                    </div>
                  </div>
                  <p className="text-2xl font-bold" data-testid="text-proj-3yr-total">
                    {projection.length > 0 ? formatPKR(projection[projection.length - 1].cumulativeRevenue) : "PKR 0"}
                  </p>
                </div>
              </GlassCard>
            </Section>
          </TabsContent>
        </Tabs>
      </div>
    </RoleLayout>
  );
}
