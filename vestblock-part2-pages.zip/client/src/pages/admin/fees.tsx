import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { SUPPORTED_CURRENCIES } from "@/lib/currencies";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate } from "@/lib/format";
import {
  Calculator,
  Plus,
  History,
  XCircle,
  Percent,
  DollarSign,
  Settings,
  Building2,
  Globe,
  Receipt,
  TrendingUp,
  ArrowRightLeft,
  Shield,
  Wallet,
  FileText, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface FeeSchedule {
  id: string;
  vehicleId: string | null;
  feeType: string;
  currency: string;
  method: string;
  rate: string;
  flatAmount: string;
  tiers: any;
  minFee: string | null;
  maxFee: string | null;
  version: number;
  isActive: boolean;
  effectiveFrom: string;
  effectiveTo: string | null;
  createdBy: string | null;
  createdAt: string;
  notes: string | null;
}

interface AppliedFee {
  id: string;
  feeScheduleId: string;
  feeScheduleVersion: number;
  feeType: string;
  vehicleId: string | null;
  userId: string | null;
  currency: string;
  grossAmount: string;
  feeAmount: string;
  netAmount: string;
  method: string;
  rate: string;
  referenceEntityType: string | null;
  referenceEntityId: string | null;
  description: string | null;
  createdAt: string;
}

interface Vehicle {
  id: string;
  name: string;
  type: string;
  status: string;
}

const MONETIZATION_FEE_TYPES = [
  { value: "acquisition", label: "Acquisition / Structuring", icon: Building2, category: "vehicle" },
  { value: "management", label: "Annual Management", icon: TrendingUp, category: "vehicle" },
  { value: "rental_processing", label: "Rental Processing", icon: Receipt, category: "vehicle" },
  { value: "property_sale", label: "Property Sale / Disposal", icon: Building2, category: "vehicle" },
  { value: "exit_trade_buyer", label: "Exit Trade (Buyer)", icon: ArrowRightLeft, category: "vehicle" },
  { value: "exit_trade_seller", label: "Exit Trade (Seller)", icon: ArrowRightLeft, category: "vehicle" },
  { value: "fx", label: "FX Conversion", icon: Globe, category: "global" },
  { value: "crypto_deposit", label: "Crypto Deposit", icon: Wallet, category: "global" },
  { value: "issuer_onboarding", label: "Issuer Onboarding", icon: FileText, category: "global" },
  { value: "withdrawal", label: "Withdrawal", icon: DollarSign, category: "global" },
  { value: "investment", label: "Investment", icon: Shield, category: "global" },
  { value: "trade", label: "Trade", icon: ArrowRightLeft, category: "global" },
  { value: "transfer", label: "Transfer", icon: ArrowRightLeft, category: "global" },
  { value: "redemption", label: "Redemption", icon: DollarSign, category: "global" },
];

const FEE_METHODS = [
  { value: "percentage", label: "Percentage", icon: Percent },
  { value: "flat", label: "Flat Amount", icon: DollarSign },
];

function formatRate(schedule: FeeSchedule): string {
  switch (schedule.method) {
    case "percentage":
      return `${(parseFloat(schedule.rate) * 100).toFixed(2)}%`;
    case "flat":
      return `${parseFloat(schedule.flatAmount).toFixed(2)} flat`;
    case "tiered":
      return "Tiered rates";
    default:
      return schedule.rate;
  }
}

function getMethodIcon(method: string) {
  const found = FEE_METHODS.find((m) => m.value === method);
  return found ? found.icon : Settings;
}

function getFeeIcon(feeType: string) {
  const found = MONETIZATION_FEE_TYPES.find((ft) => ft.value === feeType);
  return found ? found.icon : Calculator;
}

export default function AdminFees() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("schedules");
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [filterType, setFilterType] = useState<string>("all");
  const [filterScope, setFilterScope] = useState<string>("all");
  const [showHistoryDialog, setShowHistoryDialog] = useState(false);
  const [historyFeeType, setHistoryFeeType] = useState<string>("");

  const [newVehicleId, setNewVehicleId] = useState<string>("");
  const [newFeeType, setNewFeeType] = useState<string>("");
  const [newCurrency, setNewCurrency] = useState<string>("*");
  const [newMethod, setNewMethod] = useState<string>("percentage");
  const [newRate, setNewRate] = useState<string>("");
  const [newFlatAmount, setNewFlatAmount] = useState<string>("");
  const [newMinFee, setNewMinFee] = useState<string>("");
  const [newMaxFee, setNewMaxFee] = useState<string>("");
  const [newNotes, setNewNotes] = useState<string>("");

  const { data: schedules, isLoading } = useQuery<FeeSchedule[]>({
    queryKey: ["/api/admin/fees"],
  });

  const { data: vehicles } = useQuery<Vehicle[]>({
    queryKey: ["/api/admin/vehicles"],
  });

  const { data: appliedFees, isLoading: appliedLoading } = useQuery<AppliedFee[]>({
    queryKey: ["/api/admin/applied-fees"],
    enabled: activeTab === "applied",
  });

  const { data: history, isLoading: historyLoading } = useQuery<FeeSchedule[]>({
    queryKey: ["/api/admin/fees/history", historyFeeType],
    enabled: !!historyFeeType && showHistoryDialog,
    queryFn: async () => {
      const res = await fetch(`/api/admin/fees/history/${historyFeeType}`);
      if (!res.ok) throw new Error("Failed to fetch history");
      return res.json();
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/admin/fees", data);
      return res.json();
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/fees"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/applied-fees"] });
      setShowCreateDialog(false);
      resetForm();
      toast({
        title: "Fee Schedule Created",
        description: `Version ${result.version} of ${result.feeType} fee is now active.${result.vehicleId ? " (Vehicle-specific)" : " (Global default)"}`,
      });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to create fee schedule", variant: "destructive" });
    },
  });

  const deactivateMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("POST", `/api/admin/fees/${id}/deactivate`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/fees"] });
      toast({ title: "Fee Schedule Deactivated" });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to deactivate", variant: "destructive" });
    },
  });

  function resetForm() {
    setNewVehicleId("");
    setNewFeeType("");
    setNewCurrency("*");
    setNewMethod("percentage");
    setNewRate("");
    setNewFlatAmount("");
    setNewMinFee("");
    setNewMaxFee("");
    setNewNotes("");
  }

  function handleCreate() {
    if (!newFeeType) {
      toast({ title: "Error", description: "Please select a fee type", variant: "destructive" });
      return;
    }

    const data: any = {
      feeType: newFeeType,
      currency: newCurrency || "*",
      method: newMethod,
      notes: newNotes || null,
      vehicleId: newVehicleId || null,
    };

    if (newMethod === "percentage") {
      const rateVal = parseFloat(newRate);
      if (isNaN(rateVal) || rateVal < 0 || rateVal > 1) {
        toast({ title: "Error", description: "Rate must be between 0 and 1 (e.g. 0.02 for 2%)", variant: "destructive" });
        return;
      }
      data.rate = newRate;
      data.flatAmount = "0";
    } else if (newMethod === "flat") {
      const flatVal = parseFloat(newFlatAmount);
      if (isNaN(flatVal) || flatVal < 0) {
        toast({ title: "Error", description: "Flat amount must be a positive number", variant: "destructive" });
        return;
      }
      data.rate = "0";
      data.flatAmount = newFlatAmount;
    }

    if (newMinFee) data.minFee = newMinFee;
    if (newMaxFee) data.maxFee = newMaxFee;

    createMutation.mutate(data);
  }

  const activeSchedules = (schedules || []).filter((s) => s.isActive);
  const filteredSchedules = (schedules || []).filter((s) => {
    if (filterType !== "all" && s.feeType !== filterType) return false;
    if (filterScope === "global" && s.vehicleId) return false;
    if (filterScope === "vehicle" && !s.vehicleId) return false;
    return true;
  });

  const vehicleMap = new Map<string, Vehicle>();
  (vehicles || []).forEach(v => vehicleMap.set(v.id, v));

  const vehicleFeeTypes = MONETIZATION_FEE_TYPES.filter(ft => ft.category === "vehicle");
  const globalFeeTypes = MONETIZATION_FEE_TYPES.filter(ft => ft.category === "global");

  const totalRevenue = (appliedFees || []).reduce((sum, f) => sum + parseFloat(f.feeAmount || "0"), 0);

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Fee Engine"
          description="Configure per-vehicle and global fee schedules. All fees are versioned and auditable."
        />
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList data-testid="fee-tabs">
            <TabsTrigger value="schedules" data-testid="tab-schedules">Schedules</TabsTrigger>
            <TabsTrigger value="applied" data-testid="tab-applied">Applied Fees</TabsTrigger>
          </TabsList>

          <TabsContent value="schedules" className="space-y-6 mt-4">
            <Section title="Vehicle Fee Schedules" description="Per-fund/SPV fees: acquisition, management, rental processing, exit trading">
              {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-32 rounded-md" />)}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {vehicleFeeTypes.map(({ value, label, icon: Icon }) => {
                    const active = activeSchedules.filter(s => s.feeType === value);
                    const globalOnes = active.filter(s => !s.vehicleId);
                    const vehicleOnes = active.filter(s => s.vehicleId);

                    return (
                      <GlassCard key={value} padding="md" data-testid={`fee-card-${value}`}>
                        <div className="flex items-start justify-between gap-2 mb-3">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                              <Icon className="w-4 h-4 text-primary" />
                            </div>
                            <div>
                              <p className="text-sm font-semibold" data-testid={`fee-type-label-${value}`}>{label}</p>
                              <p className="text-xs text-muted-foreground">
                                {globalOnes.length > 0 ? `Global default: ${formatRate(globalOnes[0])}` : "No global default"}
                              </p>
                            </div>
                          </div>
                          <Badge
                            variant={active.length > 0 ? "default" : "outline"}
                            className="no-default-hover-elevate"
                          >
                            {active.length > 0 ? `${active.length} active` : "None"}
                          </Badge>
                        </div>

                        {vehicleOnes.length > 0 && (
                          <div className="space-y-1 mb-2">
                            {vehicleOnes.slice(0, 3).map(s => {
                              const v = vehicleMap.get(s.vehicleId!);
                              return (
                                <div key={s.id} className="flex justify-between text-xs">
                                  <span className="text-muted-foreground truncate max-w-[60%]">{v?.name || s.vehicleId}</span>
                                  <span className="font-medium">{formatRate(s)}</span>
                                </div>
                              );
                            })}
                            {vehicleOnes.length > 3 && (
                              <p className="text-xs text-muted-foreground">+{vehicleOnes.length - 3} more</p>
                            )}
                          </div>
                        )}

                        <div className="flex items-center gap-1.5 mt-3 pt-3 border-t flex-wrap">
                          <Button size="sm" variant="outline" onClick={() => { setHistoryFeeType(value); setShowHistoryDialog(true); }} data-testid={`button-history-${value}`}>
                            <History className="w-3.5 h-3.5 mr-1" />
                            History
                          </Button>
                        </div>
                      </GlassCard>
                    );
                  })}
                </div>
              )}
            </Section>

            <Section title="Global Fee Schedules" description="Platform-wide fees: FX, crypto, withdrawal, investment, trading, onboarding">
              {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {[...Array(6)].map((_, i) => <Skeleton key={i} className="h-32 rounded-md" />)}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {globalFeeTypes.map(({ value, label, icon: Icon }) => {
                    const schedule = activeSchedules.find(s => s.feeType === value && !s.vehicleId);
                    return (
                      <GlassCard key={value} padding="md" data-testid={`fee-card-${value}`}>
                        <div className="flex items-start justify-between gap-2 mb-3">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                              <Icon className="w-4 h-4 text-primary" />
                            </div>
                            <div>
                              <p className="text-sm font-semibold">{label}</p>
                              <p className="text-xs text-muted-foreground">
                                {schedule ? `v${schedule.version}` : "Not configured"}
                              </p>
                            </div>
                          </div>
                          {schedule ? (
                            <Badge variant="default" className="no-default-hover-elevate">Active</Badge>
                          ) : (
                            <Badge variant="outline" className="no-default-hover-elevate">None</Badge>
                          )}
                        </div>

                        {schedule ? (
                          <div className="space-y-1.5">
                            <div className="flex justify-between text-xs">
                              <span className="text-muted-foreground">Rate</span>
                              <span className="font-medium">{formatRate(schedule)}</span>
                            </div>
                            <div className="flex justify-between text-xs">
                              <span className="text-muted-foreground">Method</span>
                              <span className="font-medium capitalize">{schedule.method}</span>
                            </div>
                            <div className="flex justify-between text-xs">
                              <span className="text-muted-foreground">Currency</span>
                              <span className="font-medium">{schedule.currency === "*" ? "All" : schedule.currency}</span>
                            </div>
                          </div>
                        ) : (
                          <p className="text-xs text-muted-foreground">No active fee schedule. Zero fees for this type.</p>
                        )}

                        <div className="flex items-center gap-1.5 mt-3 pt-3 border-t flex-wrap">
                          <Button size="sm" variant="outline" onClick={() => { setHistoryFeeType(value); setShowHistoryDialog(true); }} data-testid={`button-history-${value}`}>
                            <History className="w-3.5 h-3.5 mr-1" />
                            History
                          </Button>
                          {schedule && (
                            <Button size="sm" variant="outline" onClick={() => deactivateMutation.mutate(schedule.id)} disabled={deactivateMutation.isPending} data-testid={`button-deactivate-${value}`}>
                              <XCircle className="w-3.5 h-3.5 mr-1" />
                              Deactivate
                            </Button>
                          )}
                        </div>
                      </GlassCard>
                    );
                  })}
                </div>
              )}
            </Section>

            <Section
              title="All Fee Versions"
              description="Complete history of fee schedule changes across all vehicles"
              action={
                <div className="flex items-center gap-1.5 flex-wrap">
                  <Button size="sm" onClick={() => { setShowCreateDialog(true); resetForm(); }} data-testid="button-create-fee">
                    <Plus className="w-3.5 h-3.5 mr-1" />
                    New Fee Schedule
                  </Button>
                  <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger className="w-40" data-testid="select-filter-type">
                      <SelectValue placeholder="Filter type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      {MONETIZATION_FEE_TYPES.map((ft) => (
                        <SelectItem key={ft.value} value={ft.value}>{ft.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={filterScope} onValueChange={setFilterScope}>
                    <SelectTrigger className="w-32" data-testid="select-filter-scope">
                      <SelectValue placeholder="Filter scope" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Scopes</SelectItem>
                      <SelectItem value="global">Global</SelectItem>
                      <SelectItem value="vehicle">Vehicle</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              }
            >
              {isLoading ? (
                <div className="space-y-3">
                  {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-20 rounded-md" />)}
                </div>
              ) : filteredSchedules.length === 0 ? (
                <GlassCard>
                  <div className="text-center py-8 text-muted-foreground">
                    <Calculator className="w-10 h-10 mx-auto mb-3 opacity-50" />
                    <p className="text-sm">No fee schedules found</p>
                  </div>
                </GlassCard>
              ) : (
                <div className="space-y-2">
                  {filteredSchedules.map((schedule) => {
                    const MethodIcon = getMethodIcon(schedule.method);
                    const FeeIcon = getFeeIcon(schedule.feeType);
                    const typeLabel = MONETIZATION_FEE_TYPES.find((ft) => ft.value === schedule.feeType)?.label || schedule.feeType;
                    const vehicle = schedule.vehicleId ? vehicleMap.get(schedule.vehicleId) : null;
                    return (
                      <GlassCard key={schedule.id} padding="sm" data-testid={`fee-schedule-row-${schedule.id}`}>
                        <div className="flex items-center justify-between gap-3 flex-wrap">
                          <div className="flex items-center gap-3 min-w-0">
                            <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                              <FeeIcon className="w-4 h-4 text-primary" />
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-sm font-semibold">{typeLabel}</span>
                                <Badge variant={schedule.isActive ? "default" : "outline"} className="no-default-hover-elevate">
                                  {schedule.isActive ? "Active" : `v${schedule.version}`}
                                </Badge>
                                {schedule.isActive && (
                                  <Badge variant="secondary" className="no-default-hover-elevate">v{schedule.version}</Badge>
                                )}
                                {schedule.vehicleId ? (
                                  <Badge variant="outline" className="no-default-hover-elevate">
                                    <Building2 className="w-3 h-3 mr-1" />
                                    {vehicle?.name || schedule.vehicleId.slice(0, 8)}
                                  </Badge>
                                ) : (
                                  <Badge variant="outline" className="no-default-hover-elevate">
                                    <Globe className="w-3 h-3 mr-1" />
                                    Global
                                  </Badge>
                                )}
                              </div>
                              <div className="flex gap-x-3 gap-y-0.5 text-xs text-muted-foreground mt-0.5 flex-wrap">
                                <span>Rate: <span className="font-medium text-foreground">{formatRate(schedule)}</span></span>
                                <span>Currency: <span className="font-medium text-foreground">{schedule.currency === "*" ? "All" : schedule.currency}</span></span>
                                <span>{formatDate(schedule.createdAt, "long")}</span>
                              </div>
                              {schedule.notes && (
                                <p className="text-xs text-muted-foreground mt-0.5 italic">{schedule.notes}</p>
                              )}
                            </div>
                          </div>
                          {schedule.isActive && (
                            <Button size="sm" variant="outline" onClick={() => deactivateMutation.mutate(schedule.id)} disabled={deactivateMutation.isPending}>
                              <XCircle className="w-3.5 h-3.5 mr-1" />
                              Deactivate
                            </Button>
                          )}
                        </div>
                      </GlassCard>
                    );
                  })}
                </div>
              )}
            </Section>
          </TabsContent>

          <TabsContent value="applied" className="space-y-6 mt-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Fees Collected</CardTitle>
                  <DollarSign className="w-4 h-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold" data-testid="text-total-revenue">${totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  <p className="text-xs text-muted-foreground">{(appliedFees || []).length} fee records</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Fee Types Active</CardTitle>
                  <Calculator className="w-4 h-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">{new Set((appliedFees || []).map(f => f.feeType)).size}</p>
                  <p className="text-xs text-muted-foreground">Distinct types charged</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Schedules</CardTitle>
                  <Settings className="w-4 h-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold">{activeSchedules.length}</p>
                  <p className="text-xs text-muted-foreground">Across all vehicles</p>
                </CardContent>
              </Card>
            </div>

            <Section title="Applied Fee Ledger" description="Immutable record of all fees charged">
              {appliedLoading ? (
                <div className="space-y-2">
                  {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-16 rounded-md" />)}
                </div>
              ) : !appliedFees || appliedFees.length === 0 ? (
                <GlassCard>
                  <div className="text-center py-8 text-muted-foreground">
                    <Receipt className="w-10 h-10 mx-auto mb-3 opacity-50" />
                    <p className="text-sm">No fees have been applied yet</p>
                    <p className="text-xs mt-1">Fees will appear here as transactions are processed.</p>
                  </div>
                </GlassCard>
              ) : (
                <div className="space-y-2">
                  {appliedFees.map((fee) => {
                    const FeeIcon = getFeeIcon(fee.feeType);
                    const typeLabel = MONETIZATION_FEE_TYPES.find(ft => ft.value === fee.feeType)?.label || fee.feeType;
                    const vehicle = fee.vehicleId ? vehicleMap.get(fee.vehicleId) : null;
                    return (
                      <GlassCard key={fee.id} padding="sm" data-testid={`applied-fee-row-${fee.id}`}>
                        <div className="flex items-center justify-between gap-3 flex-wrap">
                          <div className="flex items-center gap-3 min-w-0">
                            <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                              <FeeIcon className="w-4 h-4 text-primary" />
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-sm font-semibold">{typeLabel}</span>
                                {vehicle && (
                                  <Badge variant="outline" className="no-default-hover-elevate">
                                    <Building2 className="w-3 h-3 mr-1" />
                                    {vehicle.name}
                                  </Badge>
                                )}
                              </div>
                              <div className="flex gap-x-3 gap-y-0.5 text-xs text-muted-foreground mt-0.5 flex-wrap">
                                <span>Gross: <span className="font-medium text-foreground">{parseFloat(fee.grossAmount).toFixed(2)} {fee.currency}</span></span>
                                <span>Fee: <span className="font-medium text-foreground">{parseFloat(fee.feeAmount).toFixed(2)}</span></span>
                                <span>Net: <span className="font-medium text-foreground">{parseFloat(fee.netAmount).toFixed(2)}</span></span>
                                <span>{formatDate(fee.createdAt, "long")}</span>
                              </div>
                              {fee.description && (
                                <p className="text-xs text-muted-foreground mt-0.5 italic">{fee.description}</p>
                              )}
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-bold text-primary" data-testid={`applied-fee-amount-${fee.id}`}>
                              {parseFloat(fee.feeAmount).toFixed(2)} {fee.currency}
                            </p>
                            <p className="text-xs text-muted-foreground capitalize">{fee.method} @ {(parseFloat(fee.rate) * 100).toFixed(2)}%</p>
                          </div>
                        </div>
                      </GlassCard>
                    );
                  })}
                </div>
              )}
            </Section>
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={showCreateDialog} onOpenChange={(open) => { if (!open) setShowCreateDialog(false); }}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto" data-testid="create-fee-dialog">
          <DialogHeader>
            <DialogTitle>Create Fee Schedule</DialogTitle>
            <DialogDescription>
              Creating a new version automatically deactivates the previous active schedule for the same type, currency, and scope.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Scope</label>
              <Select value={newVehicleId || "__global__"} onValueChange={(v) => setNewVehicleId(v === "__global__" ? "" : v)}>
                <SelectTrigger data-testid="select-new-scope">
                  <SelectValue placeholder="Select scope" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__global__">
                    <div className="flex items-center gap-2">
                      <Globe className="w-3.5 h-3.5" />
                      <span>Global Default</span>
                    </div>
                  </SelectItem>
                  {(vehicles || []).map(v => (
                    <SelectItem key={v.id} value={v.id}>
                      <div className="flex items-center gap-2">
                        <Building2 className="w-3.5 h-3.5" />
                        <span>{v.name} ({v.type})</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {newVehicleId && (
                <p className="text-xs text-muted-foreground mt-1">
                  This fee will override the global default for the selected vehicle only.
                </p>
              )}
            </div>

            <div>
              <label className="text-sm font-medium mb-1.5 block">Fee Type</label>
              <Select value={newFeeType} onValueChange={setNewFeeType}>
                <SelectTrigger data-testid="select-new-fee-type">
                  <SelectValue placeholder="Select fee type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__header_vehicle__" disabled>
                    <span className="text-xs font-semibold text-muted-foreground">VEHICLE FEES</span>
                  </SelectItem>
                  {vehicleFeeTypes.map((ft) => (
                    <SelectItem key={ft.value} value={ft.value}>{ft.label}</SelectItem>
                  ))}
                  <SelectItem value="__header_global__" disabled>
                    <span className="text-xs font-semibold text-muted-foreground">PLATFORM FEES</span>
                  </SelectItem>
                  {globalFeeTypes.map((ft) => (
                    <SelectItem key={ft.value} value={ft.value}>{ft.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-1.5 block">Currency</label>
              <Select value={newCurrency} onValueChange={setNewCurrency}>
                <SelectTrigger data-testid="select-new-currency">
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="*">All Currencies</SelectItem>
                  {[...SUPPORTED_CURRENCIES].map(c => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-1.5 block">Method</label>
              <Select value={newMethod} onValueChange={setNewMethod}>
                <SelectTrigger data-testid="select-new-method">
                  <SelectValue placeholder="Select method" />
                </SelectTrigger>
                <SelectContent>
                  {FEE_METHODS.map((m) => (
                    <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {newMethod === "percentage" && (
              <div>
                <label className="text-sm font-medium mb-1.5 block">Rate (decimal)</label>
                <Input
                  placeholder="e.g. 0.02 for 2%"
                  value={newRate}
                  onChange={(e) => setNewRate(e.target.value)}
                  data-testid="input-new-rate"
                />
                {newRate && !isNaN(parseFloat(newRate)) && (
                  <p className="text-xs text-muted-foreground mt-1">
                    = {(parseFloat(newRate) * 100).toFixed(2)}% per transaction
                  </p>
                )}
              </div>
            )}

            {newMethod === "flat" && (
              <div>
                <label className="text-sm font-medium mb-1.5 block">Flat Amount</label>
                <Input
                  placeholder="e.g. 500.00"
                  value={newFlatAmount}
                  onChange={(e) => setNewFlatAmount(e.target.value)}
                  data-testid="input-new-flat-amount"
                />
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-sm font-medium mb-1.5 block">Min Fee (optional)</label>
                <Input
                  placeholder="e.g. 10.00"
                  value={newMinFee}
                  onChange={(e) => setNewMinFee(e.target.value)}
                  data-testid="input-min-fee"
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1.5 block">Max Fee (optional)</label>
                <Input
                  placeholder="e.g. 5000.00"
                  value={newMaxFee}
                  onChange={(e) => setNewMaxFee(e.target.value)}
                  data-testid="input-max-fee"
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-medium mb-1.5 block">Notes (optional)</label>
              <Textarea
                placeholder="Reason for this fee configuration..."
                value={newNotes}
                onChange={(e) => setNewNotes(e.target.value)}
                data-testid="input-fee-notes"
              />
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowCreateDialog(false)}>Cancel</Button>
              <Button
                onClick={handleCreate}
                disabled={createMutation.isPending || !newFeeType}
                data-testid="button-submit-fee"
              >
                {createMutation.isPending ? "Creating..." : "Create Fee Schedule"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showHistoryDialog} onOpenChange={(open) => { if (!open) { setShowHistoryDialog(false); setHistoryFeeType(""); } }}>
        <DialogContent className="max-w-lg" data-testid="fee-history-dialog">
          <DialogHeader>
            <DialogTitle>Fee History: {MONETIZATION_FEE_TYPES.find((ft) => ft.value === historyFeeType)?.label || historyFeeType}</DialogTitle>
            <DialogDescription>
              Complete version history for this fee type across all scopes.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {historyLoading ? (
              [...Array(3)].map((_, i) => <Skeleton key={i} className="h-16 rounded-md" />)
            ) : !history || history.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">No version history found.</p>
            ) : (
              history.map((h) => {
                const vehicle = h.vehicleId ? vehicleMap.get(h.vehicleId) : null;
                return (
                  <GlassCard key={h.id} padding="sm" data-testid={`history-row-${h.id}`}>
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm font-semibold">v{h.version}</span>
                          <Badge variant={h.isActive ? "default" : "outline"} className="no-default-hover-elevate">
                            {h.isActive ? "Active" : "Inactive"}
                          </Badge>
                          {h.vehicleId ? (
                            <Badge variant="outline" className="no-default-hover-elevate">
                              <Building2 className="w-3 h-3 mr-1" />
                              {vehicle?.name || h.vehicleId.slice(0, 8)}
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="no-default-hover-elevate">
                              <Globe className="w-3 h-3 mr-1" />
                              Global
                            </Badge>
                          )}
                        </div>
                        <div className="flex gap-x-3 text-xs text-muted-foreground mt-0.5 flex-wrap">
                          <span>Rate: {formatRate(h)}</span>
                          <span>Method: {h.method}</span>
                          <span>{formatDate(h.createdAt, "long")}</span>
                        </div>
                        {h.notes && <p className="text-xs text-muted-foreground mt-0.5 italic">{h.notes}</p>}
                      </div>
                    </div>
                  </GlassCard>
                );
              })
            )}
          </div>
        </DialogContent>
      </Dialog>
    </RoleLayout>
  );
}
