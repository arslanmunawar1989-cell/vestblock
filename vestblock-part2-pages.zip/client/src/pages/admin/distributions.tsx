import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { StatTile } from "@/components/stat-tile";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { WALLET_CURRENCIES, CURRENCY_DETAILS } from "@shared/constants";
import { formatCurrency, formatDate } from "@/lib/format";
import { Banknote, Layers, DollarSign, Hash, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
interface Distribution {
  id: string;
  assetId: string;
  roundId: string | null;
  amount: string;
  currency: string;
  distributionDate: string;
  type: string;
  status: string;
  notes: string | null;
  createdAt: string;
  asset: { id: string; name: string; symbol: string } | null;
}

export default function AdminDistributions() {
  const [currencyFilter, setCurrencyFilter] = useState<string>("all");

  const { data: distributions, isLoading } = useQuery<Distribution[]>({
    queryKey: ["/api/admin/distributions"],
  });

  const relevant = currencyFilter === "all"
    ? (distributions || [])
    : (distributions || []).filter(d => d.currency === currencyFilter);

  const totalAmount = relevant.reduce((sum, d) => sum + (parseFloat(d.amount) || 0), 0);
  const uniqueAssets = new Set(relevant.map(d => d.assetId)).size;
  const completedCount = relevant.filter(d => d.status === "COMPLETED" || d.status === "CREDITED").length;

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle title="Distributions" description="Manage dividend and distribution payouts" />
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <Select value={currencyFilter} onValueChange={setCurrencyFilter}>
            <SelectTrigger className="w-[160px]" data-testid="select-currency-filter">
              <SelectValue placeholder="All Currencies" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Currencies</SelectItem>
              {WALLET_CURRENCIES.map(cur => (
                <SelectItem key={cur} value={cur}>{CURRENCY_DETAILS[cur].symbol} {cur}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatTile
            label="Total Distributions"
            value={String(relevant.length)}
            icon={<Hash className="w-5 h-5" />}
          />
          <StatTile
            label="Total Amount"
            value={currencyFilter !== "all" ? formatCurrency(totalAmount, currencyFilter) : String(relevant.length)}
            icon={<DollarSign className="w-5 h-5" />}
          />
          <StatTile
            label="Unique Assets"
            value={String(uniqueAssets)}
            icon={<Layers className="w-5 h-5" />}
          />
          <StatTile
            label="Credited"
            value={String(completedCount)}
            icon={<Banknote className="w-5 h-5" />}
          />
        </div>

        <Section title="Distribution History">
          <GlassCard>
            {isLoading ? (
              <div className="space-y-3">
                {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
              </div>
            ) : relevant.length === 0 ? (
              <p className="text-muted-foreground text-center py-8" data-testid="text-no-distributions">No distributions found</p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Asset</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Currency</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {relevant.map((d) => (
                      <TableRow key={d.id} data-testid={`row-distribution-${d.id}`}>
                        <TableCell className="font-medium">{d.asset?.name || d.assetId}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-xs">{d.type}</Badge>
                        </TableCell>
                        <TableCell>{formatCurrency(d.amount, d.currency)}</TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="text-xs">{d.currency}</Badge>
                        </TableCell>
                        <TableCell>{formatDate(d.distributionDate || d.createdAt)}</TableCell>
                        <TableCell>
                          <Badge
                            variant={d.status === "COMPLETED" || d.status === "CREDITED" ? "default" : "secondary"}
                            className="text-xs"
                          >
                            {d.status}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </GlassCard>
        </Section>
      </div>
    </RoleLayout>
  );
}
