import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { StatTile } from "@/components/stat-tile";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { formatCurrency } from "@/lib/format";
import { WALLET_CURRENCIES, CURRENCY_DETAILS } from "@shared/constants";
import {
  Download,
  AlertTriangle,
  CheckCircle2,
  ArrowDownCircle,
  ArrowUpCircle,
  RefreshCcw,
  DollarSign, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface DailyTotals {
  currency: string;
  date: string;
  deposits: { count: number; total: number };
  withdrawals: { count: number; total: number };
  fxConversionsIn: { count: number; total: number };
  fxConversionsOut: { count: number; total: number };
  investments: { count: number; total: number };
  dividends: { count: number; total: number };
  fees: { count: number; total: number };
  trades: { buyCount: number; buyTotal: number; sellCount: number; sellTotal: number };
  netFlow: number;
  ledgerBalance: number;
  walletBalance: number;
  discrepancy: number;
  hasDiscrepancy: boolean;
}

function todayStr(): string {
  return new Date().toISOString().split("T")[0];
}

export default function AdminReconciliation() {
  const [date, setDate] = useState(todayStr());
  const [currency, setCurrency] = useState<string>("all");

  const queryParams = currency === "all"
    ? `/api/admin/reconciliation/daily?date=${date}`
    : `/api/admin/reconciliation/daily?date=${date}&currency=${currency}`;

  const { data: reconciliation, isLoading } = useQuery<DailyTotals[]>({
    queryKey: [queryParams],
  });

  const data = reconciliation || [];
  const totalDiscrepancies = data.filter(d => d.hasDiscrepancy).length;
  const totalDeposits = data.reduce((s, d) => s + d.deposits.total, 0);
  const totalWithdrawals = data.reduce((s, d) => s + d.withdrawals.total, 0);
  const totalFxVolume = data.reduce((s, d) => s + d.fxConversionsIn.total + d.fxConversionsOut.total, 0);
  const totalNetFlow = data.reduce((s, d) => s + d.netFlow, 0);

  function handleExport() {
    const params = new URLSearchParams({ date });
    if (currency !== "all") params.set("currency", currency);
    window.open(`/api/admin/reconciliation/export?${params.toString()}`, "_blank");
  }

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <Link href="/admin/dashboard">
              <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <PageTitle title="Finance Reconciliation" description="Daily reconciliation totals by currency with discrepancy detection" />
          </div>
          <Button onClick={handleExport} data-testid="button-export-csv">
            <Download className="w-4 h-4 mr-1" /> Export CSV
          </Button>
        </div>

        <GlassCard>
          <div className="flex items-end gap-4 flex-wrap">
            <div>
              <Label>Date</Label>
              <Input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                data-testid="input-recon-date"
              />
            </div>
            <div>
              <Label>Currency</Label>
              <Select value={currency} onValueChange={setCurrency}>
                <SelectTrigger className="w-[160px]" data-testid="select-recon-currency">
                  <SelectValue placeholder="All Currencies" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Currencies</SelectItem>
                  {WALLET_CURRENCIES.map(c => (
                    <SelectItem key={c} value={c}>{CURRENCY_DETAILS[c].symbol} {c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </GlassCard>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <StatTile
            label="Total Deposits"
            value={isLoading ? "..." : totalDeposits.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            icon={<ArrowDownCircle className="w-5 h-5" />}
          />
          <StatTile
            label="Total Withdrawals"
            value={isLoading ? "..." : totalWithdrawals.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            icon={<ArrowUpCircle className="w-5 h-5" />}
          />
          <StatTile
            label="FX Volume"
            value={isLoading ? "..." : totalFxVolume.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            icon={<RefreshCcw className="w-5 h-5" />}
          />
          <StatTile
            label="Net Flow"
            value={isLoading ? "..." : totalNetFlow.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            icon={<DollarSign className="w-5 h-5" />}
          />
          <StatTile
            label="Discrepancies"
            value={isLoading ? "..." : String(totalDiscrepancies)}
            icon={totalDiscrepancies > 0 ? <AlertTriangle className="w-5 h-5" /> : <CheckCircle2 className="w-5 h-5" />}
          />
        </div>

        <Section title={`Reconciliation for ${date}`}>
          <GlassCard>
            {isLoading ? (
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
              </div>
            ) : data.length === 0 ? (
              <p className="text-muted-foreground text-center py-8" data-testid="text-no-data">No reconciliation data for this date</p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Currency</TableHead>
                      <TableHead>Deposits</TableHead>
                      <TableHead>Withdrawals</TableHead>
                      <TableHead>FX In</TableHead>
                      <TableHead>FX Out</TableHead>
                      <TableHead>Investments</TableHead>
                      <TableHead>Dividends</TableHead>
                      <TableHead>Fees</TableHead>
                      <TableHead>Net Flow</TableHead>
                      <TableHead>Ledger Balance</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.map((row) => (
                      <TableRow key={row.currency} data-testid={`row-recon-${row.currency}`}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            <span>{CURRENCY_DETAILS[row.currency as keyof typeof CURRENCY_DETAILS]?.symbol || ""}</span>
                            <span>{row.currency}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="text-sm">{formatCurrency(row.deposits.total, row.currency)}</span>
                            <span className="text-xs text-muted-foreground">{row.deposits.count} txns</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="text-sm">{formatCurrency(row.withdrawals.total, row.currency)}</span>
                            <span className="text-xs text-muted-foreground">{row.withdrawals.count} txns</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="text-sm">{formatCurrency(row.fxConversionsIn.total, row.currency)}</span>
                            <span className="text-xs text-muted-foreground">{row.fxConversionsIn.count} txns</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="text-sm">{formatCurrency(row.fxConversionsOut.total, row.currency)}</span>
                            <span className="text-xs text-muted-foreground">{row.fxConversionsOut.count} txns</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="text-sm">{formatCurrency(row.investments.total, row.currency)}</span>
                            <span className="text-xs text-muted-foreground">{row.investments.count} txns</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="text-sm">{formatCurrency(row.dividends.total, row.currency)}</span>
                            <span className="text-xs text-muted-foreground">{row.dividends.count} txns</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="text-sm">{formatCurrency(row.fees.total, row.currency)}</span>
                            <span className="text-xs text-muted-foreground">{row.fees.count} txns</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className={`text-sm font-medium ${row.netFlow >= 0 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}`}>
                            {row.netFlow >= 0 ? "+" : ""}{formatCurrency(row.netFlow, row.currency)}
                          </span>
                        </TableCell>
                        <TableCell>
                          <span className="text-sm font-medium">{formatCurrency(row.ledgerBalance, row.currency)}</span>
                        </TableCell>
                        <TableCell>
                          {row.hasDiscrepancy ? (
                            <div className="flex flex-col gap-1">
                              <Badge variant="destructive" className="text-xs">
                                <AlertTriangle className="w-3 h-3 mr-1" /> Discrepancy
                              </Badge>
                              <span className="text-xs text-muted-foreground">
                                {formatCurrency(row.discrepancy, row.currency)} off
                              </span>
                            </div>
                          ) : (
                            <Badge variant="secondary" className="text-xs">
                              <CheckCircle2 className="w-3 h-3 mr-1" /> Balanced
                            </Badge>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </GlassCard>
        </Section>

        {data.some(d => d.trades.buyCount > 0 || d.trades.sellCount > 0) && (
          <Section title="Trade Activity">
            <GlassCard>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Currency</TableHead>
                      <TableHead>Buy Count</TableHead>
                      <TableHead>Buy Total</TableHead>
                      <TableHead>Sell Count</TableHead>
                      <TableHead>Sell Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.filter(d => d.trades.buyCount > 0 || d.trades.sellCount > 0).map((row) => (
                      <TableRow key={`trade-${row.currency}`}>
                        <TableCell className="font-medium">{row.currency}</TableCell>
                        <TableCell>{row.trades.buyCount}</TableCell>
                        <TableCell>{formatCurrency(row.trades.buyTotal, row.currency)}</TableCell>
                        <TableCell>{row.trades.sellCount}</TableCell>
                        <TableCell>{formatCurrency(row.trades.sellTotal, row.currency)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </GlassCard>
          </Section>
        )}
      </div>
    </RoleLayout>
  );
}
