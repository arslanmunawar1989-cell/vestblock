import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { WALLET_CURRENCIES, CURRENCY_DETAILS } from "@shared/constants";
import { DEFAULT_CURRENCY } from "@/lib/currencies";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { StatTile } from "@/components/stat-tile";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatCurrency, formatDate } from "@/lib/format";
import {
  CheckCircle2,
  XCircle,
  Clock,
  RotateCcw,
  AlertCircle,
  Banknote,
  ArrowDownLeft,
  Search,
  FileCheck,
  ExternalLink,
  Image, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface PaymentIntentWithUser {
  id: string;
  userId: string;
  walletAccountId: string | null;
  amount: string;
  currency: string;
  countryCode: string | null;
  referenceCode: string | null;
  status: string;
  paymentMethod: string;
  provider: string;
  providerIntentId: string | null;
  providerResponse: Record<string, any> | null;
  fee: string;
  netAmount: string;
  reference: string | null;
  reconciliationId: string | null;
  reconciledAt: string | null;
  reconciledBy: string | null;
  proofDocumentUrl: string | null;
  failureReason: string | null;
  ledgerTxId: string | null;
  reversalLedgerTxId: string | null;
  reversedAt: string | null;
  reversalReason: string | null;
  bankAccountConfigId: string | null;
  expiresAt: string | null;
  confirmedAt: string | null;
  createdAt: string;
  user: { fullName: string; username: string; email: string } | null;
}

const STATUS_CONFIG: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline"; icon: typeof Clock }> = {
  CREATED: { label: "Awaiting Proof", variant: "outline", icon: Clock },
  PENDING: { label: "Proof Uploaded", variant: "secondary", icon: FileCheck },
  CONFIRMED: { label: "Confirmed", variant: "default", icon: CheckCircle2 },
  FAILED: { label: "Rejected", variant: "destructive", icon: XCircle },
  REVERSED: { label: "Reversed", variant: "secondary", icon: RotateCcw },
};

const METHOD_LABELS: Record<string, string> = {
  bank_transfer: "Bank Transfer",
  card: "Card",
  crypto: "Crypto",
  manual: "Manual",
  mobile_wallet: "Mobile Wallet",
  remittance: "Remittance",
  instant_transfer: "Instant Transfer",
  international_wire: "International Wire",
};

const PROVIDER_LABELS: Record<string, string> = {
  manual: "Bank Transfer",
  stripe: "Stripe",
  jazzcash: "JazzCash",
  easypaisa: "Easypaisa",
  raast: "Raast",
  taptap_send: "TapTap Send",
  pk_international_wire: "Int'l Wire",
};


function getReferenceCode(intent: PaymentIntentWithUser): string {
  return intent.referenceCode || `VB-${intent.id.slice(0, 8).toUpperCase()}`;
}

export default function AdminPayments() {
  const { toast } = useToast();
  const [showDetail, setShowDetail] = useState<PaymentIntentWithUser | null>(null);
  const [showConfirm, setShowConfirm] = useState<PaymentIntentWithUser | null>(null);
  const [showFail, setShowFail] = useState<PaymentIntentWithUser | null>(null);
  const [reconciliationId, setReconciliationId] = useState("");
  const [confirmNotes, setConfirmNotes] = useState("");
  const [failReason, setFailReason] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [currencyFilter, setCurrencyFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");

  const { data: intents, isLoading } = useQuery<PaymentIntentWithUser[]>({
    queryKey: ["/api/admin/payment-intents"],
  });

  const confirmMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      const res = await apiRequest("POST", `/api/admin/payment-intents/${id}/confirm`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Deposit Confirmed", description: "Funds have been credited to the investor's wallet." });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/payment-intents"] });
      setShowConfirm(null);
      setShowDetail(null);
      setReconciliationId("");
      setConfirmNotes("");
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to confirm payment", variant: "destructive" });
    },
  });

  const failMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      const res = await apiRequest("POST", `/api/admin/payment-intents/${id}/fail`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Deposit Rejected", description: "The deposit request has been rejected." });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/payment-intents"] });
      setShowFail(null);
      setShowDetail(null);
      setFailReason("");
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to reject payment", variant: "destructive" });
    },
  });

  const relevantIntents = currencyFilter === "all" ? (intents || []) : (intents || []).filter(i => i.currency === currencyFilter);
  const pendingCount = relevantIntents.filter(i => i.status === "PENDING").length;
  const awaitingProofCount = relevantIntents.filter(i => i.status === "CREATED").length;
  const confirmedCount = relevantIntents.filter(i => i.status === "CONFIRMED").length;
  const totalConfirmedAmount = relevantIntents
    .filter(i => i.status === "CONFIRMED")
    .reduce((sum, i) => sum + parseFloat(i.netAmount), 0);

  const filtered = (intents || []).filter(i => {
    if (statusFilter !== "all" && i.status !== statusFilter) return false;
    if (currencyFilter !== "all" && i.currency !== currencyFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const ref = getReferenceCode(i).toLowerCase();
      const name = i.user?.fullName?.toLowerCase() || "";
      const uname = i.user?.username?.toLowerCase() || "";
      if (!ref.includes(q) && !name.includes(q) && !uname.includes(q)) return false;
    }
    return true;
  });

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle title="Finance - Deposits" description="Review bank transfers and confirm deposits to credit investor wallets" />
        </div>

        {isLoading ? (
          <div className="space-y-4">
            <div className="grid gap-4 md:grid-cols-4">
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
            </div>
            <Skeleton className="h-64 w-full" />
          </div>
        ) : (
          <>
            <div className="grid gap-4 md:grid-cols-4">
              <StatTile
                label="Ready for Review"
                value={pendingCount.toString()}
                icon={<FileCheck className="w-5 h-5" />}
              />
              <StatTile
                label="Awaiting Proof"
                value={awaitingProofCount.toString()}
                icon={<Clock className="w-5 h-5" />}
              />
              <StatTile
                label="Confirmed"
                value={confirmedCount.toString()}
                icon={<CheckCircle2 className="w-5 h-5" />}
              />
              <StatTile
                label="Total Confirmed"
                value={totalConfirmedAmount > 0 ? formatCurrency(totalConfirmedAmount, currencyFilter !== "all" ? currencyFilter : DEFAULT_CURRENCY) : `${CURRENCY_DETAILS[currencyFilter !== "all" ? currencyFilter as any : DEFAULT_CURRENCY].symbol} 0.00`}
                icon={<Banknote className="w-5 h-5" />}
              />
            </div>

            <Section title="All Deposit Requests">
              <div className="flex flex-wrap items-center gap-3 mb-4">
                <div className="relative flex-1 min-w-[200px]">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by name, username, or reference..."
                    className="pl-9"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    data-testid="input-search-intents"
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-40" data-testid="select-status-filter">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="CREATED">Awaiting Proof</SelectItem>
                    <SelectItem value="PENDING">Proof Uploaded</SelectItem>
                    <SelectItem value="CONFIRMED">Confirmed</SelectItem>
                    <SelectItem value="FAILED">Rejected</SelectItem>
                    <SelectItem value="REVERSED">Reversed</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={currencyFilter} onValueChange={setCurrencyFilter}>
                  <SelectTrigger className="w-[160px]" data-testid="select-currency-filter">
                    <SelectValue placeholder="All Currencies" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Currencies</SelectItem>
                    {WALLET_CURRENCIES.map(cur => (
                      <SelectItem key={cur} value={cur}>{CURRENCY_DETAILS[cur].symbol} {cur}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <GlassCard>
                {filtered.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <ArrowDownLeft className="w-12 h-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">No deposit requests found</h3>
                    <p className="text-muted-foreground">
                      {statusFilter !== "all" ? "Try changing the status filter." : "No deposit requests have been created yet."}
                    </p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Reference</TableHead>
                        <TableHead>Investor</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Net</TableHead>
                        <TableHead>Proof</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filtered.map(intent => {
                        const config = STATUS_CONFIG[intent.status] || STATUS_CONFIG.CREATED;
                        const canAction = intent.status === "CREATED" || intent.status === "PENDING";
                        return (
                          <TableRow key={intent.id} data-testid={`row-admin-intent-${intent.id}`}>
                            <TableCell
                              className="font-mono text-sm cursor-pointer"
                              onClick={() => setShowDetail(intent)}
                              data-testid={`text-admin-ref-${intent.id}`}
                            >
                              {getReferenceCode(intent)}
                            </TableCell>
                            <TableCell>
                              <div>
                                <p className="font-medium text-sm">{intent.user?.fullName || "Unknown"}</p>
                                <p className="text-xs text-muted-foreground">@{intent.user?.username}</p>
                              </div>
                            </TableCell>
                            <TableCell className="font-medium">
                              {formatCurrency(intent.amount, intent.currency)}
                            </TableCell>
                            <TableCell className="font-medium">
                              {formatCurrency(intent.netAmount, intent.currency)}
                            </TableCell>
                            <TableCell>
                              {intent.proofDocumentUrl ? (
                                <Badge variant="secondary" data-testid={`badge-proof-${intent.id}`}>
                                  <FileCheck className="w-3 h-3 mr-1" />
                                  Yes
                                </Badge>
                              ) : (
                                <span className="text-xs text-muted-foreground">No</span>
                              )}
                            </TableCell>
                            <TableCell>
                              <Badge variant={config.variant} data-testid={`badge-status-${intent.id}`}>{config.label}</Badge>
                            </TableCell>
                            <TableCell className="text-muted-foreground text-sm">
                              {formatDate(intent.createdAt, "long")}
                            </TableCell>
                            <TableCell>
                              {canAction && (
                                <div className="flex items-center gap-1">
                                  <Button
                                    size="sm"
                                    onClick={() => setShowConfirm(intent)}
                                    data-testid={`button-confirm-${intent.id}`}
                                  >
                                    <CheckCircle2 className="w-3 h-3 mr-1" />
                                    Confirm
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="destructive"
                                    onClick={() => setShowFail(intent)}
                                    data-testid={`button-reject-${intent.id}`}
                                  >
                                    <XCircle className="w-3 h-3 mr-1" />
                                    Reject
                                  </Button>
                                </div>
                              )}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                )}
              </GlassCard>
            </Section>
          </>
        )}

        <Dialog open={!!showDetail} onOpenChange={() => setShowDetail(null)}>
          <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto" data-testid="dialog-admin-intent-detail">
            {showDetail && (
              <>
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2 flex-wrap">
                    Deposit Detail
                    <Badge variant={STATUS_CONFIG[showDetail.status]?.variant || "outline"}>
                      {STATUS_CONFIG[showDetail.status]?.label || showDetail.status}
                    </Badge>
                  </DialogTitle>
                  <DialogDescription className="font-mono">
                    {getReferenceCode(showDetail)}
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Investor</p>
                      <p className="font-medium">{showDetail.user?.fullName || "Unknown"}</p>
                      <p className="text-xs text-muted-foreground">@{showDetail.user?.username} · {showDetail.user?.email}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Amount</p>
                      <p className="text-lg font-bold">{formatCurrency(showDetail.amount, showDetail.currency)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Fee</p>
                      <p className="font-medium">{formatCurrency(showDetail.fee, showDetail.currency)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Net Credit</p>
                      <p className="font-medium">{formatCurrency(showDetail.netAmount, showDetail.currency)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Payment Method</p>
                      <p className="font-medium">{PROVIDER_LABELS[showDetail.provider] || METHOD_LABELS[showDetail.paymentMethod] || showDetail.paymentMethod}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Created</p>
                      <p className="font-medium">{formatDate(showDetail.createdAt, "long")}</p>
                    </div>
                  </div>

                  {showDetail.proofDocumentUrl && (
                    <Card data-testid="card-admin-proof">
                      <CardContent className="pt-4">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2 text-sm font-medium">
                            <Image className="w-4 h-4" />
                            Proof of Transfer
                          </div>
                          <a
                            href={showDetail.proofDocumentUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            data-testid="link-view-proof"
                          >
                            <Button size="sm" variant="outline">
                              <ExternalLink className="w-3 h-3 mr-1" />
                              View
                            </Button>
                          </a>
                        </div>
                        <div className="rounded overflow-hidden bg-muted">
                          <img
                            src={showDetail.proofDocumentUrl}
                            alt="Proof of transfer"
                            className="w-full max-h-64 object-contain"
                            onError={(e) => {
                              (e.target as HTMLImageElement).style.display = "none";
                              (e.target as HTMLImageElement).nextElementSibling?.classList.remove("hidden");
                            }}
                            data-testid="img-proof"
                          />
                          <div className="hidden p-4 text-center text-sm text-muted-foreground">
                            <FileCheck className="w-8 h-8 mx-auto mb-2" />
                            Document uploaded (click View to open)
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {showDetail.countryCode && (
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Country</p>
                      <Badge variant="outline" data-testid="text-admin-country">{showDetail.countryCode}</Badge>
                    </div>
                  )}

                  {showDetail.reference && (
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">User Reference</p>
                      <code className="text-sm bg-muted px-2 py-1 rounded block">{showDetail.reference}</code>
                    </div>
                  )}

                  {showDetail.reconciliationId && (
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Reconciliation ID</p>
                      <code className="text-sm bg-muted px-2 py-1 rounded block">{showDetail.reconciliationId}</code>
                    </div>
                  )}

                  {showDetail.ledgerTxId && (
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Ledger Transaction</p>
                      <code className="text-sm bg-muted px-2 py-1 rounded block" data-testid="text-admin-ledger-tx">{showDetail.ledgerTxId}</code>
                    </div>
                  )}

                  {showDetail.confirmedAt && (
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Confirmed</p>
                      <p className="text-sm">{formatDate(showDetail.confirmedAt, "long")}</p>
                    </div>
                  )}

                  {showDetail.providerResponse && Object.keys(showDetail.providerResponse).length > 0 && (
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">Provider Receipt</p>
                      <div className="bg-muted rounded p-2 space-y-1" data-testid="card-provider-receipt">
                        {Object.entries(showDetail.providerResponse).map(([key, value]) => (
                          <div key={key} className="flex justify-between text-xs">
                            <span className="text-muted-foreground capitalize">{key.replace(/([A-Z])/g, " $1").trim()}</span>
                            <span className="font-mono">{typeof value === "object" ? JSON.stringify(value) : String(value)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {showDetail.failureReason && (
                    <Card className="border-destructive">
                      <CardContent className="pt-4">
                        <div className="flex items-start gap-2">
                          <AlertCircle className="w-4 h-4 text-destructive mt-0.5" />
                          <div>
                            <p className="text-sm font-medium text-destructive">Rejection Reason</p>
                            <p className="text-sm text-muted-foreground">{showDetail.failureReason}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {(showDetail.status === "CREATED" || showDetail.status === "PENDING") && (
                    <DialogFooter className="gap-2">
                      <Button variant="destructive" onClick={() => { setShowDetail(null); setShowFail(showDetail); }}>
                        <XCircle className="w-4 h-4 mr-2" />
                        Reject
                      </Button>
                      <Button onClick={() => { setShowDetail(null); setShowConfirm(showDetail); }}>
                        <CheckCircle2 className="w-4 h-4 mr-2" />
                        Confirm Deposit
                      </Button>
                    </DialogFooter>
                  )}
                </div>
              </>
            )}
          </DialogContent>
        </Dialog>

        <Dialog open={!!showConfirm} onOpenChange={() => setShowConfirm(null)}>
          <DialogContent className="sm:max-w-md" data-testid="dialog-confirm-payment">
            {showConfirm && (
              <>
                <DialogHeader>
                  <DialogTitle>Confirm Deposit</DialogTitle>
                  <DialogDescription>
                    Confirm bank transfer of {formatCurrency(showConfirm.amount, showConfirm.currency)} from {showConfirm.user?.fullName || "Unknown"}.
                    This will credit {formatCurrency(showConfirm.netAmount, showConfirm.currency)} to their {showConfirm.currency} wallet.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Bank Reconciliation ID</Label>
                    <Input
                      placeholder="Bank statement transaction reference"
                      value={reconciliationId}
                      onChange={(e) => setReconciliationId(e.target.value)}
                      data-testid="input-reconciliation-id"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Notes (optional)</Label>
                    <Textarea
                      placeholder="Additional notes..."
                      value={confirmNotes}
                      onChange={(e) => setConfirmNotes(e.target.value)}
                      data-testid="input-confirm-notes"
                    />
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setShowConfirm(null)}>Cancel</Button>
                    <Button
                      onClick={() => confirmMutation.mutate({
                        id: showConfirm.id,
                        data: { reconciliationId: reconciliationId || undefined, notes: confirmNotes || undefined },
                      })}
                      disabled={confirmMutation.isPending}
                      data-testid="button-submit-confirm"
                    >
                      {confirmMutation.isPending ? "Confirming..." : "Confirm Deposit"}
                    </Button>
                  </DialogFooter>
                </div>
              </>
            )}
          </DialogContent>
        </Dialog>

        <Dialog open={!!showFail} onOpenChange={() => setShowFail(null)}>
          <DialogContent className="sm:max-w-md" data-testid="dialog-reject-payment">
            {showFail && (
              <>
                <DialogHeader>
                  <DialogTitle>Reject Deposit</DialogTitle>
                  <DialogDescription>
                    Reject bank transfer of {formatCurrency(showFail.amount, showFail.currency)} from {showFail.user?.fullName || "Unknown"}.
                    The investor will be notified.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Reason</Label>
                    <Textarea
                      placeholder="Reason for rejection..."
                      value={failReason}
                      onChange={(e) => setFailReason(e.target.value)}
                      data-testid="input-fail-reason"
                    />
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setShowFail(null)}>Cancel</Button>
                    <Button
                      variant="destructive"
                      onClick={() => failMutation.mutate({
                        id: showFail.id,
                        data: { reason: failReason || undefined },
                      })}
                      disabled={failMutation.isPending}
                      data-testid="button-submit-reject"
                    >
                      {failMutation.isPending ? "Rejecting..." : "Reject Deposit"}
                    </Button>
                  </DialogFooter>
                </div>
              </>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </RoleLayout>
  );
}
