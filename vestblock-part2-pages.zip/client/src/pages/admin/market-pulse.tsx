import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import {
  BarChart3, Play, Loader2, CheckCircle,
  FileText, Eye, Send, ArrowLeft,
  TrendingUp, Building2, ArrowUpDown,
  Info,
} from "lucide-react";

interface Report {
  id: string;
  weekStart: string;
  weekEnd: string;
  region: string;
  status: string;
  narrativeMd: string | null;
  highlightsJson: string[] | null;
  metricsSnapshotId: string | null;
  createdAt: string;
}

interface Snapshot {
  id: string;
  metricsJson: any;
}

export default function AdminMarketPulse() {
  const { toast } = useToast();
  const [selectedReport, setSelectedReport] = useState<string | null>(null);

  const reportsQuery = useQuery<{ ok: boolean; reports: Report[] }>({
    queryKey: ["/api/ai/market-pulse/reports"],
  });

  const detailQuery = useQuery<{ ok: boolean; report: Report; snapshot: Snapshot | null }>({
    queryKey: ["/api/ai/market-pulse/reports", selectedReport],
    enabled: !!selectedReport,
  });

  const generateMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/ai/market-pulse/run", { region: "PK" });
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: "Report Generated", description: `Weekly digest for ${data.report.weekStart} to ${data.report.weekEnd} created.` });
      queryClient.invalidateQueries({ queryKey: ["/api/ai/market-pulse/reports"] });
      setSelectedReport(data.report.id);
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to generate report. Please try again.", variant: "destructive" });
    },
  });

  const publishMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("PATCH", `/api/ai/market-pulse/reports/${id}/publish`, {});
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Published", description: "Report is now visible on the public market pulse page." });
      queryClient.invalidateQueries({ queryKey: ["/api/ai/market-pulse/reports"] });
      if (selectedReport) queryClient.invalidateQueries({ queryKey: ["/api/ai/market-pulse/reports", selectedReport] });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to publish report.", variant: "destructive" });
    },
  });

  const reports = reportsQuery.data?.reports || [];
  const detail = detailQuery.data;

  if (selectedReport && detail) {
    return (
      <RoleLayout role="admin" title="Market Pulse">
        <div className="space-y-6 p-6">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => setSelectedReport(null)} data-testid="back-to-reports">
              <ArrowLeft className="w-4 h-4 mr-1" /> Back
            </Button>
            <h2 className="text-lg font-semibold" data-testid="report-detail-title">
              Report: {detail.report.weekStart} — {detail.report.weekEnd}
            </h2>
            <Badge variant={detail.report.status === "published" ? "default" : "secondary"} data-testid="report-status-badge">
              {detail.report.status}
            </Badge>
          </div>

          {detail.report.status === "draft" && (
            <Card className="p-4 bg-amber-50 border-amber-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-amber-800">
                  <Info className="w-4 h-4" />
                  <span className="text-sm font-medium">This report is in draft. Review and publish to make it public.</span>
                </div>
                <Button
                  size="sm"
                  onClick={() => publishMutation.mutate(detail.report.id)}
                  disabled={publishMutation.isPending}
                  data-testid="publish-report-btn"
                >
                  {publishMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Send className="w-4 h-4 mr-1" />}
                  Publish
                </Button>
              </div>
            </Card>
          )}

          {detail.report.highlightsJson && (detail.report.highlightsJson as string[]).length > 0 && (
            <Card className="p-5" data-testid="highlights-card">
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-blue-600" /> Key Highlights
              </h3>
              <ul className="space-y-2">
                {(detail.report.highlightsJson as string[]).map((h, i) => (
                  <li key={i} className="text-sm text-gray-700 flex items-start gap-2">
                    <CheckCircle className="w-3.5 h-3.5 text-green-500 mt-0.5 shrink-0" />
                    {h}
                  </li>
                ))}
              </ul>
            </Card>
          )}

          {detail.report.narrativeMd && (
            <Card className="p-5" data-testid="narrative-card">
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                <FileText className="w-4 h-4 text-blue-600" /> Narrative
              </h3>
              <div className="prose prose-sm max-w-none text-gray-700" data-testid="narrative-content">
                <MarkdownRenderer content={detail.report.narrativeMd} />
              </div>
            </Card>
          )}

          {detail.snapshot?.metricsJson && (
            <Card className="p-5" data-testid="metrics-card">
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-blue-600" /> Raw Metrics
              </h3>
              <MetricsSummary metrics={detail.snapshot.metricsJson} />
            </Card>
          )}
        </div>
      </RoleLayout>
    );
  }

  return (
    <RoleLayout role="admin" title="Market Pulse">
      <div className="space-y-6 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold" data-testid="market-pulse-admin-title">Market Pulse — Pakistan Insights</h1>
            <p className="text-sm text-gray-500 mt-1">Generate, review, and publish weekly market digests from platform data.</p>
          </div>
          <Button
            onClick={() => generateMutation.mutate()}
            disabled={generateMutation.isPending}
            data-testid="generate-report-btn"
          >
            {generateMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Play className="w-4 h-4 mr-1" />}
            Generate Report
          </Button>
        </div>

        {generateMutation.isPending && (
          <Card className="p-6 text-center" data-testid="generating-card">
            <Loader2 className="w-8 h-8 animate-spin mx-auto text-blue-600 mb-3" />
            <p className="text-sm text-gray-600">Computing metrics from database and generating narrative...</p>
          </Card>
        )}

        <Card className="overflow-hidden" data-testid="reports-table-card">
          <div className="px-5 py-3 border-b bg-gray-50/50 flex items-center gap-2">
            <FileText className="w-4 h-4 text-gray-500" />
            <h3 className="text-sm font-semibold text-gray-700">Generated Reports</h3>
          </div>

          {reportsQuery.isLoading ? (
            <div className="p-8 text-center text-gray-400">
              <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
              Loading reports...
            </div>
          ) : reports.length === 0 ? (
            <div className="p-8 text-center text-gray-400" data-testid="no-reports">
              <BarChart3 className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No reports generated yet. Click "Generate Report" to create the first one.</p>
            </div>
          ) : (
            <table className="w-full" data-testid="reports-table">
              <thead>
                <tr className="border-b text-xs text-gray-500">
                  <th className="text-left px-5 py-2.5">Week</th>
                  <th className="text-left px-5 py-2.5">Region</th>
                  <th className="text-left px-5 py-2.5">Status</th>
                  <th className="text-left px-5 py-2.5">Created</th>
                  <th className="text-right px-5 py-2.5">Actions</th>
                </tr>
              </thead>
              <tbody>
                {reports.map((r) => (
                  <tr key={r.id} className="border-b last:border-b-0 hover:bg-gray-50/50" data-testid={`report-row-${r.id}`}>
                    <td className="px-5 py-3 text-sm font-medium">{r.weekStart} — {r.weekEnd}</td>
                    <td className="px-5 py-3 text-sm text-gray-500">{r.region}</td>
                    <td className="px-5 py-3">
                      <Badge variant={r.status === "published" ? "default" : "secondary"}>
                        {r.status}
                      </Badge>
                    </td>
                    <td className="px-5 py-3 text-sm text-gray-500">{new Date(r.createdAt).toLocaleDateString()}</td>
                    <td className="px-5 py-3 text-right">
                      <div className="flex items-center gap-2 justify-end">
                        <Button variant="ghost" size="sm" onClick={() => setSelectedReport(r.id)} data-testid={`view-report-${r.id}`}>
                          <Eye className="w-3.5 h-3.5 mr-1" /> View
                        </Button>
                        {r.status === "draft" && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => publishMutation.mutate(r.id)}
                            disabled={publishMutation.isPending}
                            data-testid={`publish-report-${r.id}`}
                          >
                            <Send className="w-3.5 h-3.5 mr-1" /> Publish
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>

        <div className="text-[11px] text-gray-400 flex items-start gap-1.5">
          <Info className="w-3 h-3 mt-0.5 shrink-0" />
          Reports are generated from real-time platform data. Market insights are for informational purposes only and do not constitute financial advice.
        </div>
      </div>
    </RoleLayout>
  );
}

function MarkdownRenderer({ content }: { content: string }) {
  const lines = content.split("\n");
  return (
    <div className="space-y-2">
      {lines.map((line, i) => {
        if (line.startsWith("## ")) return <h2 key={i} className="text-base font-bold text-gray-900 mt-4">{line.replace("## ", "")}</h2>;
        if (line.startsWith("### ")) return <h3 key={i} className="text-sm font-semibold text-gray-800 mt-3">{line.replace("### ", "")}</h3>;
        if (line.startsWith("- ")) {
          const text = line.replace("- ", "");
          const boldMatch = text.match(/\*\*(.+?)\*\*/g);
          if (boldMatch) {
            const parts = text.split(/\*\*(.+?)\*\*/);
            return (
              <li key={i} className="text-sm text-gray-700 ml-4 list-disc">
                {parts.map((p, j) => j % 2 === 1 ? <strong key={j}>{p}</strong> : p)}
              </li>
            );
          }
          return <li key={i} className="text-sm text-gray-700 ml-4 list-disc">{text}</li>;
        }
        if (line.trim() === "") return <div key={i} className="h-2" />;
        return <p key={i} className="text-sm text-gray-700">{line}</p>;
      })}
    </div>
  );
}

function MetricsSummary({ metrics }: { metrics: any }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="space-y-3">
        <h4 className="text-xs font-semibold text-gray-500 flex items-center gap-1.5">
          <Building2 className="w-3.5 h-3.5" /> Rental Yields
        </h4>
        {metrics.rentalYieldsByCity?.length > 0 ? (
          metrics.rentalYieldsByCity.map((c: any, i: number) => (
            <div key={i} className="flex items-center justify-between text-sm">
              <span className="text-gray-700">{c.city}</span>
              <span className="font-medium">{c.avgYield}%</span>
            </div>
          ))
        ) : (
          <p className="text-xs text-gray-400">No yield data</p>
        )}
      </div>
      <div className="space-y-3">
        <h4 className="text-xs font-semibold text-gray-500 flex items-center gap-1.5">
          <TrendingUp className="w-3.5 h-3.5" /> Listings
        </h4>
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-700">New Listings</span>
          <span className="font-medium">{metrics.listingPerformance?.newListingsCount ?? 0}</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-700">Avg Funding</span>
          <span className="font-medium">{metrics.listingPerformance?.avgFundingPercent ?? 0}%</span>
        </div>
      </div>
      <div className="space-y-3">
        <h4 className="text-xs font-semibold text-gray-500 flex items-center gap-1.5">
          <ArrowUpDown className="w-3.5 h-3.5" /> Exit Windows
        </h4>
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-700">Units Listed</span>
          <span className="font-medium">{metrics.exitWindowStats?.unitsListed ?? 0}</span>
        </div>
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-700">Units Sold</span>
          <span className="font-medium">{metrics.exitWindowStats?.unitsSold ?? 0}</span>
        </div>
      </div>
    </div>
  );
}
