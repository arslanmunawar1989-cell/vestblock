import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { DataTable, type Column } from "@/components/data-table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Search, Plus, Building2, Users, Shield, Archive, Eye, AlertTriangle, ArrowLeft,
} from "lucide-react";
import { useState } from "react";
import { TENANT_ROLE_LABELS } from "@shared/constants";
import { Link } from "wouter";
interface Tenant {
  id: string;
  name: string;
  slug: string;
  status: string;
  brandingJson: any;
  createdAt: string;
  userCount?: number;
}

export default function AdminTenants() {
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newName, setNewName] = useState("");
  const [newSlug, setNewSlug] = useState("");
  const [impersonateDialogId, setImpersonateDialogId] = useState<string | null>(null);
  const [impersonateReason, setImpersonateReason] = useState("");
  const { toast } = useToast();
  const { isSuperAdmin, can } = useAuth();

  const { data: tenantsList = [], isLoading } = useQuery<Tenant[]>({
    queryKey: ["/api/tenants"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: { name: string; slug: string }) => {
      const res = await apiRequest("POST", "/api/tenants", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenants"] });
      setDialogOpen(false);
      setNewName("");
      setNewSlug("");
      toast({ title: "Agency created successfully" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to create agency", description: err.message, variant: "destructive" });
    },
  });

  const toggleStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const res = await apiRequest("PATCH", `/api/tenants/${id}`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenants"] });
      toast({ title: "Agency status updated" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to update status", description: err.message, variant: "destructive" });
    },
  });

  const archiveMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("DELETE", `/api/tenants/${id}`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenants"] });
      toast({ title: "Agency archived safely" });
    },
    onError: (err: any) => {
      toast({ title: "Failed to archive agency", description: err.message, variant: "destructive" });
    },
  });

  const impersonateMutation = useMutation({
    mutationFn: async ({ id, reason }: { id: string; reason: string }) => {
      const res = await apiRequest("POST", `/api/tenants/${id}/impersonate`, { reason });
      return res.json();
    },
    onSuccess: (data) => {
      setImpersonateDialogId(null);
      setImpersonateReason("");
      toast({ title: "Impersonation started", description: `Now viewing as: ${data.tenantName}` });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      window.location.href = "/admin";
    },
    onError: (err: any) => {
      toast({ title: "Failed to impersonate", description: err.message, variant: "destructive" });
    },
  });

  const filtered = tenantsList
    .filter(t => t.status !== "DELETED")
    .filter(t =>
      !search || t.name?.toLowerCase().includes(search.toLowerCase()) || t.slug?.toLowerCase().includes(search.toLowerCase())
    );

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "ACTIVE": return <Badge variant="default" data-testid="badge-status-active">Active</Badge>;
      case "SUSPENDED": return <Badge variant="destructive" data-testid="badge-status-suspended">Suspended</Badge>;
      case "DELETED": return <Badge variant="secondary" data-testid="badge-status-deleted">Archived</Badge>;
      default: return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const columns: Column<Tenant>[] = [
    {
      header: "Agency",
      accessor: (row) => (
        <div className="flex items-center gap-2">
          <Building2 className="w-4 h-4 text-muted-foreground" />
          <div>
            <span className="font-medium" data-testid={`text-name-${row.id}`}>{row.name}</span>
            <p className="text-xs text-muted-foreground" data-testid={`text-slug-${row.id}`}>{row.slug}</p>
          </div>
        </div>
      ),
    },
    {
      header: "Status",
      accessor: (row) => getStatusBadge(row.status),
    },
    {
      header: "Users",
      accessor: (row) => (
        <span className="text-sm" data-testid={`text-users-${row.id}`}>{row.userCount ?? 0}</span>
      ),
    },
    {
      header: "Created",
      accessor: (row) => row.createdAt ? new Date(row.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "—",
    },
    {
      header: "Active",
      accessor: (row) => (
        row.slug !== "platform" ? (
          <Switch
            checked={row.status === "ACTIVE"}
            onCheckedChange={(checked) => {
              toggleStatusMutation.mutate({
                id: row.id,
                status: checked ? "ACTIVE" : "SUSPENDED",
              });
            }}
            disabled={toggleStatusMutation.isPending}
            data-testid={`switch-status-${row.id}`}
          />
        ) : (
          <Badge variant="secondary">Platform</Badge>
        )
      ),
    },
    {
      header: "Actions",
      accessor: (row) => (
        <div className="flex gap-1 flex-wrap">
          {row.slug !== "platform" && isSuperAdmin() && (
            <>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setImpersonateDialogId(row.id)}
                data-testid={`button-impersonate-${row.id}`}
              >
                <Eye className="w-3 h-3 mr-1" />
                View As
              </Button>
              <Button
                size="sm"
                variant="destructive"
                onClick={() => {
                  if (confirm(`Are you sure you want to archive "${row.name}"? This is a safe delete and can be reversed.`)) {
                    archiveMutation.mutate(row.id);
                  }
                }}
                disabled={archiveMutation.isPending}
                data-testid={`button-archive-${row.id}`}
              >
                <Archive className="w-3 h-3 mr-1" />
                Archive
              </Button>
            </>
          )}
        </div>
      ),
    },
  ];

  const handleCreate = () => {
    if (!newName.trim() || !newSlug.trim()) return;
    createMutation.mutate({ name: newName.trim(), slug: newSlug.trim().toLowerCase().replace(/[^a-z0-9_-]/g, "-") });
  };

  const platformTenant = tenantsList.find(t => t.slug === "platform");
  const agencyCount = tenantsList.filter(t => t.slug !== "platform" && t.status !== "DELETED").length;
  const activeAgencies = tenantsList.filter(t => t.status === "ACTIVE" && t.slug !== "platform").length;
  const suspendedAgencies = tenantsList.filter(t => t.status === "SUSPENDED").length;

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Agency Management"
          description="Create, manage, and monitor agency tenants"
          action={
            can("tenants.create") ? (
              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                <DialogTrigger asChild>
                  <Button data-testid="button-create-tenant"><Plus className="w-4 h-4 mr-1" /> New Agency</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create New Agency</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <Label htmlFor="tenant-name">Agency Name</Label>
                      <Input
                        id="tenant-name"
                        placeholder="e.g. Acme Real Estate"
                        value={newName}
                        onChange={e => setNewName(e.target.value)}
                        data-testid="input-tenant-name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="tenant-slug">URL Slug</Label>
                      <Input
                        id="tenant-slug"
                        placeholder="e.g. acme-realestate"
                        value={newSlug}
                        onChange={e => setNewSlug(e.target.value)}
                        data-testid="input-tenant-slug"
                      />
                      <p className="text-xs text-muted-foreground">Access via /t/{newSlug || "slug"}/...</p>
                    </div>
                    <Button
                      className="w-full"
                      onClick={handleCreate}
                      disabled={createMutation.isPending || !newName.trim() || !newSlug.trim()}
                      data-testid="button-confirm-create-tenant"
                    >
                      {createMutation.isPending ? "Creating..." : "Create Agency"}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            ) : undefined
          }
        />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Agencies</CardTitle>
              <Building2 className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-total-tenants">{agencyCount}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active</CardTitle>
              <Shield className="w-4 h-4 text-emerald-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-emerald-600" data-testid="text-active-count">{activeAgencies}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Suspended</CardTitle>
              <AlertTriangle className="w-4 h-4 text-amber-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-amber-600" data-testid="text-suspended-count">{suspendedAgencies}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-1 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              <Users className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-total-users">
                {tenantsList.reduce((sum, t) => sum + (t.userCount || 0), 0)}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search agencies..." className="pl-9" value={search} onChange={e => setSearch(e.target.value)} data-testid="input-search-tenants" />
          </div>
        </div>

        <Section>
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => <Skeleton key={i} className="h-12 w-full" />)}
            </div>
          ) : (
            <DataTable columns={columns} data={filtered} emptyMessage="No agencies found" />
          )}
        </Section>

        <Dialog open={!!impersonateDialogId} onOpenChange={(open) => { if (!open) { setImpersonateDialogId(null); setImpersonateReason(""); } }}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Impersonate Agency Admin</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="p-3 rounded-md bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800">
                <p className="text-sm text-amber-800 dark:text-amber-200">
                  This action is logged for security. You will view the platform as the agency's admin.
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="impersonate-reason">Reason (required for audit)</Label>
                <Input
                  id="impersonate-reason"
                  placeholder="e.g. Supporting user issue #1234"
                  value={impersonateReason}
                  onChange={e => setImpersonateReason(e.target.value)}
                  data-testid="input-impersonate-reason"
                />
              </div>
              <Button
                className="w-full"
                onClick={() => {
                  if (impersonateDialogId && impersonateReason.trim()) {
                    impersonateMutation.mutate({ id: impersonateDialogId, reason: impersonateReason.trim() });
                  }
                }}
                disabled={impersonateMutation.isPending || !impersonateReason.trim()}
                data-testid="button-confirm-impersonate"
              >
                {impersonateMutation.isPending ? "Starting..." : "Start Impersonation"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </RoleLayout>
  );
}
