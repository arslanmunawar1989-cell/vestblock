import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Coins,
  Download,
  Loader2,
  Lock,
  Unlock,
  Users,
  Building2,
  BarChart3,
  Filter,
  FileSpreadsheet,
  Landmark, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface TokenInfo {
  id: string;
  shareClassId: string | null;
  vehicleId: string | null;
  tokenSymbol: string;
  decimals: number;
  totalSupply: string;
  frozen: boolean;
}

interface VehicleInfo {
  id: string;
  name: string;
  type: string;
  jurisdiction: string;
}

interface CapTableHolder {
  holdingId: string;
  userId: string;
  investorName: string;
  email: string;
  nationality: string;
  kycStatus: string;
  balance: string;
  percentage: string;
  updatedAt: string;
}

interface CapTableResponse {
  token: { id: string; tokenSymbol: string; frozen: boolean; decimals: number; totalSupply: string };
  vehicle: { id: string; name: string; type: string; jurisdiction: string } | null;
  shareClass: { id: string; name: string; totalSupply: string; currency: string } | null;
  spv: { id: string; legalName: string; jurisdiction: string } | null;
  asset: { id: string; name: string; symbol: string } | null;
  holders: CapTableHolder[];
  totalHolders: number;
  totalAllocated: string;
}

const JURISDICTION_OPTIONS = [
  { value: "all", label: "All Jurisdictions" },
  { value: "AE", label: "UAE (AE)" },
  { value: "PK", label: "Pakistan (PK)" },
  { value: "GB", label: "United Kingdom (GB)" },
  { value: "US", label: "United States (US)" },
  { value: "QA", label: "Qatar (QA)" },
  { value: "SA", label: "Saudi Arabia (SA)" },
];

export default function AdminTokenConsole() {
  const { toast } = useToast();
  const [selectedTokenId, setSelectedTokenId] = useState<string>("");
  const [jurisdictionFilter, setJurisdictionFilter] = useState("all");
  const [downloadingRegistry, setDownloadingRegistry] = useState(false);
  const [downloadingCapTable, setDownloadingCapTable] = useState(false);

  const { data: allTokens = [], isLoading: tokensLoading } = useQuery<TokenInfo[]>({
    queryKey: ["/api/tokenization/tokens"],
  });

  const { data: vehicles = [] } = useQuery<VehicleInfo[]>({
    queryKey: ["/api/vehicles"],
  });

  const { data: capTable, isLoading: capTableLoading } = useQuery<CapTableResponse>({
    queryKey: ["/api/tokenization/admin/cap-table", selectedTokenId],
    enabled: !!selectedTokenId,
  });

  const freezeMutation = useMutation({
    mutationFn: async (tokenId: string) => {
      const res = await apiRequest("POST", `/api/tokenization/admin/token/${tokenId}/freeze`);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/tokenization/tokens"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tokenization/admin/cap-table", selectedTokenId] });
      toast({ title: "Token Frozen", description: data.message });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const unfreezeMutation = useMutation({
    mutationFn: async (tokenId: string) => {
      const res = await apiRequest("POST", `/api/tokenization/admin/token/${tokenId}/unfreeze`);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/tokenization/tokens"] });
      queryClient.invalidateQueries({ queryKey: ["/api/tokenization/admin/cap-table", selectedTokenId] });
      toast({ title: "Token Unfrozen", description: data.message });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const vehicleMap = new Map(vehicles.map((v) => [v.id, v]));

  const getTokenContext = (token: TokenInfo) => {
    const vehicle = token.vehicleId ? vehicleMap.get(token.vehicleId) : undefined;
    return { vehicle };
  };

  const handleExportRegistry = async () => {
    if (!selectedTokenId) return;
    setDownloadingRegistry(true);
    try {
      const jurisdictionParam = jurisdictionFilter !== "all" ? `?jurisdiction=${jurisdictionFilter}` : "";
      const resp = await fetch(`/api/tokenization/admin/investor-registry/${selectedTokenId}${jurisdictionParam}`, { credentials: "include" });
      if (!resp.ok) throw new Error("Export failed");
      const blob = await resp.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      const disposition = resp.headers.get("Content-Disposition");
      const filename = disposition?.match(/filename="(.+)"/)?.[1] || "investor_registry.csv";
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      toast({ title: "Export Complete", description: "Investor registry CSV downloaded." });
    } catch {
      toast({ title: "Export Failed", description: "Could not download investor registry.", variant: "destructive" });
    } finally {
      setDownloadingRegistry(false);
    }
  };

  const handleExportCapTable = async () => {
    if (!selectedTokenId) return;
    setDownloadingCapTable(true);
    try {
      const resp = await fetch(`/api/tokenization/admin/cap-table/${selectedTokenId}/export`, { credentials: "include" });
      if (!resp.ok) throw new Error("Export failed");
      const blob = await resp.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      const disposition = resp.headers.get("Content-Disposition");
      const filename = disposition?.match(/filename="(.+)"/)?.[1] || "cap_table.csv";
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      toast({ title: "Export Complete", description: "Cap table CSV downloaded." });
    } catch {
      toast({ title: "Export Failed", description: "Could not download cap table.", variant: "destructive" });
    } finally {
      setDownloadingCapTable(false);
    }
  };

  const filteredHolders = capTable?.holders?.filter((h) => {
    if (jurisdictionFilter === "all") return true;
    return h.nationality === jurisdictionFilter;
  }) || [];

  return (
    <RoleLayout role="admin">
      <div className="flex items-center gap-3">
        <Link href="/admin/dashboard">
          <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <PageTitle title="Token Console" />
      </div>
      <Section>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <Card data-testid="card-total-tokens-admin">
            <CardContent className="pt-6">
              <div className="text-sm text-muted-foreground">Total Tokens</div>
              <div className="text-2xl font-bold mt-1" data-testid="text-total-tokens">{allTokens.length}</div>
            </CardContent>
          </Card>
          <Card data-testid="card-total-vehicles">
            <CardContent className="pt-6">
              <div className="text-sm text-muted-foreground">Investment Vehicles</div>
              <div className="text-2xl font-bold mt-1" data-testid="text-total-vehicles">{vehicles.length}</div>
            </CardContent>
          </Card>
          <Card data-testid="card-frozen-tokens">
            <CardContent className="pt-6">
              <div className="text-sm text-muted-foreground">Frozen Tokens</div>
              <div className="text-2xl font-bold mt-1" data-testid="text-frozen-count">
                {allTokens.filter((t) => t.frozen).length}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Coins className="w-5 h-5" />
              Token Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            {tokensLoading ? (
              <div className="space-y-3">
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-16 w-full" />
              </div>
            ) : allTokens.length === 0 ? (
              <p className="text-muted-foreground" data-testid="text-no-tokens">No tokens have been created yet.</p>
            ) : (
              <div className="space-y-3">
                {allTokens.map((token) => {
                  const ctx = getTokenContext(token);
                  const isFund = ctx.vehicle?.type === "FUND";
                  return (
                    <div
                      key={token.id}
                      className={`flex items-center justify-between gap-4 p-4 border rounded-md flex-wrap cursor-pointer ${
                        selectedTokenId === token.id ? "border-primary bg-primary/5" : ""
                      }`}
                      onClick={() => setSelectedTokenId(token.id)}
                      data-testid={`token-row-${token.id}`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                          {isFund ? <Landmark className="w-5 h-5 text-primary" /> : <Coins className="w-5 h-5 text-primary" />}
                        </div>
                        <div>
                          <div className="font-medium flex items-center gap-2 flex-wrap">
                            {token.tokenSymbol}
                            <Badge variant="secondary">
                              {isFund ? "Fund" : "SPV"}
                            </Badge>
                            {token.frozen && (
                              <Badge variant="destructive" data-testid={`badge-frozen-${token.id}`}>
                                <Lock className="w-3 h-3 mr-1" />
                                Frozen
                              </Badge>
                            )}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {ctx.vehicle?.name || "No Vehicle"} &middot; {ctx.vehicle?.jurisdiction || "N/A"} &middot; {token.decimals} decimals
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="secondary">{parseFloat(token.totalSupply || "0").toLocaleString()} supply</Badge>
                        {token.frozen ? (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={(e) => { e.stopPropagation(); unfreezeMutation.mutate(token.id); }}
                            disabled={unfreezeMutation.isPending}
                            data-testid={`button-unfreeze-${token.id}`}
                          >
                            {unfreezeMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Unlock className="w-4 h-4 mr-1" />}
                            Unfreeze
                          </Button>
                        ) : (
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={(e) => { e.stopPropagation(); freezeMutation.mutate(token.id); }}
                            disabled={freezeMutation.isPending}
                            data-testid={`button-freeze-${token.id}`}
                          >
                            {freezeMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Lock className="w-4 h-4 mr-1" />}
                            Freeze
                          </Button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {selectedTokenId && (
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  Cap Table — {capTable?.token?.tokenSymbol || "Loading..."}
                </CardTitle>
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="flex items-center gap-2">
                    <Filter className="w-4 h-4 text-muted-foreground" />
                    <Select value={jurisdictionFilter} onValueChange={setJurisdictionFilter}>
                      <SelectTrigger className="w-[180px]" data-testid="select-jurisdiction-filter">
                        <SelectValue placeholder="Filter by jurisdiction" />
                      </SelectTrigger>
                      <SelectContent>
                        {JURISDICTION_OPTIONS.map((opt) => (
                          <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button
                    variant="outline"
                    onClick={handleExportCapTable}
                    disabled={downloadingCapTable || !capTable}
                    data-testid="button-export-cap-table"
                  >
                    {downloadingCapTable ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <FileSpreadsheet className="w-4 h-4 mr-1" />}
                    Export Cap Table
                  </Button>
                  <Button
                    variant="outline"
                    onClick={handleExportRegistry}
                    disabled={downloadingRegistry || !capTable}
                    data-testid="button-export-registry"
                  >
                    {downloadingRegistry ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Download className="w-4 h-4 mr-1" />}
                    Export Registry
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {capTableLoading ? (
                <div className="space-y-3">
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                </div>
              ) : !capTable ? (
                <p className="text-muted-foreground">Could not load cap table data.</p>
              ) : (
                <>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 mb-6">
                    {capTable.vehicle && (
                      <div className="p-3 border rounded-md">
                        <div className="text-xs text-muted-foreground">Vehicle</div>
                        <div className="font-medium" data-testid="text-cap-vehicle">{capTable.vehicle.name}</div>
                        <div className="text-xs text-muted-foreground mt-0.5">
                          <Badge variant="secondary">{capTable.vehicle.type}</Badge>
                        </div>
                      </div>
                    )}
                    {capTable.asset && (
                      <div className="p-3 border rounded-md">
                        <div className="text-xs text-muted-foreground">Asset</div>
                        <div className="font-medium" data-testid="text-cap-asset">{capTable.asset.name}</div>
                      </div>
                    )}
                    {capTable.spv && (
                      <div className="p-3 border rounded-md">
                        <div className="text-xs text-muted-foreground">SPV Entity</div>
                        <div className="font-medium" data-testid="text-cap-spv">{capTable.spv.legalName}</div>
                      </div>
                    )}
                    <div className="p-3 border rounded-md">
                      <div className="text-xs text-muted-foreground">Total Supply</div>
                      <div className="font-medium" data-testid="text-cap-supply">
                        {parseFloat(capTable.token.totalSupply || capTable.shareClass?.totalSupply || "0").toLocaleString()}
                      </div>
                      <div className="text-xs text-muted-foreground mt-0.5">{capTable.token.decimals} decimals</div>
                    </div>
                    <div className="p-3 border rounded-md">
                      <div className="text-xs text-muted-foreground">Total Holders</div>
                      <div className="font-medium" data-testid="text-cap-holders">{capTable.totalHolders}</div>
                      <div className="text-xs text-muted-foreground mt-0.5">{capTable.totalAllocated} allocated</div>
                    </div>
                  </div>

                  {filteredHolders.length === 0 ? (
                    <p className="text-muted-foreground" data-testid="text-no-holders">
                      {capTable.holders.length === 0 ? "No token holders found." : "No holders match the selected jurisdiction filter."}
                    </p>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm" data-testid="table-cap-table">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left p-3 font-medium text-muted-foreground">Investor</th>
                            <th className="text-left p-3 font-medium text-muted-foreground">Email</th>
                            <th className="text-left p-3 font-medium text-muted-foreground">Nationality</th>
                            <th className="text-left p-3 font-medium text-muted-foreground">KYC</th>
                            <th className="text-right p-3 font-medium text-muted-foreground">Balance</th>
                            <th className="text-right p-3 font-medium text-muted-foreground">Ownership %</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filteredHolders.map((holder) => (
                            <tr key={holder.holdingId} className="border-b" data-testid={`row-holder-${holder.userId}`}>
                              <td className="p-3">
                                <div className="flex items-center gap-2">
                                  <Users className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                                  <span className="font-medium">{holder.investorName}</span>
                                </div>
                              </td>
                              <td className="p-3 text-muted-foreground">{holder.email}</td>
                              <td className="p-3">
                                <Badge variant="secondary">{holder.nationality || "N/A"}</Badge>
                              </td>
                              <td className="p-3">
                                <Badge variant={holder.kycStatus === "approved" ? "default" : "secondary"}>
                                  {holder.kycStatus}
                                </Badge>
                              </td>
                              <td className="p-3 text-right font-mono">{parseFloat(holder.balance).toFixed(capTable.token.decimals)}</td>
                              <td className="p-3 text-right font-mono">{holder.percentage}%</td>
                            </tr>
                          ))}
                        </tbody>
                        <tfoot>
                          <tr className="border-t font-medium">
                            <td className="p-3" colSpan={4}>Total</td>
                            <td className="p-3 text-right font-mono">
                              {filteredHolders.reduce((sum, h) => sum + parseFloat(h.balance), 0).toFixed(capTable.token.decimals)}
                            </td>
                            <td className="p-3 text-right font-mono">
                              {filteredHolders.reduce((sum, h) => sum + parseFloat(h.percentage), 0).toFixed(4)}%
                            </td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        )}

        {!selectedTokenId && allTokens.length > 0 && (
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3 text-muted-foreground">
                <Building2 className="w-5 h-5" />
                <p>Select a token above to view its cap table, export investor registry, or manage compliance controls.</p>
              </div>
            </CardContent>
          </Card>
        )}
      </Section>
    </RoleLayout>
  );
}
