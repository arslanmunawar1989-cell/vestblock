import { useQuery } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import {
  Users,
  Shield,
  DollarSign,
  Building2,
  Coins,
  FileText,
  ArrowDownLeft,
  Send,
  Activity,
  TrendingUp,
  ArrowRight,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Blocks, ArrowLeft,
} from "lucide-react";

interface DashStats {
  totals: {
    users: number;
    kycProfiles: number;
    pendingKyc: number;
    pendingDeposits: number;
    pendingWithdrawals: number;
    totalDeposits: number;
    totalWithdrawals: number;
    totalFxTransactions: number;
    totalDistributions: number;
  };
}

interface AuditStats {
  totalLogs: number;
  todayLogs: number;
}

interface QuickAction {
  label: string;
  path: string;
  icon: typeof Users;
  description: string;
  badge?: string;
  badgeVariant?: "default" | "destructive" | "outline" | "secondary";
}

export default function SuperAdminConsole() {
  const { user, isSuperAdmin } = useAuth();
  const [, navigate] = useLocation();

  if (user && !isSuperAdmin()) {
    navigate("/admin");
    return null;
  }

  const { data: stats, isLoading: statsLoading } = useQuery<DashStats>({
    queryKey: ["/api/admin/dashboard/stats"],
  });

  const { data: auditStats, isLoading: auditLoading } = useQuery<AuditStats>({
    queryKey: ["/api/admin/audit-logs/stats"],
  });

  const { data: users = [] } = useQuery<any[]>({
    queryKey: ["/api/admin/users"],
  });

  const activeUsers = users.filter(u => u.accountStatus === "ACTIVE").length;
  const disabledUsers = users.filter(u => u.accountStatus === "DISABLED").length;
  const archivedUsers = users.filter(u => u.accountStatus === "ARCHIVED").length;
  const pendingKyc = stats?.totals?.pendingKyc || 0;
  const pendingDeposits = stats?.totals?.pendingDeposits || 0;
  const pendingWithdrawals = stats?.totals?.pendingWithdrawals || 0;
  const totalPending = pendingKyc + pendingDeposits + pendingWithdrawals;

  const sections: { title: string; items: QuickAction[] }[] = [
    {
      title: "User Management",
      items: [
        {
          label: "Account Management",
          path: "/admin/users",
          icon: Users,
          description: "Enable/disable accounts, assign roles, force logout, archive users",
          badge: disabledUsers > 0 ? `${disabledUsers} disabled` : undefined,
          badgeVariant: disabledUsers > 0 ? "destructive" : undefined,
        },
        {
          label: "Agency Management",
          path: "/admin/tenants",
          icon: Building2,
          description: "Create, suspend, archive agencies. Impersonate tenant admins.",
        },
        {
          label: "Role Permissions",
          path: "/admin/role-permissions",
          icon: Shield,
          description: "View and configure platform and tenant role permissions",
        },
      ],
    },
    {
      title: "Properties & Tokens",
      items: [
        {
          label: "Properties",
          path: "/admin/properties",
          icon: Building2,
          description: "Manage real estate properties, acquisitions, rental operations",
        },
        {
          label: "Offerings",
          path: "/admin/offerings",
          icon: TrendingUp,
          description: "Manage investment offerings, rounds, and subscription terms",
        },
        {
          label: "Token Console",
          path: "/admin/token-console",
          icon: Coins,
          description: "Issue tokens, manage cap table, freeze/unfreeze holdings",
        },
        {
          label: "Assets",
          path: "/admin/assets",
          icon: Blocks,
          description: "Create and manage tokenized assets and their lifecycle",
        },
        {
          label: "Exit Windows",
          path: "/admin/exit-windows",
          icon: Clock,
          description: "Configure secondary trading windows for controlled liquidity",
        },
      ],
    },
    {
      title: "Finance Approvals",
      items: [
        {
          label: "Finance Console",
          path: "/admin/finance",
          icon: DollarSign,
          description: "Confirm deposits, approve withdrawals, manage crypto, FX, distributions",
          badge: totalPending > 0 ? `${totalPending} pending` : undefined,
          badgeVariant: totalPending > 0 ? "destructive" : undefined,
        },
        {
          label: "Distributions",
          path: "/admin/distributions",
          icon: Send,
          description: "Run waterfall distributions, view payout history",
        },
        {
          label: "Payments",
          path: "/admin/payments",
          icon: ArrowDownLeft,
          description: "Payment intents, reconciliation, fee collection",
        },
        {
          label: "Waterfall Distribution",
          path: "/admin/waterfall-distribution",
          icon: TrendingUp,
          description: "Run end-to-end rent-to-investor waterfall distribution cycles",
        },
      ],
    },
    {
      title: "Compliance & Audit",
      items: [
        {
          label: "Compliance",
          path: "/admin/compliance",
          icon: Shield,
          description: "KYC review, EDD profiles, compliance status tracking",
          badge: pendingKyc > 0 ? `${pendingKyc} pending` : undefined,
          badgeVariant: pendingKyc > 0 ? "destructive" : undefined,
        },
        {
          label: "AML / EDD",
          path: "/admin/aml",
          icon: AlertTriangle,
          description: "AML screening, flags, enhanced due diligence",
        },
        {
          label: "Audit Logs",
          path: "/admin/audit-logs",
          icon: FileText,
          description: "Every admin action recorded with actor, timestamp, and reason",
          badge: auditStats ? `${auditStats.todayLogs} today` : undefined,
          badgeVariant: "secondary",
        },
        {
          label: "System Status",
          path: "/admin/system-status",
          icon: Activity,
          description: "Database health, system diagnostics, API monitoring",
        },
      ],
    },
  ];

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Super Admin Console"
          description="Full platform control center with user management, finance approvals, and audit oversight"
        />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {statsLoading ? (
            [...Array(6)].map((_, i) => <Skeleton key={i} className="h-20 rounded-md" />)
          ) : (
            <>
              <Card data-testid="stat-total-users">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <Users className="w-4 h-4 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Users</span>
                  </div>
                  <p className="text-2xl font-bold" data-testid="text-total-users">{users.length}</p>
                  <p className="text-xs text-muted-foreground">{activeUsers} active</p>
                </CardContent>
              </Card>
              <Card data-testid="stat-pending-kyc">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <Shield className="w-4 h-4 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">KYC Pending</span>
                  </div>
                  <p className="text-2xl font-bold" data-testid="text-pending-kyc">{pendingKyc}</p>
                  <p className="text-xs text-muted-foreground">need review</p>
                </CardContent>
              </Card>
              <Card data-testid="stat-pending-deposits">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <ArrowDownLeft className="w-4 h-4 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Deposits</span>
                  </div>
                  <p className="text-2xl font-bold" data-testid="text-pending-deposits">{pendingDeposits}</p>
                  <p className="text-xs text-muted-foreground">awaiting confirm</p>
                </CardContent>
              </Card>
              <Card data-testid="stat-pending-withdrawals">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <Send className="w-4 h-4 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Withdrawals</span>
                  </div>
                  <p className="text-2xl font-bold" data-testid="text-pending-withdrawals">{pendingWithdrawals}</p>
                  <p className="text-xs text-muted-foreground">awaiting approval</p>
                </CardContent>
              </Card>
              <Card data-testid="stat-distributions">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <DollarSign className="w-4 h-4 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Distributions</span>
                  </div>
                  <p className="text-2xl font-bold">{stats?.totals?.totalDistributions || 0}</p>
                  <p className="text-xs text-muted-foreground">completed</p>
                </CardContent>
              </Card>
              <Card data-testid="stat-audit-today">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <FileText className="w-4 h-4 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Audit Today</span>
                  </div>
                  <p className="text-2xl font-bold">{auditLoading ? "..." : auditStats?.todayLogs || 0}</p>
                  <p className="text-xs text-muted-foreground">of {auditStats?.totalLogs || 0} total</p>
                </CardContent>
              </Card>
            </>
          )}
        </div>

        {totalPending > 0 && (
          <Card className="border-amber-500/30 bg-amber-500/5">
            <CardContent className="p-4">
              <div className="flex items-center gap-3 flex-wrap">
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-amber-500" />
                  <span className="font-medium" data-testid="text-pending-actions">
                    {totalPending} item{totalPending !== 1 ? "s" : ""} require your attention
                  </span>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  {pendingKyc > 0 && (
                    <Link href="/admin/compliance">
                      <Badge variant="outline" className="cursor-pointer" data-testid="badge-pending-kyc">{pendingKyc} KYC</Badge>
                    </Link>
                  )}
                  {pendingDeposits > 0 && (
                    <Link href="/admin/finance">
                      <Badge variant="outline" className="cursor-pointer" data-testid="badge-pending-deposits">{pendingDeposits} Deposits</Badge>
                    </Link>
                  )}
                  {pendingWithdrawals > 0 && (
                    <Link href="/admin/finance">
                      <Badge variant="outline" className="cursor-pointer" data-testid="badge-pending-withdrawals">{pendingWithdrawals} Withdrawals</Badge>
                    </Link>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {sections.map((section) => (
          <div key={section.title} className="space-y-3">
            <h2 className="text-lg font-semibold" data-testid={`heading-${section.title.toLowerCase().replace(/\s+/g, "-")}`}>{section.title}</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
              {section.items.map((item) => {
                const Icon = item.icon;
                return (
                  <Link key={item.path} href={item.path}>
                    <Card className="h-full hover-elevate cursor-pointer" data-testid={`card-nav-${item.path.split("/").pop()}`}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <div className="w-9 h-9 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                            <Icon className="w-5 h-5 text-primary" />
                          </div>
                          {item.badge && (
                            <Badge variant={item.badgeVariant || "secondary"} className="text-xs no-default-hover-elevate" data-testid={`badge-${item.path.split("/").pop()}`}>
                              {item.badge}
                            </Badge>
                          )}
                        </div>
                        <h3 className="font-medium text-sm mb-1">{item.label}</h3>
                        <p className="text-xs text-muted-foreground leading-relaxed">{item.description}</p>
                      </CardContent>
                    </Card>
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </RoleLayout>
  );
}
