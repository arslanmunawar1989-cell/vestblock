import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { StatTile } from "@/components/stat-tile";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate } from "@/lib/format";
import {
  AlertTriangle, Shield, Search, Loader2, User, CheckCircle2,
  XCircle, Flag, Scan, ShieldCheck, ShieldAlert, Clock, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface AmlFlagUser {
  id: string;
  username: string;
  email: string;
  fullName: string;
  eddStatus: string;
}

interface AmlFlagWithUser {
  id: string;
  userId: string;
  flagType: string;
  severity: string;
  description: string;
  details: any;
  status: string;
  resolvedBy: string | null;
  resolvedAt: string | null;
  resolutionNotes: string | null;
  createdAt: string;
  user: AmlFlagUser | null;
}

function SeverityBadge({ severity }: { severity: string }) {
  const config: Record<string, { variant: "default" | "secondary" | "destructive" | "outline" }> = {
    critical: { variant: "destructive" },
    high: { variant: "destructive" },
    medium: { variant: "default" },
    low: { variant: "secondary" },
  };
  const c = config[severity] || { variant: "secondary" };
  return <Badge variant={c.variant} data-testid={`badge-severity-${severity}`} className="capitalize text-xs">{severity}</Badge>;
}

function FlagTypeBadge({ type }: { type: string }) {
  return <Badge variant="outline" data-testid={`badge-flag-type-${type}`} className="capitalize text-xs">{type.replace(/_/g, " ")}</Badge>;
}

function EddStatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
    none: { label: "No EDD", variant: "secondary" },
    EDD_REQUIRED: { label: "EDD Required", variant: "destructive" },
    EDD_IN_PROGRESS: { label: "EDD In Progress", variant: "default" },
    EDD_COMPLETE: { label: "EDD Complete", variant: "secondary" },
  };
  const c = config[status] || { label: status, variant: "secondary" };
  return <Badge variant={c.variant} data-testid={`badge-edd-${status}`}>{c.label}</Badge>;
}

function CreateFlagDialog({ open, onClose, users }: { open: boolean; onClose: () => void; users: { id: string; username: string; fullName: string }[] }) {
  const { toast } = useToast();
  const [selectedUserId, setSelectedUserId] = useState("");
  const [flagType, setFlagType] = useState("");
  const [severity, setSeverity] = useState("medium");
  const [description, setDescription] = useState("");

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/admin/aml/flags", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/aml/flags"] });
      toast({ title: "Flag created", description: "AML flag has been created and user set to EDD Required." });
      setSelectedUserId("");
      setFlagType("");
      setSeverity("medium");
      setDescription("");
      onClose();
    },
    onError: (err: any) => {
      toast({ title: "Failed to create flag", description: err.message, variant: "destructive" });
    },
  });

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Create AML Flag</DialogTitle>
          <DialogDescription>Manually flag a user for enhanced due diligence review.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label className="text-sm">User</Label>
            <Select value={selectedUserId} onValueChange={setSelectedUserId}>
              <SelectTrigger data-testid="select-flag-user">
                <SelectValue placeholder="Select user" />
              </SelectTrigger>
              <SelectContent>
                {users.map(u => (
                  <SelectItem key={u.id} value={u.id}>{u.fullName} (@{u.username})</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-sm">Flag Type</Label>
            <Select value={flagType} onValueChange={setFlagType}>
              <SelectTrigger data-testid="select-flag-type">
                <SelectValue placeholder="Select flag type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="high_risk_country">High Risk Country</SelectItem>
                <SelectItem value="pep_flag">PEP Flag</SelectItem>
                <SelectItem value="large_deposit">Large Deposit</SelectItem>
                <SelectItem value="name_mismatch">Name Mismatch</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-sm">Severity</Label>
            <Select value={severity} onValueChange={setSeverity}>
              <SelectTrigger data-testid="select-flag-severity">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-sm">Description</Label>
            <Textarea
              placeholder="Describe the reason for this flag..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              data-testid="textarea-flag-description"
            />
          </div>
          <div className="flex items-center gap-2">
            <Button
              onClick={() => createMutation.mutate({ userId: selectedUserId, flagType, severity, description })}
              disabled={!selectedUserId || !flagType || !description.trim() || createMutation.isPending}
              data-testid="button-create-flag"
            >
              {createMutation.isPending && <Loader2 className="w-4 h-4 mr-1 animate-spin" />}
              Create Flag
            </Button>
            <Button variant="outline" onClick={onClose} data-testid="button-cancel-create-flag">Cancel</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ResolveFlagDialog({ flag, open, onClose }: { flag: AmlFlagWithUser | null; open: boolean; onClose: () => void }) {
  const { toast } = useToast();
  const [notes, setNotes] = useState("");

  const resolveMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/admin/aml/flags/${flag!.id}/resolve`, { notes });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/aml/flags"] });
      toast({ title: "Flag resolved", description: "AML flag has been cleared." });
      setNotes("");
      onClose();
    },
    onError: (err: any) => {
      toast({ title: "Failed to resolve flag", description: err.message, variant: "destructive" });
    },
  });

  if (!flag) return null;

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Resolve AML Flag</DialogTitle>
          <DialogDescription>Clear this flag and provide resolution notes.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <GlassCard>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2 flex-wrap">
                <FlagTypeBadge type={flag.flagType} />
                <SeverityBadge severity={flag.severity} />
              </div>
              <p className="text-muted-foreground">{flag.description}</p>
              <p className="text-xs text-muted-foreground">User: {flag.user?.fullName || "Unknown"} ({flag.user?.email})</p>
            </div>
          </GlassCard>
          <div>
            <Label className="text-sm">Resolution Notes</Label>
            <Textarea
              placeholder="Explain why this flag is being cleared..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              data-testid="textarea-resolve-notes"
            />
          </div>
          <div className="flex items-center gap-2">
            <Button
              onClick={() => resolveMutation.mutate()}
              disabled={!notes.trim() || resolveMutation.isPending}
              data-testid="button-confirm-resolve"
            >
              {resolveMutation.isPending && <Loader2 className="w-4 h-4 mr-1 animate-spin" />}
              Clear Flag
            </Button>
            <Button variant="outline" onClick={onClose}>Cancel</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function EddCompleteDialog({ userId, userName, open, onClose }: { userId: string; userName: string; open: boolean; onClose: () => void }) {
  const { toast } = useToast();
  const [notes, setNotes] = useState("");

  const completeMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/admin/aml/edd/${userId}/complete`, { notes: notes || undefined });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/aml/flags"] });
      toast({ title: "EDD Complete", description: `Enhanced due diligence marked complete for ${userName}.` });
      setNotes("");
      onClose();
    },
    onError: (err: any) => {
      toast({ title: "Failed", description: err.message, variant: "destructive" });
    },
  });

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Mark EDD Complete</DialogTitle>
          <DialogDescription>Mark enhanced due diligence as complete for {userName}. This will lift account restrictions.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label className="text-sm">Notes (optional)</Label>
            <Textarea
              placeholder="Any notes about the EDD completion..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              data-testid="textarea-edd-notes"
            />
          </div>
          <div className="flex items-center gap-2">
            <Button
              onClick={() => completeMutation.mutate()}
              disabled={completeMutation.isPending}
              data-testid="button-confirm-edd-complete"
            >
              {completeMutation.isPending && <Loader2 className="w-4 h-4 mr-1 animate-spin" />}
              Mark EDD Complete
            </Button>
            <Button variant="outline" onClick={onClose}>Cancel</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function AdminAml() {
  const { toast } = useToast();
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [resolveFlag, setResolveFlag] = useState<AmlFlagWithUser | null>(null);
  const [eddCompleteUser, setEddCompleteUser] = useState<{ id: string; name: string } | null>(null);

  const { data: flags = [], isLoading } = useQuery<AmlFlagWithUser[]>({
    queryKey: ["/api/admin/aml/flags"],
  });

  const { data: allUsers = [] } = useQuery<{ id: string; username: string; fullName: string; email: string }[]>({
    queryKey: ["/api/users"],
  });

  const scanMutation = useMutation({
    mutationFn: async (userId: string) => {
      const res = await apiRequest("POST", `/api/admin/aml/scan/${userId}`);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/aml/flags"] });
      toast({
        title: "Scan complete",
        description: `Found ${data.newFlags.length} new flag(s). Total active: ${data.totalActive}`,
      });
    },
    onError: (err: any) => {
      toast({ title: "Scan failed", description: err.message, variant: "destructive" });
    },
  });

  const filtered = flags.filter((f) => {
    if (statusFilter !== "all" && f.status !== statusFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        f.user?.fullName?.toLowerCase().includes(q) ||
        f.user?.email?.toLowerCase().includes(q) ||
        f.user?.username?.toLowerCase().includes(q) ||
        f.flagType.toLowerCase().includes(q) ||
        f.description.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const stats = {
    total: flags.length,
    active: flags.filter(f => f.status === "active").length,
    high: flags.filter(f => f.status === "active" && (f.severity === "high" || f.severity === "critical")).length,
    cleared: flags.filter(f => f.status === "cleared").length,
  };

  const usersWithEdd = Array.from(
    new Map(
      flags
        .filter(f => f.user && (f.user.eddStatus === "EDD_REQUIRED" || f.user.eddStatus === "EDD_IN_PROGRESS"))
        .map(f => [f.user!.id, f.user!])
    ).values()
  );

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="AML / EDD Management"
          description="Monitor anti-money laundering flags and enhanced due diligence reviews"
          action={
            <Button onClick={() => setCreateDialogOpen(true)} data-testid="button-create-flag-open">
              <Flag className="w-4 h-4 mr-1" />
              Manual Flag
            </Button>
          }
        />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatTile label="Total Flags" value={String(stats.total)} icon={<Flag className="w-5 h-5" />} />
          <StatTile label="Active Flags" value={String(stats.active)} trend="neutral" icon={<ShieldAlert className="w-5 h-5" />} />
          <StatTile label="High/Critical" value={String(stats.high)} trend={stats.high > 0 ? "down" : "neutral"} icon={<AlertTriangle className="w-5 h-5" />} />
          <StatTile label="Cleared" value={String(stats.cleared)} trend="up" icon={<ShieldCheck className="w-5 h-5" />} />
        </div>

        {usersWithEdd.length > 0 && (
          <Section title="Users Requiring EDD">
            <div className="space-y-2">
              {usersWithEdd.map(u => (
                <GlassCard key={u.id}>
                  <div className="flex items-center justify-between gap-3 flex-wrap">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-9 h-9 rounded-md bg-destructive/10 flex items-center justify-center flex-shrink-0">
                        <ShieldAlert className="w-4 h-4 text-destructive" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium" data-testid={`edd-user-${u.id}`}>{u.fullName}</p>
                        <p className="text-xs text-muted-foreground">{u.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <EddStatusBadge status={u.eddStatus} />
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => scanMutation.mutate(u.id)}
                        disabled={scanMutation.isPending}
                        data-testid={`button-scan-${u.id}`}
                      >
                        <Scan className="w-3 h-3 mr-1" />
                        Re-scan
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => setEddCompleteUser({ id: u.id, name: u.fullName })}
                        data-testid={`button-edd-complete-${u.id}`}
                      >
                        <CheckCircle2 className="w-3 h-3 mr-1" />
                        Mark EDD Complete
                      </Button>
                    </div>
                  </div>
                </GlassCard>
              ))}
            </div>
          </Section>
        )}

        <Section title="AML Flags">
          <div className="flex items-center gap-3 mb-4 flex-wrap">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search flags by user, type, or description..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
                data-testid="input-search-aml"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[140px]" data-testid="select-filter-aml-status">
                <SelectValue placeholder="Filter status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="cleared">Cleared</SelectItem>
                <SelectItem value="escalated">Escalated</SelectItem>
              </SelectContent>
            </Select>
            <Select onValueChange={(userId) => scanMutation.mutate(userId)}>
              <SelectTrigger className="w-[180px]" data-testid="select-scan-user">
                <SelectValue placeholder="Run AML Scan..." />
              </SelectTrigger>
              <SelectContent>
                {allUsers.map(u => (
                  <SelectItem key={u.id} value={u.id}>{u.fullName}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : filtered.length === 0 ? (
            <GlassCard>
              <div className="text-center py-6">
                <Shield className="w-10 h-10 mx-auto text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground">No AML flags found</p>
              </div>
            </GlassCard>
          ) : (
            <div className="space-y-2">
              {filtered.map((flag) => (
                <GlassCard key={flag.id} data-testid={`aml-flag-${flag.id}`}>
                  <div className="flex items-center justify-between gap-3 flex-wrap">
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <div className={`w-9 h-9 rounded-md flex items-center justify-center flex-shrink-0 ${flag.status === "active" ? "bg-destructive/10" : "bg-muted"}`}>
                        {flag.status === "active" ? (
                          <AlertTriangle className="w-4 h-4 text-destructive" />
                        ) : (
                          <CheckCircle2 className="w-4 h-4 text-muted-foreground" />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <p className="text-sm font-medium" data-testid={`flag-user-name-${flag.id}`}>
                            {flag.user?.fullName || "Unknown"}
                          </p>
                          <FlagTypeBadge type={flag.flagType} />
                          <SeverityBadge severity={flag.severity} />
                          {flag.status === "cleared" && (
                            <Badge variant="secondary" className="text-xs">Cleared</Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-1" data-testid={`flag-desc-${flag.id}`}>
                          {flag.description}
                        </p>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {formatDate(flag.createdAt, "short")}
                          {flag.resolvedAt && ` - Cleared ${formatDate(flag.resolvedAt, "short")}`}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {flag.status === "active" && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setResolveFlag(flag)}
                          data-testid={`button-resolve-${flag.id}`}
                        >
                          <CheckCircle2 className="w-3 h-3 mr-1" />
                          Clear
                        </Button>
                      )}
                      {flag.status === "cleared" && flag.resolutionNotes && (
                        <span className="text-xs text-muted-foreground max-w-[200px] truncate" title={flag.resolutionNotes}>
                          {flag.resolutionNotes}
                        </span>
                      )}
                    </div>
                  </div>
                </GlassCard>
              ))}
            </div>
          )}
        </Section>
      </div>

      <CreateFlagDialog
        open={createDialogOpen}
        onClose={() => setCreateDialogOpen(false)}
        users={allUsers.map(u => ({ id: u.id, username: u.username, fullName: u.fullName }))}
      />
      <ResolveFlagDialog
        flag={resolveFlag}
        open={!!resolveFlag}
        onClose={() => setResolveFlag(null)}
      />
      {eddCompleteUser && (
        <EddCompleteDialog
          userId={eddCompleteUser.id}
          userName={eddCompleteUser.name}
          open={!!eddCompleteUser}
          onClose={() => setEddCompleteUser(null)}
        />
      )}
    </RoleLayout>
  );
}
