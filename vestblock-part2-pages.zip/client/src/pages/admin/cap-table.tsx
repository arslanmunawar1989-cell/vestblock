import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import {
  Download,
  Loader2,
  Users,
  BarChart3,
  Building2,
  Coins,
  DollarSign,
  PieChart, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface AssetInfo {
  id: string;
  name: string;
  symbol: string;
  baseCurrency: string;
  pricePerToken: string;
  totalSupply: string;
}

interface HolderHolding {
  tokenSymbol: string;
  shareClassName: string;
  currency: string;
  balance: string;
  percentage: string;
}

interface CapTableHolder {
  userId: string;
  investorName: string;
  email: string;
  nationality: string;
  kycStatus: string;
  totalTokens: number;
  totalValue: string;
  ownershipPercent: string;
  holdings: HolderHolding[];
}

interface PropertyCapTableResponse {
  asset: AssetInfo;
  holders: CapTableHolder[];
  totalHolders: number;
  totalValue: string;
  grandTotalSupply: string;
}

export default function AdminCapTable() {
  const { toast } = useToast();
  const [selectedAssetId, setSelectedAssetId] = useState<string>("");
  const [downloading, setDownloading] = useState(false);
  const [expandedHolder, setExpandedHolder] = useState<string | null>(null);

  const { data: assets = [], isLoading: assetsLoading } = useQuery<AssetInfo[]>({
    queryKey: ["/api/assets"],
  });

  const { data: capTable, isLoading: capTableLoading } = useQuery<PropertyCapTableResponse>({
    queryKey: ["/api/tokenization/admin/property-cap-table", selectedAssetId],
    enabled: !!selectedAssetId,
  });

  const handleExport = async () => {
    if (!selectedAssetId) return;
    setDownloading(true);
    try {
      const resp = await fetch(`/api/tokenization/admin/property-cap-table/${selectedAssetId}/export`, { credentials: "include" });
      if (!resp.ok) throw new Error("Export failed");
      const blob = await resp.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      const disposition = resp.headers.get("Content-Disposition");
      const filename = disposition?.match(/filename="(.+)"/)?.[1] || "cap_table.csv";
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      toast({ title: "Export Complete", description: "Cap table CSV downloaded." });
    } catch {
      toast({ title: "Export Failed", description: "Could not download cap table.", variant: "destructive" });
    } finally {
      setDownloading(false);
    }
  };

  const selectedAsset = assets.find(a => a.id === selectedAssetId);

  return (
    <RoleLayout role="admin">
      <div className="flex items-center gap-3">
        <Link href="/admin/dashboard">
          <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <PageTitle title="Cap Table" />
      </div>
      <Section>
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="w-5 h-5" />
              Select Property
            </CardTitle>
          </CardHeader>
          <CardContent>
            {assetsLoading ? (
              <Skeleton className="h-10 w-full" />
            ) : (
              <Select value={selectedAssetId} onValueChange={setSelectedAssetId}>
                <SelectTrigger data-testid="select-property">
                  <SelectValue placeholder="Choose a property to view cap table" />
                </SelectTrigger>
                <SelectContent>
                  {assets.map((asset) => (
                    <SelectItem key={asset.id} value={asset.id} data-testid={`option-property-${asset.id}`}>
                      {asset.name} ({asset.symbol})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </CardContent>
        </Card>

        {selectedAssetId && capTableLoading && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
            </div>
            <Skeleton className="h-64" />
          </div>
        )}

        {selectedAssetId && !capTableLoading && capTable && (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 mb-6">
              <Card data-testid="card-total-holders">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Users className="w-4 h-4" />
                    Total Investors
                  </div>
                  <div className="text-2xl font-bold mt-1" data-testid="text-total-holders">
                    {capTable.totalHolders}
                  </div>
                </CardContent>
              </Card>
              <Card data-testid="card-total-tokens">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Coins className="w-4 h-4" />
                    Total Supply
                  </div>
                  <div className="text-2xl font-bold mt-1" data-testid="text-total-supply">
                    {parseFloat(capTable.grandTotalSupply).toLocaleString()}
                  </div>
                </CardContent>
              </Card>
              <Card data-testid="card-total-value">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <DollarSign className="w-4 h-4" />
                    Total Value
                  </div>
                  <div className="text-2xl font-bold mt-1" data-testid="text-total-value">
                    {parseFloat(capTable.totalValue).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {capTable.asset.baseCurrency}
                  </div>
                </CardContent>
              </Card>
              <Card data-testid="card-price-per-token">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <PieChart className="w-4 h-4" />
                    Price / Token
                  </div>
                  <div className="text-2xl font-bold mt-1" data-testid="text-price-per-token">
                    {parseFloat(capTable.asset.pricePerToken).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {capTable.asset.baseCurrency}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <div className="flex items-center justify-between gap-4 flex-wrap">
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5" />
                    Investor Holdings — {capTable.asset.name}
                  </CardTitle>
                  <Button
                    variant="outline"
                    onClick={handleExport}
                    disabled={downloading || capTable.holders.length === 0}
                    data-testid="button-export-cap-table"
                  >
                    {downloading ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Download className="w-4 h-4 mr-1" />}
                    Export CSV
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {capTable.holders.length === 0 ? (
                  <p className="text-muted-foreground" data-testid="text-no-holders">
                    No investors hold tokens for this property yet.
                  </p>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm" data-testid="table-cap-table">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left p-3 font-medium text-muted-foreground">Investor</th>
                          <th className="text-left p-3 font-medium text-muted-foreground">Email</th>
                          <th className="text-left p-3 font-medium text-muted-foreground">Nationality</th>
                          <th className="text-left p-3 font-medium text-muted-foreground">KYC</th>
                          <th className="text-right p-3 font-medium text-muted-foreground">Tokens</th>
                          <th className="text-right p-3 font-medium text-muted-foreground">Ownership %</th>
                          <th className="text-right p-3 font-medium text-muted-foreground">Value ({capTable.asset.baseCurrency})</th>
                        </tr>
                      </thead>
                      <tbody>
                        {capTable.holders.map((holder) => (
                          <>
                            <tr
                              key={holder.userId}
                              className={`border-b cursor-pointer ${expandedHolder === holder.userId ? "bg-muted/30" : ""}`}
                              onClick={() => setExpandedHolder(expandedHolder === holder.userId ? null : holder.userId)}
                              data-testid={`row-holder-${holder.userId}`}
                            >
                              <td className="p-3" data-testid={`text-name-${holder.userId}`}>
                                <div className="flex items-center gap-2">
                                  <Users className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                                  <span className="font-medium">{holder.investorName}</span>
                                </div>
                              </td>
                              <td className="p-3 text-muted-foreground" data-testid={`text-email-${holder.userId}`}>{holder.email}</td>
                              <td className="p-3" data-testid={`text-nationality-${holder.userId}`}>
                                <Badge variant="secondary">{holder.nationality || "N/A"}</Badge>
                              </td>
                              <td className="p-3" data-testid={`badge-kyc-${holder.userId}`}>
                                <Badge variant={holder.kycStatus === "approved" ? "default" : "secondary"}>
                                  {holder.kycStatus}
                                </Badge>
                              </td>
                              <td className="p-3 text-right font-mono" data-testid={`text-tokens-${holder.userId}`}>{holder.totalTokens.toLocaleString()}</td>
                              <td className="p-3 text-right font-mono" data-testid={`text-ownership-${holder.userId}`}>{holder.ownershipPercent}%</td>
                              <td className="p-3 text-right font-mono" data-testid={`text-value-${holder.userId}`}>
                                {parseFloat(holder.totalValue).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                              </td>
                            </tr>
                            {expandedHolder === holder.userId && holder.holdings.length > 0 && (
                              <tr key={`${holder.userId}-detail`}>
                                <td colSpan={7} className="px-3 pb-3">
                                  <div className="ml-6 mt-1 p-3 border rounded-md bg-muted/10">
                                    <div className="text-xs font-medium text-muted-foreground mb-2">Token Breakdown</div>
                                    <table className="w-full text-xs" data-testid={`table-breakdown-${holder.userId}`}>
                                      <thead>
                                        <tr className="border-b">
                                          <th className="text-left p-2 font-medium text-muted-foreground">Token</th>
                                          <th className="text-left p-2 font-medium text-muted-foreground">Share Class</th>
                                          <th className="text-left p-2 font-medium text-muted-foreground">Currency</th>
                                          <th className="text-right p-2 font-medium text-muted-foreground">Balance</th>
                                          <th className="text-right p-2 font-medium text-muted-foreground">% of Class</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        {holder.holdings.map((h, idx) => (
                                          <tr key={idx} className="border-b last:border-0" data-testid={`row-breakdown-${holder.userId}-${idx}`}>
                                            <td className="p-2" data-testid={`text-token-symbol-${holder.userId}-${idx}`}>
                                              <Badge variant="secondary">{h.tokenSymbol}</Badge>
                                            </td>
                                            <td className="p-2 text-muted-foreground" data-testid={`text-share-class-${holder.userId}-${idx}`}>{h.shareClassName}</td>
                                            <td className="p-2" data-testid={`badge-currency-${holder.userId}-${idx}`}>
                                              <Badge variant="outline">{h.currency}</Badge>
                                            </td>
                                            <td className="p-2 text-right font-mono" data-testid={`text-balance-${holder.userId}-${idx}`}>{parseFloat(h.balance).toLocaleString()}</td>
                                            <td className="p-2 text-right font-mono" data-testid={`text-class-pct-${holder.userId}-${idx}`}>{h.percentage}%</td>
                                          </tr>
                                        ))}
                                      </tbody>
                                    </table>
                                  </div>
                                </td>
                              </tr>
                            )}
                          </>
                        ))}
                      </tbody>
                      <tfoot>
                        <tr className="border-t font-medium">
                          <td className="p-3" colSpan={4}>Total</td>
                          <td className="p-3 text-right font-mono">
                            {capTable.holders.reduce((sum, h) => sum + h.totalTokens, 0).toLocaleString()}
                          </td>
                          <td className="p-3 text-right font-mono">
                            {capTable.holders.reduce((sum, h) => sum + parseFloat(h.ownershipPercent), 0).toFixed(4)}%
                          </td>
                          <td className="p-3 text-right font-mono">
                            {parseFloat(capTable.totalValue).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </>
        )}

        {!selectedAssetId && !assetsLoading && (
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3 text-muted-foreground">
                <Building2 className="w-5 h-5" />
                <p data-testid="text-select-prompt">Select a property above to view its cap table with investor percentages, currencies, and holdings.</p>
              </div>
            </CardContent>
          </Card>
        )}
      </Section>
    </RoleLayout>
  );
}
