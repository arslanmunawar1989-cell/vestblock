import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { PERMISSION_CATEGORIES, ROLES, type Permission, type Role } from "@shared/constants";
import { Shield, RotateCcw, Check, X, Loader2, ArrowLeft,
} from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
interface PermissionMatrix {
  roles: string[];
  permissions: string[];
  matrix: Record<string, string[]>;
  defaults: Record<string, string[]>;
}

const ROLE_COLORS: Record<string, string> = {
  admin: "text-red-500",
  investor: "text-emerald-500",
  issuer: "text-blue-500",
  agent: "text-amber-500",
};

export default function AdminRolePermissions() {
  const { toast } = useToast();
  const [pendingChanges, setPendingChanges] = useState<Record<string, Set<string>>>({});

  const { data: matrixData, isLoading } = useQuery<PermissionMatrix>({
    queryKey: ["/api/admin/permissions/matrix"],
  });

  const updatePermissionsMutation = useMutation({
    mutationFn: async ({ role, permissions }: { role: string; permissions: string[] }) => {
      return apiRequest("PUT", `/api/admin/permissions/${role}`, { permissions });
    },
    onSuccess: (_, { role }) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/permissions/matrix"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      queryClient.invalidateQueries({ queryKey: ["/api/permissions/me"] });
      toast({ title: "Permissions updated", description: `Permissions for ${role} role have been saved.` });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update permissions.", variant: "destructive" });
    },
  });

  const resetMutation = useMutation({
    mutationFn: async (role: string) => {
      return apiRequest("POST", `/api/admin/permissions/${role}/reset`);
    },
    onSuccess: (_, role) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/permissions/matrix"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      setPendingChanges(prev => {
        const next = { ...prev };
        delete next[role];
        return next;
      });
      toast({ title: "Reset complete", description: `${role} permissions restored to defaults.` });
    },
  });

  const getEffectivePermissions = (role: string): Set<string> => {
    if (pendingChanges[role]) return pendingChanges[role];
    if (!matrixData) return new Set();
    return new Set(matrixData.matrix[role] || []);
  };

  const togglePermission = (role: string, permission: string) => {
    const current = getEffectivePermissions(role);
    const next = new Set(current);
    if (next.has(permission)) {
      next.delete(permission);
    } else {
      next.add(permission);
    }
    setPendingChanges(prev => ({ ...prev, [role]: next }));
  };

  const saveRolePermissions = (role: string) => {
    const perms = pendingChanges[role];
    if (!perms) return;
    updatePermissionsMutation.mutate(
      { role, permissions: Array.from(perms) },
      {
        onSuccess: () => {
          setPendingChanges(prev => {
            const next = { ...prev };
            delete next[role];
            return next;
          });
        },
      }
    );
  };

  const hasChanged = (role: string): boolean => {
    if (!pendingChanges[role] || !matrixData) return false;
    const current = new Set(matrixData.matrix[role] || []);
    const pending = pendingChanges[role];
    if (current.size !== pending.size) return true;
    const arr = Array.from(current);
    for (let i = 0; i < arr.length; i++) {
      if (!pending.has(arr[i])) return true;
    }
    return false;
  };

  if (isLoading) {
    return (
      <RoleLayout role="admin">
        <div className="flex items-center justify-center py-20 text-muted-foreground">
          <Loader2 className="w-5 h-5 animate-spin mr-2" />
          Loading permission matrix...
        </div>
      </RoleLayout>
    );
  }

  const categories = Object.entries(PERMISSION_CATEGORIES);

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Role Permissions"
          description="Configure what each role can access — changes take effect immediately"
          action={
            <Badge variant="secondary" className="text-xs">
              <Shield className="w-3 h-3 mr-1" />
              {matrixData?.permissions.length || 0} permissions across {ROLES.length} roles
            </Badge>
          }
        />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-sm" data-testid="table-permission-matrix">
            <thead>
              <tr className="border-b">
                <th className="text-left p-3 font-semibold min-w-[200px]">Permission</th>
                {ROLES.map(role => (
                  <th key={role} className="text-center p-3 min-w-[120px]">
                    <div className="space-y-1">
                      <span className={`font-semibold capitalize ${ROLE_COLORS[role] || ""}`} data-testid={`text-role-header-${role}`}>
                        {role}
                      </span>
                      <div className="flex items-center justify-center gap-1 flex-wrap">
                        {hasChanged(role) && (
                          <Button
                            size="sm"
                            onClick={() => saveRolePermissions(role)}
                            disabled={updatePermissionsMutation.isPending}
                            data-testid={`button-save-${role}`}
                          >
                            {updatePermissionsMutation.isPending ? (
                              <Loader2 className="w-3 h-3 animate-spin" />
                            ) : (
                              "Save"
                            )}
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => resetMutation.mutate(role)}
                          disabled={resetMutation.isPending}
                          data-testid={`button-reset-${role}`}
                        >
                          <RotateCcw className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {categories.map(([catKey, cat]) => (
                <>
                  <tr key={`cat-${catKey}`} className="bg-muted/50">
                    <td colSpan={ROLES.length + 1} className="p-2 font-semibold text-xs text-muted-foreground uppercase tracking-wider">
                      {cat.label}
                    </td>
                  </tr>
                  {cat.permissions.map(perm => (
                    <tr key={perm} className="border-b hover-elevate">
                      <td className="p-3">
                        <span className="text-sm" data-testid={`text-permission-${perm}`}>{perm}</span>
                      </td>
                      {ROLES.map(role => {
                        const granted = getEffectivePermissions(role).has(perm);
                        return (
                          <td key={`${role}-${perm}`} className="text-center p-3">
                            <Button
                              size="icon"
                              variant={granted ? "default" : "ghost"}
                              onClick={() => togglePermission(role, perm)}
                              data-testid={`toggle-${role}-${perm}`}
                            >
                              {granted ? (
                                <Check className="w-4 h-4" />
                              ) : (
                                <X className="w-4 h-4 text-muted-foreground" />
                              )}
                            </Button>
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </>
              ))}
            </tbody>
          </table>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm">How It Works</CardTitle>
          </CardHeader>
          <CardContent className="text-xs text-muted-foreground space-y-1">
            <p data-testid="text-info-1">Toggle permissions for each role. Click Save to apply changes.</p>
            <p data-testid="text-info-2">Changes take effect immediately on the next page load or API call.</p>
            <p data-testid="text-info-3">Use the reset button to restore a role to its default permissions.</p>
          </CardContent>
        </Card>
      </div>
    </RoleLayout>
  );
}
