import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import {
  FileText,
  Upload,
  Sparkles,
  Loader2,
  AlertTriangle,
  CheckCircle,
  ChevronDown,
  ChevronUp,
  ArrowLeft,
  Shield,
  List,
  Hash,
  HelpCircle,
  Eye,
  File,
} from "lucide-react";

interface AdtDocument {
  id: string;
  region: string;
  propertyId: string | null;
  filename: string;
  fileUrl: string | null;
  extractedText: string;
  uploadedByUserId: string | null;
  createdAt: string;
}

interface KeyNumber {
  label: string;
  value: string;
  context: string;
}

interface Risk {
  category: string;
  description: string;
  severity: string;
}

interface SummaryData {
  executiveSummary: string[];
  keyNumbers: KeyNumber[];
  risks: Risk[];
  missingInfo: string[];
  investorQuestions: string[];
  plainEnglishExplanation: string;
}

interface DocSummary {
  id: string;
  documentId: string;
  summaryJson: SummaryData;
  riskFlagsJson: Risk[];
  questionsJson: string[];
  createdAt: string;
}

const ADT_DISCLAIMER =
  "This AI-generated summary is for informational and educational purposes only. " +
  "It does not constitute financial, legal, or investment advice. " +
  "All document analysis should be verified by qualified professionals. " +
  "Past performance is not indicative of future results.";

type View = "list" | "upload" | "detail";

export default function AdminAdtPage({ readOnly = false }: { readOnly?: boolean }) {
  const [view, setView] = useState<View>("list");
  const [selectedDocId, setSelectedDocId] = useState<string | null>(null);

  return (
    <RoleLayout role={readOnly ? "investor" : "admin"} title="ADT Document Summarizer">
      <PageTitle
        title="ADT Document Summarizer"
        subtitle={readOnly ? "View AI-analyzed real estate documents" : "Upload and analyze real estate documents with AI"}
      />
      <Section>
        <div className="flex items-center gap-2 mb-4 text-xs text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg px-3 py-2" data-testid="adt-disclaimer">
          <Shield className="w-4 h-4 shrink-0" />
          <span>{ADT_DISCLAIMER}</span>
        </div>

        {view === "list" && (
          <DocumentList
            readOnly={readOnly}
            onUpload={() => setView("upload")}
            onSelect={(id) => {
              setSelectedDocId(id);
              setView("detail");
            }}
          />
        )}
        {view === "upload" && !readOnly && (
          <UploadForm
            onBack={() => setView("list")}
            onSuccess={(id) => {
              setSelectedDocId(id);
              setView("detail");
            }}
          />
        )}
        {view === "detail" && selectedDocId && (
          <DocumentDetail
            documentId={selectedDocId}
            readOnly={readOnly}
            onBack={() => {
              setSelectedDocId(null);
              setView("list");
            }}
          />
        )}
      </Section>
    </RoleLayout>
  );
}

function DocumentList({
  readOnly,
  onUpload,
  onSelect,
}: {
  readOnly: boolean;
  onUpload: () => void;
  onSelect: (id: string) => void;
}) {
  const { data: documents, isLoading } = useQuery<AdtDocument[]>({
    queryKey: ["/api/ai/adt/documents"],
  });

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold" data-testid="adt-list-heading">Documents</h3>
        {!readOnly && (
          <Button onClick={onUpload} data-testid="adt-upload-btn">
            <Upload className="w-4 h-4 mr-2" />
            Upload Document
          </Button>
        )}
      </div>

      {isLoading && (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      )}

      {!isLoading && (!documents || documents.length === 0) && (
        <Card className="p-8 text-center" data-testid="adt-empty-state">
          <FileText className="w-12 h-12 mx-auto text-muted-foreground/30 mb-3" />
          <p className="text-sm text-muted-foreground mb-4">
            {readOnly ? "No analyzed documents available yet" : "No documents uploaded yet"}
          </p>
          {!readOnly && (
            <Button onClick={onUpload} variant="outline" data-testid="adt-empty-upload-btn">
              <Upload className="w-4 h-4 mr-2" />
              Upload your first document
            </Button>
          )}
        </Card>
      )}

      {documents && documents.length > 0 && (
        <div className="space-y-2" data-testid="adt-document-list">
          {documents.map((doc) => (
            <Card
              key={doc.id}
              className="p-4 cursor-pointer hover:bg-muted/50 transition-colors"
              onClick={() => onSelect(doc.id)}
              data-testid={`adt-doc-${doc.id}`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileText className="w-5 h-5 text-blue-500" />
                  <div>
                    <p className="font-medium text-sm">{doc.filename}</p>
                    <p className="text-xs text-muted-foreground">
                      {doc.region} · {new Date(doc.createdAt).toLocaleDateString()} ·{" "}
                      {doc.extractedText.length.toLocaleString()} chars
                    </p>
                  </div>
                </div>
                <Button variant="ghost" size="sm" data-testid={`adt-view-${doc.id}`}>
                  <Eye className="w-4 h-4 mr-1" />
                  View
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function UploadForm({
  onBack,
  onSuccess,
}: {
  onBack: () => void;
  onSuccess: (id: string) => void;
}) {
  const [filename, setFilename] = useState("");
  const [extractedText, setExtractedText] = useState("");
  const [fileUrl, setFileUrl] = useState("");
  const [region, setRegion] = useState("PK");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadMode, setUploadMode] = useState<"file" | "text">("file");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const uploadMutation = useMutation({
    mutationFn: async () => {
      const formData = new FormData();
      if (uploadMode === "file" && selectedFile) {
        formData.append("file", selectedFile);
        if (filename) formData.append("filename", filename);
      } else {
        formData.append("filename", filename);
        formData.append("extractedText", extractedText);
      }
      formData.append("region", region);
      if (fileUrl) formData.append("fileUrl", fileUrl);

      const token = localStorage.getItem("vestblock_token");
      const res = await fetch("/api/ai/adt/upload", {
        method: "POST",
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        body: formData,
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Upload failed");
      }
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/ai/adt/documents"] });
      toast({ title: "Document uploaded", description: "You can now generate an AI summary." });
      onSuccess(data.document.id);
    },
    onError: (err: any) => {
      toast({ title: "Upload failed", description: err.message, variant: "destructive" });
    },
  });

  const canSubmit =
    uploadMode === "file"
      ? !!selectedFile
      : !!filename.trim() && extractedText.trim().length >= 50;

  return (
    <div>
      <button onClick={onBack} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4" data-testid="adt-back-btn">
        <ArrowLeft className="w-4 h-4" />
        Back to documents
      </button>

      <Card className="p-6" data-testid="adt-upload-form">
        <h3 className="text-lg font-semibold mb-4">Upload Document</h3>

        <div className="flex gap-2 mb-4">
          <Button
            variant={uploadMode === "file" ? "default" : "outline"}
            size="sm"
            onClick={() => setUploadMode("file")}
            data-testid="adt-mode-file"
          >
            <File className="w-4 h-4 mr-1" />
            Upload File
          </Button>
          <Button
            variant={uploadMode === "text" ? "default" : "outline"}
            size="sm"
            onClick={() => setUploadMode("text")}
            data-testid="adt-mode-text"
          >
            <FileText className="w-4 h-4 mr-1" />
            Paste Text
          </Button>
        </div>

        <div className="space-y-4">
          {uploadMode === "file" && (
            <div>
              <Label>Select PDF or Text File</Label>
              <div
                className="mt-1 border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center cursor-pointer hover:border-blue-400 transition-colors"
                onClick={() => fileInputRef.current?.click()}
                data-testid="adt-file-dropzone"
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf,.txt,.csv,text/*"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) {
                      setSelectedFile(f);
                      if (!filename) setFilename(f.name);
                    }
                  }}
                  data-testid="adt-file-input"
                />
                {selectedFile ? (
                  <div className="flex items-center justify-center gap-2">
                    <File className="w-5 h-5 text-blue-500" />
                    <span className="text-sm font-medium">{selectedFile.name}</span>
                    <Badge variant="secondary">{(selectedFile.size / 1024).toFixed(0)} KB</Badge>
                  </div>
                ) : (
                  <>
                    <Upload className="w-8 h-8 mx-auto text-muted-foreground/40 mb-2" />
                    <p className="text-sm text-muted-foreground">Click to select a PDF or text file</p>
                    <p className="text-xs text-muted-foreground mt-1">Max 10 MB</p>
                  </>
                )}
              </div>
            </div>
          )}

          <div>
            <Label htmlFor="filename">Document Name {uploadMode === "file" && "(auto-filled from file)"}</Label>
            <Input
              id="filename"
              value={filename}
              onChange={(e) => setFilename(e.target.value)}
              placeholder="e.g., Plot 42 Title Deed"
              data-testid="adt-filename-input"
            />
          </div>

          <div>
            <Label htmlFor="region">Region</Label>
            <select
              id="region"
              value={region}
              onChange={(e) => setRegion(e.target.value)}
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background"
              data-testid="adt-region-select"
            >
              <option value="PK">Pakistan</option>
              <option value="AE">UAE</option>
              <option value="GB">UK</option>
            </select>
          </div>

          <div>
            <Label htmlFor="fileUrl">File URL (optional)</Label>
            <Input
              id="fileUrl"
              value={fileUrl}
              onChange={(e) => setFileUrl(e.target.value)}
              placeholder="https://..."
              data-testid="adt-fileurl-input"
            />
          </div>

          {uploadMode === "text" && (
            <div>
              <Label htmlFor="extractedText">Document Text</Label>
              <p className="text-xs text-muted-foreground mb-1">
                Paste the full text content of the document (minimum 50 characters).
              </p>
              <Textarea
                id="extractedText"
                value={extractedText}
                onChange={(e) => setExtractedText(e.target.value)}
                placeholder="Paste document text here..."
                rows={12}
                data-testid="adt-text-input"
              />
              <p className="text-xs text-muted-foreground mt-1">
                {extractedText.length.toLocaleString()} characters
              </p>
            </div>
          )}

          <Button
            onClick={() => uploadMutation.mutate()}
            disabled={!canSubmit || uploadMutation.isPending}
            className="w-full"
            data-testid="adt-submit-upload"
          >
            {uploadMutation.isPending ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Upload className="w-4 h-4 mr-2" />
            )}
            Upload Document
          </Button>
        </div>
      </Card>
    </div>
  );
}

function DocumentDetail({
  documentId,
  readOnly,
  onBack,
}: {
  documentId: string;
  readOnly: boolean;
  onBack: () => void;
}) {
  const { toast } = useToast();

  const { data, isLoading } = useQuery<{ document: AdtDocument; summaries: DocSummary[] }>({
    queryKey: ["/api/ai/adt/documents", documentId],
  });

  const summarizeMutation = useMutation({
    mutationFn: async () => {
      const token = localStorage.getItem("vestblock_token");
      const res = await fetch("/api/ai/adt/summarize", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ documentId }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Summarization failed");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ai/adt/documents", documentId] });
      toast({ title: "Summary generated", description: "AI analysis is ready." });
    },
    onError: (err: any) => {
      toast({ title: "Summarization failed", description: err.message, variant: "destructive" });
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!data) return null;
  const { document: doc, summaries } = data;
  const latestSummary = summaries.length > 0 ? summaries[0] : null;

  return (
    <div>
      <button onClick={onBack} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4" data-testid="adt-detail-back">
        <ArrowLeft className="w-4 h-4" />
        Back to documents
      </button>

      <div className="flex items-start justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold" data-testid="adt-doc-title">{doc.filename}</h3>
          <p className="text-sm text-muted-foreground">
            {doc.region} · Uploaded {new Date(doc.createdAt).toLocaleDateString()} ·{" "}
            {doc.extractedText.length.toLocaleString()} characters
          </p>
        </div>
        {!readOnly && (
          <Button
            onClick={() => summarizeMutation.mutate()}
            disabled={summarizeMutation.isPending}
            data-testid="adt-summarize-btn"
          >
            {summarizeMutation.isPending ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Sparkles className="w-4 h-4 mr-2" />
            )}
            {latestSummary ? "Re-analyze" : "Generate Summary"}
          </Button>
        )}
      </div>

      {!readOnly && (
        <Card className="p-4 mb-6" data-testid="adt-text-preview">
          <div className="flex items-center gap-2 mb-2">
            <FileText className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm font-medium">Document Text Preview</span>
          </div>
          <p className="text-xs text-muted-foreground whitespace-pre-wrap max-h-40 overflow-y-auto">
            {doc.extractedText.substring(0, 2000)}
            {doc.extractedText.length > 2000 && "..."}
          </p>
        </Card>
      )}

      {summarizeMutation.isPending && (
        <Card className="p-8 text-center mb-6" data-testid="adt-analyzing">
          <Loader2 className="w-8 h-8 mx-auto animate-spin text-blue-500 mb-3" />
          <p className="text-sm font-medium">Analyzing document...</p>
          <p className="text-xs text-muted-foreground mt-1">This may take 15-30 seconds</p>
        </Card>
      )}

      {latestSummary && <SummaryView summary={latestSummary} />}

      {!latestSummary && readOnly && (
        <Card className="p-8 text-center">
          <FileText className="w-10 h-10 mx-auto text-muted-foreground/30 mb-3" />
          <p className="text-sm text-muted-foreground">No AI summary available for this document yet.</p>
        </Card>
      )}
    </div>
  );
}

function SummaryView({ summary }: { summary: DocSummary }) {
  const s = summary.summaryJson;
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    executive: true,
    numbers: true,
    risks: true,
    missing: false,
    questions: false,
    plain: false,
  });

  function toggle(key: string) {
    setExpandedSections((prev) => ({ ...prev, [key]: !prev[key] }));
  }

  return (
    <div className="space-y-4" data-testid="adt-summary-view">
      <div className="flex items-center gap-2 text-xs text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg px-3 py-2">
        <Shield className="w-4 h-4 shrink-0" />
        <span>{ADT_DISCLAIMER}</span>
      </div>

      <SectionCollapse
        title="Executive Summary"
        icon={<List className="w-4 h-4 text-blue-500" />}
        expanded={expandedSections.executive}
        onToggle={() => toggle("executive")}
        testId="adt-section-executive"
      >
        <ul className="space-y-2">
          {(s.executiveSummary || []).map((bullet, i) => (
            <li key={i} className="flex gap-2 text-sm">
              <CheckCircle className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
              <span>{bullet}</span>
            </li>
          ))}
        </ul>
      </SectionCollapse>

      <SectionCollapse
        title="Key Numbers"
        icon={<Hash className="w-4 h-4 text-indigo-500" />}
        expanded={expandedSections.numbers}
        onToggle={() => toggle("numbers")}
        testId="adt-section-numbers"
      >
        {(s.keyNumbers || []).length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2 pr-4 font-medium text-muted-foreground">Metric</th>
                  <th className="text-left py-2 pr-4 font-medium text-muted-foreground">Value</th>
                  <th className="text-left py-2 font-medium text-muted-foreground">Context</th>
                </tr>
              </thead>
              <tbody>
                {s.keyNumbers.map((n, i) => (
                  <tr key={i} className="border-b last:border-0">
                    <td className="py-2 pr-4 font-medium">{n.label}</td>
                    <td className="py-2 pr-4 text-blue-600 dark:text-blue-400 font-mono">{n.value}</td>
                    <td className="py-2 text-muted-foreground">{n.context}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">No key numbers extracted</p>
        )}
      </SectionCollapse>

      <SectionCollapse
        title={`Risk Flags (${(s.risks || []).length})`}
        icon={<AlertTriangle className="w-4 h-4 text-orange-500" />}
        expanded={expandedSections.risks}
        onToggle={() => toggle("risks")}
        testId="adt-section-risks"
      >
        {(s.risks || []).length > 0 ? (
          <div className="space-y-2">
            {s.risks.map((r, i) => (
              <div key={i} className="flex items-start gap-2">
                <Badge
                  variant={r.severity === "high" ? "destructive" : r.severity === "medium" ? "default" : "secondary"}
                  className="shrink-0 mt-0.5"
                >
                  {r.severity}
                </Badge>
                <div>
                  <span className="text-xs font-medium text-muted-foreground">{r.category}</span>
                  <p className="text-sm">{r.description}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">No risks flagged</p>
        )}
      </SectionCollapse>

      <SectionCollapse
        title={`Missing Information (${(s.missingInfo || []).length})`}
        icon={<AlertTriangle className="w-4 h-4 text-yellow-500" />}
        expanded={expandedSections.missing}
        onToggle={() => toggle("missing")}
        testId="adt-section-missing"
      >
        {(s.missingInfo || []).length > 0 ? (
          <ul className="space-y-1">
            {s.missingInfo.map((item, i) => (
              <li key={i} className="flex gap-2 text-sm">
                <span className="text-yellow-500">○</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-muted-foreground">No missing information identified</p>
        )}
      </SectionCollapse>

      <SectionCollapse
        title={`Investor Questions (${(s.investorQuestions || []).length})`}
        icon={<HelpCircle className="w-4 h-4 text-purple-500" />}
        expanded={expandedSections.questions}
        onToggle={() => toggle("questions")}
        testId="adt-section-questions"
      >
        {(s.investorQuestions || []).length > 0 ? (
          <ol className="space-y-1 list-decimal list-inside">
            {s.investorQuestions.map((q, i) => (
              <li key={i} className="text-sm">{q}</li>
            ))}
          </ol>
        ) : (
          <p className="text-sm text-muted-foreground">No questions generated</p>
        )}
      </SectionCollapse>

      <SectionCollapse
        title="Plain English Explanation"
        icon={<FileText className="w-4 h-4 text-teal-500" />}
        expanded={expandedSections.plain}
        onToggle={() => toggle("plain")}
        testId="adt-section-plain"
      >
        <p className="text-sm leading-relaxed whitespace-pre-wrap">
          {s.plainEnglishExplanation || "No explanation available"}
        </p>
      </SectionCollapse>
    </div>
  );
}

function SectionCollapse({
  title,
  icon,
  expanded,
  onToggle,
  children,
  testId,
}: {
  title: string;
  icon: React.ReactNode;
  expanded: boolean;
  onToggle: () => void;
  children: React.ReactNode;
  testId: string;
}) {
  return (
    <Card className="overflow-hidden" data-testid={testId}>
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between px-4 py-3 hover:bg-muted/50 transition-colors"
        data-testid={`${testId}-toggle`}
      >
        <div className="flex items-center gap-2">
          {icon}
          <span className="font-medium text-sm">{title}</span>
        </div>
        {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
      </button>
      {expanded && <div className="px-4 pb-4">{children}</div>}
    </Card>
  );
}
