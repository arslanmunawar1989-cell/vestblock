import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { type CryptoWallet, SUPPORTED_CHAINS } from "@shared/schema";
import {
  ShieldAlert,
  ShieldCheck,
  StickyNote,
  Copy,
  ExternalLink,
  Search, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface UserInfo {
  id: string;
  username: string;
  fullName: string;
  email: string;
}

export default function AdminCryptoWallets() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterBlacklisted, setFilterBlacklisted] = useState<"all" | "blacklisted" | "clean">("all");
  const [blacklistDialog, setBlacklistDialog] = useState<CryptoWallet | null>(null);
  const [notesDialog, setNotesDialog] = useState<CryptoWallet | null>(null);
  const [blacklistReason, setBlacklistReason] = useState("");
  const [adminNotes, setAdminNotes] = useState("");

  const { data: wallets, isLoading } = useQuery<CryptoWallet[]>({
    queryKey: ["/api/admin/crypto/wallets"],
  });

  const { data: users } = useQuery<UserInfo[]>({
    queryKey: ["/api/users"],
  });

  const blacklistMutation = useMutation({
    mutationFn: async ({ id, reason }: { id: string; reason: string }) => {
      const res = await apiRequest("POST", `/api/admin/crypto/wallets/${id}/blacklist`, { reason });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/crypto/wallets"] });
      setBlacklistDialog(null);
      setBlacklistReason("");
      toast({ title: "Wallet blacklisted" });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to blacklist", description: error.message, variant: "destructive" });
    },
  });

  const unblacklistMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("POST", `/api/admin/crypto/wallets/${id}/unblacklist`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/crypto/wallets"] });
      toast({ title: "Wallet unblacklisted" });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to unblacklist", description: error.message, variant: "destructive" });
    },
  });

  const notesMutation = useMutation({
    mutationFn: async ({ id, notes }: { id: string; notes: string }) => {
      const res = await apiRequest("PATCH", `/api/admin/crypto/wallets/${id}/notes`, { notes });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/crypto/wallets"] });
      setNotesDialog(null);
      setAdminNotes("");
      toast({ title: "Notes updated" });
    },
    onError: (error: Error) => {
      toast({ title: "Failed to update notes", description: error.message, variant: "destructive" });
    },
  });

  function getChain(chainId: string) {
    return SUPPORTED_CHAINS.find(c => c.id === chainId);
  }

  function getUser(userId: string) {
    return users?.find((u: UserInfo) => u.id === userId);
  }

  function copyAddress(address: string) {
    navigator.clipboard.writeText(address);
    toast({ title: "Address copied" });
  }

  function truncateAddress(addr: string) {
    if (addr.length <= 16) return addr;
    return `${addr.slice(0, 8)}...${addr.slice(-6)}`;
  }

  const filtered = wallets?.filter(w => {
    if (filterBlacklisted === "blacklisted" && !w.isBlacklisted) return false;
    if (filterBlacklisted === "clean" && w.isBlacklisted) return false;
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      const user = getUser(w.userId);
      return (
        w.address.toLowerCase().includes(term) ||
        w.chainId.toLowerCase().includes(term) ||
        (w.label || "").toLowerCase().includes(term) ||
        (user?.username || "").toLowerCase().includes(term) ||
        (user?.fullName || "").toLowerCase().includes(term)
      );
    }
    return true;
  }) || [];

  const blacklistedCount = wallets?.filter(w => w.isBlacklisted).length || 0;

  return (
    <RoleLayout role="admin">
      <div className="p-6 space-y-6 max-w-6xl mx-auto">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle title="Crypto Wallets" description="Manage investor crypto wallet addresses and blacklist suspicious wallets" />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <GlassCard className="p-4 text-center">
            <p className="text-2xl font-bold" data-testid="text-total-wallets">{wallets?.length || 0}</p>
            <p className="text-sm text-muted-foreground">Total Wallets</p>
          </GlassCard>
          <GlassCard className="p-4 text-center">
            <p className="text-2xl font-bold text-destructive" data-testid="text-blacklisted-count">{blacklistedCount}</p>
            <p className="text-sm text-muted-foreground">Blacklisted</p>
          </GlassCard>
          <GlassCard className="p-4 text-center">
            <p className="text-2xl font-bold" data-testid="text-clean-count">{(wallets?.length || 0) - blacklistedCount}</p>
            <p className="text-sm text-muted-foreground">Clean</p>
          </GlassCard>
        </div>

        <Section title="All Wallets">
          <div className="flex items-center gap-3 flex-wrap mb-4">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by address, chain, user..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
                data-testid="input-search-wallets"
              />
            </div>
            <div className="flex gap-1">
              <Button
                variant={filterBlacklisted === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterBlacklisted("all")}
                data-testid="button-filter-all"
              >
                All
              </Button>
              <Button
                variant={filterBlacklisted === "blacklisted" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterBlacklisted("blacklisted")}
                data-testid="button-filter-blacklisted"
              >
                Blacklisted
              </Button>
              <Button
                variant={filterBlacklisted === "clean" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterBlacklisted("clean")}
                data-testid="button-filter-clean"
              >
                Clean
              </Button>
            </div>
          </div>

          {isLoading ? (
            <div className="space-y-3">
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-24 w-full" />
            </div>
          ) : filtered.length === 0 ? (
            <GlassCard className="p-8 text-center">
              <p className="text-muted-foreground">No wallets found matching your criteria.</p>
            </GlassCard>
          ) : (
            <div className="space-y-3">
              {filtered.map(wallet => {
                const chain = getChain(wallet.chainId);
                const user = getUser(wallet.userId);
                return (
                  <GlassCard key={wallet.id} className="p-4" data-testid={`card-admin-wallet-${wallet.id}`}>
                    <div className="flex items-start justify-between flex-wrap gap-3">
                      <div className="space-y-1 min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium">{chain?.name || wallet.chainId}</span>
                          <Badge variant="secondary">{chain?.symbol || wallet.chainId}</Badge>
                          {wallet.isBlacklisted && (
                            <Badge variant="destructive" data-testid={`badge-bl-${wallet.id}`}>
                              <ShieldAlert className="w-3 h-3 mr-1" />
                              Blacklisted
                            </Badge>
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          User: <span className="font-medium" data-testid={`text-user-${wallet.id}`}>{user?.fullName || wallet.userId}</span>
                          {user && <span className="ml-1">(@{user.username})</span>}
                        </div>
                        {wallet.label && <div className="text-sm text-muted-foreground">Label: {wallet.label}</div>}
                        <div className="flex items-center gap-2">
                          <code className="text-xs font-mono bg-muted px-2 py-1 rounded-md break-all" data-testid={`text-addr-${wallet.id}`}>
                            {truncateAddress(wallet.address)}
                          </code>
                          <Button size="icon" variant="ghost" onClick={() => copyAddress(wallet.address)} data-testid={`button-copy-${wallet.id}`}>
                            <Copy className="w-3 h-3" />
                          </Button>
                          {chain && (
                            <a href={`${chain.explorerUrl}/address/${wallet.address}`} target="_blank" rel="noopener noreferrer">
                              <Button size="icon" variant="ghost">
                                <ExternalLink className="w-3 h-3" />
                              </Button>
                            </a>
                          )}
                        </div>
                        {wallet.blacklistReason && (
                          <div className="text-sm mt-1">
                            <span className="text-destructive font-medium">Reason:</span> {wallet.blacklistReason}
                          </div>
                        )}
                        {wallet.adminNotes && (
                          <div className="text-sm mt-1 bg-muted/50 p-2 rounded-md" data-testid={`text-notes-${wallet.id}`}>
                            <span className="font-medium">Notes:</span> {wallet.adminNotes}
                          </div>
                        )}
                      </div>
                      <div className="flex gap-1">
                        {wallet.isBlacklisted ? (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => unblacklistMutation.mutate(wallet.id)}
                            disabled={unblacklistMutation.isPending}
                            data-testid={`button-unblacklist-${wallet.id}`}
                          >
                            <ShieldCheck className="w-3 h-3 mr-1" />
                            Unblacklist
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => { setBlacklistDialog(wallet); setBlacklistReason(""); }}
                            data-testid={`button-blacklist-${wallet.id}`}
                          >
                            <ShieldAlert className="w-3 h-3 mr-1" />
                            Blacklist
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => { setNotesDialog(wallet); setAdminNotes(wallet.adminNotes || ""); }}
                          data-testid={`button-notes-${wallet.id}`}
                        >
                          <StickyNote className="w-3 h-3 mr-1" />
                          Notes
                        </Button>
                      </div>
                    </div>
                  </GlassCard>
                );
              })}
            </div>
          )}
        </Section>

        <Dialog open={!!blacklistDialog} onOpenChange={(open) => !open && setBlacklistDialog(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Blacklist Wallet</DialogTitle>
              <DialogDescription>
                Blacklisting will prevent this wallet from being used or deleted. Provide a reason for the record.
              </DialogDescription>
            </DialogHeader>
            {blacklistDialog && (
              <div className="space-y-4">
                <div className="text-sm">
                  <p><span className="font-medium">Chain:</span> {getChain(blacklistDialog.chainId)?.name || blacklistDialog.chainId}</p>
                  <p className="font-mono text-xs break-all mt-1">{blacklistDialog.address}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">Reason</label>
                  <Textarea
                    placeholder="Enter reason for blacklisting..."
                    value={blacklistReason}
                    onChange={(e) => setBlacklistReason(e.target.value)}
                    className="mt-1"
                    data-testid="input-blacklist-reason"
                  />
                </div>
                <Button
                  variant="destructive"
                  className="w-full"
                  onClick={() => blacklistMutation.mutate({ id: blacklistDialog.id, reason: blacklistReason })}
                  disabled={!blacklistReason.trim() || blacklistMutation.isPending}
                  data-testid="button-confirm-blacklist"
                >
                  {blacklistMutation.isPending ? "Blacklisting..." : "Confirm Blacklist"}
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>

        <Dialog open={!!notesDialog} onOpenChange={(open) => !open && setNotesDialog(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Admin Notes</DialogTitle>
              <DialogDescription>
                Add internal notes about this wallet address for compliance review.
              </DialogDescription>
            </DialogHeader>
            {notesDialog && (
              <div className="space-y-4">
                <div className="text-sm">
                  <p><span className="font-medium">Chain:</span> {getChain(notesDialog.chainId)?.name || notesDialog.chainId}</p>
                  <p className="font-mono text-xs break-all mt-1">{notesDialog.address}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">Notes</label>
                  <Textarea
                    placeholder="Enter admin notes..."
                    value={adminNotes}
                    onChange={(e) => setAdminNotes(e.target.value)}
                    className="mt-1"
                    data-testid="input-admin-notes"
                  />
                </div>
                <Button
                  className="w-full"
                  onClick={() => notesMutation.mutate({ id: notesDialog.id, notes: adminNotes })}
                  disabled={notesMutation.isPending}
                  data-testid="button-save-notes"
                >
                  {notesMutation.isPending ? "Saving..." : "Save Notes"}
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </RoleLayout>
  );
}
