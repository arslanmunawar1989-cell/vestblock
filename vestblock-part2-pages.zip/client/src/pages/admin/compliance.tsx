import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { StatTile } from "@/components/stat-tile";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { SUPPORTED_COUNTRIES, COUNTRY_DETAILS } from "@shared/constants";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate } from "@/lib/format";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  ShieldCheck, AlertTriangle, FileCheck, Clock, Search,
  CheckCircle2, XCircle, Eye, Loader2, FileText, User, Info,
  Download, FilePlus, History, ClipboardList, Globe, Ban, ArrowLeft,
} from "lucide-react";
import { getAllPolicies } from "@shared/compliance-policy";
import { SANCTIONED_COUNTRIES, COUNTRY_INVESTOR_POLICIES } from "@shared/investor-policy";
import { Link } from "wouter";
interface KycUser {
  id: string;
  username: string;
  email: string;
  fullName: string;
}

interface KycProfileWithUser {
  id: string;
  userId: string;
  legalName: string;
  dob: string;
  address: string;
  idType: string;
  idNumber: string;
  emiratesIdFlag: boolean;
  sourceOfWealth: string;
  sourceOfFunds: string;
  pepFlag: boolean;
  status: string;
  submittedAt: string;
  reviewedAt: string | null;
  reviewNotes: string | null;
  user: KycUser | null;
  documentCount: number;
  countryCode: string | null;
}

interface KycDocument {
  id: string;
  type: string;
  fileName: string;
  url: string;
  mimeType: string | null;
  fileSize: number | null;
  status: string;
  createdAt: string;
}

interface KycDetailResponse extends Omit<KycProfileWithUser, 'documentCount'> {
  documents: KycDocument[];
}

interface RiskReviewTemplate {
  id: string;
  label: string;
  notes: string;
}

interface KycDocRequirement {
  docType: string;
  label: string;
  description: string;
  required: boolean;
}

interface RiskTemplateResponse {
  countryCode: string;
  countryName: string;
  templates: RiskReviewTemplate[];
  requiredDocs: KycDocRequirement[];
}

interface AuditLogEntry {
  id: string;
  action: string;
  entity: string;
  entityId: string;
  details: string;
  ipAddress: string | null;
  createdAt: string;
}

function KycStatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
    IN_REVIEW: { label: "In Review", variant: "default" },
    APPROVED: { label: "Approved", variant: "secondary" },
    REJECTED: { label: "Rejected", variant: "destructive" },
    INFO_REQUESTED: { label: "Info Requested", variant: "outline" },
    EXPIRED: { label: "Expired", variant: "secondary" },
  };
  const c = config[status] || { label: status, variant: "secondary" };
  return <Badge variant={c.variant} data-testid={`badge-kyc-status-${status}`}>{c.label}</Badge>;
}

function KycDetailModal({ profileId, open, onClose }: { profileId: string | null; open: boolean; onClose: () => void }) {
  const { toast } = useToast();
  const [actionNotes, setActionNotes] = useState("");
  const [confirmAction, setConfirmAction] = useState<"approve" | "reject" | "request_info" | "request_doc" | null>(null);
  const [selectedDocType, setSelectedDocType] = useState("");
  const [activeTab, setActiveTab] = useState("details");

  const { data: detail, isLoading } = useQuery<KycDetailResponse>({
    queryKey: ["/api/admin/kyc", profileId],
    enabled: !!profileId && open,
  });

  const { data: riskData } = useQuery<RiskTemplateResponse>({
    queryKey: ["/api/admin/kyc", profileId, "risk-templates"],
    enabled: !!profileId && open,
  });

  const { data: auditLogs = [] } = useQuery<AuditLogEntry[]>({
    queryKey: ["/api/admin/kyc", profileId, "audit-log"],
    enabled: !!profileId && open && activeTab === "audit",
  });

  const actionMutation = useMutation({
    mutationFn: async (payload: { action: string; notes?: string; requestedDocType?: string; requestedDocLabel?: string }) => {
      const res = await apiRequest("POST", `/api/admin/kyc/${profileId}/action`, payload);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/kyc"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/kyc", profileId] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/kyc", profileId, "audit-log"] });
      toast({ title: "Action completed", description: "KYC profile has been updated." });
      resetActionState();
      onClose();
    },
    onError: (err: any) => {
      toast({ title: "Action failed", description: err.message || "Please try again.", variant: "destructive" });
    },
  });

  const resetActionState = () => {
    setConfirmAction(null);
    setActionNotes("");
    setSelectedDocType("");
  };

  const handleAction = () => {
    if (!confirmAction) return;
    if (confirmAction === "request_doc") {
      const docReq = riskData?.requiredDocs.find(d => d.docType === selectedDocType);
      actionMutation.mutate({
        action: "request_doc",
        notes: actionNotes || undefined,
        requestedDocType: selectedDocType,
        requestedDocLabel: docReq?.label || selectedDocType.replace(/_/g, " "),
      });
    } else {
      actionMutation.mutate({ action: confirmAction, notes: actionNotes || undefined });
    }
  };

  const applyTemplate = (notes: string) => {
    setActionNotes(notes);
  };

  if (!open) return null;

  const isRequestDocDisabled = confirmAction === "request_doc" && !selectedDocType;

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) { resetActionState(); onClose(); } }}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>KYC Application Review</DialogTitle>
          <DialogDescription>Review the applicant's information and supporting documents.</DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin text-primary" />
          </div>
        ) : detail ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-muted-foreground" />
                <span className="font-medium text-sm" data-testid="detail-user-name">{detail.user?.fullName || "Unknown"}</span>
                <span className="text-xs text-muted-foreground">({detail.user?.email})</span>
              </div>
              <div className="flex items-center gap-2">
                {riskData && <Badge variant="outline" data-testid="badge-country">{riskData.countryName}</Badge>}
                <KycStatusBadge status={detail.status} />
              </div>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="w-full">
                <TabsTrigger value="details" data-testid="tab-details" className="flex-1">
                  <FileText className="w-3 h-3 mr-1" /> Details
                </TabsTrigger>
                <TabsTrigger value="audit" data-testid="tab-audit" className="flex-1">
                  <History className="w-3 h-3 mr-1" /> Audit Log
                </TabsTrigger>
                <TabsTrigger value="risk" data-testid="tab-risk" className="flex-1">
                  <ClipboardList className="w-3 h-3 mr-1" /> Risk Review
                </TabsTrigger>
              </TabsList>

              <TabsContent value="details" className="mt-4 space-y-4">
                <GlassCard>
                  <h4 className="font-medium text-sm mb-3">Personal Information</h4>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <Label className="text-muted-foreground text-xs">Legal Name</Label>
                      <p data-testid="detail-legal-name">{detail.legalName}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground text-xs">Date of Birth</Label>
                      <p>{detail.dob}</p>
                    </div>
                    <div className="col-span-2">
                      <Label className="text-muted-foreground text-xs">Address</Label>
                      <p>{detail.address}</p>
                    </div>
                  </div>
                </GlassCard>

                <GlassCard>
                  <h4 className="font-medium text-sm mb-3">ID Verification</h4>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <Label className="text-muted-foreground text-xs">ID Type</Label>
                      <p className="capitalize">{detail.idType?.replace(/_/g, " ")}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground text-xs">ID Number</Label>
                      <p>{detail.idNumber}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground text-xs">Emirates ID</Label>
                      <p>{detail.emiratesIdFlag ? "Yes" : "No"}</p>
                    </div>
                  </div>
                </GlassCard>

                <GlassCard>
                  <h4 className="font-medium text-sm mb-3">Financial Information</h4>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <Label className="text-muted-foreground text-xs">Source of Wealth</Label>
                      <p>{detail.sourceOfWealth}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground text-xs">Source of Funds</Label>
                      <p>{detail.sourceOfFunds}</p>
                    </div>
                    <div>
                      <Label className="text-muted-foreground text-xs">PEP Status</Label>
                      <Badge variant={detail.pepFlag ? "destructive" : "secondary"}>
                        {detail.pepFlag ? "Yes - PEP" : "No"}
                      </Badge>
                    </div>
                  </div>
                </GlassCard>

                <GlassCard>
                  <h4 className="font-medium text-sm mb-3">Uploaded Documents ({detail.documents?.length || 0})</h4>
                  {detail.documents && detail.documents.length > 0 ? (
                    <div className="space-y-2">
                      {detail.documents.map((doc) => (
                        <div key={doc.id} className="flex items-center justify-between gap-2 p-2 bg-muted/50 rounded-md" data-testid={`doc-item-${doc.type}`}>
                          <div className="flex items-center gap-2 min-w-0">
                            <FileText className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                            <div className="min-w-0">
                              <p className="text-xs font-medium capitalize">{doc.type.replace(/_/g, " ")}</p>
                              <p className="text-xs text-muted-foreground truncate">{doc.fileName}</p>
                            </div>
                          </div>
                          <a href={doc.url.startsWith("/objects") ? doc.url : `/objects/${doc.url}`} target="_blank" rel="noopener noreferrer">
                            <Button size="icon" variant="ghost" data-testid={`button-view-doc-${doc.type}`}>
                              <Download className="w-3 h-3" />
                            </Button>
                          </a>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">No documents uploaded</p>
                  )}
                </GlassCard>

                {detail.reviewNotes && (
                  <GlassCard>
                    <h4 className="font-medium text-sm mb-2">Previous Review Notes</h4>
                    <p className="text-sm text-muted-foreground" data-testid="text-review-notes">{detail.reviewNotes}</p>
                  </GlassCard>
                )}
              </TabsContent>

              <TabsContent value="audit" className="mt-4">
                <GlassCard>
                  <h4 className="font-medium text-sm mb-3">Audit Trail</h4>
                  {auditLogs.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No audit entries found.</p>
                  ) : (
                    <div className="space-y-3" data-testid="audit-log-list">
                      {auditLogs.map((log) => (
                        <div key={log.id} className="flex items-start gap-3 p-2 bg-muted/50 rounded-md" data-testid={`audit-entry-${log.id}`}>
                          <History className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <Badge variant="outline" className="text-xs">{log.action.replace(/_/g, " ")}</Badge>
                              <span className="text-xs text-muted-foreground">
                                {formatDate(log.createdAt, "long")}
                              </span>
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">{log.details}</p>
                            {log.ipAddress && (
                              <p className="text-xs text-muted-foreground">IP: {log.ipAddress}</p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </GlassCard>
              </TabsContent>

              <TabsContent value="risk" className="mt-4">
                <GlassCard>
                  <h4 className="font-medium text-sm mb-3">Country-Based Risk Review Notes Templates</h4>
                  <p className="text-xs text-muted-foreground mb-3">
                    Select a template to pre-fill review notes based on {riskData?.countryName || "the applicant's"} compliance requirements.
                  </p>
                  {riskData?.templates ? (
                    <div className="space-y-2" data-testid="risk-templates-list">
                      {riskData.templates.map((tmpl) => (
                        <div key={tmpl.id} className="flex items-start justify-between gap-2 p-2 bg-muted/50 rounded-md" data-testid={`risk-template-${tmpl.id}`}>
                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-medium">{tmpl.label}</p>
                            <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{tmpl.notes}</p>
                          </div>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              applyTemplate(tmpl.notes);
                              setActiveTab("details");
                              if (!confirmAction) setConfirmAction("request_info");
                              toast({ title: "Template applied", description: `"${tmpl.label}" notes loaded.` });
                            }}
                            data-testid={`button-apply-template-${tmpl.id}`}
                          >
                            Use
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex items-center justify-center py-4">
                      <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                    </div>
                  )}
                </GlassCard>
              </TabsContent>
            </Tabs>

            {(detail.status === "IN_REVIEW" || detail.status === "INFO_REQUESTED") && (
              <div className="space-y-3 pt-2">
                {!confirmAction ? (
                  <div className="flex items-center gap-2 flex-wrap">
                    <Button onClick={() => setConfirmAction("approve")} data-testid="button-approve-kyc">
                      <CheckCircle2 className="w-4 h-4 mr-1" />
                      Approve
                    </Button>
                    <Button variant="destructive" onClick={() => setConfirmAction("reject")} data-testid="button-reject-kyc">
                      <XCircle className="w-4 h-4 mr-1" />
                      Reject
                    </Button>
                    <Button variant="outline" onClick={() => setConfirmAction("request_info")} data-testid="button-request-info-kyc">
                      <Info className="w-4 h-4 mr-1" />
                      Request Info
                    </Button>
                    <Button variant="outline" onClick={() => setConfirmAction("request_doc")} data-testid="button-request-doc-kyc">
                      <FilePlus className="w-4 h-4 mr-1" />
                      Request Document
                    </Button>
                  </div>
                ) : (
                  <GlassCard>
                    <h4 className="font-medium text-sm mb-2 capitalize">
                      {confirmAction === "request_doc" ? "Request Additional Document" : confirmAction.replace(/_/g, " ") + " Application"}
                    </h4>

                    {confirmAction === "request_doc" && (
                      <div className="mb-3">
                        <Label className="text-xs text-muted-foreground mb-1.5 block">Document Type Required</Label>
                        <Select value={selectedDocType} onValueChange={setSelectedDocType}>
                          <SelectTrigger data-testid="select-request-doc-type">
                            <SelectValue placeholder="Select document type..." />
                          </SelectTrigger>
                          <SelectContent>
                            {riskData?.requiredDocs.map((doc) => (
                              <SelectItem key={doc.docType} value={doc.docType} data-testid={`option-doc-${doc.docType}`}>
                                {doc.label}
                              </SelectItem>
                            )) || (
                              <>
                                <SelectItem value="id_front">ID Front</SelectItem>
                                <SelectItem value="id_back">ID Back</SelectItem>
                                <SelectItem value="proof_of_address">Proof of Address</SelectItem>
                                <SelectItem value="bank_statement">Bank Statement</SelectItem>
                                <SelectItem value="source_of_funds">Source of Funds</SelectItem>
                                <SelectItem value="other">Other</SelectItem>
                              </>
                            )}
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    <Textarea
                      placeholder={confirmAction === "approve" ? "Optional notes..." : confirmAction === "request_doc" ? "Specify what the investor needs to provide..." : "Reason or details (required)..."}
                      value={actionNotes}
                      onChange={(e) => setActionNotes(e.target.value)}
                      className="text-sm mb-3"
                      data-testid="textarea-action-notes"
                    />
                    <div className="flex items-center gap-2">
                      <Button
                        onClick={handleAction}
                        disabled={actionMutation.isPending || (confirmAction !== "approve" && confirmAction !== "request_doc" && !actionNotes.trim()) || isRequestDocDisabled}
                        data-testid="button-confirm-action"
                      >
                        {actionMutation.isPending && <Loader2 className="w-4 h-4 mr-1 animate-spin" />}
                        {confirmAction === "request_doc" ? "Send Document Request" : `Confirm ${confirmAction.replace(/_/g, " ")}`}
                      </Button>
                      <Button variant="outline" onClick={resetActionState} data-testid="button-cancel-action">
                        Cancel
                      </Button>
                    </div>
                  </GlassCard>
                )}
              </div>
            )}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">Failed to load profile details.</p>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default function AdminCompliance() {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [countryFilter, setCountryFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedProfileId, setSelectedProfileId] = useState<string | null>(null);

  const { data: profiles = [], isLoading } = useQuery<KycProfileWithUser[]>({
    queryKey: ["/api/admin/kyc"],
  });

  const filtered = profiles.filter((p) => {
    if (statusFilter !== "all" && p.status !== statusFilter) return false;
    if (countryFilter !== "all" && p.countryCode !== countryFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        p.legalName?.toLowerCase().includes(q) ||
        p.user?.fullName?.toLowerCase().includes(q) ||
        p.user?.email?.toLowerCase().includes(q) ||
        p.user?.username?.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const stats = {
    total: profiles.length,
    inReview: profiles.filter(p => p.status === "IN_REVIEW").length,
    approved: profiles.filter(p => p.status === "APPROVED").length,
    rejected: profiles.filter(p => p.status === "REJECTED").length,
  };

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle title="Compliance" description="Review and manage KYC verification applications" />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatTile label="Total Applications" value={String(stats.total)} icon={<FileCheck className="w-5 h-5" />} />
          <StatTile label="Pending Review" value={String(stats.inReview)} trend="neutral" icon={<Clock className="w-5 h-5" />} />
          <StatTile label="Approved" value={String(stats.approved)} trend="up" icon={<ShieldCheck className="w-5 h-5" />} />
          <StatTile label="Rejected" value={String(stats.rejected)} trend="down" icon={<AlertTriangle className="w-5 h-5" />} />
        </div>

        <Section title="KYC Queue">
          <div className="flex items-center gap-3 mb-4 flex-wrap">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by name, email, or username..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
                data-testid="input-search-kyc"
              />
            </div>
            <Select value={countryFilter} onValueChange={setCountryFilter}>
              <SelectTrigger className="w-[160px]" data-testid="select-country-filter">
                <SelectValue placeholder="All Countries" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Countries</SelectItem>
                {SUPPORTED_COUNTRIES.map(cc => (
                  <SelectItem key={cc} value={cc}>{COUNTRY_DETAILS[cc].name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[160px]" data-testid="select-filter-status">
                <SelectValue placeholder="Filter status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="IN_REVIEW">In Review</SelectItem>
                <SelectItem value="APPROVED">Approved</SelectItem>
                <SelectItem value="REJECTED">Rejected</SelectItem>
                <SelectItem value="INFO_REQUESTED">Info Requested</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : filtered.length === 0 ? (
            <GlassCard>
              <div className="text-center py-6">
                <ShieldCheck className="w-10 h-10 mx-auto text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground">No KYC applications found</p>
              </div>
            </GlassCard>
          ) : (
            <div className="space-y-2">
              {filtered.map((profile) => (
                <GlassCard key={profile.id} className="hover-elevate cursor-pointer" data-testid={`kyc-row-${profile.id}`}>
                  <div
                    className="flex items-center justify-between gap-3 flex-wrap"
                    onClick={() => setSelectedProfileId(profile.id)}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-9 h-9 rounded-md bg-muted flex items-center justify-center flex-shrink-0">
                        <User className="w-4 h-4 text-muted-foreground" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate" data-testid={`kyc-name-${profile.id}`}>
                          {profile.user?.fullName || profile.legalName}
                        </p>
                        <p className="text-xs text-muted-foreground truncate">
                          {profile.user?.email} {profile.documentCount > 0 && `- ${profile.documentCount} doc(s)`}
                        </p>
                        {profile.countryCode && <Badge variant="outline" className="text-xs">{COUNTRY_DETAILS[profile.countryCode as keyof typeof COUNTRY_DETAILS]?.name || profile.countryCode}</Badge>}
                      </div>
                    </div>
                    <div className="flex items-center gap-3 flex-wrap">
                      <KycStatusBadge status={profile.status} />
                      <span className="text-xs text-muted-foreground">
                        {profile.submittedAt ? new Date(profile.submittedAt).toLocaleDateString() : "N/A"}
                      </span>
                      <Button size="icon" variant="ghost" data-testid={`button-view-kyc-${profile.id}`}>
                        <Eye className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </GlassCard>
              ))}
            </div>
          )}
        </Section>

        <Section title="Geo & Country Policy">
          <div className="space-y-4">
            <GlassCard>
              <div className="flex items-center gap-2 mb-3">
                <Ban className="w-4 h-4 text-destructive" />
                <h4 className="text-sm font-medium" data-testid="heading-sanctioned">Sanctioned Countries ({SANCTIONED_COUNTRIES.length})</h4>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {SANCTIONED_COUNTRIES.map(code => (
                  <Badge key={code} variant="destructive" data-testid={`badge-sanctioned-${code}`}>
                    {code}
                  </Badge>
                ))}
              </div>
              <p className="text-xs text-muted-foreground mt-2">Investors from these countries are automatically blocked from all platform activity.</p>
            </GlassCard>

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {SUPPORTED_COUNTRIES.map(code => {
                const details = COUNTRY_DETAILS[code];
                const investorPolicy = COUNTRY_INVESTOR_POLICIES[code];
                const compliancePolicy = getAllPolicies().find(p => p.countryCode === code);
                if (!investorPolicy || !compliancePolicy) return null;

                return (
                  <GlassCard key={code} data-testid={`card-country-policy-${code}`}>
                    <div className="flex items-center gap-2 mb-3">
                      <Globe className="w-4 h-4 text-primary flex-shrink-0" />
                      <h4 className="text-sm font-medium" data-testid={`text-country-name-${code}`}>{details.name}</h4>
                      <Badge variant="outline" className="ml-auto">{code}</Badge>
                    </div>

                    <div className="space-y-2 text-xs">
                      <div>
                        <span className="text-muted-foreground">Blocked Actions: </span>
                        {compliancePolicy.blockedActions.length > 0
                          ? compliancePolicy.blockedActions.map(a => (
                              <Badge key={a} variant="destructive" className="mr-1" data-testid={`badge-blocked-action-${code}-${a}`}>
                                {a.replace(/_/g, " ")}
                              </Badge>
                            ))
                          : <span className="text-muted-foreground">None</span>
                        }
                      </div>
                      <div>
                        <span className="text-muted-foreground">FX Conversion: </span>
                        <Badge variant={compliancePolicy.allowsFxConversion ? "secondary" : "destructive"} data-testid={`badge-fx-${code}`}>
                          {compliancePolicy.allowsFxConversion ? "Allowed" : "Restricted"}
                        </Badge>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Payment Rails: </span>
                        <span>{compliancePolicy.paymentRails.filter(r => r.status === "active").length} active / {compliancePolicy.paymentRails.length} total</span>
                      </div>
                      <div className="border-t pt-2 mt-2">
                        <p className="text-muted-foreground font-medium mb-1">Investor Types:</p>
                        <div className="space-y-1">
                          {(["retail", "sophisticated", "accredited", "institutional"] as const).map(type => {
                            const policy = investorPolicy.investorPolicies[type];
                            if (!policy) return null;
                            return (
                              <div key={type} className="flex items-center justify-between gap-2" data-testid={`row-investor-type-${code}-${type}`}>
                                <span className="capitalize">{type}</span>
                                <span className="text-muted-foreground">
                                  {policy.minInvestAmount.toLocaleString()} - {policy.maxInvestAmount ? policy.maxInvestAmount.toLocaleString() : "No limit"}
                                  {policy.canTrade && " | Trade"}
                                  {policy.cryptoAllowed && " | Crypto"}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                      {compliancePolicy.notes.length > 0 && (
                        <div className="border-t pt-2 mt-2">
                          <p className="text-muted-foreground font-medium mb-1">Regulatory Notes:</p>
                          {compliancePolicy.notes.map((note, i) => (
                            <p key={i} className="text-muted-foreground" data-testid={`text-note-${code}-${i}`}>{note}</p>
                          ))}
                        </div>
                      )}
                    </div>
                  </GlassCard>
                );
              })}
            </div>
          </div>
        </Section>
      </div>

      <KycDetailModal
        profileId={selectedProfileId}
        open={!!selectedProfileId}
        onClose={() => setSelectedProfileId(null)}
      />
    </RoleLayout>
  );
}
