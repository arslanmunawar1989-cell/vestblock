import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Shield, Search, Download, ChevronLeft, ChevronRight, Clock, User, Activity, FileText, Eye, ArrowLeft,
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Link } from "wouter";
interface AuditLog {
  id: string;
  actorId: string;
  actorRole: string | null;
  actorName: string;
  actorEmail: string;
  actionType: string;
  entityType: string;
  entityId: string | null;
  reason: string | null;
  beforeState: any;
  afterState: any;
  metadata: any;
  ipAddress: string | null;
  userAgent: string | null;
  createdAt: string;
}

interface AuditSearchResult {
  logs: AuditLog[];
  total: number;
  limit: number;
  offset: number;
}

interface AuditStats {
  totalLogs: number;
  todayLogs: number;
}

const ACTION_COLORS: Record<string, string> = {
  USER_LOGIN: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  USER_LOGIN_FAILED: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  USER_REGISTERED: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  KYC_SUBMITTED: "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200",
  KYC_APPROVED: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  KYC_REJECTED: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  AML_SCAN: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
  AML_FLAG_CREATED: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  AML_FLAG_RESOLVED: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
  CRYPTO_DEPOSIT_REVIEWED: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
  TOKEN_FROZEN: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
  TOKEN_UNFROZEN: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
};

function getActionColor(action: string): string {
  return ACTION_COLORS[action] || "bg-muted text-muted-foreground";
}

function formatDate(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleString();
}

function truncate(str: string, len: number): string {
  if (!str) return "";
  return str.length > len ? str.slice(0, len) + "..." : str;
}

export default function AdminAuditLogs() {
  const [search, setSearch] = useState("");
  const [actionType, setActionType] = useState("all");
  const [entityType, setEntityType] = useState("all");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [page, setPage] = useState(0);
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);
  const pageSize = 25;

  const buildQueryString = () => {
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    if (actionType && actionType !== "all") params.set("actionType", actionType);
    if (entityType && entityType !== "all") params.set("entityType", entityType);
    if (fromDate) params.set("from", fromDate);
    if (toDate) params.set("to", toDate);
    params.set("limit", String(pageSize));
    params.set("offset", String(page * pageSize));
    return params.toString();
  };

  const queryString = buildQueryString();

  const { data: logsData, isLoading } = useQuery<AuditSearchResult>({
    queryKey: [`/api/admin/audit-logs?${queryString}`],
  });

  const { data: stats } = useQuery<AuditStats>({
    queryKey: ["/api/admin/audit-logs/stats"],
  });

  const { data: actionTypes } = useQuery<string[]>({
    queryKey: ["/api/admin/audit-logs/action-types"],
  });

  const { data: entityTypes } = useQuery<string[]>({
    queryKey: ["/api/admin/audit-logs/entity-types"],
  });

  const totalPages = logsData ? Math.ceil(logsData.total / pageSize) : 0;

  const handleExport = () => {
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    if (actionType && actionType !== "all") params.set("actionType", actionType);
    if (entityType && entityType !== "all") params.set("entityType", entityType);
    if (fromDate) params.set("from", fromDate);
    if (toDate) params.set("to", toDate);
    window.open(`/api/admin/audit-logs/export?${params.toString()}`, "_blank");
  };

  const handleSearch = () => {
    setPage(0);
  };

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <Link href="/admin/dashboard">
              <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <PageTitle title="Audit Logs" description="Immutable record of all sensitive actions" />
          </div>
          <Button variant="outline" onClick={handleExport} data-testid="button-export-audit">
            <Download className="mr-2 h-4 w-4" />
            Export CSV
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Audit Entries</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-total-logs">{stats?.totalLogs ?? 0}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Today's Activity</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-today-logs">{stats?.todayLogs ?? 0}</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Search & Filter</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3">
              <div className="sm:col-span-2 lg:col-span-1 xl:col-span-1">
                <Input
                  placeholder="Search reason, action, entity..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  data-testid="input-audit-search"
                />
              </div>
              <Select value={actionType} onValueChange={(v) => { setActionType(v); setPage(0); }}>
                <SelectTrigger data-testid="select-action-type">
                  <SelectValue placeholder="Action Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Actions</SelectItem>
                  {actionTypes?.map((a) => (
                    <SelectItem key={a} value={a}>{a}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={entityType} onValueChange={(v) => { setEntityType(v); setPage(0); }}>
                <SelectTrigger data-testid="select-entity-type">
                  <SelectValue placeholder="Entity Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Entities</SelectItem>
                  {entityTypes?.map((e) => (
                    <SelectItem key={e} value={e}>{e}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                type="date"
                value={fromDate}
                onChange={(e) => { setFromDate(e.target.value); setPage(0); }}
                data-testid="input-date-from"
              />
              <Input
                type="date"
                value={toDate}
                onChange={(e) => { setToDate(e.target.value); setPage(0); }}
                data-testid="input-date-to"
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-8 text-center text-muted-foreground">Loading audit logs...</div>
            ) : !logsData?.logs.length ? (
              <div className="p-8 text-center text-muted-foreground">No audit logs found matching your filters.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/50">
                      <th className="text-left p-3 font-medium">Time</th>
                      <th className="text-left p-3 font-medium">Actor</th>
                      <th className="text-left p-3 font-medium">Action</th>
                      <th className="text-left p-3 font-medium">Entity</th>
                      <th className="text-left p-3 font-medium">Reason</th>
                      <th className="text-left p-3 font-medium">IP</th>
                      <th className="text-left p-3 font-medium">Details</th>
                    </tr>
                  </thead>
                  <tbody>
                    {logsData.logs.map((log) => (
                      <tr key={log.id} className="border-b hover-elevate" data-testid={`row-audit-${log.id}`}>
                        <td className="p-3 whitespace-nowrap">
                          <div className="flex items-center gap-1.5">
                            <Clock className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
                            <span className="text-xs">{formatDate(log.createdAt)}</span>
                          </div>
                        </td>
                        <td className="p-3">
                          <div className="flex items-center gap-1.5">
                            <User className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
                            <div>
                              <div className="font-medium text-xs">{log.actorName}</div>
                              {log.actorRole && (
                                <Badge variant="outline" className="text-[10px] mt-0.5">{log.actorRole}</Badge>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="p-3">
                          <Badge className={getActionColor(log.actionType)} variant="secondary">
                            {log.actionType}
                          </Badge>
                        </td>
                        <td className="p-3">
                          <div className="text-xs">
                            <span className="font-medium">{log.entityType}</span>
                            {log.entityId && (
                              <span className="text-muted-foreground ml-1">#{truncate(log.entityId, 8)}</span>
                            )}
                          </div>
                        </td>
                        <td className="p-3 max-w-[200px]">
                          <span className="text-xs text-muted-foreground">{truncate(log.reason || "-", 60)}</span>
                        </td>
                        <td className="p-3">
                          <span className="text-xs text-muted-foreground">{log.ipAddress || "-"}</span>
                        </td>
                        <td className="p-3">
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => setSelectedLog(log)}
                            data-testid={`button-view-${log.id}`}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {totalPages > 1 && (
          <div className="flex items-center justify-between gap-4">
            <span className="text-sm text-muted-foreground">
              Showing {page * pageSize + 1}-{Math.min((page + 1) * pageSize, logsData?.total || 0)} of {logsData?.total || 0}
            </span>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={page === 0}
                onClick={() => setPage(p => p - 1)}
                data-testid="button-prev-page"
              >
                <ChevronLeft className="h-4 w-4 mr-1" />
                Prev
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={page >= totalPages - 1}
                onClick={() => setPage(p => p + 1)}
                data-testid="button-next-page"
              >
                Next
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          </div>
        )}

        <Dialog open={!!selectedLog} onOpenChange={(open) => !open && setSelectedLog(null)}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Audit Log Detail</DialogTitle>
            </DialogHeader>
            {selectedLog && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-muted-foreground">Action</span>
                    <div className="font-medium mt-1">
                      <Badge className={getActionColor(selectedLog.actionType)} variant="secondary">
                        {selectedLog.actionType}
                      </Badge>
                    </div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Time</span>
                    <div className="font-medium mt-1">{formatDate(selectedLog.createdAt)}</div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Actor</span>
                    <div className="font-medium mt-1">{selectedLog.actorName} ({selectedLog.actorRole || "unknown"})</div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Entity</span>
                    <div className="font-medium mt-1">{selectedLog.entityType} {selectedLog.entityId ? `#${selectedLog.entityId}` : ""}</div>
                  </div>
                  <div className="col-span-2">
                    <span className="text-muted-foreground">IP Address</span>
                    <div className="font-medium mt-1">{selectedLog.ipAddress || "-"}</div>
                  </div>
                  {selectedLog.reason && (
                    <div className="col-span-2">
                      <span className="text-muted-foreground">Reason</span>
                      <div className="font-medium mt-1">{selectedLog.reason}</div>
                    </div>
                  )}
                </div>

                {selectedLog.beforeState && (
                  <div>
                    <span className="text-sm text-muted-foreground font-medium">Before State</span>
                    <pre className="mt-1 p-3 bg-muted rounded-md text-xs overflow-x-auto max-h-48" data-testid="pre-before-state">
                      {JSON.stringify(selectedLog.beforeState, null, 2)}
                    </pre>
                  </div>
                )}

                {selectedLog.afterState && (
                  <div>
                    <span className="text-sm text-muted-foreground font-medium">After State</span>
                    <pre className="mt-1 p-3 bg-muted rounded-md text-xs overflow-x-auto max-h-48" data-testid="pre-after-state">
                      {JSON.stringify(selectedLog.afterState, null, 2)}
                    </pre>
                  </div>
                )}

                {selectedLog.metadata && (
                  <div>
                    <span className="text-sm text-muted-foreground font-medium">Metadata</span>
                    <pre className="mt-1 p-3 bg-muted rounded-md text-xs overflow-x-auto max-h-48" data-testid="pre-metadata">
                      {JSON.stringify(selectedLog.metadata, null, 2)}
                    </pre>
                  </div>
                )}

                {selectedLog.userAgent && (
                  <div>
                    <span className="text-sm text-muted-foreground">User Agent</span>
                    <div className="text-xs mt-1 text-muted-foreground break-all">{selectedLog.userAgent}</div>
                  </div>
                )}
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </RoleLayout>
  );
}
