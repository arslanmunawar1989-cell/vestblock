import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { StatTile } from "@/components/stat-tile";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DEFAULT_CURRENCY } from "@/lib/currencies";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate, formatCurrency } from "@/lib/format";
import {
  Building2, Plus, Pencil, ArrowRight, Loader2,
  Search, Filter, Landmark, Shield, Briefcase,
  LinkIcon, Unlink, Home, TrendingUp, ArrowLeft,
} from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Link } from "wouter";
interface InvestmentVehicle {
  id: string;
  name: string;
  type: string;
  jurisdictionCountry: string;
  baseCurrency: string;
  bankAccountConfigId: string | null;
  status: string;
  platformFee: string | null;
  trusteeFee: string | null;
  propertyMgmtFee: string | null;
  legalFee: string | null;
  reservePercent: string | null;
  description: string | null;
  targetAum: string | null;
  currentNav: string | null;
  strategy: string | null;
  fundManager: string | null;
  inceptionDate: string | null;
  openEnded: boolean | null;
  regNumber: string | null;
  registeredAgent: string | null;
  incorporationDate: string | null;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  assets?: Asset[];
}

interface Asset {
  id: string;
  name: string;
  symbol: string;
  assetType: string;
  status: string;
  vehicleId: string | null;
}

const VEHICLE_TYPES = ["FUND", "SPV", "TRUST"] as const;
const VEHICLE_STATUSES = ["DRAFT", "REVIEW", "ACTIVE", "SUSPENDED", "CLOSED"] as const;

const STATUS_TRANSITIONS: Record<string, string[]> = {
  DRAFT: ["REVIEW"],
  REVIEW: ["ACTIVE", "DRAFT"],
  ACTIVE: ["SUSPENDED", "CLOSED"],
  SUSPENDED: ["ACTIVE", "CLOSED"],
  CLOSED: [],
};

function typeLabel(type: string): string {
  switch (type) {
    case "FUND": return "Fund";
    case "SPV": return "Property SPV";
    case "TRUST": return "Trust";
    default: return type;
  }
}

function statusBadgeVariant(status: string): "default" | "secondary" | "destructive" | "outline" {
  switch (status) {
    case "ACTIVE": return "default";
    case "REVIEW": return "secondary";
    case "DRAFT": return "outline";
    case "SUSPENDED":
    case "CLOSED": return "destructive";
    default: return "outline";
  }
}

function vehicleTypeIcon(type: string) {
  switch (type) {
    case "FUND": return <Briefcase className="h-4 w-4" />;
    case "SPV": return <Home className="h-4 w-4" />;
    case "TRUST": return <Shield className="h-4 w-4" />;
    default: return <Landmark className="h-4 w-4" />;
  }
}

const initialFormState = {
  name: "",
  type: "SPV" as string,
  jurisdictionCountry: "",
  baseCurrency: DEFAULT_CURRENCY,
  bankAccountConfigId: "",
  platformFee: "",
  trusteeFee: "",
  propertyMgmtFee: "",
  legalFee: "",
  reservePercent: "",
  description: "",
  targetAum: "",
  currentNav: "",
  strategy: "",
  fundManager: "",
  inceptionDate: "",
  openEnded: false,
  regNumber: "",
  registeredAgent: "",
  incorporationDate: "",
};

export default function AdminVehiclesPage() {
  const { toast } = useToast();
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<InvestmentVehicle | null>(null);
  const [selectedVehicle, setSelectedVehicle] = useState<InvestmentVehicle | null>(null);
  const [formData, setFormData] = useState(initialFormState);
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterType, setFilterType] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [attachAssetId, setAttachAssetId] = useState("");

  const { data: vehicles = [], isLoading } = useQuery<InvestmentVehicle[]>({
    queryKey: ["/api/admin/vehicles"],
  });

  const { data: allAssets = [] } = useQuery<Asset[]>({
    queryKey: ["/api/assets"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const res = await apiRequest("POST", "/api/admin/vehicles", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/vehicles"] });
      setShowCreateDialog(false);
      setFormData(initialFormState);
      toast({ title: "Created", description: `${typeLabel(formData.type)} created successfully.` });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: typeof formData }) => {
      const res = await apiRequest("PATCH", `/api/admin/vehicles/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/vehicles"] });
      setEditingVehicle(null);
      setFormData(initialFormState);
      toast({ title: "Updated", description: "Changes saved successfully." });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const statusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const res = await apiRequest("PATCH", `/api/admin/vehicles/${id}/status`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/vehicles"] });
      setSelectedVehicle(null);
      toast({ title: "Status Updated", description: "Status changed successfully." });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const attachMutation = useMutation({
    mutationFn: async ({ vehicleId, assetId }: { vehicleId: string; assetId: string }) => {
      const res = await apiRequest("POST", `/api/admin/vehicles/${vehicleId}/attach-asset`, { assetId });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/vehicles"] });
      queryClient.invalidateQueries({ queryKey: ["/api/assets"] });
      setAttachAssetId("");
      toast({ title: "Property Linked", description: "Property assigned to this structure." });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const detachMutation = useMutation({
    mutationFn: async ({ vehicleId, assetId }: { vehicleId: string; assetId: string }) => {
      const res = await apiRequest("POST", `/api/admin/vehicles/${vehicleId}/detach-asset`, { assetId });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/vehicles"] });
      queryClient.invalidateQueries({ queryKey: ["/api/assets"] });
      toast({ title: "Property Removed", description: "Property removed from this structure." });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const openEdit = (vehicle: InvestmentVehicle) => {
    setEditingVehicle(vehicle);
    setFormData({
      name: vehicle.name,
      type: vehicle.type,
      jurisdictionCountry: vehicle.jurisdictionCountry,
      baseCurrency: vehicle.baseCurrency as typeof initialFormState.baseCurrency,
      bankAccountConfigId: vehicle.bankAccountConfigId || "",
      platformFee: vehicle.platformFee || "",
      trusteeFee: vehicle.trusteeFee || "",
      propertyMgmtFee: vehicle.propertyMgmtFee || "",
      legalFee: vehicle.legalFee || "",
      reservePercent: vehicle.reservePercent || "",
      description: vehicle.description || "",
      targetAum: vehicle.targetAum || "",
      currentNav: vehicle.currentNav || "",
      strategy: vehicle.strategy || "",
      fundManager: vehicle.fundManager || "",
      inceptionDate: vehicle.inceptionDate || "",
      openEnded: vehicle.openEnded || false,
      regNumber: vehicle.regNumber || "",
      registeredAgent: vehicle.registeredAgent || "",
      incorporationDate: vehicle.incorporationDate || "",
    });
  };

  const openDetails = async (vehicle: InvestmentVehicle) => {
    try {
      const res = await apiRequest("GET", `/api/admin/vehicles/${vehicle.id}`);
      const detail = await res.json();
      setSelectedVehicle(detail);
    } catch {
      setSelectedVehicle(vehicle);
    }
  };

  const handleSubmit = () => {
    if (editingVehicle) {
      updateMutation.mutate({ id: editingVehicle.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const filtered = vehicles.filter((v) => {
    if (filterStatus !== "all" && v.status !== filterStatus) return false;
    if (filterType !== "all" && v.type !== filterType) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return v.name.toLowerCase().includes(q) || v.jurisdictionCountry.toLowerCase().includes(q);
    }
    return true;
  });

  const fundCount = vehicles.filter((v) => v.type === "FUND").length;
  const spvCount = vehicles.filter((v) => v.type === "SPV").length;
  const activeCount = vehicles.filter((v) => v.status === "ACTIVE").length;
  const draftCount = vehicles.filter((v) => v.status === "DRAFT").length;

  const unattachedAssets = allAssets.filter((a) => !a.vehicleId);
  const vehicleAssets = selectedVehicle?.assets || [];

  if (isLoading) {
    return (
      <RoleLayout role="admin">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </RoleLayout>
    );
  }

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Funds & SPVs"
          description="Manage Fund (REIT) and Property SPV structures for tokenized real estate"
        />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <StatTile
            label="Funds"
            value={String(fundCount)}
            icon={<Briefcase className="h-4 w-4" />}
          />
          <StatTile
            label="Property SPVs"
            value={String(spvCount)}
            icon={<Home className="h-4 w-4" />}
          />
          <StatTile
            label="Active"
            value={String(activeCount)}
            icon={<TrendingUp className="h-4 w-4" />}
          />
          <StatTile
            label="Drafts"
            value={String(draftCount)}
            icon={<Building2 className="h-4 w-4" />}
          />
        </div>

        <Section
          title="All Structures"
          action={
            <Button
              data-testid="button-create-vehicle"
              onClick={() => {
                setFormData(initialFormState);
                setShowCreateDialog(true);
              }}
            >
              <Plus className="h-4 w-4 mr-1" /> New Fund / SPV
            </Button>
          }
        >
          <div className="flex flex-wrap gap-3 mb-4">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                data-testid="input-search-vehicles"
                placeholder="Search funds and SPVs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-[160px]" data-testid="select-filter-status">
                <Filter className="h-4 w-4 mr-1" />
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                {VEHICLE_STATUSES.map((s) => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-[160px]" data-testid="select-filter-type">
                <Filter className="h-4 w-4 mr-1" />
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="FUND">Fund</SelectItem>
                <SelectItem value="SPV">Property SPV</SelectItem>
                <SelectItem value="TRUST">Trust</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {filtered.length === 0 ? (
            <GlassCard className="text-center py-12">
              <Landmark className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
              <p className="text-muted-foreground">No funds or SPVs found</p>
            </GlassCard>
          ) : (
            <div className="grid gap-3">
              {filtered.map((vehicle) => (
                <GlassCard key={vehicle.id} className="flex items-center justify-between gap-4 flex-wrap" padding="md">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="flex items-center justify-center w-9 h-9 rounded-md bg-primary/10 text-primary shrink-0">
                      {vehicleTypeIcon(vehicle.type)}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold truncate" data-testid={`text-vehicle-name-${vehicle.id}`}>{vehicle.name}</span>
                        <Badge variant={statusBadgeVariant(vehicle.status)} data-testid={`badge-vehicle-status-${vehicle.id}`}>
                          {vehicle.status}
                        </Badge>
                        <Badge variant="outline">{typeLabel(vehicle.type)}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {vehicle.jurisdictionCountry} &middot; {vehicle.baseCurrency}
                        {vehicle.type === "FUND" && vehicle.targetAum ? ` \u00B7 Target ${formatCurrency(vehicle.targetAum, vehicle.baseCurrency)}` : ""}
                        {vehicle.type === "SPV" && vehicle.regNumber ? ` \u00B7 Reg: ${vehicle.regNumber}` : ""}
                        {vehicle.platformFee ? ` \u00B7 Platform ${vehicle.platformFee}%` : ""}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      size="icon"
                      variant="ghost"
                      data-testid={`button-edit-vehicle-${vehicle.id}`}
                      onClick={() => openEdit(vehicle)}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      data-testid={`button-view-vehicle-${vehicle.id}`}
                      onClick={() => openDetails(vehicle)}
                    >
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                </GlassCard>
              ))}
            </div>
          )}
        </Section>
      </div>

      <Dialog open={showCreateDialog || !!editingVehicle} onOpenChange={(open) => {
        if (!open) {
          setShowCreateDialog(false);
          setEditingVehicle(null);
          setFormData(initialFormState);
        }
      }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingVehicle
                ? `Edit ${typeLabel(editingVehicle.type)}`
                : formData.type === "FUND"
                  ? "Create Fund (REIT)"
                  : formData.type === "SPV"
                    ? "Create Property SPV"
                    : "Create Trust"
              }
            </DialogTitle>
            <DialogDescription>
              {editingVehicle
                ? "Update the details below."
                : formData.type === "FUND"
                  ? "Set up a REIT-like pooled vehicle to hold multiple properties."
                  : formData.type === "SPV"
                    ? "Set up a single-property SPV wrapper."
                    : "Set up a new trust structure."
              }
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Structure Type</Label>
              <Select
                value={formData.type}
                onValueChange={(v) => setFormData({ ...formData, type: v })}
                disabled={!!editingVehicle}
              >
                <SelectTrigger data-testid="select-vehicle-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="FUND">Fund (REIT)</SelectItem>
                  <SelectItem value="SPV">Property SPV</SelectItem>
                  <SelectItem value="TRUST">Trust</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>{formData.type === "FUND" ? "Fund Name" : formData.type === "SPV" ? "SPV Name" : "Name"}</Label>
              <Input
                data-testid="input-vehicle-name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder={formData.type === "FUND" ? "e.g. VestBlock Alpha REIT" : formData.type === "SPV" ? "e.g. Marina Tower SPV" : "e.g. VestBlock Trust I"}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Jurisdiction</Label>
                <Select value={formData.jurisdictionCountry} onValueChange={(v) => setFormData({ ...formData, jurisdictionCountry: v })}>
                  <SelectTrigger data-testid="input-vehicle-jurisdiction">
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="AE">UAE</SelectItem>
                    <SelectItem value="PK">Pakistan</SelectItem>
                    <SelectItem value="GB">United Kingdom</SelectItem>
                    <SelectItem value="US">United States</SelectItem>
                    <SelectItem value="QA">Qatar</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Base Currency</Label>
                <Select value={formData.baseCurrency} onValueChange={(v: string) => setFormData({ ...formData, baseCurrency: v as typeof formData.baseCurrency })}>
                  <SelectTrigger data-testid="input-vehicle-currency">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="AED">AED</SelectItem>
                    <SelectItem value="PKR">PKR</SelectItem>
                    <SelectItem value="GBP">GBP</SelectItem>
                    <SelectItem value="USD">USD</SelectItem>
                    <SelectItem value="QAR">QAR</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label>Description</Label>
              <Textarea
                data-testid="input-vehicle-description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder={formData.type === "FUND" ? "Investment strategy and fund overview" : "Property and SPV details"}
              />
            </div>

            {formData.type === "FUND" && (
              <div className="border-t pt-3 space-y-3">
                <p className="text-sm font-medium">Fund Details</p>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Target AUM</Label>
                    <Input
                      data-testid="input-fund-target-aum"
                      type="number"
                      step="0.01"
                      value={formData.targetAum}
                      onChange={(e) => setFormData({ ...formData, targetAum: e.target.value })}
                      placeholder="e.g. 50000000"
                    />
                  </div>
                  <div>
                    <Label>Current NAV</Label>
                    <Input
                      data-testid="input-fund-nav"
                      type="number"
                      step="0.01"
                      value={formData.currentNav}
                      onChange={(e) => setFormData({ ...formData, currentNav: e.target.value })}
                      placeholder="e.g. 10000000"
                    />
                  </div>
                </div>
                <div>
                  <Label>Fund Manager</Label>
                  <Input
                    data-testid="input-fund-manager"
                    value={formData.fundManager}
                    onChange={(e) => setFormData({ ...formData, fundManager: e.target.value })}
                    placeholder="e.g. VestBlock Asset Management"
                  />
                </div>
                <div>
                  <Label>Investment Strategy</Label>
                  <Textarea
                    data-testid="input-fund-strategy"
                    value={formData.strategy}
                    onChange={(e) => setFormData({ ...formData, strategy: e.target.value })}
                    placeholder="e.g. Core+ real estate strategy focused on Grade A commercial properties"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Inception Date</Label>
                    <Input
                      data-testid="input-fund-inception"
                      type="date"
                      value={formData.inceptionDate}
                      onChange={(e) => setFormData({ ...formData, inceptionDate: e.target.value })}
                    />
                  </div>
                  <div className="flex items-end gap-3 pb-1">
                    <div className="flex items-center gap-2">
                      <Switch
                        id="open-ended"
                        checked={formData.openEnded}
                        onCheckedChange={(v) => setFormData({ ...formData, openEnded: v })}
                        data-testid="switch-fund-open-ended"
                      />
                      <Label htmlFor="open-ended" className="text-sm cursor-pointer">Open-ended Fund</Label>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {formData.type === "SPV" && (
              <div className="border-t pt-3 space-y-3">
                <p className="text-sm font-medium">SPV Registration</p>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Registration Number</Label>
                    <Input
                      data-testid="input-spv-reg-number"
                      value={formData.regNumber}
                      onChange={(e) => setFormData({ ...formData, regNumber: e.target.value })}
                      placeholder="e.g. SPV-2025-001"
                    />
                  </div>
                  <div>
                    <Label>Incorporation Date</Label>
                    <Input
                      data-testid="input-spv-incorporation"
                      type="date"
                      value={formData.incorporationDate}
                      onChange={(e) => setFormData({ ...formData, incorporationDate: e.target.value })}
                    />
                  </div>
                </div>
                <div>
                  <Label>Registered Agent</Label>
                  <Input
                    data-testid="input-spv-registered-agent"
                    value={formData.registeredAgent}
                    onChange={(e) => setFormData({ ...formData, registeredAgent: e.target.value })}
                    placeholder="e.g. VestBlock Corporate Services LLC"
                  />
                </div>
              </div>
            )}

            <div className="border-t pt-3">
              <p className="text-sm font-medium mb-2">Fee Configuration (%)</p>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Platform Fee</Label>
                  <Input
                    data-testid="input-vehicle-platform-fee"
                    type="number"
                    step="0.01"
                    value={formData.platformFee}
                    onChange={(e) => setFormData({ ...formData, platformFee: e.target.value })}
                    placeholder="e.g. 2.00"
                  />
                </div>
                <div>
                  <Label>Trustee Fee</Label>
                  <Input
                    data-testid="input-vehicle-trustee-fee"
                    type="number"
                    step="0.01"
                    value={formData.trusteeFee}
                    onChange={(e) => setFormData({ ...formData, trusteeFee: e.target.value })}
                    placeholder="e.g. 0.50"
                  />
                </div>
                <div>
                  <Label>Property Mgmt Fee</Label>
                  <Input
                    data-testid="input-vehicle-mgmt-fee"
                    type="number"
                    step="0.01"
                    value={formData.propertyMgmtFee}
                    onChange={(e) => setFormData({ ...formData, propertyMgmtFee: e.target.value })}
                    placeholder="e.g. 1.00"
                  />
                </div>
                <div>
                  <Label>Legal Fee</Label>
                  <Input
                    data-testid="input-vehicle-legal-fee"
                    type="number"
                    step="0.01"
                    value={formData.legalFee}
                    onChange={(e) => setFormData({ ...formData, legalFee: e.target.value })}
                    placeholder="e.g. 0.25"
                  />
                </div>
                <div>
                  <Label>Reserve %</Label>
                  <Input
                    data-testid="input-vehicle-reserve"
                    type="number"
                    step="0.01"
                    value={formData.reservePercent}
                    onChange={(e) => setFormData({ ...formData, reservePercent: e.target.value })}
                    placeholder="e.g. 5.00"
                  />
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => { setShowCreateDialog(false); setEditingVehicle(null); }}
            >
              Cancel
            </Button>
            <Button
              data-testid="button-submit-vehicle"
              onClick={handleSubmit}
              disabled={createMutation.isPending || updateMutation.isPending}
            >
              {(createMutation.isPending || updateMutation.isPending) && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
              {editingVehicle ? "Save Changes" : `Create ${typeLabel(formData.type)}`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!selectedVehicle} onOpenChange={(open) => { if (!open) setSelectedVehicle(null); }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          {selectedVehicle && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  {vehicleTypeIcon(selectedVehicle.type)}
                  {selectedVehicle.name}
                </DialogTitle>
                <DialogDescription>
                  {typeLabel(selectedVehicle.type)} &middot; {selectedVehicle.jurisdictionCountry} &middot; {selectedVehicle.baseCurrency}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge variant={statusBadgeVariant(selectedVehicle.status)} data-testid="badge-detail-status">
                    {selectedVehicle.status}
                  </Badge>
                  {(STATUS_TRANSITIONS[selectedVehicle.status] || []).map((nextStatus) => (
                    <Button
                      key={nextStatus}
                      size="sm"
                      variant="outline"
                      data-testid={`button-transition-${nextStatus.toLowerCase()}`}
                      onClick={() => statusMutation.mutate({ id: selectedVehicle.id, status: nextStatus })}
                      disabled={statusMutation.isPending}
                    >
                      {statusMutation.isPending && <Loader2 className="h-3 w-3 mr-1 animate-spin" />}
                      <ArrowRight className="h-3 w-3 mr-1" /> {nextStatus}
                    </Button>
                  ))}
                </div>

                {selectedVehicle.description && (
                  <p className="text-sm text-muted-foreground">{selectedVehicle.description}</p>
                )}

                {selectedVehicle.type === "FUND" && (
                  <div className="border rounded-md p-3 space-y-2 bg-muted/20">
                    <p className="text-sm font-medium">Fund Information</p>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      {selectedVehicle.targetAum && (
                        <div><span className="text-muted-foreground">Target AUM:</span> {formatCurrency(selectedVehicle.targetAum, selectedVehicle.baseCurrency)}</div>
                      )}
                      {selectedVehicle.currentNav && (
                        <div><span className="text-muted-foreground">Current NAV:</span> {formatCurrency(selectedVehicle.currentNav, selectedVehicle.baseCurrency)}</div>
                      )}
                      {selectedVehicle.fundManager && (
                        <div className="col-span-2"><span className="text-muted-foreground">Fund Manager:</span> {selectedVehicle.fundManager}</div>
                      )}
                      {selectedVehicle.inceptionDate && (
                        <div><span className="text-muted-foreground">Inception:</span> {formatDate(selectedVehicle.inceptionDate)}</div>
                      )}
                      <div><span className="text-muted-foreground">Structure:</span> {selectedVehicle.openEnded ? "Open-ended" : "Closed-end"}</div>
                    </div>
                    {selectedVehicle.strategy && (
                      <div className="text-sm">
                        <span className="text-muted-foreground">Strategy:</span>
                        <p className="mt-1 text-muted-foreground/80">{selectedVehicle.strategy}</p>
                      </div>
                    )}
                  </div>
                )}

                {selectedVehicle.type === "SPV" && (selectedVehicle.regNumber || selectedVehicle.registeredAgent || selectedVehicle.incorporationDate) && (
                  <div className="border rounded-md p-3 space-y-2 bg-muted/20">
                    <p className="text-sm font-medium">SPV Registration</p>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      {selectedVehicle.regNumber && (
                        <div><span className="text-muted-foreground">Reg Number:</span> {selectedVehicle.regNumber}</div>
                      )}
                      {selectedVehicle.incorporationDate && (
                        <div><span className="text-muted-foreground">Incorporated:</span> {formatDate(selectedVehicle.incorporationDate)}</div>
                      )}
                      {selectedVehicle.registeredAgent && (
                        <div className="col-span-2"><span className="text-muted-foreground">Registered Agent:</span> {selectedVehicle.registeredAgent}</div>
                      )}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-2 text-sm">
                  {selectedVehicle.platformFee && (
                    <div><span className="text-muted-foreground">Platform Fee:</span> {selectedVehicle.platformFee}%</div>
                  )}
                  {selectedVehicle.trusteeFee && (
                    <div><span className="text-muted-foreground">Trustee Fee:</span> {selectedVehicle.trusteeFee}%</div>
                  )}
                  {selectedVehicle.propertyMgmtFee && (
                    <div><span className="text-muted-foreground">Mgmt Fee:</span> {selectedVehicle.propertyMgmtFee}%</div>
                  )}
                  {selectedVehicle.legalFee && (
                    <div><span className="text-muted-foreground">Legal Fee:</span> {selectedVehicle.legalFee}%</div>
                  )}
                  {selectedVehicle.reservePercent && (
                    <div><span className="text-muted-foreground">Reserve:</span> {selectedVehicle.reservePercent}%</div>
                  )}
                </div>

                <div className="border-t pt-3">
                  <p className="text-sm font-medium mb-2">
                    {selectedVehicle.type === "FUND"
                      ? `Properties in Fund (${vehicleAssets.length})`
                      : selectedVehicle.type === "SPV"
                        ? `Property (${vehicleAssets.length}/1)`
                        : `Linked Properties (${vehicleAssets.length})`
                    }
                  </p>
                  {vehicleAssets.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No properties assigned yet</p>
                  ) : (
                    <div className="space-y-2">
                      {vehicleAssets.map((asset) => (
                        <div key={asset.id} className="flex items-center justify-between gap-2 p-2 rounded-md bg-muted/30">
                          <div className="flex items-center gap-2">
                            <Home className="h-4 w-4 text-muted-foreground shrink-0" />
                            <div>
                              <span className="text-sm font-medium">{asset.name}</span>
                              <span className="text-xs text-muted-foreground ml-2">{asset.symbol}</span>
                            </div>
                          </div>
                          <Button
                            size="icon"
                            variant="ghost"
                            data-testid={`button-detach-asset-${asset.id}`}
                            onClick={() => detachMutation.mutate({ vehicleId: selectedVehicle.id, assetId: asset.id })}
                            disabled={detachMutation.isPending}
                          >
                            <Unlink className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}

                  {(selectedVehicle.type !== "SPV" || vehicleAssets.length === 0) && unattachedAssets.length > 0 && (
                    <div className="flex items-center gap-2 mt-3">
                      <Select value={attachAssetId} onValueChange={setAttachAssetId}>
                        <SelectTrigger className="flex-1" data-testid="select-attach-asset">
                          <SelectValue placeholder="Select property to assign" />
                        </SelectTrigger>
                        <SelectContent>
                          {unattachedAssets.map((a) => (
                            <SelectItem key={a.id} value={a.id}>{a.name} ({a.symbol})</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Button
                        size="icon"
                        data-testid="button-attach-asset"
                        disabled={!attachAssetId || attachMutation.isPending}
                        onClick={() => {
                          if (attachAssetId) {
                            attachMutation.mutate({ vehicleId: selectedVehicle.id, assetId: attachAssetId });
                          }
                        }}
                      >
                        {attachMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <LinkIcon className="h-4 w-4" />}
                      </Button>
                    </div>
                  )}

                  {selectedVehicle.type === "SPV" && vehicleAssets.length >= 1 && unattachedAssets.length > 0 && (
                    <p className="text-xs text-muted-foreground mt-2">
                      SPV is limited to one property. Detach the current property to assign a different one.
                    </p>
                  )}
                </div>

                <div className="text-xs text-muted-foreground">
                  Created: {formatDate(selectedVehicle.createdAt)} &middot; Updated: {formatDate(selectedVehicle.updatedAt)}
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </RoleLayout>
  );
}
