import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DEFAULT_CURRENCY } from "@/lib/currencies";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatCurrency, formatDate } from "@/lib/format";
import {
  TrendingUp,
  DollarSign,
  Building2,
  Clock,
  Plus,
  FileText,
  ArrowRight, ArrowLeft,
} from "lucide-react";
import type { Asset, ValuationUpdate } from "@shared/schema";
import { Link } from "wouter";
const VALUATION_METHODS = [
  { value: "DCF", label: "Discounted Cash Flow (DCF)" },
  { value: "comparable_sales", label: "Comparable Sales" },
  { value: "income_approach", label: "Income Approach" },
  { value: "cost_approach", label: "Cost Approach" },
  { value: "appraisal", label: "Independent Appraisal" },
  { value: "market_value", label: "Market Value" },
  { value: "nav_calculation", label: "NAV Calculation" },
  { value: "other", label: "Other" },
];

export default function AdminValuations() {
  const [selectedAssetId, setSelectedAssetId] = useState<string>("");
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const { toast } = useToast();

  const { data: assets, isLoading: assetsLoading } = useQuery<Asset[]>({
    queryKey: ["/api/assets"],
  });

  const { data: valuations, isLoading: valuationsLoading } = useQuery<ValuationUpdate[]>({
    queryKey: ["/api/assets", selectedAssetId, "valuations"],
    queryFn: async () => {
      if (!selectedAssetId) return [];
      const res = await fetch(`/api/assets/${selectedAssetId}/valuations`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch valuations");
      return res.json();
    },
    enabled: !!selectedAssetId,
  });

  const selectedAsset = assets?.find(a => a.id === selectedAssetId);

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle title="Valuation Updates" description="Update asset valuations and implied token prices" />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <GlassCard>
            <div className="flex items-center gap-3 p-4">
              <Building2 className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Total Assets</p>
                <p className="text-2xl font-semibold" data-testid="text-total-assets">{assets?.length || 0}</p>
              </div>
            </div>
          </GlassCard>
          <GlassCard>
            <div className="flex items-center gap-3 p-4">
              <TrendingUp className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Selected Token Price</p>
                <p className="text-2xl font-semibold" data-testid="text-current-price">
                  {selectedAsset ? parseFloat(selectedAsset.pricePerToken).toFixed(2) : "—"}
                </p>
              </div>
            </div>
          </GlassCard>
          <GlassCard>
            <div className="flex items-center gap-3 p-4">
              <Clock className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Valuation History</p>
                <p className="text-2xl font-semibold" data-testid="text-valuation-count">{valuations?.length || 0}</p>
              </div>
            </div>
          </GlassCard>
        </div>

        <Section>
          <div className="flex items-center justify-between gap-3 flex-wrap mb-4">
            <Select value={selectedAssetId} onValueChange={setSelectedAssetId}>
              <SelectTrigger className="w-[300px]" data-testid="select-asset">
                <SelectValue placeholder="Select an asset" />
              </SelectTrigger>
              <SelectContent>
                {assets?.map(a => (
                  <SelectItem key={a.id} value={a.id}>{a.name} ({a.symbol})</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button
              onClick={() => setShowCreateDialog(true)}
              disabled={!selectedAssetId}
              data-testid="button-new-valuation"
            >
              <Plus className="w-4 h-4 mr-2" />
              New Valuation
            </Button>
          </div>

          {!selectedAssetId ? (
            <div className="text-center py-12">
              <Building2 className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground">Select an asset to view and manage valuations</p>
            </div>
          ) : valuationsLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => <Skeleton key={i} className="h-20 w-full" />)}
            </div>
          ) : (
            <>
              {selectedAsset && (
                <Card className="mb-4">
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <DollarSign className="w-4 h-4" /> Current Asset Summary
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Total Supply</p>
                        <p className="font-semibold" data-testid="text-total-supply">{parseFloat(selectedAsset.totalSupply).toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Price/Token</p>
                        <p className="font-semibold" data-testid="text-price-per-token">
                          {formatCurrency(selectedAsset.pricePerToken, selectedAsset.baseCurrency)}
                        </p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Property Value</p>
                        <p className="font-semibold" data-testid="text-property-value">
                          {selectedAsset.totalPropertyValue
                            ? formatCurrency(selectedAsset.totalPropertyValue, selectedAsset.baseCurrency)
                            : "—"}
                        </p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Base Currency</p>
                        <p className="font-semibold" data-testid="text-base-currency">{selectedAsset.baseCurrency}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {valuations && valuations.length === 0 ? (
                <div className="text-center py-8">
                  <FileText className="w-10 h-10 mx-auto text-muted-foreground mb-3" />
                  <p className="text-muted-foreground">No valuation history for this asset</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {valuations?.map((v, i) => (
                    <GlassCard key={v.id}>
                      <div className="flex flex-wrap items-center justify-between gap-3 p-4">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="font-medium text-sm" data-testid={`text-valuation-date-${i}`}>{formatDate(v.date)}</p>
                            <Badge variant="secondary" className="text-xs" data-testid={`badge-valuation-method-${i}`}>
                              {VALUATION_METHODS.find(m => m.value === v.method)?.label || v.method}
                            </Badge>
                            {i === 0 && <Badge variant="default" className="text-xs">Latest</Badge>}
                          </div>
                          <div className="flex items-center gap-4 mt-1 flex-wrap">
                            <span className="text-sm" data-testid={`text-valuation-amount-${i}`}>
                              Valuation: {formatCurrency(v.valuationAmount, v.currency)}
                            </span>
                            <span className="text-sm flex items-center gap-1">
                              <ArrowRight className="w-3 h-3 text-muted-foreground" />
                              Implied Price: <span className="font-semibold" data-testid={`text-implied-price-${i}`}>
                                {v.impliedTokenPrice ? formatCurrency(v.impliedTokenPrice, v.currency) : "—"}
                              </span>
                            </span>
                          </div>
                          {v.notes && (
                            <p className="text-xs text-muted-foreground mt-1" data-testid={`text-valuation-notes-${i}`}>{v.notes}</p>
                          )}
                        </div>
                      </div>
                    </GlassCard>
                  ))}
                </div>
              )}
            </>
          )}
        </Section>

        <CreateValuationDialog
          assetId={selectedAssetId}
          asset={selectedAsset || null}
          open={showCreateDialog}
          onOpenChange={setShowCreateDialog}
        />
      </div>
    </RoleLayout>
  );
}

function CreateValuationDialog({
  assetId,
  asset,
  open,
  onOpenChange,
}: {
  assetId: string;
  asset: Asset | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const { toast } = useToast();
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [valuationAmount, setValuationAmount] = useState("");
  const [method, setMethod] = useState("");
  const [notes, setNotes] = useState("");
  const [docs, setDocs] = useState("");

  const totalSupply = asset ? parseFloat(asset.totalSupply) : 0;
  const valuation = parseFloat(valuationAmount) || 0;
  const impliedPrice = totalSupply > 0 ? valuation / totalSupply : 0;
  const currentPrice = asset ? parseFloat(asset.pricePerToken) : 0;
  const priceChange = currentPrice > 0 ? ((impliedPrice - currentPrice) / currentPrice) * 100 : 0;

  const createMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/admin/valuations", {
        assetId,
        date,
        valuationAmount,
        currency: asset?.baseCurrency || DEFAULT_CURRENCY,
        method,
        notes: notes || undefined,
        docs: docs || undefined,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/assets", assetId, "valuations"] });
      queryClient.invalidateQueries({ queryKey: ["/api/assets"] });
      onOpenChange(false);
      setValuationAmount("");
      setMethod("");
      setNotes("");
      setDocs("");
      toast({
        title: "Valuation Updated",
        description: `Token price updated to ${impliedPrice.toFixed(2)} ${asset?.baseCurrency || ""}`,
      });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create valuation update", variant: "destructive" });
    },
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>New Valuation Update</DialogTitle>
          <DialogDescription>
            Update the valuation for {asset?.name || "this asset"}. The implied token price will be automatically calculated.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Valuation Date</Label>
            <Input
              type="date"
              value={date}
              onChange={e => setDate(e.target.value)}
              data-testid="input-valuation-date"
            />
          </div>

          <div className="space-y-2">
            <Label>Valuation Amount ({asset?.baseCurrency || DEFAULT_CURRENCY})</Label>
            <Input
              type="number"
              step="0.01"
              placeholder="e.g. 15000000"
              value={valuationAmount}
              onChange={e => setValuationAmount(e.target.value)}
              data-testid="input-valuation-amount"
            />
          </div>

          <div className="space-y-2">
            <Label>Valuation Method</Label>
            <Select value={method} onValueChange={setMethod}>
              <SelectTrigger data-testid="select-valuation-method">
                <SelectValue placeholder="Select method" />
              </SelectTrigger>
              <SelectContent>
                {VALUATION_METHODS.map(m => (
                  <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {valuation > 0 && totalSupply > 0 && (
            <Card>
              <CardContent className="p-4">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-muted-foreground">Current Price</p>
                    <p className="font-semibold" data-testid="text-preview-current">{formatCurrency(currentPrice, asset?.baseCurrency || DEFAULT_CURRENCY)}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">New Implied Price</p>
                    <p className="font-semibold" data-testid="text-preview-implied">{formatCurrency(impliedPrice, asset?.baseCurrency || DEFAULT_CURRENCY)}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Total Supply</p>
                    <p className="font-semibold">{totalSupply.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Price Change</p>
                    <p className={`font-semibold ${priceChange >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-red-600 dark:text-red-400"}`} data-testid="text-preview-change">
                      {priceChange >= 0 ? "+" : ""}{priceChange.toFixed(2)}%
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="space-y-2">
            <Label>Notes (optional)</Label>
            <Textarea
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="Reason for valuation update"
              data-testid="input-valuation-notes"
            />
          </div>

          <div className="space-y-2">
            <Label>Document Reference (optional)</Label>
            <Input
              value={docs}
              onChange={e => setDocs(e.target.value)}
              placeholder="Link or reference to supporting documents"
              data-testid="input-valuation-docs"
            />
          </div>

          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => onOpenChange(false)} data-testid="button-cancel-valuation">
              Cancel
            </Button>
            <Button
              onClick={() => createMutation.mutate()}
              disabled={!date || !valuationAmount || !method || createMutation.isPending}
              data-testid="button-submit-valuation"
            >
              {createMutation.isPending ? "Saving..." : "Update Valuation"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
