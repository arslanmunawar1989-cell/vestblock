import { useQuery } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { GradientHeader } from "@/components/gradient-header";
import { StatTile } from "@/components/stat-tile";
import { Section } from "@/components/section";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Building2, Users, FolderKanban, TrendingUp, ShieldCheck,
  ArrowDownLeft, Activity, UserCheck,
} from "lucide-react";
import {
  ResponsiveContainer, LineChart, Line, BarChart, Bar,
  XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell, Legend,
} from "recharts";

const COLORS = ["#10b981", "#3b82f6", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4", "#ec4899"];

interface PlatformAnalytics {
  kpis: {
    totalTenants: number;
    activeTenants: number;
    totalUsers: number;
    totalProjects: number;
    activeInvestors: number;
    totalDeposits: number;
    depositVolume: number;
    kycProfiles: number;
  };
  charts: {
    projectsByStatus: { name: string; value: number }[];
    projectsByType: { name: string; value: number }[];
    projectsByTenant: { name: string; projects: number }[];
    usersByRole: { name: string; value: number }[];
    userGrowth: { date: string; value: number }[];
    projectGrowth: { date: string; value: number }[];
    activityTrend: { date: string; value: number }[];
    tenantGrowth: { date: string; value: number }[];
  };
}

function formatDate(d: string) {
  const date = new Date(d);
  return `${date.getMonth() + 1}/${date.getDate()}`;
}

function ChartSkeleton() {
  return <Skeleton className="h-[260px] w-full" />;
}

export default function AdminDashboard() {
  const { data, isLoading } = useQuery<PlatformAnalytics>({
    queryKey: ["/api/analytics/platform"],
  });

  const kpis = data?.kpis;
  const charts = data?.charts;

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <GradientHeader>
          <div>
            <p className="text-white/80 text-sm mb-1">Admin Control Center</p>
            <h1 className="text-2xl font-bold text-white">Platform Analytics</h1>
          </div>
        </GradientHeader>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[...Array(8)].map((_, i) => <Skeleton key={i} className="h-28" />)}
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <StatTile label="Total Agencies" value={String(kpis?.totalTenants || 0)} icon={<Building2 className="w-5 h-5" />} data-testid="stat-total-tenants" />
              <StatTile label="Active Agencies" value={String(kpis?.activeTenants || 0)} icon={<Building2 className="w-5 h-5" />} data-testid="stat-active-tenants" />
              <StatTile label="Total Users" value={String(kpis?.totalUsers || 0)} icon={<Users className="w-5 h-5" />} data-testid="stat-total-users" />
              <StatTile label="Total Projects" value={String(kpis?.totalProjects || 0)} icon={<FolderKanban className="w-5 h-5" />} data-testid="stat-total-projects" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <StatTile label="Active Investors" value={String(kpis?.activeInvestors || 0)} icon={<UserCheck className="w-5 h-5" />} data-testid="stat-active-investors" />
              <StatTile label="Confirmed Deposits" value={String(kpis?.totalDeposits || 0)} icon={<ArrowDownLeft className="w-5 h-5" />} data-testid="stat-total-deposits" />
              <StatTile label="Deposit Volume" value={`$${(kpis?.depositVolume || 0).toLocaleString()}`} icon={<TrendingUp className="w-5 h-5" />} data-testid="stat-deposit-volume" />
              <StatTile label="KYC Profiles" value={String(kpis?.kycProfiles || 0)} icon={<ShieldCheck className="w-5 h-5" />} data-testid="stat-kyc-profiles" />
            </div>
          </>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Users className="w-4 h-4" /> User Growth (30 days)
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? <ChartSkeleton /> : (
                <ResponsiveContainer width="100%" height={260}>
                  <LineChart data={charts?.userGrowth}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="date" tickFormatter={formatDate} className="text-xs" tick={{ fontSize: 11 }} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                    <Tooltip labelFormatter={v => `Date: ${v}`} contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                    <Line type="monotone" dataKey="value" name="New Users" stroke="#10b981" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Activity className="w-4 h-4" /> Activity Trend (30 days)
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? <ChartSkeleton /> : (
                <ResponsiveContainer width="100%" height={260}>
                  <LineChart data={charts?.activityTrend}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="date" tickFormatter={formatDate} tick={{ fontSize: 11 }} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                    <Tooltip labelFormatter={v => `Date: ${v}`} contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                    <Line type="monotone" dataKey="value" name="Activities" stroke="#3b82f6" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <FolderKanban className="w-4 h-4" /> Project Growth (30 days)
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? <ChartSkeleton /> : (
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={charts?.projectGrowth}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="date" tickFormatter={formatDate} tick={{ fontSize: 11 }} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                    <Tooltip labelFormatter={v => `Date: ${v}`} contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                    <Bar dataKey="value" name="New Projects" fill="#10b981" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Building2 className="w-4 h-4" /> Agency Growth (30 days)
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? <ChartSkeleton /> : (
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={charts?.tenantGrowth}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="date" tickFormatter={formatDate} tick={{ fontSize: 11 }} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                    <Tooltip labelFormatter={v => `Date: ${v}`} contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                    <Bar dataKey="value" name="New Agencies" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Projects by Status</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? <ChartSkeleton /> : (charts?.projectsByStatus?.length || 0) > 0 ? (
                <ResponsiveContainer width="100%" height={260}>
                  <PieChart>
                    <Pie data={charts?.projectsByStatus} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false}>
                      {charts?.projectsByStatus.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie>
                    <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                  </PieChart>
                </ResponsiveContainer>
              ) : <EmptyChart />}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Users by Role</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? <ChartSkeleton /> : (charts?.usersByRole?.length || 0) > 0 ? (
                <ResponsiveContainer width="100%" height={260}>
                  <PieChart>
                    <Pie data={charts?.usersByRole} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false}>
                      {charts?.usersByRole.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie>
                    <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                  </PieChart>
                </ResponsiveContainer>
              ) : <EmptyChart />}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Projects by Type</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? <ChartSkeleton /> : (charts?.projectsByType?.length || 0) > 0 ? (
                <ResponsiveContainer width="100%" height={260}>
                  <PieChart>
                    <Pie data={charts?.projectsByType} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false}>
                      {charts?.projectsByType.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie>
                    <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                  </PieChart>
                </ResponsiveContainer>
              ) : <EmptyChart />}
            </CardContent>
          </Card>
        </div>

        {(charts?.projectsByTenant?.length || 0) > 0 && (
          <Section title="Projects per Agency">
            <Card>
              <CardContent className="pt-4">
                <ResponsiveContainer width="100%" height={Math.max(200, (charts?.projectsByTenant?.length || 0) * 40)}>
                  <BarChart data={charts?.projectsByTenant} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11 }} />
                    <YAxis type="category" dataKey="name" width={120} tick={{ fontSize: 11 }} />
                    <Tooltip contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                    <Bar dataKey="projects" name="Projects" fill="#10b981" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </Section>
        )}
      </div>
    </RoleLayout>
  );
}

function EmptyChart() {
  return (
    <div className="h-[260px] flex items-center justify-center text-sm text-muted-foreground" data-testid="text-no-chart-data">
      No data available
    </div>
  );
}
