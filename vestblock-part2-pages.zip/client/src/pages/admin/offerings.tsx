import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { StatTile } from "@/components/stat-tile";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate, formatCurrency } from "@/lib/format";
import { DEFAULT_CURRENCY } from "@/lib/currencies";
import {
  TrendingUp, Plus, ArrowRight, Loader2,
  Search, Filter, FileText, CircleDot,
  Ban, CheckCircle2, Clock, DollarSign,
  Building2, MapPin, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface Property {
  id: string;
  name: string;
  symbol: string;
  location?: string;
  country: string;
  baseCurrency: string;
  vehicleId?: string;
  propertyType?: string;
  imageUrl?: string;
}

interface InvestmentVehicle {
  id: string;
  name: string;
  type: string;
  baseCurrency: string;
  status: string;
}

interface Commitment {
  id: string;
  userId: string;
  offeringId: string;
  amount: string;
  currency: string;
  convertedAmount: string | null;
  baseCurrency: string | null;
  fxRate: string | null;
  status: string;
  coolingOffEndsAt: string | null;
  createdAt: string;
}

interface Offering {
  id: string;
  vehicleId: string;
  name: string;
  targetAmount: string;
  minInvest: string;
  maxInvest: string | null;
  startDate: string;
  endDate: string;
  status: string;
  totalCommitted: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  vehicle?: InvestmentVehicle;
  property?: Property | null;
  commitments?: Commitment[];
}

const OFFERING_STATUSES = ["DRAFT", "OPEN", "CLOSED", "CANCELLED"] as const;

const STATUS_TRANSITIONS: Record<string, string[]> = {
  DRAFT: ["OPEN"],
  OPEN: ["CLOSED", "CANCELLED"],
  CLOSED: [],
  CANCELLED: [],
};

function statusBadgeVariant(status: string): "default" | "secondary" | "destructive" | "outline" {
  switch (status) {
    case "OPEN": return "default";
    case "DRAFT": return "outline";
    case "CLOSED": return "secondary";
    case "CANCELLED": return "destructive";
    default: return "outline";
  }
}

function commitmentBadgeVariant(status: string): "default" | "secondary" | "destructive" | "outline" {
  switch (status) {
    case "CONFIRMED": return "default";
    case "SETTLED": return "secondary";
    case "CANCELLED": return "destructive";
    case "PENDING": return "outline";
    default: return "outline";
  }
}

const initialFormState = {
  name: "",
  vehicleId: "",
  propertyId: "",
  targetAmount: "",
  minInvest: "",
  maxInvest: "",
  startDate: "",
  endDate: "",
};

export default function AdminOfferingsPage() {
  const { toast } = useToast();
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedOffering, setSelectedOffering] = useState<Offering | null>(null);
  const [formData, setFormData] = useState(initialFormState);
  const [filterStatus, setFilterStatus] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const { data: offerings = [], isLoading } = useQuery<Offering[]>({
    queryKey: ["/api/admin/offerings"],
  });

  const { data: vehicles = [] } = useQuery<InvestmentVehicle[]>({
    queryKey: ["/api/admin/vehicles"],
  });

  const { data: properties = [] } = useQuery<Property[]>({
    queryKey: ["/api/assets"],
  });

  const activeVehicles = vehicles.filter((v) => v.status === "ACTIVE");

  const propertiesWithVehicle = properties.filter((p) => p.vehicleId);

  const createMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      let vehicleId = data.vehicleId;

      if (data.propertyId && !vehicleId) {
        const prop = properties.find(p => p.id === data.propertyId);
        if (prop?.vehicleId) {
          vehicleId = prop.vehicleId;
        }
      }

      if (!vehicleId) {
        throw new Error("Please select a property with a linked SPV or select a Fund/SPV directly.");
      }

      const payload: Record<string, unknown> = {
        vehicleId,
        name: data.name,
        targetAmount: data.targetAmount,
        minInvest: data.minInvest,
        startDate: data.startDate,
        endDate: data.endDate,
      };
      if (data.maxInvest) {
        payload.maxInvest = data.maxInvest;
      }
      const res = await apiRequest("POST", "/api/admin/offerings", payload);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/offerings"] });
      setShowCreateDialog(false);
      setFormData(initialFormState);
      toast({ title: "Offering Created", description: "Property offering created successfully." });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const statusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const res = await apiRequest("PATCH", `/api/admin/offerings/${id}/status`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/offerings"] });
      setSelectedOffering(null);
      toast({ title: "Status Updated", description: "Offering status changed." });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const commitmentStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const res = await apiRequest("PATCH", `/api/admin/commitments/${id}/status`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/offerings"] });
      if (selectedOffering) {
        openDetails(selectedOffering);
      }
      toast({ title: "Commitment Updated", description: "Commitment status changed." });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const openDetails = async (offering: Offering) => {
    try {
      const res = await apiRequest("GET", `/api/admin/offerings/${offering.id}`);
      const detail = await res.json();
      setSelectedOffering(detail);
    } catch {
      setSelectedOffering(offering);
    }
  };

  const handleSelectProperty = (propertyId: string) => {
    const prop = properties.find(p => p.id === propertyId);
    if (prop) {
      setFormData(prev => ({
        ...prev,
        propertyId,
        vehicleId: prop.vehicleId || "",
        name: prev.name || `${prop.name} — Property Offering`,
      }));
    }
  };

  const handleSubmit = () => {
    createMutation.mutate(formData);
  };

  const filtered = offerings.filter((o) => {
    if (filterStatus !== "all" && o.status !== filterStatus) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const propName = o.property?.name?.toLowerCase() || "";
      return o.name.toLowerCase().includes(q) || propName.includes(q);
    }
    return true;
  });

  const openCount = offerings.filter((o) => o.status === "OPEN").length;
  const draftCount = offerings.filter((o) => o.status === "DRAFT").length;
  const closedCount = offerings.filter((o) => o.status === "CLOSED").length;

  const getProgressPercent = (offering: Offering) => {
    const committed = parseFloat(offering.totalCommitted || "0");
    const target = parseFloat(offering.targetAmount || "1");
    if (target <= 0) return 0;
    return Math.min(100, (committed / target) * 100);
  };

  if (isLoading) {
    return (
      <RoleLayout role="admin">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </RoleLayout>
    );
  }

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Property Offerings"
          description="Create per-property investment offerings and track investor commitments"
        />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <StatTile
            label="Total Offerings"
            value={String(offerings.length)}
            icon={<FileText className="h-4 w-4" />}
          />
          <StatTile
            label="Open"
            value={String(openCount)}
            icon={<CircleDot className="h-4 w-4" />}
          />
          <StatTile
            label="Draft"
            value={String(draftCount)}
            icon={<Clock className="h-4 w-4" />}
          />
          <StatTile
            label="Closed"
            value={String(closedCount)}
            icon={<CheckCircle2 className="h-4 w-4" />}
          />
        </div>

        <Section
          title="Offerings"
          action={
            <Button
              data-testid="button-create-offering"
              onClick={() => {
                setFormData(initialFormState);
                setShowCreateDialog(true);
              }}
            >
              <Plus className="h-4 w-4 mr-1" /> Create Property Offering
            </Button>
          }
        >
          <div className="flex flex-wrap gap-3 mb-4">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                data-testid="input-search-offerings"
                placeholder="Search by offering or property name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-[160px]" data-testid="select-filter-status">
                <Filter className="h-4 w-4 mr-1" />
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                {OFFERING_STATUSES.map((s) => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {filtered.length === 0 ? (
            <GlassCard className="text-center py-12">
              <FileText className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
              <p className="text-muted-foreground">No offerings found</p>
            </GlassCard>
          ) : (
            <div className="grid gap-3">
              {filtered.map((offering) => {
                const currency = offering.vehicle?.baseCurrency || DEFAULT_CURRENCY;
                return (
                  <GlassCard key={offering.id} className="flex items-center justify-between gap-4 flex-wrap" padding="md">
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <div className="flex items-center justify-center w-9 h-9 rounded-md bg-primary/10 text-primary shrink-0">
                        {offering.property ? <Building2 className="h-4 w-4" /> : <TrendingUp className="h-4 w-4" />}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-semibold truncate" data-testid={`text-offering-name-${offering.id}`}>{offering.name}</span>
                          <Badge variant={statusBadgeVariant(offering.status)} data-testid={`badge-offering-status-${offering.id}`}>
                            {offering.status}
                          </Badge>
                        </div>
                        {offering.property && (
                          <div className="flex items-center gap-2 mt-0.5 text-sm text-muted-foreground flex-wrap">
                            <Building2 className="h-3 w-3" />
                            <span>{offering.property.name}</span>
                            {offering.property.location && (
                              <>
                                <MapPin className="h-3 w-3" />
                                <span>{offering.property.location}</span>
                              </>
                            )}
                            <Badge variant="outline" className="no-default-hover-elevate text-[10px]">{offering.property.symbol}</Badge>
                          </div>
                        )}
                        <p className="text-sm text-muted-foreground">
                          Target: {formatCurrency(offering.targetAmount, currency)} &middot; Min: {formatCurrency(offering.minInvest, currency)}
                          {offering.maxInvest ? ` \u00B7 Max: ${formatCurrency(offering.maxInvest, currency)}` : ""}
                        </p>
                        <div className="mt-1.5">
                          <Progress value={getProgressPercent(offering)} className="h-1.5" />
                          <p className="text-xs text-muted-foreground mt-0.5">
                            {formatCurrency(offering.totalCommitted || "0", currency)} / {formatCurrency(offering.targetAmount, currency)} committed
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        size="icon"
                        variant="ghost"
                        data-testid={`button-view-offering-${offering.id}`}
                        onClick={() => openDetails(offering)}
                      >
                        <ArrowRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </GlassCard>
                );
              })}
            </div>
          )}
        </Section>
      </div>

      <Dialog open={showCreateDialog} onOpenChange={(open) => {
        if (!open) {
          setShowCreateDialog(false);
          setFormData(initialFormState);
        }
      }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create Property Offering</DialogTitle>
            <DialogDescription>
              Select a property and set investment parameters. Each offering raises capital for one specific property.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Property</Label>
              <Select value={formData.propertyId} onValueChange={handleSelectProperty}>
                <SelectTrigger data-testid="select-offering-property">
                  <SelectValue placeholder="Select a property" />
                </SelectTrigger>
                <SelectContent>
                  {propertiesWithVehicle.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.name} ({p.symbol}) — {p.location || p.country}
                    </SelectItem>
                  ))}
                  {propertiesWithVehicle.length === 0 && (
                    <SelectItem value="_none" disabled>No properties with linked SPV found</SelectItem>
                  )}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground mt-1">Properties must have a linked SPV/Fund vehicle.</p>
            </div>

            {!formData.propertyId && (
              <div>
                <Label>Or select Fund / SPV directly</Label>
                <Select value={formData.vehicleId} onValueChange={(v) => setFormData({ ...formData, vehicleId: v })}>
                  <SelectTrigger data-testid="select-offering-vehicle">
                    <SelectValue placeholder="Select a Fund or SPV" />
                  </SelectTrigger>
                  <SelectContent>
                    {activeVehicles.map((v) => (
                      <SelectItem key={v.id} value={v.id}>{v.name} ({v.type === "FUND" ? "Fund" : v.type === "SPV" ? "SPV" : v.type})</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div>
              <Label>Offering Name</Label>
              <Input
                data-testid="input-offering-name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g. DHA Lahore — Investment Round 1"
              />
            </div>
            <div>
              <Label>Target Amount</Label>
              <Input
                data-testid="input-target-amount"
                type="number"
                step="0.01"
                value={formData.targetAmount}
                onChange={(e) => setFormData({ ...formData, targetAmount: e.target.value })}
                placeholder="e.g. 1000000"
              />
              <p className="text-xs text-muted-foreground mt-1">Total capital to raise for this property.</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Min Investment</Label>
                <Input
                  data-testid="input-min-invest"
                  type="number"
                  step="0.01"
                  value={formData.minInvest}
                  onChange={(e) => setFormData({ ...formData, minInvest: e.target.value })}
                  placeholder="e.g. 5000"
                />
              </div>
              <div>
                <Label>Max Investment (optional)</Label>
                <Input
                  data-testid="input-max-invest"
                  type="number"
                  step="0.01"
                  value={formData.maxInvest}
                  onChange={(e) => setFormData({ ...formData, maxInvest: e.target.value })}
                  placeholder="e.g. 100000"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Start Date</Label>
                <Input
                  data-testid="input-start-date"
                  type="date"
                  value={formData.startDate}
                  onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                />
              </div>
              <div>
                <Label>End Date</Label>
                <Input
                  data-testid="input-end-date"
                  type="date"
                  value={formData.endDate}
                  onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => { setShowCreateDialog(false); setFormData(initialFormState); }}
            >
              Cancel
            </Button>
            <Button
              data-testid="button-submit-offering"
              onClick={handleSubmit}
              disabled={createMutation.isPending}
            >
              {createMutation.isPending && <Loader2 className="h-4 w-4 mr-1 animate-spin" />}
              Create Offering
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!selectedOffering} onOpenChange={(open) => { if (!open) setSelectedOffering(null); }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          {selectedOffering && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  {selectedOffering.property ? <Building2 className="h-5 w-5" /> : <TrendingUp className="h-5 w-5" />}
                  {selectedOffering.name}
                </DialogTitle>
                <DialogDescription>
                  {selectedOffering.property ? (
                    <span className="flex items-center gap-1.5 flex-wrap">
                      <Building2 className="h-3 w-3" />
                      {selectedOffering.property.name}
                      {selectedOffering.property.location && (
                        <>
                          <MapPin className="h-3 w-3" />
                          {selectedOffering.property.location}
                        </>
                      )}
                      &middot; {selectedOffering.property.baseCurrency}
                    </span>
                  ) : (
                    <span>{selectedOffering.vehicle?.name || "Fund/SPV"} &middot; {formatDate(selectedOffering.startDate, "short")} - {formatDate(selectedOffering.endDate, "short")}</span>
                  )}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge variant={statusBadgeVariant(selectedOffering.status)} data-testid="badge-detail-status">
                    {selectedOffering.status}
                  </Badge>
                  {(STATUS_TRANSITIONS[selectedOffering.status] || []).map((nextStatus) => (
                    <Button
                      key={nextStatus}
                      size="sm"
                      variant="outline"
                      data-testid={`button-transition-${nextStatus.toLowerCase()}`}
                      onClick={() => statusMutation.mutate({ id: selectedOffering.id, status: nextStatus })}
                      disabled={statusMutation.isPending}
                    >
                      {statusMutation.isPending && <Loader2 className="h-3 w-3 mr-1 animate-spin" />}
                      <ArrowRight className="h-3 w-3 mr-1" /> {nextStatus}
                    </Button>
                  ))}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2 text-sm">
                    <span className="text-muted-foreground">Progress</span>
                    <span className="font-medium">{getProgressPercent(selectedOffering).toFixed(1)}%</span>
                  </div>
                  <Progress value={getProgressPercent(selectedOffering)} className="h-2" />
                  <div className="flex items-center justify-between gap-2 text-sm">
                    <span className="text-muted-foreground">Committed</span>
                    <span>{formatCurrency(selectedOffering.totalCommitted || "0", selectedOffering.vehicle?.baseCurrency || DEFAULT_CURRENCY)}</span>
                  </div>
                  <div className="flex items-center justify-between gap-2 text-sm">
                    <span className="text-muted-foreground">Target</span>
                    <span>{formatCurrency(selectedOffering.targetAmount, selectedOffering.vehicle?.baseCurrency || DEFAULT_CURRENCY)}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div><span className="text-muted-foreground">Min Investment:</span> {formatCurrency(selectedOffering.minInvest, selectedOffering.vehicle?.baseCurrency || DEFAULT_CURRENCY)}</div>
                  {selectedOffering.maxInvest && (
                    <div><span className="text-muted-foreground">Max Investment:</span> {formatCurrency(selectedOffering.maxInvest, selectedOffering.vehicle?.baseCurrency || DEFAULT_CURRENCY)}</div>
                  )}
                  <div><span className="text-muted-foreground">Start:</span> {formatDate(selectedOffering.startDate)}</div>
                  <div><span className="text-muted-foreground">End:</span> {formatDate(selectedOffering.endDate)}</div>
                  <div><span className="text-muted-foreground">Created:</span> {formatDate(selectedOffering.createdAt)}</div>
                </div>

                {selectedOffering.commitments && selectedOffering.commitments.length > 0 && (
                  <div className="border-t pt-3">
                    <p className="text-sm font-medium mb-2 flex items-center gap-1">
                      <DollarSign className="h-4 w-4" />
                      Commitments ({selectedOffering.commitments.length})
                    </p>
                    <div className="space-y-2 max-h-60 overflow-y-auto">
                      {selectedOffering.commitments.map((commitment) => (
                        <GlassCard key={commitment.id} padding="sm" className="space-y-2">
                          <div className="flex items-center justify-between gap-2 flex-wrap">
                            <div className="text-sm">
                              <span className="font-medium">{formatCurrency(commitment.amount, commitment.currency)}</span>
                              {commitment.convertedAmount && commitment.baseCurrency !== commitment.currency && (
                                <span className="text-muted-foreground ml-1">
                                  ({formatCurrency(commitment.convertedAmount, commitment.baseCurrency || DEFAULT_CURRENCY)})
                                </span>
                              )}
                              {commitment.fxRate && commitment.baseCurrency !== commitment.currency && (
                                <span className="text-xs text-muted-foreground ml-1">FX: {commitment.fxRate}</span>
                              )}
                            </div>
                            <Badge variant={commitmentBadgeVariant(commitment.status)}>
                              {commitment.status}
                            </Badge>
                          </div>
                          <div className="flex items-center justify-between gap-2 text-xs text-muted-foreground flex-wrap">
                            <span>User: {commitment.userId.slice(0, 8)}...</span>
                            <span>{formatDate(commitment.createdAt, "short")}</span>
                          </div>
                          {commitment.status === "PENDING" && (
                            <div className="flex items-center gap-2 flex-wrap">
                              <Button
                                size="sm"
                                variant="outline"
                                data-testid={`button-commitment-confirmed-${commitment.id}`}
                                onClick={() => commitmentStatusMutation.mutate({ id: commitment.id, status: "CONFIRMED" })}
                                disabled={commitmentStatusMutation.isPending}
                              >
                                <CheckCircle2 className="h-3 w-3 mr-1" /> Confirm
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                data-testid={`button-commitment-cancelled-${commitment.id}`}
                                onClick={() => commitmentStatusMutation.mutate({ id: commitment.id, status: "CANCELLED" })}
                                disabled={commitmentStatusMutation.isPending}
                              >
                                <Ban className="h-3 w-3 mr-1" /> Cancel
                              </Button>
                            </div>
                          )}
                          {commitment.status === "CONFIRMED" && (
                            <div className="flex items-center gap-2 flex-wrap">
                              <Button
                                size="sm"
                                variant="outline"
                                data-testid={`button-commitment-settled-${commitment.id}`}
                                onClick={() => commitmentStatusMutation.mutate({ id: commitment.id, status: "SETTLED" })}
                                disabled={commitmentStatusMutation.isPending}
                              >
                                <CheckCircle2 className="h-3 w-3 mr-1" /> Settle
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                data-testid={`button-commitment-cancelled-${commitment.id}`}
                                onClick={() => commitmentStatusMutation.mutate({ id: commitment.id, status: "CANCELLED" })}
                                disabled={commitmentStatusMutation.isPending}
                              >
                                <Ban className="h-3 w-3 mr-1" /> Cancel
                              </Button>
                            </div>
                          )}
                        </GlassCard>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </RoleLayout>
  );
}
