import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { StatTile } from "@/components/stat-tile";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatCurrency, formatDate } from "@/lib/format";
import {
  Landmark,
  ArrowRight,
  FileCheck,
  Shield,
  Clock,
  CheckCircle2,
  XCircle,
  Eye,
  Banknote,
  FileText,
  ChevronRight, ArrowLeft,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
const STATE_LABELS: Record<string, string> = {
  CLIENT_MONEY_HELD: "Client Money Held",
  SETTLEMENT_INITIATED: "Settlement Initiated",
  ACQUISITION_PAID: "Acquisition Paid",
  SETTLED: "Settled",
  FAILED: "Failed",
};

const STATE_COLORS: Record<string, string> = {
  CLIENT_MONEY_HELD: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  SETTLEMENT_INITIATED: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
  ACQUISITION_PAID: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
  SETTLED: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  FAILED: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
};

const STATE_ICONS: Record<string, typeof Landmark> = {
  CLIENT_MONEY_HELD: Banknote,
  SETTLEMENT_INITIATED: Clock,
  ACQUISITION_PAID: FileCheck,
  SETTLED: CheckCircle2,
  FAILED: XCircle,
};

interface SettlementEntry {
  id: string;
  assetId: string;
  roundId: string | null;
  userId: string;
  walletTransactionId: string | null;
  paymentIntentId: string | null;
  referenceId: string;
  state: string;
  amount: string;
  currency: string;
  previousState: string | null;
  notes: string | null;
  proofDocumentUrl: string | null;
  advancedBy: string | null;
  advancedAt: string | null;
  metadata: any;
  createdAt: string;
  assetName?: string;
  assetSymbol?: string;
  investorName?: string;
  documentCount?: number;
  documents?: any[];
  auditTrail?: SettlementEntry[];
}

interface SettlementStats {
  totalEntries: number;
  uniqueSettlements: number;
  byState: Record<string, number>;
  totalAmount: string;
}

function StateBadge({ state }: { state: string }) {
  const colorClass = STATE_COLORS[state] || "bg-muted text-muted-foreground";
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-medium ${colorClass}`} data-testid={`badge-state-${state}`}>
      {STATE_LABELS[state] || state}
    </span>
  );
}

export default function AdminSettlement() {
  const { toast } = useToast();
  const [stateFilter, setStateFilter] = useState<string>("all");
  const [assetFilter, setAssetFilter] = useState<string>("all");
  const [detailEntry, setDetailEntry] = useState<SettlementEntry | null>(null);
  const [showAdvanceDialog, setShowAdvanceDialog] = useState(false);
  const [advanceTarget, setAdvanceTarget] = useState<SettlementEntry | null>(null);
  const [advanceState, setAdvanceState] = useState("");
  const [advanceNotes, setAdvanceNotes] = useState("");
  const [advanceProofUrl, setAdvanceProofUrl] = useState("");

  const { data: stats, isLoading: statsLoading } = useQuery<SettlementStats>({
    queryKey: ["/api/finance/settlement-stats"],
  });

  const { data: settlements = [], isLoading: settlementsLoading } = useQuery<SettlementEntry[]>({
    queryKey: ["/api/finance/settlements", stateFilter, assetFilter],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (stateFilter !== "all") params.set("state", stateFilter);
      if (assetFilter !== "all") params.set("assetId", assetFilter);
      const res = await fetch(`/api/finance/settlements?${params.toString()}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch settlements");
      return res.json();
    },
  });

  const { data: detailData, isLoading: detailLoading } = useQuery<SettlementEntry>({
    queryKey: ["/api/finance/settlements", detailEntry?.id],
    queryFn: async () => {
      const res = await fetch(`/api/finance/settlements/${detailEntry!.id}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch settlement detail");
      return res.json();
    },
    enabled: !!detailEntry,
  });

  const { data: assets = [] } = useQuery<any[]>({
    queryKey: ["/api/assets"],
  });

  const advanceMutation = useMutation({
    mutationFn: async ({ id, state, notes, proofDocumentUrl }: { id: string; state: string; notes?: string; proofDocumentUrl?: string }) => {
      const res = await apiRequest("POST", `/api/finance/settlements/${id}/advance`, {
        state,
        notes,
        proofDocumentUrl,
      });
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Settlement advanced", description: "Settlement state updated successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/finance/settlements"] });
      queryClient.invalidateQueries({ queryKey: ["/api/finance/settlement-stats"] });
      setShowAdvanceDialog(false);
      setAdvanceTarget(null);
      setAdvanceState("");
      setAdvanceNotes("");
      setAdvanceProofUrl("");
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to advance settlement", variant: "destructive" });
    },
  });

  const latestByRef = new Map<string, SettlementEntry>();
  for (const entry of settlements) {
    const existing = latestByRef.get(entry.referenceId);
    if (!existing || entry.createdAt > existing.createdAt) {
      latestByRef.set(entry.referenceId, entry);
    }
  }
  const displayEntries = Array.from(latestByRef.values());

  const getNextStates = (current: string): string[] => {
    const transitions: Record<string, string[]> = {
      CLIENT_MONEY_HELD: ["SETTLEMENT_INITIATED", "FAILED"],
      SETTLEMENT_INITIATED: ["ACQUISITION_PAID", "FAILED"],
      ACQUISITION_PAID: ["SETTLED", "FAILED"],
    };
    return transitions[current] || [];
  };

  const openAdvanceDialog = (entry: SettlementEntry) => {
    setAdvanceTarget(entry);
    const next = getNextStates(entry.state);
    setAdvanceState(next[0] || "");
    setAdvanceNotes("");
    setAdvanceProofUrl("");
    setShowAdvanceDialog(true);
  };

  return (
    <RoleLayout role="admin">
      <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Settlement Journal"
          description="Client money segregation and acquisition settlement tracking"
        />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {statsLoading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-20 rounded-md" />
            ))
          ) : (
            <>
              <StatTile
                label="Total Settlements"
                value={String(stats?.uniqueSettlements || 0)}
                icon={<Landmark className="h-4 w-4" />}
              />
              <StatTile
                label="Client Money Held"
                value={String(stats?.byState?.CLIENT_MONEY_HELD || 0)}
                icon={<Banknote className="h-4 w-4" />}
              />
              <StatTile
                label="Settlement Initiated"
                value={String(stats?.byState?.SETTLEMENT_INITIATED || 0)}
                icon={<Clock className="h-4 w-4" />}
              />
              <StatTile
                label="Acquisition Paid"
                value={String(stats?.byState?.ACQUISITION_PAID || 0)}
                icon={<FileCheck className="h-4 w-4" />}
              />
              <StatTile
                label="Settled"
                value={String(stats?.byState?.SETTLED || 0)}
                icon={<CheckCircle2 className="h-4 w-4" />}
              />
            </>
          )}
        </div>

        <Section title="Settlement Entries">
          <div className="flex flex-wrap items-center gap-3 mb-4">
            <Select value={stateFilter} onValueChange={setStateFilter}>
              <SelectTrigger className="w-48" data-testid="select-state-filter">
                <SelectValue placeholder="Filter by state" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All States</SelectItem>
                <SelectItem value="CLIENT_MONEY_HELD">Client Money Held</SelectItem>
                <SelectItem value="SETTLEMENT_INITIATED">Settlement Initiated</SelectItem>
                <SelectItem value="ACQUISITION_PAID">Acquisition Paid</SelectItem>
                <SelectItem value="SETTLED">Settled</SelectItem>
                <SelectItem value="FAILED">Failed</SelectItem>
              </SelectContent>
            </Select>

            <Select value={assetFilter} onValueChange={setAssetFilter}>
              <SelectTrigger className="w-56" data-testid="select-asset-filter">
                <SelectValue placeholder="Filter by asset" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Assets</SelectItem>
                {assets.map((a: any) => (
                  <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {settlementsLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-24 rounded-md" />
              ))}
            </div>
          ) : displayEntries.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Landmark className="mx-auto h-10 w-10 text-muted-foreground mb-3" />
                <p className="text-muted-foreground">No settlement entries found</p>
                <p className="text-sm text-muted-foreground mt-1">Settlement entries are created automatically when investments are made</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {displayEntries.map((entry) => {
                const Icon = STATE_ICONS[entry.state] || Shield;
                const nextStates = getNextStates(entry.state);
                return (
                  <Card key={entry.id} data-testid={`settlement-entry-${entry.id}`}>
                    <CardContent className="p-4">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div className="flex items-start gap-3 min-w-0">
                          <div className="mt-0.5">
                            <Icon className="h-5 w-5 text-muted-foreground" />
                          </div>
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="font-medium text-sm" data-testid="text-asset-name">{entry.assetName}</span>
                              <StateBadge state={entry.state} />
                              {entry.previousState && (
                                <span className="text-xs text-muted-foreground flex items-center gap-1">
                                  <ArrowRight className="h-3 w-3" />
                                  from {STATE_LABELS[entry.previousState] || entry.previousState}
                                </span>
                              )}
                            </div>
                            <div className="flex flex-wrap items-center gap-3 mt-1 text-xs text-muted-foreground">
                              <span>Ref: {entry.referenceId}</span>
                              <span>Investor: {entry.investorName}</span>
                              <span>{formatCurrency(parseFloat(entry.amount), entry.currency)}</span>
                              <span>{formatDate(entry.createdAt)}</span>
                              {(entry.documentCount ?? 0) > 0 && (
                                <span className="flex items-center gap-1">
                                  <FileText className="h-3 w-3" />
                                  {entry.documentCount} docs
                                </span>
                              )}
                            </div>
                            {entry.notes && (
                              <p className="text-xs text-muted-foreground mt-1 truncate max-w-md">{entry.notes}</p>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setDetailEntry(entry)}
                            data-testid={`button-view-detail-${entry.id}`}
                          >
                            <Eye className="h-3 w-3 mr-1" />
                            Trail
                          </Button>
                          {nextStates.length > 0 && (
                            <Button
                              size="sm"
                              onClick={() => openAdvanceDialog(entry)}
                              data-testid={`button-advance-${entry.id}`}
                            >
                              <ChevronRight className="h-3 w-3 mr-1" />
                              Advance
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </Section>

        <Dialog open={showAdvanceDialog} onOpenChange={setShowAdvanceDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Advance Settlement</DialogTitle>
              <DialogDescription>
                Move settlement {advanceTarget?.referenceId} to the next state
              </DialogDescription>
            </DialogHeader>
            {advanceTarget && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-sm">
                  <StateBadge state={advanceTarget.state} />
                  <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  {advanceState && <StateBadge state={advanceState} />}
                </div>

                <div>
                  <label className="text-sm font-medium mb-1 block">New State</label>
                  <Select value={advanceState} onValueChange={setAdvanceState}>
                    <SelectTrigger data-testid="select-advance-state">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {getNextStates(advanceTarget.state).map((s) => (
                        <SelectItem key={s} value={s}>{STATE_LABELS[s]}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {advanceState === "ACQUISITION_PAID" && (
                  <div>
                    <label className="text-sm font-medium mb-1 block">Proof Document URL *</label>
                    <Input
                      value={advanceProofUrl}
                      onChange={(e) => setAdvanceProofUrl(e.target.value)}
                      placeholder="https://storage.example.com/proof-doc.pdf"
                      data-testid="input-proof-url"
                    />
                    <p className="text-xs text-muted-foreground mt-1">Required when marking acquisition as paid</p>
                  </div>
                )}

                <div>
                  <label className="text-sm font-medium mb-1 block">Notes</label>
                  <Textarea
                    value={advanceNotes}
                    onChange={(e) => setAdvanceNotes(e.target.value)}
                    placeholder="Settlement notes..."
                    rows={3}
                    data-testid="input-advance-notes"
                  />
                </div>

                <div className="flex items-center gap-3 pt-2">
                  <span className="text-sm text-muted-foreground flex-1">
                    {advanceTarget.assetName} — {formatCurrency(parseFloat(advanceTarget.amount), advanceTarget.currency)}
                  </span>
                  <Button
                    variant="outline"
                    onClick={() => setShowAdvanceDialog(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={() => {
                      if (!advanceTarget || !advanceState) return;
                      advanceMutation.mutate({
                        id: advanceTarget.id,
                        state: advanceState,
                        notes: advanceNotes || undefined,
                        proofDocumentUrl: advanceProofUrl || undefined,
                      });
                    }}
                    disabled={advanceMutation.isPending || (advanceState === "ACQUISITION_PAID" && !advanceProofUrl)}
                    data-testid="button-confirm-advance"
                  >
                    {advanceMutation.isPending ? "Advancing..." : "Confirm"}
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        <Dialog open={!!detailEntry} onOpenChange={(open) => { if (!open) setDetailEntry(null); }}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Settlement Audit Trail</DialogTitle>
              <DialogDescription>
                Full traceability for {detailData?.referenceId || detailEntry?.referenceId}
              </DialogDescription>
            </DialogHeader>
            {detailLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-16 rounded-md" />
                ))}
              </div>
            ) : detailData ? (
              <div className="space-y-4">
                <Card>
                  <CardContent className="p-4 space-y-2">
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <span className="text-muted-foreground">Asset:</span>{" "}
                        <span className="font-medium" data-testid="text-detail-asset">{detailData.assetName}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Investor:</span>{" "}
                        <span className="font-medium" data-testid="text-detail-investor">{detailData.investorName}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Amount:</span>{" "}
                        <span className="font-medium">{formatCurrency(parseFloat(detailData.amount), detailData.currency)}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Reference:</span>{" "}
                        <span className="font-mono text-xs">{detailData.referenceId}</span>
                      </div>
                      {detailData.walletTransactionId && (
                        <div>
                          <span className="text-muted-foreground">Wallet Tx:</span>{" "}
                          <span className="font-mono text-xs">{detailData.walletTransactionId}</span>
                        </div>
                      )}
                      <div>
                        <span className="text-muted-foreground">Current State:</span>{" "}
                        <StateBadge state={detailData.state} />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {detailData.auditTrail && detailData.auditTrail.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium mb-2">State Timeline</h4>
                    <div className="relative pl-6 space-y-3">
                      <div className="absolute left-2 top-2 bottom-2 w-px bg-border" />
                      {detailData.auditTrail
                        .sort((a, b) => a.createdAt.localeCompare(b.createdAt))
                        .map((step, i) => {
                          const StepIcon = STATE_ICONS[step.state] || Shield;
                          return (
                            <div key={step.id} className="relative" data-testid={`trail-step-${i}`}>
                              <div className="absolute -left-4 top-1 w-3 h-3 rounded-full bg-border flex items-center justify-center">
                                <div className="w-1.5 h-1.5 rounded-full bg-foreground" />
                              </div>
                              <div className="flex flex-wrap items-center gap-2 text-sm">
                                <StepIcon className="h-3.5 w-3.5 text-muted-foreground" />
                                <StateBadge state={step.state} />
                                <span className="text-xs text-muted-foreground">{formatDate(step.createdAt)}</span>
                              </div>
                              {step.notes && (
                                <p className="text-xs text-muted-foreground mt-0.5 ml-5">{step.notes}</p>
                              )}
                              {step.proofDocumentUrl && (
                                <a
                                  href={step.proofDocumentUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-xs text-primary ml-5 flex items-center gap-1 mt-0.5"
                                >
                                  <FileText className="h-3 w-3" /> View Proof
                                </a>
                              )}
                            </div>
                          );
                        })}
                    </div>
                  </div>
                )}

                {detailData.documents && detailData.documents.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium mb-2">Documents</h4>
                    <div className="space-y-2">
                      {detailData.documents.map((doc: any) => (
                        <Card key={doc.id}>
                          <CardContent className="p-3 flex items-center gap-3">
                            <FileText className="h-4 w-4 text-muted-foreground" />
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium">{doc.fileName || doc.documentType}</p>
                              {doc.description && <p className="text-xs text-muted-foreground">{doc.description}</p>}
                            </div>
                            <span className="text-xs text-muted-foreground">{formatDate(doc.createdAt)}</span>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : null}
          </DialogContent>
        </Dialog>
      </div>
    </RoleLayout>
  );
}