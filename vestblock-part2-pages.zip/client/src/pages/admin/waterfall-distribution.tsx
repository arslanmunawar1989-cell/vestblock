import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  ArrowDown,
  Minus,
  Equal,
  ArrowRight,
  Users,
  Calculator,
  Save,
  Eye,
  ChevronDown,
  ChevronUp,
  Wallet,
  CheckCircle2,
  Loader2, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
function fmt(amount: string | number, currency: string): string {
  const num = typeof amount === "string" ? parseFloat(amount) : amount;
  if (isNaN(num)) return `${currency} 0.00`;
  return `${currency} ${num.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

interface PropertySummary {
  assetId: string;
  assetName: string;
  location: string | null;
  propertyType: string | null;
  baseCurrency: string;
  totalPeriods: number;
  totalGrossRent: string;
  totalExpenses: string;
  netOperatingIncome: string;
  latestPeriod: string | null;
}

interface WaterfallStep {
  label: string;
  amount: string;
  runningTotal: string;
  tier: string;
  percentOfGross?: string;
}

interface UnitDistribution {
  totalUnits: string;
  incomePerUnit: string;
  currency: string;
}

interface InvestorPayout {
  userId: string;
  username?: string;
  units: string;
  incomePerUnit: string;
  totalPayout: string;
}

interface WaterfallPreview {
  preview: boolean;
  assetId: string;
  assetName: string;
  period: string;
  baseCurrency: string;
  grossRent: string;
  vacancyImpact: string;
  effectiveRent: string;
  maintenanceExpense: string;
  managementFeeExpense: string;
  insuranceExpense: string;
  propertyTaxExpense: string;
  utilityExpense: string;
  platformFeePercent: string;
  platformFeeAmount: string;
  otherExpense: string;
  totalExpenses: string;
  netOperatingIncome: string;
  reservePercent: string;
  reserveAmount: string;
  distributableIncome: string;
  unitDistribution: UnitDistribution | null;
  breakdown: WaterfallStep[];
  investorPayouts: InvestorPayout[];
  rentCollectionCount: number;
  expenseCount: number;
}

const TIER_COLORS: Record<string, string> = {
  income: "text-emerald-600 dark:text-emerald-400",
  vacancy: "text-amber-600 dark:text-amber-400",
  effective: "text-blue-600 dark:text-blue-400",
  expense: "text-red-500 dark:text-red-400",
  noi: "text-emerald-700 dark:text-emerald-300",
  reserve: "text-orange-600 dark:text-orange-400",
  distributable: "text-emerald-700 dark:text-emerald-300",
  per_unit: "text-violet-600 dark:text-violet-400",
};

const TIER_BG: Record<string, string> = {
  income: "bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800",
  effective: "bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800",
  noi: "bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-700",
  distributable: "bg-emerald-100 dark:bg-emerald-950/50 border-emerald-400 dark:border-emerald-600",
  per_unit: "bg-violet-50 dark:bg-violet-950/30 border-violet-200 dark:border-violet-800",
};

function WaterfallStepRow({ step, currency }: { step: WaterfallStep; currency: string }) {
  const isHighlight = ["income", "effective", "noi", "distributable", "per_unit"].includes(step.tier);
  const bgClass = TIER_BG[step.tier] || "";
  const textColor = TIER_COLORS[step.tier] || "text-foreground";
  const isDeduction = step.amount.startsWith("-");

  return (
    <div
      className={`flex items-center justify-between gap-2 px-4 py-3 rounded-md border ${isHighlight ? bgClass : "border-transparent"}`}
      data-testid={`waterfall-step-${step.tier}`}
    >
      <div className="flex items-center gap-3 flex-1 min-w-0">
        {isDeduction ? (
          <Minus className="w-4 h-4 shrink-0 text-muted-foreground" />
        ) : isHighlight ? (
          <Equal className="w-4 h-4 shrink-0 text-muted-foreground" />
        ) : (
          <ArrowDown className="w-4 h-4 shrink-0 text-muted-foreground invisible" />
        )}
        <span className={`text-sm ${isHighlight ? "font-semibold" : ""}`}>
          {step.label}
        </span>
      </div>
      <div className="flex items-center gap-4 shrink-0">
        {step.percentOfGross && (
          <span className="text-xs text-muted-foreground w-16 text-right">
            {step.percentOfGross}%
          </span>
        )}
        <span className={`text-sm font-mono w-32 text-right ${textColor} ${isHighlight ? "font-bold text-base" : ""}`}>
          {step.tier === "per_unit" ? step.amount : fmt(step.amount.replace("-", ""), currency)}
        </span>
      </div>
    </div>
  );
}

function WaterfallCascade({ data }: { data: WaterfallPreview }) {
  const [showPayouts, setShowPayouts] = useState(true);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div>
          <h3 className="text-lg font-semibold" data-testid="text-waterfall-property">{data.assetName}</h3>
          <p className="text-sm text-muted-foreground">Period: {data.period} | Currency: {data.baseCurrency}</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" data-testid="badge-rent-count">
            {data.rentCollectionCount} rent record{data.rentCollectionCount !== 1 ? "s" : ""}
          </Badge>
          <Badge variant="outline" data-testid="badge-expense-count">
            {data.expenseCount} expense{data.expenseCount !== 1 ? "s" : ""}
          </Badge>
        </div>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-2 pb-3">
          <CardTitle className="text-base">Waterfall Breakdown</CardTitle>
          <Badge variant="secondary" data-testid="badge-distributable">
            Distributable: {fmt(data.distributableIncome, data.baseCurrency)}
          </Badge>
        </CardHeader>
        <CardContent className="space-y-1 p-3" data-testid="waterfall-breakdown">
          {data.breakdown.map((step, i) => (
            <WaterfallStepRow key={i} step={step} currency={data.baseCurrency} />
          ))}
        </CardContent>
      </Card>

      {data.unitDistribution && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Calculator className="w-4 h-4" />
              Per-Unit Distribution
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3" data-testid="unit-distribution">
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">Distributable Income</p>
                <p className="text-sm font-semibold" data-testid="text-distributable">{fmt(data.distributableIncome, data.baseCurrency)}</p>
              </div>
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">Total Units</p>
                <p className="text-sm font-semibold" data-testid="text-total-units">{parseFloat(data.unitDistribution.totalUnits).toLocaleString()}</p>
              </div>
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">Income Per Unit</p>
                <p className="text-sm font-semibold text-violet-600 dark:text-violet-400" data-testid="text-income-per-unit">
                  {fmt(data.unitDistribution.incomePerUnit, data.baseCurrency)}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted/50 p-3 rounded-md">
              <ArrowRight className="w-4 h-4 shrink-0" />
              <span>
                {fmt(data.distributableIncome, data.baseCurrency)} / {parseFloat(data.unitDistribution.totalUnits).toLocaleString()} units = {fmt(data.unitDistribution.incomePerUnit, data.baseCurrency)} per unit
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      {data.investorPayouts.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <button
              className="flex items-center justify-between gap-2 w-full text-left"
              onClick={() => setShowPayouts(!showPayouts)}
              data-testid="button-toggle-payouts"
            >
              <CardTitle className="text-base flex items-center gap-2">
                <Users className="w-4 h-4" />
                Investor Payouts ({data.investorPayouts.length})
              </CardTitle>
              {showPayouts ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
          </CardHeader>
          {showPayouts && (
            <CardContent data-testid="investor-payouts">
              <div className="border rounded-md overflow-hidden">
                <div className="grid grid-cols-4 gap-2 px-4 py-2 bg-muted/50 text-xs font-medium text-muted-foreground">
                  <span>Investor</span>
                  <span className="text-right">Units Held</span>
                  <span className="text-right">Per Unit</span>
                  <span className="text-right">Payout</span>
                </div>
                {data.investorPayouts.map((p) => (
                  <div
                    key={p.userId}
                    className="grid grid-cols-4 gap-2 px-4 py-2 border-t text-sm"
                    data-testid={`payout-row-${p.userId}`}
                  >
                    <span className="truncate">{p.username}</span>
                    <span className="text-right font-mono">{parseFloat(p.units).toLocaleString()}</span>
                    <span className="text-right font-mono">{fmt(p.incomePerUnit, data.baseCurrency)}</span>
                    <span className="text-right font-mono font-semibold text-emerald-600 dark:text-emerald-400">
                      {fmt(p.totalPayout, data.baseCurrency)}
                    </span>
                  </div>
                ))}
              </div>
              <div className="flex items-center gap-2 mt-3 text-sm text-muted-foreground bg-muted/50 p-3 rounded-md">
                <ArrowRight className="w-4 h-4 shrink-0" />
                <span>
                  Investor payout = Units held x {fmt(data.unitDistribution?.incomePerUnit || "0", data.baseCurrency)} per unit
                </span>
              </div>
            </CardContent>
          )}
        </Card>
      )}

      {!data.unitDistribution && (
        <Card>
          <CardContent className="py-6 text-center text-sm text-muted-foreground" data-testid="no-units-message">
            <p>No property units configured for this asset.</p>
            <p>Set up units in Property Acquisition to see per-unit and investor payout calculations.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

interface DistributionResult {
  distribution: {
    id: string;
    assetId: string;
    amount: string;
    currency: string;
    distributionDate: string;
    status: string;
    perTokenAmount: string;
    recipientCount: number;
  };
  snapshot: {
    id: string;
    recordDate: string;
    totalSupply: string;
    holderCount: number;
  };
  summary: {
    snapshotDate: string;
    recordDate: string;
    totalDistributed: string;
    currency: string;
    recipientCount: number;
    perTokenAmount: string;
    totalTokenSupply: string;
    autoConvertedCount: number;
    payoutDetails: Array<{
      userId: string;
      username: string;
      fullName: string;
      holdingBalance: number;
      holdingPercent: number;
      payoutAmount: number;
      payoutCurrency: string;
      autoConverted: boolean;
      convertedAmount?: number;
      convertedCurrency?: string;
    }>;
  };
}

function DistributionResultCard({ result, currency }: { result: DistributionResult; currency: string }) {
  const [showPayouts, setShowPayouts] = useState(true);

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-2 pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-500" />
            Distribution Executed
          </CardTitle>
          <Badge variant="default" data-testid="badge-distribution-status">
            {result.distribution.status}
          </Badge>
        </CardHeader>
        <CardContent data-testid="distribution-result">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Total Distributed</p>
              <p className="text-sm font-semibold text-emerald-600 dark:text-emerald-400" data-testid="text-total-distributed">
                {fmt(result.summary.totalDistributed, currency)}
              </p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Per Token</p>
              <p className="text-sm font-semibold" data-testid="text-per-token">
                {fmt(result.summary.perTokenAmount, currency)}
              </p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Recipients</p>
              <p className="text-sm font-semibold" data-testid="text-recipient-count">
                {result.summary.recipientCount}
              </p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Token Supply</p>
              <p className="text-sm font-semibold" data-testid="text-token-supply">
                {parseFloat(result.summary.totalTokenSupply).toLocaleString()}
              </p>
            </div>
          </div>
          <div className="mt-4 flex items-center gap-2 text-sm text-muted-foreground bg-muted/50 p-3 rounded-md">
            <Wallet className="w-4 h-4 shrink-0" />
            <span>
              Snapshot taken at {new Date(result.summary.snapshotDate).toLocaleString()} with {result.snapshot.holderCount} holder{result.snapshot.holderCount !== 1 ? "s" : ""}
              {result.summary.autoConvertedCount > 0 && ` | ${result.summary.autoConvertedCount} auto-converted`}
            </span>
          </div>
        </CardContent>
      </Card>

      {result.summary.payoutDetails.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <Button
              variant="ghost"
              className="flex items-center justify-between gap-2 w-full text-left"
              onClick={() => setShowPayouts(!showPayouts)}
              data-testid="button-toggle-dist-payouts"
            >
              <span className="flex items-center gap-2 text-base font-semibold">
                <Users className="w-4 h-4" />
                Wallet Credits ({result.summary.payoutDetails.length})
              </span>
              {showPayouts ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </Button>
          </CardHeader>
          {showPayouts && (
            <CardContent data-testid="distribution-payouts">
              <div className="border rounded-md overflow-hidden">
                <div className="grid grid-cols-5 gap-2 px-4 py-2 bg-muted/50 text-xs font-medium text-muted-foreground">
                  <span>Investor</span>
                  <span className="text-right">Holding</span>
                  <span className="text-right">Share %</span>
                  <span className="text-right">Payout</span>
                  <span className="text-right">Status</span>
                </div>
                {result.summary.payoutDetails.map((p) => (
                  <div
                    key={p.userId}
                    className="grid grid-cols-5 gap-2 px-4 py-2 border-t text-sm"
                    data-testid={`dist-payout-row-${p.userId}`}
                  >
                    <span className="truncate">{p.fullName || p.username}</span>
                    <span className="text-right font-mono">{p.holdingBalance.toLocaleString()}</span>
                    <span className="text-right font-mono">{p.holdingPercent.toFixed(2)}%</span>
                    <span className="text-right font-mono font-semibold text-emerald-600 dark:text-emerald-400">
                      {fmt(p.payoutAmount, p.payoutCurrency)}
                    </span>
                    <span className="text-right">
                      {p.autoConverted ? (
                        <Badge variant="secondary" className="text-xs">
                          {fmt(p.convertedAmount || 0, p.convertedCurrency || "")}
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-xs">Credited</Badge>
                      )}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          )}
        </Card>
      )}
    </div>
  );
}

export default function AdminWaterfallDistribution() {
  const { toast } = useToast();
  const [selectedAssetId, setSelectedAssetId] = useState<string | null>(null);
  const [selectedPeriod, setSelectedPeriod] = useState("");
  const [reservePercent, setReservePercent] = useState("5");
  const [platformFeePercent, setPlatformFeePercent] = useState("1");
  const [previewData, setPreviewData] = useState<WaterfallPreview | null>(null);
  const [lastSavedWaterfallId, setLastSavedWaterfallId] = useState<string | null>(null);
  const [distributionResult, setDistributionResult] = useState<DistributionResult | null>(null);

  const { data: properties, isLoading: propertiesLoading } = useQuery<PropertySummary[]>({
    queryKey: ["/api/admin/rental-operations"],
  });

  const selectedProperty = properties?.find(p => p.assetId === selectedAssetId);

  const availablePeriods = selectedProperty
    ? Array.from({ length: 24 }, (_, i) => {
        const d = new Date();
        d.setMonth(d.getMonth() - i);
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      })
    : [];

  const previewMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/finance/waterfall/preview", {
        assetId: selectedAssetId,
        period: selectedPeriod,
        reservePercent: parseFloat(reservePercent) || 0,
        platformFeePercent: parseFloat(platformFeePercent) || 0,
      });
      return res.json();
    },
    onSuccess: (data) => {
      setPreviewData(data);
    },
    onError: (err: any) => {
      toast({ title: "Preview failed", description: err.message, variant: "destructive" });
    },
  });

  const saveMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/finance/waterfall", {
        assetId: selectedAssetId,
        period: selectedPeriod,
        reservePercent: parseFloat(reservePercent) || 0,
        platformFeePercent: parseFloat(platformFeePercent) || 0,
        force: true,
      });
      return res.json();
    },
    onSuccess: (data: any) => {
      setLastSavedWaterfallId(data.id);
      setDistributionResult(null);
      toast({ title: "Waterfall saved", description: `Calculation for ${selectedPeriod} has been recorded.` });
      queryClient.invalidateQueries({ queryKey: ["/api/finance/waterfall"] });
    },
    onError: (err: any) => {
      toast({ title: "Save failed", description: err.message, variant: "destructive" });
    },
  });

  const distributeMutation = useMutation({
    mutationFn: async () => {
      if (!previewData || !selectedAssetId) throw new Error("No waterfall data");
      const res = await apiRequest("POST", "/api/finance/distributions", {
        assetId: selectedAssetId,
        netDistributable: parseFloat(previewData.distributableIncome),
        currency: previewData.baseCurrency,
        waterfallCalculationId: lastSavedWaterfallId || undefined,
        recordDate: new Date().toISOString().split("T")[0],
      });
      return res.json();
    },
    onSuccess: (data: DistributionResult) => {
      setDistributionResult(data);
      toast({
        title: "Distribution executed",
        description: `${fmt(data.summary.totalDistributed, data.summary.currency)} credited to ${data.summary.recipientCount} investor wallet${data.summary.recipientCount !== 1 ? "s" : ""}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/finance/distributions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/distributions"] });
    },
    onError: (err: any) => {
      toast({ title: "Distribution failed", description: err.message, variant: "destructive" });
    },
  });

  const { data: savedCalcs } = useQuery<any[]>({
    queryKey: ["/api/finance/waterfall", { assetId: selectedAssetId }],
    queryFn: async () => {
      if (!selectedAssetId) return [];
      const res = await fetch(`/api/finance/waterfall?assetId=${selectedAssetId}`, { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!selectedAssetId,
  });

  return (
    <RoleLayout role="admin">
      <div className="p-6 space-y-6 max-w-5xl mx-auto">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle title="Waterfall Distribution" description="Transparent income-to-payout cascade for each property" />
        </div>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Configure Calculation</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-muted-foreground">Property</label>
                {propertiesLoading ? (
                  <Skeleton className="h-9 w-full" />
                ) : (
                  <Select
                    value={selectedAssetId || ""}
                    onValueChange={(v) => {
                      setSelectedAssetId(v);
                      setPreviewData(null);
                      setLastSavedWaterfallId(null);
                      setDistributionResult(null);
                    }}
                  >
                    <SelectTrigger data-testid="select-property">
                      <SelectValue placeholder="Select property" />
                    </SelectTrigger>
                    <SelectContent>
                      {properties?.map(p => (
                        <SelectItem key={p.assetId} value={p.assetId}>
                          {p.assetName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-muted-foreground">Period</label>
                <Select
                  value={selectedPeriod}
                  onValueChange={(v) => {
                    setSelectedPeriod(v);
                    setPreviewData(null);
                    setLastSavedWaterfallId(null);
                    setDistributionResult(null);
                  }}
                  disabled={!selectedAssetId}
                >
                  <SelectTrigger data-testid="select-period">
                    <SelectValue placeholder="Select period" />
                  </SelectTrigger>
                  <SelectContent>
                    {availablePeriods.map(p => (
                      <SelectItem key={p} value={p}>{p}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-muted-foreground">Reserve %</label>
                <Input
                  type="number"
                  value={reservePercent}
                  onChange={(e) => setReservePercent(e.target.value)}
                  min="0"
                  max="100"
                  step="0.5"
                  data-testid="input-reserve-percent"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-muted-foreground">Platform Fee %</label>
                <Input
                  type="number"
                  value={platformFeePercent}
                  onChange={(e) => setPlatformFeePercent(e.target.value)}
                  min="0"
                  max="100"
                  step="0.1"
                  data-testid="input-platform-fee"
                />
              </div>
            </div>

            <div className="flex items-center gap-3 flex-wrap">
              <Button
                onClick={() => previewMutation.mutate()}
                disabled={!selectedAssetId || !selectedPeriod || previewMutation.isPending}
                data-testid="button-preview"
              >
                <Eye className="w-4 h-4 mr-2" />
                {previewMutation.isPending ? "Calculating..." : "Preview Waterfall"}
              </Button>
              {previewData && (
                <Button
                  variant="default"
                  onClick={() => saveMutation.mutate()}
                  disabled={saveMutation.isPending}
                  data-testid="button-save"
                >
                  <Save className="w-4 h-4 mr-2" />
                  {saveMutation.isPending ? "Saving..." : "Save & Record"}
                </Button>
              )}
              {previewData && lastSavedWaterfallId && !distributionResult && (
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="default"
                      disabled={distributeMutation.isPending || parseFloat(previewData.distributableIncome) <= 0}
                      data-testid="button-distribute"
                    >
                      {distributeMutation.isPending ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Wallet className="w-4 h-4 mr-2" />
                      )}
                      {distributeMutation.isPending ? "Distributing..." : "Distribute to Investors"}
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Execute Distribution</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will take a snapshot of current token holders and credit{" "}
                        <strong>{fmt(previewData.distributableIncome, previewData.baseCurrency)}</strong>{" "}
                        proportionally to their wallets. This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel data-testid="button-cancel-distribute">Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={(e) => {
                          e.preventDefault();
                          if (!distributeMutation.isPending) {
                            distributeMutation.mutate();
                          }
                        }}
                        disabled={distributeMutation.isPending}
                        data-testid="button-confirm-distribute"
                      >
                        {distributeMutation.isPending ? "Distributing..." : "Confirm Distribution"}
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              )}
              {distributionResult && (
                <Badge variant="default" className="flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  Distributed
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>

        {previewMutation.isPending && (
          <div className="space-y-3">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-64 w-full" />
          </div>
        )}

        {previewData && !previewMutation.isPending && (
          <WaterfallCascade data={previewData} />
        )}

        {distributionResult && previewData && (
          <DistributionResultCard result={distributionResult} currency={previewData.baseCurrency} />
        )}

        {savedCalcs && savedCalcs.length > 0 && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Saved Calculations</CardTitle>
            </CardHeader>
            <CardContent data-testid="saved-calculations">
              <div className="border rounded-md overflow-hidden">
                <div className="grid grid-cols-5 gap-2 px-4 py-2 bg-muted/50 text-xs font-medium text-muted-foreground">
                  <span>Period</span>
                  <span className="text-right">Gross Rent</span>
                  <span className="text-right">NOI</span>
                  <span className="text-right">Distributable</span>
                  <span className="text-right">Date</span>
                </div>
                {savedCalcs.map((c: any) => (
                  <div
                    key={c.id}
                    className="grid grid-cols-5 gap-2 px-4 py-2 border-t text-sm hover-elevate cursor-pointer"
                    onClick={() => {
                      setSelectedPeriod(c.period);
                      const bd = c.breakdown as any;
                      if (bd?.steps) {
                        setPreviewData({
                          preview: false,
                          assetId: c.assetId,
                          assetName: selectedProperty?.assetName || c.assetId,
                          period: c.period,
                          baseCurrency: c.baseCurrency,
                          grossRent: c.grossRent,
                          vacancyImpact: "0",
                          effectiveRent: c.grossRent,
                          maintenanceExpense: "0",
                          managementFeeExpense: "0",
                          insuranceExpense: "0",
                          propertyTaxExpense: "0",
                          utilityExpense: "0",
                          platformFeePercent: c.platformFeePercent,
                          platformFeeAmount: c.platformFeeAmount,
                          otherExpense: "0",
                          totalExpenses: c.totalExpenses,
                          netOperatingIncome: c.netOperatingIncome,
                          reservePercent: c.reservePercent,
                          reserveAmount: c.reserveAmount,
                          distributableIncome: c.netDistributable,
                          unitDistribution: null,
                          breakdown: bd.steps,
                          investorPayouts: bd.investorPayouts || [],
                          rentCollectionCount: 0,
                          expenseCount: 0,
                        });
                      }
                    }}
                    data-testid={`saved-calc-${c.period}`}
                  >
                    <span className="font-medium">{c.period}</span>
                    <span className="text-right font-mono">{fmt(c.grossRent, c.baseCurrency)}</span>
                    <span className="text-right font-mono">{fmt(c.netOperatingIncome, c.baseCurrency)}</span>
                    <span className="text-right font-mono font-semibold text-emerald-600 dark:text-emerald-400">
                      {fmt(c.netDistributable, c.baseCurrency)}
                    </span>
                    <span className="text-right text-muted-foreground text-xs">
                      {c.createdAt ? new Date(c.createdAt).toLocaleDateString() : "-"}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </RoleLayout>
  );
}
