import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { WALLET_CURRENCIES } from "@/lib/currencies";
import {
  Building2,
  Plus,
  Pencil,
  Trash2,
  Globe,
  CheckCircle2,
  XCircle, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface ReceivingBankAccount {
  id: string;
  countryCode: string;
  currency: string;
  bankName: string;
  accountName: string;
  iban: string | null;
  swiftCode: string | null;
  sortCode: string | null;
  routingNumber: string | null;
  branch: string | null;
  accountNumber: string | null;
  isActive: boolean;
  notes: string | null;
  updatedBy: string | null;
  createdAt: string;
}

const COUNTRY_OPTIONS = [
  { code: "AE", name: "United Arab Emirates" },
  { code: "PK", name: "Pakistan" },
  { code: "GB", name: "United Kingdom" },
  { code: "US", name: "United States" },
  { code: "QA", name: "Qatar" },
];


const EMPTY_FORM = {
  countryCode: "",
  currency: "",
  bankName: "",
  accountName: "",
  iban: "",
  swiftCode: "",
  sortCode: "",
  routingNumber: "",
  branch: "",
  accountNumber: "",
  notes: "",
};

export default function AdminReceivingBanks() {
  const { toast } = useToast();
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);

  const { data: accounts, isLoading } = useQuery<ReceivingBankAccount[]>({
    queryKey: ["/api/admin/receiving-banks"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: typeof EMPTY_FORM) => {
      const clean = Object.fromEntries(
        Object.entries(data).filter(([_, v]) => v !== "")
      );
      const res = await apiRequest("POST", "/api/admin/receiving-banks", clean);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Bank Account Created", description: "Receiving bank account has been added." });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/receiving-banks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/receiving-banks"] });
      closeForm();
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to create bank account", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: typeof EMPTY_FORM }) => {
      const clean = Object.fromEntries(
        Object.entries(data).filter(([_, v]) => v !== "")
      );
      const res = await apiRequest("PATCH", `/api/admin/receiving-banks/${id}`, clean);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Bank Account Updated", description: "Receiving bank account has been updated." });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/receiving-banks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/receiving-banks"] });
      closeForm();
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to update bank account", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("DELETE", `/api/admin/receiving-banks/${id}`);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Bank Account Disabled", description: "Receiving bank account has been deactivated." });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/receiving-banks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/receiving-banks"] });
      setShowDeleteConfirm(null);
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to deactivate bank account", variant: "destructive" });
    },
  });

  function closeForm() {
    setShowForm(false);
    setEditId(null);
    setForm(EMPTY_FORM);
  }

  function openEdit(account: ReceivingBankAccount) {
    setEditId(account.id);
    setForm({
      countryCode: account.countryCode,
      currency: account.currency,
      bankName: account.bankName,
      accountName: account.accountName,
      iban: account.iban || "",
      swiftCode: account.swiftCode || "",
      sortCode: account.sortCode || "",
      routingNumber: account.routingNumber || "",
      branch: account.branch || "",
      accountNumber: account.accountNumber || "",
      notes: account.notes || "",
    });
    setShowForm(true);
  }

  function handleSubmit() {
    if (!form.countryCode || !form.currency || !form.bankName || !form.accountName) {
      toast({ title: "Validation Error", description: "Country, currency, bank name and account name are required.", variant: "destructive" });
      return;
    }
    if (editId) {
      updateMutation.mutate({ id: editId, data: form });
    } else {
      createMutation.mutate(form);
    }
  }

  const activeAccounts = accounts?.filter(a => a.isActive) || [];
  const inactiveAccounts = accounts?.filter(a => !a.isActive) || [];
  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <RoleLayout role="admin">
      <div className="flex items-center gap-3">
        <Link href="/admin/dashboard">
          <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <PageTitle title="Receiving Bank Accounts" description="Manage platform bank details shown to investors for deposits" />
      </div>

      <Section>
        <div className="flex items-center justify-between gap-2 flex-wrap mb-4">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">{activeAccounts.length} active account{activeAccounts.length !== 1 ? "s" : ""}</span>
          </div>
          <Button
            onClick={() => { setEditId(null); setForm(EMPTY_FORM); setShowForm(true); }}
            data-testid="button-add-receiving-bank"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Bank Account
          </Button>
        </div>

        {isLoading ? (
          <div className="space-y-2">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        ) : activeAccounts.length === 0 ? (
          <GlassCard className="p-8 text-center">
            <Building2 className="w-10 h-10 mx-auto mb-3 text-muted-foreground" />
            <p className="text-muted-foreground">No receiving bank accounts configured yet.</p>
            <p className="text-xs text-muted-foreground mt-1">Add your platform's bank details so investors can make deposits.</p>
          </GlassCard>
        ) : (
          <GlassCard className="overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Currency</TableHead>
                  <TableHead>Country</TableHead>
                  <TableHead>Bank</TableHead>
                  <TableHead>Account Name</TableHead>
                  <TableHead>IBAN / Account</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {activeAccounts.map(account => (
                  <TableRow key={account.id} data-testid={`row-bank-${account.id}`}>
                    <TableCell>
                      <Badge variant="outline" data-testid={`text-currency-${account.id}`}>{account.currency}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Globe className="w-3 h-3 text-muted-foreground" />
                        <span className="text-sm" data-testid={`text-country-${account.id}`}>
                          {COUNTRY_OPTIONS.find(c => c.code === account.countryCode)?.name || account.countryCode}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="font-medium text-sm" data-testid={`text-bank-${account.id}`}>{account.bankName}</span>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm" data-testid={`text-account-name-${account.id}`}>{account.accountName}</span>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm font-mono" data-testid={`text-iban-${account.id}`}>
                        {account.iban || account.accountNumber || "-"}
                      </span>
                    </TableCell>
                    <TableCell>
                      <Badge variant="default" data-testid={`badge-status-${account.id}`}>
                        <CheckCircle2 className="w-3 h-3 mr-1" />
                        Active
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => openEdit(account)}
                          data-testid={`button-edit-${account.id}`}
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => setShowDeleteConfirm(account.id)}
                          data-testid={`button-disable-${account.id}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </GlassCard>
        )}

        {inactiveAccounts.length > 0 && (
          <div className="mt-6">
            <p className="text-sm text-muted-foreground mb-2">Inactive Accounts ({inactiveAccounts.length})</p>
            <GlassCard className="overflow-hidden opacity-60">
              <Table>
                <TableBody>
                  {inactiveAccounts.map(account => (
                    <TableRow key={account.id}>
                      <TableCell>
                        <Badge variant="secondary">{account.currency}</Badge>
                      </TableCell>
                      <TableCell className="text-sm">{account.bankName}</TableCell>
                      <TableCell className="text-sm">{account.accountName}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">
                          <XCircle className="w-3 h-3 mr-1" />
                          Inactive
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </GlassCard>
          </div>
        )}
      </Section>

      <Dialog open={showForm} onOpenChange={() => closeForm()}>
        <DialogContent className="sm:max-w-lg" data-testid="dialog-bank-form">
          <DialogHeader>
            <DialogTitle>{editId ? "Edit" : "Add"} Receiving Bank Account</DialogTitle>
            <DialogDescription>
              {editId ? "Update the bank details for this receiving account." : "Add a new bank account that investors will use for deposits."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label>Country</Label>
                <Select value={form.countryCode} onValueChange={v => setForm(f => ({ ...f, countryCode: v }))}>
                  <SelectTrigger data-testid="select-country">
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    {COUNTRY_OPTIONS.map(c => (
                      <SelectItem key={c.code} value={c.code}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label>Currency</Label>
                <Select value={form.currency} onValueChange={v => setForm(f => ({ ...f, currency: v }))}>
                  <SelectTrigger data-testid="select-currency">
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    {[...WALLET_CURRENCIES].map(c => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1">
              <Label>Bank Name</Label>
              <Input
                value={form.bankName}
                onChange={e => setForm(f => ({ ...f, bankName: e.target.value }))}
                placeholder="e.g. Barclays Bank UK"
                data-testid="input-bank-name"
              />
            </div>
            <div className="space-y-1">
              <Label>Account Name</Label>
              <Input
                value={form.accountName}
                onChange={e => setForm(f => ({ ...f, accountName: e.target.value }))}
                placeholder="e.g. VestBlock UK Limited"
                data-testid="input-account-name"
              />
            </div>
            <div className="space-y-1">
              <Label>IBAN</Label>
              <Input
                value={form.iban}
                onChange={e => setForm(f => ({ ...f, iban: e.target.value }))}
                placeholder="e.g. GB29 BARC 2013 8456 7890 12"
                data-testid="input-iban"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label>SWIFT / BIC Code</Label>
                <Input
                  value={form.swiftCode}
                  onChange={e => setForm(f => ({ ...f, swiftCode: e.target.value }))}
                  placeholder="e.g. BARCGB22XXX"
                  data-testid="input-swift"
                />
              </div>
              <div className="space-y-1">
                <Label>Sort Code (UK)</Label>
                <Input
                  value={form.sortCode}
                  onChange={e => setForm(f => ({ ...f, sortCode: e.target.value }))}
                  placeholder="e.g. 20-13-84"
                  data-testid="input-sort-code"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label>Routing Number (US)</Label>
                <Input
                  value={form.routingNumber}
                  onChange={e => setForm(f => ({ ...f, routingNumber: e.target.value }))}
                  placeholder="e.g. 021000021"
                  data-testid="input-routing"
                />
              </div>
              <div className="space-y-1">
                <Label>Account Number</Label>
                <Input
                  value={form.accountNumber}
                  onChange={e => setForm(f => ({ ...f, accountNumber: e.target.value }))}
                  placeholder="e.g. 123456789012"
                  data-testid="input-account-number"
                />
              </div>
            </div>
            <div className="space-y-1">
              <Label>Branch</Label>
              <Input
                value={form.branch}
                onChange={e => setForm(f => ({ ...f, branch: e.target.value }))}
                placeholder="e.g. London City Branch"
                data-testid="input-branch"
              />
            </div>
            <div className="space-y-1">
              <Label>Notes (internal)</Label>
              <Textarea
                value={form.notes}
                onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                placeholder="Internal notes for finance team"
                className="resize-none"
                data-testid="input-notes"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2 mt-4">
            <Button variant="outline" onClick={closeForm} data-testid="button-cancel-form">
              Cancel
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={isPending}
              data-testid="button-save-bank"
            >
              {isPending ? "Saving..." : editId ? "Update Account" : "Add Account"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={!!showDeleteConfirm} onOpenChange={() => setShowDeleteConfirm(null)}>
        <DialogContent className="sm:max-w-sm" data-testid="dialog-disable-confirm">
          <DialogHeader>
            <DialogTitle>Disable Bank Account</DialogTitle>
            <DialogDescription>
              This will hide this bank account from investors. It can be re-activated later. Are you sure?
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-2 mt-4">
            <Button variant="outline" onClick={() => setShowDeleteConfirm(null)} data-testid="button-cancel-disable">
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => showDeleteConfirm && deleteMutation.mutate(showDeleteConfirm)}
              disabled={deleteMutation.isPending}
              data-testid="button-confirm-disable"
            >
              {deleteMutation.isPending ? "Disabling..." : "Disable Account"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </RoleLayout>
  );
}
