import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { DataTable, type Column } from "@/components/data-table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Search,
  Users,
  ShieldAlert,
  ShieldCheck,
  Archive,
  LogOut,
  ArrowRightLeft,
  Clock,
  AlertTriangle,
  Eye,
  UserCog, ArrowLeft,
} from "lucide-react";
import { useState } from "react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
interface UserRow {
  id: string;
  username: string;
  email: string;
  fullName: string;
  role: string;
  platformRole: string | null;
  kycStatus: string;
  accountStatus: string;
  isActive: boolean;
  disabledAt: string | null;
  archivedAt: string | null;
  hasFinancialRecords?: boolean;
}

interface AuditLogEntry {
  id: string;
  actorId: string;
  actorRole: string;
  actionType: string;
  entityType: string;
  entityId: string;
  reason: string;
  beforeState: any;
  afterState: any;
  createdAt: string;
}

type ModalAction = "status" | "force-logout" | "transfer" | "audit" | "detail" | "role" | null;

const LEGACY_ROLES = ["admin", "investor", "issuer", "agent"];
const PLATFORM_ROLES_LIST = ["SUPER_ADMIN", "PLATFORM_ADMIN", "PLATFORM_FINANCE", "PLATFORM_COMPLIANCE"];

export default function AdminUsers() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedUser, setSelectedUser] = useState<UserRow | null>(null);
  const [modalAction, setModalAction] = useState<ModalAction>(null);
  const [statusValue, setStatusValue] = useState("");
  const [reason, setReason] = useState("");
  const [transferToUserId, setTransferToUserId] = useState("");
  const [roleValue, setRoleValue] = useState("");
  const [platformRoleValue, setPlatformRoleValue] = useState("");
  const [togglingUserId, setTogglingUserId] = useState<string | null>(null);
  const { toast } = useToast();

  const { data: users = [], isLoading } = useQuery<UserRow[]>({
    queryKey: ["/api/admin/users"],
  });

  const statusMutation = useMutation({
    mutationFn: async ({ userId, status, reason }: { userId: string; status: string; reason: string }) => {
      setTogglingUserId(userId);
      const res = await apiRequest("POST", `/api/admin/users/${userId}/status`, { status, reason });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({ title: "Status Updated", description: data.message || "Account status changed successfully" });
      setTogglingUserId(null);
      closeModal();
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to update status", variant: "destructive" });
      setTogglingUserId(null);
    },
  });

  const forceLogoutMutation = useMutation({
    mutationFn: async (userId: string) => {
      const res = await apiRequest("POST", `/api/admin/users/${userId}/force-logout`);
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: "Force Logout", description: data.message || "Sessions revoked" });
      closeModal();
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to force logout", variant: "destructive" });
    },
  });

  const transferMutation = useMutation({
    mutationFn: async ({ fromUserId, toUserId }: { fromUserId: string; toUserId: string }) => {
      const res = await apiRequest("POST", `/api/admin/users/${fromUserId}/transfer-projects`, { toUserId });
      return res.json();
    },
    onSuccess: (data) => {
      toast({ title: "Transferred", description: data.message || "Projects transferred" });
      closeModal();
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to transfer", variant: "destructive" });
    },
  });

  const roleMutation = useMutation({
    mutationFn: async ({ userId, role, platformRole, reason }: { userId: string; role?: string; platformRole?: string | null; reason?: string }) => {
      const res = await apiRequest("POST", `/api/admin/users/${userId}/role`, { role, platformRole, reason });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({ title: "Role Updated", description: data.message || "User roles updated successfully" });
      closeModal();
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to update roles", variant: "destructive" });
    },
  });

  const { data: auditLogs = [], isLoading: auditLoading } = useQuery<AuditLogEntry[]>({
    queryKey: [`/api/admin/users/${selectedUser?.id}/audit-log`],
    enabled: modalAction === "audit" && !!selectedUser,
  });

  const { data: userDetail } = useQuery<UserRow>({
    queryKey: [`/api/admin/users/${selectedUser?.id}`],
    enabled: modalAction === "detail" && !!selectedUser,
  });

  const closeModal = () => {
    setModalAction(null);
    setSelectedUser(null);
    setStatusValue("");
    setReason("");
    setTransferToUserId("");
    setRoleValue("");
    setPlatformRoleValue("");
  };

  const openAction = (user: UserRow, action: ModalAction) => {
    setSelectedUser(user);
    setModalAction(action);
    if (action === "status") setStatusValue(user.accountStatus);
    if (action === "role") {
      setRoleValue(user.role);
      setPlatformRoleValue(user.platformRole || "none");
    }
  };

  const filtered = users.filter((u) => {
    const matchSearch = !search ||
      u.fullName?.toLowerCase().includes(search.toLowerCase()) ||
      u.email?.toLowerCase().includes(search.toLowerCase()) ||
      u.username?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || u.accountStatus === statusFilter;
    return matchSearch && matchStatus;
  });

  const statusBadge = (status: string) => {
    switch (status) {
      case "ACTIVE": return <Badge variant="default" className="text-xs" data-testid="badge-status-active">Active</Badge>;
      case "DISABLED": return <Badge variant="destructive" className="text-xs" data-testid="badge-status-disabled">Disabled</Badge>;
      case "ARCHIVED": return <Badge variant="secondary" className="text-xs" data-testid="badge-status-archived">Archived</Badge>;
      default: return <Badge variant="outline" className="text-xs">{status}</Badge>;
    }
  };

  const statusCounts = {
    all: users.length,
    ACTIVE: users.filter(u => u.accountStatus === "ACTIVE").length,
    DISABLED: users.filter(u => u.accountStatus === "DISABLED").length,
    ARCHIVED: users.filter(u => u.accountStatus === "ARCHIVED").length,
  };

  const columns: Column<UserRow>[] = [
    { header: "Name", accessor: (row) => (
      <div>
        <p className="font-medium" data-testid={`text-user-name-${row.id}`}>{row.fullName || row.username}</p>
        <p className="text-xs text-muted-foreground">{row.email}</p>
      </div>
    )},
    { header: "Role", accessor: (row) => (
      <div className="flex items-center gap-1 flex-wrap">
        <Badge variant="outline" className="text-xs">{row.role}</Badge>
        {row.platformRole && <Badge variant="secondary" className="text-xs">{row.platformRole}</Badge>}
      </div>
    )},
    { header: "Status", accessor: (row) => (
      <div className="flex items-center gap-2">
        <Switch
          checked={row.accountStatus === "ACTIVE"}
          disabled={row.accountStatus === "ARCHIVED" || togglingUserId === row.id}
          onCheckedChange={(checked) => {
            const newStatus = checked ? "ACTIVE" : "DISABLED";
            statusMutation.mutate({ userId: row.id, status: newStatus, reason: `Account ${checked ? "enabled" : "disabled"} via toggle` });
          }}
          data-testid={`switch-status-${row.id}`}
        />
        <span className="text-xs text-muted-foreground">
          {row.accountStatus === "ACTIVE" ? "ON" : row.accountStatus === "ARCHIVED" ? "Archived" : "OFF"}
        </span>
      </div>
    )},
    { header: "KYC", accessor: (row) => (
      <Badge variant={row.kycStatus === "verified" ? "default" : "secondary"} className="text-xs">{row.kycStatus}</Badge>
    )},
    { header: "Actions", accessor: (row) => (
      <div className="flex items-center gap-1 flex-wrap">
        <Button size="icon" variant="ghost" onClick={() => openAction(row, "detail")} data-testid={`button-view-user-${row.id}`}>
          <Eye className="w-4 h-4" />
        </Button>
        <Button size="icon" variant="ghost" onClick={() => openAction(row, "role")} data-testid={`button-role-user-${row.id}`}>
          <UserCog className="w-4 h-4" />
        </Button>
        <Button size="icon" variant="ghost" onClick={() => openAction(row, "force-logout")} data-testid={`button-logout-user-${row.id}`}>
          <LogOut className="w-4 h-4" />
        </Button>
        <Button size="icon" variant="ghost" onClick={() => openAction(row, "transfer")} data-testid={`button-transfer-user-${row.id}`}>
          <ArrowRightLeft className="w-4 h-4" />
        </Button>
        <Button size="icon" variant="ghost" onClick={() => openAction(row, "audit")} data-testid={`button-audit-user-${row.id}`}>
          <Clock className="w-4 h-4" />
        </Button>
        <Button size="icon" variant="ghost" onClick={() => openAction(row, "status")} data-testid={`button-status-user-${row.id}`}>
          <Archive className="w-4 h-4" />
        </Button>
      </div>
    )},
  ];

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Account Management"
          description="Manage user accounts, status, sessions, and ownership"
        />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {(["all", "ACTIVE", "DISABLED", "ARCHIVED"] as const).map((s) => (
            <Card
              key={s}
              className={`cursor-pointer hover-elevate ${statusFilter === s ? "ring-2 ring-primary" : ""}`}
              onClick={() => setStatusFilter(s)}
              data-testid={`card-filter-${s.toLowerCase()}`}
            >
              <CardContent className="p-4">
                <p className="text-2xl font-bold" data-testid={`text-count-${s.toLowerCase()}`}>{statusCounts[s]}</p>
                <p className="text-xs text-muted-foreground capitalize">{s === "all" ? "All Users" : s.toLowerCase()}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search users..." className="pl-9" value={search} onChange={e => setSearch(e.target.value)} data-testid="input-search-users" />
          </div>
        </div>

        <Section>
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3, 4, 5].map(i => <Skeleton key={i} className="h-12 w-full" />)}
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12">
              <Users className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground" data-testid="text-no-users">No users found</p>
            </div>
          ) : (
            <DataTable columns={columns} data={filtered} />
          )}
        </Section>
      </div>

      <Dialog open={modalAction === "status"} onOpenChange={(open) => !open && closeModal()}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Change Account Status</DialogTitle>
            <DialogDescription>
              Update status for <span className="font-medium">{selectedUser?.fullName || selectedUser?.username}</span>
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">New Status</label>
              <Select value={statusValue} onValueChange={setStatusValue}>
                <SelectTrigger data-testid="select-status">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ACTIVE">Active - Full access</SelectItem>
                  <SelectItem value="DISABLED">Disabled - Login blocked, money actions blocked</SelectItem>
                  <SelectItem value="ARCHIVED">Archived - Removed from listings, audit preserved</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">Reason</label>
              <Textarea
                placeholder="Reason for status change..."
                value={reason}
                onChange={e => setReason(e.target.value)}
                data-testid="input-status-reason"
              />
            </div>
            {(statusValue === "DISABLED" || statusValue === "ARCHIVED") && (
              <div className="flex items-start gap-2 p-3 bg-muted rounded-md">
                <AlertTriangle className="w-4 h-4 mt-0.5 text-amber-500 flex-shrink-0" />
                <div className="text-sm">
                  <p className="font-medium">This will:</p>
                  <ul className="list-disc ml-4 text-muted-foreground">
                    <li>Prevent the user from logging in</li>
                    <li>Revoke all active sessions</li>
                    <li>Block all financial operations</li>
                    {selectedUser?.role === "admin" && <li>Auto-transfer project ownership to another admin</li>}
                  </ul>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={closeModal} data-testid="button-cancel-status">Cancel</Button>
            <Button
              onClick={() => selectedUser && statusMutation.mutate({ userId: selectedUser.id, status: statusValue, reason })}
              disabled={!statusValue || statusValue === selectedUser?.accountStatus || statusMutation.isPending}
              data-testid="button-confirm-status"
            >
              {statusMutation.isPending ? "Updating..." : "Update Status"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={modalAction === "force-logout"} onOpenChange={(open) => !open && closeModal()}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Force Logout</DialogTitle>
            <DialogDescription>
              Revoke all sessions for <span className="font-medium">{selectedUser?.fullName || selectedUser?.username}</span>?
              They will need to log in again.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={closeModal} data-testid="button-cancel-logout">Cancel</Button>
            <Button
              variant="destructive"
              onClick={() => selectedUser && forceLogoutMutation.mutate(selectedUser.id)}
              disabled={forceLogoutMutation.isPending}
              data-testid="button-confirm-logout"
            >
              {forceLogoutMutation.isPending ? "Revoking..." : "Revoke Sessions"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={modalAction === "transfer"} onOpenChange={(open) => !open && closeModal()}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Transfer Project Ownership</DialogTitle>
            <DialogDescription>
              Transfer all projects owned by <span className="font-medium">{selectedUser?.fullName || selectedUser?.username}</span> to another user.
            </DialogDescription>
          </DialogHeader>
          <div>
            <label className="text-sm font-medium">Transfer To</label>
            <Select value={transferToUserId} onValueChange={setTransferToUserId}>
              <SelectTrigger data-testid="select-transfer-to">
                <SelectValue placeholder="Select target user" />
              </SelectTrigger>
              <SelectContent>
                {users.filter(u => u.id !== selectedUser?.id && u.accountStatus === "ACTIVE").map(u => (
                  <SelectItem key={u.id} value={u.id}>{u.fullName || u.username} ({u.email})</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={closeModal} data-testid="button-cancel-transfer">Cancel</Button>
            <Button
              onClick={() => selectedUser && transferToUserId && transferMutation.mutate({ fromUserId: selectedUser.id, toUserId: transferToUserId })}
              disabled={!transferToUserId || transferMutation.isPending}
              data-testid="button-confirm-transfer"
            >
              {transferMutation.isPending ? "Transferring..." : "Transfer Projects"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={modalAction === "audit"} onOpenChange={(open) => !open && closeModal()}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Audit Log</DialogTitle>
            <DialogDescription>
              Account actions for <span className="font-medium">{selectedUser?.fullName || selectedUser?.username}</span>
            </DialogDescription>
          </DialogHeader>
          {auditLoading ? (
            <div className="space-y-2">{[1,2,3].map(i => <Skeleton key={i} className="h-16 w-full" />)}</div>
          ) : auditLogs.length === 0 ? (
            <p className="text-center text-muted-foreground py-8" data-testid="text-no-audit">No audit entries found</p>
          ) : (
            <div className="space-y-3">
              {auditLogs.map((log) => (
                <Card key={log.id}>
                  <CardContent className="p-3">
                    <div className="flex items-start justify-between gap-2 flex-wrap">
                      <div>
                        <Badge variant="outline" className="text-xs mb-1">{log.actionType}</Badge>
                        <p className="text-sm" data-testid={`text-audit-reason-${log.id}`}>{log.reason}</p>
                      </div>
                      <span className="text-xs text-muted-foreground whitespace-nowrap">
                        {new Date(log.createdAt).toLocaleString()}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={modalAction === "role"} onOpenChange={(open) => !open && closeModal()}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign Roles</DialogTitle>
            <DialogDescription>
              Change roles for <span className="font-medium">{selectedUser?.fullName || selectedUser?.username}</span>
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Application Role</label>
              <Select value={roleValue} onValueChange={setRoleValue}>
                <SelectTrigger data-testid="select-role">
                  <SelectValue placeholder="Select role" />
                </SelectTrigger>
                <SelectContent>
                  {LEGACY_ROLES.map(r => (
                    <SelectItem key={r} value={r}>{r.charAt(0).toUpperCase() + r.slice(1)}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">Platform Role</label>
              <Select value={platformRoleValue} onValueChange={setPlatformRoleValue}>
                <SelectTrigger data-testid="select-platform-role">
                  <SelectValue placeholder="Select platform role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None (Standard User)</SelectItem>
                  {PLATFORM_ROLES_LIST.map(r => (
                    <SelectItem key={r} value={r}>{r.replace(/_/g, " ")}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium">Reason</label>
              <Textarea
                placeholder="Reason for role change..."
                value={reason}
                onChange={e => setReason(e.target.value)}
                data-testid="input-role-reason"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={closeModal} data-testid="button-cancel-role">Cancel</Button>
            <Button
              onClick={() => {
                if (!selectedUser) return;
                const updates: any = { reason };
                if (roleValue !== selectedUser.role) updates.role = roleValue;
                if ((platformRoleValue === "none" ? null : platformRoleValue) !== selectedUser.platformRole) {
                  updates.platformRole = platformRoleValue === "none" ? null : platformRoleValue;
                }
                roleMutation.mutate({ userId: selectedUser.id, ...updates });
              }}
              disabled={roleMutation.isPending || (roleValue === selectedUser?.role && (platformRoleValue === "none" ? null : platformRoleValue) === selectedUser?.platformRole)}
              data-testid="button-confirm-role"
            >
              {roleMutation.isPending ? "Updating..." : "Update Roles"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={modalAction === "detail"} onOpenChange={(open) => !open && closeModal()}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>User Details</DialogTitle>
          </DialogHeader>
          {selectedUser && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="text-xs text-muted-foreground">Full Name</p>
                  <p className="font-medium" data-testid="text-detail-name">{selectedUser.fullName}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Username</p>
                  <p className="font-medium">{selectedUser.username}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Email</p>
                  <p className="font-medium">{selectedUser.email}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Role</p>
                  <p className="font-medium">{selectedUser.role}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Account Status</p>
                  {statusBadge(selectedUser.accountStatus)}
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">KYC Status</p>
                  <p className="font-medium">{selectedUser.kycStatus}</p>
                </div>
                {selectedUser.platformRole && (
                  <div>
                    <p className="text-xs text-muted-foreground">Platform Role</p>
                    <Badge variant="secondary" className="text-xs">{selectedUser.platformRole}</Badge>
                  </div>
                )}
                {userDetail?.hasFinancialRecords && (
                  <div>
                    <p className="text-xs text-muted-foreground">Financial Records</p>
                    <Badge variant="outline" className="text-xs">Has Records</Badge>
                  </div>
                )}
              </div>
              {selectedUser.disabledAt && (
                <p className="text-xs text-muted-foreground">Disabled at: {new Date(selectedUser.disabledAt).toLocaleString()}</p>
              )}
              {selectedUser.archivedAt && (
                <p className="text-xs text-muted-foreground">Archived at: {new Date(selectedUser.archivedAt).toLocaleString()}</p>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </RoleLayout>
  );
}
