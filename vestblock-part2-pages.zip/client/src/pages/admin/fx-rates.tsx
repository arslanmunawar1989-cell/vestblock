import { useState, useMemo } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate, formatNumber } from "@/lib/format";
import { WALLET_CURRENCIES, CURRENCY_DETAILS } from "@shared/constants";
import { DEFAULT_CURRENCY } from "@/lib/currencies";
import {
  ArrowLeftRight,
  Plus,
  CheckCircle2,
  XCircle,
  TrendingUp,
  Server,
  Search,
} from "lucide-react";

interface FxRate {
  id: string;
  fromCurrency: string;
  toCurrency: string;
  rate: string;
  spread: string;
  provider: string;
  sourceLabel: string;
  fetchedAt: string;
  isActive: boolean;
  effectiveFrom: string;
  effectiveTo: string | null;
  createdBy: string | null;
  createdAt: string;
  updatedAt: string;
}

interface FxProviderInfo {
  name: string;
  label: string;
  description: string;
  configured: boolean;
}

const PROVIDERS = [
  { value: "manual", label: "Manual Entry" },
  { value: "market_feed", label: "Market Feed" },
  { value: "central_bank", label: "Central Bank" },
  { value: "bloomberg", label: "Bloomberg" },
  { value: "reuters", label: "Reuters" },
];

function formatRate(rate: string): string {
  const num = parseFloat(rate);
  if (num >= 1) return num.toFixed(4);
  return num.toFixed(8);
}

export default function AdminFxRates() {
  const { toast } = useToast();
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [fromCurrency, setFromCurrency] = useState(DEFAULT_CURRENCY);
  const [toCurrency, setToCurrency] = useState("PKR");
  const [rate, setRate] = useState("");
  const [spread, setSpread] = useState("0.005");
  const [provider, setProvider] = useState("manual");
  const [sourceLabel, setSourceLabel] = useState("manual");
  const [historyFromFilter, setHistoryFromFilter] = useState("ALL");
  const [historyToFilter, setHistoryToFilter] = useState("ALL");
  const [searchQuery, setSearchQuery] = useState("");

  const { data: rates, isLoading } = useQuery<FxRate[]>({
    queryKey: ["/api/admin/fx-rates"],
  });

  const historyParams = new URLSearchParams();
  if (historyFromFilter !== "ALL") historyParams.set("from", historyFromFilter);
  if (historyToFilter !== "ALL") historyParams.set("to", historyToFilter);
  const historyQs = historyParams.toString();

  const { data: historyRates, isLoading: historyLoading } = useQuery<FxRate[]>({
    queryKey: ["/api/admin/fx-rates/history", historyFromFilter, historyToFilter],
    queryFn: async () => {
      const res = await fetch(`/api/admin/fx-rates/history${historyQs ? `?${historyQs}` : ""}`);
      if (!res.ok) throw new Error("Failed to fetch history");
      return res.json();
    },
  });

  const { data: providers } = useQuery<FxProviderInfo[]>({
    queryKey: ["/api/admin/fx-providers"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: { fromCurrency: string; toCurrency: string; rate: string; spread: string; provider: string; sourceLabel: string }) => {
      const res = await apiRequest("POST", "/api/admin/fx-rates", data);
      if (!res.ok) {
        const err = await res.json().catch(() => ({ message: "Failed to create rate" }));
        throw new Error(err.message);
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/fx-rates"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/fx-rates/history"] });
      setShowCreateDialog(false);
      setRate("");
      setSpread("0.005");
      toast({ title: "Rate Published", description: "New FX rate is now active. Previous rate for this pair has been deactivated." });
    },
    onError: (err: any) => {
      toast({ title: "Failed", description: err.message || "Could not create rate", variant: "destructive" });
    },
  });

  const deactivateMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("POST", `/api/admin/fx-rates/${id}/deactivate`);
      if (!res.ok) {
        const err = await res.json().catch(() => ({ message: "Failed" }));
        throw new Error(err.message);
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/fx-rates"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/fx-rates/history"] });
      toast({ title: "Rate Deactivated", description: "FX rate has been deactivated" });
    },
    onError: (err: any) => {
      toast({ title: "Failed", description: err.message || "Could not deactivate rate", variant: "destructive" });
    },
  });

  const activeRates = useMemo(() => {
    let active = rates?.filter(r => r.isActive) || [];
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      active = active.filter(r =>
        r.fromCurrency.toLowerCase().includes(q) ||
        r.toCurrency.toLowerCase().includes(q) ||
        r.provider.toLowerCase().includes(q) ||
        r.sourceLabel.toLowerCase().includes(q)
      );
    }
    return active;
  }, [rates, searchQuery]);

  const historicalRates = useMemo(() => {
    return (historyRates || []).filter(r => !r.isActive);
  }, [historyRates]);

  const uniquePairs = useMemo(() => {
    const pairs = new Set<string>();
    activeRates.forEach(r => pairs.add(`${r.fromCurrency}/${r.toCurrency}`));
    return pairs.size;
  }, [activeRates]);

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <PageTitle title="FX Rate Management" description="Manage exchange rates across all currency pairs" />
          <Button onClick={() => setShowCreateDialog(true)} data-testid="button-create-fx-rate">
            <Plus className="h-4 w-4 mr-2" />
            New Rate
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <GlassCard padding="sm" data-testid="stat-active-rates">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-md bg-primary/10 flex items-center justify-center">
                <TrendingUp className="w-4 h-4 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{activeRates.length}</p>
                <p className="text-xs text-muted-foreground">Active Rates</p>
              </div>
            </div>
          </GlassCard>
          <GlassCard padding="sm" data-testid="stat-pairs">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-md bg-primary/10 flex items-center justify-center">
                <ArrowLeftRight className="w-4 h-4 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{uniquePairs}</p>
                <p className="text-xs text-muted-foreground">Currency Pairs</p>
              </div>
            </div>
          </GlassCard>
          <GlassCard padding="sm" data-testid="stat-providers">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-md bg-primary/10 flex items-center justify-center">
                <Server className="w-4 h-4 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{providers?.length ?? 0}</p>
                <p className="text-xs text-muted-foreground">Active Providers</p>
              </div>
            </div>
          </GlassCard>
        </div>

        {providers && providers.length > 0 && (
          <GlassCard padding="sm" data-testid="providers-card">
            <p className="text-xs font-semibold text-muted-foreground mb-2">Rate Providers</p>
            <div className="flex items-center gap-2 flex-wrap">
              {providers.map(p => (
                <Badge key={p.name} variant={p.configured ? "default" : "outline"} className="no-default-hover-elevate" data-testid={`provider-badge-${p.name}`}>
                  <Server className="w-3 h-3 mr-1" />
                  {p.label}
                  {!p.configured && <span className="ml-1 text-xs opacity-60">(not configured)</span>}
                </Badge>
              ))}
            </div>
          </GlassCard>
        )}

        <Section title="Active Rates">
          <div className="mb-4">
            <div className="relative max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by pair, provider..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
                data-testid="input-search-rates"
              />
            </div>
          </div>
          {isLoading ? (
            <div className="space-y-2">
              {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-12" />)}
            </div>
          ) : activeRates.length === 0 ? (
            <GlassCard padding="md">
              <p className="text-muted-foreground text-center py-4">No active exchange rates configured</p>
            </GlassCard>
          ) : (
            <GlassCard className="p-0 overflow-hidden" data-testid="table-active-rates">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Pair</TableHead>
                    <TableHead>Rate</TableHead>
                    <TableHead>Spread</TableHead>
                    <TableHead>Provider</TableHead>
                    <TableHead>Last Updated</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {activeRates.map(r => {
                    const fromDetails = CURRENCY_DETAILS[r.fromCurrency as keyof typeof CURRENCY_DETAILS];
                    const toDetails = CURRENCY_DETAILS[r.toCurrency as keyof typeof CURRENCY_DETAILS];
                    return (
                      <TableRow key={r.id} data-testid={`rate-row-${r.id}`}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <span className="font-semibold" data-testid={`rate-pair-${r.id}`}>
                              {r.fromCurrency}/{r.toCurrency}
                            </span>
                            <span className="text-xs text-muted-foreground">
                              {fromDetails?.symbol} {"->"} {toDetails?.symbol}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="font-mono font-semibold" data-testid={`rate-value-${r.id}`}>
                            {formatRate(r.rate)}
                          </span>
                        </TableCell>
                        <TableCell>
                          <span className="font-mono text-muted-foreground" data-testid={`rate-spread-${r.id}`}>
                            {(parseFloat(r.spread) * 100).toFixed(2)}%
                          </span>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="no-default-hover-elevate capitalize">
                            {r.provider}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {formatDate(r.updatedAt, "long")}
                        </TableCell>
                        <TableCell>
                          <Badge variant="default" className="no-default-hover-elevate" data-testid={`rate-status-${r.id}`}>
                            <CheckCircle2 className="h-3 w-3 mr-1" />
                            Active
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => deactivateMutation.mutate(r.id)}
                            disabled={deactivateMutation.isPending}
                            data-testid={`button-deactivate-${r.id}`}
                          >
                            <XCircle className="h-3 w-3 mr-1" />
                            Deactivate
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </GlassCard>
          )}
        </Section>

        {(historicalRates.length > 0 || (rates?.some(r => !r.isActive))) && (
          <Section title="Rate History">
            <div className="flex items-center gap-3 mb-4 flex-wrap">
              <Select value={historyFromFilter} onValueChange={setHistoryFromFilter}>
                <SelectTrigger className="w-[140px]" data-testid="filter-history-from">
                  <SelectValue placeholder="From Currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">All From</SelectItem>
                  {WALLET_CURRENCIES.map(cur => (
                    <SelectItem key={cur} value={cur}>{cur}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={historyToFilter} onValueChange={setHistoryToFilter}>
                <SelectTrigger className="w-[140px]" data-testid="filter-history-to">
                  <SelectValue placeholder="To Currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">All To</SelectItem>
                  {WALLET_CURRENCIES.map(cur => (
                    <SelectItem key={cur} value={cur}>{cur}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <span className="text-sm text-muted-foreground">
                {historicalRates.length} historical rate{historicalRates.length !== 1 ? "s" : ""}
              </span>
            </div>
            <GlassCard className="p-0 overflow-hidden" data-testid="table-rate-history">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Pair</TableHead>
                    <TableHead>Rate</TableHead>
                    <TableHead>Spread</TableHead>
                    <TableHead>Provider</TableHead>
                    <TableHead>Source</TableHead>
                    <TableHead>Effective Period</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {historicalRates.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-6 text-muted-foreground">
                        No historical rates match the selected filters
                      </TableCell>
                    </TableRow>
                  ) : (
                    historicalRates.map(r => (
                      <TableRow key={r.id} data-testid={`history-row-${r.id}`}>
                        <TableCell className="font-medium">{r.fromCurrency}/{r.toCurrency}</TableCell>
                        <TableCell className="font-mono">{formatRate(r.rate)}</TableCell>
                        <TableCell className="font-mono text-muted-foreground">{(parseFloat(r.spread) * 100).toFixed(2)}%</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="no-default-hover-elevate capitalize">{r.provider}</Badge>
                        </TableCell>
                        <TableCell className="capitalize text-sm text-muted-foreground">{r.sourceLabel}</TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {formatDate(r.effectiveFrom, "short")}
                          {r.effectiveTo && ` - ${formatDate(r.effectiveTo, "short")}`}
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="no-default-hover-elevate">
                            <XCircle className="h-3 w-3 mr-1" />
                            Inactive
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </GlassCard>
          </Section>
        )}

        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogContent data-testid="dialog-create-fx-rate">
            <DialogHeader>
              <DialogTitle>Set New Exchange Rate</DialogTitle>
              <DialogDescription>
                Publishing a new rate automatically deactivates the previous active rate for this currency pair and stores it in rate history.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>From Currency</Label>
                  <Select value={fromCurrency} onValueChange={(v: string) => {
                    setFromCurrency(v as typeof fromCurrency);
                    if (v === toCurrency) {
                      const alt = WALLET_CURRENCIES.find(c => c !== v);
                      if (alt) setToCurrency(alt);
                    }
                  }}>
                    <SelectTrigger data-testid="select-from-currency">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {WALLET_CURRENCIES.map(cur => (
                        <SelectItem key={cur} value={cur}>
                          {CURRENCY_DETAILS[cur].symbol} {cur}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>To Currency</Label>
                  <Select value={toCurrency} onValueChange={(v: string) => setToCurrency(v as typeof toCurrency)}>
                    <SelectTrigger data-testid="select-to-currency">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {WALLET_CURRENCIES.filter(c => c !== fromCurrency).map(cur => (
                        <SelectItem key={cur} value={cur}>
                          {CURRENCY_DETAILS[cur].symbol} {cur}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-1.5">
                <Label>Exchange Rate</Label>
                <Input
                  type="number"
                  step="any"
                  placeholder={`How many ${toCurrency} per 1 ${fromCurrency}`}
                  value={rate}
                  onChange={e => setRate(e.target.value)}
                  data-testid="input-fx-rate"
                />
                <p className="text-xs text-muted-foreground">
                  1 {fromCurrency} = {rate ? parseFloat(rate).toFixed(6) : "?"} {toCurrency}
                </p>
              </div>

              <div className="space-y-1.5">
                <Label>Spread (decimal, e.g. 0.005 = 0.5%)</Label>
                <Input
                  type="number"
                  step="any"
                  placeholder="e.g. 0.005"
                  value={spread}
                  onChange={e => setSpread(e.target.value)}
                  data-testid="input-fx-spread"
                />
                {spread && parseFloat(spread) > 0 && (
                  <p className="text-xs text-muted-foreground">
                    Spread: {(parseFloat(spread) * 100).toFixed(2)}%
                  </p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label>Provider</Label>
                  <Select value={provider} onValueChange={setProvider}>
                    <SelectTrigger data-testid="select-provider">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PROVIDERS.map(p => (
                        <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Source Label</Label>
                  <Select value={sourceLabel} onValueChange={setSourceLabel}>
                    <SelectTrigger data-testid="select-source-label">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="manual">Manual</SelectItem>
                      <SelectItem value="market">Market Feed</SelectItem>
                      <SelectItem value="central_bank">Central Bank</SelectItem>
                      <SelectItem value="api_feed">API Feed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {rate && parseFloat(rate) > 0 && (
                <GlassCard padding="sm" data-testid="card-rate-preview">
                  <p className="text-xs font-semibold text-muted-foreground mb-2">Rate Preview</p>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between gap-2">
                      <span className="text-muted-foreground">Pair</span>
                      <span className="font-semibold">{fromCurrency}/{toCurrency}</span>
                    </div>
                    <div className="flex justify-between gap-2">
                      <span className="text-muted-foreground">Rate</span>
                      <span className="font-mono font-semibold">{parseFloat(rate).toFixed(6)}</span>
                    </div>
                    <div className="flex justify-between gap-2">
                      <span className="text-muted-foreground">Spread</span>
                      <span className="font-mono">{(parseFloat(spread || "0") * 100).toFixed(2)}%</span>
                    </div>
                    <div className="flex justify-between gap-2">
                      <span className="text-muted-foreground">Example</span>
                      <span>
                        {CURRENCY_DETAILS[fromCurrency as keyof typeof CURRENCY_DETAILS]?.symbol}1,000 = {CURRENCY_DETAILS[toCurrency as keyof typeof CURRENCY_DETAILS]?.symbol}{formatNumber(1000 * parseFloat(rate), { decimals: 2 })}
                      </span>
                    </div>
                  </div>
                </GlassCard>
              )}

              <Button
                className="w-full"
                disabled={!rate || parseFloat(rate) <= 0 || fromCurrency === toCurrency || createMutation.isPending}
                onClick={() => {
                  createMutation.mutate({
                    fromCurrency,
                    toCurrency,
                    rate,
                    spread: spread || "0",
                    provider,
                    sourceLabel,
                  });
                }}
                data-testid="button-submit-fx-rate"
              >
                {createMutation.isPending ? "Publishing..." : "Publish Rate"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </RoleLayout>
  );
}
