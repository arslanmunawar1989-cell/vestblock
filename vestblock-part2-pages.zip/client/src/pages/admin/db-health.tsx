import { RoleLayout } from "@/components/role-layout";
import { GradientHeader } from "@/components/gradient-header";
import { GlassCard } from "@/components/glass-card";
import { Section } from "@/components/section";
import { PageTitle } from "@/components/page-title";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Database, CheckCircle, XCircle, RefreshCw, Server, Clock, HardDrive, ArrowLeft,
} from "lucide-react";
import { queryClient } from "@/lib/queryClient";
import { Link } from "wouter";
interface DbHealthResponse {
  status: "healthy" | "unhealthy";
  timestamp: string;
  latencyMs: number;
  prisma: {
    connected: boolean;
    userCount: number;
    auditLogCount: number;
  };
  drizzle: {
    connected: boolean;
    userCount: number;
    assetCount: number;
  };
  tables: string[];
  error?: string;
}

export default function AdminDbHealth() {
  const { data, isLoading, isError, error, isFetching } = useQuery<DbHealthResponse>({
    queryKey: ["/api/db-health"],
    refetchInterval: 30000,
  });

  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/db-health"] });
  };

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <GradientHeader>
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div>
              <p className="text-white/80 text-sm mb-1">System Monitoring</p>
              <h1 className="text-2xl font-bold text-white">Database Health</h1>
            </div>
            <div className="flex items-center gap-2">
              {data && (
                <Badge
                  className={
                    data.status === "healthy"
                      ? "bg-emerald-500/20 text-emerald-100 border-emerald-400/30"
                      : "bg-red-500/20 text-red-100 border-red-400/30"
                  }
                  data-testid="badge-db-status"
                >
                  {data.status === "healthy" ? (
                    <CheckCircle className="w-3 h-3 mr-1" />
                  ) : (
                    <XCircle className="w-3 h-3 mr-1" />
                  )}
                  {data.status === "healthy" ? "Healthy" : "Unhealthy"}
                </Badge>
              )}
            </div>
          </div>
        </GradientHeader>

        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <Link href="/admin/dashboard">
              <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <PageTitle title="Connection Status" />
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={isFetching}
            data-testid="button-refresh-health"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isFetching ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>

        {isLoading && (
          <GlassCard>
            <div className="flex items-center justify-center py-12">
              <RefreshCw className="w-6 h-6 animate-spin text-muted-foreground" />
              <span className="ml-3 text-muted-foreground">Checking database connection...</span>
            </div>
          </GlassCard>
        )}

        {isError && (
          <GlassCard>
            <div className="flex items-center gap-3 text-red-500 dark:text-red-400" data-testid="text-db-error">
              <XCircle className="w-5 h-5" />
              <div>
                <p className="font-medium">Connection Failed</p>
                <p className="text-sm text-muted-foreground">
                  {error instanceof Error ? error.message : "Unable to reach the database"}
                </p>
              </div>
            </div>
          </GlassCard>
        )}

        {data && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <GlassCard>
                <div className="flex items-center gap-3" data-testid="stat-latency">
                  <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                    <Clock className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Latency</p>
                    <p className="text-lg font-semibold">{data.latencyMs}ms</p>
                  </div>
                </div>
              </GlassCard>

              <GlassCard>
                <div className="flex items-center gap-3" data-testid="stat-tables">
                  <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                    <HardDrive className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Tables</p>
                    <p className="text-lg font-semibold">{data.tables.length}</p>
                  </div>
                </div>
              </GlassCard>

              <GlassCard>
                <div className="flex items-center gap-3" data-testid="stat-timestamp">
                  <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                    <Server className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Last Check</p>
                    <p className="text-sm font-semibold">
                      {new Date(data.timestamp).toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              </GlassCard>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Section title="Prisma ORM">
                <GlassCard>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-3" data-testid="prisma-connection-status">
                      <span className="text-sm">Connection</span>
                      <Badge variant={data.prisma.connected ? "default" : "destructive"}>
                        {data.prisma.connected ? "Connected" : "Disconnected"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between gap-3" data-testid="prisma-user-count">
                      <span className="text-sm">Prisma Users</span>
                      <span className="text-sm font-medium">{data.prisma.userCount}</span>
                    </div>
                    <div className="flex items-center justify-between gap-3" data-testid="prisma-audit-count">
                      <span className="text-sm">Audit Logs</span>
                      <span className="text-sm font-medium">{data.prisma.auditLogCount}</span>
                    </div>
                  </div>
                </GlassCard>
              </Section>

              <Section title="Drizzle ORM">
                <GlassCard>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-3" data-testid="drizzle-connection-status">
                      <span className="text-sm">Connection</span>
                      <Badge variant={data.drizzle.connected ? "default" : "destructive"}>
                        {data.drizzle.connected ? "Connected" : "Disconnected"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between gap-3" data-testid="drizzle-user-count">
                      <span className="text-sm">Users</span>
                      <span className="text-sm font-medium">{data.drizzle.userCount}</span>
                    </div>
                    <div className="flex items-center justify-between gap-3" data-testid="drizzle-asset-count">
                      <span className="text-sm">Assets</span>
                      <span className="text-sm font-medium">{data.drizzle.assetCount}</span>
                    </div>
                  </div>
                </GlassCard>
              </Section>
            </div>

            <Section title="Database Tables">
              <GlassCard>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2" data-testid="table-list">
                  {data.tables.map((table) => (
                    <div
                      key={table}
                      className="flex items-center gap-2 px-3 py-2 rounded-md bg-muted/50"
                      data-testid={`table-item-${table}`}
                    >
                      <Database className="w-3 h-3 text-muted-foreground" />
                      <span className="text-sm font-mono truncate">{table}</span>
                    </div>
                  ))}
                </div>
              </GlassCard>
            </Section>
          </div>
        )}
      </div>
    </RoleLayout>
  );
}
