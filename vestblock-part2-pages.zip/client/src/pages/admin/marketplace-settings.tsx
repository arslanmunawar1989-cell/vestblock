import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Globe, Eye, EyeOff, ArrowLeft,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Link } from "wouter";
interface CountrySetting {
  id: string | null;
  countryCode: string;
  name: string;
  isVisible: boolean;
  displayOrder: number;
}


export default function AdminMarketplaceSettings() {
  const { toast } = useToast();

  const { data: countries, isLoading } = useQuery<CountrySetting[]>({
    queryKey: ["/api/admin/marketplace/countries"],
  });

  const toggleMutation = useMutation({
    mutationFn: async ({ countryCode, isVisible }: { countryCode: string; isVisible: boolean }) => {
      const res = await apiRequest("PATCH", `/api/admin/marketplace/countries/${countryCode}`, { isVisible });
      return res.json();
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/marketplace/countries"] });
      queryClient.invalidateQueries({ queryKey: ["/api/marketplace/countries"] });
      toast({
        title: variables.isVisible ? "Country Visible" : "Country Hidden",
        description: `Marketplace visibility updated successfully.`,
      });
    },
    onError: (err: any) => {
      toast({ title: "Failed", description: err.message, variant: "destructive" });
    },
  });

  const visibleCount = countries?.filter(c => c.isVisible).length || 0;
  const hiddenCount = countries?.filter(c => !c.isVisible).length || 0;

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Marketplace Settings"
          description="Control which country marketplaces are visible to investors"
        />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Globe className="w-4 h-4 text-primary" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Total Markets</p>
                <p className="text-lg font-bold" data-testid="text-total-markets">{countries?.length || 0}</p>
              </div>
            </div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-md bg-emerald-500/10 flex items-center justify-center flex-shrink-0">
                <Eye className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Visible</p>
                <p className="text-lg font-bold" data-testid="text-visible-markets">{visibleCount}</p>
              </div>
            </div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-md bg-muted flex items-center justify-center flex-shrink-0">
                <EyeOff className="w-4 h-4 text-muted-foreground" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Hidden</p>
                <p className="text-lg font-bold" data-testid="text-hidden-markets">{hiddenCount}</p>
              </div>
            </div>
          </Card>
        </div>

        {isLoading ? (
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-16 rounded-md" />)}
          </div>
        ) : (
          <div className="space-y-3">
            {countries?.map(country => (
              <Card key={country.countryCode} className="p-4" data-testid={`country-setting-${country.countryCode}`}>
                <div className="flex items-center justify-between gap-4 flex-wrap">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center flex-shrink-0">
                      <Globe className="w-5 h-5 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold" data-testid={`country-name-${country.countryCode}`}>
                        {country.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Code: {country.countryCode}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge
                      variant={country.isVisible ? "default" : "outline"}
                      data-testid={`country-status-${country.countryCode}`}
                    >
                      {country.isVisible ? "Visible" : "Hidden"}
                    </Badge>
                    <Switch
                      checked={country.isVisible}
                      onCheckedChange={(checked) => {
                        toggleMutation.mutate({ countryCode: country.countryCode, isVisible: checked });
                      }}
                      disabled={toggleMutation.isPending}
                      data-testid={`switch-country-${country.countryCode}`}
                    />
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {!isLoading && countries?.length === 0 && (
          <Card className="p-8 text-center">
            <Globe className="w-10 h-10 mx-auto mb-3 text-muted-foreground opacity-50" />
            <p className="text-sm text-muted-foreground">No marketplace countries configured.</p>
          </Card>
        )}
      </div>
    </RoleLayout>
  );
}
