import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate } from "@/lib/format";
import { SUPPORTED_CURRENCIES } from "@/lib/currencies";
import type { Asset, PropertyAcquisition, PropertyUnit, PropertyUnitLedger } from "@shared/schema";
import {
  Building2,
  FileText,
  Calculator,
  PlusCircle,
  Pencil,
  Landmark,
  Hammer,
  Armchair,
  Handshake,
  ShieldAlert,
  Receipt,
  Stamp,
  Scale,
  Layers,
  BookOpen,
  ArrowUpRight,
  ArrowDownRight,
  Coins,
  TrendingUp,
  Users, ArrowLeft,
} from "lucide-react";

interface AcquisitionFormData {
  currency: string;
  purchasePrice: string;
  stampDuty: string;
  registrationFee: string;
  legalCost: string;
  renovationCost: string;
  furnitureCost: string;
  brokerage: string;
  contingencyPercent: string;
  otherCosts: string;
  otherCostsDescription: string;
  notes: string;
}

const COST_LINE_ITEMS = [
  { key: "purchasePrice", label: "Purchase Price", icon: Building2, required: true, hint: "Agreed property purchase price" },
  { key: "stampDuty", label: "Stamp Duty", icon: Stamp, required: false, hint: "Government stamp duty / transfer tax" },
  { key: "registrationFee", label: "Registration Fee", icon: Landmark, required: false, hint: "Land registry / property registration" },
  { key: "legalCost", label: "Legal Cost", icon: Scale, required: false, hint: "Legal counsel, due diligence, conveyancing" },
  { key: "renovationCost", label: "Renovation Cost", icon: Hammer, required: false, hint: "Fit-out, refurbishment, repairs" },
  { key: "furnitureCost", label: "Furniture Cost", icon: Armchair, required: false, hint: "FF&E if rental-ready" },
  { key: "brokerage", label: "Brokerage", icon: Handshake, required: false, hint: "Agent / broker commission" },
  { key: "otherCosts", label: "Other Costs", icon: Receipt, required: false, hint: "Insurance, inspection, misc" },
];

const defaultForm: AcquisitionFormData = {
  currency: "AED",
  purchasePrice: "",
  stampDuty: "0",
  registrationFee: "0",
  legalCost: "0",
  renovationCost: "0",
  furnitureCost: "0",
  brokerage: "0",
  contingencyPercent: "5",
  otherCosts: "0",
  otherCostsDescription: "",
  notes: "",
};

function computePreview(form: AcquisitionFormData, totalSupply?: string) {
  const vals = {
    purchasePrice: parseFloat(form.purchasePrice || "0"),
    stampDuty: parseFloat(form.stampDuty || "0"),
    registrationFee: parseFloat(form.registrationFee || "0"),
    legalCost: parseFloat(form.legalCost || "0"),
    renovationCost: parseFloat(form.renovationCost || "0"),
    furnitureCost: parseFloat(form.furnitureCost || "0"),
    brokerage: parseFloat(form.brokerage || "0"),
    otherCosts: parseFloat(form.otherCosts || "0"),
  };
  const contingencyPercent = parseFloat(form.contingencyPercent || "5");
  const baseCost = Object.values(vals).reduce((s, v) => s + v, 0);
  const contingencyAmount = parseFloat((baseCost * contingencyPercent / 100).toFixed(2));
  const total = parseFloat((baseCost + contingencyAmount).toFixed(2));
  const supply = parseFloat(totalSupply || "0");
  const costPerToken = supply > 0 ? total / supply : 0;
  return { baseCost, contingencyAmount, total, costPerToken, ...vals };
}

function formatCurrency(amount: number | string, currency: string = "") {
  const n = typeof amount === "string" ? parseFloat(amount) : amount;
  if (isNaN(n)) return "0.00";
  return n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + (currency ? ` ${currency}` : "");
}

function formatUnits(amount: number | string, decimals: number = 2) {
  const n = typeof amount === "string" ? parseFloat(amount) : amount;
  if (isNaN(n)) return "0";
  return n.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: decimals });
}

export default function PropertyAcquisitionPage() {
  const { toast } = useToast();
  const [selectedAssetId, setSelectedAssetId] = useState<string>("");
  const [showFormDialog, setShowFormDialog] = useState(false);
  const [showUnitDialog, setShowUnitDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [form, setForm] = useState<AcquisitionFormData>({ ...defaultForm });
  const [unitForm, setUnitForm] = useState({ totalUnits: "", unitDecimals: 2 });

  const { data: assets, isLoading: assetsLoading } = useQuery<Asset[]>({
    queryKey: ["/api/assets"],
  });

  const { data: allAcquisitions, isLoading: acquisitionsLoading } = useQuery<PropertyAcquisition[]>({
    queryKey: ["/api/admin/property-acquisitions"],
  });

  const { data: allUnits } = useQuery<PropertyUnit[]>({
    queryKey: ["/api/admin/property-units"],
  });

  const { data: acquisition } = useQuery<PropertyAcquisition | null>({
    queryKey: ["/api/assets", selectedAssetId, "acquisition"],
    queryFn: async () => {
      const res = await fetch(`/api/assets/${selectedAssetId}/acquisition`, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
    enabled: !!selectedAssetId,
  });

  const { data: propertyUnit } = useQuery<PropertyUnit | null>({
    queryKey: ["/api/assets", selectedAssetId, "units"],
    queryFn: async () => {
      const res = await fetch(`/api/assets/${selectedAssetId}/units`, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
    enabled: !!selectedAssetId,
  });

  const { data: unitLedger } = useQuery<PropertyUnitLedger[]>({
    queryKey: ["/api/assets", selectedAssetId, "units", "ledger"],
    queryFn: async () => {
      const res = await fetch(`/api/assets/${selectedAssetId}/units/ledger`, { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!selectedAssetId && !!propertyUnit,
  });

  const { data: ownershipData } = useQuery<{
    property: { name: string; symbol: string };
    unitConfig: { totalUnits: string; unitPrice: string; currency: string; unitsIssued: string };
    summary: { totalOwners: number; totalAllocated: string; totalUnallocated: string; percentAllocated: string };
    owners: Array<{ userId: string; username: string; fullName: string; unitsOwned: string; percentageOwned: string; currentValue: string }>;
  }>({
    queryKey: ["/api/admin/properties", selectedAssetId, "ownership"],
    queryFn: async () => {
      const res = await fetch(`/api/admin/properties/${selectedAssetId}/ownership`, { credentials: "include" });
      if (!res.ok) return null;
      return res.json();
    },
    enabled: !!selectedAssetId && !!propertyUnit,
  });

  const createMutation = useMutation({
    mutationFn: async (data: AcquisitionFormData & { assetId: string }) => {
      const res = await apiRequest("POST", `/api/assets/${data.assetId}/acquisition`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/assets", selectedAssetId, "acquisition"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/property-acquisitions"] });
      setShowFormDialog(false);
      toast({ title: "Acquisition Data Saved", description: "Property acquisition cost structure has been recorded." });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to save", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: AcquisitionFormData & { assetId: string }) => {
      const res = await apiRequest("PATCH", `/api/assets/${data.assetId}/acquisition`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/assets", selectedAssetId, "acquisition"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/property-acquisitions"] });
      setShowFormDialog(false);
      toast({ title: "Acquisition Data Updated" });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to update", variant: "destructive" });
    },
  });

  const createUnitMutation = useMutation({
    mutationFn: async (data: { assetId: string; totalUnits: string; unitDecimals: number }) => {
      const res = await apiRequest("POST", `/api/assets/${data.assetId}/units`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/assets", selectedAssetId, "units"] });
      queryClient.invalidateQueries({ queryKey: ["/api/assets", selectedAssetId, "units", "ledger"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/property-units"] });
      setShowUnitDialog(false);
      toast({ title: "Units Created", description: "Property units have been minted and recorded in the ledger." });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to create units", variant: "destructive" });
    },
  });

  const updateUnitMutation = useMutation({
    mutationFn: async (data: { assetId: string; status?: string; totalUnits?: string; unitDecimals?: number }) => {
      const res = await apiRequest("PATCH", `/api/assets/${data.assetId}/units`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/assets", selectedAssetId, "units"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/property-units"] });
      toast({ title: "Unit Configuration Updated" });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to update", variant: "destructive" });
    },
  });

  function handleOpenCreate(assetId: string, asset: Asset) {
    setSelectedAssetId(assetId);
    setIsEditing(false);
    setForm({ ...defaultForm, currency: asset.baseCurrency || "AED" });
    setShowFormDialog(true);
  }

  function handleOpenEdit(assetId: string, acq: PropertyAcquisition) {
    setSelectedAssetId(assetId);
    setIsEditing(true);
    setForm({
      currency: acq.currency,
      purchasePrice: acq.purchasePrice,
      stampDuty: acq.stampDuty,
      registrationFee: acq.registrationFee,
      legalCost: acq.legalCost,
      renovationCost: acq.renovationCost,
      furnitureCost: acq.furnitureCost,
      brokerage: acq.brokerage,
      contingencyPercent: acq.contingencyPercent,
      otherCosts: acq.otherCosts,
      otherCostsDescription: acq.otherCostsDescription || "",
      notes: acq.notes || "",
    });
    setShowFormDialog(true);
  }

  function handleSubmit() {
    if (!selectedAssetId) return;
    if (!form.purchasePrice || parseFloat(form.purchasePrice) <= 0) {
      toast({ title: "Validation Error", description: "Purchase price is required and must be positive", variant: "destructive" });
      return;
    }
    const data = { ...form, assetId: selectedAssetId };
    if (isEditing) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  }

  function handleOpenUnitCreate(assetId: string) {
    setSelectedAssetId(assetId);
    setUnitForm({ totalUnits: "", unitDecimals: 2 });
    setShowUnitDialog(true);
  }

  function handleUnitSubmit() {
    if (!selectedAssetId) return;
    if (!unitForm.totalUnits || parseFloat(unitForm.totalUnits) <= 0) {
      toast({ title: "Validation Error", description: "Total units must be a positive number", variant: "destructive" });
      return;
    }
    createUnitMutation.mutate({
      assetId: selectedAssetId,
      totalUnits: unitForm.totalUnits,
      unitDecimals: unitForm.unitDecimals,
    });
  }

  function updateField(key: keyof AcquisitionFormData, value: string) {
    setForm(prev => ({ ...prev, [key]: value }));
  }

  const selectedAsset = assets?.find(a => a.id === selectedAssetId);
  const preview = computePreview(form, selectedAsset?.totalSupply);

  const acquisitionMap = new Map<string, PropertyAcquisition>();
  (allAcquisitions || []).forEach(a => acquisitionMap.set(a.assetId, a));

  const unitMap = new Map<string, PropertyUnit>();
  (allUnits || []).forEach(u => unitMap.set(u.assetId, u));

  const isLoading = assetsLoading || acquisitionsLoading;
  const isSaving = createMutation.isPending || updateMutation.isPending;

  const unitPreviewPrice = unitForm.totalUnits && acquisition
    ? parseFloat(acquisition.totalAcquisitionCost) / parseFloat(unitForm.totalUnits || "1")
    : 0;

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Property Acquisition & Units"
          description="Define acquisition costs and create units for each property. Total Capital Required becomes the tokenized amount."
        />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Properties</CardTitle>
              <Building2 className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold" data-testid="text-total-properties">{(assets || []).length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Capital Modeled</CardTitle>
              <Calculator className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold" data-testid="text-modeled-count">{(allAcquisitions || []).length}</p>
              <p className="text-xs text-muted-foreground">of {(assets || []).length} properties</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Units Created</CardTitle>
              <Layers className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold" data-testid="text-units-count">{(allUnits || []).length}</p>
              <p className="text-xs text-muted-foreground">of {(allAcquisitions || []).length} modeled</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Setup</CardTitle>
              <ShieldAlert className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold" data-testid="text-pending-count">{(assets || []).length - (allAcquisitions || []).length}</p>
              <p className="text-xs text-muted-foreground">Need cost structure</p>
            </CardContent>
          </Card>
        </div>

        <Section title="Properties" description="Select a property to view or define its acquisition cost structure and create units">
          {isLoading ? (
            <div className="space-y-2">
              {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-20 rounded-md" />)}
            </div>
          ) : !assets || assets.length === 0 ? (
            <GlassCard>
              <div className="text-center py-8 text-muted-foreground">
                <Building2 className="w-10 h-10 mx-auto mb-3 opacity-50" />
                <p className="text-sm">No properties found</p>
                <p className="text-xs mt-1">Properties must be created before modeling acquisition costs.</p>
              </div>
            </GlassCard>
          ) : (
            <div className="space-y-2">
              {assets.map(asset => {
                const acq = acquisitionMap.get(asset.id);
                const unit = unitMap.get(asset.id);
                const hasAcquisition = !!acq;
                const hasUnits = !!unit;
                return (
                  <GlassCard key={asset.id} padding="sm" data-testid={`property-row-${asset.id}`}>
                    <div className="flex items-center justify-between gap-3 flex-wrap">
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-9 h-9 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <Building2 className="w-4 h-4 text-primary" />
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-sm font-semibold" data-testid={`text-property-name-${asset.id}`}>{asset.name}</span>
                            <Badge variant="outline" className="no-default-hover-elevate">{asset.symbol}</Badge>
                            {hasAcquisition ? (
                              <Badge variant="default" className="no-default-hover-elevate">Capital Modeled</Badge>
                            ) : (
                              <Badge variant="secondary" className="no-default-hover-elevate">No Acquisition Data</Badge>
                            )}
                            {hasUnits && (
                              <Badge variant="default" className="no-default-hover-elevate">
                                {formatUnits(unit!.totalUnits)} Units
                              </Badge>
                            )}
                          </div>
                          <div className="flex gap-x-3 text-xs text-muted-foreground mt-0.5 flex-wrap">
                            <span>{asset.location || asset.country}</span>
                            <span>{asset.baseCurrency}</span>
                            {hasAcquisition && (
                              <span>Capital: <span className="font-medium text-foreground">{formatCurrency(acq!.totalAcquisitionCost, acq!.currency)}</span></span>
                            )}
                            {hasUnits && (
                              <span>Unit Price: <span className="font-medium text-foreground">{formatCurrency(unit!.unitPrice, unit!.currency)}</span></span>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-1.5 flex-wrap">
                        {hasAcquisition ? (
                          <>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => { setSelectedAssetId(asset.id); }}
                              data-testid={`button-view-acquisition-${asset.id}`}
                            >
                              <FileText className="w-3.5 h-3.5 mr-1" />
                              View
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleOpenEdit(asset.id, acq!)}
                              data-testid={`button-edit-acquisition-${asset.id}`}
                            >
                              <Pencil className="w-3.5 h-3.5 mr-1" />
                              Edit
                            </Button>
                            {!hasUnits && (
                              <Button
                                size="sm"
                                onClick={() => handleOpenUnitCreate(asset.id)}
                                data-testid={`button-create-units-${asset.id}`}
                              >
                                <Layers className="w-3.5 h-3.5 mr-1" />
                                Create Units
                              </Button>
                            )}
                            {hasUnits && asset.vehicleId && (
                              <Link href="/admin/offerings">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  data-testid={`button-create-offering-${asset.id}`}
                                >
                                  <TrendingUp className="w-3.5 h-3.5 mr-1" />
                                  Create Offering
                                </Button>
                              </Link>
                            )}
                          </>
                        ) : (
                          <Button
                            size="sm"
                            onClick={() => handleOpenCreate(asset.id, asset)}
                            data-testid={`button-create-acquisition-${asset.id}`}
                          >
                            <PlusCircle className="w-3.5 h-3.5 mr-1" />
                            Model Acquisition
                          </Button>
                        )}
                      </div>
                    </div>

                    {selectedAssetId === asset.id && (hasAcquisition || hasUnits) && !showFormDialog && !showUnitDialog && (
                      <div className="mt-4 pt-4 border-t space-y-4" data-testid={`acquisition-detail-${asset.id}`}>
                        {hasAcquisition && <AcquisitionBreakdown acquisition={acq!} />}
                        {hasUnits && (
                          <UnitInfo
                            unit={unit!}
                            ledger={selectedAssetId === asset.id ? unitLedger || [] : []}
                            onActivate={() => updateUnitMutation.mutate({ assetId: asset.id, status: "active" })}
                            onFreeze={() => updateUnitMutation.mutate({ assetId: asset.id, status: "frozen" })}
                          />
                        )}
                        {hasUnits && ownershipData && ownershipData.owners && ownershipData.owners.length > 0 && (
                          <OwnershipSnapshot data={ownershipData} />
                        )}
                      </div>
                    )}
                  </GlassCard>
                );
              })}
            </div>
          )}
        </Section>
      </div>

      <Dialog open={showFormDialog} onOpenChange={(open) => { if (!open) setShowFormDialog(false); }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" data-testid="acquisition-form-dialog">
          <DialogHeader>
            <DialogTitle>{isEditing ? "Edit" : "Model"} Acquisition Costs</DialogTitle>
            <DialogDescription>
              {selectedAsset ? `${selectedAsset.name} (${selectedAsset.symbol})` : "Property"} — Enter all cost line items for this property acquisition.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Currency</label>
              <Select value={form.currency} onValueChange={(v) => updateField("currency", v)}>
                <SelectTrigger data-testid="select-acq-currency">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[...SUPPORTED_CURRENCIES].map(c => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3">
              <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Cost Line Items</h4>
              {COST_LINE_ITEMS.map(item => {
                const Icon = item.icon;
                return (
                  <div key={item.key}>
                    <label className="text-sm font-medium mb-1 flex items-center gap-1.5">
                      <Icon className="w-3.5 h-3.5 text-muted-foreground" />
                      {item.label}
                      {item.required && <span className="text-destructive">*</span>}
                    </label>
                    <Input
                      type="number"
                      step="0.01"
                      min="0"
                      value={form[item.key as keyof AcquisitionFormData]}
                      onChange={(e) => updateField(item.key as keyof AcquisitionFormData, e.target.value)}
                      placeholder={item.hint}
                      data-testid={`input-acq-${item.key}`}
                    />
                  </div>
                );
              })}

              {form.otherCosts && parseFloat(form.otherCosts) > 0 && (
                <div>
                  <label className="text-sm font-medium mb-1 block">Other Costs Description</label>
                  <Input
                    value={form.otherCostsDescription}
                    onChange={(e) => updateField("otherCostsDescription", e.target.value)}
                    placeholder="Describe other costs"
                    data-testid="input-acq-otherCostsDescription"
                  />
                </div>
              )}
            </div>

            <div className="space-y-3">
              <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Contingency Reserve</h4>
              <div>
                <label className="text-sm font-medium mb-1 flex items-center gap-1.5">
                  <ShieldAlert className="w-3.5 h-3.5 text-muted-foreground" />
                  Contingency Percent (%)
                </label>
                <Input
                  type="number"
                  step="0.5"
                  min="0"
                  max="25"
                  value={form.contingencyPercent}
                  onChange={(e) => updateField("contingencyPercent", e.target.value)}
                  placeholder="5-10% recommended"
                  data-testid="input-acq-contingencyPercent"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Applied to base cost. Recommended: 5-10% for standard, up to 15% for off-plan.
                </p>
              </div>
            </div>

            <div>
              <label className="text-sm font-medium mb-1 block">Notes (optional)</label>
              <Textarea
                value={form.notes}
                onChange={(e) => updateField("notes", e.target.value)}
                placeholder="Additional context about this acquisition..."
                data-testid="input-acq-notes"
              />
            </div>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Capital Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-1.5">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Purchase Price</span>
                  <span className="font-medium" data-testid="text-preview-purchase">{formatCurrency(preview.purchasePrice, form.currency)}</span>
                </div>
                {preview.baseCost - preview.purchasePrice > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">All Fees & Costs</span>
                    <span className="font-medium" data-testid="text-preview-fees">{formatCurrency(preview.baseCost - preview.purchasePrice, form.currency)}</span>
                  </div>
                )}
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Contingency Reserve ({form.contingencyPercent}%)</span>
                  <span className="font-medium" data-testid="text-preview-contingency">{formatCurrency(preview.contingencyAmount, form.currency)}</span>
                </div>
                <div className="flex justify-between text-sm font-bold border-t pt-2 mt-2">
                  <span>Total Capital Required</span>
                  <span data-testid="text-preview-total">{formatCurrency(preview.total, form.currency)}</span>
                </div>
                <p className="text-xs text-muted-foreground" data-testid="text-tokenization-note">This is the amount that gets tokenized into units.</p>
              </CardContent>
            </Card>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowFormDialog(false)}>Cancel</Button>
              <Button onClick={handleSubmit} disabled={isSaving} data-testid="button-submit-acquisition">
                {isSaving ? "Saving..." : (isEditing ? "Update Acquisition" : "Save Acquisition")}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showUnitDialog} onOpenChange={(open) => { if (!open) setShowUnitDialog(false); }}>
        <DialogContent className="max-w-md" data-testid="unit-form-dialog">
          <DialogHeader>
            <DialogTitle>Create Property Units</DialogTitle>
            <DialogDescription>
              {selectedAsset ? `${selectedAsset.name} (${selectedAsset.symbol})` : "Property"} — Define how many units to create. Unit price is automatically calculated from Total Capital Required.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {acquisition && (
              <Card>
                <CardContent className="pt-4 pb-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Total Capital Required</span>
                    <span className="font-bold">{formatCurrency(acquisition.totalAcquisitionCost, acquisition.currency)}</span>
                  </div>
                </CardContent>
              </Card>
            )}

            <div>
              <label className="text-sm font-medium mb-1.5 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-muted-foreground" />
                Total Units <span className="text-destructive">*</span>
              </label>
              <Input
                type="number"
                step="1"
                min="1"
                value={unitForm.totalUnits}
                onChange={(e) => setUnitForm(prev => ({ ...prev, totalUnits: e.target.value }))}
                placeholder="e.g. 100"
                data-testid="input-unit-totalUnits"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Number of units to divide this property into.
              </p>
            </div>

            <div>
              <label className="text-sm font-medium mb-1.5 flex items-center gap-1.5">
                <Coins className="w-3.5 h-3.5 text-muted-foreground" />
                Fractional Decimals
              </label>
              <Select
                value={unitForm.unitDecimals.toString()}
                onValueChange={(v) => setUnitForm(prev => ({ ...prev, unitDecimals: parseInt(v) }))}
              >
                <SelectTrigger data-testid="select-unit-decimals">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">0 — Whole units only</SelectItem>
                  <SelectItem value="1">1 — e.g. 0.5 units</SelectItem>
                  <SelectItem value="2">2 — e.g. 0.25 units</SelectItem>
                  <SelectItem value="3">3 — e.g. 0.125 units</SelectItem>
                  <SelectItem value="4">4 — e.g. 0.0001 units</SelectItem>
                  <SelectItem value="6">6 — High precision</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground mt-1">
                Allows investors to buy fractional units (e.g. 0.25 of a unit).
              </p>
            </div>

            {unitForm.totalUnits && parseFloat(unitForm.totalUnits) > 0 && acquisition && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">Unit Preview</CardTitle>
                </CardHeader>
                <CardContent className="space-y-1.5">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Total Units</span>
                    <span className="font-medium" data-testid="text-unit-preview-total">{formatUnits(unitForm.totalUnits)}</span>
                  </div>
                  <div className="flex justify-between text-sm font-bold border-t pt-1.5">
                    <span>Unit Price</span>
                    <span data-testid="text-unit-preview-price">{formatCurrency(unitPreviewPrice, acquisition.currency)}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {formatCurrency(acquisition.totalAcquisitionCost, acquisition.currency)} / {formatUnits(unitForm.totalUnits)} units = {formatCurrency(unitPreviewPrice, acquisition.currency)} per unit
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Min fractional purchase: {(1 / Math.pow(10, unitForm.unitDecimals)).toFixed(unitForm.unitDecimals)} units = {formatCurrency(unitPreviewPrice / Math.pow(10, unitForm.unitDecimals), acquisition.currency)}
                  </p>
                </CardContent>
              </Card>
            )}

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowUnitDialog(false)}>Cancel</Button>
              <Button onClick={handleUnitSubmit} disabled={createUnitMutation.isPending} data-testid="button-submit-units">
                {createUnitMutation.isPending ? "Creating..." : "Create Units"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </RoleLayout>
  );
}

function AcquisitionBreakdown({ acquisition }: { acquisition: PropertyAcquisition }) {
  const items = [
    { label: "Purchase Price", value: acquisition.purchasePrice, icon: Building2 },
    { label: "Stamp Duty", value: acquisition.stampDuty, icon: Stamp },
    { label: "Registration Fee", value: acquisition.registrationFee, icon: Landmark },
    { label: "Legal Cost", value: acquisition.legalCost, icon: Scale },
    { label: "Renovation Cost", value: acquisition.renovationCost, icon: Hammer },
    { label: "Furniture Cost", value: acquisition.furnitureCost, icon: Armchair },
    { label: "Brokerage", value: acquisition.brokerage, icon: Handshake },
    { label: "Other Costs", value: acquisition.otherCosts, icon: Receipt },
  ].filter(item => parseFloat(item.value) > 0);

  return (
    <div className="space-y-3">
      <h4 className="text-sm font-semibold">Capital Breakdown</h4>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        {items.map(({ label, value, icon: Icon }) => (
          <div key={label} className="flex items-start gap-2">
            <Icon className="w-3.5 h-3.5 text-muted-foreground mt-0.5 shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">{label}</p>
              <p className="text-sm font-medium">{formatCurrency(value, acquisition.currency)}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-2 pt-2 border-t">
        <div>
          <p className="text-xs text-muted-foreground">Contingency Reserve ({acquisition.contingencyPercent}%)</p>
          <p className="text-sm font-medium">{formatCurrency(acquisition.contingencyAmount, acquisition.currency)}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">Total Capital Required</p>
          <p className="text-sm font-bold" data-testid="text-total-acquisition-cost">{formatCurrency(acquisition.totalAcquisitionCost, acquisition.currency)}</p>
          <p className="text-xs text-muted-foreground mt-0.5">Amount tokenized</p>
        </div>
      </div>

      {acquisition.otherCostsDescription && (
        <p className="text-xs text-muted-foreground italic">Other costs: {acquisition.otherCostsDescription}</p>
      )}
      {acquisition.notes && (
        <p className="text-xs text-muted-foreground italic">Notes: {acquisition.notes}</p>
      )}
      <p className="text-xs text-muted-foreground">Last updated: {formatDate(acquisition.updatedAt, "long")}</p>
    </div>
  );
}

function UnitInfo({
  unit,
  ledger,
  onActivate,
  onFreeze,
}: {
  unit: PropertyUnit;
  ledger: PropertyUnitLedger[];
  onActivate: () => void;
  onFreeze: () => void;
}) {
  const unitsAvailable = parseFloat(unit.totalUnits) - parseFloat(unit.unitsIssued);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <h4 className="text-sm font-semibold flex items-center gap-1.5">
          <Layers className="w-4 h-4" />
          Unit Configuration
        </h4>
        <div className="flex gap-1.5 flex-wrap">
          <Badge
            variant={unit.status === "active" ? "default" : unit.status === "frozen" ? "destructive" : "secondary"}
            className="no-default-hover-elevate"
          >
            {unit.status}
          </Badge>
          {unit.status === "draft" && (
            <Button size="sm" variant="outline" onClick={onActivate} data-testid="button-activate-units">
              Activate
            </Button>
          )}
          {unit.status === "active" && (
            <Button size="sm" variant="outline" onClick={onFreeze} data-testid="button-freeze-units">
              Freeze
            </Button>
          )}
          {unit.status === "frozen" && (
            <Button size="sm" variant="outline" onClick={onActivate} data-testid="button-unfreeze-units">
              Unfreeze
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div>
          <p className="text-xs text-muted-foreground">Total Units</p>
          <p className="text-sm font-bold" data-testid="text-total-units">{formatUnits(unit.totalUnits, unit.unitDecimals)}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">Unit Price</p>
          <p className="text-sm font-bold" data-testid="text-unit-price">{formatCurrency(unit.unitPrice, unit.currency)}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">Units Issued</p>
          <p className="text-sm font-medium" data-testid="text-units-issued">{formatUnits(unit.unitsIssued, unit.unitDecimals)}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">Units Available</p>
          <p className="text-sm font-medium" data-testid="text-units-available">{formatUnits(unitsAvailable, unit.unitDecimals)}</p>
        </div>
      </div>

      <div className="text-xs text-muted-foreground">
        Fractional precision: {unit.unitDecimals} decimals (min purchase: {(1 / Math.pow(10, unit.unitDecimals)).toFixed(unit.unitDecimals)} units)
      </div>

      {ledger.length > 0 && (
        <div className="pt-2 border-t">
          <h5 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <BookOpen className="w-3.5 h-3.5" />
            Unit Ledger
          </h5>
          <div className="space-y-1.5">
            {ledger.map(entry => (
              <div key={entry.id} className="flex items-center justify-between text-xs gap-2 flex-wrap" data-testid={`ledger-entry-${entry.id}`}>
                <div className="flex items-center gap-1.5">
                  {entry.direction === "CREDIT" ? (
                    <ArrowDownRight className="w-3 h-3 text-green-600" />
                  ) : (
                    <ArrowUpRight className="w-3 h-3 text-red-600" />
                  )}
                  <span className="font-medium">{entry.direction}</span>
                  <span>{formatUnits(entry.units)} units</span>
                  <Badge variant="outline" className="no-default-hover-elevate text-[10px]">{entry.reason}</Badge>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <span>{formatCurrency(entry.totalValue, unit.currency)}</span>
                  <span>{formatDate(entry.createdAt, "short")}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function OwnershipSnapshot({ data }: {
  data: {
    unitConfig: { totalUnits: string; unitPrice: string; currency: string; unitsIssued: string };
    summary: { totalOwners: number; totalAllocated: string; totalUnallocated: string; percentAllocated: string };
    owners: Array<{ userId: string; username: string; fullName: string; unitsOwned: string; percentageOwned: string; currentValue: string }>;
  };
}) {
  const currency = data.unitConfig.currency;
  return (
    <div className="space-y-3 pt-2 border-t" data-testid="ownership-snapshot">
      <h4 className="text-sm font-semibold flex items-center gap-1.5">
        <Users className="w-4 h-4" />
        Ownership Cap Table
      </h4>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div>
          <p className="text-xs text-muted-foreground">Total Owners</p>
          <p className="text-sm font-bold" data-testid="text-total-owners">{data.summary.totalOwners}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">Units Allocated</p>
          <p className="text-sm font-bold" data-testid="text-allocated-units">{formatUnits(data.summary.totalAllocated)}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">Units Unallocated</p>
          <p className="text-sm font-medium" data-testid="text-unallocated-units">{formatUnits(data.summary.totalUnallocated)}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">Allocated %</p>
          <p className="text-sm font-bold" data-testid="text-allocated-pct">{data.summary.percentAllocated}%</p>
        </div>
      </div>

      <div className="space-y-1.5">
        {data.owners.map(owner => (
          <div key={owner.userId} className="flex items-center justify-between text-xs gap-2 flex-wrap p-2 rounded-md bg-muted/40" data-testid={`owner-row-${owner.userId}`}>
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <span className="text-[10px] font-semibold text-primary">
                  {(owner.fullName || owner.username).charAt(0).toUpperCase()}
                </span>
              </div>
              <div className="min-w-0">
                <span className="font-medium block truncate" data-testid={`text-owner-name-${owner.userId}`}>
                  {owner.fullName || owner.username}
                </span>
                <span className="text-muted-foreground">@{owner.username}</span>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="font-semibold" data-testid={`text-owner-units-${owner.userId}`}>
                  {formatUnits(owner.unitsOwned)} units
                </span>
                <span className="text-muted-foreground ml-1">({owner.percentageOwned}%)</span>
              </div>
              <span className="font-medium text-muted-foreground" data-testid={`text-owner-value-${owner.userId}`}>
                {formatCurrency(owner.currentValue, currency)}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
