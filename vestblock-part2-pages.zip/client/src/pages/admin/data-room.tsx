import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  FileText,
  Upload,
  Trash2,
  CheckCircle,
  Circle,
  FolderOpen,
  Plus,
  Eye,
  EyeOff,
  Archive,
  Loader2,
  AlertCircle, ArrowLeft,
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { DATA_ROOM_DOC_TYPE_LABELS, dataRoomDocTypeEnum, DATA_ROOM_ACCESS_TIER_LABELS, dataRoomAccessTierEnum, DEFAULT_TIER_THRESHOLDS } from "@shared/schema";
import type { DataRoomDocType, DataRoomAccessTier } from "@shared/schema";
import { Link } from "wouter";
interface DataRoomDoc {
  id: string;
  scope: string;
  assetId: string | null;
  offeringId: string | null;
  category: string;
  docType: string | null;
  checklistKey: string | null;
  title: string;
  description: string | null;
  fileName: string;
  fileSize: number | null;
  mimeType: string | null;
  url: string;
  status: string;
  accessTier: string;
  jurisdiction: string | null;
  uploadedBy: string;
  createdAt: string;
  updatedAt: string;
}

interface Asset {
  id: string;
  name: string;
  symbol: string;
  country: string;
  status: string;
}

interface ChecklistItemResponse {
  key: string;
  label: string;
  description: string;
  category: string;
  required: boolean;
  uploaded: boolean;
  document: DataRoomDoc | null;
}

interface ChecklistResponse {
  country: string;
  assetId: string;
  items: ChecklistItemResponse[];
  totalRequired: number;
  completedRequired: number;
  complete: boolean;
}

const CATEGORIES = ["legal", "financial", "valuation", "compliance", "corporate", "technical", "marketing", "other"];

function statusBadgeVariant(status: string) {
  switch (status) {
    case "live": return "default" as const;
    case "draft": return "outline" as const;
    case "archived": return "secondary" as const;
    default: return "outline" as const;
  }
}

interface TierThresholds {
  public: number;
  standard: number;
  qualified: number;
  confidential: number;
}

interface TierConfigResponse {
  assetId: string;
  assetName: string;
  thresholds: TierThresholds;
}

function AccessTierConfig({ assets }: { assets: Asset[] }) {
  const { toast } = useToast();
  const [selectedAsset, setSelectedAsset] = useState("");
  const [editing, setEditing] = useState<TierThresholds | null>(null);

  const { data: tierConfig, isLoading } = useQuery<TierConfigResponse>({
    queryKey: [`/api/data-room/assets/${selectedAsset}/tier-thresholds`],
    enabled: !!selectedAsset,
  });

  const saveMutation = useMutation({
    mutationFn: async (thresholds: TierThresholds) => {
      const res = await apiRequest("PUT", `/api/data-room/assets/${selectedAsset}/tier-thresholds`, { thresholds });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/data-room/assets/${selectedAsset}/tier-thresholds`] });
      setEditing(null);
      toast({ title: "Thresholds updated", description: "Access tier thresholds have been saved" });
    },
    onError: (err: Error) => {
      toast({ title: "Save failed", description: err.message, variant: "destructive" });
    },
  });

  const handleEdit = () => {
    if (tierConfig) {
      setEditing({ ...tierConfig.thresholds });
    }
  };

  const handleSave = () => {
    if (editing) saveMutation.mutate(editing);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3 flex-wrap">
        <Select value={selectedAsset} onValueChange={v => { setSelectedAsset(v); setEditing(null); }}>
          <SelectTrigger className="w-[250px]" data-testid="select-tier-asset">
            <SelectValue placeholder="Select an asset" />
          </SelectTrigger>
          <SelectContent>
            {assets.map(a => (
              <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {!selectedAsset ? (
        <Card className="p-8">
          <div className="flex flex-col items-center gap-3 text-center">
            <AlertCircle className="w-10 h-10 text-muted-foreground" />
            <p className="text-sm text-muted-foreground" data-testid="text-select-asset-prompt">
              Select an asset to configure data room access tier thresholds
            </p>
          </div>
        </Card>
      ) : isLoading ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
        </div>
      ) : tierConfig ? (
        <Card className="p-5" data-testid="card-tier-config">
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <div>
                <h3 className="font-semibold" data-testid="text-tier-asset-name">{tierConfig.assetName}</h3>
                <p className="text-sm text-muted-foreground">Minimum investment amount required for each access tier</p>
              </div>
              {!editing ? (
                <Button variant="outline" onClick={handleEdit} data-testid="button-edit-tiers">Edit Thresholds</Button>
              ) : (
                <div className="flex items-center gap-2">
                  <Button variant="outline" onClick={() => setEditing(null)} data-testid="button-cancel-tiers">Cancel</Button>
                  <Button onClick={handleSave} disabled={saveMutation.isPending} data-testid="button-save-tiers">
                    {saveMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                    Save
                  </Button>
                </div>
              )}
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              {(["public", "standard", "qualified", "confidential"] as const).map(tier => (
                <div key={tier} className="p-3 rounded-md bg-muted/50" data-testid={`tier-row-${tier}`}>
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <Badge variant="outline" className="text-xs">{DATA_ROOM_ACCESS_TIER_LABELS[tier]}</Badge>
                    </div>
                    {editing ? (
                      <Input
                        type="number"
                        min={0}
                        value={editing[tier]}
                        onChange={e => setEditing(prev => prev ? { ...prev, [tier]: Number(e.target.value) || 0 } : null)}
                        className="w-32 text-right"
                        data-testid={`input-tier-${tier}`}
                      />
                    ) : (
                      <p className="text-sm font-medium" data-testid={`text-tier-value-${tier}`}>
                        {tierConfig.thresholds[tier].toLocaleString()}
                      </p>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {tier === "public" ? "Visible to all investors in this property" :
                     tier === "standard" ? "Requires minimum investment to access" :
                     tier === "qualified" ? "Available to qualified investors" :
                     "Restricted to major investors only"}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </Card>
      ) : null}
    </div>
  );
}

export default function AdminDataRoom() {
  const { toast } = useToast();
  const [uploadOpen, setUploadOpen] = useState(false);
  const [filterAssetId, setFilterAssetId] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [selectedAssetForChecklist, setSelectedAssetForChecklist] = useState<string>("");

  const [form, setForm] = useState({
    scope: "asset" as "asset" | "offering",
    assetId: "",
    title: "",
    description: "",
    category: "legal",
    docType: "other" as string,
    accessTier: "public" as string,
    checklistKey: "",
    fileName: "",
    url: "",
    status: "draft",
  });

  const { data: docs = [], isLoading: docsLoading } = useQuery<DataRoomDoc[]>({
    queryKey: ["/api/data-room/all"],
  });

  const { data: assets = [] } = useQuery<Asset[]>({
    queryKey: ["/api/assets"],
  });

  const { data: checklist } = useQuery<ChecklistResponse>({
    queryKey: ["/api/data-room/checklist/asset", selectedAssetForChecklist],
    enabled: !!selectedAssetForChecklist,
  });

  const { data: formChecklist } = useQuery<ChecklistResponse>({
    queryKey: ["/api/data-room/checklist/asset", form.assetId],
    enabled: !!form.assetId && form.scope === "asset",
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/data-room/docs", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/data-room/all"] });
      queryClient.invalidateQueries({ queryKey: ["/api/data-room/checklist/asset"] });
      setUploadOpen(false);
      setForm({ scope: "asset", assetId: "", title: "", description: "", category: "legal", docType: "other", accessTier: "public", checklistKey: "", fileName: "", url: "", status: "draft" });
      toast({ title: "Document uploaded", description: "Data room document has been added" });
    },
    onError: (err: Error) => {
      toast({ title: "Upload failed", description: err.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      const res = await apiRequest("PATCH", `/api/data-room/docs/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/data-room/all"] });
      toast({ title: "Document updated" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/data-room/docs/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/data-room/all"] });
      queryClient.invalidateQueries({ queryKey: ["/api/data-room/checklist/asset"] });
      toast({ title: "Document deleted" });
    },
  });

  const filteredDocs = docs.filter(d => {
    if (filterAssetId !== "all" && d.assetId !== filterAssetId) return false;
    if (filterStatus !== "all" && d.status !== filterStatus) return false;
    return true;
  });

  const getAssetName = (id: string | null) => {
    if (!id) return "N/A";
    return assets.find(a => a.id === id)?.name || id.slice(0, 8);
  };

  const handleSubmit = () => {
    if (!form.title || !form.fileName || !form.url) {
      toast({ title: "Missing fields", description: "Title, file name, and URL are required", variant: "destructive" });
      return;
    }
    if (form.scope === "asset" && !form.assetId) {
      toast({ title: "Missing asset", description: "Please select an asset", variant: "destructive" });
      return;
    }
    createMutation.mutate({
      ...form,
      docType: form.docType || "other",
      accessTier: form.accessTier || "public",
      checklistKey: form.checklistKey && form.checklistKey !== "none" ? form.checklistKey : undefined,
      description: form.description || undefined,
    });
  };

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Data Room"
          description="Manage asset and offering data room documents with jurisdiction checklists"
          action={
            <Button onClick={() => setUploadOpen(true)} data-testid="button-upload-doc">
              <Plus className="w-4 h-4 mr-2" />
              Add Document
            </Button>
          }
        />
        </div>

        <Tabs defaultValue="documents">
          <TabsList data-testid="tabs-data-room">
            <TabsTrigger value="documents" data-testid="tab-documents">Documents</TabsTrigger>
            <TabsTrigger value="checklists" data-testid="tab-checklists">Jurisdiction Checklists</TabsTrigger>
            <TabsTrigger value="access-tiers" data-testid="tab-access-tiers">Access Tiers</TabsTrigger>
          </TabsList>

          <TabsContent value="documents" className="space-y-4 mt-4">
            <div className="flex items-center gap-3 flex-wrap">
              <Select value={filterAssetId} onValueChange={setFilterAssetId}>
                <SelectTrigger className="w-[200px]" data-testid="select-filter-asset">
                  <SelectValue placeholder="Filter by asset" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Assets</SelectItem>
                  {assets.map(a => (
                    <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-[150px]" data-testid="select-filter-status">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="live">Live</SelectItem>
                  <SelectItem value="archived">Archived</SelectItem>
                </SelectContent>
              </Select>
              <Badge variant="secondary">{filteredDocs.length} documents</Badge>
            </div>

            {docsLoading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
              </div>
            ) : filteredDocs.length === 0 ? (
              <Card className="p-8">
                <div className="flex flex-col items-center gap-3 text-center">
                  <FolderOpen className="w-10 h-10 text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">No data room documents found</p>
                  <Button variant="outline" onClick={() => setUploadOpen(true)} data-testid="button-upload-empty">
                    <Upload className="w-4 h-4 mr-2" />
                    Upload First Document
                  </Button>
                </div>
              </Card>
            ) : (
              <div className="space-y-2">
                {filteredDocs.map(doc => (
                  <Card key={doc.id} className="p-4" data-testid={`doc-row-${doc.id}`}>
                    <div className="flex items-center justify-between gap-3 flex-wrap">
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-9 h-9 rounded-md bg-muted flex items-center justify-center flex-shrink-0">
                          <FileText className="w-4 h-4 text-muted-foreground" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-medium truncate" data-testid={`doc-title-${doc.id}`}>{doc.title}</p>
                          <p className="text-xs text-muted-foreground truncate">
                            {getAssetName(doc.assetId)} &middot; {doc.fileName} &middot; {new Date(doc.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="outline" className="text-xs capitalize">{doc.category}</Badge>
                        {doc.docType && doc.docType !== "other" && (
                          <Badge variant="outline" className="text-xs">
                            {DATA_ROOM_DOC_TYPE_LABELS[doc.docType as DataRoomDocType] || doc.docType}
                          </Badge>
                        )}
                        <Badge variant={statusBadgeVariant(doc.status)} className="text-xs capitalize" data-testid={`doc-status-${doc.id}`}>
                          {doc.status}
                        </Badge>
                        <Badge variant="outline" className="text-xs" data-testid={`doc-tier-${doc.id}`}>
                          {DATA_ROOM_ACCESS_TIER_LABELS[(doc.accessTier as DataRoomAccessTier) || "public"]}
                        </Badge>
                        {doc.checklistKey && (
                          <Badge variant="secondary" className="text-xs">Checklist</Badge>
                        )}
                        {doc.status === "draft" && (
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => updateMutation.mutate({ id: doc.id, data: { status: "live" } })}
                            data-testid={`button-make-live-${doc.id}`}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                        )}
                        {doc.status === "live" && (
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => updateMutation.mutate({ id: doc.id, data: { status: "draft" } })}
                            data-testid={`button-make-draft-${doc.id}`}
                          >
                            <EyeOff className="w-4 h-4" />
                          </Button>
                        )}
                        {doc.status !== "archived" && (
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => updateMutation.mutate({ id: doc.id, data: { status: "archived" } })}
                            data-testid={`button-archive-${doc.id}`}
                          >
                            <Archive className="w-4 h-4" />
                          </Button>
                        )}
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => deleteMutation.mutate(doc.id)}
                          data-testid={`button-delete-${doc.id}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="checklists" className="space-y-4 mt-4">
            <Select value={selectedAssetForChecklist} onValueChange={setSelectedAssetForChecklist}>
              <SelectTrigger className="w-[250px]" data-testid="select-checklist-asset">
                <SelectValue placeholder="Select an asset to view checklist" />
              </SelectTrigger>
              <SelectContent>
                {assets.map(a => (
                  <SelectItem key={a.id} value={a.id}>{a.name} ({a.country})</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {!selectedAssetForChecklist ? (
              <Card className="p-8">
                <div className="flex flex-col items-center gap-3 text-center">
                  <AlertCircle className="w-10 h-10 text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">Select an asset to view its jurisdiction-specific document checklist</p>
                </div>
              </Card>
            ) : checklist ? (
              <Card className="p-5" data-testid="checklist-card">
                <div className="space-y-4">
                  <div className="flex items-center justify-between gap-3 flex-wrap">
                    <div>
                      <h3 className="font-semibold" data-testid="checklist-title">
                        {getAssetName(selectedAssetForChecklist)} — {checklist.country} Checklist
                      </h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        {checklist.completedRequired}/{checklist.totalRequired} required documents uploaded
                      </p>
                    </div>
                    <Badge variant={checklist.complete ? "default" : "outline"} data-testid="checklist-status">
                      {checklist.complete ? "Complete" : "Incomplete"}
                    </Badge>
                  </div>
                  <Progress value={checklist.totalRequired > 0 ? (checklist.completedRequired / checklist.totalRequired) * 100 : 0} className="h-2" data-testid="checklist-progress" />
                  <div className="space-y-2">
                    {checklist.items.map(item => (
                      <div key={item.key} className="flex items-start gap-3 p-3 rounded-md bg-muted/50" data-testid={`checklist-item-${item.key}`}>
                        {item.uploaded ? (
                          <CheckCircle className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                        ) : (
                          <Circle className="w-5 h-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                        )}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="text-sm font-medium">{item.label}</p>
                            {item.required && <Badge variant="outline" className="text-xs">Required</Badge>}
                            <Badge variant="outline" className="text-xs capitalize">{item.category}</Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-0.5">{item.description}</p>
                          {item.document && (
                            <p className="text-xs text-muted-foreground mt-1">
                              Uploaded: {item.document.fileName} ({item.document.status})
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </Card>
            ) : (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
              </div>
            )}
          </TabsContent>

          <TabsContent value="access-tiers" className="space-y-4 mt-4">
            <AccessTierConfig assets={assets} />
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={uploadOpen} onOpenChange={setUploadOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Add Data Room Document</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label>Asset</Label>
              <Select value={form.assetId} onValueChange={v => setForm(f => ({ ...f, assetId: v, checklistKey: "" }))}>
                <SelectTrigger data-testid="input-doc-asset">
                  <SelectValue placeholder="Select asset" />
                </SelectTrigger>
                <SelectContent>
                  {assets.map(a => (
                    <SelectItem key={a.id} value={a.id}>{a.name} ({a.country})</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Title</Label>
              <Input
                value={form.title}
                onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
                placeholder="Document title"
                data-testid="input-doc-title"
              />
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea
                value={form.description}
                onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                placeholder="Optional description"
                data-testid="input-doc-description"
              />
            </div>
            <div className="space-y-2">
              <Label>Document Type</Label>
              <Select value={form.docType} onValueChange={v => setForm(f => ({ ...f, docType: v }))}>
                <SelectTrigger data-testid="input-doc-type">
                  <SelectValue placeholder="Select document type" />
                </SelectTrigger>
                <SelectContent>
                  {dataRoomDocTypeEnum.map(dt => (
                    <SelectItem key={dt} value={dt}>{DATA_ROOM_DOC_TYPE_LABELS[dt]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Category</Label>
                <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v }))}>
                  <SelectTrigger data-testid="input-doc-category">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map(c => (
                      <SelectItem key={c} value={c} className="capitalize">{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Status</Label>
                <Select value={form.status} onValueChange={v => setForm(f => ({ ...f, status: v }))}>
                  <SelectTrigger data-testid="input-doc-status">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="live">Live</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Access Tier</Label>
              <Select value={form.accessTier} onValueChange={v => setForm(f => ({ ...f, accessTier: v }))}>
                <SelectTrigger data-testid="input-doc-access-tier">
                  <SelectValue placeholder="Select access tier" />
                </SelectTrigger>
                <SelectContent>
                  {dataRoomAccessTierEnum.map(tier => (
                    <SelectItem key={tier} value={tier}>{DATA_ROOM_ACCESS_TIER_LABELS[tier]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">Controls which investors can view this document based on their investment amount</p>
            </div>
            {formChecklist && formChecklist.items.length > 0 && (
              <div className="space-y-2">
                <Label>Checklist Item (optional)</Label>
                <Select value={form.checklistKey} onValueChange={v => setForm(f => ({ ...f, checklistKey: v }))}>
                  <SelectTrigger data-testid="input-doc-checklist-key">
                    <SelectValue placeholder="Link to checklist item" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    {formChecklist.items.filter(i => !i.uploaded).map(i => (
                      <SelectItem key={i.key} value={i.key}>{i.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="space-y-2">
              <Label>File Name</Label>
              <Input
                value={form.fileName}
                onChange={e => setForm(f => ({ ...f, fileName: e.target.value }))}
                placeholder="e.g. title-deed.pdf"
                data-testid="input-doc-filename"
              />
            </div>
            <div className="space-y-2">
              <Label>File URL</Label>
              <Input
                value={form.url}
                onChange={e => setForm(f => ({ ...f, url: e.target.value }))}
                placeholder="https://storage.example.com/file.pdf"
                data-testid="input-doc-url"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setUploadOpen(false)}>Cancel</Button>
            <Button onClick={handleSubmit} disabled={createMutation.isPending} data-testid="button-submit-doc">
              {createMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Upload
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </RoleLayout>
  );
}
