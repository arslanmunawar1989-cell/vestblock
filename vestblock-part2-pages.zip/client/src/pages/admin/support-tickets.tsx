import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  type SupportTicket,
  TICKET_CATEGORIES,
  TICKET_PRIORITIES,
  TICKET_STATUSES,
} from "@shared/schema";
import { SUPPORTED_COUNTRIES, SUPPORTED_CURRENCIES, COUNTRY_DETAILS, CURRENCY_DETAILS } from "@shared/constants";
import {
  MessageSquare,
  Filter,
  Loader2,
  Eye, ArrowLeft,
} from "lucide-react";
import { formatDate } from "@/lib/format";
import { Link } from "wouter";
interface TicketWithUser extends SupportTicket {
  userName: string;
}

const STATUS_CONFIG: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  open: { label: "Open", variant: "outline" },
  in_progress: { label: "In Progress", variant: "secondary" },
  resolved: { label: "Resolved", variant: "default" },
  closed: { label: "Closed", variant: "destructive" },
};

const PRIORITY_CONFIG: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  low: { label: "Low", variant: "outline" },
  medium: { label: "Medium", variant: "secondary" },
  high: { label: "High", variant: "default" },
  urgent: { label: "Urgent", variant: "destructive" },
};

const CATEGORY_LABELS: Record<string, string> = {
  account: "Account",
  kyc: "KYC / Verification",
  deposit: "Deposits",
  withdrawal: "Withdrawals",
  trading: "Trading",
  technical: "Technical Issue",
  other: "Other",
};

export default function AdminSupportTickets() {
  const { toast } = useToast();
  const [countryFilter, setCountryFilter] = useState<string>("all");
  const [currencyFilter, setCurrencyFilter] = useState<string>("all");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [priorityFilter, setPriorityFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [detailTicket, setDetailTicket] = useState<TicketWithUser | null>(null);
  const [updateStatus, setUpdateStatus] = useState<string>("");
  const [updatePriority, setUpdatePriority] = useState<string>("");
  const [adminNotes, setAdminNotes] = useState<string>("");

  const queryParams = new URLSearchParams();
  if (countryFilter !== "all") queryParams.set("countryCode", countryFilter);
  if (currencyFilter !== "all") queryParams.set("currency", currencyFilter);
  if (categoryFilter !== "all") queryParams.set("category", categoryFilter);
  if (priorityFilter !== "all") queryParams.set("priority", priorityFilter);
  if (statusFilter !== "all") queryParams.set("status", statusFilter);

  const queryString = queryParams.toString();
  const apiUrl = `/api/admin/tickets${queryString ? `?${queryString}` : ""}`;

  const { data: tickets, isLoading } = useQuery<TicketWithUser[]>({
    queryKey: ["/api/admin/tickets", countryFilter, currencyFilter, categoryFilter, priorityFilter, statusFilter],
    queryFn: async () => {
      const res = await fetch(apiUrl, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch tickets");
      return res.json();
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      const res = await apiRequest("PATCH", `/api/admin/tickets/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Ticket updated" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/tickets"] });
      setDetailTicket(null);
    },
    onError: (err: any) => {
      toast({ title: "Failed to update ticket", description: err.message, variant: "destructive" });
    },
  });

  const openDetail = (ticket: TicketWithUser) => {
    setDetailTicket(ticket);
    setUpdateStatus(ticket.status);
    setUpdatePriority(ticket.priority);
    setAdminNotes(ticket.adminNotes || "");
  };

  const handleUpdate = () => {
    if (!detailTicket) return;
    const data: any = {};
    if (updateStatus !== detailTicket.status) data.status = updateStatus;
    if (updatePriority !== detailTicket.priority) data.priority = updatePriority;
    if (adminNotes !== (detailTicket.adminNotes || "")) data.adminNotes = adminNotes;
    if (Object.keys(data).length === 0) {
      toast({ title: "No changes to save" });
      return;
    }
    updateMutation.mutate({ id: detailTicket.id, data });
  };

  const ticketCounts = {
    total: tickets?.length || 0,
    open: tickets?.filter(t => t.status === "open").length || 0,
    inProgress: tickets?.filter(t => t.status === "in_progress").length || 0,
    urgent: tickets?.filter(t => t.priority === "urgent").length || 0,
  };

  return (
    <RoleLayout role="admin">
      <div className="flex items-center gap-3">
        <Link href="/admin/dashboard">
          <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <PageTitle title="Support Tickets" description="Manage user support requests" />
      </div>
      <Section>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          <GlassCard>
            <div className="text-center">
              <p className="text-2xl font-bold" data-testid="text-total-tickets">{ticketCounts.total}</p>
              <p className="text-xs text-muted-foreground">Total</p>
            </div>
          </GlassCard>
          <GlassCard>
            <div className="text-center">
              <p className="text-2xl font-bold" data-testid="text-open-tickets">{ticketCounts.open}</p>
              <p className="text-xs text-muted-foreground">Open</p>
            </div>
          </GlassCard>
          <GlassCard>
            <div className="text-center">
              <p className="text-2xl font-bold" data-testid="text-inprogress-tickets">{ticketCounts.inProgress}</p>
              <p className="text-xs text-muted-foreground">In Progress</p>
            </div>
          </GlassCard>
          <GlassCard>
            <div className="text-center">
              <p className="text-2xl font-bold text-destructive" data-testid="text-urgent-tickets">{ticketCounts.urgent}</p>
              <p className="text-xs text-muted-foreground">Urgent</p>
            </div>
          </GlassCard>
        </div>

        <div className="flex items-center gap-2 mb-4 flex-wrap">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <Select value={countryFilter} onValueChange={setCountryFilter}>
            <SelectTrigger className="w-[140px]" data-testid="select-filter-country">
              <SelectValue placeholder="Country" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Countries</SelectItem>
              {SUPPORTED_COUNTRIES.map(code => (
                <SelectItem key={code} value={code}>{COUNTRY_DETAILS[code].name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={currencyFilter} onValueChange={setCurrencyFilter}>
            <SelectTrigger className="w-[130px]" data-testid="select-filter-currency">
              <SelectValue placeholder="Currency" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Currencies</SelectItem>
              {SUPPORTED_CURRENCIES.map(code => (
                <SelectItem key={code} value={code}>{code}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-[140px]" data-testid="select-filter-category">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {TICKET_CATEGORIES.map(cat => (
                <SelectItem key={cat} value={cat}>{CATEGORY_LABELS[cat] || cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={priorityFilter} onValueChange={setPriorityFilter}>
            <SelectTrigger className="w-[120px]" data-testid="select-filter-priority">
              <SelectValue placeholder="Priority" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Priorities</SelectItem>
              {TICKET_PRIORITIES.map(p => (
                <SelectItem key={p} value={p}>{p.charAt(0).toUpperCase() + p.slice(1)}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[130px]" data-testid="select-filter-status">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              {TICKET_STATUSES.map(s => (
                <SelectItem key={s} value={s}>{STATUS_CONFIG[s]?.label || s}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-24 w-full" />)}
          </div>
        ) : !tickets?.length ? (
          <GlassCard>
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <MessageSquare className="w-12 h-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground" data-testid="text-no-tickets">No tickets match the current filters.</p>
            </div>
          </GlassCard>
        ) : (
          <div className="space-y-3">
            {tickets.map(ticket => {
              const statusCfg = STATUS_CONFIG[ticket.status] || STATUS_CONFIG.open;
              const priorityCfg = PRIORITY_CONFIG[ticket.priority] || PRIORITY_CONFIG.medium;
              const countryName = COUNTRY_DETAILS[ticket.countryCode as keyof typeof COUNTRY_DETAILS]?.name || ticket.countryCode;
              return (
                <GlassCard key={ticket.id}>
                  <div className="flex items-start justify-between gap-2 flex-wrap">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-medium truncate" data-testid={`text-ticket-subject-${ticket.id}`}>{ticket.subject}</h4>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-1">{ticket.description}</p>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground mt-2 flex-wrap">
                        <span data-testid={`text-ticket-user-${ticket.id}`}>{ticket.userName}</span>
                        <span data-testid={`text-ticket-country-${ticket.id}`}>{countryName}</span>
                        <span data-testid={`text-ticket-currency-${ticket.id}`}>{ticket.currency}</span>
                        <span>{CATEGORY_LABELS[ticket.category] || ticket.category}</span>
                        <span>{formatDate(ticket.createdAt)}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <Badge variant={priorityCfg.variant} data-testid={`badge-ticket-priority-${ticket.id}`}>{priorityCfg.label}</Badge>
                      <Badge variant={statusCfg.variant} data-testid={`badge-ticket-status-${ticket.id}`}>{statusCfg.label}</Badge>
                      <Button size="icon" variant="ghost" onClick={() => openDetail(ticket)} data-testid={`button-view-ticket-${ticket.id}`}>
                        <Eye className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </GlassCard>
              );
            })}
          </div>
        )}
      </Section>

      <Dialog open={!!detailTicket} onOpenChange={(open) => !open && setDetailTicket(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Ticket Details</DialogTitle>
            <DialogDescription>Review and update this support ticket.</DialogDescription>
          </DialogHeader>
          {detailTicket && (
            <div className="space-y-4">
              <div>
                <Label className="text-xs text-muted-foreground">Subject</Label>
                <p className="font-medium" data-testid="text-detail-subject">{detailTicket.subject}</p>
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Description</Label>
                <p className="text-sm whitespace-pre-wrap" data-testid="text-detail-description">{detailTicket.description}</p>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <Label className="text-xs text-muted-foreground">User</Label>
                  <p data-testid="text-detail-user">{detailTicket.userName}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Category</Label>
                  <p data-testid="text-detail-category">{CATEGORY_LABELS[detailTicket.category] || detailTicket.category}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Country</Label>
                  <p data-testid="text-detail-country">{COUNTRY_DETAILS[detailTicket.countryCode as keyof typeof COUNTRY_DETAILS]?.name || detailTicket.countryCode}</p>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Currency</Label>
                  <p data-testid="text-detail-currency">{detailTicket.currency}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Status</Label>
                  <Select value={updateStatus} onValueChange={setUpdateStatus}>
                    <SelectTrigger data-testid="select-detail-status">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {TICKET_STATUSES.map(s => (
                        <SelectItem key={s} value={s}>{STATUS_CONFIG[s]?.label || s}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Priority</Label>
                  <Select value={updatePriority} onValueChange={setUpdatePriority}>
                    <SelectTrigger data-testid="select-detail-priority">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {TICKET_PRIORITIES.map(p => (
                        <SelectItem key={p} value={p}>{p.charAt(0).toUpperCase() + p.slice(1)}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label>Admin Notes</Label>
                <Textarea
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  placeholder="Add notes or response..."
                  className="min-h-[80px]"
                  data-testid="input-admin-notes"
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setDetailTicket(null)} data-testid="button-cancel-update">Cancel</Button>
                <Button onClick={handleUpdate} disabled={updateMutation.isPending} data-testid="button-save-ticket">
                  {updateMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                  Save Changes
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </RoleLayout>
  );
}
