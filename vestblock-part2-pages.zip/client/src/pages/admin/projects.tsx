import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  FolderKanban, Plus, Search, Users, Calendar, Activity,
  Trash2, UserPlus, UserMinus, ChevronRight, ArrowLeft,
} from "lucide-react";
import { useState } from "react";
import { PLATFORM_TENANT_ID } from "@shared/constants";
import { PROJECT_STATUSES, PROJECT_TYPES, PROJECT_MEMBER_ROLES } from "@shared/schema";

interface ProjectMemberWithUser {
  id: string;
  projectId: string;
  userId: string;
  role: string;
  assignedAt: string;
  user: { id: string; fullName: string; email: string; avatarUrl: string | null } | null;
}

interface ProjectWithMembers {
  id: string;
  tenantId: string;
  name: string;
  description: string | null;
  type: string;
  status: string;
  startDate: string | null;
  dueDate: string | null;
  healthScore: number | null;
  marketScore: number | null;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  members: ProjectMemberWithUser[];
}

interface ActivityLogWithUser {
  id: string;
  projectId: string;
  userId: string;
  action: string;
  details: string | null;
  createdAt: string;
  user: { id: string; fullName: string } | null;
}

interface ProjectDetail extends ProjectWithMembers {
  activityLogs: ActivityLogWithUser[];
}

interface TenantMember {
  id: string;
  userId: string;
  role: string;
  status: string;
  user: { id: string; username: string; email: string; fullName: string } | null;
}

const STATUS_COLORS: Record<string, string> = {
  PLANNING: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
  IN_PROGRESS: "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200",
  ON_HOLD: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
  COMPLETED: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200",
  CANCELLED: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
};

const ROLE_LABELS: Record<string, string> = { DEV: "Developer", PM: "Project Manager", VIEWER: "Viewer" };
const TYPE_LABELS: Record<string, string> = { DEVELOPMENT: "Development", ACQUISITION: "Acquisition", RENOVATION: "Renovation", MARKETING: "Marketing", COMPLIANCE: "Compliance", OTHER: "Other" };
const STATUS_LABELS: Record<string, string> = { PLANNING: "Planning", IN_PROGRESS: "In Progress", ON_HOLD: "On Hold", COMPLETED: "Completed", CANCELLED: "Cancelled" };

function initials(name: string) {
  return name.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase();
}

export default function AdminProjects() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [createOpen, setCreateOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<string | null>(null);
  const [addMemberOpen, setAddMemberOpen] = useState(false);
  const [addLogOpen, setAddLogOpen] = useState(false);

  const [newName, setNewName] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newType, setNewType] = useState("DEVELOPMENT");
  const [newStatus, setNewStatus] = useState("PLANNING");
  const [newStartDate, setNewStartDate] = useState("");
  const [newDueDate, setNewDueDate] = useState("");

  const [memberUserId, setMemberUserId] = useState("");
  const [memberRole, setMemberRole] = useState("DEV");

  const [logAction, setLogAction] = useState("");
  const [logDetails, setLogDetails] = useState("");

  const tenantId = user?.role === "admin" ? PLATFORM_TENANT_ID : (user as any)?.tenantId || PLATFORM_TENANT_ID;

  const projectsQuery = useQuery<ProjectWithMembers[]>({
    queryKey: ["/api/tenant", tenantId, "projects"],
    queryFn: async () => {
      const res = await fetch(`/api/tenant/${tenantId}/projects`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch projects");
      return res.json();
    },
    enabled: !!tenantId,
  });

  const projectDetailQuery = useQuery<ProjectDetail>({
    queryKey: ["/api/tenant", tenantId, "projects", selectedProject],
    queryFn: async () => {
      const res = await fetch(`/api/tenant/${tenantId}/projects/${selectedProject}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch project");
      return res.json();
    },
    enabled: !!selectedProject && !!tenantId,
  });

  const tenantUsersQuery = useQuery<TenantMember[]>({
    queryKey: ["/api/tenant-admin", tenantId, "users"],
    queryFn: async () => {
      const res = await fetch(`/api/tenant-admin/${tenantId}/users`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch users");
      return res.json();
    },
    enabled: !!tenantId && addMemberOpen,
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", `/api/tenant/${tenantId}/projects`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant", tenantId, "projects"] });
      toast({ title: "Project created" });
      setCreateOpen(false);
      setNewName(""); setNewDesc(""); setNewType("DEVELOPMENT"); setNewStatus("PLANNING"); setNewStartDate(""); setNewDueDate("");
    },
    onError: () => toast({ title: "Failed to create project", variant: "destructive" }),
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ projectId, status }: { projectId: string; status: string }) => {
      const res = await apiRequest("PATCH", `/api/tenant/${tenantId}/projects/${projectId}`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant", tenantId, "projects"] });
      if (selectedProject) queryClient.invalidateQueries({ queryKey: ["/api/tenant", tenantId, "projects", selectedProject] });
      toast({ title: "Status updated" });
    },
    onError: () => toast({ title: "Failed to update status", variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: async (projectId: string) => {
      await apiRequest("DELETE", `/api/tenant/${tenantId}/projects/${projectId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant", tenantId, "projects"] });
      setSelectedProject(null);
      toast({ title: "Project deleted" });
    },
    onError: () => toast({ title: "Failed to delete project", variant: "destructive" }),
  });

  const addMemberMutation = useMutation({
    mutationFn: async ({ projectId, userId, role }: { projectId: string; userId: string; role: string }) => {
      const res = await apiRequest("POST", `/api/tenant/${tenantId}/projects/${projectId}/members`, { userId, role });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant", tenantId, "projects"] });
      if (selectedProject) queryClient.invalidateQueries({ queryKey: ["/api/tenant", tenantId, "projects", selectedProject] });
      toast({ title: "Member added" });
      setAddMemberOpen(false);
      setMemberUserId(""); setMemberRole("DEV");
    },
    onError: (err: any) => toast({ title: err?.message || "Failed to add member", variant: "destructive" }),
  });

  const removeMemberMutation = useMutation({
    mutationFn: async ({ projectId, userId }: { projectId: string; userId: string }) => {
      await apiRequest("DELETE", `/api/tenant/${tenantId}/projects/${projectId}/members/${userId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tenant", tenantId, "projects"] });
      if (selectedProject) queryClient.invalidateQueries({ queryKey: ["/api/tenant", tenantId, "projects", selectedProject] });
      toast({ title: "Member removed" });
    },
    onError: () => toast({ title: "Failed to remove member", variant: "destructive" }),
  });

  const addLogMutation = useMutation({
    mutationFn: async ({ projectId, action, details }: { projectId: string; action: string; details: string }) => {
      const res = await apiRequest("POST", `/api/tenant/${tenantId}/projects/${projectId}/activity`, { action, details });
      return res.json();
    },
    onSuccess: () => {
      if (selectedProject) queryClient.invalidateQueries({ queryKey: ["/api/tenant", tenantId, "projects", selectedProject] });
      toast({ title: "Activity logged" });
      setAddLogOpen(false);
      setLogAction(""); setLogDetails("");
    },
    onError: () => toast({ title: "Failed to add log", variant: "destructive" }),
  });

  const projects = projectsQuery.data || [];
  const filtered = projects.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));
  const detail = projectDetailQuery.data;

  const stats = {
    total: projects.length,
    active: projects.filter(p => p.status === "IN_PROGRESS").length,
    planning: projects.filter(p => p.status === "PLANNING").length,
    completed: projects.filter(p => p.status === "COMPLETED").length,
  };

  if (selectedProject && detail) {
    return (
      <RoleLayout role="admin">
        <div className="p-4 md:p-6 space-y-6 max-w-5xl">
          <div className="flex items-center gap-2 flex-wrap">
            <Button variant="ghost" size="icon" onClick={() => setSelectedProject(null)} data-testid="button-back-projects">
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="flex-1 min-w-0">
              <h1 className="text-xl font-bold truncate" data-testid="text-project-name">{detail.name}</h1>
              <p className="text-sm text-muted-foreground">{TYPE_LABELS[detail.type] || detail.type}</p>
            </div>
            <Badge className={STATUS_COLORS[detail.status] || ""} data-testid="badge-project-status">{STATUS_LABELS[detail.status] || detail.status}</Badge>
          </div>

          {detail.description && (
            <Card>
              <CardContent className="pt-4">
                <p className="text-sm text-muted-foreground" data-testid="text-project-description">{detail.description}</p>
              </CardContent>
            </Card>
          )}

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Card><CardContent className="pt-4 text-center"><p className="text-xs text-muted-foreground">Health</p><p className="text-lg font-bold" data-testid="text-health-score">{detail.healthScore ?? "N/A"}</p></CardContent></Card>
            <Card><CardContent className="pt-4 text-center"><p className="text-xs text-muted-foreground">Market</p><p className="text-lg font-bold" data-testid="text-market-score">{detail.marketScore ?? "N/A"}</p></CardContent></Card>
            <Card><CardContent className="pt-4 text-center"><p className="text-xs text-muted-foreground">Start</p><p className="text-sm font-medium" data-testid="text-start-date">{detail.startDate ? new Date(detail.startDate).toLocaleDateString() : "Not set"}</p></CardContent></Card>
            <Card><CardContent className="pt-4 text-center"><p className="text-xs text-muted-foreground">Due</p><p className="text-sm font-medium" data-testid="text-due-date">{detail.dueDate ? new Date(detail.dueDate).toLocaleDateString() : "Not set"}</p></CardContent></Card>
          </div>

          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-2">
              <Label className="text-sm font-medium">Status:</Label>
              <Select value={detail.status} onValueChange={(val) => updateStatusMutation.mutate({ projectId: detail.id, status: val })}>
                <SelectTrigger className="w-[160px]" data-testid="select-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PROJECT_STATUSES.map(s => <SelectItem key={s} value={s}>{STATUS_LABELS[s]}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <Button variant="destructive" size="sm" onClick={() => { if (confirm("Delete this project?")) deleteMutation.mutate(detail.id); }} data-testid="button-delete-project">
              <Trash2 className="w-4 h-4 mr-1" /> Delete
            </Button>
          </div>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 pb-3">
              <CardTitle className="text-base flex items-center gap-2"><Users className="w-4 h-4" /> Members ({detail.members.length})</CardTitle>
              <Dialog open={addMemberOpen} onOpenChange={setAddMemberOpen}>
                <DialogTrigger asChild>
                  <Button size="sm" data-testid="button-add-member"><UserPlus className="w-4 h-4 mr-1" /> Add</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader><DialogTitle>Add Project Member</DialogTitle></DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label>User</Label>
                      <Select value={memberUserId} onValueChange={setMemberUserId}>
                        <SelectTrigger data-testid="select-member-user">
                          <SelectValue placeholder="Select a user" />
                        </SelectTrigger>
                        <SelectContent>
                          {(tenantUsersQuery.data || [])
                            .filter(m => m.user && m.status === "ACTIVE" && !detail.members.some(dm => dm.userId === m.userId))
                            .map(m => (
                              <SelectItem key={m.userId} value={m.userId}>{m.user?.fullName} ({m.user?.email})</SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Role</Label>
                      <Select value={memberRole} onValueChange={setMemberRole}>
                        <SelectTrigger data-testid="select-member-role">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {PROJECT_MEMBER_ROLES.map(r => <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      onClick={() => memberUserId && addMemberMutation.mutate({ projectId: detail.id, userId: memberUserId, role: memberRole })}
                      disabled={!memberUserId || addMemberMutation.isPending}
                      data-testid="button-confirm-add-member"
                    >
                      {addMemberMutation.isPending ? "Adding..." : "Add Member"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {detail.members.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4" data-testid="text-no-members">No members assigned</p>
              ) : (
                <div className="space-y-2">
                  {detail.members.map(m => (
                    <div key={m.id} className="flex items-center gap-3 p-2 rounded-md border" data-testid={`member-row-${m.userId}`}>
                      <Avatar className="w-8 h-8">
                        <AvatarFallback className="text-xs">{m.user ? initials(m.user.fullName) : "?"}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{m.user?.fullName || "Unknown"}</p>
                        <p className="text-xs text-muted-foreground truncate">{m.user?.email}</p>
                      </div>
                      <Badge variant="secondary" className="no-default-active-elevate">{ROLE_LABELS[m.role] || m.role}</Badge>
                      <Button variant="ghost" size="icon" onClick={() => removeMemberMutation.mutate({ projectId: detail.id, userId: m.userId })} data-testid={`button-remove-member-${m.userId}`}>
                        <UserMinus className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 pb-3">
              <CardTitle className="text-base flex items-center gap-2"><Activity className="w-4 h-4" /> Activity Log</CardTitle>
              <Dialog open={addLogOpen} onOpenChange={setAddLogOpen}>
                <DialogTrigger asChild>
                  <Button size="sm" variant="outline" data-testid="button-add-activity"><Plus className="w-4 h-4 mr-1" /> Log Activity</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader><DialogTitle>Log Activity</DialogTitle></DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label>Action</Label>
                      <Select value={logAction} onValueChange={setLogAction}>
                        <SelectTrigger data-testid="select-log-action">
                          <SelectValue placeholder="Select action type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="MILESTONE_REACHED">Milestone Reached</SelectItem>
                          <SelectItem value="STATUS_UPDATE">Status Update</SelectItem>
                          <SelectItem value="NOTE">Note</SelectItem>
                          <SelectItem value="BLOCKER">Blocker</SelectItem>
                          <SelectItem value="REVIEW">Review</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Details</Label>
                      <Textarea value={logDetails} onChange={e => setLogDetails(e.target.value)} placeholder="Describe the activity..." data-testid="input-log-details" />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button
                      onClick={() => logAction && addLogMutation.mutate({ projectId: detail.id, action: logAction, details: logDetails })}
                      disabled={!logAction || addLogMutation.isPending}
                      data-testid="button-confirm-add-activity"
                    >
                      {addLogMutation.isPending ? "Logging..." : "Log Activity"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {(detail.activityLogs || []).length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-4" data-testid="text-no-activity">No activity yet</p>
              ) : (
                <div className="space-y-3 max-h-[400px] overflow-y-auto">
                  {detail.activityLogs.map(log => (
                    <div key={log.id} className="flex gap-3 text-sm" data-testid={`activity-log-${log.id}`}>
                      <div className="w-2 h-2 rounded-full bg-primary mt-1.5 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium">{log.action.replace(/_/g, " ")}</span>
                          <span className="text-xs text-muted-foreground">{new Date(log.createdAt).toLocaleString()}</span>
                        </div>
                        {log.details && <p className="text-muted-foreground mt-0.5">{log.details}</p>}
                        <p className="text-xs text-muted-foreground">by {log.user?.fullName || "System"}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </RoleLayout>
    );
  }

  return (
    <RoleLayout role="admin">
      <div className="p-4 md:p-6 space-y-6 max-w-5xl">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div>
            <h1 className="text-xl font-bold flex items-center gap-2"><FolderKanban className="w-5 h-5" /> Projects</h1>
            <p className="text-sm text-muted-foreground">Manage agency development projects</p>
          </div>
          <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-create-project"><Plus className="w-4 h-4 mr-1" /> New Project</Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader><DialogTitle>Create Project</DialogTitle></DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Name</Label>
                  <Input value={newName} onChange={e => setNewName(e.target.value)} placeholder="Project name" data-testid="input-project-name" />
                </div>
                <div>
                  <Label>Description</Label>
                  <Textarea value={newDesc} onChange={e => setNewDesc(e.target.value)} placeholder="Brief description" data-testid="input-project-desc" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Type</Label>
                    <Select value={newType} onValueChange={setNewType}>
                      <SelectTrigger data-testid="select-project-type"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {PROJECT_TYPES.map(t => <SelectItem key={t} value={t}>{TYPE_LABELS[t]}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Status</Label>
                    <Select value={newStatus} onValueChange={setNewStatus}>
                      <SelectTrigger data-testid="select-project-status"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {PROJECT_STATUSES.map(s => <SelectItem key={s} value={s}>{STATUS_LABELS[s]}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Start Date</Label>
                    <Input type="date" value={newStartDate} onChange={e => setNewStartDate(e.target.value)} data-testid="input-start-date" />
                  </div>
                  <div>
                    <Label>Due Date</Label>
                    <Input type="date" value={newDueDate} onChange={e => setNewDueDate(e.target.value)} data-testid="input-due-date" />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button
                  onClick={() => newName && createMutation.mutate({
                    name: newName,
                    description: newDesc || undefined,
                    type: newType,
                    status: newStatus,
                    startDate: newStartDate || undefined,
                    dueDate: newDueDate || undefined,
                  })}
                  disabled={!newName || createMutation.isPending}
                  data-testid="button-confirm-create"
                >
                  {createMutation.isPending ? "Creating..." : "Create Project"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card><CardContent className="pt-4 text-center"><p className="text-xs text-muted-foreground">Total</p><p className="text-2xl font-bold" data-testid="stat-total">{stats.total}</p></CardContent></Card>
          <Card><CardContent className="pt-4 text-center"><p className="text-xs text-muted-foreground">Active</p><p className="text-2xl font-bold" data-testid="stat-active">{stats.active}</p></CardContent></Card>
          <Card><CardContent className="pt-4 text-center"><p className="text-xs text-muted-foreground">Planning</p><p className="text-2xl font-bold" data-testid="stat-planning">{stats.planning}</p></CardContent></Card>
          <Card><CardContent className="pt-4 text-center"><p className="text-xs text-muted-foreground">Completed</p><p className="text-2xl font-bold" data-testid="stat-completed">{stats.completed}</p></CardContent></Card>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input className="pl-9" placeholder="Search projects..." value={search} onChange={e => setSearch(e.target.value)} data-testid="input-search-projects" />
        </div>

        {projectsQuery.isLoading ? (
          <div className="space-y-3">{[1,2,3].map(i => <Skeleton key={i} className="h-24 w-full" />)}</div>
        ) : filtered.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <FolderKanban className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground" data-testid="text-no-projects">No projects found. Create your first project to get started.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {filtered.map(project => (
              <Card
                key={project.id}
                className="hover-elevate cursor-pointer"
                onClick={() => setSelectedProject(project.id)}
                data-testid={`card-project-${project.id}`}
              >
                <CardContent className="py-4">
                  <div className="flex items-center gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-medium truncate" data-testid={`text-project-name-${project.id}`}>{project.name}</h3>
                        <Badge className={STATUS_COLORS[project.status] || ""} data-testid={`badge-status-${project.id}`}>
                          {STATUS_LABELS[project.status] || project.status}
                        </Badge>
                        <Badge variant="outline" className="no-default-active-elevate">{TYPE_LABELS[project.type] || project.type}</Badge>
                      </div>
                      {project.description && <p className="text-sm text-muted-foreground mt-1 truncate">{project.description}</p>}
                      <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground flex-wrap">
                        <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {project.members.length} members</span>
                        {project.dueDate && <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> Due {new Date(project.dueDate).toLocaleDateString()}</span>}
                        {project.healthScore != null && <span>Health: {project.healthScore}</span>}
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      {project.members.slice(0, 3).map(m => (
                        <Avatar key={m.id} className="w-7 h-7">
                          <AvatarFallback className="text-xs">{m.user ? initials(m.user.fullName) : "?"}</AvatarFallback>
                        </Avatar>
                      ))}
                      {project.members.length > 3 && <span className="text-xs text-muted-foreground ml-1">+{project.members.length - 3}</span>}
                    </div>
                    <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </RoleLayout>
  );
}
