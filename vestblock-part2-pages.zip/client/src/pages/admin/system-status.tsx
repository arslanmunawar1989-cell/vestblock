import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import {
  Activity,
  CheckCircle,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Server,
  Database,
  Shield,
  Clock,
  Cpu,
  Loader2, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface SystemCheck {
  name: string;
  status: "ok" | "degraded" | "down";
  message: string;
  latencyMs?: number;
  details?: Record<string, unknown>;
}

interface SystemStatusResponse {
  status: "healthy" | "degraded" | "unhealthy";
  timestamp: string;
  uptime: {
    seconds: number;
    formatted: string;
  };
  node: {
    version: string;
    env: string;
    pid: number;
  };
  checks: SystemCheck[];
}

const STATUS_CONFIG = {
  ok: { icon: CheckCircle, color: "text-emerald-500", bg: "bg-emerald-500/10", label: "OK" },
  degraded: { icon: AlertTriangle, color: "text-amber-500", bg: "bg-amber-500/10", label: "Degraded" },
  down: { icon: XCircle, color: "text-destructive", bg: "bg-destructive/10", label: "Down" },
};

const OVERALL_STATUS_CONFIG = {
  healthy: { label: "All Systems Operational", variant: "default" as const, color: "text-emerald-500" },
  degraded: { label: "Some Systems Degraded", variant: "secondary" as const, color: "text-amber-500" },
  unhealthy: { label: "System Issues Detected", variant: "destructive" as const, color: "text-destructive" },
};

export default function AdminSystemStatus() {
  const { data, isLoading, isFetching } = useQuery<SystemStatusResponse>({
    queryKey: ["/api/admin/system-status"],
    refetchInterval: 30000,
  });

  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/admin/system-status"] });
  };

  if (isLoading) {
    return (
      <RoleLayout role="admin">
        <div className="flex items-center justify-center py-20 text-muted-foreground">
          <Loader2 className="w-5 h-5 animate-spin mr-2" />
          Loading system status...
        </div>
      </RoleLayout>
    );
  }

  const overallCfg = data ? OVERALL_STATUS_CONFIG[data.status] : OVERALL_STATUS_CONFIG.healthy;

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <Link href="/admin/dashboard">
              <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <PageTitle
            title="System Status"
            description="Real-time health monitoring for all platform services"
          />
          </div>
          <div className="flex items-center gap-2">
            {data && (
              <Badge variant={overallCfg.variant} data-testid="badge-overall-status">
                <Activity className="w-3 h-3 mr-1" />
                {overallCfg.label}
              </Badge>
            )}
            <Button
              variant="outline"
              size="sm"
              onClick={handleRefresh}
              disabled={isFetching}
              data-testid="button-refresh-status"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isFetching ? "animate-spin" : ""}`} />
              Refresh
            </Button>
          </div>
        </div>

        {data && (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3" data-testid="stat-uptime">
                    <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                      <Clock className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Uptime</p>
                      <p className="text-lg font-semibold">{data.uptime.formatted}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3" data-testid="stat-node">
                    <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                      <Server className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Node.js</p>
                      <p className="text-lg font-semibold">{data.node.version}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3" data-testid="stat-env">
                    <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                      <Cpu className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Environment</p>
                      <p className="text-lg font-semibold capitalize">{data.node.env}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Activity className="w-4 h-4" />
                  Service Health Checks
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3" data-testid="checks-list">
                  {data.checks.map((check, idx) => {
                    const cfg = STATUS_CONFIG[check.status];
                    const StatusIcon = cfg.icon;
                    return (
                      <div
                        key={idx}
                        className="flex items-start gap-3 p-3 rounded-md bg-muted/30"
                        data-testid={`check-item-${idx}`}
                      >
                        <div className={`w-8 h-8 rounded-md ${cfg.bg} flex items-center justify-center mt-0.5 shrink-0`}>
                          <StatusIcon className={`w-4 h-4 ${cfg.color}`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-sm font-medium" data-testid={`check-name-${idx}`}>{check.name}</span>
                            <Badge variant="secondary" className="text-xs" data-testid={`check-status-${idx}`}>
                              {cfg.label}
                            </Badge>
                            {check.latencyMs !== undefined && (
                              <span className="text-xs text-muted-foreground">{check.latencyMs}ms</span>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground mt-0.5" data-testid={`check-message-${idx}`}>
                            {check.message}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <p className="text-xs text-muted-foreground" data-testid="text-last-checked">
                  Last checked: {new Date(data.timestamp).toLocaleString()} (PID: {data.node.pid})
                </p>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </RoleLayout>
  );
}
