import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { StatTile } from "@/components/stat-tile";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatCurrency, formatDate } from "@/lib/format";
import { WALLET_CURRENCIES, CURRENCY_DETAILS } from "@shared/constants";
import {
  DollarSign,
  TrendingUp,
  ArrowDownLeft,
  ArrowUpRight,
  Building2,
  CheckCircle2,
  XCircle,
  Clock,
  Send,
  Banknote,
  Download,
  AlertTriangle,
  Shield,
  RefreshCw,
  ArrowRightLeft,
  FileText,
  Wallet, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface BankAccountWithUser {
  id: string;
  userId: string;
  country: string;
  label: string;
  accountHolderName: string;
  iban: string | null;
  bankName: string;
  branchCode: string | null;
  accountNumber: string | null;
  swiftCode: string | null;
  currency: string;
  status: string;
  verifiedBy: string | null;
  verifiedAt: string | null;
  verificationNotes: string | null;
  isDefault: boolean;
  createdAt: string;
  user: { id: string; username: string; email: string; fullName: string } | null;
}

interface WithdrawalWithUser {
  id: string;
  userId: string;
  walletAccountId: string;
  bankAccountId: string;
  amount: string;
  currency: string;
  fee: string;
  netAmount: string;
  status: string;
  requestedAt: string;
  reviewedBy: string | null;
  reviewedAt: string | null;
  reviewNotes: string | null;
  payoutReference: string | null;
  paidAt: string | null;
  paidBy: string | null;
  user: { id: string; username: string; email: string; fullName: string } | null;
  bankAccount: { id: string; label: string; bankName: string; iban: string | null; accountNumber: string | null; currency: string; country: string } | null;
}

const STATUS_CONFIG: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline"; icon: typeof CheckCircle2 }> = {
  pending: { label: "Pending", variant: "outline", icon: Clock },
  verified: { label: "Verified", variant: "default", icon: CheckCircle2 },
  rejected: { label: "Rejected", variant: "destructive", icon: XCircle },
};

const WITHDRAWAL_STATUS_CONFIG: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline"; icon: typeof CheckCircle2 }> = {
  REQUESTED: { label: "Requested", variant: "outline", icon: Clock },
  APPROVED: { label: "Approved", variant: "default", icon: CheckCircle2 },
  DECLINED: { label: "Declined", variant: "destructive", icon: XCircle },
  PAID: { label: "Paid", variant: "secondary", icon: Banknote },
};

function DepositsTab({ currencyFilter }: { currencyFilter: string }) {
  const { toast } = useToast();
  const { data, isLoading } = useQuery<{ deposits: any[]; stats: any }>({
    queryKey: ["/api/admin/finance/deposits", currencyFilter],
    queryFn: async () => {
      const params = currencyFilter !== "all" ? `?currency=${currencyFilter}` : "";
      const res = await fetch(`/api/admin/finance/deposits${params}`, { credentials: "include" });
      return res.json();
    },
  });

  const confirmMutation = useMutation({
    mutationFn: async ({ id, action, notes }: { id: string; action: "confirm" | "reject"; notes?: string }) => {
      const res = await apiRequest("POST", `/api/admin/finance/deposits/${id}/confirm`, { action, notes });
      return res.json();
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/finance/deposits"] });
      toast({ title: "Deposit Updated", description: `Deposit ${variables.action === "confirm" ? "confirmed" : "rejected"} successfully` });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to update deposit", variant: "destructive" });
    },
  });

  const handleExport = () => {
    const params = currencyFilter !== "all" ? `?currency=${currencyFilter}` : "";
    window.open(`/api/admin/finance/deposits/export${params}`, "_blank");
  };

  if (isLoading) return <div className="space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-20 rounded-md" />)}</div>;

  const stats = data?.stats || {};
  const deposits = data?.deposits || [];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 flex-1">
          <StatTile label="Total Deposits" value={String(stats.totalCount || 0)} icon={<ArrowDownLeft className="w-5 h-5" />} />
          <StatTile label="Total Amount" value={stats.totalAmount || "0.00"} icon={<DollarSign className="w-5 h-5" />} />
          <StatTile label="Pending" value={String(stats.pendingCount || 0)} icon={<Clock className="w-5 h-5" />} />
          <StatTile label="Completed" value={String(stats.completedCount || 0)} icon={<CheckCircle2 className="w-5 h-5" />} />
        </div>
        <Button variant="outline" size="sm" onClick={handleExport} data-testid="button-export-deposits">
          <Download className="w-4 h-4 mr-1" />
          Export CSV
        </Button>
      </div>

      {deposits.length === 0 ? (
        <GlassCard><div className="text-center py-8 text-muted-foreground"><ArrowDownLeft className="w-10 h-10 mx-auto mb-3 opacity-50" /><p className="text-sm">No deposits found</p></div></GlassCard>
      ) : (
        <div className="space-y-2">
          {deposits.slice(0, 50).map((d: any) => (
            <GlassCard key={d.id} padding="sm" data-testid={`deposit-card-${d.id}`}>
              <div className="flex items-center justify-between gap-3 flex-wrap">
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                    {d.type === "CRYPTO_DEPOSIT" ? <Wallet className="w-4 h-4 text-primary" /> : <ArrowDownLeft className="w-4 h-4 text-primary" />}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-semibold">{d.amount} {d.currency}</span>
                      <Badge variant={d.status === "COMPLETED" ? "default" : d.status === "PENDING" ? "outline" : "destructive"} className="no-default-hover-elevate">
                        {d.status}
                      </Badge>
                      <Badge variant="secondary" className="no-default-hover-elevate">{d.type}</Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">{d.userName} &middot; {formatDate(d.createdAt)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  {d.referenceId && <span className="text-xs text-muted-foreground mr-2">Ref: {d.referenceId.slice(0, 12)}...</span>}
                  {d.status === "PENDING" && d.type === "DEPOSIT" && (
                    <>
                      <Button size="sm" onClick={() => confirmMutation.mutate({ id: d.id, action: "confirm" })} disabled={confirmMutation.isPending} data-testid={`button-confirm-deposit-${d.id}`}>
                        <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                        Confirm
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => confirmMutation.mutate({ id: d.id, action: "reject" })} disabled={confirmMutation.isPending} data-testid={`button-reject-deposit-${d.id}`}>
                        <XCircle className="w-3.5 h-3.5 mr-1" />
                        Reject
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  );
}

function CryptoApprovalsTab() {
  const { toast } = useToast();
  const [statusFilter, setStatusFilter] = useState("all");
  const [reviewTarget, setReviewTarget] = useState<any>(null);
  const [reviewAction, setReviewAction] = useState<string>("");
  const [reviewNotes, setReviewNotes] = useState("");

  const { data, isLoading } = useQuery<{ deposits: any[]; stats: any }>({
    queryKey: ["/api/admin/finance/crypto-deposits"],
  });

  const reviewMutation = useMutation({
    mutationFn: async ({ id, action, notes }: { id: string; action: string; notes?: string }) => {
      const res = await apiRequest("POST", `/api/admin/finance/crypto-deposits/${id}/review`, { action, notes });
      return res.json();
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/finance/crypto-deposits"] });
      setReviewTarget(null);
      setReviewNotes("");
      toast({ title: "Crypto Deposit Reviewed", description: `Action: ${variables.action} completed successfully.` });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to review deposit", variant: "destructive" });
    },
  });

  const handleExport = () => window.open("/api/admin/finance/crypto-deposits/export", "_blank");

  if (isLoading) return <div className="space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-20 rounded-md" />)}</div>;

  const stats = data?.stats || {};
  const deposits = (data?.deposits || []).filter((d: any) => statusFilter === "all" || d.status === statusFilter);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 flex-1">
          <StatTile label="Pending Review" value={String(stats.pendingReview || 0)} icon={<Shield className="w-5 h-5" />} />
          <StatTile label="Confirmed" value={String(stats.confirmed || 0)} icon={<CheckCircle2 className="w-5 h-5" />} />
          <StatTile label="Rejected" value={String(stats.rejected || 0)} icon={<XCircle className="w-5 h-5" />} />
          <StatTile label="Total Confirmed" value={stats.totalConfirmedAmount || "0.00"} icon={<DollarSign className="w-5 h-5" />} />
        </div>
        <Button variant="outline" size="sm" onClick={handleExport} data-testid="button-export-crypto">
          <Download className="w-4 h-4 mr-1" />
          Export CSV
        </Button>
      </div>

      <div className="flex items-center gap-1.5 flex-wrap">
        {["all", "PENDING", "AML_HOLD", "CONFIRMED", "REJECTED"].map(s => (
          <Button key={s} variant={statusFilter === s ? "default" : "outline"} size="sm" onClick={() => setStatusFilter(s)} data-testid={`filter-crypto-${s}`}>
            {s === "all" ? "All" : s.replace("_", " ")}
          </Button>
        ))}
      </div>

      {deposits.length === 0 ? (
        <GlassCard><div className="text-center py-8 text-muted-foreground"><Shield className="w-10 h-10 mx-auto mb-3 opacity-50" /><p className="text-sm">No crypto deposits found</p></div></GlassCard>
      ) : (
        <div className="space-y-2">
          {deposits.map((d: any) => (
            <GlassCard key={d.id} padding="sm" data-testid={`crypto-card-${d.id}`}>
              <div className="flex items-start justify-between gap-3 flex-wrap">
                <div className="flex items-start gap-3 min-w-0 flex-1">
                  <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Wallet className="w-4 h-4 text-primary" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-semibold">{String(d.amount)} {d.currency}</span>
                      <Badge variant={d.status === "CONFIRMED" ? "default" : d.status === "REJECTED" ? "destructive" : d.status === "AML_HOLD" ? "secondary" : "outline"} className="no-default-hover-elevate">
                        {d.status}
                      </Badge>
                      {d.amlStatus && <Badge variant="outline" className="no-default-hover-elevate">{d.amlStatus}</Badge>}
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">{d.userName} &middot; {d.chain} &middot; {formatDate(d.createdAt)}</p>
                    {d.walletAddress && <p className="text-xs text-muted-foreground mt-0.5">Wallet: {d.walletAddress.slice(0, 10)}...{d.walletAddress.slice(-6)}</p>}
                    {d.txHash && <p className="text-xs text-muted-foreground">TX: {d.txHash.slice(0, 16)}...</p>}
                    {d.reviewNotes && <p className="text-xs text-muted-foreground italic mt-1">Notes: {d.reviewNotes}</p>}
                  </div>
                </div>
                {(d.status === "PENDING" || d.status === "AML_HOLD") && (
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    <Button size="sm" onClick={() => reviewMutation.mutate({ id: d.id, action: d.status === "AML_HOLD" ? "clear" : "approve" })} disabled={reviewMutation.isPending} data-testid={`button-approve-crypto-${d.id}`}>
                      <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                      {d.status === "AML_HOLD" ? "Clear" : "Approve"}
                    </Button>
                    {d.status === "PENDING" && (
                      <Button size="sm" variant="secondary" onClick={() => reviewMutation.mutate({ id: d.id, action: "aml_hold" })} disabled={reviewMutation.isPending} data-testid={`button-hold-crypto-${d.id}`}>
                        <Shield className="w-3.5 h-3.5 mr-1" />
                        AML Hold
                      </Button>
                    )}
                    <Button size="sm" variant="outline" onClick={() => { setReviewTarget(d); setReviewAction("reject"); setReviewNotes(""); }} disabled={reviewMutation.isPending} data-testid={`button-reject-crypto-${d.id}`}>
                      <XCircle className="w-3.5 h-3.5 mr-1" />
                      Reject
                    </Button>
                  </div>
                )}
              </div>
            </GlassCard>
          ))}
        </div>
      )}

      <Dialog open={!!reviewTarget} onOpenChange={(open) => { if (!open) setReviewTarget(null); }}>
        <DialogContent data-testid="crypto-review-dialog">
          <DialogHeader>
            <DialogTitle>Reject Crypto Deposit</DialogTitle>
            <DialogDescription>Rejecting {reviewTarget?.amount} {reviewTarget?.currency} from {reviewTarget?.userName}.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea placeholder="Reason for rejection..." value={reviewNotes} onChange={e => setReviewNotes(e.target.value)} data-testid="input-crypto-review-notes" />
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setReviewTarget(null)}>Cancel</Button>
              <Button variant="destructive" onClick={() => { if (reviewTarget) reviewMutation.mutate({ id: reviewTarget.id, action: reviewAction, notes: reviewNotes || undefined }); }} disabled={reviewMutation.isPending} data-testid="button-confirm-crypto-reject">
                {reviewMutation.isPending ? "Processing..." : "Reject Deposit"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function FxMonitorTab() {
  const { data, isLoading } = useQuery<any>({
    queryKey: ["/api/admin/finance/fx/overview"],
  });

  const handleExport = () => window.open("/api/admin/finance/fx/export", "_blank");

  if (isLoading) return <div className="space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-20 rounded-md" />)}</div>;

  const stats = data?.stats || {};
  const rates = data?.rates || [];
  const conversions = data?.conversions || [];
  const recentTransactions = data?.recentTransactions || [];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 flex-1">
          <StatTile label="Active Rates" value={String(stats.activeRateCount || 0)} icon={<ArrowRightLeft className="w-5 h-5" />} />
          <StatTile label="Pending Conversions" value={String(stats.pendingConversionCount || 0)} icon={<Clock className="w-5 h-5" />} />
          <StatTile label="Total Transactions" value={String(stats.totalTransactions || 0)} icon={<TrendingUp className="w-5 h-5" />} />
          <StatTile label="Total Volume" value={stats.totalVolume || "0.00"} icon={<DollarSign className="w-5 h-5" />} />
        </div>
        <Button variant="outline" size="sm" onClick={handleExport} data-testid="button-export-fx">
          <Download className="w-4 h-4 mr-1" />
          Export CSV
        </Button>
      </div>

      <Section title="Active FX Rates" description={`${rates.length} active rate pairs`}>
        {rates.length === 0 ? (
          <GlassCard><div className="text-center py-6 text-muted-foreground text-sm">No active rates</div></GlassCard>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {rates.map((r: any) => (
              <GlassCard key={r.id} padding="sm" data-testid={`fx-rate-${r.id}`}>
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <span className="text-sm font-semibold">{r.fromCurrency}/{r.toCurrency}</span>
                    <p className="text-xs text-muted-foreground">Spread: {r.spread} &middot; {r.provider}</p>
                  </div>
                  <span className="text-sm font-mono font-semibold">{parseFloat(r.rate).toFixed(4)}</span>
                </div>
              </GlassCard>
            ))}
          </div>
        )}
      </Section>

      <Section title="Pending Conversions" description={`${conversions.filter((c: any) => c.status === "PENDING").length} awaiting review`}>
        {conversions.filter((c: any) => c.status === "PENDING").length === 0 ? (
          <GlassCard><div className="text-center py-6 text-muted-foreground text-sm">No pending conversions</div></GlassCard>
        ) : (
          <div className="space-y-2">
            {conversions.filter((c: any) => c.status === "PENDING").map((c: any) => (
              <GlassCard key={c.id} padding="sm">
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <div>
                    <span className="text-sm font-semibold">{c.fromCurrency} {c.fromAmount} -&gt; {c.toCurrency}</span>
                    <p className="text-xs text-muted-foreground">{formatDate(c.createdAt)}</p>
                  </div>
                  <Badge variant="outline" className="no-default-hover-elevate">{c.status}</Badge>
                </div>
              </GlassCard>
            ))}
          </div>
        )}
      </Section>

      <Section title="Recent FX Transactions" description={`Last ${Math.min(recentTransactions.length, 20)} transactions`}>
        {recentTransactions.length === 0 ? (
          <GlassCard><div className="text-center py-6 text-muted-foreground text-sm">No transactions</div></GlassCard>
        ) : (
          <div className="space-y-2">
            {recentTransactions.slice(0, 20).map((t: any) => (
              <GlassCard key={t.id} padding="sm">
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <div>
                    <span className="text-sm font-semibold">{t.fromCurrency} {t.amountFrom} &rarr; {t.toCurrency} {t.amountTo}</span>
                    <p className="text-xs text-muted-foreground">Rate: {t.rate} &middot; {formatDate(t.createdAt)}</p>
                  </div>
                  <Badge variant={t.status === "COMPLETED" ? "default" : "outline"} className="no-default-hover-elevate">{t.status}</Badge>
                </div>
              </GlassCard>
            ))}
          </div>
        )}
      </Section>
    </div>
  );
}

function DistributionsTab() {
  const { data, isLoading } = useQuery<any>({
    queryKey: ["/api/admin/finance/distributions/overview"],
  });

  const handleExport = () => window.open("/api/admin/finance/distributions/export", "_blank");

  if (isLoading) return <div className="space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-20 rounded-md" />)}</div>;

  const stats = data?.stats || {};
  const distributions = data?.distributions || [];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="grid grid-cols-2 gap-3 flex-1">
          <StatTile label="Total Distributions" value={String(stats.totalDistributions || 0)} icon={<Send className="w-5 h-5" />} />
          <StatTile label="Total Distributed" value={stats.totalDistributed || "0.00"} icon={<DollarSign className="w-5 h-5" />} />
        </div>
        <Button variant="outline" size="sm" onClick={handleExport} data-testid="button-export-distributions">
          <Download className="w-4 h-4 mr-1" />
          Export CSV
        </Button>
      </div>

      {distributions.length === 0 ? (
        <GlassCard><div className="text-center py-8 text-muted-foreground"><Send className="w-10 h-10 mx-auto mb-3 opacity-50" /><p className="text-sm">No distributions executed yet</p></div></GlassCard>
      ) : (
        <div className="space-y-2">
          {distributions.map((d: any) => (
            <GlassCard key={d.id} padding="sm" data-testid={`distribution-card-${d.id}`}>
              <div className="flex items-start justify-between gap-3 flex-wrap">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold">{d.assetName || d.assetId.slice(0, 8)}</span>
                    {d.assetSymbol && <Badge variant="secondary" className="no-default-hover-elevate">{d.assetSymbol}</Badge>}
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    Date: {d.distributionDate} &middot; Per Token: {d.perTokenAmount} {d.currency}
                  </p>
                  <div className="flex flex-wrap gap-x-4 gap-y-1 mt-1.5 text-xs">
                    <span className="text-muted-foreground">Total: <span className="font-medium text-foreground">{d.totalAmount} {d.currency}</span></span>
                    <span className="text-muted-foreground">Payouts: <span className="font-medium text-foreground">{d.payoutCount}</span></span>
                    <span className="text-muted-foreground">Paid Out: <span className="font-medium text-foreground">{d.totalPaidOut}</span></span>
                    {d.waterfallPeriod && <span className="text-muted-foreground">Waterfall: <span className="font-medium text-foreground">{d.waterfallPeriod}</span></span>}
                  </div>
                </div>
              </div>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  );
}

function ReconciliationTab() {
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [reconCurrency, setReconCurrency] = useState("all");

  const { data: reconData, isLoading: reconLoading, refetch } = useQuery<any[]>({
    queryKey: ["/api/admin/reconciliation/daily", date, reconCurrency],
    queryFn: async () => {
      const params = new URLSearchParams({ date });
      if (reconCurrency !== "all") params.append("currency", reconCurrency);
      const res = await fetch(`/api/admin/reconciliation/daily?${params}`, { credentials: "include" });
      return res.json();
    },
  });

  const { data: discrepancies } = useQuery<any>({
    queryKey: ["/api/admin/finance/discrepancies", date],
    queryFn: async () => {
      const res = await fetch(`/api/admin/finance/discrepancies?date=${date}`, { credentials: "include" });
      return res.json();
    },
  });

  const handleExport = () => {
    const params = new URLSearchParams({ date });
    if (reconCurrency !== "all") params.append("currency", reconCurrency);
    window.open(`/api/admin/reconciliation/export?${params}`, "_blank");
  };

  return (
    <div className="space-y-4">
      {discrepancies?.hasDiscrepancies && (
        <GlassCard padding="sm">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-destructive">Discrepancies Detected</p>
              <div className="mt-1 space-y-1">
                {discrepancies.flags.map((f: any, i: number) => (
                  <p key={i} className="text-xs text-muted-foreground">
                    <span className="font-medium text-foreground">{f.currency}</span>: Ledger {f.ledgerBalance.toFixed(2)} vs Wallet {f.walletBalance.toFixed(2)} (diff: {f.discrepancy.toFixed(2)})
                    <Badge variant={f.severity === "critical" ? "destructive" : "secondary"} className="ml-2 no-default-hover-elevate">{f.severity}</Badge>
                  </p>
                ))}
              </div>
            </div>
          </div>
        </GlassCard>
      )}

      <div className="flex items-center gap-3 flex-wrap">
        <Input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-[180px]" data-testid="input-recon-date" />
        <Select value={reconCurrency} onValueChange={setReconCurrency}>
          <SelectTrigger className="w-[160px]" data-testid="select-recon-currency">
            <SelectValue placeholder="All Currencies" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Currencies</SelectItem>
            {WALLET_CURRENCIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button variant="outline" size="sm" onClick={() => refetch()} data-testid="button-refresh-recon">
          <RefreshCw className="w-4 h-4 mr-1" />
          Refresh
        </Button>
        <Button variant="outline" size="sm" onClick={handleExport} data-testid="button-export-recon">
          <Download className="w-4 h-4 mr-1" />
          Export CSV
        </Button>
      </div>

      {reconLoading ? (
        <div className="space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-32 rounded-md" />)}</div>
      ) : !reconData || reconData.length === 0 ? (
        <GlassCard><div className="text-center py-8 text-muted-foreground"><FileText className="w-10 h-10 mx-auto mb-3 opacity-50" /><p className="text-sm">No reconciliation data for this date</p></div></GlassCard>
      ) : (
        <div className="space-y-3">
          {reconData.map((d: any, i: number) => (
            <GlassCard key={i} padding="md" data-testid={`recon-card-${d.currency}`}>
              <div className="flex items-center justify-between gap-3 mb-3 flex-wrap">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold">{d.currency}</span>
                  <span className="text-xs text-muted-foreground">{d.date}</span>
                </div>
                {d.hasDiscrepancy ? (
                  <Badge variant="destructive" className="no-default-hover-elevate">
                    <AlertTriangle className="w-3 h-3 mr-1" />
                    Discrepancy: {d.discrepancy.toFixed(2)}
                  </Badge>
                ) : (
                  <Badge variant="default" className="no-default-hover-elevate">
                    <CheckCircle2 className="w-3 h-3 mr-1" />
                    Balanced
                  </Badge>
                )}
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div><span className="text-muted-foreground">Deposits:</span> <span className="font-medium">{d.deposits.count} ({d.deposits.total.toFixed(2)})</span></div>
                <div><span className="text-muted-foreground">Withdrawals:</span> <span className="font-medium">{d.withdrawals.count} ({d.withdrawals.total.toFixed(2)})</span></div>
                <div><span className="text-muted-foreground">FX In:</span> <span className="font-medium">{d.fxConversionsIn.count} ({d.fxConversionsIn.total.toFixed(2)})</span></div>
                <div><span className="text-muted-foreground">FX Out:</span> <span className="font-medium">{d.fxConversionsOut.count} ({d.fxConversionsOut.total.toFixed(2)})</span></div>
                <div><span className="text-muted-foreground">Investments:</span> <span className="font-medium">{d.investments.count} ({d.investments.total.toFixed(2)})</span></div>
                <div><span className="text-muted-foreground">Dividends:</span> <span className="font-medium">{d.dividends.count} ({d.dividends.total.toFixed(2)})</span></div>
                <div><span className="text-muted-foreground">Fees:</span> <span className="font-medium">{d.fees.count} ({d.fees.total.toFixed(2)})</span></div>
                <div><span className="text-muted-foreground">Net Flow:</span> <span className="font-medium">{d.netFlow.toFixed(2)}</span></div>
              </div>
              <div className="mt-2 pt-2 border-t flex justify-between text-xs">
                <span className="text-muted-foreground">Ledger Balance: <span className="font-medium text-foreground">{d.ledgerBalance.toFixed(2)}</span></span>
                <span className="text-muted-foreground">Wallet Balance: <span className="font-medium text-foreground">{d.walletBalance.toFixed(2)}</span></span>
              </div>
            </GlassCard>
          ))}
        </div>
      )}
    </div>
  );
}

export default function AdminFinance() {
  const { toast } = useToast();
  const [reviewAccount, setReviewAccount] = useState<BankAccountWithUser | null>(null);
  const [rejectNotes, setRejectNotes] = useState("");
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [withdrawalFilter, setWithdrawalFilter] = useState<string>("all");
  const [currencyFilter, setCurrencyFilter] = useState<string>("all");
  const [declineTarget, setDeclineTarget] = useState<WithdrawalWithUser | null>(null);
  const [declineNotes, setDeclineNotes] = useState("");
  const [showDeclineDialog, setShowDeclineDialog] = useState(false);
  const [paidTarget, setPaidTarget] = useState<WithdrawalWithUser | null>(null);
  const [payoutRef, setPayoutRef] = useState("");
  const [showPaidDialog, setShowPaidDialog] = useState(false);

  const { data: bankAccounts, isLoading: bankLoading } = useQuery<BankAccountWithUser[]>({
    queryKey: ["/api/admin/bank-accounts"],
  });

  const { data: withdrawals, isLoading: withdrawalLoading } = useQuery<WithdrawalWithUser[]>({
    queryKey: ["/api/admin/withdrawals"],
  });

  const withdrawalReviewMutation = useMutation({
    mutationFn: async ({ id, action, notes }: { id: string; action: "approve" | "decline"; notes?: string }) => {
      const res = await apiRequest("POST", `/api/admin/withdrawals/${id}/review`, { action, notes });
      return res.json();
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/withdrawals"] });
      setShowDeclineDialog(false);
      setDeclineTarget(null);
      setDeclineNotes("");
      toast({
        title: variables.action === "approve" ? "Withdrawal Approved" : "Withdrawal Declined",
        description: variables.action === "approve"
          ? "The withdrawal has been approved. Ledger entries created."
          : "The withdrawal has been declined. The investor has been notified.",
      });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to process withdrawal", variant: "destructive" });
    },
  });

  const markPaidMutation = useMutation({
    mutationFn: async ({ id, payoutReference }: { id: string; payoutReference: string }) => {
      const res = await apiRequest("POST", `/api/admin/withdrawals/${id}/paid`, { payoutReference });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/withdrawals"] });
      setShowPaidDialog(false);
      setPaidTarget(null);
      setPayoutRef("");
      toast({ title: "Withdrawal Marked as Paid", description: "Payout reference saved. The investor has been notified." });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to mark as paid", variant: "destructive" });
    },
  });

  const verifyMutation = useMutation({
    mutationFn: async ({ id, action, notes }: { id: string; action: "verify" | "reject"; notes?: string }) => {
      const res = await apiRequest("POST", `/api/admin/bank-accounts/${id}/verify`, { action, notes });
      return res.json();
    },
    onSuccess: (_data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/bank-accounts"] });
      setReviewAccount(null);
      setShowRejectDialog(false);
      setRejectNotes("");
      toast({
        title: variables.action === "verify" ? "Bank Account Verified" : "Bank Account Rejected",
        description: variables.action === "verify"
          ? "The bank account has been verified."
          : "The bank account has been rejected.",
      });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to process verification", variant: "destructive" });
    },
  });

  const handleExportWithdrawals = () => window.open("/api/admin/finance/withdrawals/export", "_blank");

  const relevantWithdrawals = currencyFilter === "all" ? (withdrawals || []) : (withdrawals || []).filter(w => w.currency === currencyFilter);
  const relevantBankAccounts = currencyFilter === "all" ? (bankAccounts || []) : (bankAccounts || []).filter(a => a.currency === currencyFilter);

  const totalDepositsPending = relevantBankAccounts.filter(a => a.status === "pending").length;
  const totalWithdrawalAmount = relevantWithdrawals
    .filter(w => w.status === "APPROVED" || w.status === "PAID")
    .reduce((sum, w) => sum + parseFloat(w.amount), 0);
  const requestedWithdrawals = relevantWithdrawals.filter(w => w.status === "REQUESTED").length;
  const paidWithdrawals = relevantWithdrawals.filter(w => w.status === "PAID").length;

  const filteredAccounts = bankAccounts?.filter(a => {
    if (currencyFilter !== "all" && a.currency !== currencyFilter) return false;
    if (filterStatus === "all") return true;
    return a.status === filterStatus;
  }) || [];

  const pendingCount = bankAccounts?.filter(a => a.status === "pending").length || 0;
  const verifiedCount = bankAccounts?.filter(a => a.status === "verified").length || 0;
  const rejectedCount = bankAccounts?.filter(a => a.status === "rejected").length || 0;

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle title="Finance Console" description="Deposits, withdrawals, crypto approvals, FX monitoring, distributions, and reconciliation" />
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <Select value={currencyFilter} onValueChange={setCurrencyFilter}>
            <SelectTrigger className="w-[160px]" data-testid="select-currency-filter">
              <SelectValue placeholder="All Currencies" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Currencies</SelectItem>
              {WALLET_CURRENCIES.map(cur => (
                <SelectItem key={cur} value={cur}>{CURRENCY_DETAILS[cur].symbol} {cur}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Tabs defaultValue="deposits" className="w-full">
          <TabsList className="flex flex-wrap gap-1 h-auto" data-testid="finance-tabs">
            <TabsTrigger value="deposits" data-testid="tab-deposits">Deposits</TabsTrigger>
            <TabsTrigger value="withdrawals" data-testid="tab-withdrawals">Withdrawals</TabsTrigger>
            <TabsTrigger value="crypto" data-testid="tab-crypto">Crypto Approvals</TabsTrigger>
            <TabsTrigger value="fx" data-testid="tab-fx">FX Monitor</TabsTrigger>
            <TabsTrigger value="distributions" data-testid="tab-distributions">Distributions</TabsTrigger>
            <TabsTrigger value="reconciliation" data-testid="tab-reconciliation">Reconciliation</TabsTrigger>
          </TabsList>

          <TabsContent value="deposits" className="mt-4">
            <DepositsTab currencyFilter={currencyFilter} />
          </TabsContent>

          <TabsContent value="withdrawals" className="mt-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-3 flex-wrap">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 flex-1">
                  <StatTile label="Pending Bank Reviews" value={String(totalDepositsPending)} icon={<Building2 className="w-5 h-5" />} />
                  <StatTile label="Requested Withdrawals" value={String(requestedWithdrawals)} icon={<Clock className="w-5 h-5" />} />
                  <StatTile label="Total Withdrawals" value={currencyFilter !== "all" ? formatCurrency(totalWithdrawalAmount, currencyFilter) : String(relevantWithdrawals.filter(w => w.status === "APPROVED" || w.status === "PAID").length)} icon={<ArrowUpRight className="w-5 h-5" />} />
                  <StatTile label="Paid Out" value={String(paidWithdrawals)} icon={<Banknote className="w-5 h-5" />} />
                </div>
                <Button variant="outline" size="sm" onClick={handleExportWithdrawals} data-testid="button-export-withdrawals">
                  <Download className="w-4 h-4 mr-1" />
                  Export CSV
                </Button>
              </div>

              <Section
                title="Bank Account Verification"
                description={`${pendingCount} account(s) awaiting verification`}
                action={
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {["all", "pending", "verified", "rejected"].map((status) => {
                      const count = status === "all" ? (bankAccounts?.length || 0) : status === "pending" ? pendingCount : status === "verified" ? verifiedCount : rejectedCount;
                      return (
                        <Button key={status} variant={filterStatus === status ? "default" : "outline"} size="sm" onClick={() => setFilterStatus(status)} data-testid={`filter-bank-${status}`}>
                          {status.charAt(0).toUpperCase() + status.slice(1)} ({count})
                        </Button>
                      );
                    })}
                  </div>
                }
              >
                {bankLoading ? (
                  <div className="space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-28 rounded-md" />)}</div>
                ) : filteredAccounts.length === 0 ? (
                  <GlassCard data-testid="empty-bank-verification">
                    <div className="text-center py-8 text-muted-foreground">
                      <Building2 className="w-10 h-10 mx-auto mb-3 opacity-50" />
                      <p className="text-sm">No bank accounts {filterStatus !== "all" ? `with status "${filterStatus}"` : "submitted yet"}</p>
                    </div>
                  </GlassCard>
                ) : (
                  <div className="space-y-3">
                    {filteredAccounts.map((account) => {
                      const statusCfg = STATUS_CONFIG[account.status] || STATUS_CONFIG.pending;
                      const StatusIcon = statusCfg.icon;
                      return (
                        <GlassCard key={account.id} padding="md" data-testid={`admin-bank-card-${account.id}`}>
                          <div className="flex items-start justify-between gap-3 flex-wrap">
                            <div className="flex items-start gap-3 min-w-0 flex-1">
                              <div className="w-9 h-9 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                                <Building2 className="w-5 h-5 text-primary" />
                              </div>
                              <div className="min-w-0">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <p className="text-sm font-semibold" data-testid={`admin-bank-label-${account.id}`}>{account.label}</p>
                                  <Badge variant={statusCfg.variant} className="no-default-hover-elevate" data-testid={`admin-bank-status-${account.id}`}>
                                    <StatusIcon className="w-3 h-3 mr-1" />
                                    {statusCfg.label}
                                  </Badge>
                                </div>
                                <p className="text-xs text-muted-foreground mt-0.5">
                                  {account.user?.fullName || "Unknown"} ({account.user?.username || "?"}) &middot; {account.bankName}
                                </p>
                                <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-xs">
                                  <span className="text-muted-foreground">Country: <span className="font-medium text-foreground">{account.country}</span></span>
                                  <span className="text-muted-foreground">Currency: <span className="font-medium text-foreground">{account.currency}</span></span>
                                  {account.iban && <span className="text-muted-foreground">IBAN: <span className="font-medium text-foreground" data-testid={`admin-bank-iban-${account.id}`}>{account.iban}</span></span>}
                                  {account.accountNumber && <span className="text-muted-foreground">Acc#: <span className="font-medium text-foreground" data-testid={`admin-bank-accnum-${account.id}`}>{account.accountNumber}</span></span>}
                                  {account.branchCode && <span className="text-muted-foreground">Branch: <span className="font-medium text-foreground">{account.branchCode}</span></span>}
                                  {account.swiftCode && <span className="text-muted-foreground">SWIFT: <span className="font-medium text-foreground">{account.swiftCode}</span></span>}
                                  <span className="text-muted-foreground">Holder: <span className="font-medium text-foreground">{account.accountHolderName}</span></span>
                                </div>
                                {account.verificationNotes && (
                                  <p className="text-xs text-muted-foreground mt-1.5 italic">Notes: {account.verificationNotes}</p>
                                )}
                              </div>
                            </div>
                            {account.status === "pending" && (
                              <div className="flex items-center gap-1.5 flex-shrink-0">
                                <Button size="sm" onClick={() => verifyMutation.mutate({ id: account.id, action: "verify" })} disabled={verifyMutation.isPending} data-testid={`button-verify-bank-${account.id}`}>
                                  <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                                  Verify
                                </Button>
                                <Button size="sm" variant="outline" onClick={() => { setReviewAccount(account); setShowRejectDialog(true); setRejectNotes(""); }} disabled={verifyMutation.isPending} data-testid={`button-reject-bank-${account.id}`}>
                                  <XCircle className="w-3.5 h-3.5 mr-1" />
                                  Reject
                                </Button>
                              </div>
                            )}
                          </div>
                        </GlassCard>
                      );
                    })}
                  </div>
                )}
              </Section>

              <Section
                title="Withdrawal Requests"
                description={`${withdrawals?.filter(w => w.status === "REQUESTED").length || 0} pending review`}
                action={
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {["all", "REQUESTED", "APPROVED", "DECLINED", "PAID"].map((status) => {
                      const count = status === "all" ? (withdrawals?.length || 0) : (withdrawals?.filter(w => w.status === status).length || 0);
                      return (
                        <Button key={status} variant={withdrawalFilter === status ? "default" : "outline"} size="sm" onClick={() => setWithdrawalFilter(status)} data-testid={`filter-withdrawal-${status}`}>
                          {status === "all" ? "All" : WITHDRAWAL_STATUS_CONFIG[status]?.label || status} ({count})
                        </Button>
                      );
                    })}
                  </div>
                }
              >
                {withdrawalLoading ? (
                  <div className="space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-28 rounded-md" />)}</div>
                ) : (() => {
                  const filtered = (withdrawals || []).filter(w => (withdrawalFilter === "all" || w.status === withdrawalFilter) && (currencyFilter === "all" || w.currency === currencyFilter));
                  return filtered.length === 0 ? (
                    <GlassCard data-testid="empty-withdrawals">
                      <div className="text-center py-8 text-muted-foreground">
                        <Send className="w-10 h-10 mx-auto mb-3 opacity-50" />
                        <p className="text-sm">No withdrawal requests {withdrawalFilter !== "all" ? `with status "${withdrawalFilter}"` : "yet"}</p>
                      </div>
                    </GlassCard>
                  ) : (
                    <div className="space-y-3">
                      {filtered.map((wr) => {
                        const statusCfg = WITHDRAWAL_STATUS_CONFIG[wr.status] || WITHDRAWAL_STATUS_CONFIG.REQUESTED;
                        const StatusIcon = statusCfg.icon;
                        return (
                          <GlassCard key={wr.id} padding="md" data-testid={`admin-withdrawal-card-${wr.id}`}>
                            <div className="flex items-start justify-between gap-3 flex-wrap">
                              <div className="flex items-start gap-3 min-w-0 flex-1">
                                <div className="w-9 h-9 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                                  <Send className="w-5 h-5 text-primary" />
                                </div>
                                <div className="min-w-0">
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <p className="text-sm font-semibold" data-testid={`admin-withdrawal-amount-${wr.id}`}>
                                      {formatCurrency(wr.amount, wr.currency)}
                                    </p>
                                    <Badge variant={statusCfg.variant} className="no-default-hover-elevate" data-testid={`admin-withdrawal-status-${wr.id}`}>
                                      <StatusIcon className="w-3 h-3 mr-1" />
                                      {statusCfg.label}
                                    </Badge>
                                  </div>
                                  <p className="text-xs text-muted-foreground mt-0.5">
                                    {wr.user?.fullName || "Unknown"} ({wr.user?.username || "?"}) &middot; {formatDate(wr.requestedAt)}
                                  </p>
                                  <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-xs">
                                    <span className="text-muted-foreground">Fee: <span className="font-medium text-foreground">{formatCurrency(wr.fee, wr.currency)}</span></span>
                                    <span className="text-muted-foreground">Net: <span className="font-medium text-foreground">{formatCurrency(wr.netAmount, wr.currency)}</span></span>
                                    <span className="text-muted-foreground">Bank: <span className="font-medium text-foreground">{wr.bankAccount?.label || "N/A"} ({wr.bankAccount?.bankName || ""})</span></span>
                                    {wr.bankAccount?.iban && <span className="text-muted-foreground">IBAN: <span className="font-medium text-foreground">{wr.bankAccount.iban}</span></span>}
                                  </div>
                                  {wr.reviewNotes && <p className="text-xs text-muted-foreground mt-1.5 italic">Notes: {wr.reviewNotes}</p>}
                                  {wr.payoutReference && <p className="text-xs text-muted-foreground mt-1">Payout Ref: <span className="font-medium text-foreground">{wr.payoutReference}</span></p>}
                                </div>
                              </div>
                              <div className="flex items-center gap-1.5 flex-shrink-0">
                                {wr.status === "REQUESTED" && (
                                  <>
                                    <Button size="sm" onClick={() => withdrawalReviewMutation.mutate({ id: wr.id, action: "approve" })} disabled={withdrawalReviewMutation.isPending} data-testid={`button-approve-withdrawal-${wr.id}`}>
                                      <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                                      Approve
                                    </Button>
                                    <Button size="sm" variant="outline" onClick={() => { setDeclineTarget(wr); setShowDeclineDialog(true); setDeclineNotes(""); }} disabled={withdrawalReviewMutation.isPending} data-testid={`button-decline-withdrawal-${wr.id}`}>
                                      <XCircle className="w-3.5 h-3.5 mr-1" />
                                      Decline
                                    </Button>
                                  </>
                                )}
                                {wr.status === "APPROVED" && (
                                  <Button size="sm" onClick={() => { setPaidTarget(wr); setShowPaidDialog(true); setPayoutRef(""); }} disabled={markPaidMutation.isPending} data-testid={`button-mark-paid-${wr.id}`}>
                                    <Banknote className="w-3.5 h-3.5 mr-1" />
                                    Mark Paid
                                  </Button>
                                )}
                              </div>
                            </div>
                          </GlassCard>
                        );
                      })}
                    </div>
                  );
                })()}
              </Section>
            </div>
          </TabsContent>

          <TabsContent value="crypto" className="mt-4">
            <CryptoApprovalsTab />
          </TabsContent>

          <TabsContent value="fx" className="mt-4">
            <FxMonitorTab />
          </TabsContent>

          <TabsContent value="distributions" className="mt-4">
            <DistributionsTab />
          </TabsContent>

          <TabsContent value="reconciliation" className="mt-4">
            <ReconciliationTab />
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={showDeclineDialog} onOpenChange={(open) => { if (!open) { setShowDeclineDialog(false); setDeclineTarget(null); } }}>
        <DialogContent data-testid="decline-withdrawal-dialog">
          <DialogHeader>
            <DialogTitle>Decline Withdrawal</DialogTitle>
            <DialogDescription>
              Declining withdrawal of {declineTarget ? formatCurrency(declineTarget.amount, declineTarget.currency) : ""} from {declineTarget?.user?.fullName}. The investor will be notified.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Reason (Optional)</label>
              <Textarea placeholder="Provide a reason for declining..." value={declineNotes} onChange={(e) => setDeclineNotes(e.target.value)} data-testid="input-decline-notes" />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => { setShowDeclineDialog(false); setDeclineTarget(null); }}>Cancel</Button>
              <Button variant="destructive" onClick={() => { if (declineTarget) withdrawalReviewMutation.mutate({ id: declineTarget.id, action: "decline", notes: declineNotes || undefined }); }} disabled={withdrawalReviewMutation.isPending} data-testid="button-confirm-decline">
                {withdrawalReviewMutation.isPending ? "Declining..." : "Decline Withdrawal"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showPaidDialog} onOpenChange={(open) => { if (!open) { setShowPaidDialog(false); setPaidTarget(null); } }}>
        <DialogContent data-testid="mark-paid-dialog">
          <DialogHeader>
            <DialogTitle>Mark as Paid</DialogTitle>
            <DialogDescription>
              Record the payout reference for {paidTarget ? formatCurrency(paidTarget.netAmount, paidTarget.currency) : ""} to {paidTarget?.user?.fullName}.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Payout Reference</label>
              <Input placeholder="e.g. WIRE-2026-02-13-001" value={payoutRef} onChange={(e) => setPayoutRef(e.target.value)} data-testid="input-payout-reference" />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => { setShowPaidDialog(false); setPaidTarget(null); }}>Cancel</Button>
              <Button onClick={() => { if (paidTarget) markPaidMutation.mutate({ id: paidTarget.id, payoutReference: payoutRef }); }} disabled={!payoutRef.trim() || markPaidMutation.isPending} data-testid="button-confirm-paid">
                {markPaidMutation.isPending ? "Processing..." : "Confirm Paid"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showRejectDialog} onOpenChange={(open) => { if (!open) { setShowRejectDialog(false); setReviewAccount(null); } }}>
        <DialogContent data-testid="reject-bank-dialog">
          <DialogHeader>
            <DialogTitle>Reject Bank Account</DialogTitle>
            <DialogDescription>
              Rejecting "{reviewAccount?.label}" for {reviewAccount?.user?.fullName}. The investor will be notified.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Rejection Reason (Optional)</label>
              <Textarea placeholder="Provide a reason for rejection..." value={rejectNotes} onChange={(e) => setRejectNotes(e.target.value)} data-testid="input-reject-notes" />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => { setShowRejectDialog(false); setReviewAccount(null); }} data-testid="button-cancel-reject">Cancel</Button>
              <Button variant="destructive" onClick={() => { if (reviewAccount) verifyMutation.mutate({ id: reviewAccount.id, action: "reject", notes: rejectNotes || undefined }); }} disabled={verifyMutation.isPending} data-testid="button-confirm-reject">
                {verifyMutation.isPending ? "Rejecting..." : "Reject Account"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </RoleLayout>
  );
}
