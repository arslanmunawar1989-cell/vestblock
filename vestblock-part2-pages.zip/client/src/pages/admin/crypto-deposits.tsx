import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { CryptoDepositIntent } from "@shared/schema";
import {
  CheckCircle2,
  XCircle,
  Clock,
  AlertCircle,
  ArrowDownLeft,
  Search,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Lock,
  Unlock,
  AlertTriangle, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface UserInfo {
  id: string;
  username: string;
  fullName: string;
}

const STATUS_CONFIG: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline"; icon: any }> = {
  CREATED: { label: "Awaiting Payment", variant: "outline", icon: Clock },
  PENDING: { label: "Pending", variant: "secondary", icon: AlertCircle },
  CONFIRMED: { label: "Confirmed", variant: "default", icon: CheckCircle2 },
  REJECTED: { label: "Rejected", variant: "destructive", icon: XCircle },
  EXPIRED: { label: "Expired", variant: "secondary", icon: Clock },
  AML_HOLD: { label: "AML Hold", variant: "destructive", icon: ShieldAlert },
};

const AML_STATUS_CONFIG: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  CLEAR: { label: "Clear", variant: "default" },
  FLAGGED: { label: "Flagged", variant: "destructive" },
  HOLD: { label: "Hold", variant: "destructive" },
  CLEARED: { label: "Cleared", variant: "outline" },
};

export default function AdminCryptoDeposits() {
  const { toast } = useToast();
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [confirmDialog, setConfirmDialog] = useState<CryptoDepositIntent | null>(null);
  const [rejectDialog, setRejectDialog] = useState<CryptoDepositIntent | null>(null);
  const [holdDialog, setHoldDialog] = useState<CryptoDepositIntent | null>(null);
  const [releaseDialog, setReleaseDialog] = useState<CryptoDepositIntent | null>(null);
  const [txHash, setTxHash] = useState("");
  const [confirmations, setConfirmations] = useState(0);
  const [convertToAed, setConvertToAed] = useState(false);
  const [rejectReason, setRejectReason] = useState("");
  const [holdReason, setHoldReason] = useState("");
  const [releaseNotes, setReleaseNotes] = useState("");

  const { data: intents, isLoading } = useQuery<CryptoDepositIntent[]>({
    queryKey: ["/api/admin/crypto/deposit-intents"],
  });

  const { data: users } = useQuery<UserInfo[]>({
    queryKey: ["/api/users"],
  });

  const confirmMutation = useMutation({
    mutationFn: async ({ id, txHash, confirmations, convertToAed }: { id: string; txHash: string; confirmations: number; convertToAed: boolean }) => {
      const res = await apiRequest("POST", `/api/admin/crypto/deposit-intents/${id}/confirm`, { txHash, confirmations, convertToAed });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/crypto/deposit-intents"] });
      setConfirmDialog(null);
      setTxHash("");
      setConfirmations(0);
      setConvertToAed(false);
      toast({ title: "Deposit confirmed", description: "Wallet has been credited successfully." });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to confirm deposit", variant: "destructive" });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async ({ id, reason }: { id: string; reason: string }) => {
      const res = await apiRequest("POST", `/api/admin/crypto/deposit-intents/${id}/reject`, { reason });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/crypto/deposit-intents"] });
      setRejectDialog(null);
      setRejectReason("");
      toast({ title: "Deposit rejected" });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to reject deposit", variant: "destructive" });
    },
  });

  const holdMutation = useMutation({
    mutationFn: async ({ id, reason }: { id: string; reason: string }) => {
      const res = await apiRequest("POST", `/api/admin/crypto/deposit-intents/${id}/hold`, { reason });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/crypto/deposit-intents"] });
      setHoldDialog(null);
      setHoldReason("");
      toast({ title: "Deposit placed on AML hold" });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to hold deposit", variant: "destructive" });
    },
  });

  const releaseMutation = useMutation({
    mutationFn: async ({ id, notes }: { id: string; notes: string }) => {
      const res = await apiRequest("POST", `/api/admin/crypto/deposit-intents/${id}/release`, { notes });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/crypto/deposit-intents"] });
      setReleaseDialog(null);
      setReleaseNotes("");
      toast({ title: "AML hold released", description: "Deposit is now available for confirmation." });
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err.message || "Failed to release deposit", variant: "destructive" });
    },
  });

  const getUserName = (userId: string) => {
    const user = users?.find(u => u.id === userId);
    return user?.fullName || user?.username || userId.slice(0, 8);
  };

  const filteredIntents = intents?.filter(intent => {
    if (statusFilter !== "all" && intent.status !== statusFilter) return false;
    if (searchTerm) {
      const userName = getUserName(intent.userId).toLowerCase();
      const search = searchTerm.toLowerCase();
      return (
        userName.includes(search) ||
        intent.chainId.toLowerCase().includes(search) ||
        intent.tokenSymbol.toLowerCase().includes(search) ||
        intent.invoiceAddress.toLowerCase().includes(search) ||
        (intent.txHash && intent.txHash.toLowerCase().includes(search))
      );
    }
    return true;
  }) || [];

  const pendingCount = intents?.filter(i => i.status === "CREATED" || i.status === "PENDING").length || 0;
  const confirmedCount = intents?.filter(i => i.status === "CONFIRMED").length || 0;
  const amlHoldCount = intents?.filter(i => i.status === "AML_HOLD").length || 0;
  const totalAmount = intents?.filter(i => i.status === "CONFIRMED").reduce((sum, i) => sum + parseFloat(i.amount), 0) || 0;

  const getAmlFlags = (intent: CryptoDepositIntent): any[] => {
    if (!intent.amlFlags) return [];
    if (Array.isArray(intent.amlFlags)) return intent.amlFlags;
    return [];
  };

  return (
    <RoleLayout role="admin">
      <div className="p-4 md:p-6 space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle title="Crypto Deposits" description="Review and confirm crypto deposit intents" />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <GlassCard className="p-4">
            <p className="text-sm text-muted-foreground">Pending Deposits</p>
            <p className="text-2xl font-bold" data-testid="text-pending-count">{pendingCount}</p>
          </GlassCard>
          <GlassCard className="p-4">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-destructive" />
              <p className="text-sm text-muted-foreground">AML Holds</p>
            </div>
            <p className="text-2xl font-bold text-destructive" data-testid="text-aml-hold-count">{amlHoldCount}</p>
          </GlassCard>
          <GlassCard className="p-4">
            <p className="text-sm text-muted-foreground">Confirmed Deposits</p>
            <p className="text-2xl font-bold" data-testid="text-confirmed-count">{confirmedCount}</p>
          </GlassCard>
          <GlassCard className="p-4">
            <p className="text-sm text-muted-foreground">Total Confirmed (USD)</p>
            <p className="text-2xl font-bold" data-testid="text-total-amount">${totalAmount.toLocaleString()}</p>
          </GlassCard>
        </div>

        <div className="flex items-center gap-4 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by user, chain, token, address..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
              data-testid="input-search"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[180px]" data-testid="select-status-filter">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="CREATED">Awaiting Payment</SelectItem>
              <SelectItem value="PENDING">Pending</SelectItem>
              <SelectItem value="AML_HOLD">AML Hold</SelectItem>
              <SelectItem value="CONFIRMED">Confirmed</SelectItem>
              <SelectItem value="REJECTED">Rejected</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-32 w-full" />)}
          </div>
        ) : filteredIntents.length > 0 ? (
          <Section title={`Deposits (${filteredIntents.length})`}>
            <div className="grid gap-4">
              {filteredIntents.map(intent => {
                const statusCfg = STATUS_CONFIG[intent.status] || STATUS_CONFIG.CREATED;
                const StatusIcon = statusCfg.icon;
                const canConfirm = intent.status === "CREATED" || intent.status === "PENDING";
                const canHold = intent.status === "CREATED" || intent.status === "PENDING";
                const canRelease = intent.status === "AML_HOLD";
                const canReject = intent.status !== "CONFIRMED" && intent.status !== "REJECTED";
                const flags = getAmlFlags(intent);
                const amlCfg = AML_STATUS_CONFIG[intent.amlStatus as string] || AML_STATUS_CONFIG.CLEAR;
                const hasRisk = intent.amlStatus !== "CLEAR" || flags.length > 0;
                return (
                  <GlassCard key={intent.id} className="p-4">
                    <div className="flex items-start justify-between gap-4 flex-wrap">
                      <div className="space-y-1 min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-semibold" data-testid={`text-user-${intent.id}`}>
                            {getUserName(intent.userId)}
                          </span>
                          <Badge variant="outline">{intent.chainId}</Badge>
                          <Badge variant="outline">{intent.tokenSymbol}</Badge>
                          <Badge variant={statusCfg.variant} data-testid={`badge-status-${intent.id}`}>
                            <StatusIcon className="w-3 h-3 mr-1" />
                            {statusCfg.label}
                          </Badge>
                          {intent.amlStatus && intent.amlStatus !== "CLEAR" && (
                            <Badge variant={amlCfg.variant} data-testid={`badge-aml-${intent.id}`}>
                              <Shield className="w-3 h-3 mr-1" />
                              AML: {amlCfg.label}
                            </Badge>
                          )}
                        </div>
                        <p className="text-xl font-bold" data-testid={`text-amount-${intent.id}`}>
                          {parseFloat(intent.amount).toLocaleString()} {intent.tokenSymbol}
                        </p>
                        <p className="text-xs text-muted-foreground truncate">
                          Invoice: {intent.invoiceAddress}
                        </p>
                        {intent.memo && (
                          <p className="text-xs text-muted-foreground">Memo: {intent.memo}</p>
                        )}
                        {intent.txHash && (
                          <p className="text-xs text-muted-foreground">
                            TX: {intent.txHash}
                          </p>
                        )}
                        {intent.status === "CONFIRMED" && (
                          <p className="text-xs text-muted-foreground">
                            Confirmations: {intent.confirmations}/{intent.requiredConfirmations}
                            {intent.convertToAed && " | Converted to AED"}
                          </p>
                        )}
                        <p className="text-xs text-muted-foreground">
                          Created: {new Date(intent.createdAt).toLocaleString()}
                          {intent.confirmedAt && ` | Confirmed: ${new Date(intent.confirmedAt).toLocaleString()}`}
                        </p>
                        {intent.adminNotes && (
                          <p className="text-xs text-muted-foreground">Notes: {intent.adminNotes}</p>
                        )}

                        {hasRisk && (
                          <div className="mt-2 p-2 rounded-md bg-destructive/10 border border-destructive/20 space-y-1" data-testid={`aml-risk-panel-${intent.id}`}>
                            <div className="flex items-center gap-1">
                              <AlertTriangle className="w-3 h-3 text-destructive" />
                              <span className="text-xs font-semibold text-destructive">Risk Indicators</span>
                            </div>
                            {intent.holdReason && (
                              <p className="text-xs text-destructive/80" data-testid={`text-hold-reason-${intent.id}`}>
                                {intent.holdReason}
                              </p>
                            )}
                            {flags.map((flag: any, idx: number) => (
                              <div key={idx} className="flex items-center gap-1">
                                <Badge variant="destructive" className="text-[10px]" data-testid={`badge-flag-${intent.id}-${idx}`}>
                                  {flag.type || "FLAG"}
                                </Badge>
                                <span className="text-[11px] text-muted-foreground">{flag.description}</span>
                              </div>
                            ))}
                            {intent.clearedAt && (
                              <div className="flex items-center gap-1 mt-1">
                                <ShieldCheck className="w-3 h-3 text-green-600" />
                                <span className="text-xs text-green-600">
                                  Cleared: {new Date(intent.clearedAt).toLocaleString()}
                                </span>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                      <div className="flex gap-2 flex-wrap">
                        {canRelease && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setReleaseDialog(intent)}
                            data-testid={`button-release-${intent.id}`}
                          >
                            <Unlock className="w-4 h-4 mr-1" />
                            Release
                          </Button>
                        )}
                        {canConfirm && (
                          <Button
                            size="sm"
                            onClick={() => {
                              setConfirmDialog(intent);
                              setConfirmations(intent.requiredConfirmations);
                            }}
                            data-testid={`button-confirm-${intent.id}`}
                          >
                            <CheckCircle2 className="w-4 h-4 mr-1" />
                            Confirm
                          </Button>
                        )}
                        {canHold && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setHoldDialog(intent)}
                            data-testid={`button-hold-${intent.id}`}
                          >
                            <Lock className="w-4 h-4 mr-1" />
                            Hold
                          </Button>
                        )}
                        {canReject && (
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => setRejectDialog(intent)}
                            data-testid={`button-reject-${intent.id}`}
                          >
                            <XCircle className="w-4 h-4 mr-1" />
                            Reject
                          </Button>
                        )}
                      </div>
                    </div>
                  </GlassCard>
                );
              })}
            </div>
          </Section>
        ) : (
          <GlassCard className="p-8 text-center">
            <ArrowDownLeft className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No Deposits Found</h3>
            <p className="text-sm text-muted-foreground">
              {statusFilter !== "all" ? "Try changing the filter." : "No crypto deposit intents have been created yet."}
            </p>
          </GlassCard>
        )}

        <Dialog open={!!confirmDialog} onOpenChange={() => setConfirmDialog(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Confirm Crypto Deposit</DialogTitle>
              <DialogDescription>
                Confirming will credit {confirmDialog ? parseFloat(confirmDialog.amount).toLocaleString() : ""} USD to the user's wallet.
              </DialogDescription>
            </DialogHeader>
            {confirmDialog && (
              <div className="space-y-4">
                <div className="bg-muted/50 p-3 rounded-md space-y-1">
                  <p className="text-sm"><span className="text-muted-foreground">User:</span> {getUserName(confirmDialog.userId)}</p>
                  <p className="text-sm"><span className="text-muted-foreground">Chain:</span> {confirmDialog.chainId}</p>
                  <p className="text-sm"><span className="text-muted-foreground">Token:</span> {confirmDialog.tokenSymbol}</p>
                  <p className="text-sm"><span className="text-muted-foreground">Amount:</span> {parseFloat(confirmDialog.amount).toLocaleString()} {confirmDialog.tokenSymbol}</p>
                  <p className="text-sm"><span className="text-muted-foreground">Required Confirmations:</span> {confirmDialog.requiredConfirmations}</p>
                  {confirmDialog.amlStatus === "CLEARED" && (
                    <div className="flex items-center gap-1 mt-1">
                      <ShieldCheck className="w-3 h-3 text-green-600" />
                      <span className="text-xs text-green-600">AML cleared by compliance</span>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="txHash">Transaction Hash</Label>
                  <Input
                    id="txHash"
                    placeholder="Enter blockchain transaction hash"
                    value={txHash}
                    onChange={(e) => setTxHash(e.target.value)}
                    data-testid="input-tx-hash"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmations">Confirmations</Label>
                  <Input
                    id="confirmations"
                    type="number"
                    min={0}
                    value={confirmations}
                    onChange={(e) => setConfirmations(parseInt(e.target.value) || 0)}
                    data-testid="input-confirmations"
                  />
                  {confirmations < confirmDialog.requiredConfirmations && (
                    <p className="text-xs text-destructive">
                      Minimum {confirmDialog.requiredConfirmations} confirmations required
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <Checkbox
                    id="convertToAed"
                    checked={convertToAed}
                    onCheckedChange={(checked) => setConvertToAed(checked as boolean)}
                    data-testid="checkbox-convert-aed"
                  />
                  <Label htmlFor="convertToAed" className="text-sm cursor-pointer">
                    Convert to AED via FX engine after crediting
                  </Label>
                </div>

                <div className="flex gap-2">
                  <Button
                    className="flex-1"
                    disabled={!txHash || confirmations < confirmDialog.requiredConfirmations || confirmMutation.isPending}
                    onClick={() => confirmMutation.mutate({
                      id: confirmDialog.id,
                      txHash,
                      confirmations,
                      convertToAed,
                    })}
                    data-testid="button-submit-confirm"
                  >
                    {confirmMutation.isPending ? "Confirming..." : "Confirm Deposit"}
                  </Button>
                  <Button variant="outline" onClick={() => setConfirmDialog(null)}>
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        <Dialog open={!!rejectDialog} onOpenChange={() => setRejectDialog(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Reject Crypto Deposit</DialogTitle>
              <DialogDescription>
                Provide a reason for rejecting this deposit.
              </DialogDescription>
            </DialogHeader>
            {rejectDialog && (
              <div className="space-y-4">
                <div className="bg-muted/50 p-3 rounded-md space-y-1">
                  <p className="text-sm"><span className="text-muted-foreground">User:</span> {getUserName(rejectDialog.userId)}</p>
                  <p className="text-sm"><span className="text-muted-foreground">Amount:</span> {parseFloat(rejectDialog.amount).toLocaleString()} {rejectDialog.tokenSymbol}</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="rejectReason">Reason</Label>
                  <Textarea
                    id="rejectReason"
                    placeholder="Enter reason for rejection"
                    value={rejectReason}
                    onChange={(e) => setRejectReason(e.target.value)}
                    data-testid="input-reject-reason"
                  />
                </div>

                <div className="flex gap-2">
                  <Button
                    variant="destructive"
                    className="flex-1"
                    disabled={!rejectReason || rejectMutation.isPending}
                    onClick={() => rejectMutation.mutate({
                      id: rejectDialog.id,
                      reason: rejectReason,
                    })}
                    data-testid="button-submit-reject"
                  >
                    {rejectMutation.isPending ? "Rejecting..." : "Reject Deposit"}
                  </Button>
                  <Button variant="outline" onClick={() => setRejectDialog(null)}>
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        <Dialog open={!!holdDialog} onOpenChange={() => setHoldDialog(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Place Deposit on AML Hold</DialogTitle>
              <DialogDescription>
                This will block the deposit from being confirmed until compliance releases it.
              </DialogDescription>
            </DialogHeader>
            {holdDialog && (
              <div className="space-y-4">
                <div className="bg-muted/50 p-3 rounded-md space-y-1">
                  <p className="text-sm"><span className="text-muted-foreground">User:</span> {getUserName(holdDialog.userId)}</p>
                  <p className="text-sm"><span className="text-muted-foreground">Amount:</span> {parseFloat(holdDialog.amount).toLocaleString()} {holdDialog.tokenSymbol}</p>
                  <p className="text-sm"><span className="text-muted-foreground">Chain:</span> {holdDialog.chainId}</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="holdReason">Hold Reason</Label>
                  <Textarea
                    id="holdReason"
                    placeholder="Enter reason for compliance hold"
                    value={holdReason}
                    onChange={(e) => setHoldReason(e.target.value)}
                    data-testid="input-hold-reason"
                  />
                </div>

                <div className="flex gap-2">
                  <Button
                    className="flex-1"
                    disabled={!holdReason || holdMutation.isPending}
                    onClick={() => holdMutation.mutate({
                      id: holdDialog.id,
                      reason: holdReason,
                    })}
                    data-testid="button-submit-hold"
                  >
                    <Lock className="w-4 h-4 mr-1" />
                    {holdMutation.isPending ? "Holding..." : "Place on Hold"}
                  </Button>
                  <Button variant="outline" onClick={() => setHoldDialog(null)}>
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        <Dialog open={!!releaseDialog} onOpenChange={() => setReleaseDialog(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Release AML Hold</DialogTitle>
              <DialogDescription>
                This will clear the AML hold and allow the deposit to be confirmed.
              </DialogDescription>
            </DialogHeader>
            {releaseDialog && (
              <div className="space-y-4">
                <div className="bg-muted/50 p-3 rounded-md space-y-1">
                  <p className="text-sm"><span className="text-muted-foreground">User:</span> {getUserName(releaseDialog.userId)}</p>
                  <p className="text-sm"><span className="text-muted-foreground">Amount:</span> {parseFloat(releaseDialog.amount).toLocaleString()} {releaseDialog.tokenSymbol}</p>
                  {releaseDialog.holdReason && (
                    <div className="mt-1">
                      <p className="text-xs text-muted-foreground">Original hold reason:</p>
                      <p className="text-sm text-destructive">{releaseDialog.holdReason}</p>
                    </div>
                  )}
                  {getAmlFlags(releaseDialog).length > 0 && (
                    <div className="mt-1 space-y-1">
                      <p className="text-xs text-muted-foreground">AML Flags:</p>
                      {getAmlFlags(releaseDialog).map((flag: any, idx: number) => (
                        <Badge key={idx} variant="destructive" className="text-[10px] mr-1">
                          {flag.type || "FLAG"}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="releaseNotes">Compliance Notes</Label>
                  <Textarea
                    id="releaseNotes"
                    placeholder="Enter compliance clearance notes"
                    value={releaseNotes}
                    onChange={(e) => setReleaseNotes(e.target.value)}
                    data-testid="input-release-notes"
                  />
                </div>

                <div className="flex gap-2">
                  <Button
                    className="flex-1"
                    disabled={!releaseNotes || releaseMutation.isPending}
                    onClick={() => releaseMutation.mutate({
                      id: releaseDialog.id,
                      notes: releaseNotes,
                    })}
                    data-testid="button-submit-release"
                  >
                    <Unlock className="w-4 h-4 mr-1" />
                    {releaseMutation.isPending ? "Releasing..." : "Release Hold"}
                  </Button>
                  <Button variant="outline" onClick={() => setReleaseDialog(null)}>
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </RoleLayout>
  );
}
