import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Asset } from "@shared/schema";
import {
  Building2,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Users,
  Banknote,
  Gavel,
  FileText,
  Calculator,
  AlertTriangle,
  CheckCircle2,
  ArrowRight,
  Eye, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface SalePreview {
  assetId: string;
  assetName: string;
  currency: string;
  saleAmount: number;
  agentCommission: number;
  legalFees: number;
  transferTax: number;
  otherCosts: number;
  totalSellingCosts: number;
  netSaleProceeds: number;
  totalCapitalInvested: number;
  capitalGain: number;
  totalUnits: number;
  returnPerUnit: number;
  gainPerUnit: number;
  totalPayoutPerUnit: number;
  holders: {
    userId: string;
    username: string;
    fullName: string;
    units: number;
    capitalReturn: number;
    capitalGainShare: number;
    totalPayout: number;
  }[];
}

interface SaleEvent {
  id: string;
  assetId: string;
  assetName: string;
  saleAmount: string;
  currency: string;
  totalSellingCosts: string;
  netSaleProceeds: string;
  totalCapitalInvested: string;
  capitalGain: string;
  totalUnitsAtSale: string;
  returnPerUnit: string;
  gainPerUnit: string;
  totalPayoutPerUnit: string;
  status: string;
  executedAt: string | null;
  createdAt: string;
  payoutCount: number;
}

function fmt(val: number | string, decimals = 2): string {
  const n = typeof val === "string" ? parseFloat(val) : val;
  return n.toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
}

export default function AdminPropertySales() {
  const { toast } = useToast();
  const [selectedAssetId, setSelectedAssetId] = useState("");
  const [showSaleDialog, setShowSaleDialog] = useState(false);
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const [selectedSaleId, setSelectedSaleId] = useState<string | null>(null);
  const [preview, setPreview] = useState<SalePreview | null>(null);
  const [formData, setFormData] = useState({
    saleAmount: "",
    agentCommission: "0",
    legalFees: "0",
    transferTax: "0",
    otherCosts: "0",
    otherCostsDescription: "",
    notes: "",
  });

  const { data: assets, isLoading: assetsLoading } = useQuery<Asset[]>({
    queryKey: ["/api/assets"],
  });

  const { data: sales, isLoading: salesLoading } = useQuery<SaleEvent[]>({
    queryKey: ["/api/admin/property-sales"],
  });

  const { data: saleDetail } = useQuery({
    queryKey: ["/api/admin/property-sales", selectedSaleId],
    enabled: !!selectedSaleId,
  });

  const previewMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/admin/property-sales/preview", data);
      return res.json();
    },
    onSuccess: (data: SalePreview) => {
      setPreview(data);
    },
    onError: (err: any) => {
      toast({ title: "Preview failed", description: err.message, variant: "destructive" });
    },
  });

  const executeMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/admin/property-sales/execute", data);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Property sale executed", description: "All investors have been paid and units burned." });
      setShowSaleDialog(false);
      setPreview(null);
      setFormData({ saleAmount: "", agentCommission: "0", legalFees: "0", transferTax: "0", otherCosts: "0", otherCostsDescription: "", notes: "" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/property-sales"] });
      queryClient.invalidateQueries({ queryKey: ["/api/assets"] });
    },
    onError: (err: any) => {
      toast({ title: "Execution failed", description: err.message, variant: "destructive" });
    },
  });

  const activeAssets = assets?.filter(a => a.status !== "sold") || [];
  const soldSales = sales?.filter(s => s.status === "executed") || [];

  const handlePreview = () => {
    if (!selectedAssetId || !formData.saleAmount) {
      toast({ title: "Missing fields", description: "Select a property and enter the sale amount.", variant: "destructive" });
      return;
    }
    previewMutation.mutate({
      assetId: selectedAssetId,
      saleAmount: formData.saleAmount,
      agentCommission: formData.agentCommission || "0",
      legalFees: formData.legalFees || "0",
      transferTax: formData.transferTax || "0",
      otherCosts: formData.otherCosts || "0",
      otherCostsDescription: formData.otherCostsDescription,
      notes: formData.notes,
    });
  };

  const handleExecute = () => {
    if (!preview) return;
    executeMutation.mutate({
      assetId: selectedAssetId,
      saleAmount: formData.saleAmount,
      agentCommission: formData.agentCommission || "0",
      legalFees: formData.legalFees || "0",
      transferTax: formData.transferTax || "0",
      otherCosts: formData.otherCosts || "0",
      otherCostsDescription: formData.otherCostsDescription,
      notes: formData.notes,
    });
  };

  const openNewSale = () => {
    setPreview(null);
    setSelectedAssetId("");
    setFormData({ saleAmount: "", agentCommission: "0", legalFees: "0", transferTax: "0", otherCosts: "0", otherCostsDescription: "", notes: "" });
    setShowSaleDialog(true);
  };

  return (
    <RoleLayout role="admin">
      <div className="flex items-center gap-3">
        <Link href="/admin/dashboard">
          <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <PageTitle
        title="Property Sale Settlement"
        description="Record property sales, distribute proceeds, and close positions"
      />
      </div>

      <div className="space-y-6">
        <div className="flex items-center gap-3 flex-wrap">
          <Button onClick={openNewSale} data-testid="button-new-sale">
            <Gavel className="w-4 h-4 mr-2" />
            Record Property Sale
          </Button>
        </div>

        {salesLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-20 w-full" />
          </div>
        ) : soldSales.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Building2 className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground" data-testid="text-no-sales">No property sales recorded yet</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {soldSales.map((sale) => {
              const gain = parseFloat(sale.capitalGain);
              return (
                <Card key={sale.id} data-testid={`card-sale-${sale.id}`}>
                  <CardContent className="py-4">
                    <div className="flex items-center justify-between gap-3 flex-wrap">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-semibold truncate" data-testid={`text-sale-name-${sale.id}`}>{sale.assetName}</h3>
                          <Badge variant="outline" data-testid={`badge-sale-status-${sale.id}`}>
                            <CheckCircle2 className="w-3 h-3 mr-1" />
                            Settled
                          </Badge>
                          <Badge variant={gain >= 0 ? "default" : "destructive"}>
                            {gain >= 0 ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
                            {gain >= 0 ? "Gain" : "Loss"}: {sale.currency} {fmt(Math.abs(gain))}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground flex-wrap">
                          <span>Sale: {sale.currency} {fmt(sale.saleAmount)}</span>
                          <span>Net Proceeds: {sale.currency} {fmt(sale.netSaleProceeds)}</span>
                          <span>{sale.payoutCount} investors paid</span>
                          {sale.executedAt && <span>Settled {new Date(sale.executedAt).toLocaleDateString()}</span>}
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => { setSelectedSaleId(sale.id); setShowDetailDialog(true); }}
                        data-testid={`button-view-sale-${sale.id}`}
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        Details
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      <Dialog open={showSaleDialog} onOpenChange={setShowSaleDialog}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Record Property Sale</DialogTitle>
            <DialogDescription>Enter the sale details to preview and execute the settlement.</DialogDescription>
          </DialogHeader>

          {!preview ? (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1 block">Property</label>
                <Select value={selectedAssetId} onValueChange={setSelectedAssetId}>
                  <SelectTrigger data-testid="select-asset">
                    <SelectValue placeholder="Select property" />
                  </SelectTrigger>
                  <SelectContent>
                    {activeAssets.map(a => (
                      <SelectItem key={a.id} value={a.id}>{a.name} ({a.baseCurrency})</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-1 block">Sale Amount</label>
                <Input
                  type="number"
                  step="0.01"
                  placeholder="e.g. 5000000"
                  value={formData.saleAmount}
                  onChange={e => setFormData(p => ({ ...p, saleAmount: e.target.value }))}
                  data-testid="input-sale-amount"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium mb-1 block">Agent Commission</label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.agentCommission}
                    onChange={e => setFormData(p => ({ ...p, agentCommission: e.target.value }))}
                    data-testid="input-agent-commission"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Legal Fees</label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.legalFees}
                    onChange={e => setFormData(p => ({ ...p, legalFees: e.target.value }))}
                    data-testid="input-legal-fees"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Transfer Tax</label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.transferTax}
                    onChange={e => setFormData(p => ({ ...p, transferTax: e.target.value }))}
                    data-testid="input-transfer-tax"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">Other Costs</label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.otherCosts}
                    onChange={e => setFormData(p => ({ ...p, otherCosts: e.target.value }))}
                    data-testid="input-other-costs"
                  />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-1 block">Other Costs Description</label>
                <Input
                  placeholder="Optional description"
                  value={formData.otherCostsDescription}
                  onChange={e => setFormData(p => ({ ...p, otherCostsDescription: e.target.value }))}
                  data-testid="input-other-costs-desc"
                />
              </div>

              <div>
                <label className="text-sm font-medium mb-1 block">Notes</label>
                <Textarea
                  placeholder="Optional notes about this sale"
                  value={formData.notes}
                  onChange={e => setFormData(p => ({ ...p, notes: e.target.value }))}
                  data-testid="input-notes"
                />
              </div>

              <Button onClick={handlePreview} className="w-full" disabled={previewMutation.isPending} data-testid="button-preview-sale">
                {previewMutation.isPending ? "Computing..." : "Preview Settlement"}
                <Calculator className="w-4 h-4 ml-2" />
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2 flex-wrap">
                    <Building2 className="w-4 h-4" />
                    {preview.assetName} - Settlement Preview
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="flex justify-between gap-1">
                      <span className="text-muted-foreground">Sale Amount</span>
                      <span className="font-medium" data-testid="text-preview-sale-amount">{preview.currency} {fmt(preview.saleAmount)}</span>
                    </div>
                    <div className="flex justify-between gap-1">
                      <span className="text-muted-foreground">Selling Costs</span>
                      <span className="font-medium text-destructive" data-testid="text-preview-selling-costs">- {preview.currency} {fmt(preview.totalSellingCosts)}</span>
                    </div>
                    <div className="flex justify-between gap-1">
                      <span className="text-muted-foreground">Net Sale Proceeds</span>
                      <span className="font-semibold" data-testid="text-preview-net-proceeds">{preview.currency} {fmt(preview.netSaleProceeds)}</span>
                    </div>
                    <div className="flex justify-between gap-1">
                      <span className="text-muted-foreground">Total Capital Invested</span>
                      <span className="font-medium" data-testid="text-preview-capital-invested">{preview.currency} {fmt(preview.totalCapitalInvested)}</span>
                    </div>
                  </div>

                  <div className="border-t pt-3">
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <span className="text-sm font-medium">Capital Gain / (Loss)</span>
                      <Badge variant={preview.capitalGain >= 0 ? "default" : "destructive"} data-testid="badge-capital-gain">
                        {preview.capitalGain >= 0 ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
                        {preview.currency} {fmt(preview.capitalGain)}
                      </Badge>
                    </div>
                  </div>

                  <div className="border-t pt-3 text-sm">
                    <h4 className="font-medium mb-2">Per Unit Breakdown</h4>
                    <div className="grid grid-cols-3 gap-3">
                      <div>
                        <span className="text-muted-foreground block">Return of Capital</span>
                        <span className="font-medium" data-testid="text-per-unit-return">{preview.currency} {fmt(preview.returnPerUnit, 4)}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground block">Capital Gain</span>
                        <span className="font-medium" data-testid="text-per-unit-gain">{preview.currency} {fmt(preview.gainPerUnit, 4)}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground block">Total per Unit</span>
                        <span className="font-semibold" data-testid="text-per-unit-total">{preview.currency} {fmt(preview.totalPayoutPerUnit, 4)}</span>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">Total Units: {fmt(preview.totalUnits, 2)}</p>
                  </div>
                </CardContent>
              </Card>

              {preview.holders.length > 0 && (
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center gap-2 flex-wrap">
                      <Users className="w-4 h-4" />
                      Investor Payouts ({preview.holders.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm" data-testid="table-investor-payouts">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left py-2 font-medium">Investor</th>
                            <th className="text-right py-2 font-medium">Units</th>
                            <th className="text-right py-2 font-medium">Capital Return</th>
                            <th className="text-right py-2 font-medium">Capital Gain</th>
                            <th className="text-right py-2 font-medium">Total Payout</th>
                          </tr>
                        </thead>
                        <tbody>
                          {preview.holders.map((h) => (
                            <tr key={h.userId} className="border-b last:border-0">
                              <td className="py-2">
                                <div className="font-medium">{h.fullName}</div>
                                <div className="text-muted-foreground text-xs">@{h.username}</div>
                              </td>
                              <td className="text-right py-2">{fmt(h.units, 2)}</td>
                              <td className="text-right py-2">{preview.currency} {fmt(h.capitalReturn)}</td>
                              <td className="text-right py-2">{preview.currency} {fmt(h.capitalGainShare)}</td>
                              <td className="text-right py-2 font-semibold">{preview.currency} {fmt(h.totalPayout)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              )}

              <Card className="border-destructive/30">
                <CardContent className="py-4">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-sm">This action is irreversible</p>
                      <p className="text-sm text-muted-foreground">
                        Executing will: credit investor wallets, burn all units, and mark the property as sold. This cannot be undone.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="flex gap-3">
                <Button variant="outline" onClick={() => setPreview(null)} className="flex-1" data-testid="button-back-to-form">
                  Back to Form
                </Button>
                <Button
                  onClick={handleExecute}
                  disabled={executeMutation.isPending}
                  className="flex-1"
                  variant="default"
                  data-testid="button-execute-sale"
                >
                  {executeMutation.isPending ? "Processing..." : "Execute Settlement"}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={showDetailDialog} onOpenChange={(open) => { setShowDetailDialog(open); if (!open) setSelectedSaleId(null); }}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Sale Settlement Details</DialogTitle>
            <DialogDescription>Complete breakdown of the property sale and investor payouts.</DialogDescription>
          </DialogHeader>
          {saleDetail ? (
            <SaleDetailView sale={saleDetail as any} />
          ) : (
            <Skeleton className="h-40 w-full" />
          )}
        </DialogContent>
      </Dialog>
    </RoleLayout>
  );
}

function SaleDetailView({ sale }: { sale: any }) {
  const gain = parseFloat(sale.capitalGain);
  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="py-4 space-y-3">
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <h3 className="font-semibold">{sale.assetName}</h3>
            <Badge variant="outline">
              <CheckCircle2 className="w-3 h-3 mr-1" />
              Settled
            </Badge>
          </div>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="flex justify-between gap-1">
              <span className="text-muted-foreground">Sale Amount</span>
              <span className="font-medium">{sale.currency} {fmt(sale.saleAmount)}</span>
            </div>
            <div className="flex justify-between gap-1">
              <span className="text-muted-foreground">Selling Costs</span>
              <span className="font-medium text-destructive">- {sale.currency} {fmt(sale.totalSellingCosts)}</span>
            </div>
            <div className="flex justify-between gap-1">
              <span className="text-muted-foreground">Net Proceeds</span>
              <span className="font-semibold">{sale.currency} {fmt(sale.netSaleProceeds)}</span>
            </div>
            <div className="flex justify-between gap-1">
              <span className="text-muted-foreground">Capital Invested</span>
              <span className="font-medium">{sale.currency} {fmt(sale.totalCapitalInvested)}</span>
            </div>
          </div>
          <div className="border-t pt-2 flex items-center justify-between gap-2 flex-wrap">
            <span className="text-sm font-medium">Capital {gain >= 0 ? "Gain" : "Loss"}</span>
            <Badge variant={gain >= 0 ? "default" : "destructive"}>
              {gain >= 0 ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
              {sale.currency} {fmt(Math.abs(gain))}
            </Badge>
          </div>
          <div className="border-t pt-2 grid grid-cols-3 gap-3 text-sm">
            <div>
              <span className="text-muted-foreground block text-xs">Return/Unit</span>
              <span>{sale.currency} {fmt(sale.returnPerUnit, 4)}</span>
            </div>
            <div>
              <span className="text-muted-foreground block text-xs">Gain/Unit</span>
              <span>{sale.currency} {fmt(sale.gainPerUnit, 4)}</span>
            </div>
            <div>
              <span className="text-muted-foreground block text-xs">Total/Unit</span>
              <span className="font-semibold">{sale.currency} {fmt(sale.totalPayoutPerUnit, 4)}</span>
            </div>
          </div>
          {sale.notes && (
            <div className="border-t pt-2 text-sm">
              <span className="text-muted-foreground">Notes: </span>
              <span>{sale.notes}</span>
            </div>
          )}
          {sale.executedAt && (
            <div className="text-xs text-muted-foreground">
              Executed: {new Date(sale.executedAt).toLocaleString()}
            </div>
          )}
        </CardContent>
      </Card>

      {sale.payouts && sale.payouts.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2 flex-wrap">
              <Users className="w-4 h-4" />
              Investor Payouts ({sale.payouts.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-2 font-medium">Investor</th>
                    <th className="text-right py-2 font-medium">Units</th>
                    <th className="text-right py-2 font-medium">Capital Return</th>
                    <th className="text-right py-2 font-medium">Capital Gain</th>
                    <th className="text-right py-2 font-medium">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {sale.payouts.map((p: any) => (
                    <tr key={p.id} className="border-b last:border-0">
                      <td className="py-2">
                        <div className="font-medium">{p.fullName}</div>
                        <div className="text-muted-foreground text-xs">@{p.username}</div>
                      </td>
                      <td className="text-right py-2">{fmt(p.units, 2)}</td>
                      <td className="text-right py-2">{sale.currency} {fmt(p.capitalReturnAmount)}</td>
                      <td className="text-right py-2">{sale.currency} {fmt(p.capitalGainAmount)}</td>
                      <td className="text-right py-2 font-semibold">{sale.currency} {fmt(p.totalPayout)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
