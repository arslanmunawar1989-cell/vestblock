import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { Section } from "@/components/section";
import { GlassCard } from "@/components/glass-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Asset } from "@shared/schema";
import {
  COUNTRY_DETAILS,
  CURRENCY_DETAILS,
  ASSET_TYPE_LABELS,
  SUPPORTED_COUNTRIES,
} from "@shared/constants";
import type { CountryCode, CurrencyCode, JurisdictionDoc } from "@shared/constants";
import {
  Eye,
  CheckCircle2,
  AlertCircle,
  Clock,
  FileText,
  XCircle,
  ShieldCheck,
  Filter, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
interface EnrichedAsset extends Asset {
  issuerFullName: string;
  issuerEmail: string;
  jurisdictionDocs: JurisdictionDoc[];
  checklistSummary: {
    total: number;
    completed: number;
    requiredTotal: number;
    requiredCompleted: number;
  };
}

const STATUS_STYLES: Record<string, { variant: "default" | "secondary" | "destructive" | "outline"; label: string }> = {
  draft: { variant: "secondary", label: "Draft" },
  submitted: { variant: "default", label: "Submitted" },
  approved: { variant: "default", label: "Approved" },
  rejected: { variant: "destructive", label: "Rejected" },
  changes_requested: { variant: "outline", label: "Changes Requested" },
  pending: { variant: "secondary", label: "Pending" },
  active: { variant: "default", label: "Active" },
};

export default function AdminAssets() {
  const [selectedAsset, setSelectedAsset] = useState<EnrichedAsset | null>(null);
  const [showReviewDialog, setShowReviewDialog] = useState(false);
  const [filterCountry, setFilterCountry] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const { toast } = useToast();

  const { data: submissions, isLoading } = useQuery<EnrichedAsset[]>({
    queryKey: ["/api/admin/asset-submissions"],
  });

  const filtered = submissions?.filter(a => {
    if (filterCountry !== "all" && a.country !== filterCountry) return false;
    if (filterStatus !== "all" && a.submissionStatus !== filterStatus) return false;
    return true;
  }) || [];

  const totalSubmitted = submissions?.filter(a => a.submissionStatus === "submitted").length || 0;
  const totalApproved = submissions?.filter(a => a.submissionStatus === "approved").length || 0;
  const totalPending = submissions?.filter(a => ["draft", "submitted", "changes_requested"].includes(a.submissionStatus || "")).length || 0;

  return (
    <RoleLayout role="admin">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle title="Asset Management" description="Review issuer asset submissions and jurisdiction compliance" />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <GlassCard>
            <div className="flex items-center gap-3 p-4">
              <Clock className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Awaiting Review</p>
                <p className="text-2xl font-semibold" data-testid="text-stat-submitted">{totalSubmitted}</p>
              </div>
            </div>
          </GlassCard>
          <GlassCard>
            <div className="flex items-center gap-3 p-4">
              <CheckCircle2 className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Approved</p>
                <p className="text-2xl font-semibold" data-testid="text-stat-approved">{totalApproved}</p>
              </div>
            </div>
          </GlassCard>
          <GlassCard>
            <div className="flex items-center gap-3 p-4">
              <FileText className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Total Pending</p>
                <p className="text-2xl font-semibold" data-testid="text-stat-pending">{totalPending}</p>
              </div>
            </div>
          </GlassCard>
        </div>

        <Section>
          <div className="flex items-center gap-3 flex-wrap mb-4">
            <Filter className="w-4 h-4 text-muted-foreground" />
            <Select value={filterCountry} onValueChange={setFilterCountry}>
              <SelectTrigger className="w-[180px]" data-testid="select-filter-country">
                <SelectValue placeholder="All Countries" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Countries</SelectItem>
                {SUPPORTED_COUNTRIES.map(c => (
                  <SelectItem key={c} value={c}>{COUNTRY_DETAILS[c].name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-[180px]" data-testid="select-filter-status">
                <SelectValue placeholder="All Statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="submitted">Submitted</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="changes_requested">Changes Requested</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => <Skeleton key={i} className="h-20 w-full" />)}
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12" data-testid="text-no-submissions">
              <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground">No asset submissions found</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filtered.map(asset => {
                const statusInfo = STATUS_STYLES[asset.submissionStatus || "draft"] || STATUS_STYLES.draft;
                const country = asset.country as CountryCode;
                const countryName = COUNTRY_DETAILS[country]?.name || asset.country;
                const currencyInfo = CURRENCY_DETAILS[asset.baseCurrency as CurrencyCode];
                const { requiredTotal, requiredCompleted } = asset.checklistSummary;

                return (
                  <GlassCard key={asset.id}>
                    <div className="flex flex-wrap items-center justify-between gap-3 p-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="font-medium truncate" data-testid={`text-asset-name-${asset.id}`}>{asset.name}</p>
                          <Badge variant="secondary" className="text-xs">{asset.symbol}</Badge>
                          <Badge variant={statusInfo.variant} className="text-xs" data-testid={`badge-asset-status-${asset.id}`}>
                            {statusInfo.label}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-3 mt-1 flex-wrap">
                          <span className="text-xs text-muted-foreground">Issuer: {asset.issuerFullName}</span>
                          <span className="text-xs text-muted-foreground" data-testid={`text-asset-country-${asset.id}`}>{countryName}</span>
                          <span className="text-xs text-muted-foreground" data-testid={`text-asset-currency-${asset.id}`}>{currencyInfo?.symbol || ""} {asset.baseCurrency}</span>
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <ShieldCheck className="w-3.5 h-3.5 text-muted-foreground" />
                          <span className="text-xs text-muted-foreground" data-testid={`text-docs-progress-${asset.id}`}>
                            Docs: {requiredCompleted}/{requiredTotal} required
                          </span>
                          {requiredCompleted === requiredTotal && requiredTotal > 0 && (
                            <CheckCircle2 className="w-3.5 h-3.5 text-green-600" />
                          )}
                        </div>
                      </div>
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => { setSelectedAsset(asset); setShowReviewDialog(true); }}
                        data-testid={`button-review-asset-${asset.id}`}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                    </div>
                  </GlassCard>
                );
              })}
            </div>
          )}
        </Section>

        <ReviewAssetDialog asset={selectedAsset} open={showReviewDialog} onOpenChange={setShowReviewDialog} />
      </div>
    </RoleLayout>
  );
}

function ReviewAssetDialog({ asset, open, onOpenChange }: { asset: EnrichedAsset | null; open: boolean; onOpenChange: (v: boolean) => void }) {
  const { toast } = useToast();
  const [reviewStatus, setReviewStatus] = useState("");
  const [reviewNotes, setReviewNotes] = useState("");

  const reviewMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("PATCH", `/api/admin/asset-submissions/${asset!.id}/review`, {
        submissionStatus: reviewStatus,
        adminReviewNotes: reviewNotes,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/asset-submissions"] });
      onOpenChange(false);
      setReviewStatus("");
      setReviewNotes("");
      toast({ title: "Review Submitted", description: `Asset has been ${reviewStatus}` });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to submit review", variant: "destructive" });
    },
  });

  if (!asset) return null;

  const country = asset.country as CountryCode;
  const countryName = COUNTRY_DETAILS[country]?.name || asset.country;
  const checklist = (asset.jurisdictionChecklist || {}) as Record<string, boolean>;
  const statusInfo = STATUS_STYLES[asset.submissionStatus || "draft"] || STATUS_STYLES.draft;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Review: {asset.name}</DialogTitle>
          <DialogDescription>Review asset submission and jurisdiction compliance documents</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <p className="text-muted-foreground">Issuer</p>
              <p className="font-medium" data-testid="text-review-issuer">{asset.issuerFullName}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Current Status</p>
              <Badge variant={statusInfo.variant} className="text-xs" data-testid="badge-review-status">{statusInfo.label}</Badge>
            </div>
            <div>
              <p className="text-muted-foreground">Country / Jurisdiction</p>
              <p className="font-medium" data-testid="text-review-country">{countryName}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Base Currency</p>
              <p className="font-medium" data-testid="text-review-currency">{asset.baseCurrency}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Asset Type</p>
              <p className="font-medium">{ASSET_TYPE_LABELS[asset.assetType as keyof typeof ASSET_TYPE_LABELS] || asset.assetType}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Token Supply</p>
              <p className="font-medium">{parseFloat(asset.totalSupply).toLocaleString()} tokens</p>
            </div>
            <div>
              <p className="text-muted-foreground">Price Per Token</p>
              <p className="font-medium">{asset.baseCurrency} {parseFloat(asset.pricePerToken).toLocaleString()}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Token Decimals</p>
              <p className="font-medium">{asset.tokenDecimals ?? 2} (min {(1 / Math.pow(10, asset.tokenDecimals ?? 2)).toFixed(asset.tokenDecimals ?? 2)} tokens)</p>
            </div>
            {asset.location && (
              <div>
                <p className="text-muted-foreground">Location</p>
                <p className="font-medium">{asset.location}</p>
              </div>
            )}
          </div>

          {asset.description && (
            <div>
              <p className="text-sm text-muted-foreground">Description</p>
              <p className="text-sm">{asset.description}</p>
            </div>
          )}

          <div className="border rounded-md p-4 space-y-3" data-testid="section-review-docs">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-muted-foreground" />
                <h4 className="font-medium text-sm">Required Documents - {countryName}</h4>
              </div>
              <Badge variant="secondary" className="text-xs" data-testid="badge-review-docs-progress">
                {asset.checklistSummary.requiredCompleted}/{asset.checklistSummary.requiredTotal} required
              </Badge>
            </div>
            {asset.jurisdictionDocs.map(doc => (
              <div key={doc.key} className="flex items-center gap-2 text-sm" data-testid={`doc-status-${doc.key}`}>
                {checklist[doc.key] ? (
                  <CheckCircle2 className="w-4 h-4 text-green-600 shrink-0" />
                ) : (
                  <XCircle className={`w-4 h-4 shrink-0 ${doc.required ? "text-destructive" : "text-muted-foreground"}`} />
                )}
                <span className={checklist[doc.key] ? "" : "text-muted-foreground"}>
                  {doc.label}
                </span>
                {doc.required && (
                  <Badge variant={checklist[doc.key] ? "default" : "destructive"} className="text-xs ml-auto">
                    {checklist[doc.key] ? "Confirmed" : "Missing"}
                  </Badge>
                )}
                {!doc.required && (
                  <Badge variant="secondary" className="text-xs ml-auto">Optional</Badge>
                )}
              </div>
            ))}
          </div>

          {asset.submissionStatus === "submitted" && (
            <div className="border-t pt-4 space-y-3">
              <h4 className="font-medium text-sm">Admin Review</h4>
              <Select value={reviewStatus} onValueChange={setReviewStatus}>
                <SelectTrigger data-testid="select-review-decision">
                  <SelectValue placeholder="Select decision" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="approved">Approve</SelectItem>
                  <SelectItem value="rejected">Reject</SelectItem>
                  <SelectItem value="changes_requested">Request Changes</SelectItem>
                </SelectContent>
              </Select>
              <Textarea
                value={reviewNotes}
                onChange={(e) => setReviewNotes(e.target.value)}
                placeholder="Review notes (optional)"
                data-testid="input-review-notes"
              />
              <div className="flex justify-end">
                <Button
                  onClick={() => reviewMutation.mutate()}
                  disabled={!reviewStatus || reviewMutation.isPending}
                  data-testid="button-submit-review"
                >
                  {reviewMutation.isPending ? "Submitting..." : "Submit Review"}
                </Button>
              </div>
            </div>
          )}

          {asset.adminReviewNotes && asset.submissionStatus !== "submitted" && (
            <div className="border rounded-md p-3">
              <p className="text-sm text-muted-foreground">Previous Review Notes</p>
              <p className="text-sm">{asset.adminReviewNotes}</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
