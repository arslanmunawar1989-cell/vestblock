import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { RoleLayout } from "@/components/role-layout";
import { PageTitle } from "@/components/page-title";
import { StatTile } from "@/components/stat-tile";
import { Section } from "@/components/section";
import { DataTable, type Column } from "@/components/data-table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate } from "@/lib/format";
import {
  Building2,
  Target,
  FileText,
  Users,
  Tag,
  Plus,
  Trash2,
  CheckCircle2,
  Clock,
  AlertTriangle,
  XCircle,
  Milestone,
  Percent, ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
type Asset = {
  id: string;
  name: string;
  constructionStatus: string | null;
  occupancyRate: string | null;
  propertyType: string | null;
  status: string;
  country: string;
};

type PropertyMilestone = {
  id: string;
  assetId: string;
  name: string;
  description: string | null;
  status: string;
  targetDate: string | null;
  completionDate: string | null;
  progressPercent: number;
  sortOrder: number;
  notes: string | null;
  createdAt: string;
};

type RentalContract = {
  id: string;
  assetId: string;
  tenantName: string;
  tenantEmail: string | null;
  tenantPhone: string | null;
  unitIdentifier: string | null;
  startDate: string;
  endDate: string;
  monthlyRent: string;
  currency: string;
  securityDeposit: string | null;
  status: string;
  contractRef: string | null;
  notes: string | null;
  createdAt: string;
};

type PropertyManager = {
  id: string;
  name: string;
  company: string | null;
  email: string | null;
  phone: string | null;
  licenseNumber: string | null;
  country: string;
  isActive: boolean;
  assignedAssetIds: string[] | null;
  notes: string | null;
  createdAt: string;
};

type ExpenseCategory = {
  id: string;
  name: string;
  description: string | null;
  isDefault: boolean;
  createdAt: string;
};

const milestoneStatusColors: Record<string, string> = {
  planned: "secondary",
  in_progress: "default",
  completed: "default",
  delayed: "destructive",
  cancelled: "outline",
};

const contractStatusColors: Record<string, string> = {
  draft: "secondary",
  active: "default",
  expired: "destructive",
  terminated: "destructive",
  renewed: "default",
};

function MilestoneStatusIcon({ status }: { status: string }) {
  switch (status) {
    case "completed": return <CheckCircle2 className="w-4 h-4 text-green-600" />;
    case "in_progress": return <Clock className="w-4 h-4 text-blue-500" />;
    case "delayed": return <AlertTriangle className="w-4 h-4 text-red-500" />;
    case "cancelled": return <XCircle className="w-4 h-4 text-muted-foreground" />;
    default: return <Target className="w-4 h-4 text-muted-foreground" />;
  }
}

export default function AdminProperties() {
  const { toast } = useToast();
  const [selectedAssetId, setSelectedAssetId] = useState<string>("");
  const [activeTab, setActiveTab] = useState("milestones");

  const [showMilestoneDialog, setShowMilestoneDialog] = useState(false);
  const [showContractDialog, setShowContractDialog] = useState(false);
  const [showManagerDialog, setShowManagerDialog] = useState(false);
  const [showCategoryDialog, setShowCategoryDialog] = useState(false);

  const [milestoneForm, setMilestoneForm] = useState({
    name: "", description: "", status: "planned", targetDate: "",
    completionDate: "", progressPercent: 0, sortOrder: 0, notes: "",
  });

  const [contractForm, setContractForm] = useState({
    tenantName: "", tenantEmail: "", tenantPhone: "", unitIdentifier: "",
    startDate: "", endDate: "", monthlyRent: "", currency: "AED",
    securityDeposit: "", status: "draft", contractRef: "", notes: "",
  });

  const [managerForm, setManagerForm] = useState({
    name: "", company: "", email: "", phone: "",
    licenseNumber: "", country: "AE", isActive: true, notes: "",
  });

  const [categoryForm, setCategoryForm] = useState({
    name: "", description: "", isDefault: false,
  });

  const { data: assets = [], isLoading: assetsLoading } = useQuery<Asset[]>({
    queryKey: ["/api/assets"],
  });

  const { data: milestones = [], isLoading: milestonesLoading } = useQuery<PropertyMilestone[]>({
    queryKey: ["/api/properties", selectedAssetId, "milestones"],
    enabled: !!selectedAssetId,
    queryFn: () => fetch(`/api/properties/${selectedAssetId}/milestones`, { credentials: "include" }).then(r => r.json()),
  });

  const { data: contracts = [], isLoading: contractsLoading } = useQuery<RentalContract[]>({
    queryKey: ["/api/properties", selectedAssetId, "contracts"],
    enabled: !!selectedAssetId,
    queryFn: () => fetch(`/api/properties/${selectedAssetId}/contracts`, { credentials: "include" }).then(r => r.json()),
  });

  const { data: allContracts = [] } = useQuery<RentalContract[]>({
    queryKey: ["/api/properties/contracts"],
    queryFn: () => fetch("/api/properties/contracts", { credentials: "include" }).then(r => r.json()),
  });

  const { data: managers = [], isLoading: managersLoading } = useQuery<PropertyManager[]>({
    queryKey: ["/api/property-managers"],
  });

  const { data: expenseCategories = [], isLoading: categoriesLoading } = useQuery<ExpenseCategory[]>({
    queryKey: ["/api/property-expense-categories"],
  });

  const createMilestone = useMutation({
    mutationFn: () => apiRequest("POST", `/api/properties/${selectedAssetId}/milestones`, milestoneForm),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/properties", selectedAssetId, "milestones"] });
      setShowMilestoneDialog(false);
      setMilestoneForm({ name: "", description: "", status: "planned", targetDate: "", completionDate: "", progressPercent: 0, sortOrder: 0, notes: "" });
      toast({ title: "Milestone created" });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const updateMilestone = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => apiRequest("PATCH", `/api/properties/milestones/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/properties", selectedAssetId, "milestones"] });
      toast({ title: "Milestone updated" });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const deleteMilestone = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/properties/milestones/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/properties", selectedAssetId, "milestones"] });
      toast({ title: "Milestone deleted" });
    },
  });

  const createContract = useMutation({
    mutationFn: () => apiRequest("POST", `/api/properties/${selectedAssetId}/contracts`, contractForm),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/properties", selectedAssetId, "contracts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/properties/contracts"] });
      setShowContractDialog(false);
      setContractForm({ tenantName: "", tenantEmail: "", tenantPhone: "", unitIdentifier: "", startDate: "", endDate: "", monthlyRent: "", currency: "AED", securityDeposit: "", status: "draft", contractRef: "", notes: "" });
      toast({ title: "Contract created" });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const updateContract = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => apiRequest("PATCH", `/api/properties/contracts/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/properties", selectedAssetId, "contracts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/properties/contracts"] });
      toast({ title: "Contract updated" });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const deleteContract = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/properties/contracts/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/properties", selectedAssetId, "contracts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/properties/contracts"] });
      toast({ title: "Contract deleted" });
    },
  });

  const createManager = useMutation({
    mutationFn: () => apiRequest("POST", "/api/property-managers", managerForm),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/property-managers"] });
      setShowManagerDialog(false);
      setManagerForm({ name: "", company: "", email: "", phone: "", licenseNumber: "", country: "AE", isActive: true, notes: "" });
      toast({ title: "Manager added" });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const deleteManager = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/property-managers/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/property-managers"] });
      toast({ title: "Manager removed" });
    },
  });

  const createCategory = useMutation({
    mutationFn: () => apiRequest("POST", "/api/property-expense-categories", categoryForm),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/property-expense-categories"] });
      setShowCategoryDialog(false);
      setCategoryForm({ name: "", description: "", isDefault: false });
      toast({ title: "Category created" });
    },
    onError: (e: any) => toast({ title: "Error", description: e.message, variant: "destructive" }),
  });

  const deleteCategory = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/property-expense-categories/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/property-expense-categories"] });
      toast({ title: "Category deleted" });
    },
  });

  const selectedAsset = assets.find(a => a.id === selectedAssetId);
  const activeContracts = allContracts.filter(c => c.status === "active");
  const totalMonthlyRent = activeContracts.reduce((s, c) => s + parseFloat(c.monthlyRent || "0"), 0);
  const activeManagers = managers.filter(m => m.isActive);

  const milestoneColumns: Column<PropertyMilestone>[] = [
    {
      header: "Milestone",
      accessor: (m: PropertyMilestone) => (
        <div className="flex items-center gap-2">
          <MilestoneStatusIcon status={m.status} />
          <div>
            <div className="font-medium" data-testid={`text-milestone-name-${m.id}`}>{m.name}</div>
            {m.description && <div className="text-xs text-muted-foreground">{m.description}</div>}
          </div>
        </div>
      ),
    },
    {
      header: "Progress",
      accessor: (m: PropertyMilestone) => (
        <div className="flex items-center gap-2 min-w-[120px]">
          <Progress value={m.progressPercent} className="h-2 flex-1" />
          <span className="text-xs text-muted-foreground w-8">{m.progressPercent}%</span>
        </div>
      ),
    },
    {
      header: "Status",
      accessor: (m: PropertyMilestone) => (
        <Select
          value={m.status}
          onValueChange={(v) => updateMilestone.mutate({ id: m.id, data: { status: v, ...(v === "completed" ? { progressPercent: 100, completionDate: new Date().toISOString().split("T")[0] } : {}) } })}
        >
          <SelectTrigger className="w-[130px]" data-testid={`select-milestone-status-${m.id}`}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="planned">Planned</SelectItem>
            <SelectItem value="in_progress">In Progress</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="delayed">Delayed</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
          </SelectContent>
        </Select>
      ),
    },
    { header: "Target Date", accessor: (m: PropertyMilestone) => m.targetDate ? formatDate(m.targetDate) : "-" },
    { header: "Completed", accessor: (m: PropertyMilestone) => m.completionDate ? formatDate(m.completionDate) : "-" },
    {
      header: "",
      accessor: (m: PropertyMilestone) => (
        <Button size="icon" variant="ghost" onClick={() => deleteMilestone.mutate(m.id)} data-testid={`button-delete-milestone-${m.id}`}>
          <Trash2 className="w-4 h-4" />
        </Button>
      ),
    },
  ];

  const contractColumns: Column<RentalContract>[] = [
    {
      header: "Tenant",
      accessor: (c: RentalContract) => (
        <div>
          <div className="font-medium" data-testid={`text-tenant-name-${c.id}`}>{c.tenantName}</div>
          {c.unitIdentifier && <div className="text-xs text-muted-foreground">Unit: {c.unitIdentifier}</div>}
        </div>
      ),
    },
    { header: "Start", accessor: (c: RentalContract) => formatDate(c.startDate) },
    { header: "End", accessor: (c: RentalContract) => formatDate(c.endDate) },
    { header: "Monthly Rent", accessor: (c: RentalContract) => `${c.currency} ${parseFloat(c.monthlyRent).toLocaleString()}` },
    {
      header: "Status",
      accessor: (c: RentalContract) => (
        <Select
          value={c.status}
          onValueChange={(v) => updateContract.mutate({ id: c.id, data: { status: v } })}
        >
          <SelectTrigger className="w-[120px]" data-testid={`select-contract-status-${c.id}`}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="expired">Expired</SelectItem>
            <SelectItem value="terminated">Terminated</SelectItem>
            <SelectItem value="renewed">Renewed</SelectItem>
          </SelectContent>
        </Select>
      ),
    },
    {
      header: "",
      accessor: (c: RentalContract) => (
        <Button size="icon" variant="ghost" onClick={() => deleteContract.mutate(c.id)} data-testid={`button-delete-contract-${c.id}`}>
          <Trash2 className="w-4 h-4" />
        </Button>
      ),
    },
  ];

  const managerColumns: Column<PropertyManager>[] = [
    {
      header: "Name",
      accessor: (m: PropertyManager) => (
        <div>
          <div className="font-medium" data-testid={`text-manager-name-${m.id}`}>{m.name}</div>
          {m.company && <div className="text-xs text-muted-foreground">{m.company}</div>}
        </div>
      ),
    },
    { header: "Email", accessor: (m: PropertyManager) => m.email || "-" },
    { header: "Phone", accessor: (m: PropertyManager) => m.phone || "-" },
    { header: "License", accessor: (m: PropertyManager) => m.licenseNumber || "-" },
    { header: "Country", accessor: "country" },
    {
      header: "Status",
      accessor: (m: PropertyManager) => <Badge variant={m.isActive ? "default" : "secondary"}>{m.isActive ? "Active" : "Inactive"}</Badge>,
    },
    {
      header: "Properties",
      accessor: (m: PropertyManager) => {
        const count = m.assignedAssetIds?.length || 0;
        return <Badge variant="secondary">{count} assigned</Badge>;
      },
    },
    {
      header: "",
      accessor: (m: PropertyManager) => (
        <Button size="icon" variant="ghost" onClick={() => deleteManager.mutate(m.id)} data-testid={`button-delete-manager-${m.id}`}>
          <Trash2 className="w-4 h-4" />
        </Button>
      ),
    },
  ];

  const categoryColumns: Column<ExpenseCategory>[] = [
    {
      header: "Category",
      accessor: (c: ExpenseCategory) => (
        <div>
          <div className="font-medium" data-testid={`text-category-name-${c.id}`}>{c.name}</div>
          {c.description && <div className="text-xs text-muted-foreground">{c.description}</div>}
        </div>
      ),
    },
    {
      header: "Default",
      accessor: (c: ExpenseCategory) => c.isDefault ? <Badge variant="default">Default</Badge> : <Badge variant="secondary">Custom</Badge>,
    },
    {
      header: "",
      accessor: (c: ExpenseCategory) => (
        <Button size="icon" variant="ghost" onClick={() => deleteCategory.mutate(c.id)} data-testid={`button-delete-category-${c.id}`}>
          <Trash2 className="w-4 h-4" />
        </Button>
      ),
    },
  ];

  if (assetsLoading) {
    return (
      <RoleLayout role="admin">
        <div className="p-6 space-y-4">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-64 w-full" />
        </div>
      </RoleLayout>
    );
  }

  return (
    <RoleLayout role="admin">
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-3">
          <Link href="/admin/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <PageTitle
          title="Property Lifecycle"
          description="Manage off-plan milestones, rental onboarding, contracts, property managers, and expense categories"
        />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <StatTile icon={<Building2 className="w-5 h-5" />} label="Total Properties" value={String(assets.length)} />
          <StatTile icon={<FileText className="w-5 h-5" />} label="Active Contracts" value={String(activeContracts.length)} />
          <StatTile icon={<Users className="w-5 h-5" />} label="Active Managers" value={String(activeManagers.length)} />
          <StatTile icon={<Tag className="w-5 h-5" />} label="Expense Categories" value={String(expenseCategories.length)} />
        </div>

        <Section>
          <div className="mb-4">
            <Label className="text-sm font-medium mb-2 block">Select Property</Label>
            <Select value={selectedAssetId} onValueChange={setSelectedAssetId}>
              <SelectTrigger className="w-full max-w-md" data-testid="select-property">
                <SelectValue placeholder="Choose a property to manage..." />
              </SelectTrigger>
              <SelectContent>
                {assets.map(a => (
                  <SelectItem key={a.id} value={a.id}>{a.name} ({a.country})</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedAsset && (
            <div className="flex flex-wrap items-center gap-2 mb-4">
              <Badge variant="secondary">{selectedAsset.propertyType || "Property"}</Badge>
              <Badge variant="secondary">{selectedAsset.country}</Badge>
              {selectedAsset.constructionStatus && (
                <Badge variant={selectedAsset.constructionStatus === "completed" ? "default" : "secondary"}>
                  {selectedAsset.constructionStatus}
                </Badge>
              )}
              {selectedAsset.occupancyRate && (
                <Badge variant="outline">
                  <Percent className="w-3 h-3 mr-1" />
                  {selectedAsset.occupancyRate}% occupancy
                </Badge>
              )}
            </div>
          )}
        </Section>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="flex flex-wrap gap-1">
            <TabsTrigger value="milestones" data-testid="tab-milestones">
              <Milestone className="w-4 h-4 mr-1" /> Milestones
            </TabsTrigger>
            <TabsTrigger value="contracts" data-testid="tab-contracts">
              <FileText className="w-4 h-4 mr-1" /> Rental Contracts
            </TabsTrigger>
            <TabsTrigger value="managers" data-testid="tab-managers">
              <Users className="w-4 h-4 mr-1" /> Property Managers
            </TabsTrigger>
            <TabsTrigger value="categories" data-testid="tab-categories">
              <Tag className="w-4 h-4 mr-1" /> Expense Categories
            </TabsTrigger>
          </TabsList>

          <TabsContent value="milestones" className="mt-4">
            <Section>
              <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                <div>
                  <h3 className="font-semibold">Off-Plan Milestones</h3>
                  <p className="text-sm text-muted-foreground">Track construction progress and project phases</p>
                </div>
                <Button
                  onClick={() => setShowMilestoneDialog(true)}
                  disabled={!selectedAssetId}
                  data-testid="button-add-milestone"
                >
                  <Plus className="w-4 h-4 mr-1" /> Add Milestone
                </Button>
              </div>
              {!selectedAssetId ? (
                <p className="text-muted-foreground text-sm">Select a property above to view milestones.</p>
              ) : milestonesLoading ? (
                <Skeleton className="h-32 w-full" />
              ) : milestones.length === 0 ? (
                <p className="text-muted-foreground text-sm">No milestones recorded for this property.</p>
              ) : (
                <DataTable columns={milestoneColumns} data={milestones} />
              )}
            </Section>
          </TabsContent>

          <TabsContent value="contracts" className="mt-4">
            <Section>
              <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                <div>
                  <h3 className="font-semibold">Rental Contracts</h3>
                  <p className="text-sm text-muted-foreground">Manage tenant leases and rental onboarding</p>
                </div>
                <Button
                  onClick={() => setShowContractDialog(true)}
                  disabled={!selectedAssetId}
                  data-testid="button-add-contract"
                >
                  <Plus className="w-4 h-4 mr-1" /> Add Contract
                </Button>
              </div>
              {!selectedAssetId ? (
                <p className="text-muted-foreground text-sm">Select a property above to view contracts.</p>
              ) : contractsLoading ? (
                <Skeleton className="h-32 w-full" />
              ) : contracts.length === 0 ? (
                <p className="text-muted-foreground text-sm">No contracts recorded for this property.</p>
              ) : (
                <DataTable columns={contractColumns} data={contracts} />
              )}
            </Section>
          </TabsContent>

          <TabsContent value="managers" className="mt-4">
            <Section>
              <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                <div>
                  <h3 className="font-semibold">Property Managers</h3>
                  <p className="text-sm text-muted-foreground">Manage property management companies and contacts</p>
                </div>
                <Button onClick={() => setShowManagerDialog(true)} data-testid="button-add-manager">
                  <Plus className="w-4 h-4 mr-1" /> Add Manager
                </Button>
              </div>
              {managersLoading ? (
                <Skeleton className="h-32 w-full" />
              ) : managers.length === 0 ? (
                <p className="text-muted-foreground text-sm">No property managers registered.</p>
              ) : (
                <DataTable columns={managerColumns} data={managers} />
              )}
            </Section>
          </TabsContent>

          <TabsContent value="categories" className="mt-4">
            <Section>
              <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                <div>
                  <h3 className="font-semibold">Expense Categories</h3>
                  <p className="text-sm text-muted-foreground">Standardize property operating expense classifications</p>
                </div>
                <Button onClick={() => setShowCategoryDialog(true)} data-testid="button-add-category">
                  <Plus className="w-4 h-4 mr-1" /> Add Category
                </Button>
              </div>
              {categoriesLoading ? (
                <Skeleton className="h-32 w-full" />
              ) : expenseCategories.length === 0 ? (
                <p className="text-muted-foreground text-sm">No expense categories defined.</p>
              ) : (
                <DataTable columns={categoryColumns} data={expenseCategories} />
              )}
            </Section>
          </TabsContent>
        </Tabs>

        <Dialog open={showMilestoneDialog} onOpenChange={setShowMilestoneDialog}>
          <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add Milestone</DialogTitle>
              <DialogDescription>Track an off-plan construction phase or project milestone</DialogDescription>
            </DialogHeader>
            <form onSubmit={(e) => { e.preventDefault(); createMilestone.mutate(); }} className="space-y-4">
              <div>
                <Label>Name</Label>
                <Input value={milestoneForm.name} onChange={e => setMilestoneForm(f => ({ ...f, name: e.target.value }))} required data-testid="input-milestone-name" />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea value={milestoneForm.description} onChange={e => setMilestoneForm(f => ({ ...f, description: e.target.value }))} data-testid="input-milestone-description" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Status</Label>
                  <Select value={milestoneForm.status} onValueChange={v => setMilestoneForm(f => ({ ...f, status: v }))}>
                    <SelectTrigger data-testid="select-milestone-form-status">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="planned">Planned</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="delayed">Delayed</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Progress %</Label>
                  <Input type="number" min={0} max={100} value={milestoneForm.progressPercent} onChange={e => setMilestoneForm(f => ({ ...f, progressPercent: parseInt(e.target.value) || 0 }))} data-testid="input-milestone-progress" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Target Date</Label>
                  <Input type="date" value={milestoneForm.targetDate} onChange={e => setMilestoneForm(f => ({ ...f, targetDate: e.target.value }))} data-testid="input-milestone-target-date" />
                </div>
                <div>
                  <Label>Sort Order</Label>
                  <Input type="number" value={milestoneForm.sortOrder} onChange={e => setMilestoneForm(f => ({ ...f, sortOrder: parseInt(e.target.value) || 0 }))} data-testid="input-milestone-sort-order" />
                </div>
              </div>
              <div>
                <Label>Notes</Label>
                <Textarea value={milestoneForm.notes} onChange={e => setMilestoneForm(f => ({ ...f, notes: e.target.value }))} data-testid="input-milestone-notes" />
              </div>
              <Button type="submit" className="w-full" disabled={createMilestone.isPending} data-testid="button-submit-milestone">
                {createMilestone.isPending ? "Creating..." : "Create Milestone"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>

        <Dialog open={showContractDialog} onOpenChange={setShowContractDialog}>
          <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add Rental Contract</DialogTitle>
              <DialogDescription>Onboard a new tenant with a lease agreement</DialogDescription>
            </DialogHeader>
            <form onSubmit={(e) => { e.preventDefault(); createContract.mutate(); }} className="space-y-4">
              <div>
                <Label>Tenant Name</Label>
                <Input value={contractForm.tenantName} onChange={e => setContractForm(f => ({ ...f, tenantName: e.target.value }))} required data-testid="input-contract-tenant" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Email</Label>
                  <Input type="email" value={contractForm.tenantEmail} onChange={e => setContractForm(f => ({ ...f, tenantEmail: e.target.value }))} data-testid="input-contract-email" />
                </div>
                <div>
                  <Label>Phone</Label>
                  <Input value={contractForm.tenantPhone} onChange={e => setContractForm(f => ({ ...f, tenantPhone: e.target.value }))} data-testid="input-contract-phone" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Unit / Apartment</Label>
                  <Input value={contractForm.unitIdentifier} onChange={e => setContractForm(f => ({ ...f, unitIdentifier: e.target.value }))} data-testid="input-contract-unit" />
                </div>
                <div>
                  <Label>Contract Ref</Label>
                  <Input value={contractForm.contractRef} onChange={e => setContractForm(f => ({ ...f, contractRef: e.target.value }))} data-testid="input-contract-ref" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Start Date</Label>
                  <Input type="date" value={contractForm.startDate} onChange={e => setContractForm(f => ({ ...f, startDate: e.target.value }))} required data-testid="input-contract-start" />
                </div>
                <div>
                  <Label>End Date</Label>
                  <Input type="date" value={contractForm.endDate} onChange={e => setContractForm(f => ({ ...f, endDate: e.target.value }))} required data-testid="input-contract-end" />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label>Monthly Rent</Label>
                  <Input value={contractForm.monthlyRent} onChange={e => setContractForm(f => ({ ...f, monthlyRent: e.target.value }))} required data-testid="input-contract-rent" />
                </div>
                <div>
                  <Label>Currency</Label>
                  <Select value={contractForm.currency} onValueChange={v => setContractForm(f => ({ ...f, currency: v }))}>
                    <SelectTrigger data-testid="select-contract-currency">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="AED">AED</SelectItem>
                      <SelectItem value="USD">USD</SelectItem>
                      <SelectItem value="GBP">GBP</SelectItem>
                      <SelectItem value="PKR">PKR</SelectItem>
                      <SelectItem value="QAR">QAR</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Security Deposit</Label>
                  <Input value={contractForm.securityDeposit} onChange={e => setContractForm(f => ({ ...f, securityDeposit: e.target.value }))} data-testid="input-contract-deposit" />
                </div>
              </div>
              <div>
                <Label>Status</Label>
                <Select value={contractForm.status} onValueChange={v => setContractForm(f => ({ ...f, status: v }))}>
                  <SelectTrigger data-testid="select-contract-form-status">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="expired">Expired</SelectItem>
                    <SelectItem value="terminated">Terminated</SelectItem>
                    <SelectItem value="renewed">Renewed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Notes</Label>
                <Textarea value={contractForm.notes} onChange={e => setContractForm(f => ({ ...f, notes: e.target.value }))} data-testid="input-contract-notes" />
              </div>
              <Button type="submit" className="w-full" disabled={createContract.isPending} data-testid="button-submit-contract">
                {createContract.isPending ? "Creating..." : "Create Contract"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>

        <Dialog open={showManagerDialog} onOpenChange={setShowManagerDialog}>
          <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add Property Manager</DialogTitle>
              <DialogDescription>Register a property management company or individual</DialogDescription>
            </DialogHeader>
            <form onSubmit={(e) => { e.preventDefault(); createManager.mutate(); }} className="space-y-4">
              <div>
                <Label>Name</Label>
                <Input value={managerForm.name} onChange={e => setManagerForm(f => ({ ...f, name: e.target.value }))} required data-testid="input-manager-name" />
              </div>
              <div>
                <Label>Company</Label>
                <Input value={managerForm.company} onChange={e => setManagerForm(f => ({ ...f, company: e.target.value }))} data-testid="input-manager-company" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Email</Label>
                  <Input type="email" value={managerForm.email} onChange={e => setManagerForm(f => ({ ...f, email: e.target.value }))} data-testid="input-manager-email" />
                </div>
                <div>
                  <Label>Phone</Label>
                  <Input value={managerForm.phone} onChange={e => setManagerForm(f => ({ ...f, phone: e.target.value }))} data-testid="input-manager-phone" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>License Number</Label>
                  <Input value={managerForm.licenseNumber} onChange={e => setManagerForm(f => ({ ...f, licenseNumber: e.target.value }))} data-testid="input-manager-license" />
                </div>
                <div>
                  <Label>Country</Label>
                  <Select value={managerForm.country} onValueChange={v => setManagerForm(f => ({ ...f, country: v }))}>
                    <SelectTrigger data-testid="select-manager-country">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="AE">UAE</SelectItem>
                      <SelectItem value="PK">Pakistan</SelectItem>
                      <SelectItem value="GB">United Kingdom</SelectItem>
                      <SelectItem value="US">United States</SelectItem>
                      <SelectItem value="QA">Qatar</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Switch checked={managerForm.isActive} onCheckedChange={v => setManagerForm(f => ({ ...f, isActive: v }))} data-testid="switch-manager-active" />
                <Label>Active</Label>
              </div>
              <div>
                <Label>Notes</Label>
                <Textarea value={managerForm.notes} onChange={e => setManagerForm(f => ({ ...f, notes: e.target.value }))} data-testid="input-manager-notes" />
              </div>
              <Button type="submit" className="w-full" disabled={createManager.isPending} data-testid="button-submit-manager">
                {createManager.isPending ? "Adding..." : "Add Manager"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>

        <Dialog open={showCategoryDialog} onOpenChange={setShowCategoryDialog}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Add Expense Category</DialogTitle>
              <DialogDescription>Create a standardized property expense classification</DialogDescription>
            </DialogHeader>
            <form onSubmit={(e) => { e.preventDefault(); createCategory.mutate(); }} className="space-y-4">
              <div>
                <Label>Category Name</Label>
                <Input value={categoryForm.name} onChange={e => setCategoryForm(f => ({ ...f, name: e.target.value }))} required data-testid="input-category-name" />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea value={categoryForm.description} onChange={e => setCategoryForm(f => ({ ...f, description: e.target.value }))} data-testid="input-category-description" />
              </div>
              <div className="flex items-center gap-2">
                <Switch checked={categoryForm.isDefault} onCheckedChange={v => setCategoryForm(f => ({ ...f, isDefault: v }))} data-testid="switch-category-default" />
                <Label>Default category (available for all properties)</Label>
              </div>
              <Button type="submit" className="w-full" disabled={createCategory.isPending} data-testid="button-submit-category">
                {createCategory.isPending ? "Creating..." : "Create Category"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </RoleLayout>
  );
}
