import { Link } from "wouter";
import { GlassCard } from "@/components/glass-card";
import { GlassButton } from "@/components/glass-button";
import { AlertCircle, Home } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center gradient-bg p-6">
      <GlassCard className="w-full max-w-md text-center" padding="lg">
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 rounded-md gradient-hero flex items-center justify-center">
            <AlertCircle className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold" data-testid="text-404-title">Page Not Found</h1>
          <p className="text-sm text-muted-foreground">
            The page you're looking for doesn't exist or has been moved.
          </p>
          <Link href="/">
            <GlassButton variant="primary" data-testid="button-go-home">
              <Home className="w-4 h-4" />
              Back to Home
            </GlassButton>
          </Link>
        </div>
      </GlassCard>
    </div>
  );
}
