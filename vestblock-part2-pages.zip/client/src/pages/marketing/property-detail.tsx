import { useState } from "react";
import { Link, useParams } from "wouter";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { GlassButton } from "@/components/marketing/glass-button";
import { GlassCard } from "@/components/marketing/glass-card";

import { motion } from "framer-motion";
import {
  ArrowLeft, MapPin, TrendingUp, Calendar,
  FileText, ChevronLeft, ChevronRight, Download,
  Building2, Percent, Wallet, AlertTriangle,
  Info, DollarSign, PieChart, ArrowDownRight,
  Shield, Layers,
} from "lucide-react";
import { useCmsProperties } from "@/hooks/use-cms-content";

import allProperties from "@/data/featured-properties.json";
import detailsData from "@/data/property-details.json";

type Property = (typeof allProperties)[number];
type DetailData = (typeof detailsData)[keyof typeof detailsData];

function mapCmsToProperty(cms: any): Property {
  return {
    id: cms.slug || cms.id,
    name: cms.name,
    city: cms.city,
    type: cms.propertyType,
    strategy: cms.strategy || "Income",
    status: "funding",
    minInvestment: Number(cms.minInvestment),
    totalRaised: Number(cms.fundingTarget || 0) * (cms.fundingProgressPercent || 0) / 100,
    targetRaise: Number(cms.fundingTarget || 0),
    tokenPrice: Number(cms.minInvestment),
    totalTokens: 10000,
    soldTokens: Math.round(10000 * (cms.fundingProgressPercent || 0) / 100),
    annualYield: Number(cms.expectedYield || 0),
    appreciation: 8.0,
    image: (cms.imagesJson as any)?.[0] || "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=600&h=400&fit=crop",
    listingDate: cms.createdAt?.split("T")[0] || "2026-01-01",
    location: `${cms.city}, Pakistan`,
  };
}

function formatPKR(value: number) {
  if (value >= 10000000) return `PKR ${(value / 10000000).toFixed(1)}Cr`;
  if (value >= 100000) return `PKR ${(value / 100000).toFixed(0)}L`;
  return `PKR ${value.toLocaleString()}`;
}

const fadeUp = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } };

export default function PropertyDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const { data: cmsProperties } = useCmsProperties("PK");
  const properties: Property[] = cmsProperties && cmsProperties.length > 0
    ? cmsProperties.map(mapCmsToProperty)
    : allProperties;
  const property = properties.find((p) => p.id === slug) as Property | undefined;
  const details = slug ? (detailsData as Record<string, DetailData>)[slug] : undefined;

  if (!property || !details) {
    return (
      <MarketingLayout>
        <div className="min-h-[60vh] flex flex-col items-center justify-center py-20 px-4">
          <GlassCard className="max-w-md text-center">
            <Building2 className="w-12 h-12 text-ink-muted/70 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-ink-dark mb-2">Property Not Found</h2>
            <p className="text-ink-muted/70 mb-6 text-sm">The property you're looking for doesn't exist or has been removed.</p>
            <Link href="/properties">
              <GlassButton variant="secondary"><ArrowLeft className="w-4 h-4" /> Back to Properties</GlassButton>
            </Link>
          </GlassCard>
        </div>
      </MarketingLayout>
    );
  }

  const pct = Math.round((property.soldTokens / property.totalTokens) * 100);

  return (
    <MarketingLayout>
      <PageMeta title={`${property.name} — Investment Details`} description={`Explore ${property.name} in ${property.location}. ${property.annualYield}% expected yield, PKR ${property.minInvestment.toLocaleString()} minimum investment. View financials, risks, and documents.`} path={`/pk/properties/${property.id}`} />
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link href="/properties" className="inline-flex items-center gap-2 text-sm text-ink-muted/70 hover:text-ink-dark transition-colors mb-6" data-testid="back-to-properties">
            <ArrowLeft className="w-4 h-4" /> Back to Properties
        </Link>

        <Gallery images={details.gallery} name={property.name} />

        <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ delay: 0.1 }} className="mt-6 mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-ink-dark mb-1" data-testid="property-title">{property.name}</h1>
          <p className="flex items-center gap-1.5 text-sm text-ink-muted" data-testid="property-location">
            <MapPin className="w-4 h-4 text-ink-muted/70" /> {property.location}
          </p>
        </motion.div>

        <div className="space-y-8">
          <OverviewSection property={property} details={details} pct={pct} />
          <InvestmentThesisSection thesis={details.investmentThesis} />
          <FinancialSummarySection financials={details.financials} />
          <RentalDistributionSection rental={details.rentalDistribution} />
          <DataRoomSection docs={details.dataRoom} />
          <RisksSection risks={details.risks} />
          <CtaSection propertyName={property.name} />
        </div>
      </div>
    </MarketingLayout>
  );
}

function Gallery({ images, name }: { images: string[]; name: string }) {
  const [idx, setIdx] = useState(0);
  const prev = () => setIdx((i) => (i === 0 ? images.length - 1 : i - 1));
  const next = () => setIdx((i) => (i === images.length - 1 ? 0 : i + 1));

  return (
    <motion.div variants={fadeUp} initial="hidden" animate="visible" className="relative rounded-3xl overflow-hidden" data-testid="property-gallery">
      <div className="relative aspect-[16/9]">
        <img
          src={images[idx]}
          alt={`${name} - Image ${idx + 1}`}
          className="w-full h-full object-cover transition-all duration-500"
          data-testid="gallery-main-image"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#050B1A]/60 via-transparent to-[#050B1A]/20" />

        <button
          onClick={prev}
          className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-2xl bg-black/50 backdrop-blur-sm text-white flex items-center justify-center hover:bg-black/70 transition-colors"
          data-testid="gallery-prev"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <button
          onClick={next}
          className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-2xl bg-black/50 backdrop-blur-sm text-white flex items-center justify-center hover:bg-black/70 transition-colors"
          data-testid="gallery-next"
        >
          <ChevronRight className="w-5 h-5" />
        </button>

        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5">
          {images.map((_, i) => (
            <button
              key={i}
              onClick={() => setIdx(i)}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${i === idx ? "bg-white w-5" : "bg-white/40"}`}
              data-testid={`gallery-dot-${i}`}
            />
          ))}
        </div>
      </div>

      <div className="flex gap-2 mt-2">
        {images.map((img, i) => (
          <button
            key={i}
            onClick={() => setIdx(i)}
            className={`flex-1 rounded-xl overflow-hidden aspect-[16/9] border-2 transition-all duration-200 ${
              i === idx ? "border-vest-g5 shadow-glassGlow" : "border-transparent opacity-60 hover:opacity-100"
            }`}
            data-testid={`gallery-thumb-${i}`}
          >
            <img src={img} alt={`${name} thumbnail ${i + 1}`} className="w-full h-full object-cover" loading="lazy" />
          </button>
        ))}
      </div>
    </motion.div>
  );
}

function OverviewSection({ property, details, pct }: { property: Property; details: DetailData; pct: number }) {
  const overviewItems = [
    { label: "Location", value: property.location, icon: MapPin },
    { label: "Property Type", value: property.type, icon: Building2 },
    { label: "Expected Yield", value: `${property.annualYield}%`, icon: TrendingUp, accent: true },
    { label: "Payout Frequency", value: details.payoutFrequency, icon: Calendar },
    { label: "Minimum Investment", value: `PKR ${property.minInvestment.toLocaleString()}`, icon: Wallet },
  ];

  return (
    <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
      <GlassCard className="p-0 overflow-hidden" data-testid="overview-section">
        <div className="px-6 py-4 border-b border-vest-g5/15 flex items-center gap-2">
          <Layers className="w-4 h-4 text-vest-g5" />
          <h2 className="text-lg font-semibold text-ink-dark">Overview</h2>
        </div>

        <div className="p-6 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {overviewItems.map((item) => (
              <div key={item.label} className="flex items-start gap-3 p-3 rounded-2xl bg-white/40 border border-vest-g5/15" data-testid={`overview-${item.label.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="w-9 h-9 rounded-xl bg-vest-g5/10 flex items-center justify-center shrink-0">
                  <item.icon className="w-4 h-4 text-vest-g5" />
                </div>
                <div>
                  <p className="text-xs text-ink-muted/70 mb-0.5">{item.label}</p>
                  <p className={`text-sm font-semibold ${item.accent ? "text-vest-g5" : "text-ink-dark"}`}>{item.value}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 rounded-2xl bg-white/50 border border-vest-g5/15" data-testid="funding-progress">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-vest-g5" />
                <span className="text-sm font-semibold text-ink-dark">Funding Progress</span>
              </div>
              <span className="text-sm font-bold text-vest-g5" data-testid="funding-pct">{pct}%</span>
            </div>
            <div className="h-2 w-full rounded-full bg-white/40 mb-3" data-testid="funding-bar">
              <div
                className="h-2 rounded-full bg-vest-g5 shadow-glassGlow transition-all duration-700"
                style={{ width: `${pct}%` }}
              />
            </div>
            <div className="grid grid-cols-3 gap-3 text-center">
              <div>
                <p className="text-xs font-bold text-ink-dark" data-testid="funding-raised">{formatPKR(property.totalRaised)}</p>
                <p className="text-[10px] text-ink-muted/70">Raised</p>
              </div>
              <div>
                <p className="text-xs font-bold text-ink-dark" data-testid="funding-target">{formatPKR(property.targetRaise)}</p>
                <p className="text-[10px] text-ink-muted/70">Target</p>
              </div>
              <div>
                <p className="text-xs font-bold text-ink-dark">{property.soldTokens.toLocaleString()} / {property.totalTokens.toLocaleString()}</p>
                <p className="text-[10px] text-ink-muted/70">Tokens Sold</p>
              </div>
            </div>
          </div>
        </div>
      </GlassCard>
    </motion.div>
  );
}

function InvestmentThesisSection({ thesis }: { thesis: string }) {
  return (
    <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
      <GlassCard data-testid="investment-thesis">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 rounded-xl bg-vest-g5/15 flex items-center justify-center">
            <TrendingUp className="w-4 h-4 text-vest-g5" />
          </div>
          <h2 className="text-lg font-semibold text-ink-dark">Investment Thesis</h2>
        </div>
        <p className="text-sm text-ink-muted leading-relaxed">{thesis}</p>
      </GlassCard>
    </motion.div>
  );
}

function FinancialSummarySection({ financials }: { financials: DetailData["financials"] }) {
  const items = [
    { label: "Purchase Cost", value: formatPKR(financials.purchaseCost), icon: DollarSign, desc: "Total property acquisition price" },
    { label: "Transaction Costs", value: `${financials.transactionCosts}%`, icon: Percent, desc: "Legal, registration & transfer fees" },
    { label: "Management Fee", value: `${financials.managementFee}%`, icon: PieChart, desc: "Annual platform management fee" },
    { label: "Reserve Allocation", value: `${financials.reserveAllocation}%`, icon: Shield, desc: "Maintenance & contingency reserve" },
  ];

  return (
    <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
      <GlassCard data-testid="financial-summary">
        <div className="flex items-center gap-2 mb-5">
          <div className="w-8 h-8 rounded-xl bg-vest-g5/15 flex items-center justify-center">
            <DollarSign className="w-4 h-4 text-vest-g5" />
          </div>
          <h2 className="text-lg font-semibold text-ink-dark">Financial Summary</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {items.map((item) => (
            <div key={item.label} className="p-4 rounded-2xl bg-white/40 border border-vest-g5/15" data-testid={`financial-${item.label.toLowerCase().replace(/\s+/g, "-")}`}>
              <div className="flex items-center gap-2 mb-2">
                <item.icon className="w-4 h-4 text-ink-muted/70" />
                <span className="text-xs font-medium text-ink-muted/70">{item.label}</span>
              </div>
              <p className="text-lg font-bold text-ink-dark mb-0.5">{item.value}</p>
              <p className="text-[10px] text-ink-muted">{item.desc}</p>
            </div>
          ))}
        </div>
      </GlassCard>
    </motion.div>
  );
}

function RentalDistributionSection({ rental }: { rental: DetailData["rentalDistribution"] }) {
  const steps = [
    { label: "Gross Rent", value: formatPKR(rental.grossRent), color: "text-ink-dark" },
    { label: "Operating Expenses", value: `- ${formatPKR(rental.expenses)}`, color: "text-amber-400" },
    { label: "Platform Fees", value: `- ${formatPKR(rental.fees)}`, color: "text-amber-400" },
  ];

  return (
    <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
      <GlassCard data-testid="rental-distribution">
        <div className="flex items-center gap-2 mb-5">
          <div className="w-8 h-8 rounded-xl bg-vest-g5/15 flex items-center justify-center">
            <ArrowDownRight className="w-4 h-4 text-vest-g5" />
          </div>
          <h2 className="text-lg font-semibold text-ink-dark">Rental & Distribution</h2>
        </div>

        <p className="text-sm text-ink-muted mb-5">
          Gross Rent &ndash; Expenses &ndash; Fees = Distributable Income
        </p>

        <div className="space-y-3 mb-4">
          {steps.map((s) => (
            <div key={s.label} className="flex items-center justify-between p-3 rounded-2xl bg-white/40 border border-vest-g5/15" data-testid={`waterfall-${s.label.toLowerCase().replace(/\s+/g, "-")}`}>
              <span className="text-sm text-ink-muted">{s.label}</span>
              <span className={`text-sm font-semibold ${s.color}`}>{s.value}</span>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between p-4 rounded-2xl bg-vest-g5/10 border border-vest-g5/20" data-testid="waterfall-distributable">
          <div className="flex items-center gap-2">
            <Wallet className="w-4 h-4 text-vest-g5" />
            <span className="text-sm font-semibold text-ink-dark">Distributable Income</span>
          </div>
          <span className="text-lg font-bold text-vest-g5">{formatPKR(rental.distributableIncome)}</span>
        </div>

        <p className="text-[10px] text-ink-muted mt-3">{rental.description}</p>
      </GlassCard>
    </motion.div>
  );
}

function DataRoomSection({ docs }: { docs: DetailData["dataRoom"] }) {
  return (
    <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
      <GlassCard data-testid="data-room-section">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 rounded-xl bg-vest-g5/15 flex items-center justify-center">
            <FileText className="w-4 h-4 text-vest-g5" />
          </div>
          <h2 className="text-lg font-semibold text-ink-dark">Data Room (ADT)</h2>
        </div>

        <p className="text-xs text-ink-muted/70 mb-3">Available Documents</p>
        <div className="space-y-2">
          {docs.map((doc) => (
            <div
              key={doc.name}
              className="flex items-center justify-between gap-3 px-4 py-3 rounded-2xl border border-vest-g5/15 bg-white/40 hover:border-vest-g5/20 transition-colors"
              data-testid={`doc-${doc.name.toLowerCase().replace(/[\s()]/g, "-")}`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <FileText className="w-4 h-4 text-ink-muted/70 shrink-0" />
                <div className="min-w-0">
                  <p className="text-sm text-ink-dark truncate">{doc.name}</p>
                  <p className="text-[10px] text-ink-muted">{doc.type} &middot; {doc.size}</p>
                </div>
              </div>
              <Download className="w-4 h-4 text-ink-muted shrink-0 cursor-pointer hover:text-vest-g5 transition-colors" />
            </div>
          ))}
        </div>
      </GlassCard>
    </motion.div>
  );
}

const STANDARD_RISKS = [
  "Market fluctuation — Property values and rental income may vary due to economic conditions, interest rate changes, and local market dynamics.",
  "Vacancy risk — Periods of tenant vacancy may reduce distributable income below projected yields.",
  "Expense volatility — Maintenance costs, insurance premiums, and regulatory fees may increase beyond initial estimates.",
];

function RisksSection({ risks }: { risks: string[] }) {
  const allRisks = [...STANDARD_RISKS, ...risks];

  return (
    <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
      <GlassCard data-testid="risks-section">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 rounded-xl bg-amber-500/15 flex items-center justify-center">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <h2 className="text-lg font-semibold text-ink-dark">Risks</h2>
        </div>
        <ul className="space-y-2.5">
          {allRisks.map((r, i) => (
            <li key={i} className="flex items-start gap-2.5 text-sm text-ink-muted">
              <span className="mt-1 w-1.5 h-1.5 rounded-full bg-amber-400/60 shrink-0" />
              {r}
            </li>
          ))}
        </ul>
      </GlassCard>
    </motion.div>
  );
}

function CtaSection({ propertyName }: { propertyName: string }) {
  return (
    <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
      <GlassCard className="border border-vest-g5/20 bg-gradient-to-br from-vest-g5/5 to-transparent text-center" data-testid="cta-section">
        <h3 className="text-lg font-semibold text-ink-dark mb-2">Invest in {propertyName}</h3>
        <p className="text-sm text-ink-muted mb-5">Create a free account to access the full data room, review documents, and begin your investment.</p>
        <Link href="/auth/register">
            <GlassButton className="px-8" data-testid="cta-create-account">Create Account to Invest</GlassButton>
        </Link>
        <div className="mt-4 flex items-start justify-center gap-2 text-[10px] text-ink-muted">
          <Info className="w-3 h-3 mt-0.5 shrink-0" />
          <span>Investment involves risk. Past performance does not guarantee future returns. Please review all documents before investing.</span>
        </div>
      </GlassCard>
    </motion.div>
  );
}
