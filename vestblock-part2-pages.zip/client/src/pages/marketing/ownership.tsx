import { Link } from "wouter";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { GlassButton } from "@/components/marketing/glass-button";
import { GlassCard } from "@/components/marketing/glass-card";
import { motion } from "framer-motion";
import {
  ArrowRight, Building2, Layers, FileText,
  CheckCircle2, ShieldCheck, CalendarCheck, Info,
} from "lucide-react";

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const keyPoints = [
  {
    icon: Layers,
    title: "Units allocated upon funding completion",
    desc: "Once a property's funding round is fully subscribed and closed, units are allocated to each investor proportional to their contribution. Allocation is recorded on the digital ledger and visible in your dashboard immediately.",
  },
  {
    icon: ShieldCheck,
    title: "Ownership records maintained digitally",
    desc: "All ownership records are maintained on VestBlock's secure digital ledger. Your unit holdings, transaction history, and beneficial ownership status are accessible at any time through your investor dashboard.",
  },
  {
    icon: CalendarCheck,
    title: "Monthly statements available",
    desc: "Detailed monthly statements are generated for every investor. Each statement includes your unit holdings, rental distributions received, fee deductions, and current portfolio valuation — available to download from your dashboard.",
  },
];

export default function OwnershipPage() {
  return (
    <MarketingLayout>
      <PageMeta
        title="Ownership & Structure — Understanding Unit Ownership"
        description="Learn how property ownership is structured on VestBlock. Each property is a dedicated investment offering with units representing beneficial ownership interest."
        path="/pk/ownership"
      />

      <section className="relative py-24 sm:py-32 px-4 overflow-hidden" data-testid="ownership-hero">
        <div className="absolute inset-0 bg-gradient-to-b from-vest-g5/5 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div variants={fadeUp} initial="hidden" animate="visible">
            <span className="inline-flex items-center px-3.5 py-1.5 rounded-2xl text-xs font-medium mb-6 text-vest-g5 bg-vest-g5/10 border border-vest-g5/20" data-testid="ownership-badge">
              Ownership &amp; Structure
            </span>
            <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-5" data-testid="ownership-headline">
              Understanding Unit <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Ownership</span>
            </h1>
            <p className="text-base sm:text-lg text-ink-muted max-w-2xl mx-auto leading-relaxed" data-testid="ownership-subtext">
              A clear explanation of how your investment is structured and what owning units means on VestBlock.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-12 px-4" data-testid="ownership-structure">
        <div className="max-w-4xl mx-auto">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <GlassCard className="border border-vest-g5/20 bg-gradient-to-br from-vest-g5/5 to-transparent" data-testid="structure-card">
              <div className="flex flex-col sm:flex-row gap-6">
                <div className="flex-1">
                  <div className="w-12 h-12 rounded-2xl bg-vest-g5/15 flex items-center justify-center mb-4">
                    <Building2 className="w-6 h-6 text-vest-g5" />
                  </div>
                  <h2 className="text-lg font-semibold text-ink-dark mb-3" data-testid="structure-title-1">
                    Dedicated Investment Offering
                  </h2>
                  <p className="text-sm text-ink-muted leading-relaxed" data-testid="structure-desc-1">
                    Each property is structured as a dedicated investment offering. This means every property on VestBlock is held through its own ring-fenced structure — separate from all other properties and from VestBlock's own operations.
                  </p>
                </div>

                <div className="w-px bg-vest-g5/15 hidden sm:block" />
                <div className="h-px bg-vest-g5/15 sm:hidden" />

                <div className="flex-1">
                  <div className="w-12 h-12 rounded-2xl bg-vest-g5/15 flex items-center justify-center mb-4">
                    <FileText className="w-6 h-6 text-vest-g5" />
                  </div>
                  <h2 className="text-lg font-semibold text-ink-dark mb-3" data-testid="structure-title-2">
                    Beneficial Ownership Interest
                  </h2>
                  <p className="text-sm text-ink-muted leading-relaxed" data-testid="structure-desc-2">
                    Units represent a beneficial ownership interest in that specific property offering. When you purchase units, you hold a proportional economic interest — entitling you to your share of rental income and any capital appreciation.
                  </p>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        </div>
      </section>

      <section className="py-12 px-4" data-testid="ownership-key-points">
        <div className="max-w-4xl mx-auto">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center mb-8">
            <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark mb-3" data-testid="key-points-title">Key <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Points</span></h2>
            <p className="text-sm text-ink-muted">How ownership works on VestBlock — from allocation to ongoing reporting.</p>
          </motion.div>

          <div className="space-y-4">
            {keyPoints.map((point, i) => (
              <motion.div
                key={point.title}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                transition={{ delay: i * 0.06 }}
              >
                <GlassCard className="p-0 overflow-hidden" data-testid={`key-point-${i}`}>
                  <div className="flex items-center gap-4 px-6 py-5">
                    <div className="w-10 h-10 rounded-xl bg-vest-g5/15 flex items-center justify-center shrink-0">
                      <point.icon className="w-5 h-5 text-vest-g5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-sm font-semibold text-ink-dark mb-1">{point.title}</h3>
                      <p className="text-xs text-ink-muted leading-relaxed">{point.desc}</p>
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 px-4" data-testid="ownership-what-you-get">
        <div className="max-w-4xl mx-auto">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <GlassCard data-testid="what-you-get-card">
              <h2 className="text-lg font-semibold text-ink-dark mb-5">What Unit Ownership Includes</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {[
                  "Proportional share of net rental income",
                  "Proportional share of capital appreciation at exit",
                  "Access to property documentation and data room",
                  "Monthly statements and portfolio reporting",
                  "Voting rights on material property decisions (if applicable)",
                  "Participation in structured exit windows",
                ].map((item) => (
                  <div key={item} className="flex items-start gap-2 text-xs text-ink-muted">
                    <CheckCircle2 className="w-3.5 h-3.5 text-vest-g5 shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </GlassCard>
          </motion.div>
        </div>
      </section>

      <section className="py-12 px-4" data-testid="ownership-disclaimer">
        <div className="max-w-4xl mx-auto">
          <GlassCard className="border border-vest-g5/20">
            <div className="flex items-start gap-3">
              <Info className="w-4 h-4 text-ink-muted/70 mt-0.5 shrink-0" />
              <div className="text-[10px] text-ink-muted leading-relaxed space-y-2">
                <p>
                  Units represent a beneficial ownership interest and do not constitute direct legal title to the underlying property. The investment structure, rights, and obligations are governed by the offering documents for each property.
                </p>
                <p>
                  All investments carry risk, including the potential loss of principal. Past performance is not indicative of future results. Please review all documentation before investing.
                </p>
              </div>
            </div>
          </GlassCard>
        </div>
      </section>

      <section className="py-16 px-4" data-testid="ownership-cta">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <GlassCard className="border border-vest-g5/20 bg-gradient-to-br from-vest-g5/5 to-transparent py-10">
              <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark mb-3" data-testid="ownership-cta-title">
                Start Building Your <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Portfolio</span>
              </h2>
              <p className="text-sm text-ink-muted mb-6 max-w-md mx-auto">
                Browse tokenized properties with full documentation and transparent ownership structures.
              </p>
              <div className="flex flex-wrap items-center justify-center gap-3">
                <Link href="/pk/properties">
                  <GlassButton data-testid="ownership-cta-properties">Browse Properties <ArrowRight className="w-4 h-4" /></GlassButton>
                </Link>
                <Link href="/pk/how-it-works">
                  <GlassButton variant="secondary" data-testid="ownership-cta-hiw">How It Works</GlassButton>
                </Link>
              </div>
            </GlassCard>
          </motion.div>
        </div>
      </section>
    </MarketingLayout>
  );
}
