import { useState, useMemo } from "react";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { GlassCard } from "@/components/marketing/glass-card";
import { GlassButton } from "@/components/marketing/glass-button";
import { motion, AnimatePresence } from "framer-motion";
import {
  Calculator, TrendingUp, BarChart3,
  Banknote, Clock,
  Info, AlertTriangle, Sparkles, Loader2,
  ArrowDown, ArrowUp, ChevronDown, ChevronUp,
  Lightbulb, Navigation, BookOpen, Globe, Droplets,
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const amountPresets = [50000, 100000, 250000, 500000, 1000000, 2500000];
const yieldPresets = [6, 8, 10, 12, 15, 18];
const monthPresets = [6, 12, 24, 36, 60, 84, 120];
const currencies = ["PKR", "AED", "USD", "GBP"];

function formatPKR(value: number) {
  if (value >= 10000000) return `PKR ${(value / 10000000).toFixed(2)} Cr`;
  if (value >= 100000) return `PKR ${(value / 100000).toFixed(2)} L`;
  return `PKR ${Math.round(value).toLocaleString()}`;
}

function formatMonths(m: number) {
  if (m < 12) return `${m} mo`;
  const y = Math.floor(m / 12);
  const rem = m % 12;
  return rem > 0 ? `${y}y ${rem}mo` : `${y}y`;
}

function parseQueryParams(): Record<string, number> {
  const params = new URLSearchParams(window.location.search);
  const result: Record<string, number> = {};
  params.forEach((val, key) => {
    const num = parseFloat(val);
    if (!isNaN(num)) result[key] = num;
  });
  return result;
}

interface Sensitivity {
  occupancyDrop10: { effectiveYield: number; annual: number; monthly: number; impact: number };
  feesUp1: { effectiveYield: number; annual: number; monthly: number; impact: number };
  yieldDown1: { effectiveYield: number; annual: number; monthly: number; impact: number };
}

interface ExplanationData {
  plainExplanation: string;
  biggestFactor: string;
  nextSteps: string;
  holdingStrategy: string;
  currencyNote: string;
}

export default function ROICalculatorPage() {
  const qp = parseQueryParams();

  const [amount, setAmount] = useState(qp.amount || 500000);
  const [yieldPct, setYieldPct] = useState(qp.yield_pct || 12);
  const [occupancy, setOccupancy] = useState(qp.occupancy || 90);
  const [fees, setFees] = useState(qp.fees || 2);
  const [months, setMonths] = useState(qp.months || 60);
  const [currency, setCurrency] = useState("PKR");
  const [liquidityNeed, setLiquidityNeed] = useState<"LOW" | "MED" | "HIGH">("MED");
  const [explaining, setExplaining] = useState(false);
  const [explanation, setExplanation] = useState<ExplanationData | null>(null);
  const [explainError, setExplainError] = useState<string | null>(null);
  const [showSensitivity, setShowSensitivity] = useState(false);

  const results = useMemo(() => {
    const effectiveYield = (yieldPct * (occupancy / 100)) - fees;
    const annualReturn = amount * (effectiveYield / 100);
    const monthlyDist = annualReturn / 12;
    const totalReturn = annualReturn * (months / 12);
    const roiPercent = (totalReturn / amount) * 100;
    const isNegative = effectiveYield < 0;

    const scenarios = [
      { label: "Low", yieldAdj: -2, occAdj: -10 },
      { label: "Base", yieldAdj: 0, occAdj: 0 },
      { label: "High", yieldAdj: 2, occAdj: 5 },
    ].map((s) => {
      const adjYield = yieldPct + s.yieldAdj;
      const adjOcc = Math.min(100, occupancy + s.occAdj);
      const effYield = (adjYield * (adjOcc / 100)) - fees;
      const annual = amount * (effYield / 100);
      const monthly = annual / 12;
      const total = annual * (months / 12);
      const roi = (total / amount) * 100;
      return { label: s.label, yieldUsed: adjYield, occUsed: adjOcc, effectiveYield: effYield, annual, monthly, total, roi };
    });

    const sensitivity: Sensitivity = {
      occupancyDrop10: (() => {
        const eff = (yieldPct * ((occupancy - 10) / 100)) - fees;
        return { effectiveYield: eff, annual: amount * (eff / 100), monthly: amount * (eff / 100) / 12, impact: effectiveYield !== 0 ? ((eff - effectiveYield) / Math.abs(effectiveYield)) * 100 : 0 };
      })(),
      feesUp1: (() => {
        const eff = (yieldPct * (occupancy / 100)) - (fees + 1);
        return { effectiveYield: eff, annual: amount * (eff / 100), monthly: amount * (eff / 100) / 12, impact: effectiveYield !== 0 ? ((eff - effectiveYield) / Math.abs(effectiveYield)) * 100 : 0 };
      })(),
      yieldDown1: (() => {
        const eff = ((yieldPct - 1) * (occupancy / 100)) - fees;
        return { effectiveYield: eff, annual: amount * (eff / 100), monthly: amount * (eff / 100) / 12, impact: effectiveYield !== 0 ? ((eff - effectiveYield) / Math.abs(effectiveYield)) * 100 : 0 };
      })(),
    };

    return { effectiveYield, annualReturn, monthlyDist, totalReturn, roiPercent, isNegative, scenarios, sensitivity };
  }, [amount, yieldPct, occupancy, fees, months]);

  const handleExplain = async () => {
    setExplaining(true);
    setExplainError(null);
    setExplanation(null);
    try {
      const res = await apiRequest("POST", "/api/ai/roi/explain", {
        amount, yieldPct, occupancy, fees, months,
        currency: currency !== "PKR" ? currency : undefined,
        liquidityNeed,
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error || "Failed to get explanation");
      setExplanation(data.explanation);
    } catch (err: any) {
      setExplainError(err.message || "Something went wrong");
    } finally {
      setExplaining(false);
    }
  };

  return (
    <MarketingLayout>
      <PageMeta
        title="ROI Calculator — Estimate Potential Returns in PKR"
        description="Model potential returns on tokenized real estate in Pakistan. Adjust yield, occupancy, fees, and holding period to explore different scenarios."
        path="/pk/roi-calculator"
      />

      <section className="relative py-16 sm:py-24 px-4 overflow-hidden" data-testid="roi-hero">
        <div className="absolute inset-0 bg-gradient-to-b from-vest-g5/5 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-3xl mx-auto text-center relative z-10">
          <motion.div variants={fadeUp} initial="hidden" animate="visible">
            <span className="inline-flex items-center px-3.5 py-1.5 rounded-2xl text-xs font-medium mb-5 text-vest-g5 bg-vest-g5/10 border border-vest-g5/20" data-testid="roi-badge">
              Interactive Tool
            </span>
            <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-4" data-testid="roi-headline">
              Estimate Potential <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Returns</span> in PKR
            </h1>
            <p className="text-sm sm:text-base text-ink-muted max-w-xl mx-auto leading-relaxed" data-testid="roi-subtext">
              Adjust the inputs below to model illustrative scenarios for tokenized Pakistani real estate.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="px-4 pb-16" data-testid="roi-calculator-section">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">

            <div className="lg:col-span-2 space-y-5">
              <motion.div variants={fadeUp} initial="hidden" animate="visible">
                <GlassCard data-testid="roi-inputs-card">
                  <h2 className="text-base font-semibold text-ink-dark mb-5 flex items-center gap-2">
                    <Calculator className="w-4 h-4 text-vest-g5" /> Inputs
                  </h2>

                  <div className="space-y-5">
                    <InputField
                      label="Investment Amount (PKR)"
                      icon={Banknote}
                      testId="input-amount"
                    >
                      <input
                        data-testid="input-amount"
                        type="number"
                        min={10000}
                        max={100000000}
                        step={10000}
                        value={amount}
                        onChange={(e) => setAmount(Math.max(10000, Number(e.target.value)))}
                        className="w-full px-4 py-2.5 rounded-xl bg-white/50 border border-vest-g5/15 text-ink-dark text-sm focus:outline-none focus:border-vest-g5/50 transition"
                      />
                      <PresetRow
                        presets={amountPresets}
                        active={amount}
                        onSelect={setAmount}
                        format={(p) => p >= 1000000 ? `${p / 1000000}M` : p >= 100000 ? `${p / 100000}L` : `${(p / 1000).toFixed(0)}K`}
                        testPrefix="preset-amount"
                      />
                    </InputField>

                    <SliderField
                      label="Expected Yield (%)"
                      value={yieldPct}
                      min={2}
                      max={25}
                      step={0.5}
                      testId="input-yield"
                      onChange={setYieldPct}
                    >
                      <PresetRow
                        presets={yieldPresets}
                        active={yieldPct}
                        onSelect={setYieldPct}
                        format={(p) => `${p}%`}
                        testPrefix="preset-yield"
                      />
                    </SliderField>

                    <SliderField
                      label="Occupancy (%)"
                      value={occupancy}
                      min={50}
                      max={100}
                      step={5}
                      testId="input-occupancy"
                      onChange={setOccupancy}
                      ticks={["50%", "75%", "100%"]}
                    />

                    <SliderField
                      label="Fees (%)"
                      value={fees}
                      min={0}
                      max={5}
                      step={0.25}
                      testId="input-fees"
                      onChange={setFees}
                      ticks={["0%", "2.5%", "5%"]}
                    />

                    <InputField label="Holding Period (Months)" icon={Clock} testId="input-months">
                      <PresetRow
                        presets={monthPresets}
                        active={months}
                        onSelect={setMonths}
                        format={(p) => formatMonths(p)}
                        testPrefix="preset-months"
                      />
                      <input
                        data-testid="input-months"
                        type="number"
                        min={1}
                        max={240}
                        step={1}
                        value={months}
                        onChange={(e) => setMonths(Math.max(1, Math.min(240, Number(e.target.value))))}
                        className="w-full px-4 py-2.5 rounded-xl bg-white/50 border border-vest-g5/15 text-ink-dark text-sm focus:outline-none focus:border-vest-g5/50 transition mt-2"
                      />
                    </InputField>

                    <div>
                      <label className="text-xs font-medium text-ink-muted mb-2 flex items-center gap-1.5">
                        <Globe className="w-3.5 h-3.5 text-ink-muted/70" />
                        Display Currency
                      </label>
                      <div className="flex gap-1.5" data-testid="currency-selector">
                        {currencies.map(c => (
                          <button key={c} onClick={() => setCurrency(c)} data-testid={`currency-${c.toLowerCase()}`}
                            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition border ${currency === c ? "bg-vest-g5/20 border-vest-g5/30 text-vest-g5" : "bg-white/50 border-vest-g5/15 text-ink-muted/70 hover:text-ink-muted"}`}>
                            {c}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-medium text-ink-muted mb-2 flex items-center gap-1.5">
                        <Droplets className="w-3.5 h-3.5 text-ink-muted/70" />
                        Liquidity Need
                      </label>
                      <div className="flex gap-1.5" data-testid="liquidity-selector">
                        {(["LOW", "MED", "HIGH"] as const).map(l => (
                          <button key={l} onClick={() => setLiquidityNeed(l)} data-testid={`liquidity-${l.toLowerCase()}`}
                            className={`flex-1 px-3 py-1.5 rounded-lg text-xs font-medium transition border ${liquidityNeed === l ? "bg-vest-g5/20 border-vest-g5/30 text-vest-g5" : "bg-white/50 border-vest-g5/15 text-ink-muted/70 hover:text-ink-muted"}`}>
                            {l === "LOW" ? "Low" : l === "MED" ? "Medium" : "High"}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            </div>

            <div className="lg:col-span-3 space-y-5">
              <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ delay: 0.05 }}>
                <GlassCard className="border border-vest-g5/20 bg-gradient-to-br from-vest-g5/5 to-transparent" data-testid="roi-results-card">
                  <h2 className="text-base font-semibold text-ink-dark mb-5 flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-vest-g5" /> Estimated Returns
                  </h2>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-5">
                    <ResultCard
                      label="Estimated Monthly Distribution"
                      value={formatPKR(results.monthlyDist)}
                      testId="result-monthly"
                    />
                    <ResultCard
                      label="Estimated Annual Return"
                      value={formatPKR(results.annualReturn)}
                      testId="result-annual"
                    />
                    <ResultCard
                      label="Projected ROI"
                      value={`${results.roiPercent.toFixed(1)}%`}
                      testId="result-roi"
                      accent
                    />
                  </div>

                  {results.isNegative && (
                    <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 flex items-start gap-2 text-[11px] text-red-300" data-testid="negative-yield-warning">
                      <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                      <span>Your inputs produce a negative effective yield. Fees exceed estimated income at this occupancy level. Adjust inputs to explore profitable scenarios.</span>
                    </div>
                  )}
                </GlassCard>
              </motion.div>

              <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ delay: 0.1 }}>
                <GlassCard className="p-0 overflow-hidden" data-testid="roi-scenario-card">
                  <div className="px-6 py-4 border-b border-vest-g5/15 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-vest-g5" />
                    <h3 className="text-sm font-semibold text-ink-dark">Scenario Table</h3>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full" data-testid="scenario-table">
                      <thead>
                        <tr className="border-b border-vest-g5/15">
                          <th className="text-left py-3 px-5 text-[11px] font-semibold text-ink-muted">Scenario</th>
                          <th className="text-center py-3 px-4 text-[11px] font-semibold text-ink-muted">Yield</th>
                          <th className="text-center py-3 px-4 text-[11px] font-semibold text-ink-muted">Occupancy</th>
                          <th className="text-center py-3 px-4 text-[11px] font-semibold text-ink-muted">Monthly</th>
                          <th className="text-center py-3 px-4 text-[11px] font-semibold text-ink-muted">Annual</th>
                          <th className="text-center py-3 px-4 text-[11px] font-semibold text-ink-muted">ROI</th>
                        </tr>
                      </thead>
                      <tbody>
                        {results.scenarios.map((s) => (
                          <tr
                            key={s.label}
                            className={`border-b border-vest-g5/15 last:border-b-0 ${s.label === "Base" ? "bg-vest-g5/5" : ""}`}
                            data-testid={`scenario-row-${s.label.toLowerCase()}`}
                          >
                            <td className="py-3 px-5 text-xs font-medium text-ink-muted">{s.label}</td>
                            <td className="py-3 px-4 text-xs text-ink-muted text-center">{s.yieldUsed}%</td>
                            <td className="py-3 px-4 text-xs text-ink-muted text-center">{s.occUsed}%</td>
                            <td className="py-3 px-4 text-xs text-ink-muted text-center">{formatPKR(s.monthly)}</td>
                            <td className="py-3 px-4 text-xs text-ink-muted text-center">{formatPKR(s.annual)}</td>
                            <td className="py-3 px-4 text-xs text-center font-bold text-vest-g5">{s.roi.toFixed(1)}%</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </GlassCard>
              </motion.div>

              <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ delay: 0.12 }}>
                <GlassCard data-testid="roi-sensitivity-card">
                  <button onClick={() => setShowSensitivity(!showSensitivity)} className="w-full flex items-center justify-between" data-testid="sensitivity-toggle">
                    <h3 className="text-sm font-semibold text-ink-dark flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-amber-500" /> Sensitivity Analysis
                    </h3>
                    {showSensitivity ? <ChevronUp className="w-4 h-4 text-ink-muted" /> : <ChevronDown className="w-4 h-4 text-ink-muted" />}
                  </button>

                  <AnimatePresence>
                    {showSensitivity && (
                      <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                        <p className="text-[11px] text-ink-muted/70 mt-3 mb-4">How your estimated returns change if key assumptions shift:</p>
                        <div className="space-y-3" data-testid="sensitivity-results">
                          <SensitivityRow
                            label="Occupancy drops 10%"
                            detail={`${occupancy}% → ${occupancy - 10}%`}
                            newMonthly={results.sensitivity.occupancyDrop10.monthly}
                            impact={results.sensitivity.occupancyDrop10.impact}
                            testId="sensitivity-occupancy"
                          />
                          <SensitivityRow
                            label="Fees increase 1%"
                            detail={`${fees}% → ${fees + 1}%`}
                            newMonthly={results.sensitivity.feesUp1.monthly}
                            impact={results.sensitivity.feesUp1.impact}
                            testId="sensitivity-fees"
                          />
                          <SensitivityRow
                            label="Yield drops 1%"
                            detail={`${yieldPct}% → ${yieldPct - 1}%`}
                            newMonthly={results.sensitivity.yieldDown1.monthly}
                            impact={results.sensitivity.yieldDown1.impact}
                            testId="sensitivity-yield"
                          />
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </GlassCard>
              </motion.div>

              <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ delay: 0.14 }}>
                <GlassCard className="border border-vest-g5/20" data-testid="roi-explain-section">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-sm font-semibold text-ink-dark flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-vest-g5" /> AI-Powered Explanation
                    </h3>
                  </div>

                  {!explanation && !explaining && !explainError && (
                    <div className="text-center py-4">
                      <p className="text-sm text-ink-muted mb-4">Get a plain-English explanation of your ROI numbers, sensitivity insights, and suggested next steps.</p>
                      <GlassButton onClick={handleExplain} data-testid="explain-btn">
                        <Sparkles className="w-4 h-4" /> Explain My Result
                      </GlassButton>
                    </div>
                  )}

                  {explaining && (
                    <div className="text-center py-6" data-testid="explain-loading">
                      <Loader2 className="w-8 h-8 text-vest-g5 animate-spin mx-auto mb-3" />
                      <p className="text-sm text-ink-muted">Analyzing your scenario...</p>
                    </div>
                  )}

                  {explainError && (
                    <div className="text-center py-4">
                      <AlertTriangle className="w-6 h-6 text-amber-500 mx-auto mb-2" />
                      <p className="text-sm text-ink-muted mb-3">{explainError}</p>
                      <GlassButton onClick={handleExplain} variant="secondary" data-testid="explain-retry">Try Again</GlassButton>
                    </div>
                  )}

                  {explanation && (
                    <div className="space-y-4" data-testid="explain-results">
                      <ExplanationSection icon={BookOpen} title="What This Means" content={explanation.plainExplanation} testId="explain-plain" />
                      <ExplanationSection icon={Lightbulb} title="Biggest Factor" content={explanation.biggestFactor} testId="explain-factor" />
                      <ExplanationSection icon={Navigation} title="Suggested Next Steps" content={explanation.nextSteps} testId="explain-steps" />
                      <ExplanationSection icon={Clock} title="Holding Strategy" content={explanation.holdingStrategy} testId="explain-holding" />
                      {explanation.currencyNote && explanation.currencyNote !== "N/A — investor is using PKR." && (
                        <ExplanationSection icon={Globe} title="Currency Note" content={explanation.currencyNote} testId="explain-currency" />
                      )}

                      <div className="pt-3 border-t border-vest-g5/15 flex justify-center">
                        <button onClick={handleExplain} className="text-xs text-vest-g5 hover:text-vest-g6 transition-colors flex items-center gap-1" data-testid="explain-refresh">
                          <Sparkles className="w-3 h-3" /> Re-explain with current inputs
                        </button>
                      </div>
                    </div>
                  )}
                </GlassCard>
              </motion.div>

              <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ delay: 0.15 }}>
                <div className="p-3 rounded-xl bg-white/40 border border-vest-g5/15 flex items-start gap-2 text-[11px] text-ink-muted/70" data-testid="roi-disclaimer">
                  <Info className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                  <span>Results are projections only. Effective yield = (Expected Yield x Occupancy) - Fees. This model uses simple return calculation without compounding. Past performance does not guarantee future results. This is not financial advice. AI explanations are for informational purposes only.</span>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>
    </MarketingLayout>
  );
}

function ExplanationSection({ icon: Icon, title, content, testId }: { icon: typeof BookOpen; title: string; content: string; testId: string }) {
  return (
    <div className="flex items-start gap-3" data-testid={testId}>
      <div className="w-8 h-8 rounded-lg bg-vest-g1 flex items-center justify-center shrink-0 mt-0.5">
        <Icon className="w-4 h-4 text-vest-g5" />
      </div>
      <div>
        <p className="text-xs font-semibold text-ink-dark mb-1">{title}</p>
        <p className="text-xs text-ink-muted leading-relaxed">{content}</p>
      </div>
    </div>
  );
}

function SensitivityRow({ label, detail, newMonthly, impact, testId }: { label: string; detail: string; newMonthly: number; impact: number; testId: string }) {
  const isNegative = impact < 0;
  return (
    <div className="flex items-center gap-3 p-3 rounded-lg bg-white/30 border border-vest-g5/10" data-testid={testId}>
      <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${isNegative ? "bg-red-50 text-red-500" : "bg-green-50 text-green-500"}`}>
        {isNegative ? <ArrowDown className="w-4 h-4" /> : <ArrowUp className="w-4 h-4" />}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-medium text-ink-dark">{label}</p>
        <p className="text-[10px] text-ink-muted">{detail}</p>
      </div>
      <div className="text-right shrink-0">
        <p className="text-xs font-medium text-ink-dark">{formatPKR(newMonthly)}/mo</p>
        <p className={`text-[10px] font-bold ${isNegative ? "text-red-500" : "text-green-500"}`}>{impact > 0 ? "+" : ""}{impact.toFixed(1)}%</p>
      </div>
    </div>
  );
}

function InputField({ label, icon: Icon, testId, children }: { label: string; icon: typeof Banknote; testId: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-xs font-medium text-ink-muted mb-2 flex items-center gap-1.5">
        <Icon className="w-3.5 h-3.5 text-ink-muted/70" />
        {label}
      </label>
      {children}
    </div>
  );
}

function SliderField({
  label, value, min, max, step, testId, onChange, ticks, children,
}: {
  label: string; value: number; min: number; max: number; step: number;
  testId: string; onChange: (v: number) => void; ticks?: string[]; children?: React.ReactNode;
}) {
  return (
    <div>
      <label className="text-xs font-medium text-ink-muted mb-2 flex items-center justify-between">
        <span>{label}</span>
        <span className="text-vest-g5 font-bold">{value}%</span>
      </label>
      <input
        data-testid={testId}
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-[#1E2BFF]"
      />
      {ticks && (
        <div className="flex justify-between text-[10px] text-ink-muted mt-0.5">
          {ticks.map((t) => <span key={t}>{t}</span>)}
        </div>
      )}
      {children}
    </div>
  );
}

function PresetRow<T extends number>({
  presets, active, onSelect, format, testPrefix,
}: {
  presets: T[]; active: number; onSelect: (v: T) => void; format: (v: T) => string; testPrefix: string;
}) {
  return (
    <div className="flex flex-wrap gap-1.5 mt-2">
      {presets.map((p) => (
        <button
          key={p}
          onClick={() => onSelect(p)}
          data-testid={`${testPrefix}-${p}`}
          className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition border ${
            active === p
              ? "bg-vest-g5/20 border-vest-g5/30 text-vest-g5"
              : "bg-white/50 border-vest-g5/15 text-ink-muted/70 hover:text-ink-muted"
          }`}
        >
          {format(p)}
        </button>
      ))}
    </div>
  );
}

function ResultCard({ label, value, testId, accent }: { label: string; value: string; testId: string; accent?: boolean }) {
  return (
    <div className="p-4 rounded-2xl bg-white/50 border border-vest-g5/15" data-testid={testId}>
      <p className="text-[10px] text-ink-muted/70 mb-1">{label}</p>
      <p className={`text-xl font-bold ${accent ? "text-vest-g5" : "text-ink-dark"}`}>{value}</p>
    </div>
  );
}
