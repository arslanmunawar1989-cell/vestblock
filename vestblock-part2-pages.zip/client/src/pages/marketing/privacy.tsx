import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { SectionHeader } from "@/components/marketing/section-header";
import { Link } from "wouter";
import { Shield, Calendar } from "lucide-react";

const sections = [
  {
    id: "information-collection",
    title: "1. Information Collection",
    content: [
      "We collect information you provide directly to us when you create an account, complete KYC verification, make investments, or communicate with our support team. This includes:",
      "Personal identification data: full name, CNIC number, date of birth, nationality, and residential address as required by SECP regulations and the Pakistan Anti-Money Laundering Act 2010.",
      "Financial information: bank account details, transaction history, investment records, source of funds documentation, and tax identification numbers (NTN/STRN).",
      "Identity verification documents: CNIC/NICOP copies, passport, proof of address, selfie photographs, and biometric data used for identity verification.",
      "Device and usage data: IP address, browser type, device identifiers, operating system, access times, pages viewed, and interactions with our platform.",
      "Communication records: emails, chat messages, phone call recordings (where disclosed), and support ticket correspondence.",
    ],
  },
  {
    id: "use-of-information",
    title: "2. Use of Information",
    content: [
      "We use the information we collect to:",
      "Process and manage your investments, including token issuance, distribution payments, and secondary market transactions in PKR.",
      "Verify your identity and conduct KYC/AML checks as required by SECP, the State Bank of Pakistan (SBP), and the Financial Monitoring Unit (FMU).",
      "Communicate with you about your account, investments, platform updates, regulatory changes, and promotional offers (with your consent).",
      "Improve our platform, develop new features, and conduct research and analytics to enhance user experience.",
      "Detect and prevent fraud, unauthorized access, money laundering, terrorism financing, and other illegal activities.",
      "Comply with legal obligations, regulatory requirements, court orders, and government requests under Pakistani law.",
    ],
  },
  {
    id: "data-sharing",
    title: "3. Data Sharing",
    content: [
      "We do not sell your personal information. We may share your data with:",
      "Regulatory authorities: SECP, FBR, SBP, FMU, and other government bodies as required by Pakistani law and regulations.",
      "KYC/AML service providers: Third-party identity verification services, credit bureaus (such as NADRA e-Sahulat), and compliance screening tools.",
      "Financial partners: Banks, payment processors (JazzCash, Easypaisa, bank transfers), and custodians involved in processing your transactions.",
      "Legal and professional advisors: Lawyers, auditors, and consultants who are bound by confidentiality obligations.",
      "Blockchain networks: Transaction data recorded on public or permissioned blockchains as necessary for token issuance and transfer.",
      "Business transfers: In the event of a merger, acquisition, or sale of assets, your information may be transferred to the acquiring entity.",
    ],
  },
  {
    id: "cookies",
    title: "4. Cookies & Tracking Technologies",
    content: [
      "We use cookies and similar tracking technologies to enhance your experience on our platform:",
      "Essential cookies: Required for platform functionality, security, and session management. These cannot be disabled.",
      "Analytics cookies: Help us understand how users interact with our platform, which pages are most visited, and where improvements are needed. We use privacy-respecting analytics tools.",
      "Preference cookies: Remember your settings such as language preference (Urdu/English), currency display (PKR), and notification preferences.",
      "You can manage cookie preferences through your browser settings. Disabling certain cookies may affect platform functionality.",
    ],
  },
  {
    id: "data-retention",
    title: "5. Data Retention",
    content: [
      "We retain your personal information for as long as necessary to fulfill the purposes outlined in this policy, subject to the following:",
      "Active accounts: Data is retained for the duration of your account being active plus any applicable regulatory retention period.",
      "Regulatory requirements: Under Pakistani AML regulations, we are required to retain KYC records and transaction data for a minimum of five (5) years after account closure or the last transaction, whichever is later.",
      "Tax records: Investment and distribution records are retained for seven (7) years as required by FBR regulations.",
      "Legal claims: Data may be retained for longer periods if necessary to establish, exercise, or defend legal claims.",
      "Upon expiry of retention periods, personal data will be securely deleted or anonymized in accordance with industry best practices.",
    ],
  },
  {
    id: "user-rights",
    title: "6. Your Rights",
    content: [
      "Subject to applicable Pakistani law, including the proposed Personal Data Protection Bill, you have the following rights:",
      "Right to access: Request a copy of the personal information we hold about you.",
      "Right to rectification: Request correction of inaccurate or incomplete personal data.",
      "Right to deletion: Request deletion of your personal data, subject to regulatory retention requirements.",
      "Right to restrict processing: Request that we limit the processing of your personal data in certain circumstances.",
      "Right to data portability: Request a copy of your data in a structured, machine-readable format.",
      "Right to object: Object to processing of your personal data for direct marketing purposes.",
      "Right to withdraw consent: Withdraw previously given consent at any time, without affecting the lawfulness of prior processing.",
      "To exercise any of these rights, please contact us at privacy@vestblock.pk. We will respond to your request within 30 days.",
    ],
  },
  {
    id: "international-transfers",
    title: "7. International Data Transfers",
    content: [
      "Your personal data is primarily stored and processed in Pakistan. However, in certain cases, data may be transferred to jurisdictions outside Pakistan:",
      "Cloud infrastructure: Our platform may use cloud services with servers located in multiple regions, subject to appropriate security measures.",
      "International compliance: When required for cross-border regulatory compliance, such as FATF requirements or international tax reporting obligations.",
      "We ensure that any international data transfers are conducted with appropriate safeguards, including contractual clauses that provide a level of protection equivalent to Pakistani data protection standards.",
    ],
  },
  {
    id: "childrens-privacy",
    title: "8. Children's Privacy",
    content: [
      "VestBlock's platform is not intended for individuals under the age of 18. We do not knowingly collect personal information from minors.",
      "As per Pakistani law and SECP regulations, all investors must be at least 18 years of age and hold a valid CNIC to use our platform.",
      "If we become aware that we have collected personal data from a person under 18, we will take steps to delete such information promptly.",
      "If you believe that a minor has provided us with personal information, please contact us at privacy@vestblock.pk immediately.",
    ],
  },
  {
    id: "changes-to-policy",
    title: "9. Changes to This Policy",
    content: [
      "We may update this Privacy Policy from time to time to reflect changes in our practices, technology, legal requirements, or regulatory guidance.",
      "Material changes will be communicated to you via email notification, in-app notification, or prominent notice on our platform at least 30 days before the changes take effect.",
      "Your continued use of VestBlock after the effective date of any changes constitutes your acceptance of the updated Privacy Policy.",
      "We encourage you to review this policy periodically to stay informed about how we protect your information.",
    ],
  },
  {
    id: "contact",
    title: "10. Contact Us",
    content: [
      "If you have any questions, concerns, or requests regarding this Privacy Policy or our data practices, please contact us:",
      "Data Protection Officer: privacy@vestblock.pk",
      "Mailing Address: VestBlock (Pvt.) Ltd., Floor 12, Centaurus Mall, F-8 Markaz, Islamabad 44000, Pakistan",
      "Phone: +92 51 111 8378 (VEST)",
      "For complaints regarding data handling, you may also contact the relevant regulatory authority in Pakistan.",
    ],
  },
];

export default function PrivacyPage() {
  return (
    <MarketingLayout>
      <PageMeta title="Privacy Policy" description="VestBlock's privacy policy covering data collection, usage, storage, and protection of personal information under Pakistani law." path="/pk/privacy" />
      <section className="relative overflow-hidden py-24 sm:py-32 px-4" data-testid="privacy-hero">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center px-3 py-1 rounded-md text-xs font-medium mb-6 text-vest-g5 border border-vest-g5/15" data-testid="privacy-badge">
            Legal
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-6" data-testid="privacy-headline">
            Privacy{" "}
            <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Policy</span>
          </h1>
          <p className="text-lg text-ink-muted max-w-2xl mx-auto leading-relaxed" data-testid="privacy-subtext">
            Your privacy is fundamental to our mission. Learn how VestBlock collects, uses, and protects your personal information.
          </p>
          <div className="flex items-center justify-center gap-2 mt-6 text-ink-muted text-sm" data-testid="privacy-updated">
            <Calendar className="w-4 h-4" />
            <span>Last updated: February 1, 2026</span>
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="privacy-intro-section">
        <div className="max-w-4xl mx-auto">
          <div className="glass rounded-md p-8 mb-8" data-testid="privacy-intro-card">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-md flex items-center justify-center shrink-0" style={{ background: "rgba(30,43,255,0.08)" }}>
                <Shield className="w-5 h-5 text-vest-g5" />
              </div>
              <div>
                <h3 className="text-ink-dark font-semibold mb-2">Regulatory Framework</h3>
                <p className="text-ink-muted text-sm leading-relaxed">
                  This Privacy Policy is governed by the laws of Pakistan, including the Prevention of Electronic Crimes Act 2016 (PECA), the proposed Personal Data Protection Bill, and regulations issued by the Securities and Exchange Commission of Pakistan (SECP). VestBlock (Pvt.) Ltd. is committed to compliance with all applicable data protection standards.
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            {sections.map((section) => (
              <div key={section.id} className="glass rounded-md p-8" data-testid={`privacy-section-${section.id}`}>
                <h2 className="text-xl font-bold text-ink-dark mb-4" data-testid={`privacy-title-${section.id}`}>
                  {section.title}
                </h2>
                <div className="space-y-3">
                  {section.content.map((paragraph, idx) => (
                    <p key={idx} className="text-ink-muted text-sm leading-relaxed">
                      {paragraph}
                    </p>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center" data-testid="privacy-footer-links">
            <p className="text-ink-muted text-sm">
              See also:{" "}
              <Link href="/terms" className="text-vest-g5 hover:underline" data-testid="privacy-terms-link">
                Terms of Service
              </Link>
              {" | "}
              <Link href="/risk-disclosure" className="text-vest-g5 hover:underline" data-testid="privacy-risk-link">
                Risk Disclosure
              </Link>
            </p>
          </div>
        </div>
      </section>
    </MarketingLayout>
  );
}
