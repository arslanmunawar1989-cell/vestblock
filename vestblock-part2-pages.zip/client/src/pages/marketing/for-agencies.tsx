import { MarketingLayout } from "@/components/marketing/layout";
import { MarketingHero } from "@/components/marketing/marketing-hero";
import { GlassCard } from "@/components/marketing/glass-card";
import { CtaSection } from "@/components/marketing/cta-section";
import { ComplianceDisclaimer } from "@/components/marketing/compliance-disclaimer";
import { PageMeta } from "@/components/marketing/page-meta";
import { motion } from "framer-motion";
import {
  Users, TrendingUp, Globe, BarChart3, Handshake, Shield,
  Wallet, CheckCircle2, Building2, ArrowRight,
} from "lucide-react";

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const benefits = [
  { icon: TrendingUp, title: "New Revenue Stream", desc: "Earn commissions on tokenized property sales. Offer your clients access to institutional-grade investments without capital lock-in." },
  { icon: Globe, title: "Branded Microsite", desc: "Get a co-branded portal to showcase your tokenized listings. Share with clients via a single link — no code required." },
  { icon: BarChart3, title: "Real-Time Dashboard", desc: "Track commissions, client investments, and portfolio performance from a dedicated agency dashboard." },
  { icon: Wallet, title: "Instant Payouts", desc: "Commissions deposited to your VestBlock wallet automatically. Withdraw anytime to your bank account in PKR." },
  { icon: Shield, title: "Compliance Built In", desc: "All KYC/AML verification handled by VestBlock. You focus on relationships — we handle regulatory complexity." },
  { icon: Handshake, title: "Dedicated Support", desc: "Priority support channel, onboarding training, and a dedicated partner success manager for your agency." },
];

const tiers = [
  { name: "Starter", clients: "Up to 25", commission: "1.0%", features: ["Agency dashboard", "Client portfolio view", "Email support"] },
  { name: "Growth", clients: "Up to 100", commission: "1.5%", features: ["Branded microsite", "Priority support", "Marketing materials", "API access"] },
  { name: "Enterprise", clients: "Unlimited", commission: "2.0%+", features: ["Custom branding", "Dedicated manager", "White-label options", "Revenue share tiers"] },
];

const steps = [
  { step: "1", title: "Apply", desc: "Submit your agency details and SECP/PEC registration. Approval within 48 hours." },
  { step: "2", title: "Onboard", desc: "Complete platform training and set up your branded microsite portal." },
  { step: "3", title: "Refer Clients", desc: "Share your portal link. Clients invest in tokenized properties with your guidance." },
  { step: "4", title: "Earn", desc: "Commissions credited automatically on each client investment." },
];

export default function ForAgenciesPage() {
  return (
    <MarketingLayout>
      <PageMeta
        title="For Real Estate Agencies"
        description="Partner with VestBlock to offer tokenized real estate to your clients. Earn commissions, get a branded microsite, and access a real-time agency dashboard."
        path="/pk/for-agencies"
      />

      <MarketingHero
        badge="For Agencies"
        title="Grow Your Agency with"
        highlight="Tokenized Properties"
        subtitle="Partner with VestBlock to offer your clients access to fractional real estate. Earn commissions, get a branded portal, and track everything in real time."
        testIdPrefix="for-agencies"
      />

      <section className="py-16 px-4" data-testid="agency-benefits-section">
        <div className="max-w-5xl mx-auto">
          <motion.div className="text-center mb-12" initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.h2 variants={fadeUp} transition={{ duration: 0.5 }} className="text-3xl sm:text-4xl font-bold text-ink-dark">
              Why Partner with <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">VestBlock?</span>
            </motion.h2>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {benefits.map((b) => (
              <GlassCard key={b.title} data-testid={`agency-benefit-${b.title.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-4 bg-vest-g5/10">
                  <b.icon className="w-5 h-5 text-vest-g5" />
                </div>
                <h3 className="text-lg font-semibold text-ink-dark mb-2">{b.title}</h3>
                <p className="text-sm text-ink-muted/70 leading-relaxed">{b.desc}</p>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-4" data-testid="agency-how-it-works">
        <div className="max-w-4xl mx-auto">
          <motion.div className="text-center mb-12" initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.h2 variants={fadeUp} transition={{ duration: 0.5 }} className="text-3xl sm:text-4xl font-bold text-ink-dark">
              How It <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Works</span>
            </motion.h2>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {steps.map((s) => (
              <GlassCard key={s.step} className="text-center" data-testid={`agency-step-${s.step}`}>
                <div className="w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-3 bg-vest-g5/10 text-vest-g5 font-bold">{s.step}</div>
                <h4 className="text-base font-semibold text-ink-dark mb-1">{s.title}</h4>
                <p className="text-sm text-ink-muted/70">{s.desc}</p>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-4" data-testid="agency-tiers-section">
        <div className="max-w-5xl mx-auto">
          <motion.div className="text-center mb-12" initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.h2 variants={fadeUp} transition={{ duration: 0.5 }} className="text-3xl sm:text-4xl font-bold text-ink-dark">
              Partner <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Tiers</span>
            </motion.h2>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {tiers.map((t, i) => (
              <GlassCard key={t.name} className={i === 1 ? "ring-1 ring-vest-g5/30" : ""} data-testid={`agency-tier-${t.name.toLowerCase()}`}>
                <h3 className="text-xl font-bold text-ink-dark mb-1">{t.name}</h3>
                <div className="text-2xl font-bold bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent mb-1">{t.commission}</div>
                <p className="text-xs text-ink-muted/70 mb-4">Commission per sale · {t.clients} clients</p>
                <ul className="space-y-2">
                  {t.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm text-ink-muted">
                      <CheckCircle2 className="w-3.5 h-3.5 text-vest-g5 shrink-0" /> {f}
                    </li>
                  ))}
                </ul>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      <CtaSection
        icon={Building2}
        title="Ready to"
        highlight="Partner?"
        subtitle="Apply to become a VestBlock agency partner and start earning from tokenized real estate today."
        actions={[
          { label: "Apply Now", href: "/contact" },
          { label: "Learn More", href: "/how-it-works", variant: "secondary" },
        ]}
        testId="agency-cta"
      />
    </MarketingLayout>
  );
}
