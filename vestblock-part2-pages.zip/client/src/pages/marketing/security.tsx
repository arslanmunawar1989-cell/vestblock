import { MarketingLayout } from "@/components/marketing/layout";
import { MarketingHero } from "@/components/marketing/marketing-hero";
import { GlassCard } from "@/components/marketing/glass-card";
import { ComplianceDisclaimer } from "@/components/marketing/compliance-disclaimer";
import { CtaSection } from "@/components/marketing/cta-section";
import { PageMeta } from "@/components/marketing/page-meta";
import { motion } from "framer-motion";
import { Shield, Lock, Server, Eye, KeyRound, Users, FileCheck, Bug, Clock, CheckCircle2 } from "lucide-react";

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const layers = [
  { icon: Lock, title: "Encryption", desc: "All data encrypted in transit (TLS 1.3) and at rest (AES-256). Private keys stored in HSM-backed vaults with multi-party computation." },
  { icon: Server, title: "Infrastructure", desc: "Cloud infrastructure hosted across geographically distributed data centres with automatic failover. 99.95% uptime SLA with real-time monitoring." },
  { icon: KeyRound, title: "Authentication", desc: "Multi-factor authentication (MFA) mandatory for all accounts. OAuth 2.0 with PKCE flow, API key rotation, IP whitelisting, and session management." },
  { icon: Eye, title: "Monitoring", desc: "24/7 security operations centre (SOC) with real-time threat detection, intrusion prevention, and automated incident response workflows." },
  { icon: Users, title: "Access Control", desc: "Role-based access control (RBAC) with least-privilege principle. Segregation of duties for critical operations. Full audit trail on every action." },
  { icon: Bug, title: "Vulnerability Management", desc: "Regular penetration testing by independent auditors. Bug bounty programme. Automated dependency scanning and patch management." },
];

const certifications = [
  { label: "ISO 27001", desc: "Information Security Management System certification" },
  { label: "PCI DSS", desc: "Payment Card Industry Data Security Standard compliance" },
  { label: "SOC 2 Type II", desc: "Service Organisation Control audit for security and availability" },
  { label: "SECP Regulated", desc: "Securities and Exchange Commission of Pakistan oversight" },
];

const practices = [
  "Smart contract audits by Halborn and CertiK before each deployment",
  "Segregated cold-storage wallets for investor assets",
  "Quarterly third-party penetration testing and red-team exercises",
  "Immutable blockchain-based audit logs for all transactions",
  "Automated AML/CFT screening on every transaction",
  "Disaster recovery with RPO < 1 hour and RTO < 4 hours",
  "Annual staff security awareness training and phishing simulations",
  "Data residency within Pakistan for PII as required by local regulations",
];

export default function SecurityPage() {
  return (
    <MarketingLayout>
      <PageMeta
        title="Platform Security"
        description="Learn how VestBlock protects your investments and data with enterprise-grade encryption, SOC 2 compliance, smart contract audits, and 24/7 monitoring."
        path="/pk/security"
      />

      <MarketingHero
        badge="Security"
        title="Enterprise-Grade"
        highlight="Security"
        subtitle="Your investments and personal data are protected by multiple layers of institutional-grade security infrastructure."
        testIdPrefix="security"
      />

      <section className="py-16 px-4" data-testid="security-layers-section">
        <div className="max-w-5xl mx-auto">
          <motion.div className="text-center mb-12" initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.h2 variants={fadeUp} transition={{ duration: 0.5 }} className="text-3xl sm:text-4xl font-bold text-ink-dark">
              Defence in <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Depth</span>
            </motion.h2>
            <motion.p variants={fadeUp} transition={{ duration: 0.5 }} className="text-ink-muted max-w-2xl mx-auto mt-4">
              Six security layers protecting every aspect of the VestBlock platform.
            </motion.p>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {layers.map((l) => (
              <GlassCard key={l.title} data-testid={`security-layer-${l.title.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="w-11 h-11 rounded-xl flex items-center justify-center mb-4 bg-vest-g5/10">
                  <l.icon className="w-5 h-5 text-vest-g5" />
                </div>
                <h3 className="text-lg font-semibold text-ink-dark mb-2">{l.title}</h3>
                <p className="text-sm text-ink-muted/70 leading-relaxed">{l.desc}</p>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-4" data-testid="certifications-section">
        <div className="max-w-5xl mx-auto">
          <motion.div className="text-center mb-12" initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.h2 variants={fadeUp} transition={{ duration: 0.5 }} className="text-3xl sm:text-4xl font-bold text-ink-dark">
              Certifications & <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Compliance</span>
            </motion.h2>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {certifications.map((c) => (
              <GlassCard key={c.label} className="text-center" data-testid={`cert-${c.label.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3 bg-vest-g5/10">
                  <FileCheck className="w-5 h-5 text-vest-g5" />
                </div>
                <h4 className="text-base font-bold text-ink-dark mb-1">{c.label}</h4>
                <p className="text-xs text-ink-muted/70">{c.desc}</p>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-4" data-testid="practices-section">
        <div className="max-w-3xl mx-auto">
          <motion.div className="text-center mb-10" initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.h2 variants={fadeUp} transition={{ duration: 0.5 }} className="text-3xl sm:text-4xl font-bold text-ink-dark">
              Security <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Practices</span>
            </motion.h2>
          </motion.div>
          <GlassCard>
            <ul className="space-y-4">
              {practices.map((p, i) => (
                <li key={i} className="flex items-start gap-3" data-testid={`practice-${i}`}>
                  <CheckCircle2 className="w-4 h-4 text-vest-g5 shrink-0 mt-0.5" />
                  <span className="text-sm text-ink-muted leading-relaxed">{p}</span>
                </li>
              ))}
            </ul>
          </GlassCard>
        </div>
      </section>

      <div className="max-w-3xl mx-auto px-4">
        <ComplianceDisclaimer
          variant="regulatory"
          title="Responsible Disclosure"
          text="If you discover a security vulnerability, please report it to security@vestblock.pk. We operate a responsible disclosure programme and will not take legal action against researchers who follow our reporting guidelines."
          testId="security-disclosure"
        />
      </div>

      <CtaSection
        icon={Shield}
        title="Questions About"
        highlight="Security?"
        subtitle="Our security team is available to answer questions from investors and partners."
        actions={[
          { label: "Contact Security Team", href: "/contact" },
          { label: "Risk Disclosure", href: "/risk-disclosure", variant: "secondary" },
        ]}
        testId="security-cta"
      />
    </MarketingLayout>
  );
}
