import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { SectionHeader } from "@/components/marketing/section-header";
import { Link } from "wouter";
import { FileText, Calendar, AlertTriangle } from "lucide-react";

const termsSections = [
  {
    id: "acceptance",
    title: "1. Acceptance of Terms",
    content: [
      "By accessing or using the VestBlock platform (\"Platform\"), operated by VestBlock (Pvt.) Ltd. (\"Company\", \"we\", \"us\"), you agree to be bound by these Terms of Service (\"Terms\") and all applicable laws and regulations of Pakistan.",
      "If you do not agree to these Terms, you must not access or use the Platform. These Terms constitute a legally binding agreement between you and VestBlock.",
      "We reserve the right to modify these Terms at any time. Material changes will be communicated via email or in-app notification at least 30 days prior to taking effect. Your continued use of the Platform after such changes constitutes acceptance of the revised Terms.",
    ],
  },
  {
    id: "eligibility",
    title: "2. Eligibility",
    content: [
      "To use the VestBlock Platform, you must meet the following eligibility requirements:",
      "Be at least 18 years of age at the time of registration.",
      "Hold a valid Computerized National Identity Card (CNIC) or National Identity Card for Overseas Pakistanis (NICOP) issued by NADRA.",
      "Not be a person sanctioned under any applicable sanctions regime, including UN Security Council sanctions, or listed on any government watch list.",
      "Not be a resident of a jurisdiction where real estate tokenization or digital securities are prohibited by law.",
      "Successfully complete our Know Your Customer (KYC) and Anti-Money Laundering (AML) verification process as mandated by SECP regulations.",
      "Provide accurate and complete information during registration and maintain its accuracy throughout your use of the Platform.",
      "Corporate entities must be duly registered with SECP or relevant authority and provide all required documentation including Certificate of Incorporation, NTN, and authorized signatory details.",
    ],
  },
  {
    id: "account",
    title: "3. Account Responsibilities",
    content: [
      "You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account.",
      "You must immediately notify VestBlock of any unauthorized use of your account or any other security breach at security@vestblock.pk.",
      "VestBlock reserves the right to suspend or terminate your account if we suspect unauthorized access, fraudulent activity, or violation of these Terms.",
      "You may not transfer, assign, or delegate your account to any other person without prior written consent from VestBlock.",
      "Multi-factor authentication (MFA) is mandatory for all accounts and must remain enabled at all times.",
    ],
  },
  {
    id: "investment-terms",
    title: "4. Investment Terms",
    content: [
      "All investments made through the VestBlock Platform are subject to the following terms:",
      "Token purchases: Property tokens represent fractional ownership interests in specific real estate assets and are issued as digital securities under applicable SECP regulations.",
      "Minimum investment: The minimum investment amount varies by property and is denominated in Pakistani Rupees (PKR). Current minimums start at PKR 50,000.",
      "Returns: Rental yields and capital appreciation are not guaranteed. Historical performance does not guarantee future results. All projected returns are estimates only.",
      "Distributions: Rental income distributions are made quarterly, subject to property performance, occupancy rates, and deduction of applicable fees and expenses.",
      "Lock-up periods: Certain tokens may be subject to lock-up periods during which they cannot be sold or transferred. Lock-up durations are specified in each property's offering documents.",
      "Secondary market: Token trading on VestBlock's secondary marketplace is subject to platform rules, liquidity availability, and regulatory restrictions.",
      "All investments carry risk. Please review our Risk Disclosure statement before investing.",
    ],
  },
  {
    id: "fees",
    title: "5. Fees & Charges",
    content: [
      "VestBlock charges the following fees for platform services (all amounts in PKR):",
      "Platform fee: Up to 2.5% of each investment transaction, disclosed at the time of purchase.",
      "Management fee: Annual management fee of up to 1.5% of assets under management, deducted from rental distributions.",
      "Trading fee: Up to 1.0% per secondary market transaction, split between buyer and seller as disclosed.",
      "Withdrawal fee: Standard bank transfer fees apply. Processing times vary by bank (typically 1-3 business days).",
      "Currency conversion: For international transactions, applicable FX rates plus a conversion spread will apply.",
      "All fees are subject to applicable taxes including Federal Excise Duty (FED), Sales Tax, and Withholding Tax as prescribed by FBR regulations.",
      "VestBlock reserves the right to modify fee structures with 60 days prior written notice to users.",
    ],
  },
  {
    id: "intellectual-property",
    title: "6. Intellectual Property",
    content: [
      "All content, features, and functionality of the VestBlock Platform, including but not limited to text, graphics, logos, icons, images, software, and source code, are the exclusive property of VestBlock (Pvt.) Ltd. and are protected by Pakistani and international intellectual property laws.",
      "You are granted a limited, non-exclusive, non-transferable license to access and use the Platform for personal, non-commercial investment purposes only.",
      "You may not copy, modify, distribute, sell, or lease any part of the Platform or its content without prior written consent from VestBlock.",
      "The VestBlock name, logo, and all related product and service names, designs, and slogans are trademarks of VestBlock (Pvt.) Ltd. You may not use these marks without prior written permission.",
      "User-generated content (e.g., reviews, comments) remains your property, but you grant VestBlock a non-exclusive, royalty-free license to use, display, and distribute such content on the Platform.",
    ],
  },
  {
    id: "disclaimers",
    title: "7. Disclaimers",
    content: [
      "THE PLATFORM IS PROVIDED \"AS IS\" AND \"AS AVAILABLE\" WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.",
      "VestBlock does not warrant that the Platform will be uninterrupted, error-free, secure, or free of viruses or other harmful components.",
      "Investment information provided on the Platform, including property valuations, projected returns, and market data, is for informational purposes only and does not constitute financial, legal, or tax advice.",
      "VestBlock is not a bank, financial institution, or licensed investment advisor. We operate as a technology platform facilitating real estate tokenization under SECP regulations.",
      "Past performance of any property or token does not guarantee future results. The value of your investment can go down as well as up.",
    ],
  },
  {
    id: "limitation-of-liability",
    title: "8. Limitation of Liability",
    content: [
      "TO THE MAXIMUM EXTENT PERMITTED BY PAKISTANI LAW, VESTBLOCK SHALL NOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, INCLUDING BUT NOT LIMITED TO LOSS OF PROFITS, DATA, OR INVESTMENT VALUE.",
      "VestBlock's total aggregate liability for any claim arising from or related to these Terms or the Platform shall not exceed the total fees paid by you to VestBlock in the twelve (12) months preceding the claim.",
      "VestBlock shall not be liable for any losses arising from market fluctuations, property devaluation, regulatory changes, force majeure events, or actions of third-party service providers.",
      "This limitation of liability applies to the fullest extent permitted by the laws of Pakistan, regardless of the legal theory upon which the claim is based.",
    ],
  },
  {
    id: "governing-law",
    title: "9. Governing Law",
    content: [
      "These Terms shall be governed by and construed in accordance with the laws of the Islamic Republic of Pakistan, without regard to its conflict of law provisions.",
      "All matters relating to the Platform and these Terms, and any dispute or claim arising from or related to them, shall be governed by the laws of Pakistan as applicable in Islamabad Capital Territory.",
      "VestBlock operates under the regulatory framework established by the Securities and Exchange Commission of Pakistan (SECP), including the Securities Act 2015, the Companies Act 2017, and all applicable SECP regulations and notifications.",
      "Nothing in these Terms shall limit or exclude any rights you may have under mandatory provisions of Pakistani consumer protection law.",
    ],
  },
  {
    id: "dispute-resolution",
    title: "10. Dispute Resolution",
    content: [
      "Any dispute, controversy, or claim arising out of or relating to these Terms, or the breach, termination, or invalidity thereof, shall be resolved through the following process:",
      "Informal resolution: Parties shall first attempt to resolve any dispute informally by contacting VestBlock's dispute resolution team at disputes@vestblock.pk within 30 days of the issue arising.",
      "Mediation: If informal resolution fails, parties agree to attempt mediation through a mutually agreed mediator or through the Islamabad Chamber of Commerce mediation services.",
      "Arbitration: If mediation is unsuccessful within 60 days, the dispute shall be referred to arbitration under the Arbitration Act 1940 (as applicable in Pakistan). The arbitration shall be conducted in Islamabad in the English language.",
      "Court jurisdiction: Notwithstanding the above, either party may seek injunctive or other equitable relief from the courts of competent jurisdiction in Islamabad, Pakistan.",
      "Class action waiver: You agree that any dispute resolution proceedings will be conducted on an individual basis and not as a class action or collective proceeding.",
    ],
  },
];

export default function TermsPage() {
  return (
    <MarketingLayout>
      <PageMeta title="Terms of Service" description="VestBlock's terms of service covering account usage, investment terms, fees, liability, and dispute resolution under Pakistani law." path="/pk/terms" />
      <section className="relative overflow-hidden py-24 sm:py-32 px-4" data-testid="terms-hero">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center px-3 py-1 rounded-md text-xs font-medium mb-6 text-vest-g5 border border-vest-g5/15" data-testid="terms-badge">
            Legal
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-6" data-testid="terms-headline">
            Terms of{" "}
            <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Service</span>
          </h1>
          <p className="text-lg text-ink-muted max-w-2xl mx-auto leading-relaxed" data-testid="terms-subtext">
            Please read these terms carefully before using the VestBlock platform.
          </p>
          <div className="flex items-center justify-center gap-2 mt-6 text-ink-muted text-sm" data-testid="terms-updated">
            <Calendar className="w-4 h-4" />
            <span>Last updated: February 1, 2026</span>
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="terms-content-section">
        <div className="max-w-4xl mx-auto">
          <div className="glass rounded-md p-8 mb-8" data-testid="secp-disclaimer-card">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-md flex items-center justify-center shrink-0" style={{ background: "rgba(255,200,0,0.1)" }}>
                <AlertTriangle className="w-5 h-5" style={{ color: "#ffd700" }} />
              </div>
              <div>
                <h3 className="text-ink-dark font-semibold mb-2">SECP Regulatory Disclaimer</h3>
                <p className="text-ink-muted text-sm leading-relaxed">
                  VestBlock (Pvt.) Ltd. is a technology platform operating under the regulatory framework of the Securities and Exchange Commission of Pakistan (SECP). Digital property tokens issued on this platform are classified as digital securities under applicable SECP regulations. Investing in digital securities involves substantial risk of loss. Prospective investors should carefully review all offering documents and consult with qualified financial and legal advisors before making investment decisions.
                </p>
              </div>
            </div>
          </div>

          <div className="glass rounded-md p-6 mb-8" data-testid="terms-toc">
            <h3 className="text-ink-dark font-semibold mb-4 flex items-center gap-2">
              <FileText className="w-4 h-4 text-vest-g5" />
              Table of Contents
            </h3>
            <nav className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {termsSections.map((section) => (
                <a
                  key={section.id}
                  href={`#${section.id}`}
                  className="text-sm text-ink-muted hover:text-vest-g5 transition-colors py-1"
                  data-testid={`terms-toc-${section.id}`}
                >
                  {section.title}
                </a>
              ))}
            </nav>
          </div>

          <div className="space-y-8">
            {termsSections.map((section) => (
              <div key={section.id} id={section.id} className="glass rounded-md p-8" data-testid={`terms-section-${section.id}`}>
                <h2 className="text-xl font-bold text-ink-dark mb-4" data-testid={`terms-title-${section.id}`}>
                  {section.title}
                </h2>
                <div className="space-y-3">
                  {section.content.map((paragraph, idx) => (
                    <p key={idx} className="text-ink-muted text-sm leading-relaxed">
                      {paragraph}
                    </p>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center" data-testid="terms-footer-links">
            <p className="text-ink-muted text-sm">
              See also:{" "}
              <Link href="/privacy" className="text-vest-g5 hover:underline" data-testid="terms-privacy-link">
                Privacy Policy
              </Link>
              {" | "}
              <Link href="/risk-disclosure" className="text-vest-g5 hover:underline" data-testid="terms-risk-link">
                Risk Disclosure
              </Link>
            </p>
          </div>
        </div>
      </section>
    </MarketingLayout>
  );
}
