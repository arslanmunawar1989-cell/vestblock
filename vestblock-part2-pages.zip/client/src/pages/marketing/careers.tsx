import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { SectionHeader } from "@/components/marketing/section-header";
import { Link } from "wouter";
import {
  MapPin,
  Briefcase,
  Heart,
  Shield,
  Zap,
  Users,
  Clock,
  TrendingUp,
  ArrowRight,
  Building2,
  Code,
  Palette,
  Handshake,
  BarChart3,
  Scale,
} from "lucide-react";

const values = [
  { icon: Zap, title: "Innovation First", desc: "We push boundaries with blockchain, smart contracts, and AI to transform how Pakistan invests in real estate." },
  { icon: Users, title: "Collaborative Culture", desc: "Cross-functional teams work together in an open, transparent environment where every voice matters." },
  { icon: Shield, title: "Integrity & Compliance", desc: "We operate with the highest ethical standards, adhering to SECP regulations and international best practices." },
  { icon: TrendingUp, title: "Growth Mindset", desc: "Continuous learning is part of our DNA. We invest in your professional development and career progression." },
];

const positions = [
  { id: 1, title: "Senior Full Stack Engineer", location: "Karachi", department: "Engineering", type: "Full-time", icon: Code },
  { id: 2, title: "Compliance Officer", location: "Islamabad", department: "Legal & Compliance", type: "Full-time", icon: Scale },
  { id: 3, title: "Product Designer", location: "Remote", department: "Design", type: "Remote", icon: Palette },
  { id: 4, title: "Blockchain Developer", location: "Lahore", department: "Engineering", type: "Full-time", icon: Code },
  { id: 5, title: "Head of Partnerships", location: "Karachi", department: "Business Development", type: "Full-time", icon: Handshake },
  { id: 6, title: "Data Analyst", location: "Remote", department: "Analytics", type: "Remote", icon: BarChart3 },
];

const benefits = [
  { icon: Heart, title: "Health Insurance", desc: "Comprehensive medical, dental, and vision coverage for you and your family." },
  { icon: Shield, title: "EOBI & Provident Fund", desc: "Employer contributions to EOBI and company provident fund for long-term security." },
  { icon: Clock, title: "Flexible Hours", desc: "Core hours with flexible scheduling. Work when you're most productive." },
  { icon: TrendingUp, title: "Equity & Token Allocation", desc: "Participate in VestBlock's growth through ESOP and platform token allocations." },
];

export default function CareersPage() {
  return (
    <MarketingLayout>
      <PageMeta title="Careers" description="Join the VestBlock team. Explore career opportunities in fintech, blockchain, real estate, compliance, and engineering in Pakistan." path="/pk/careers" />
      <section className="relative overflow-hidden py-24 sm:py-32 px-4" data-testid="careers-hero">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium mb-6 text-vest-g5 border border-vest-g5/15" data-testid="careers-badge">
            Careers
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-6" data-testid="careers-headline">
            Join the Future of{" "}
            <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Real Estate</span>
          </h1>
          <p className="text-lg text-ink-muted max-w-2xl mx-auto leading-relaxed" data-testid="careers-subtext">
            Build the platform that's democratizing real estate investment for millions of Pakistanis. We're looking for passionate people to join our mission.
          </p>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="culture-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Culture"
            title="Why"
            highlight="VestBlock?"
            description="We're building more than a product — we're building a movement. Here's what drives us every day."
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((v, i) => (
              <div key={i} className="glass rounded-md p-6" data-testid={`value-card-${i}`}>
                <div className="w-12 h-12 rounded-md flex items-center justify-center mb-5" style={{ background: "rgba(30,43,255,0.08)" }}>
                  <v.icon className="w-6 h-6 text-vest-g5" />
                </div>
                <h3 className="text-lg font-semibold text-ink-dark mb-2">{v.title}</h3>
                <p className="text-sm text-ink-muted leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4 " data-testid="positions-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Open Roles"
            title="Current"
            highlight="Openings"
            description="Find your next role at VestBlock. We offer competitive packages and a chance to shape Pakistan's fintech landscape."
          />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {positions.map((pos) => (
              <div
                key={pos.id}
                className="glass  rounded-md p-6 transition-all duration-300"
                data-testid={`position-card-${pos.id}`}
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-md flex items-center justify-center shrink-0" style={{ background: "rgba(30,43,255,0.08)" }}>
                    <pos.icon className="w-6 h-6 text-vest-g5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg font-semibold text-ink-dark mb-2" data-testid={`position-title-${pos.id}`}>{pos.title}</h3>
                    <div className="flex flex-wrap items-center gap-3 mb-4">
                      <span className="flex items-center gap-1.5 text-xs text-ink-muted">
                        <MapPin className="w-3 h-3" /> {pos.location}
                      </span>
                      <span className="flex items-center gap-1.5 text-xs text-ink-muted">
                        <Briefcase className="w-3 h-3" /> {pos.department}
                      </span>
                      <span
                        className="px-2.5 py-1 rounded-full text-xs font-medium"
                        style={{
                          background: pos.type === "Remote" ? "rgba(30,43,255,0.12)" : "rgba(58,70,255,0.12)",
                          color: "#ffffff",
                        }}
                        data-testid={`position-type-${pos.id}`}
                      >
                        {pos.type}
                      </span>
                    </div>
                    <Link href="/contact">
                      <span className="inline-flex items-center gap-1.5 text-sm font-medium text-vest-g5 cursor-pointer" data-testid={`link-apply-${pos.id}`}>
                        Apply Now <ArrowRight className="w-3.5 h-3.5" />
                      </span>
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="benefits-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Perks"
            title="Benefits &"
            highlight="Perks"
            description="We take care of our team so they can focus on building amazing things."
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((b, i) => (
              <div key={i} className="glass rounded-md p-6 text-center" data-testid={`benefit-card-${i}`}>
                <div className="w-12 h-12 rounded-md flex items-center justify-center mx-auto mb-4" style={{ background: "rgba(30,43,255,0.08)" }}>
                  <b.icon className="w-6 h-6 text-vest-g5" />
                </div>
                <h3 className="text-lg font-semibold text-ink-dark mb-2">{b.title}</h3>
                <p className="text-sm text-ink-muted leading-relaxed">{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </MarketingLayout>
  );
}
