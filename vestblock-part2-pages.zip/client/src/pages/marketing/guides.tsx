import { Link } from "wouter";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { GlassCard } from "@/components/marketing/glass-card";
import { GlassButton } from "@/components/marketing/glass-button";
import { motion } from "framer-motion";
import {
  BookOpen, TrendingUp, ShieldCheck, DoorOpen, Building2,
  Calculator, Wallet, Users, ArrowRight, ChevronRight,
  Layers, FileText, Scale,
} from "lucide-react";

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const guideCategories = [
  {
    title: "Getting Started",
    desc: "Essential reading for new investors on VestBlock.",
    icon: BookOpen,
    guides: [
      { title: "How Tokenized Ownership Works", desc: "Understand fractional property ownership through blockchain tokens and SPV structures.", link: "/blog/tokenized-ownership-vs-traditional-property", time: "9 min" },
      { title: "Your First Investment: Step by Step", desc: "From account creation to your first token purchase — a complete walkthrough.", link: "/how-it-works", time: "5 min" },
      { title: "Understanding KYC Requirements", desc: "What documents you need, how long verification takes, and why it matters.", link: "/faq", time: "3 min" },
    ],
  },
  {
    title: "Returns & Income",
    desc: "Learn how you earn from tokenized property investments.",
    icon: TrendingUp,
    guides: [
      { title: "Rental Yield Explained in Pakistan", desc: "Gross vs net yield, typical ranges by city, and how tokenization changes the math.", link: "/blog/rental-yield-explained-pakistan", time: "8 min" },
      { title: "Monthly Distributions: How Rent Reaches Your Wallet", desc: "The complete flow from tenant payment to your VestBlock wallet.", link: "/blog/monthly-distributions-how-rent-reaches-your-wallet", time: "5 min" },
      { title: "ROI Calculator Guide", desc: "Use our interactive calculator to model projected returns on any investment amount.", link: "/roi-calculator", time: "3 min" },
    ],
  },
  {
    title: "Fees & Costs",
    desc: "Complete transparency on every charge.",
    icon: Calculator,
    guides: [
      { title: "Fees & Costs Breakdown", desc: "Every fee, every charge, fully explained — no surprises.", link: "/blog/fees-and-costs-breakdown", time: "6 min" },
      { title: "Fee Comparison by Investor Tier", desc: "How fees differ across Starter, Growth, and Institutional tiers.", link: "/fees", time: "4 min" },
      { title: "Mortgage Calculator", desc: "Estimate EMI payments for traditional property comparison.", link: "/mortgage-calculator", time: "3 min" },
    ],
  },
  {
    title: "Exits & Liquidity",
    desc: "How and when you can sell your investment.",
    icon: DoorOpen,
    guides: [
      { title: "How Exit Windows Work", desc: "Complete guide to VestBlock's structured liquidity model.", link: "/blog/how-exit-windows-work", time: "7 min" },
      { title: "Exit Windows Schedule & Countdown", desc: "View upcoming exit dates, eligibility, and the step-by-step exit process.", link: "/exit-windows", time: "5 min" },
      { title: "Full vs Partial Exits Explained", desc: "Your options for selling all or part of your holdings.", link: "/blog/how-exit-windows-work", time: "4 min" },
    ],
  },
  {
    title: "Risk & Compliance",
    desc: "Honest assessment of risks and regulatory framework.",
    icon: ShieldCheck,
    guides: [
      { title: "Risk Warnings: What Every Investor Should Know", desc: "Capital risk, liquidity risk, income risk — read before investing.", link: "/blog/risk-warnings-real-estate-tokenization", time: "7 min" },
      { title: "SECP Regulatory Framework", desc: "How Pakistan's securities regulator views tokenized real estate.", link: "/blog/secp-regulatory-framework-tokenization", time: "7 min" },
      { title: "Understanding SPV Structures", desc: "What SPVs are, why they protect you, and their limitations.", link: "/blog/understanding-spv-structure-pakistan", time: "6 min" },
    ],
  },
  {
    title: "Market Analysis",
    desc: "Pakistan-focused property market insights.",
    icon: Building2,
    guides: [
      { title: "Pakistan Real Estate Market Outlook 2026", desc: "Key trends, growth corridors, and tokenization impact.", link: "/blog/pakistan-real-estate-market-outlook-2026", time: "10 min" },
      { title: "DHA vs Bahria Town: Investment Comparison", desc: "Yield, growth, and risk compared across Pakistan's top housing societies.", link: "/blog/dha-bahria-town-investment-comparison", time: "8 min" },
      { title: "Pakistan Market Overview", desc: "The PKR 50 trillion opportunity and why tokenization matters.", link: "/market", time: "5 min" },
    ],
  },
];

export default function GuidesPage() {
  return (
    <MarketingLayout>
      <PageMeta title="Investor Guides" description="Comprehensive guides for tokenized real estate investing. Learn about property analysis, portfolio diversification, and risk management." path="/pk/guides" />
      <section className="relative py-24 sm:py-32 px-4 overflow-hidden" data-testid="guides-hero">
        <div className="absolute inset-0 bg-gradient-to-b from-vest-g5/5 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div variants={fadeUp} initial="hidden" animate="visible">
            <span className="inline-flex items-center px-3.5 py-1.5 rounded-2xl text-xs font-medium mb-6 text-vest-g5 bg-vest-g5/10 border border-vest-g5/20" data-testid="guides-badge">
              Investor Guides
            </span>
            <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-5 tracking-tight" data-testid="guides-headline">
              Everything You Need
              <br />to Invest with <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Confidence</span>
            </h1>
            <p className="text-base sm:text-lg text-ink-muted max-w-2xl mx-auto leading-relaxed" data-testid="guides-subtext">
              Comprehensive guides covering every aspect of tokenized real estate investment in Pakistan — from your first token purchase to exit strategies.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="px-4 pb-20" data-testid="guides-content">
        <div className="max-w-4xl mx-auto space-y-10">
          {guideCategories.map((cat, ci) => (
            <motion.div key={cat.title} variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} transition={{ delay: ci * 0.04 }} data-testid={`guide-category-${ci}`}>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-9 h-9 rounded-xl bg-vest-g5/15 flex items-center justify-center">
                  <cat.icon className="w-4 h-4 text-vest-g5" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-ink-dark">{cat.title}</h2>
                  <p className="text-xs text-ink-muted/70">{cat.desc}</p>
                </div>
              </div>
              <div className="space-y-2">
                {cat.guides.map((guide, gi) => (
                  <Link key={gi} href={guide.link} className="block" data-testid={`guide-${ci}-${gi}`}>
                    <GlassCard className="hover:border-vest-g5/20 transition-colors cursor-pointer group p-4">
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <h3 className="text-sm font-semibold text-ink-dark group-hover:text-vest-g5 transition-colors">{guide.title}</h3>
                          <p className="text-xs text-ink-muted/70 mt-1 leading-relaxed">{guide.desc}</p>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <span className="text-[10px] text-ink-muted">{guide.time}</span>
                          <ChevronRight className="w-4 h-4 text-ink-muted group-hover:text-vest-g5 transition-colors" />
                        </div>
                      </div>
                    </GlassCard>
                  </Link>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="py-12 px-4" data-testid="guides-cta">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <GlassCard className="border border-vest-g5/20 bg-gradient-to-br from-vest-g5/5 to-transparent py-10">
              <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark mb-3">Have More <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Questions?</span></h2>
              <p className="text-sm text-ink-muted mb-6 max-w-md mx-auto">
                Check our FAQ for quick answers or browse the glossary for real estate and tokenization terms.
              </p>
              <div className="flex flex-wrap items-center justify-center gap-3">
                <Link href="/faq">
                  <GlassButton data-testid="guides-cta-faq">View FAQ <ArrowRight className="w-4 h-4" /></GlassButton>
                </Link>
                <Link href="/glossary">
                  <GlassButton variant="secondary" data-testid="guides-cta-glossary">Glossary</GlassButton>
                </Link>
              </div>
            </GlassCard>
          </motion.div>
        </div>
      </section>
    </MarketingLayout>
  );
}
