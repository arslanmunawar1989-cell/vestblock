import { useState, useRef, useEffect } from "react";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { useRegion } from "@/lib/region";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Bot, User, ChevronDown, ChevronUp, FileText, Sparkles, Shield, AlertTriangle } from "lucide-react";

interface Citation {
  title: string;
  slug: string;
  type: string;
}

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  citations?: Citation[];
  timestamp: Date;
}

const SUGGESTED_QUESTIONS = [
  "What is the minimum investment?",
  "How do exit windows work?",
  "What fees does VestBlock charge?",
  "How is my data protected?",
  "Do I legally own the property?",
  "How does tokenization work?",
];

export default function AskPage() {
  const { region } = useRegion();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function handleSend(query?: string) {
    const text = query || input.trim();
    if (!text || isLoading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      content: text,
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsLoading(true);

    try {
      const res = await fetch("/api/ai/rag/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: text, region: region.code.toUpperCase() }),
      });
      const data = await res.json();
      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: data.answer || "Sorry, I couldn't process that request.",
        citations: data.citations || [],
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content: "Something went wrong. Please try again.",
          timestamp: new Date(),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  return (
    <MarketingLayout>
      <PageMeta title="Ask VestBlock" description="Get answers about real estate tokenization, investing, and the VestBlock platform." />

      <div className="min-h-[calc(100vh-80px)] flex flex-col" data-testid="ask-page">
        <div className="py-8 px-6 text-center border-b border-vest-g5/15" style={{ background: "linear-gradient(135deg, #EEF0FF 0%, #D6DBFF 50%, #E8EAFF 100%)" }}>
          <div className="flex items-center justify-center gap-2 mb-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#1E2BFF] to-[#3B4FFF] flex items-center justify-center" data-testid="ask-icon">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-ink-dark" data-testid="ask-heading">Ask VestBlock</h1>
          </div>
          <p className="text-sm text-ink-muted max-w-xl mx-auto">
            Get instant answers about real estate tokenization, investing, fees, and more.
          </p>
          <div className="flex items-center justify-center gap-1.5 mt-3 text-xs text-ink-muted/70">
            <Shield className="w-3.5 h-3.5" />
            <span>Informational only — not financial advice</span>
          </div>
        </div>

        <div className="flex-1 max-w-3xl w-full mx-auto flex flex-col" data-testid="chat-container">
          <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-6 space-y-4" data-testid="messages-area">
            {messages.length === 0 && (
              <motion.div
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center py-12"
              >
                <Bot className="w-12 h-12 mx-auto text-[#1E2BFF]/30 mb-4" />
                <p className="text-sm text-ink-muted mb-6">Ask me anything about VestBlock</p>
                <div className="flex flex-wrap justify-center gap-2 max-w-lg mx-auto">
                  {SUGGESTED_QUESTIONS.map((q) => (
                    <button
                      key={q}
                      onClick={() => handleSend(q)}
                      className="text-xs px-3 py-1.5 rounded-full border border-vest-g5/20 text-ink-muted hover:border-[#1E2BFF]/40 hover:text-[#1E2BFF] transition-colors bg-white/60"
                      data-testid={`suggested-q-${q.slice(0, 20).replace(/\s/g, "-").toLowerCase()}`}
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </motion.div>
            )}

            <AnimatePresence mode="popLayout">
              {messages.map((msg) => (
                <MessageBubble key={msg.id} message={msg} />
              ))}
            </AnimatePresence>

            {isLoading && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex gap-3 items-start"
              >
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#1E2BFF] to-[#3B4FFF] flex items-center justify-center shrink-0">
                  <Bot className="w-4 h-4 text-white" />
                </div>
                <div className="bg-white/80 border border-vest-g5/15 rounded-xl px-4 py-3">
                  <div className="flex gap-1.5" data-testid="typing-indicator">
                    <span className="w-2 h-2 rounded-full bg-[#1E2BFF]/40 animate-bounce" style={{ animationDelay: "0ms" }} />
                    <span className="w-2 h-2 rounded-full bg-[#1E2BFF]/40 animate-bounce" style={{ animationDelay: "150ms" }} />
                    <span className="w-2 h-2 rounded-full bg-[#1E2BFF]/40 animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              </motion.div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="border-t border-vest-g5/15 px-4 sm:px-6 py-4 bg-white/50 backdrop-blur-sm">
            <div className="flex gap-2 items-end">
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask about VestBlock..."
                rows={1}
                className="flex-1 resize-none rounded-xl border border-vest-g5/20 bg-white px-4 py-3 text-sm text-ink-dark placeholder:text-ink-muted/50 focus:outline-none focus:ring-2 focus:ring-[#1E2BFF]/20 focus:border-[#1E2BFF]/40"
                data-testid="ask-input"
              />
              <Button
                onClick={() => handleSend()}
                disabled={!input.trim() || isLoading}
                className="bg-gradient-to-r from-[#1E2BFF] to-[#3B4FFF] text-white rounded-xl h-[46px] w-[46px] p-0 shrink-0"
                data-testid="ask-send"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-[10px] text-ink-muted/50 mt-2 text-center">
              AI-generated responses are informational only and do not constitute financial advice.
            </p>
          </div>
        </div>
      </div>
    </MarketingLayout>
  );
}

function MessageBubble({ message }: { message: Message }) {
  const [showSources, setShowSources] = useState(false);
  const isUser = message.role === "user";

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex gap-3 items-start ${isUser ? "flex-row-reverse" : ""}`}
      data-testid={`message-${message.role}-${message.id}`}
    >
      <div
        className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
          isUser
            ? "bg-ink-dark/10"
            : "bg-gradient-to-br from-[#1E2BFF] to-[#3B4FFF]"
        }`}
      >
        {isUser ? (
          <User className="w-4 h-4 text-ink-dark/60" />
        ) : (
          <Bot className="w-4 h-4 text-white" />
        )}
      </div>

      <div className={`max-w-[80%] ${isUser ? "text-right" : ""}`}>
        <div
          className={`rounded-xl px-4 py-3 text-sm leading-relaxed ${
            isUser
              ? "bg-gradient-to-r from-[#1E2BFF] to-[#3B4FFF] text-white"
              : "bg-white/80 border border-vest-g5/15 text-ink-dark"
          }`}
        >
          {(() => {
            const { body, disclaimer } = splitDisclaimer(message.content);
            return (
              <>
                <div className="whitespace-pre-wrap">{body}</div>
                {disclaimer && (
                  <div className="mt-3 pt-2.5 border-t border-vest-g5/10 flex gap-1.5 items-start">
                    <AlertTriangle className="w-3 h-3 text-amber-500 shrink-0 mt-0.5" />
                    <p className="text-[11px] text-ink-muted/60 leading-relaxed italic">{disclaimer}</p>
                  </div>
                )}
              </>
            );
          })()}
        </div>

        {!isUser && message.citations && message.citations.length > 0 && (
          <div className="mt-1.5">
            <button
              onClick={() => setShowSources(!showSources)}
              className="flex items-center gap-1 text-xs text-ink-muted/60 hover:text-[#1E2BFF] transition-colors"
              data-testid={`toggle-sources-${message.id}`}
            >
              <FileText className="w-3 h-3" />
              <span>{message.citations.length} source{message.citations.length > 1 ? "s" : ""} used</span>
              {showSources ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>
            <AnimatePresence>
              {showSources && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-1.5 space-y-1 overflow-hidden"
                >
                  {message.citations.map((c, i) => (
                    <a
                      key={i}
                      href={c.slug}
                      className="flex items-center gap-1.5 text-xs text-[#1E2BFF]/70 hover:text-[#1E2BFF] transition-colors"
                      data-testid={`citation-${i}`}
                    >
                      <span className="w-1 h-1 rounded-full bg-[#1E2BFF]/40" />
                      {c.title}
                      <span className="text-ink-muted/40">({c.type})</span>
                    </a>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </div>
    </motion.div>
  );
}

function splitDisclaimer(text: string): { body: string; disclaimer: string | null } {
  const disclaimerIdx = text.indexOf("\n\n---\n*");
  if (disclaimerIdx > -1) {
    return {
      body: text.substring(0, disclaimerIdx),
      disclaimer: text.substring(disclaimerIdx + 5).replace(/^\*|\*$/g, "").trim(),
    };
  }
  return { body: text, disclaimer: null };
}
