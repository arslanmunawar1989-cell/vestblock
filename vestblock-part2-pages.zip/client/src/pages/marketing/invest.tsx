import { Link } from "wouter";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { SectionHeader } from "@/components/marketing/section-header";
import { CtaSection } from "@/components/marketing/cta-section";
import { Button } from "@/components/ui/button";
import {
  Building2,
  Layers,
  Landmark,
  Briefcase,
  TrendingUp,
  Home,
  BarChart3,
  ShieldCheck,
  AlertTriangle,
  ArrowRight,
  Wallet,
  CircleDollarSign,
  PieChart,
  CheckCircle2,
} from "lucide-react";

const investmentTypes = [
  {
    icon: Building2,
    title: "Special Purpose Vehicle (SPV)",
    desc: "Own fractions of a single premium property through a dedicated legal entity. Ideal for targeted exposure to specific assets.",
    minInvest: "PKR 50,000",
    riskLevel: "Medium",
    returns: "8-12% p.a.",
  },
  {
    icon: Layers,
    title: "Real Estate Fund",
    desc: "Diversified portfolio of multiple properties managed by professional fund managers. Spread risk across assets and locations.",
    minInvest: "PKR 100,000",
    riskLevel: "Medium-Low",
    returns: "10-15% p.a.",
  },
  {
    icon: Landmark,
    title: "Real Estate Investment Trust (REIT)",
    desc: "Publicly traded trust holding income-generating commercial properties. High liquidity with quarterly distributions.",
    minInvest: "PKR 75,000",
    riskLevel: "Low-Medium",
    returns: "7-10% p.a.",
  },
  {
    icon: Briefcase,
    title: "Property Trust",
    desc: "Fixed-term trust structure with predefined exit dates and target returns. Suitable for conservative investors seeking stability.",
    minInvest: "PKR 200,000",
    riskLevel: "Low",
    returns: "6-9% p.a.",
  },
];

const riskLevels = [
  { level: "Conservative", color: "#22c55e", desc: "Capital preservation focus. Lower returns with minimal volatility. Ideal for first-time investors." },
  { level: "Moderate", color: "#eab308", desc: "Balanced risk-return profile. Mix of income and growth properties across multiple cities." },
  { level: "Growth", color: "#f97316", desc: "Higher return potential with development-stage properties. Suitable for experienced investors." },
  { level: "Aggressive", color: "#ef4444", desc: "Maximum growth focus. Pre-construction and emerging market properties with highest return potential." },
];

const returnsBreakdown = [
  { icon: Home, title: "Rental Yield", value: "5-8%", desc: "Monthly rental income distributed proportionally to token holders. Receive passive income directly to your wallet." },
  { icon: TrendingUp, title: "Capital Appreciation", value: "8-15%", desc: "Property value growth over time. Pakistan's real estate market has historically appreciated 10-20% annually in key cities." },
  { icon: CircleDollarSign, title: "Distributions", value: "Quarterly", desc: "Automated waterfall distributions following institutional-grade structures. Profits distributed every quarter." },
];

export default function InvestPage() {
  return (
    <MarketingLayout>
      <PageMeta title="Investment Guide" description="Complete guide to investing in tokenized real estate on VestBlock. Learn about minimum investments, returns, risks, and how to get started." path="/pk/invest" />
      <section className="relative overflow-hidden py-24 sm:py-32 px-4 gradient-section-blue" data-testid="invest-hero">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium mb-6 text-vest-g5 border border-vest-g5/15" data-testid="invest-badge">
            Investment Guide
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-6" data-testid="invest-headline">
            Your Guide to{" "}
            <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Real Estate Investment</span>
          </h1>
          <p className="text-lg sm:text-xl text-ink-muted max-w-2xl mx-auto mb-10 leading-relaxed" data-testid="invest-subtext">
            Learn how to build wealth through tokenized real estate in Pakistan. Start investing from as low as PKR 50,000 with full regulatory protection.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link href="/register" className="px-8 py-3 text-base font-semibold bg-vest-g5 text-ink-dark hover:opacity-90 transition rounded-md inline-flex items-center gap-2" data-testid="invest-hero-cta">
                              Start Investing <ArrowRight className="w-4 h-4" />
            </Link>
            <Link href="/how-it-works" className="px-8 py-3 text-base font-semibold border border-vest-g5/20 text-ink-dark hover:bg-vest-g0/40 transition rounded-md" data-testid="invest-hero-learn">
                              How It Works
            </Link>
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="investment-types-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Investment Vehicles"
            title="Choose Your"
            highlight="Investment Type"
            description="VestBlock offers multiple regulated investment structures to match your goals, risk appetite, and capital."
          />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {investmentTypes.map((type) => (
              <div key={type.title} className="glass rounded-md p-6  transition-all duration-300" data-testid={`invest-type-${type.title.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-md flex items-center justify-center shrink-0" style={{ background: "rgba(30,43,255,0.08)" }}>
                    <type.icon className="w-6 h-6 text-vest-g5" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-ink-dark mb-2">{type.title}</h3>
                    <p className="text-ink-muted text-sm leading-relaxed mb-4">{type.desc}</p>
                    <div className="flex flex-wrap gap-3">
                      <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium text-vest-g5 border border-vest-g5/15" data-testid={`invest-min-${type.title.toLowerCase().replace(/\s+/g, "-")}`}>
                        <Wallet className="w-3 h-3" /> Min: {type.minInvest}
                      </span>
                      <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium text-ink-muted border border-vest-g5/15-subtle" data-testid={`invest-risk-${type.title.toLowerCase().replace(/\s+/g, "-")}`}>
                        <ShieldCheck className="w-3 h-3" /> {type.riskLevel}
                      </span>
                      <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium text-ink-muted border border-vest-g5/15-subtle" data-testid={`invest-return-${type.title.toLowerCase().replace(/\s+/g, "-")}`}>
                        <TrendingUp className="w-3 h-3" /> {type.returns}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4 gradient-section-subtle" data-testid="risk-levels-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Risk Management"
            title="Understanding"
            highlight="Risk Levels"
            description="Every investment carries risk. We categorize our offerings clearly so you can invest with confidence."
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {riskLevels.map((risk) => (
              <div key={risk.level} className="glass rounded-md p-6  transition-all duration-300" data-testid={`risk-level-${risk.level.toLowerCase()}`}>
                <div className="flex items-center gap-3 mb-4">
                  <AlertTriangle className="w-5 h-5" style={{ color: risk.color }} />
                  <h3 className="text-lg font-bold text-ink-dark">{risk.level}</h3>
                </div>
                <div className="w-full h-1.5 rounded-full mb-4" style={{ background: "rgba(255,255,255,0.1)" }}>
                  <div className="h-full rounded-full" style={{ background: risk.color, width: risk.level === "Conservative" ? "25%" : risk.level === "Moderate" ? "50%" : risk.level === "Growth" ? "75%" : "100%" }} />
                </div>
                <p className="text-ink-muted text-sm leading-relaxed">{risk.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="returns-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Earning Potential"
            title="How You"
            highlight="Earn Returns"
            description="Multiple income streams from your real estate tokens — rental yield, appreciation, and quarterly distributions."
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {returnsBreakdown.map((item) => (
              <div key={item.title} className="glass rounded-md p-8  transition-all duration-300 text-center" data-testid={`returns-${item.title.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="w-14 h-14 rounded-md flex items-center justify-center mx-auto mb-5" style={{ background: "rgba(30,43,255,0.08)" }}>
                  <item.icon className="w-7 h-7 text-vest-g5" />
                </div>
                <div className="text-3xl font-bold text-vest-g5 mb-2" data-testid={`returns-value-${item.title.toLowerCase().replace(/\s+/g, "-")}`}>{item.value}</div>
                <h3 className="text-lg font-bold text-ink-dark mb-3">{item.title}</h3>
                <p className="text-ink-muted text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4 " data-testid="invest-benefits-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Why VestBlock"
            title="Benefits of Tokenized"
            highlight="Real Estate"
            description="Compared to traditional property investment, tokenized real estate offers unmatched advantages."
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: PieChart, title: "Fractional Access", desc: "Invest from PKR 50,000 instead of millions required for traditional property." },
              { icon: BarChart3, title: "Portfolio Diversification", desc: "Spread investments across multiple properties, cities, and asset classes." },
              { icon: ShieldCheck, title: "SECP Regulated", desc: "Full regulatory compliance ensures your investments are legally protected." },
              { icon: Wallet, title: "Easy Liquidity", desc: "Quarterly exit windows on our secondary marketplace — no more years-long lock-ins." },
              { icon: CheckCircle2, title: "Transparent Reporting", desc: "Real-time dashboards with property valuations, rental income, and portfolio performance." },
              { icon: Landmark, title: "Professional Management", desc: "Properties managed by experienced professionals with regular audits and inspections." },
            ].map((benefit) => (
              <div key={benefit.title} className="glass rounded-md p-6  transition-all duration-300" data-testid={`benefit-${benefit.title.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="w-10 h-10 rounded-md flex items-center justify-center mb-4" style={{ background: "rgba(30,43,255,0.08)" }}>
                  <benefit.icon className="w-5 h-5 text-vest-g5" />
                </div>
                <h3 className="text-lg font-bold text-ink-dark mb-2">{benefit.title}</h3>
                <p className="text-ink-muted text-sm leading-relaxed">{benefit.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CtaSection
        title="Ready to Start"
        highlight="Investing?"
        subtitle="Join thousands of Pakistani investors building wealth through tokenized real estate. Create your account in minutes and start with as little as PKR 50,000."
        actions={[
          { label: "Create Free Account", href: "/register" },
          { label: "Browse Properties", href: "/properties", variant: "secondary" },
        ]}
        testId="invest-cta"
      />
    </MarketingLayout>
  );
}
