import { useQuery } from "@tanstack/react-query";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { GlassCard } from "@/components/marketing/glass-card";
import { motion } from "framer-motion";
import {
  BarChart3, TrendingUp, Building2, ArrowUpDown,
  Info, Loader2, AlertTriangle, CheckCircle,
  Calendar,
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line,
} from "recharts";

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

interface Report {
  id: string;
  weekStart: string;
  weekEnd: string;
  region: string;
  status: string;
  narrativeMd: string | null;
  highlightsJson: string[] | null;
  metricsSnapshotId: string | null;
  createdAt: string;
}

interface Snapshot {
  id: string;
  metricsJson: any;
}

export default function MarketPulsePage() {
  const latestQuery = useQuery<{ ok: boolean; report: Report | null; snapshot: Snapshot | null }>({
    queryKey: ["/api/ai/market-pulse/latest"],
  });

  const report = latestQuery.data?.report;
  const snapshot = latestQuery.data?.snapshot;
  const metrics = snapshot?.metricsJson;

  return (
    <MarketingLayout>
      <PageMeta
        title="Market Pulse — Pakistan Real Estate Insights"
        description="Weekly digest of rental yields, listing activity, and liquidity trends across Pakistan's tokenized real estate market."
        path="/pk/market-pulse"
      />

      <section className="relative py-16 sm:py-24 px-4 overflow-hidden" data-testid="pulse-hero">
        <div className="absolute inset-0 bg-gradient-to-b from-vest-g5/5 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-3xl mx-auto text-center relative z-10">
          <motion.div variants={fadeUp} initial="hidden" animate="visible">
            <span className="inline-flex items-center px-3.5 py-1.5 rounded-2xl text-xs font-medium mb-5 text-vest-g5 bg-vest-g5/10 border border-vest-g5/20" data-testid="pulse-badge">
              Weekly Digest
            </span>
            <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-4" data-testid="pulse-headline">
              Market <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Pulse</span> — Pakistan
            </h1>
            <p className="text-sm sm:text-base text-ink-muted max-w-xl mx-auto leading-relaxed" data-testid="pulse-subtext">
              Data-driven insights from our platform — rental yields, listing trends, and secondary market activity.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="px-4 pb-16" data-testid="pulse-content">
        <div className="max-w-4xl mx-auto">
          {latestQuery.isLoading && (
            <div className="text-center py-12" data-testid="pulse-loading">
              <Loader2 className="w-8 h-8 text-vest-g5 animate-spin mx-auto mb-3" />
              <p className="text-sm text-ink-muted">Loading latest market insights...</p>
            </div>
          )}

          {!latestQuery.isLoading && !report && (
            <motion.div variants={fadeUp} initial="hidden" animate="visible">
              <GlassCard className="text-center py-12" data-testid="pulse-empty">
                <BarChart3 className="w-12 h-12 text-ink-muted/30 mx-auto mb-4" />
                <h2 className="text-lg font-semibold text-ink-dark mb-2">No Report Published Yet</h2>
                <p className="text-sm text-ink-muted max-w-md mx-auto">
                  Our weekly market pulse report is being prepared. Check back soon for data-driven insights on Pakistan's tokenized real estate market.
                </p>
              </GlassCard>
            </motion.div>
          )}

          {report && (
            <div className="space-y-6">
              <motion.div variants={fadeUp} initial="hidden" animate="visible">
                <div className="flex items-center justify-center gap-2 text-sm text-ink-muted mb-6" data-testid="pulse-week-label">
                  <Calendar className="w-4 h-4" />
                  <span>Week of {report.weekStart} — {report.weekEnd}</span>
                </div>
              </motion.div>

              {report.highlightsJson && (report.highlightsJson as string[]).length > 0 && (
                <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ delay: 0.05 }}>
                  <GlassCard className="border border-vest-g5/20" data-testid="pulse-highlights">
                    <h2 className="text-base font-semibold text-ink-dark mb-4 flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-vest-g5" /> Key Highlights
                    </h2>
                    <ul className="space-y-2.5">
                      {(report.highlightsJson as string[]).map((h, i) => (
                        <li key={i} className="text-sm text-ink-muted flex items-start gap-2.5" data-testid={`highlight-${i}`}>
                          <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                          {h}
                        </li>
                      ))}
                    </ul>
                  </GlassCard>
                </motion.div>
              )}

              {metrics && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ delay: 0.1 }}>
                    <GlassCard data-testid="yield-chart-card">
                      <h3 className="text-sm font-semibold text-ink-dark mb-4 flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-vest-g5" /> Avg Yield by City
                      </h3>
                      {metrics.rentalYieldsByCity?.length > 0 ? (
                        <ResponsiveContainer width="100%" height={220}>
                          <BarChart data={metrics.rentalYieldsByCity} barSize={32}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                            <XAxis dataKey="city" tick={{ fontSize: 11 }} />
                            <YAxis tick={{ fontSize: 11 }} tickFormatter={(v: number) => `${v}%`} />
                            <Tooltip
                              formatter={(value: number) => [`${value}%`, "Avg Yield"]}
                              contentStyle={{ fontSize: 12, borderRadius: 8 }}
                            />
                            <Bar dataKey="avgYield" fill="#1E2BFF" radius={[4, 4, 0, 0]} name="Avg Yield %" />
                          </BarChart>
                        </ResponsiveContainer>
                      ) : (
                        <p className="text-xs text-ink-muted/60 py-8 text-center">No yield data available</p>
                      )}
                    </GlassCard>
                  </motion.div>

                  <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ delay: 0.12 }}>
                    <GlassCard data-testid="velocity-chart-card">
                      <h3 className="text-sm font-semibold text-ink-dark mb-4 flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-vest-g5" /> Funding Velocity (30d)
                      </h3>
                      {metrics.fundingVelocity?.length > 0 ? (
                        <ResponsiveContainer width="100%" height={220}>
                          <LineChart data={metrics.fundingVelocity}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                            <XAxis dataKey="date" tick={{ fontSize: 10 }} tickFormatter={(d: string) => d.split("-").slice(1).join("/")} />
                            <YAxis tick={{ fontSize: 11 }} tickFormatter={(v: number) => `${v}%`} />
                            <Tooltip
                              formatter={(value: number) => [`${value}%`, "Avg Funding"]}
                              contentStyle={{ fontSize: 12, borderRadius: 8 }}
                            />
                            <Line type="monotone" dataKey="avgFundingPercent" stroke="#1E2BFF" strokeWidth={2} dot={{ r: 3 }} name="Avg Funding %" />
                          </LineChart>
                        </ResponsiveContainer>
                      ) : (
                        <p className="text-xs text-ink-muted/60 py-8 text-center">No funding velocity data available</p>
                      )}
                    </GlassCard>
                  </motion.div>
                </div>
              )}

              {metrics && (
                <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ delay: 0.14 }}>
                  <GlassCard data-testid="pulse-stats-grid">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                      <StatCard label="Cities Tracked" value={metrics.rentalYieldsByCity?.length ?? 0} icon={Building2} />
                      <StatCard label="New Listings" value={metrics.listingPerformance?.newListingsCount ?? 0} icon={BarChart3} />
                      <StatCard label="Units Listed" value={metrics.exitWindowStats?.unitsListed ?? 0} icon={ArrowUpDown} />
                      <StatCard label="Units Sold" value={metrics.exitWindowStats?.unitsSold ?? 0} icon={TrendingUp} />
                    </div>
                  </GlassCard>
                </motion.div>
              )}

              {report.narrativeMd && (
                <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ delay: 0.16 }}>
                  <GlassCard data-testid="pulse-narrative">
                    <div className="prose prose-sm max-w-none" data-testid="narrative-content">
                      <NarrativeRenderer content={report.narrativeMd} />
                    </div>
                  </GlassCard>
                </motion.div>
              )}

              <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ delay: 0.18 }}>
                <div className="p-3 rounded-xl bg-white/40 border border-vest-g5/15 flex items-start gap-2 text-[11px] text-ink-muted/70" data-testid="pulse-disclaimer">
                  <Info className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                  <span>Market insights are derived from platform data and are for informational purposes only. Past performance does not guarantee future results. This is not financial advice.</span>
                </div>
              </motion.div>
            </div>
          )}
        </div>
      </section>
    </MarketingLayout>
  );
}

function StatCard({ label, value, icon: Icon }: { label: string; value: number | string; icon: typeof BarChart3 }) {
  return (
    <div className="text-center p-4 rounded-2xl bg-white/50 border border-vest-g5/15">
      <Icon className="w-5 h-5 text-vest-g5 mx-auto mb-2" />
      <p className="text-xl font-bold text-ink-dark">{value}</p>
      <p className="text-[10px] text-ink-muted/70">{label}</p>
    </div>
  );
}

function NarrativeRenderer({ content }: { content: string }) {
  const lines = content.split("\n");
  return (
    <div className="space-y-2">
      {lines.map((line, i) => {
        if (line.startsWith("## ")) return <h2 key={i} className="text-lg font-bold text-ink-dark mt-4">{line.replace("## ", "")}</h2>;
        if (line.startsWith("### ")) return <h3 key={i} className="text-sm font-semibold text-ink-dark mt-3">{line.replace("### ", "")}</h3>;
        if (line.startsWith("- ")) {
          const text = line.replace("- ", "");
          const parts = text.split(/\*\*(.+?)\*\*/);
          return (
            <li key={i} className="text-sm text-ink-muted ml-4 list-disc">
              {parts.map((p, j) => j % 2 === 1 ? <strong key={j} className="text-ink-dark">{p}</strong> : p)}
            </li>
          );
        }
        if (line.trim() === "") return <div key={i} className="h-2" />;
        return <p key={i} className="text-sm text-ink-muted leading-relaxed">{line}</p>;
      })}
    </div>
  );
}
