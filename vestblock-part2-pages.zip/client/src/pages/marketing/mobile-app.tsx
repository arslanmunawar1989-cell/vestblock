import { Link } from "wouter";
import { useState, useEffect, useRef } from "react";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { PhoneMockup } from "@/components/marketing/phone-mockup";
import { MarketingAccordion } from "@/components/marketing/marketing-accordion";
import { CtaSection } from "@/components/marketing/cta-section";
import { motion, useInView, AnimatePresence } from "framer-motion";
import {
  Smartphone, ArrowRight, BarChart3, Banknote, Clock, Building2,
  FolderOpen, Wallet, FileSpreadsheet, ShieldCheck, Bell,
  Fingerprint, ScrollText, Lock, Eye, Download,
} from "lucide-react";
import { SiApple, SiGoogleplay } from "react-icons/si";

const fadeUp = { hidden: { opacity: 0, y: 30 }, visible: { opacity: 1, y: 0 } };
const stagger = { visible: { transition: { staggerChildren: 0.1 } } };

function SectionLabel({ label }: { label: string }) {
  return (
    <div className="flex items-center gap-2.5 mb-6">
      <div className="w-2 h-2 rounded-full bg-vest-g5" />
      <span className="text-xs uppercase tracking-[0.2em] text-ink-muted font-medium">{label}</span>
    </div>
  );
}

const features = [
  { icon: BarChart3, title: "Live Portfolio", desc: "Track your units, value, and performance in real-time with interactive charts." },
  { icon: Banknote, title: "Monthly Payout History", desc: "View every distribution with gross, net, and fee breakdowns month by month." },
  { icon: Clock, title: "Exit Window Alerts", desc: "Get notified before exit windows open. Set listings and track countdown." },
  { icon: Building2, title: "Property Marketplace", desc: "Browse curated properties with yield projections, funding status, and docs." },
  { icon: FolderOpen, title: "Data Room (ADT)", desc: "Access all property documents, valuations, and legal agreements securely." },
  { icon: Wallet, title: "Wallet & Conversions", desc: "Deposit, withdraw, and convert between PKR, AED, GBP, and crypto." },
  { icon: FileSpreadsheet, title: "Statements & Exports", desc: "Download monthly statements, tax summaries, and transaction history." },
  { icon: ShieldCheck, title: "Security & KYC", desc: "Complete identity verification and manage security settings in-app." },
];

const notifications = [
  { title: "Monthly payout posted", desc: "PKR 18,375 has been credited to your wallet", time: "2 min ago", icon: Banknote, color: "bg-vest-g0 text-vest-g5" },
  { title: "Exit window opens in 7 days", desc: "June 2026 window — prepare your listings", time: "1 hour ago", icon: Clock, color: "bg-vest-g2/30 text-vest-g4" },
  { title: "Document update: valuation report", desc: "DHA Phase 6 Q1 2026 valuation available", time: "3 hours ago", icon: FolderOpen, color: "bg-vest-g1/50 text-vest-g5" },
];

const faqItems = [
  { question: "Is the app available on iOS and Android?", answer: "The VestBlock app is available as a Progressive Web App (PWA) on all platforms. Native iOS and Android apps are currently in development and will be available on the App Store and Google Play soon." },
  { question: "Can I track payouts monthly?", answer: "Yes. The Payouts screen shows every monthly distribution with gross rental income, management fees deducted, and your net payout amount. You can view historical payouts and download statements." },
  { question: "Can I withdraw from the app?", answer: "Absolutely. You can initiate withdrawals directly from the app to your linked bank account via IBFT, JazzCash, or Easypaisa. Profit withdrawals are available after 30 days, and capital withdrawals after 90 days." },
  { question: "How do exit windows work in-app?", answer: "The app shows a countdown to the next exit window with progress tracking. When the window opens, you can list your tokens for sale at NAV-based pricing. You'll receive notifications 7 days before each window opens." },
  { question: "Can I access ADT documents?", answer: "Yes. The Data Room (ADT) section provides secure access to all property documents including title deeds, valuations, rental agreements, and legal filings. Documents are organized by property and date." },
  { question: "Is my data secure?", answer: "VestBlock uses bank-grade 256-bit encryption, session management with automatic timeouts, and supports biometric authentication on compatible devices. All data is stored in compliance with local data protection regulations." },
];

function NotificationToast({ notification, index }: { notification: typeof notifications[0]; index: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: 60, scale: 0.95 }}
      animate={inView ? { opacity: 1, x: 0, scale: 1 } : {}}
      transition={{ duration: 0.5, delay: index * 0.2, ease: "easeOut" }}
      className="glass rounded-md p-4 flex items-start gap-3"
      data-testid={`notification-${index}`}
    >
      <div className={`w-9 h-9 rounded-md flex items-center justify-center shrink-0 ${notification.color}`}>
        <notification.icon className="w-4 h-4" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-sm font-medium text-ink-dark">{notification.title}</div>
        <div className="text-xs text-ink-muted mt-0.5">{notification.desc}</div>
      </div>
      <div className="text-[10px] text-ink-muted/50 whitespace-nowrap shrink-0">{notification.time}</div>
    </motion.div>
  );
}

export default function MobileAppPage() {
  return (
    <MarketingLayout>
      <PageMeta
        title="Mobile App - VestBlock"
        description="Track your portfolio, payouts, and exit windows from the VestBlock mobile app. Secure, real-time access to your investments anywhere."
        path="/pk/mobile-app"
      />

      {/* ── HERO ── */}
      <section className="relative px-6 sm:px-10 lg:px-16 pt-20 pb-24 md:pt-28 md:pb-32 overflow-hidden" data-testid="app-hero">
        <div className="absolute top-0 left-0 w-full h-full">
          <div className="absolute inset-0 bg-gradient-to-br from-vest-g0/80 via-vest-g1/30 to-transparent" />
        </div>

        <div className="relative max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div initial="hidden" animate="visible" variants={stagger}>
              <motion.div variants={fadeUp} transition={{ duration: 0.5 }}>
                <SectionLabel label="Mobile App" />
              </motion.div>

              <motion.h1
                variants={fadeUp}
                transition={{ duration: 0.6 }}
                className="text-3xl sm:text-4xl font-bold text-ink-dark leading-[1.08] tracking-tight"
                data-testid="app-hero-headline"
              >
                VestBlock App —{" "}
                <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Your Portfolio, Always Accessible</span>
              </motion.h1>

              <motion.p
                variants={fadeUp}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="mt-6 text-lg text-ink-muted max-w-lg leading-relaxed"
              >
                Monitor investments, payouts, and liquidity windows from one secure app. Everything you need to manage your real estate portfolio, in your pocket.
              </motion.p>

              <motion.div variants={fadeUp} transition={{ duration: 0.5, delay: 0.2 }} className="mt-8 flex flex-wrap gap-3">
                <button className="glass-btn-primary inline-flex items-center gap-2 rounded-md px-6 py-3 text-sm font-medium" data-testid="app-hero-download">
                  <Download className="w-4 h-4" /> Get the App
                </button>
                <a href="#features" className="glass-btn-outline inline-flex items-center gap-2 rounded-md px-6 py-3 text-sm font-medium" data-testid="app-hero-features">
                  See App Features
                </a>
              </motion.div>

              <motion.div
                variants={fadeUp}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="mt-8 flex items-center gap-3 flex-wrap"
              >
                {[
                  { icon: SiApple, label: "iOS", sub: "Coming Soon" },
                  { icon: SiGoogleplay, label: "Android", sub: "Coming Soon" },
                  { icon: Smartphone, label: "PWA", sub: "Available Now" },
                ].map((p) => (
                  <div
                    key={p.label}
                    className="glass rounded-md px-4 py-2.5 flex items-center gap-2.5"
                    data-testid={`platform-badge-${p.label.toLowerCase()}`}
                  >
                    <p.icon className="w-4 h-4 text-ink-dark" />
                    <div>
                      <div className="text-[10px] font-medium text-ink-dark leading-tight">{p.label}</div>
                      <div className="text-[8px] text-ink-muted/60">{p.sub}</div>
                    </div>
                  </div>
                ))}
              </motion.div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="flex justify-center lg:justify-end"
            >
              <PhoneMockup autoPlay />
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── APP WALKTHROUGH ── */}
      <section className="py-24 px-6 sm:px-10 lg:px-16 border-t border-vest-g5/[0.08]" data-testid="app-walkthrough">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <SectionLabel label="App Walkthrough" />
            <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight">
              Three Screens,{" "}
              <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Complete Control</span>
            </h2>
            <p className="text-base text-ink-muted mt-4 leading-relaxed">
              Switch between your portfolio overview, payout history, and exit window management with a single tap. Every screen is designed for clarity and speed.
            </p>
          </div>

          <div className="flex justify-center">
            <PhoneMockup />
          </div>
        </div>
      </section>

      {/* ── FEATURES GRID ── */}
      <section id="features" className="py-24 px-6 sm:px-10 lg:px-16 border-t border-vest-g5/[0.08]" data-testid="app-features">
        <div className="max-w-7xl mx-auto">
          <SectionLabel label="App Features" />
          <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-4">
            Everything in <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">One Place</span>
          </h2>
          <p className="text-base text-ink-muted max-w-lg mb-12 leading-relaxed">
            From live portfolio tracking to document access, the VestBlock app brings your entire investment experience to your phone.
          </p>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={stagger}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5"
          >
            {features.map((f, i) => (
              <motion.div
                key={i}
                variants={fadeUp}
                transition={{ duration: 0.4 }}
                className="glass rounded-md p-5 group"
                data-testid={`feature-card-${i}`}
              >
                <div className="w-10 h-10 rounded-md bg-vest-g5/10 flex items-center justify-center mb-4 group-hover:bg-vest-g5/15 transition-colors">
                  <f.icon className="w-5 h-5 text-vest-g5" />
                </div>
                <h3 className="text-sm font-semibold text-ink-dark mb-2">{f.title}</h3>
                <p className="text-xs text-ink-muted leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── NOTIFICATIONS ── */}
      <section className="py-24 px-6 sm:px-10 lg:px-16 border-t border-vest-g5/[0.08]" data-testid="app-notifications">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <SectionLabel label="Smart Alerts" />
              <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-4">
                Never Miss a <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Payout or Window</span>
              </h2>
              <p className="text-base text-ink-muted leading-relaxed max-w-lg mb-6">
                Real-time push notifications keep you informed about distributions, exit window openings, document updates, and account activity.
              </p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-md bg-vest-g5/10 flex items-center justify-center">
                  <Bell className="w-5 h-5 text-vest-g5" />
                </div>
                <div>
                  <div className="text-sm font-medium text-ink-dark">Configurable Alerts</div>
                  <div className="text-xs text-ink-muted">Choose which notifications matter to you</div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              {notifications.map((n, i) => (
                <NotificationToast key={i} notification={n} index={i} />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── SECURITY ── */}
      <section className="py-24 px-6 sm:px-10 lg:px-16 border-t border-vest-g5/[0.08]" data-testid="app-security">
        <div className="max-w-7xl mx-auto text-center max-w-3xl">
          <SectionLabel label="Security" />
          <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-4">
            Bank-Grade <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Security</span>
          </h2>
          <p className="text-base text-ink-muted leading-relaxed max-w-xl mx-auto mb-12">
            Your data and investments are protected with enterprise-grade security measures at every level.
          </p>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={stagger}
            className="grid grid-cols-1 sm:grid-cols-2 gap-5"
          >
            {[
              { icon: Fingerprint, title: "Biometric Ready", desc: "Face ID and fingerprint authentication support for quick, secure access on compatible devices." },
              { icon: Lock, title: "Session Security", desc: "Automatic session timeouts, device management, and suspicious activity detection to protect your account." },
              { icon: ScrollText, title: "Audit Logs", desc: "Complete audit trail of every login, transaction, and settings change for your records." },
              { icon: Eye, title: "Privacy First", desc: "Data encrypted at rest and in transit. Compliant with local data protection regulations." },
            ].map((s, i) => (
              <motion.div
                key={i}
                variants={fadeUp}
                transition={{ duration: 0.4 }}
                className="glass rounded-md p-6 text-left"
                data-testid={`security-card-${i}`}
              >
                <div className="w-10 h-10 rounded-md bg-vest-g5/10 flex items-center justify-center mb-4">
                  <s.icon className="w-5 h-5 text-vest-g5" />
                </div>
                <h3 className="text-sm font-semibold text-ink-dark mb-2">{s.title}</h3>
                <p className="text-xs text-ink-muted leading-relaxed">{s.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="py-24 px-6 sm:px-10 lg:px-16 border-t border-vest-g5/[0.08]" data-testid="app-faq">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <SectionLabel label="FAQ" />
            <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight">
              App <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Questions</span>
            </h2>
          </div>
          <MarketingAccordion items={faqItems} />
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="border-t border-vest-g5/[0.08]">
        <CtaSection
          icon={Smartphone}
          title="Start investing in Pakistan real estate with"
          highlight="VestBlock"
          subtitle="Access tokenized properties, earn monthly distributions, and manage your portfolio from anywhere."
          actions={[
            { label: "Explore Properties", href: "/properties" },
            { label: "Create Account", href: "/register", variant: "secondary" },
          ]}
          testId="app-cta"
        />
      </section>
    </MarketingLayout>
  );
}
