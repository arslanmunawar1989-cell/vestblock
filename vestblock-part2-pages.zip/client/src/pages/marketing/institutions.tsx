import { Link } from "wouter";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { SectionHeader } from "@/components/marketing/section-header";
import { CtaSection } from "@/components/marketing/cta-section";
import {
  Building2,
  Code2,
  BarChart3,
  Headphones,
  Briefcase,
  Landmark,
  HardHat,
  PiggyBank,
  ShieldCheck,
  Globe,
  FileCheck,
  ArrowRight,
  CheckCircle2,
  Server,
  Lock,
  Users,
} from "lucide-react";

const features = [
  {
    icon: Building2,
    title: "White-Label Solutions",
    desc: "Launch your own branded real estate tokenization platform powered by VestBlock's infrastructure. Full customization with your brand identity, domain, and user experience.",
    highlights: ["Custom branding & domain", "Branded investor portal", "Co-branded marketing materials"],
  },
  {
    icon: Code2,
    title: "Full API Access",
    desc: "RESTful APIs and webhook integrations for seamless connectivity with your existing systems. Real-time data feeds for portfolio management and reporting.",
    highlights: ["RESTful & GraphQL APIs", "Webhook notifications", "SDKs for Python, Node.js, Java"],
  },
  {
    icon: BarChart3,
    title: "Custom Reporting",
    desc: "Enterprise-grade analytics and reporting tailored to your compliance and stakeholder requirements. Automated report generation with custom templates.",
    highlights: ["Custom report templates", "Automated scheduling", "Regulatory-ready exports"],
  },
  {
    icon: Headphones,
    title: "Dedicated Support",
    desc: "24/7 dedicated account manager and technical support team. Priority SLA with guaranteed response times for critical issues.",
    highlights: ["24/7 availability", "Dedicated account manager", "< 1 hour SLA for critical issues"],
  },
];

const useCases = [
  {
    icon: Briefcase,
    title: "Family Offices",
    desc: "Diversify family wealth into tokenized real estate across multiple Pakistani cities with professional management and full transparency.",
  },
  {
    icon: Landmark,
    title: "Banks & Financial Institutions",
    desc: "Offer tokenized real estate products to your clients through white-label integration. Expand your product suite without infrastructure investment.",
  },
  {
    icon: HardHat,
    title: "Real Estate Developers",
    desc: "Tokenize your projects to access a wider investor base. Raise capital efficiently while maintaining control through SPV structures.",
  },
  {
    icon: PiggyBank,
    title: "Pension Funds",
    desc: "Access regulated real estate exposure with institutional-grade compliance, reporting, and risk management frameworks.",
  },
];

const complianceItems = [
  { icon: ShieldCheck, title: "SECP Compliance", desc: "Fully licensed under Securities and Exchange Commission of Pakistan regulations for digital securities issuance and management." },
  { icon: Globe, title: "FATF Standards", desc: "Adherence to Financial Action Task Force recommendations for anti-money laundering and counter-terrorism financing." },
  { icon: FileCheck, title: "AML/CFT Framework", desc: "Comprehensive Anti-Money Laundering and Countering Financing of Terrorism policies with real-time transaction monitoring." },
  { icon: Lock, title: "Data Security", desc: "Enterprise-grade encryption, SOC 2 Type II certification, and ISO 27001 compliance for data protection." },
];

const stats = [
  { value: "PKR 2.8B+", label: "Assets Under Management" },
  { value: "45+", label: "Tokenized Properties" },
  { value: "99.99%", label: "Platform Uptime" },
  { value: "< 50ms", label: "API Response Time" },
];

export default function InstitutionsPage() {
  return (
    <MarketingLayout>
      <PageMeta title="For Institutions" description="Institutional-grade real estate investment solutions. Portfolio diversification, custom mandates, and dedicated support for family offices and funds." path="/pk/institutions" />
      <section className="relative overflow-hidden py-24 sm:py-32 px-4" data-testid="institutions-hero">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium mb-6 text-vest-g5 border border-vest-g5/15" data-testid="institutions-badge">
            For Institutions
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-6" data-testid="institutions-headline">
            Institutional-Grade{" "}
            <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Infrastructure</span>
          </h1>
          <p className="text-lg sm:text-xl text-ink-muted max-w-2xl mx-auto mb-10 leading-relaxed" data-testid="institutions-subtext">
            Purpose-built for banks, family offices, and asset managers. Enterprise-level security, compliance, and scalability for your real estate tokenization needs.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link href="/register" className="px-8 py-3 text-base font-semibold bg-vest-g5 text-ink-dark hover:opacity-90 transition rounded-md inline-flex items-center gap-2" data-testid="institutions-cta-demo">
                              Request a Demo <ArrowRight className="w-4 h-4" />
            </Link>
            <Link href="/pricing" className="px-8 py-3 text-base font-semibold border border-vest-g5/20 text-ink-dark hover:bg-vest-g0/40 transition rounded-md" data-testid="institutions-cta-pricing">
                              View Pricing
            </Link>
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="institutions-stats-section">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat) => (
              <div key={stat.label} className="glass rounded-md p-6 text-center  transition-all duration-300" data-testid={`stat-${stat.label.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="text-3xl font-bold text-vest-g5 mb-2" data-testid={`stat-value-${stat.label.toLowerCase().replace(/\s+/g, "-")}`}>{stat.value}</div>
                <div className="text-sm text-ink-muted">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4 " data-testid="institutions-features-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Capabilities"
            title="Enterprise"
            highlight="Features"
            description="Everything you need to integrate tokenized real estate into your institutional offering."
          />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {features.map((feature) => (
              <div key={feature.title} className="glass rounded-md p-8  transition-all duration-300" data-testid={`feature-${feature.title.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-md flex items-center justify-center shrink-0" style={{ background: "rgba(30,43,255,0.08)" }}>
                    <feature.icon className="w-6 h-6 text-vest-g5" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-ink-dark mb-2">{feature.title}</h3>
                    <p className="text-ink-muted text-sm leading-relaxed mb-4">{feature.desc}</p>
                    <ul className="space-y-2">
                      {feature.highlights.map((h) => (
                        <li key={h} className="flex items-center gap-2 text-sm text-ink-muted">
                          <CheckCircle2 className="w-4 h-4 text-vest-g5 shrink-0" />
                          {h}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="use-cases-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Use Cases"
            title="Who We"
            highlight="Serve"
            description="VestBlock's institutional platform is built for the diverse needs of Pakistan's financial ecosystem."
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {useCases.map((uc) => (
              <div key={uc.title} className="glass rounded-md p-6  transition-all duration-300 text-center" data-testid={`usecase-${uc.title.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="w-14 h-14 rounded-md flex items-center justify-center mx-auto mb-5" style={{ background: "rgba(30,43,255,0.08)" }}>
                  <uc.icon className="w-7 h-7 text-vest-g5" />
                </div>
                <h3 className="text-lg font-bold text-ink-dark mb-3">{uc.title}</h3>
                <p className="text-ink-muted text-sm leading-relaxed">{uc.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4 " data-testid="institutions-compliance-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Compliance"
            title="Regulatory"
            highlight="Framework"
            description="We meet the highest regulatory standards required by institutional investors and financial regulators."
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {complianceItems.map((item) => (
              <div key={item.title} className="glass rounded-md p-6  transition-all duration-300" data-testid={`compliance-${item.title.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-md flex items-center justify-center shrink-0" style={{ background: "rgba(30,43,255,0.08)" }}>
                    <item.icon className="w-5 h-5 text-vest-g5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-ink-dark mb-2">{item.title}</h3>
                    <p className="text-ink-muted text-sm leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="institutions-integration-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Integration"
            title="Seamless"
            highlight="Integration"
            description="Connect VestBlock to your existing infrastructure in days, not months."
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { icon: Server, title: "Infrastructure", desc: "Cloud-native, multi-region deployment with 99.99% SLA. Horizontally scalable to handle enterprise volumes." },
              { icon: Lock, title: "Security", desc: "SOC 2 Type II, ISO 27001, PCI DSS certified. End-to-end encryption with hardware security modules." },
              { icon: Users, title: "Onboarding", desc: "Dedicated onboarding team, sandbox environment, and comprehensive documentation for rapid integration." },
            ].map((item) => (
              <div key={item.title} className="glass rounded-md p-8 text-center  transition-all duration-300" data-testid={`integration-${item.title.toLowerCase()}`}>
                <div className="w-14 h-14 rounded-md flex items-center justify-center mx-auto mb-5" style={{ background: "rgba(30,43,255,0.08)" }}>
                  <item.icon className="w-7 h-7 text-vest-g5" />
                </div>
                <h3 className="text-lg font-bold text-ink-dark mb-3">{item.title}</h3>
                <p className="text-ink-muted text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CtaSection
        title="Ready for a"
        highlight="Demo?"
        subtitle="Schedule a personalized demo with our enterprise team. See how VestBlock can transform your real estate offering."
        actions={[
          { label: "Request Demo", href: "/register" },
          { label: "View Compliance", href: "/compliance", variant: "secondary" },
        ]}
        testId="institutions-cta"
      />
    </MarketingLayout>
  );
}
