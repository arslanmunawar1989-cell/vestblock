import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { SectionHeader } from "@/components/marketing/section-header";
import { CtaSection } from "@/components/marketing/cta-section";
import { Link } from "wouter";
import {
  Cpu,
  Landmark,
  Building2,
  Scale,
  ArrowRight,
  Handshake,
  Globe,
  ShieldCheck,
  TrendingUp,
  Zap,
} from "lucide-react";

const partnerCategories = [
  { label: "Technology", icon: Cpu },
  { label: "Banking", icon: Landmark },
  { label: "Real Estate", icon: Building2 },
  { label: "Legal", icon: Scale },
];

const partners = [
  { id: 1, name: "NexGen Systems", category: "Technology", desc: "Providing enterprise blockchain infrastructure and smart contract audit services for VestBlock's tokenization engine." },
  { id: 2, name: "Allied Bank Limited", category: "Banking", desc: "Strategic banking partner for escrow accounts, investor fund management, and PKR settlement services." },
  { id: 3, name: "Zameen Developments", category: "Real Estate", desc: "Premium property sourcing and due diligence partner covering DHA, Bahria Town, and commercial projects." },
  { id: 4, name: "Axis Law Associates", category: "Legal", desc: "Legal counsel for SECP compliance, SPV structuring, and investor protection frameworks." },
  { id: 5, name: "CloudForge Pakistan", category: "Technology", desc: "Cloud infrastructure and cybersecurity partner ensuring 99.99% uptime and bank-grade data protection." },
  { id: 6, name: "Habib Metro Bank", category: "Banking", desc: "Payment gateway integration and international remittance processing for overseas Pakistani investors." },
  { id: 7, name: "Prime Realty Group", category: "Real Estate", desc: "Property management and valuation partner providing ongoing asset performance monitoring across key markets." },
  { id: 8, name: "Shah & Ibrahim Legal", category: "Legal", desc: "Regulatory advisory and dispute resolution services specializing in digital securities and real estate law." },
];

const categoryIcons: Record<string, typeof Cpu> = {
  Technology: Cpu,
  Banking: Landmark,
  "Real Estate": Building2,
  Legal: Scale,
};

const programBenefits = [
  { icon: Globe, title: "Market Access", desc: "Tap into Pakistan's PKR 50 trillion real estate market through VestBlock's growing investor network." },
  { icon: ShieldCheck, title: "Regulatory Support", desc: "Leverage our SECP-compliant framework and legal infrastructure to operate with confidence." },
  { icon: TrendingUp, title: "Revenue Sharing", desc: "Earn competitive commissions and referral fees through our transparent partnership model." },
  { icon: Zap, title: "Technology Integration", desc: "Access our APIs, SDKs, and tokenization engine to build innovative solutions on top of VestBlock." },
];

export default function PartnersPage() {
  return (
    <MarketingLayout>
      <PageMeta title="Partners" description="VestBlock's strategic partners in banking, legal, technology, and real estate sectors powering Pakistan's tokenized property ecosystem." path="/pk/partners" />
      <section className="relative overflow-hidden py-24 sm:py-32 px-4" data-testid="partners-hero">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium mb-6 text-vest-g5 border border-vest-g5/15" data-testid="partners-badge">
            Ecosystem
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-6" data-testid="partners-headline">
            Strategic{" "}
            <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Partnerships</span>
          </h1>
          <p className="text-lg text-ink-muted max-w-2xl mx-auto leading-relaxed" data-testid="partners-subtext">
            We collaborate with leading organizations across technology, banking, real estate, and legal to deliver a world-class investment platform.
          </p>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="partner-categories-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Partners"
            title="Our Partner"
            highlight="Network"
            description="Trusted organizations powering the VestBlock ecosystem across four key verticals."
          />
          <div className="flex flex-wrap justify-center gap-4 mb-16">
            {partnerCategories.map((cat) => (
              <div
                key={cat.label}
                className="glass rounded-md px-6 py-4 flex items-center gap-3"
                data-testid={`partner-category-${cat.label.toLowerCase().replace(/\s+/g, "-")}`}
              >
                <cat.icon className="w-5 h-5 text-vest-g5" />
                <span className="text-sm font-medium text-ink-dark">{cat.label}</span>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {partners.map((partner) => {
              const Icon = categoryIcons[partner.category];
              return (
                <div
                  key={partner.id}
                  className="glass  rounded-md p-6 transition-all duration-300"
                  data-testid={`partner-card-${partner.id}`}
                >
                  <div className="w-12 h-12 rounded-md flex items-center justify-center mb-5" style={{ background: "rgba(30,43,255,0.10)" }}>
                    <Icon className="w-6 h-6 text-ink-dark" />
                  </div>
                  <span
                    className="inline-block px-2.5 py-1 rounded-full text-xs font-medium mb-3"
                    style={{ background: "rgba(30,43,255,0.10)", color: "#ffffff" }}
                    data-testid={`partner-category-badge-${partner.id}`}
                  >
                    {partner.category}
                  </span>
                  <h3 className="text-lg font-semibold text-ink-dark mb-2" data-testid={`partner-name-${partner.id}`}>{partner.name}</h3>
                  <p className="text-sm text-ink-muted leading-relaxed">{partner.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-20 px-4 " data-testid="program-benefits-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Program"
            title="Partnership"
            highlight="Benefits"
            description="Join our ecosystem and grow together. Here's what VestBlock partners enjoy."
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {programBenefits.map((b, i) => (
              <div key={i} className="glass rounded-md p-6 text-center" data-testid={`program-benefit-${i}`}>
                <div className="w-12 h-12 rounded-md flex items-center justify-center mx-auto mb-4" style={{ background: "rgba(30,43,255,0.08)" }}>
                  <b.icon className="w-6 h-6 text-vest-g5" />
                </div>
                <h3 className="text-lg font-semibold text-ink-dark mb-2">{b.title}</h3>
                <p className="text-sm text-ink-muted leading-relaxed">{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CtaSection
        icon={Handshake}
        title="Become a"
        highlight="Partner"
        subtitle="Interested in partnering with VestBlock? Whether you're a technology provider, financial institution, real estate developer, or legal firm — we'd love to explore how we can work together."
        actions={[
          { label: "Get in Touch", href: "/contact" },
        ]}
        testId="partner-cta"
      />
    </MarketingLayout>
  );
}
