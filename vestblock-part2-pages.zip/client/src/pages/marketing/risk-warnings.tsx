import { MarketingLayout } from "@/components/marketing/layout";
import { MarketingHero } from "@/components/marketing/marketing-hero";
import { GlassCard } from "@/components/marketing/glass-card";
import { ComplianceDisclaimer } from "@/components/marketing/compliance-disclaimer";
import { PageMeta } from "@/components/marketing/page-meta";
import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  AlertTriangle, TrendingDown, Ban, Clock, ShieldAlert,
  Smartphone, Server, Coins, Scale, Globe, ArrowRight,
} from "lucide-react";

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const warnings = [
  {
    icon: TrendingDown, title: "Capital at Risk",
    text: "The value of your investment can go down as well as up. You may receive back less than your original investment. Tokenized real estate is not a deposit and is not covered by any deposit insurance or guarantee scheme.",
  },
  {
    icon: Clock, title: "Illiquidity",
    text: "Property tokens are not as liquid as publicly traded securities. You may be unable to sell your tokens at a desired price or at all. Lock-up periods may apply during which holdings cannot be transferred.",
  },
  {
    icon: Ban, title: "No Guaranteed Returns",
    text: "All projected yields, returns, and occupancy rates are estimates only. Historical performance does not guarantee future results. Actual returns may differ materially from projections.",
  },
  {
    icon: Scale, title: "Regulatory Changes",
    text: "The regulatory framework for digital securities in Pakistan is evolving. Changes in SECP regulations, tax laws, or monetary policy could materially affect your investment or the platform's operations.",
  },
  {
    icon: Coins, title: "Currency Risk",
    text: "All investments are denominated in PKR. International investors face exchange rate risk. PKR depreciation reduces returns when converted to foreign currencies.",
  },
  {
    icon: Server, title: "Technology & Platform Risk",
    text: "The platform relies on blockchain and smart contract technology. System outages, software vulnerabilities, or cybersecurity incidents could temporarily prevent access or affect transactions.",
  },
  {
    icon: Smartphone, title: "Account Security",
    text: "You are responsible for maintaining the security of your account credentials. Loss of access credentials or MFA devices may result in inability to access your account or assets.",
  },
  {
    icon: Globe, title: "Market Data Accuracy",
    text: "Property valuations, market data, and analytics provided on the platform are for informational purposes only. Third-party data may contain errors or delays. Do not rely solely on platform data for investment decisions.",
  },
];

export default function RiskWarningsPage() {
  return (
    <MarketingLayout>
      <PageMeta
        title="Risk Warnings"
        description="Important risk warnings for VestBlock investors. Understand the risks of tokenized real estate including capital loss, illiquidity, regulatory changes, and platform risks."
        path="/pk/risk-warnings"
      />

      <MarketingHero
        badge="Important Notice"
        title="Risk"
        highlight="Warnings"
        subtitle="Please read these important risk warnings carefully before using the VestBlock platform or making any investment decisions."
        testIdPrefix="risk-warnings"
      />

      <div className="max-w-4xl mx-auto px-4 mb-12">
        <ComplianceDisclaimer
          variant="warning"
          title="Capital at Risk"
          text="Tokenized real estate investments are speculative and involve a high degree of risk. You should not invest more than you can afford to lose. These products are not suitable for all investors. Seek independent financial advice if you are unsure."
          testId="risk-warnings-main"
        />
      </div>

      <section className="py-8 px-4" data-testid="risk-warnings-list">
        <div className="max-w-4xl mx-auto space-y-5">
          {warnings.map((w, i) => (
            <motion.div
              key={w.title}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeUp}
              transition={{ duration: 0.4, delay: i * 0.05 }}
            >
              <GlassCard className="flex items-start gap-4" data-testid={`risk-warning-${i}`}>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 bg-yellow-500/10">
                  <w.icon className="w-5 h-5 text-yellow-400" />
                </div>
                <div>
                  <h3 className="text-ink-dark font-semibold mb-1">{w.title}</h3>
                  <p className="text-sm text-ink-muted leading-relaxed">{w.text}</p>
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="py-16 px-4" data-testid="risk-warnings-actions">
        <div className="max-w-3xl mx-auto">
          <GlassCard className="text-center">
            <ShieldAlert className="w-8 h-8 text-vest-g5 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-ink-dark mb-3">Before You Invest</h3>
            <p className="text-sm text-ink-muted leading-relaxed mb-6 max-w-lg mx-auto">
              We strongly recommend reading our full Risk Disclosure and Terms of Service before making any investment decisions. Consider consulting a qualified financial advisor.
            </p>
            <div className="flex items-center justify-center gap-4 flex-wrap">
              <Link href="/risk-disclosure" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold bg-vest-g5 text-ink-dark" data-testid="link-risk-disclosure">
                Full Risk Disclosure <ArrowRight className="w-4 h-4" />
              </Link>
              <Link href="/terms" className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold text-ink-muted ring-1 ring-vest-g5/20" data-testid="link-terms">
                Terms of Service
              </Link>
            </div>
          </GlassCard>
        </div>
      </section>
    </MarketingLayout>
  );
}
