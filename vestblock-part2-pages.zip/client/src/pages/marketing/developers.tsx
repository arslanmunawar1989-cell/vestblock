import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { SectionHeader } from "@/components/marketing/section-header";
import { Link } from "wouter";
import {
  Code2,
  Zap,
  Lock,
  Building2,
  Wallet,
  PieChart,
  UserCheck,
  Terminal,
  Globe,
  Gauge,
  ArrowRight,
  Check,
} from "lucide-react";

const endpoints = [
  {
    id: "auth",
    icon: Lock,
    title: "Authentication",
    description: "OAuth 2.0 and API key authentication with PKCE flow support.",
    methods: ["POST /auth/token", "POST /auth/refresh", "DELETE /auth/revoke"],
  },
  {
    id: "properties",
    icon: Building2,
    title: "Properties",
    description: "Browse, search, and retrieve detailed property information.",
    methods: ["GET /properties", "GET /properties/:id", "GET /properties/:id/documents"],
  },
  {
    id: "investments",
    icon: Wallet,
    title: "Investments",
    description: "Create, manage, and track token investments in PKR.",
    methods: ["POST /investments", "GET /investments/:id", "GET /investments/portfolio"],
  },
  {
    id: "distributions",
    icon: PieChart,
    title: "Distributions",
    description: "Access quarterly rental distribution data and payment history.",
    methods: ["GET /distributions", "GET /distributions/:id", "GET /distributions/summary"],
  },
  {
    id: "kyc",
    icon: UserCheck,
    title: "KYC Verification",
    description: "Submit and track KYC/AML verification for CNIC holders.",
    methods: ["POST /kyc/submit", "GET /kyc/status", "POST /kyc/documents"],
  },
];

const sdks = [
  {
    id: "javascript",
    language: "JavaScript / TypeScript",
    install: "npm install @vestblock/sdk",
    badge: "v2.1.0",
  },
  {
    id: "python",
    language: "Python",
    install: "pip install vestblock",
    badge: "v1.8.0",
  },
  {
    id: "php",
    language: "PHP",
    install: "composer require vestblock/sdk",
    badge: "v1.5.0",
  },
];

const pricingTiers = [
  {
    id: "free",
    name: "Free",
    price: "PKR 0",
    period: "/month",
    requests: "1,000 requests/day",
    features: [
      "REST API access",
      "Public property data",
      "Basic authentication",
      "Community support",
      "Standard rate limits",
    ],
    highlighted: false,
  },
  {
    id: "pro",
    name: "Pro",
    price: "PKR 15,000",
    period: "/month",
    requests: "50,000 requests/day",
    features: [
      "Full REST & WebSocket API",
      "Real-time price updates",
      "Portfolio management API",
      "Priority support",
      "Webhook integrations",
      "Sandbox environment",
    ],
    highlighted: true,
  },
  {
    id: "enterprise",
    name: "Enterprise",
    price: "Custom",
    period: "",
    requests: "Unlimited requests",
    features: [
      "Unlimited API access",
      "Dedicated infrastructure",
      "Custom integrations",
      "24/7 dedicated support",
      "SLA guarantees",
      "White-label options",
      "On-premise deployment",
    ],
    highlighted: false,
  },
];

const codeSnippetJS = `import VestBlock from '@vestblock/sdk';

const client = new VestBlock({
  apiKey: process.env.VESTBLOCK_API_KEY,
  environment: 'production',
});

// Fetch available properties
const properties = await client.properties.list({
  city: 'Islamabad',
  minYield: 8.5,
  currency: 'PKR',
});

// Invest in a property
const investment = await client.investments.create({
  propertyId: 'prop_abc123',
  amount: 100000, // PKR 100,000
  paymentMethod: 'bank_transfer',
});

console.log(investment.tokenId);`;

const codeSnippetWebSocket = `// Real-time price updates via WebSocket
const ws = new VestBlock.WebSocket({
  apiKey: process.env.VESTBLOCK_API_KEY,
});

ws.subscribe('property:price', {
  properties: ['prop_abc123', 'prop_def456'],
});

ws.on('price_update', (data) => {
  console.log(\`\${data.propertyId}: PKR \${data.price}\`);
});

ws.on('distribution', (data) => {
  console.log(\`Yield: \${data.amount} PKR\`);
});`;

export default function DevelopersPage() {
  return (
    <MarketingLayout>
      <PageMeta title="API & Developers" description="VestBlock API documentation for developers. RESTful APIs, webhooks, SDKs, and integration guides for building on the VestBlock platform." path="/pk/developers" />
      <section className="relative overflow-hidden py-24 sm:py-32 px-4" data-testid="developers-hero">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center px-3 py-1 rounded-md text-xs font-medium mb-6 text-vest-g5 border border-vest-g5/15" data-testid="developers-badge">
            Developer Platform
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-6" data-testid="developers-headline">
            Build with{" "}
            <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">VestBlock API</span>
          </h1>
          <p className="text-lg text-ink-muted max-w-2xl mx-auto leading-relaxed" data-testid="developers-subtext">
            Integrate real estate tokenization into your applications with our RESTful API and WebSocket support. Access property data, manage investments, and build on Pakistan's leading PropTech infrastructure.
          </p>
          <div className="flex items-center justify-center gap-4 mt-8 flex-wrap">
            <button className="bg-vest-g5 text-ink-dark hover:opacity-90 transition px-6 py-3 rounded-md text-sm flex items-center gap-2" data-testid="developers-get-key-btn">
              Get API Key <ArrowRight className="w-4 h-4" />
            </button>
            <button className="border border-vest-g5/20 text-ink-dark hover:bg-vest-g0/40 transition px-6 py-3 rounded-md text-sm flex items-center gap-2" data-testid="developers-docs-btn">
              <Terminal className="w-4 h-4" /> View Documentation
            </button>
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="api-overview-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Overview"
            title="Powerful"
            highlight="API Platform"
            description="Everything you need to integrate real estate tokenization into your application."
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="glass rounded-md p-6" data-testid="api-feature-rest">
              <div className="w-12 h-12 rounded-md flex items-center justify-center mb-4" style={{ background: "rgba(30,43,255,0.08)" }}>
                <Globe className="w-6 h-6 text-vest-g5" />
              </div>
              <h3 className="text-ink-dark font-bold text-lg mb-2">RESTful API</h3>
              <p className="text-ink-muted text-sm leading-relaxed">
                Standard REST endpoints with JSON responses. Full CRUD operations for properties, investments, and portfolio management. Supports pagination, filtering, and sorting.
              </p>
            </div>
            <div className="glass rounded-md p-6" data-testid="api-feature-websocket">
              <div className="w-12 h-12 rounded-md flex items-center justify-center mb-4" style={{ background: "rgba(30,43,255,0.08)" }}>
                <Zap className="w-6 h-6 text-vest-g5" />
              </div>
              <h3 className="text-ink-dark font-bold text-lg mb-2">WebSocket Support</h3>
              <p className="text-ink-muted text-sm leading-relaxed">
                Real-time streaming for property prices, marketplace activity, and distribution events. Subscribe to specific channels for live updates with sub-second latency.
              </p>
            </div>
            <div className="glass rounded-md p-6" data-testid="api-feature-security">
              <div className="w-12 h-12 rounded-md flex items-center justify-center mb-4" style={{ background: "rgba(30,43,255,0.08)" }}>
                <Lock className="w-6 h-6 text-vest-g5" />
              </div>
              <h3 className="text-ink-dark font-bold text-lg mb-2">Enterprise Security</h3>
              <p className="text-ink-muted text-sm leading-relaxed">
                OAuth 2.0 with PKCE, API key rotation, IP whitelisting, and request signing. All data encrypted in transit (TLS 1.3) and at rest (AES-256).
              </p>
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4"><div className="border-t border-vest-g5/10" /></div>

      <section className="py-20 px-4 " data-testid="code-examples-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Quick Start"
            title="Get Started in"
            highlight="Minutes"
            description="Simple, intuitive API design with comprehensive SDK support."
          />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="glass rounded-md overflow-hidden" data-testid="code-snippet-rest">
              <div className="px-4 py-3 border-b flex items-center gap-2" style={{ borderColor: "rgba(30,43,255,0.08)" }}>
                <Code2 className="w-4 h-4 text-vest-g5" />
                <span className="text-sm text-ink-dark font-medium">REST API Example</span>
                <span className="text-xs text-ink-muted ml-auto">JavaScript</span>
              </div>
              <pre className="p-4 text-sm leading-relaxed overflow-x-auto" style={{ fontFamily: "var(--font-mono)", color: "#94a3b8" }}>
                <code>{codeSnippetJS}</code>
              </pre>
            </div>
            <div className="glass rounded-md overflow-hidden" data-testid="code-snippet-websocket">
              <div className="px-4 py-3 border-b flex items-center gap-2" style={{ borderColor: "rgba(30,43,255,0.08)" }}>
                <Zap className="w-4 h-4 text-vest-g5" />
                <span className="text-sm text-ink-dark font-medium">WebSocket Example</span>
                <span className="text-xs text-ink-muted ml-auto">JavaScript</span>
              </div>
              <pre className="p-4 text-sm leading-relaxed overflow-x-auto" style={{ fontFamily: "var(--font-mono)", color: "#94a3b8" }}>
                <code>{codeSnippetWebSocket}</code>
              </pre>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="endpoints-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Endpoints"
            title="API"
            highlight="Reference"
            description="Core endpoints to power your real estate tokenization integration."
          />
          <div className="space-y-4">
            {endpoints.map((endpoint) => {
              const Icon = endpoint.icon;
              return (
                <div key={endpoint.id} className="glass  rounded-md p-6 transition-all duration-300" data-testid={`endpoint-card-${endpoint.id}`}>
                  <div className="flex items-start gap-4 flex-wrap">
                    <div className="w-10 h-10 rounded-md flex items-center justify-center shrink-0" style={{ background: "rgba(30,43,255,0.08)" }}>
                      <Icon className="w-5 h-5 text-vest-g5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-ink-dark font-bold text-lg mb-1" data-testid={`endpoint-title-${endpoint.id}`}>{endpoint.title}</h3>
                      <p className="text-ink-muted text-sm mb-3">{endpoint.description}</p>
                      <div className="flex flex-wrap gap-2">
                        {endpoint.methods.map((method, idx) => (
                          <code
                            key={idx}
                            className="text-xs px-2 py-1 rounded-md"
                            style={{ background: "rgba(30,43,255,0.10)", color: "#ffffff", fontFamily: "var(--font-mono)" }}
                            data-testid={`endpoint-method-${endpoint.id}-${idx}`}
                          >
                            {method}
                          </code>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4"><div className="border-t border-vest-g5/10" /></div>

      <section className="py-20 px-4 " data-testid="sdks-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="SDKs"
            title="Official"
            highlight="Client Libraries"
            description="Get started quickly with our official SDKs for popular programming languages."
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {sdks.map((sdk) => (
              <div key={sdk.id} className="glass rounded-md p-6" data-testid={`sdk-card-${sdk.id}`}>
                <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                  <h3 className="text-ink-dark font-bold">{sdk.language}</h3>
                  <span className="text-xs px-2 py-1 rounded-md text-vest-g5 border border-vest-g5/15">{sdk.badge}</span>
                </div>
                <div className="rounded-md p-3 mb-4" style={{ background: "rgba(0,0,0,0.3)" }}>
                  <code className="text-sm text-vest-g5" style={{ fontFamily: "var(--font-mono)" }} data-testid={`sdk-install-${sdk.id}`}>
                    $ {sdk.install}
                  </code>
                </div>
                <button className="border border-vest-g5/20 text-ink-dark hover:bg-vest-g0/40 transition px-4 py-2 rounded-md text-sm w-full flex items-center justify-center gap-2" data-testid={`sdk-docs-${sdk.id}`}>
                  View Docs <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="rate-limits-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Pricing"
            title="Rate Limits &"
            highlight="API Plans"
            description="Choose the plan that fits your integration needs. All plans include full API documentation and sandbox access."
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {pricingTiers.map((tier) => (
              <div
                key={tier.id}
                className={`glass rounded-md p-8 flex flex-col ${tier.highlighted ? "border border-vest-g5/20 border" : ""}`}
                style={tier.highlighted ? { borderColor: "rgba(30,43,255,0.18)" } : undefined}
                data-testid={`pricing-card-${tier.id}`}
              >
                <div className="mb-6">
                  <h3 className="text-ink-dark font-bold text-xl mb-2" data-testid={`pricing-name-${tier.id}`}>{tier.name}</h3>
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-bold text-vest-g5" data-testid={`pricing-price-${tier.id}`}>{tier.price}</span>
                    <span className="text-ink-muted text-sm">{tier.period}</span>
                  </div>
                  <div className="flex items-center gap-1.5 mt-2">
                    <Gauge className="w-4 h-4 text-vest-g5" />
                    <span className="text-ink-muted text-sm" data-testid={`pricing-requests-${tier.id}`}>{tier.requests}</span>
                  </div>
                </div>
                <ul className="space-y-3 mb-8 flex-1">
                  {tier.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-vest-g5 shrink-0 mt-0.5" />
                      <span className="text-ink-muted text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
                <button
                  className={`w-full py-3 rounded-md text-sm font-semibold ${tier.highlighted ? "bg-vest-g5 text-ink-dark hover:opacity-90 transition" : "border border-vest-g5/20 text-ink-dark hover:bg-vest-g0/40 transition"}`}
                  data-testid={`pricing-cta-${tier.id}`}
                >
                  {tier.id === "enterprise" ? "Contact Sales" : "Get Started"}
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>
    </MarketingLayout>
  );
}
