import { useState, useMemo } from "react";
import { Link } from "wouter";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { GlassCard } from "@/components/marketing/glass-card";
import { GlassButton } from "@/components/marketing/glass-button";
import { motion } from "framer-motion";
import { Search, BookOpen, ArrowRight, Hash } from "lucide-react";

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const glossaryTerms = [
  { term: "AML", full: "Anti-Money Laundering", definition: "Laws, regulations, and procedures designed to prevent criminals from disguising illegally obtained funds as legitimate income. VestBlock implements AML screening as part of its KYC process, in compliance with Pakistani Financial Monitoring Unit (FMU) requirements." },
  { term: "Capital Appreciation", full: null, definition: "The increase in the market value of a property over time. In tokenized real estate, capital appreciation is reflected in the updated Net Asset Value (NAV) of your tokens, based on periodic independent property valuations." },
  { term: "Cap Table", full: "Capitalization Table", definition: "A record of all token holders and their proportional ownership in a property's SPV. VestBlock maintains a digital cap table for each property, updated in real time as tokens are purchased or sold." },
  { term: "CNIC", full: "Computerized National Identity Card", definition: "Pakistan's primary identity document issued by NADRA. Required for KYC verification on VestBlock for Pakistani residents." },
  { term: "Distribution", full: null, definition: "The payment of rental income to token holders. VestBlock processes distributions monthly, typically by the 15th of each month, after deducting property expenses and management fees." },
  { term: "DHA", full: "Defence Housing Authority", definition: "A chain of planned housing communities in Pakistan managed by the Pakistan Army. DHA developments in Karachi, Lahore, Islamabad, and other cities are among the most sought-after residential and commercial areas in the country." },
  { term: "EDD", full: "Enhanced Due Diligence", definition: "A more thorough investigation process applied to higher-risk investors, larger transactions, or politically exposed persons (PEPs). EDD may require additional documentation and longer processing times." },
  { term: "Entry Fee", full: null, definition: "A one-time fee charged when purchasing property tokens, typically 0–1.0% of the investment amount depending on the property and investor tier. Covers platform transaction processing costs." },
  { term: "Escrow", full: null, definition: "A financial arrangement where a third party holds funds on behalf of two transacting parties. VestBlock uses escrow accounts at scheduled banks to hold investor funds and rental income until distribution or settlement." },
  { term: "Exit Fee", full: null, definition: "A fee charged when selling tokens during an exit window, typically 0.5–1.0% of gross proceeds depending on investor tier. An additional early exit penalty (up to 2.0%) may apply if selling before the lockup period expires." },
  { term: "Exit Window", full: null, definition: "A scheduled period (typically twice per year) during which token holders can list their tokens for sale on VestBlock's internal secondary marketplace. Exit windows provide structured liquidity for an otherwise illiquid asset class." },
  { term: "FMU", full: "Financial Monitoring Unit", definition: "Pakistan's financial intelligence unit responsible for receiving, analyzing, and disseminating Suspicious Transaction Reports (STRs). VestBlock reports to the FMU as required by Pakistani AML regulations." },
  { term: "Fractional Ownership", full: null, definition: "The division of property ownership into smaller units (tokens), allowing multiple investors to own a proportional share of a property. Each token represents a fractional beneficial interest in the property's SPV." },
  { term: "Gross Yield", full: null, definition: "Annual rental income divided by property value, expressed as a percentage, before deducting any expenses. Gross yield provides a quick comparison metric but does not reflect actual investor returns." },
  { term: "Hurdle Rate", full: null, definition: "The minimum rate of return that a property must achieve before performance fees are charged. If returns exceed the hurdle rate, a performance fee (typically 8–15%) is applied only to the excess returns." },
  { term: "KYC", full: "Know Your Customer", definition: "The process of verifying the identity of investors to comply with regulatory requirements. VestBlock's KYC process requires CNIC (or NICOP for overseas Pakistanis), address verification, and identity confirmation." },
  { term: "Lockup Period", full: null, definition: "A minimum holding period for property tokens, during which you cannot submit exit requests. Lockup periods vary by property (typically 6–24 months) and are disclosed before investment. Exiting during lockup incurs an early exit penalty." },
  { term: "NAV", full: "Net Asset Value", definition: "The current value of a property's assets minus liabilities, divided by the total number of tokens. NAV determines the price at which tokens can be purchased or sold during exit windows. Updated periodically based on independent valuations." },
  { term: "Net Yield", full: null, definition: "Annual rental income minus operating expenses (property tax, maintenance, management fees, vacancy allowance, insurance), divided by property value. Net yield provides a more realistic picture of actual investor returns than gross yield." },
  { term: "NICOP", full: "National Identity Card for Overseas Pakistanis", definition: "An identity document issued by NADRA for Pakistanis living abroad. Accepted for KYC verification on VestBlock for overseas Pakistani investors." },
  { term: "Performance Fee", full: null, definition: "A fee charged on investment returns that exceed the property's hurdle rate. Aligns management incentives with investor outcomes. Only charged when performance thresholds are met, typically 8–15% of excess returns." },
  { term: "PKR", full: "Pakistani Rupee", definition: "The official currency of Pakistan and the primary currency for investments on VestBlock's Pakistan platform. Multi-currency support (AED, GBP, USD) is available for international investors." },
  { term: "SECP", full: "Securities and Exchange Commission of Pakistan", definition: "Pakistan's primary regulatory body for securities markets, corporate governance, and digital asset securities. VestBlock operates under SECP oversight for token issuance and secondary market activities." },
  { term: "SPV", full: "Special Purpose Vehicle", definition: "A separate legal entity (typically a private limited company) created to hold a specific property. Each VestBlock property has its own SPV registered with SECP. Token holders have fractional beneficial ownership in the SPV, which in turn owns the property." },
  { term: "Token", full: null, definition: "A digital unit representing fractional ownership in a property's SPV. Tokens entitle holders to proportional rental distributions and capital returns. Token ownership is recorded on VestBlock's ledger and reflected in the SPV's register of beneficial owners." },
  { term: "Tokenization", full: null, definition: "The process of converting property ownership rights into digital tokens that can be purchased, held, and sold on a platform. Each token represents a proportional share of the underlying property." },
  { term: "Waterfall Distribution", full: null, definition: "A structured method of distributing property income and proceeds according to a predefined priority hierarchy. Typically: operating expenses first, then debt service, then preferred returns to investors, then performance allocation to managers." },
];

export default function GlossaryPage() {
  const [searchQuery, setSearchQuery] = useState("");

  const filtered = useMemo(() => {
    if (!searchQuery.trim()) return glossaryTerms;
    const q = searchQuery.toLowerCase();
    return glossaryTerms.filter(
      (t) =>
        t.term.toLowerCase().includes(q) ||
        (t.full && t.full.toLowerCase().includes(q)) ||
        t.definition.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  const letters = useMemo(() => {
    const groups: Record<string, typeof glossaryTerms> = {};
    filtered.forEach((t) => {
      const letter = t.term[0].toUpperCase();
      if (!groups[letter]) groups[letter] = [];
      groups[letter].push(t);
    });
    return Object.entries(groups).sort(([a], [b]) => a.localeCompare(b));
  }, [filtered]);

  const allLetters = useMemo(() => {
    const s = new Set(glossaryTerms.map((t) => t.term[0].toUpperCase()));
    return Array.from(s).sort();
  }, []);

  return (
    <MarketingLayout>
      <PageMeta title="Glossary" description="Glossary of terms used in tokenized real estate investing. Understand key concepts like SPV, tokenization, cap table, and waterfall distribution." path="/pk/glossary" />
      <section className="relative py-24 sm:py-32 px-4 overflow-hidden" data-testid="glossary-hero">
        <div className="absolute inset-0 bg-gradient-to-b from-vest-g5/5 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div variants={fadeUp} initial="hidden" animate="visible">
            <span className="inline-flex items-center px-3.5 py-1.5 rounded-2xl text-xs font-medium mb-6 text-vest-g5 bg-vest-g5/10 border border-vest-g5/20" data-testid="glossary-badge">
              Glossary
            </span>
            <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-5 tracking-tight" data-testid="glossary-headline">
              Real Estate & Tokenization
              <br /><span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Glossary</span>
            </h1>
            <p className="text-base sm:text-lg text-ink-muted max-w-2xl mx-auto leading-relaxed" data-testid="glossary-subtext">
              Key terms and definitions for tokenized real estate investment in Pakistan. Bookmark this page as a reference.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="px-4 pb-6" data-testid="glossary-search">
        <div className="max-w-3xl mx-auto">
          <div className="relative mb-5">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-muted/70" />
            <input
              type="text"
              placeholder="Search terms..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-11 pr-4 py-3.5 rounded-2xl bg-white/50 border border-vest-g5/15 text-sm text-ink-dark placeholder:text-ink-muted focus:outline-none focus:border-vest-g5/40 transition-colors"
              data-testid="glossary-search-input"
            />
          </div>
          <div className="flex flex-wrap items-center gap-1.5" data-testid="glossary-alphabet">
            {allLetters.map((l) => (
              <a
                key={l}
                href={`#letter-${l}`}
                className="w-7 h-7 rounded-lg text-[10px] font-bold text-ink-muted/70 bg-white/50 border border-vest-g5/15 flex items-center justify-center hover:text-vest-g5 hover:border-vest-g5/30 transition-colors"
                data-testid={`glossary-letter-${l}`}
              >
                {l}
              </a>
            ))}
          </div>
        </div>
      </section>

      <section className="px-4 pb-20" data-testid="glossary-content">
        <div className="max-w-3xl mx-auto">
          {filtered.length === 0 ? (
            <GlassCard className="text-center py-12" data-testid="glossary-no-results">
              <Search className="w-8 h-8 text-ink-muted mx-auto mb-3" />
              <p className="text-sm text-ink-muted mb-1">No terms found</p>
              <p className="text-xs text-ink-muted">Try a different search term.</p>
            </GlassCard>
          ) : (
            <div className="space-y-8">
              {letters.map(([letter, terms]) => (
                <div key={letter} id={`letter-${letter}`} data-testid={`glossary-group-${letter}`}>
                  <div className="flex items-center gap-2 mb-3">
                    <span className="w-8 h-8 rounded-xl bg-vest-g5/15 flex items-center justify-center text-sm font-bold text-vest-g5">{letter}</span>
                    <div className="flex-1 h-px bg-vest-g5/15" />
                  </div>
                  <div className="space-y-2">
                    {terms.map((t) => (
                      <motion.div key={t.term} variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
                        <GlassCard className="p-4" data-testid={`glossary-term-${t.term.toLowerCase().replace(/\s+/g, "-")}`}>
                          <div className="flex items-start gap-3">
                            <div className="flex-1">
                              <h3 className="text-sm font-bold text-ink-dark">
                                {t.term}
                                {t.full && <span className="text-ink-muted/70 font-normal ml-1.5">({t.full})</span>}
                              </h3>
                              <p className="text-xs text-ink-muted leading-relaxed mt-2">{t.definition}</p>
                            </div>
                          </div>
                        </GlassCard>
                      </motion.div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="py-12 px-4" data-testid="glossary-cta">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <GlassCard className="border border-vest-g5/20 bg-gradient-to-br from-vest-g5/5 to-transparent py-10">
              <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark mb-3">Learn <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">More</span></h2>
              <p className="text-sm text-ink-muted mb-6 max-w-md mx-auto">
                Explore our blog and investor guides for in-depth articles on each topic.
              </p>
              <div className="flex flex-wrap items-center justify-center gap-3">
                <Link href="/blog">
                  <GlassButton data-testid="glossary-cta-blog">Read Blog <ArrowRight className="w-4 h-4" /></GlassButton>
                </Link>
                <Link href="/guides">
                  <GlassButton variant="secondary" data-testid="glossary-cta-guides">Investor Guides</GlassButton>
                </Link>
              </div>
            </GlassCard>
          </motion.div>
        </div>
      </section>
    </MarketingLayout>
  );
}
