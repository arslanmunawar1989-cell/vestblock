import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { SectionHeader } from "@/components/marketing/section-header";
import { Link } from "wouter";
import {
  Newspaper,
  ExternalLink,
  Download,
  Mail,
  Phone,
  MapPin,
  Calendar,
  ArrowRight,
} from "lucide-react";

const pressArticles = [
  {
    id: "dawn",
    outlet: "Dawn",
    title: "VestBlock Brings Fractional Real Estate to Pakistan's Middle Class",
    excerpt: "The Islamabad-based startup is making waves by tokenizing premium properties, allowing investments starting from PKR 50,000.",
    date: "January 15, 2026",
    category: "Feature",
  },
  {
    id: "the-news",
    outlet: "The News",
    title: "How Blockchain Is Reshaping Pakistan's Property Market",
    excerpt: "VestBlock's SECP-licensed platform has crossed PKR 2 billion in assets under management, signaling growing trust in digital securities.",
    date: "December 8, 2025",
    category: "Business",
  },
  {
    id: "express-tribune",
    outlet: "Express Tribune",
    title: "VestBlock Raises $5M to Expand Tokenized Real Estate Offerings",
    excerpt: "The Series A funding will fuel expansion into commercial properties and launch of secondary marketplace for token trading.",
    date: "November 22, 2025",
    category: "Funding",
  },
  {
    id: "business-recorder",
    outlet: "Business Recorder",
    title: "SECP Approves VestBlock's Digital Asset Framework for Property Tokens",
    excerpt: "Regulatory milestone paves the way for compliant real estate tokenization in Pakistan, with VestBlock leading the charge.",
    date: "October 5, 2025",
    category: "Regulation",
  },
  {
    id: "techjuice",
    outlet: "TechJuice",
    title: "VestBlock: Pakistan's Answer to Fractional Property Investment",
    excerpt: "With over 10,000 verified investors and 45+ tokenized properties, VestBlock is proving that PropTech can work in emerging markets.",
    date: "September 18, 2025",
    category: "Tech",
  },
  {
    id: "propakistani",
    outlet: "ProPakistani",
    title: "VestBlock Launches PKR-Denominated Real Estate Tokens with Quarterly Yields",
    excerpt: "Investors can now earn rental yields distributed quarterly, with full transparency through blockchain-verified records.",
    date: "August 30, 2025",
    category: "Product",
  },
];

const pressKitItems = [
  { label: "Brand Guidelines & Logos", format: "PDF, 12MB" },
  { label: "Founder Headshots & Team Photos", format: "ZIP, 45MB" },
  { label: "Company Fact Sheet", format: "PDF, 2MB" },
  { label: "Product Screenshots", format: "ZIP, 30MB" },
];

export default function PressPage() {
  return (
    <MarketingLayout>
      <PageMeta title="Press & Coverage" description="Latest press coverage, news articles, and media mentions about VestBlock and tokenized real estate in Pakistan." path="/pk/press" />
      <section className="relative overflow-hidden py-24 sm:py-32 px-4" data-testid="press-hero">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center px-3 py-1 rounded-md text-xs font-medium mb-6 text-vest-g5 border border-vest-g5/15" data-testid="press-badge">
            Press & Media
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-6" data-testid="press-headline">
            VestBlock{" "}
            <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">In the News</span>
          </h1>
          <p className="text-lg text-ink-muted max-w-2xl mx-auto leading-relaxed" data-testid="press-subtext">
            Read the latest coverage of VestBlock across Pakistan's leading publications and technology media outlets.
          </p>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="press-mentions-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Coverage"
            title="In the News"
            description="Featured across Pakistan's most trusted media outlets."
          />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pressArticles.map((article) => (
              <div
                key={article.id}
                className="glass  rounded-md p-6 transition-all duration-300 flex flex-col"
                data-testid={`press-card-${article.id}`}
              >
                <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                  <span className="text-sm font-semibold text-vest-g5" data-testid={`press-outlet-${article.id}`}>
                    {article.outlet}
                  </span>
                  <span className="text-xs px-2 py-1 rounded-md text-ink-muted border border-vest-g5/15-subtle">
                    {article.category}
                  </span>
                </div>
                <h3 className="text-lg font-bold text-ink-dark mb-3 leading-snug" data-testid={`press-title-${article.id}`}>
                  {article.title}
                </h3>
                <p className="text-ink-muted text-sm leading-relaxed mb-4 flex-1">
                  {article.excerpt}
                </p>
                <div className="flex items-center justify-between flex-wrap gap-2 mt-auto">
                  <div className="flex items-center gap-1.5 text-ink-muted text-xs">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{article.date}</span>
                  </div>
                  <button className="flex items-center gap-1 text-sm text-vest-g5 hover:underline" data-testid={`press-read-${article.id}`}>
                    Read Article <ExternalLink className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4"><div className="border-t border-vest-g5/10" /></div>

      <section className="py-20 px-4 " data-testid="press-kit-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Resources"
            title="Press Kit"
            description="Download official VestBlock brand assets, logos, and media resources."
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {pressKitItems.map((item, index) => (
              <div
                key={index}
                className="glass rounded-md p-6 text-center flex flex-col items-center gap-4"
                data-testid={`press-kit-item-${index}`}
              >
                <div className="w-12 h-12 rounded-md flex items-center justify-center" style={{ background: "rgba(30,43,255,0.08)" }}>
                  <Download className="w-6 h-6 text-vest-g5" />
                </div>
                <div>
                  <p className="text-ink-dark font-semibold text-sm mb-1">{item.label}</p>
                  <p className="text-ink-muted text-xs">{item.format}</p>
                </div>
                <button className="border border-vest-g5/20 text-ink-dark hover:bg-vest-g0/40 transition px-4 py-2 rounded-md text-sm w-full" data-testid={`press-download-${index}`}>
                  Download
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4"><div className="border-t border-vest-g5/10" /></div>

      <section className="py-20 px-4" data-testid="media-contact-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Get in Touch"
            title="Media Contact"
            description="For press inquiries, interview requests, and media partnerships."
          />
          <div className="glass rounded-md p-8 max-w-2xl mx-auto">
            <div className="flex flex-col gap-6">
              <div className="flex items-start gap-4" data-testid="media-contact-email">
                <div className="w-10 h-10 rounded-md flex items-center justify-center shrink-0" style={{ background: "rgba(30,43,255,0.08)" }}>
                  <Mail className="w-5 h-5 text-vest-g5" />
                </div>
                <div>
                  <p className="text-ink-dark font-semibold text-sm">Email</p>
                  <p className="text-ink-muted text-sm">press@vestblock.pk</p>
                </div>
              </div>
              <div className="flex items-start gap-4" data-testid="media-contact-phone">
                <div className="w-10 h-10 rounded-md flex items-center justify-center shrink-0" style={{ background: "rgba(30,43,255,0.08)" }}>
                  <Phone className="w-5 h-5 text-vest-g5" />
                </div>
                <div>
                  <p className="text-ink-dark font-semibold text-sm">Phone</p>
                  <p className="text-ink-muted text-sm">+92 51 111 8378 (VEST)</p>
                </div>
              </div>
              <div className="flex items-start gap-4" data-testid="media-contact-address">
                <div className="w-10 h-10 rounded-md flex items-center justify-center shrink-0" style={{ background: "rgba(30,43,255,0.08)" }}>
                  <MapPin className="w-5 h-5 text-vest-g5" />
                </div>
                <div>
                  <p className="text-ink-dark font-semibold text-sm">Office</p>
                  <p className="text-ink-muted text-sm">Floor 12, Centaurus Mall, F-8 Markaz, Islamabad, Pakistan</p>
                </div>
              </div>
            </div>
            <div className="mt-8 pt-6 border-t" style={{ borderColor: "rgba(30,43,255,0.08)" }}>
              <p className="text-ink-muted text-xs text-center">
                For general inquiries, please visit our{" "}
                <Link href="/contact" className="text-vest-g5 hover:underline" data-testid="press-contact-link">
                  Contact Page
                </Link>
              </p>
            </div>
          </div>
        </div>
      </section>
    </MarketingLayout>
  );
}
