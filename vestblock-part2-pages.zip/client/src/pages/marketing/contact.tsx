import { useState } from "react";
import { MarketingLayout } from "@/components/marketing/layout";
import { MarketingHero } from "@/components/marketing/marketing-hero";
import { GlassCard } from "@/components/marketing/glass-card";
import { PageMeta } from "@/components/marketing/page-meta";
import { motion } from "framer-motion";
import { MapPin, Phone, Clock, Mail, Send, Building2 } from "lucide-react";
import { GlassButton } from "@/components/marketing/glass-button";

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const subjects = [
  "General Inquiry",
  "Investment Support",
  "KYC & Verification",
  "Technical Issue",
  "Partnership Opportunity",
  "Compliance & Legal",
  "Media & Press",
];

const offices = [
  { city: "Karachi (HQ)", address: "Floor 12, Centrepoint Tower, Shahrah-e-Faisal, Karachi 75400" },
  { city: "Lahore", address: "Office 8-A, Gulberg III, MM Alam Road, Lahore 54000" },
  { city: "Islamabad", address: "Suite 405, Beverly Centre, Blue Area, Islamabad 44000" },
];

const inputCls = "w-full px-4 py-3 rounded-xl text-sm text-ink-dark placeholder:text-ink-muted focus:outline-none focus:ring-1 focus:ring-vest-g5/40 bg-vest-g0/30 border border-vest-g5/15";

export default function ContactPage() {
  const [formData, setFormData] = useState({ name: "", email: "", phone: "", subject: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <MarketingLayout>
      <PageMeta
        title="Contact Us"
        description="Get in touch with VestBlock for investment support, partnership opportunities, compliance inquiries, or technical assistance. Offices in Karachi, Lahore, and Islamabad."
        path="/pk/contact"
      />

      <MarketingHero
        badge="Contact"
        title="Get in"
        highlight="Touch"
        subtitle="Have a question about investing, compliance, or partnerships? Our team is here to help."
        testIdPrefix="contact"
      />

      <section className="py-16 px-4" data-testid="contact-form-section">
        <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-5 gap-8">
          <div className="lg:col-span-3">
            <GlassCard data-testid="contact-form-card">
              <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark mb-6">Send Us a <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Message</span></h2>
              {submitted ? (
                <div className="text-center py-12" data-testid="contact-success">
                  <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 bg-vest-g5/10">
                    <Send className="w-7 h-7 text-vest-g5" />
                  </div>
                  <h3 className="text-xl font-semibold text-ink-dark mb-2">Message Sent</h3>
                  <p className="text-ink-muted">Thank you for reaching out. Our team will respond within 24 hours.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-sm font-medium text-ink-muted mb-2">Full Name</label>
                      <input type="text" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} placeholder="Ahmed Khan" className={inputCls} data-testid="input-name" required />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-ink-muted mb-2">Email</label>
                      <input type="email" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} placeholder="ahmed@example.com" className={inputCls} data-testid="input-email" required />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-sm font-medium text-ink-muted mb-2">Phone</label>
                      <input type="tel" value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} placeholder="+92 300 1234567" className={inputCls} data-testid="input-phone" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-ink-muted mb-2">Subject</label>
                      <select value={formData.subject} onChange={(e) => setFormData({ ...formData, subject: e.target.value })} className={inputCls} data-testid="select-subject" required>
                        <option value="" disabled>Select a subject</option>
                        {subjects.map((s) => (
                          <option key={s} value={s} style={{ background: "#071A3A" }}>{s}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-ink-muted mb-2">Message</label>
                    <textarea value={formData.message} onChange={(e) => setFormData({ ...formData, message: e.target.value })} placeholder="Tell us how we can help..." rows={5} className={`${inputCls} resize-none`} data-testid="textarea-message" required />
                  </div>
                  <GlassButton type="submit" data-testid="button-submit-contact">
                    Send Message <Send className="w-4 h-4" />
                  </GlassButton>
                </form>
              )}
            </GlassCard>
          </div>

          <div className="lg:col-span-2 space-y-5">
            {[
              { icon: Mail, title: "Email", lines: ["info@vestblock.pk", "support@vestblock.pk"], tid: "contact-info-email" },
              { icon: Phone, title: "Phone", lines: ["+92 21 3456 7890", "Mon-Fri 9AM-6PM PKT"], tid: "contact-info-phone" },
              { icon: Clock, title: "Support Hours", lines: ["Mon-Fri 9AM-6PM PKT", "Emergency support available 24/7"], tid: "contact-info-hours" },
            ].map((c) => (
              <GlassCard key={c.tid} data-testid={c.tid}>
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-vest-g5/10">
                    <c.icon className="w-5 h-5 text-vest-g5" />
                  </div>
                  <h3 className="text-lg font-semibold text-ink-dark">{c.title}</h3>
                </div>
                {c.lines.map((l, i) => (
                  <p key={i} className={`text-sm ${i === 0 ? "text-ink-muted" : "text-ink-muted/70"}`}>{l}</p>
                ))}
              </GlassCard>
            ))}

            <GlassCard data-testid="contact-offices">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-vest-g5/10">
                  <Building2 className="w-5 h-5 text-vest-g5" />
                </div>
                <h3 className="text-lg font-semibold text-ink-dark">Offices</h3>
              </div>
              {offices.map((o) => (
                <div key={o.city} className="mb-3 last:mb-0">
                  <p className="text-sm font-medium text-ink-dark">{o.city}</p>
                  <p className="text-xs text-ink-muted/70" data-testid={`text-office-${o.city.split(" ")[0].toLowerCase()}`}>{o.address}</p>
                </div>
              ))}
            </GlassCard>
          </div>
        </div>
      </section>
    </MarketingLayout>
  );
}
