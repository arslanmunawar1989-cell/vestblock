import { useState } from "react";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { GlassCard } from "@/components/marketing/glass-card";
import { GlassButton } from "@/components/marketing/glass-button";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowRight, ArrowLeft, MapPin, Wallet, Target,
  Shield, Clock, Droplets, Sparkles, TrendingUp,
  ChevronDown, ChevronUp, AlertTriangle, Info,
  CheckCircle2, Building2, BarChart3, Loader2,
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

const PK_CITIES = ["Karachi", "Lahore", "Islamabad", "Faisalabad", "Rawalpindi", "Peshawar", "Multan", "Quetta"];

const BUDGET_PRESETS = [
  { label: "PKR 25K - 50K", min: 25000, max: 50000 },
  { label: "PKR 50K - 100K", min: 50000, max: 100000 },
  { label: "PKR 100K - 250K", min: 100000, max: 250000 },
  { label: "PKR 250K - 500K", min: 250000, max: 500000 },
  { label: "PKR 500K+", min: 500000, max: 1000000 },
];

const GOAL_OPTIONS: { value: "INCOME" | "GROWTH" | "BALANCED"; label: string; desc: string; icon: React.ReactNode }[] = [
  { value: "INCOME", label: "Steady Income", desc: "Regular rental yields and distributions", icon: <Wallet className="w-5 h-5" /> },
  { value: "GROWTH", label: "Capital Growth", desc: "Long-term property value appreciation", icon: <TrendingUp className="w-5 h-5" /> },
  { value: "BALANCED", label: "Balanced", desc: "Mix of income and appreciation", icon: <BarChart3 className="w-5 h-5" /> },
];

const HORIZON_OPTIONS = [
  { value: 6, label: "6 months" },
  { value: 12, label: "1 year" },
  { value: 24, label: "2 years" },
  { value: 36, label: "3 years" },
  { value: 60, label: "5+ years" },
];

const LIQUIDITY_OPTIONS: { value: "LOW" | "MED" | "HIGH"; label: string; desc: string }[] = [
  { value: "LOW", label: "Low", desc: "I can lock my capital for the full term" },
  { value: "MED", label: "Medium", desc: "I may need partial access" },
  { value: "HIGH", label: "High", desc: "I want the ability to exit anytime" },
];

interface MatchReason { factor: string; score: number; maxScore: number; detail: string; }
interface PropertyMatch {
  property: {
    id: string; name: string; city: string; type: string; strategy: string;
    minInvestment: number; annualYield: number; appreciation: number;
    image: string; location: string; soldTokens: number; totalTokens: number;
  };
  totalScore: number; maxPossibleScore: number; percentMatch: number;
  reasons: MatchReason[];
}

interface MatchResult {
  ok: boolean;
  matches: PropertyMatch[];
  explanation: { whyTheseMatches: string; tradeoffs: string };
  preferences: { goal: string; budgetRange: string; cities: string[]; riskTolerance: number; horizonMonths: number; liquidityNeed: string };
}

const STEPS = ["Cities", "Budget", "Goal", "Risk", "Horizon", "Liquidity"];

export default function PropertyMatchPage() {
  const [step, setStep] = useState(0);
  const [cities, setCities] = useState<string[]>([]);
  const [budget, setBudget] = useState<{ min: number; max: number } | null>(null);
  const [goal, setGoal] = useState<"INCOME" | "GROWTH" | "BALANCED" | null>(null);
  const [risk, setRisk] = useState(3);
  const [horizon, setHorizon] = useState(24);
  const [liquidity, setLiquidity] = useState<"LOW" | "MED" | "HIGH" | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<MatchResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const canNext = () => {
    if (step === 0) return cities.length > 0;
    if (step === 1) return budget !== null;
    if (step === 2) return goal !== null;
    if (step === 3) return true;
    if (step === 4) return true;
    if (step === 5) return liquidity !== null;
    return false;
  };

  const toggleCity = (city: string) => {
    setCities(prev => prev.includes(city) ? prev.filter(c => c !== city) : [...prev, city]);
  };

  const handleSubmit = async () => {
    if (!budget || !goal || !liquidity) return;
    setLoading(true);
    setError(null);
    try {
      const res = await apiRequest("POST", "/api/ai/recommender/match", {
        region: "PK",
        budgetMin: budget.min,
        budgetMax: budget.max,
        goal,
        cities,
        riskTolerance: risk,
        horizonMonths: horizon,
        liquidityNeed: liquidity,
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error || "Failed to get matches");
      setResult(data);
    } catch (err: any) {
      setError(err.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  const handleNext = () => {
    if (step < 5) setStep(step + 1);
    else handleSubmit();
  };

  if (result) {
    return (
      <MarketingLayout>
        <PageMeta title="Your Property Matches | VestBlock" description="Personalized property investment recommendations based on your preferences." />
        <ResultsView result={result} onReset={() => { setResult(null); setStep(0); }} />
      </MarketingLayout>
    );
  }

  return (
    <MarketingLayout>
      <PageMeta title="Property Match Quiz | VestBlock" description="Answer a few questions to find your ideal fractional real estate investment." />
      <div className="min-h-[80vh] flex flex-col items-center justify-center py-16 px-4">
        <div className="max-w-xl w-full">
          <div className="text-center mb-8">
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-vest-g5/20 bg-vest-g1/40 text-vest-g5 text-sm font-medium mb-4">
              <Sparkles className="w-4 h-4" /> Property Match
            </motion.div>
            <h1 className="text-3xl md:text-4xl font-bold text-ink-darkest mb-2" data-testid="match-title">Find Your Ideal Investment</h1>
            <p className="text-ink-muted">Answer {STEPS.length} quick questions to get personalized property recommendations</p>
          </div>

          <div className="flex gap-1.5 mb-8" data-testid="match-progress">
            {STEPS.map((s, i) => (
              <div key={s} className="flex-1 flex flex-col items-center gap-1">
                <div className={`h-1.5 w-full rounded-full transition-colors ${i <= step ? "bg-vest-g5" : "bg-stroke-default/30"}`} />
                <span className={`text-[10px] font-medium ${i <= step ? "text-vest-g5" : "text-ink-muted/50"}`}>{s}</span>
              </div>
            ))}
          </div>

          {loading ? (
            <GlassCard className="text-center py-16">
              <Loader2 className="w-10 h-10 text-vest-g5 animate-spin mx-auto mb-4" />
              <p className="text-ink-muted text-lg" data-testid="match-loading">Analyzing properties against your preferences...</p>
              <p className="text-ink-muted/60 text-sm mt-2">Our algorithm scores each property, then AI writes your personalized explanation</p>
            </GlassCard>
          ) : error ? (
            <GlassCard className="text-center py-12">
              <AlertTriangle className="w-10 h-10 text-amber-500 mx-auto mb-4" />
              <p className="text-ink-darkest font-semibold mb-2">Something went wrong</p>
              <p className="text-ink-muted mb-4">{error}</p>
              <GlassButton onClick={() => { setError(null); handleSubmit(); }} data-testid="match-retry">Try Again</GlassButton>
            </GlassCard>
          ) : (
            <AnimatePresence mode="wait">
              <motion.div key={step} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.2 }}>
                <GlassCard data-testid={`match-step-${step}`}>
                  {step === 0 && <StepCities cities={cities} toggleCity={toggleCity} />}
                  {step === 1 && <StepBudget budget={budget} setBudget={setBudget} />}
                  {step === 2 && <StepGoal goal={goal} setGoal={setGoal} />}
                  {step === 3 && <StepRisk risk={risk} setRisk={setRisk} />}
                  {step === 4 && <StepHorizon horizon={horizon} setHorizon={setHorizon} />}
                  {step === 5 && <StepLiquidity liquidity={liquidity} setLiquidity={setLiquidity} />}

                  <div className="flex justify-between mt-8 pt-4 border-t border-stroke-default/20">
                    {step > 0 ? (
                      <button onClick={() => setStep(step - 1)} className="flex items-center gap-2 text-ink-muted hover:text-ink-darkest transition-colors" data-testid="match-back">
                        <ArrowLeft className="w-4 h-4" /> Back
                      </button>
                    ) : <div />}
                    <GlassButton onClick={handleNext} disabled={!canNext()} data-testid="match-next" className={!canNext() ? "opacity-50 cursor-not-allowed" : ""}>
                      {step === 5 ? "Find My Matches" : "Next"} <ArrowRight className="w-4 h-4" />
                    </GlassButton>
                  </div>
                </GlassCard>
              </motion.div>
            </AnimatePresence>
          )}

          <p className="text-center text-xs text-ink-muted/60 mt-6">
            <Info className="w-3 h-3 inline mr-1" />
            This tool provides informational analysis only. It does not constitute financial advice. Past performance does not guarantee future results.
          </p>
        </div>
      </div>
    </MarketingLayout>
  );
}

function StepCities({ cities, toggleCity }: { cities: string[]; toggleCity: (c: string) => void }) {
  return (
    <div>
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-lg bg-vest-g1 flex items-center justify-center"><MapPin className="w-5 h-5 text-vest-g5" /></div>
        <div><h2 className="text-lg font-semibold text-ink-darkest">Where do you want to invest?</h2><p className="text-sm text-ink-muted">Select one or more cities</p></div>
      </div>
      <div className="grid grid-cols-2 gap-3" data-testid="match-cities-grid">
        {PK_CITIES.map(city => (
          <button key={city} onClick={() => toggleCity(city)} data-testid={`match-city-${city.toLowerCase()}`}
            className={`p-3 rounded-lg border text-left transition-all ${cities.includes(city) ? "border-vest-g5 bg-vest-g1/50 text-vest-g5 font-medium" : "border-stroke-default/30 text-ink-muted hover:border-vest-g5/40"}`}>
            <MapPin className="w-4 h-4 inline mr-2" />{city}
          </button>
        ))}
      </div>
    </div>
  );
}

function StepBudget({ budget, setBudget }: { budget: { min: number; max: number } | null; setBudget: (b: { min: number; max: number }) => void }) {
  return (
    <div>
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-lg bg-vest-g1 flex items-center justify-center"><Wallet className="w-5 h-5 text-vest-g5" /></div>
        <div><h2 className="text-lg font-semibold text-ink-darkest">What's your investment budget?</h2><p className="text-sm text-ink-muted">Choose a range that suits you</p></div>
      </div>
      <div className="flex flex-col gap-3" data-testid="match-budget-options">
        {BUDGET_PRESETS.map(p => (
          <button key={p.label} onClick={() => setBudget({ min: p.min, max: p.max })} data-testid={`match-budget-${p.min}`}
            className={`p-4 rounded-lg border text-left transition-all ${budget?.min === p.min ? "border-vest-g5 bg-vest-g1/50 text-vest-g5 font-medium" : "border-stroke-default/30 text-ink-muted hover:border-vest-g5/40"}`}>
            {p.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function StepGoal({ goal, setGoal }: { goal: string | null; setGoal: (g: "INCOME" | "GROWTH" | "BALANCED") => void }) {
  return (
    <div>
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-lg bg-vest-g1 flex items-center justify-center"><Target className="w-5 h-5 text-vest-g5" /></div>
        <div><h2 className="text-lg font-semibold text-ink-darkest">What's your investment goal?</h2><p className="text-sm text-ink-muted">This helps us match property strategies</p></div>
      </div>
      <div className="flex flex-col gap-3" data-testid="match-goal-options">
        {GOAL_OPTIONS.map(g => (
          <button key={g.value} onClick={() => setGoal(g.value)} data-testid={`match-goal-${g.value.toLowerCase()}`}
            className={`p-4 rounded-lg border text-left transition-all flex items-center gap-4 ${goal === g.value ? "border-vest-g5 bg-vest-g1/50" : "border-stroke-default/30 hover:border-vest-g5/40"}`}>
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${goal === g.value ? "bg-vest-g5 text-white" : "bg-vest-g1 text-vest-g5"}`}>{g.icon}</div>
            <div><p className={`font-medium ${goal === g.value ? "text-vest-g5" : "text-ink-darkest"}`}>{g.label}</p><p className="text-sm text-ink-muted">{g.desc}</p></div>
          </button>
        ))}
      </div>
    </div>
  );
}

function StepRisk({ risk, setRisk }: { risk: number; setRisk: (r: number) => void }) {
  const labels = ["Very Conservative", "Conservative", "Moderate", "Aggressive", "Very Aggressive"];
  return (
    <div>
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-lg bg-vest-g1 flex items-center justify-center"><Shield className="w-5 h-5 text-vest-g5" /></div>
        <div><h2 className="text-lg font-semibold text-ink-darkest">What's your risk tolerance?</h2><p className="text-sm text-ink-muted">Higher risk may mean higher potential returns</p></div>
      </div>
      <div className="flex flex-col items-center gap-4 py-4" data-testid="match-risk-slider">
        <div className="flex justify-between w-full px-2">
          {[1, 2, 3, 4, 5].map(v => (
            <button key={v} onClick={() => setRisk(v)} data-testid={`match-risk-${v}`}
              className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg transition-all ${risk === v ? "bg-vest-g5 text-white scale-110 shadow-lg" : "bg-vest-g1 text-ink-muted hover:bg-vest-g2"}`}>
              {v}
            </button>
          ))}
        </div>
        <p className="text-vest-g5 font-medium" data-testid="match-risk-label">{labels[risk - 1]}</p>
        <div className="flex justify-between w-full text-xs text-ink-muted/60 px-2">
          <span>Lower risk</span><span>Higher risk</span>
        </div>
      </div>
    </div>
  );
}

function StepHorizon({ horizon, setHorizon }: { horizon: number; setHorizon: (h: number) => void }) {
  return (
    <div>
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-lg bg-vest-g1 flex items-center justify-center"><Clock className="w-5 h-5 text-vest-g5" /></div>
        <div><h2 className="text-lg font-semibold text-ink-darkest">What's your investment horizon?</h2><p className="text-sm text-ink-muted">How long do you plan to stay invested?</p></div>
      </div>
      <div className="flex flex-col gap-3" data-testid="match-horizon-options">
        {HORIZON_OPTIONS.map(h => (
          <button key={h.value} onClick={() => setHorizon(h.value)} data-testid={`match-horizon-${h.value}`}
            className={`p-4 rounded-lg border text-left transition-all ${horizon === h.value ? "border-vest-g5 bg-vest-g1/50 text-vest-g5 font-medium" : "border-stroke-default/30 text-ink-muted hover:border-vest-g5/40"}`}>
            <Clock className="w-4 h-4 inline mr-2" />{h.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function StepLiquidity({ liquidity, setLiquidity }: { liquidity: string | null; setLiquidity: (l: "LOW" | "MED" | "HIGH") => void }) {
  return (
    <div>
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-lg bg-vest-g1 flex items-center justify-center"><Droplets className="w-5 h-5 text-vest-g5" /></div>
        <div><h2 className="text-lg font-semibold text-ink-darkest">How important is liquidity?</h2><p className="text-sm text-ink-muted">Your ability to exit the investment early</p></div>
      </div>
      <div className="flex flex-col gap-3" data-testid="match-liquidity-options">
        {LIQUIDITY_OPTIONS.map(l => (
          <button key={l.value} onClick={() => setLiquidity(l.value)} data-testid={`match-liquidity-${l.value.toLowerCase()}`}
            className={`p-4 rounded-lg border text-left transition-all ${liquidity === l.value ? "border-vest-g5 bg-vest-g1/50" : "border-stroke-default/30 hover:border-vest-g5/40"}`}>
            <p className={`font-medium ${liquidity === l.value ? "text-vest-g5" : "text-ink-darkest"}`}>{l.label}</p>
            <p className="text-sm text-ink-muted">{l.desc}</p>
          </button>
        ))}
      </div>
    </div>
  );
}

function ResultsView({ result, onReset }: { result: MatchResult; onReset: () => void }) {
  const [expandedCard, setExpandedCard] = useState<string | null>(null);

  return (
    <div className="py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-10">
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-vest-g5/20 bg-vest-g1/40 text-vest-g5 text-sm font-medium mb-4">
            <CheckCircle2 className="w-4 h-4" /> {result.matches.length} Properties Matched
          </motion.div>
          <h1 className="text-3xl md:text-4xl font-bold text-ink-darkest mb-2" data-testid="results-title">Your Top Property Matches</h1>
          <p className="text-ink-muted max-w-lg mx-auto">
            Based on your preferences: {result.preferences.goal} goal, {result.preferences.budgetRange}, {result.preferences.cities.join(", ")}
          </p>
        </div>

        <div className="grid gap-6 mb-10" data-testid="results-cards">
          {result.matches.map((match, index) => (
            <motion.div key={match.property.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1 }}>
              <MatchCard match={match} rank={index + 1} expanded={expandedCard === match.property.id} onToggle={() => setExpandedCard(expandedCard === match.property.id ? null : match.property.id)} />
            </motion.div>
          ))}
        </div>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
          <GlassCard className="mb-6" data-testid="results-explanation">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-vest-g1 flex items-center justify-center"><Sparkles className="w-5 h-5 text-vest-g5" /></div>
              <h2 className="text-xl font-bold text-ink-darkest">Why These Matches</h2>
            </div>
            <p className="text-ink-muted leading-relaxed whitespace-pre-line" data-testid="results-why">{result.explanation.whyTheseMatches}</p>
          </GlassCard>

          <GlassCard className="mb-6" data-testid="results-tradeoffs">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-amber-50 flex items-center justify-center"><AlertTriangle className="w-5 h-5 text-amber-500" /></div>
              <h2 className="text-xl font-bold text-ink-darkest">Tradeoffs to Consider</h2>
            </div>
            <p className="text-ink-muted leading-relaxed whitespace-pre-line" data-testid="results-tradeoffs-text">{result.explanation.tradeoffs}</p>
          </GlassCard>
        </motion.div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
          <GlassButton variant="secondary" onClick={onReset} data-testid="results-retake">
            <ArrowLeft className="w-4 h-4" /> Retake Quiz
          </GlassButton>
        </div>

        <div className="mt-8 p-4 rounded-lg border border-stroke-default/20 bg-vest-g1/20" data-testid="results-disclaimer">
          <p className="text-xs text-ink-muted/60 text-center">
            <Info className="w-3 h-3 inline mr-1" />
            This analysis is for informational purposes only and does not constitute financial, investment, or legal advice. Property investments carry risks including potential loss of capital.
            Past performance and projected returns do not guarantee future results. Consult a qualified financial advisor before making investment decisions.
          </p>
        </div>
      </div>
    </div>
  );
}

function MatchCard({ match, rank, expanded, onToggle }: { match: PropertyMatch; rank: number; expanded: boolean; onToggle: () => void }) {
  const fundedPct = ((match.property.soldTokens / match.property.totalTokens) * 100).toFixed(0);

  const getScoreColor = (pct: number) => {
    if (pct >= 80) return "text-green-600";
    if (pct >= 60) return "text-vest-g5";
    if (pct >= 40) return "text-amber-500";
    return "text-red-400";
  };

  return (
    <GlassCard className="overflow-hidden !p-0" data-testid={`match-card-${rank}`}>
      <div className="flex flex-col md:flex-row">
        <div className="relative w-full md:w-48 h-40 md:h-auto shrink-0">
          <img src={match.property.image} alt={match.property.name} className="w-full h-full object-cover" />
          <div className="absolute top-3 left-3 bg-vest-g5 text-white text-sm font-bold px-3 py-1 rounded-full">
            #{rank}
          </div>
        </div>
        <div className="flex-1 p-5">
          <div className="flex items-start justify-between mb-2">
            <div>
              <h3 className="text-lg font-bold text-ink-darkest" data-testid={`match-name-${rank}`}>{match.property.name}</h3>
              <p className="text-sm text-ink-muted flex items-center gap-1"><MapPin className="w-3 h-3" /> {match.property.location}</p>
            </div>
            <div className="text-right">
              <p className={`text-2xl font-bold ${getScoreColor(match.percentMatch)}`} data-testid={`match-score-${rank}`}>{match.percentMatch}%</p>
              <p className="text-xs text-ink-muted">match</p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 mb-3">
            <span className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full bg-vest-g1 text-vest-g5 border border-vest-g5/20">
              <Building2 className="w-3 h-3" /> {match.property.type}
            </span>
            <span className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full bg-vest-g1 text-vest-g5 border border-vest-g5/20">
              <Target className="w-3 h-3" /> {match.property.strategy}
            </span>
            <span className="text-xs px-2 py-1 rounded-full bg-green-50 text-green-700 border border-green-200">
              {match.property.annualYield}% Yield
            </span>
            <span className="text-xs px-2 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
              {match.property.appreciation}% Growth
            </span>
          </div>

          <div className="flex items-center gap-4 text-sm text-ink-muted mb-3">
            <span>Min: PKR {match.property.minInvestment.toLocaleString()}</span>
            <span>{fundedPct}% funded</span>
          </div>

          <div className="w-full bg-stroke-default/20 rounded-full h-1.5 mb-3">
            <div className="h-1.5 rounded-full bg-vest-g5 transition-all" style={{ width: `${match.percentMatch}%` }} />
          </div>

          <button onClick={onToggle} className="flex items-center gap-1 text-sm text-vest-g5 hover:text-vest-g6 transition-colors" data-testid={`match-expand-${rank}`}>
            {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            {expanded ? "Hide" : "Show"} Scoring Breakdown
          </button>

          <AnimatePresence>
            {expanded && (
              <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                <div className="mt-4 pt-4 border-t border-stroke-default/20 space-y-3" data-testid={`match-reasons-${rank}`}>
                  {match.reasons.map((r, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <div className="shrink-0 mt-0.5">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${r.score >= r.maxScore * 0.7 ? "bg-green-100 text-green-700" : r.score >= r.maxScore * 0.4 ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-700"}`}>
                          {r.score}
                        </div>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-ink-darkest">{r.factor} <span className="text-ink-muted font-normal">({r.score}/{r.maxScore})</span></p>
                        <p className="text-xs text-ink-muted">{r.detail}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </GlassCard>
  );
}
