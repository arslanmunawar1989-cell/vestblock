import { useState, useMemo } from "react";
import { Link } from "wouter";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { SectionHeader } from "@/components/marketing/section-header";
import { GlassButton } from "@/components/marketing/glass-button";
import { GlassCard } from "@/components/marketing/glass-card";
import { useRegion } from "@/lib/region";
import { motion, AnimatePresence } from "framer-motion";
import {
  MapPin, TrendingUp, ArrowRight, ArrowUpDown, Search,
  SlidersHorizontal, X, ChevronDown, Building2, Home,
  Store, Factory, Layers, Target, Sprout, Filter,
  Users, Shield, Calculator, DoorOpen, AlertTriangle,
} from "lucide-react";
import { useCmsProperties } from "@/hooks/use-cms-content";

import allProperties from "@/data/featured-properties.json";

type Property = (typeof allProperties)[number];

function mapCmsToProperty(cms: any): Property {
  return {
    id: cms.slug || cms.id,
    name: cms.name,
    city: cms.city,
    type: cms.propertyType,
    strategy: cms.strategy || "Income",
    status: "funding",
    minInvestment: Number(cms.minInvestment),
    totalRaised: Number(cms.fundingTarget || 0) * (cms.fundingProgressPercent || 0) / 100,
    targetRaise: Number(cms.fundingTarget || 0),
    tokenPrice: Number(cms.minInvestment),
    totalTokens: 10000,
    soldTokens: Math.round(10000 * (cms.fundingProgressPercent || 0) / 100),
    annualYield: Number(cms.expectedYield || 0),
    appreciation: 8.0,
    image: (cms.imagesJson as any)?.[0] || "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=600&h=400&fit=crop",
    listingDate: cms.createdAt?.split("T")[0] || "2026-01-01",
    location: `${cms.city}, Pakistan`,
  };
}

const CITIES = ["All", "Karachi", "Lahore", "Islamabad"] as const;
const TYPES = ["All", "Ready", "Rental", "Off-Plan"] as const;
const STRATEGIES = ["All", "Income", "Growth"] as const;

function getPropertyCategory(p: Property): string {
  if (p.strategy === "Growth") return "Off-Plan";
  if (["Commercial", "Retail", "Industrial"].includes(p.type)) return "Rental";
  return "Ready";
}
const SORTS = [
  { value: "yield-desc", label: "Highest Yield" },
  { value: "min-asc", label: "Lowest Min Investment" },
  { value: "progress-desc", label: "Funding Progress" },
  { value: "newest", label: "Newest Listed" },
] as const;

const typeIcons: Record<string, typeof Building2> = {
  Commercial: Building2,
  Residential: Home,
  "Mixed-Use": Layers,
  Retail: Store,
  Industrial: Factory,
};

function formatPKR(value: number) {
  if (value >= 10000000) return `PKR ${(value / 10000000).toFixed(1)}Cr`;
  if (value >= 100000) return `PKR ${(value / 100000).toFixed(0)}L`;
  return `PKR ${value.toLocaleString()}`;
}

const fadeUp = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } };
const stagger = { visible: { transition: { staggerChildren: 0.06 } } };

export default function PropertiesPage() {
  const { region } = useRegion();

  const { data: cmsProperties } = useCmsProperties("PK");
  const properties: Property[] = cmsProperties && cmsProperties.length > 0
    ? cmsProperties.map(mapCmsToProperty)
    : allProperties;

  const [city, setCity] = useState("All");
  const [type, setType] = useState("All");
  const [strategy, setStrategy] = useState("All");
  const [minInvestMax, setMinInvestMax] = useState(500000);
  const [yieldMin, setYieldMin] = useState(0);
  const [sortBy, setSortBy] = useState<string>("yield-desc");
  const [searchQuery, setSearchQuery] = useState("");
  const [filtersOpen, setFiltersOpen] = useState(false);

  const activeFilterCount = [
    city !== "All" ? 1 : 0,
    type !== "All" ? 1 : 0,
    strategy !== "All" ? 1 : 0,
    minInvestMax < 500000 ? 1 : 0,
    yieldMin > 0 ? 1 : 0,
  ].reduce((a, b) => a + b, 0);

  const filtered = useMemo(() => {
    let result = properties.filter((p) => {
      if (city !== "All" && p.city !== city) return false;
      if (type !== "All" && getPropertyCategory(p) !== type) return false;
      if (strategy !== "All" && p.strategy !== strategy) return false;
      if (p.minInvestment > minInvestMax) return false;
      if (p.annualYield < yieldMin) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        if (!p.name.toLowerCase().includes(q) && !p.city.toLowerCase().includes(q) && !p.location.toLowerCase().includes(q)) return false;
      }
      return true;
    });

    result = [...result].sort((a, b) => {
      switch (sortBy) {
        case "yield-desc": return b.annualYield - a.annualYield;
        case "min-asc": return a.minInvestment - b.minInvestment;
        case "progress-desc": return (b.soldTokens / b.totalTokens) - (a.soldTokens / a.totalTokens);
        case "newest": return new Date(b.listingDate).getTime() - new Date(a.listingDate).getTime();
        default: return 0;
      }
    });

    return result;
  }, [city, type, strategy, minInvestMax, yieldMin, sortBy, searchQuery, properties]);

  function clearFilters() {
    setCity("All");
    setType("All");
    setStrategy("All");
    setMinInvestMax(500000);
    setYieldMin(0);
    setSearchQuery("");
  }

  return (
    <MarketingLayout>
      <PageMeta title="Properties" description="Browse tokenized real estate properties across Pakistan. Invest in residential, commercial, and mixed-use properties with transparent pricing and verified valuations." path="/pk/properties" />
      {/* Hero */}
      <section className="pt-32 pb-12 px-4 relative" data-testid="properties-hero">
        <div className="absolute inset-0 pointer-events-none" style={{ background: "radial-gradient(ellipse 60% 40% at 50% 0%, rgba(30,43,255,0.06) 0%, transparent 70%)" }} />
        <div className="relative max-w-7xl mx-auto">
          <SectionHeader
            badge="Investment Marketplace"
            title="Explore Investment Opportunities in"
            highlight="Pakistan"
            description="Filter by city, strategy, type, minimum investment, and expected yield to find the right opportunity."
          />
          <div className="max-w-xl mx-auto relative" data-testid="properties-search">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-muted/70" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by property name, city, or area..."
              className="w-full pl-11 pr-10 py-3 text-sm rounded-2xl bg-white/50 border border-vest-g5/20 text-ink-dark placeholder:text-ink-muted/70 focus:outline-none focus:border-vest-g5/25 transition-colors"
              data-testid="search-input"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-muted/70 hover:text-ink-dark transition-colors" data-testid="search-clear">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </section>

      {/* Trust Signals */}
      <section className="px-4 pb-8" data-testid="properties-trust">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { icon: Users, val: "10,000+", label: "Verified Investors" },
              { icon: Building2, val: "45+", label: "Tokenized Properties" },
              { icon: Shield, val: "SECP", label: "Regulated Platform" },
              { icon: TrendingUp, val: "PKR 2B+", label: "Assets Under Mgmt" },
            ].map((s) => (
              <div key={s.label} className="glass-surface rounded-2xl p-3 flex items-center gap-3" data-testid={`trust-${s.label.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="w-9 h-9 rounded-xl flex items-center justify-center bg-vest-g5/10 shrink-0">
                  <s.icon className="w-4 h-4 text-vest-g5" />
                </div>
                <div>
                  <p className="text-sm font-bold text-ink-dark">{s.val}</p>
                  <p className="text-[10px] text-ink-muted/70">{s.label}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 mt-6">
            <Link href="/roi-calculator" className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-medium text-ink-muted bg-white/50 border border-vest-g5/15 hover:border-vest-g5/20 transition" data-testid="link-roi-calc">
                <Calculator className="w-3.5 h-3.5 text-vest-g5" /> Calculate Your Returns
            </Link>
            <Link href="/exit-windows" className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-medium text-ink-muted bg-white/50 border border-vest-g5/15 hover:border-vest-g5/20 transition" data-testid="link-exit-windows">
                <DoorOpen className="w-3.5 h-3.5 text-vest-g5" /> Exit Windows Schedule
            </Link>
            <Link href="/risk-warnings" className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-medium text-ink-muted bg-white/50 border border-vest-g5/15 hover:border-vest-g5/20 transition" data-testid="link-risk-warnings">
                <AlertTriangle className="w-3.5 h-3.5 text-yellow-400" /> Risk Warnings
            </Link>
          </div>
        </div>
      </section>

      {/* Filters + Grid */}
      <section className="py-8 px-4" data-testid="properties-listing">
        <div className="max-w-7xl mx-auto">
          {/* Top bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
            <div className="flex items-center gap-3 flex-wrap">
              <button
                onClick={() => setFiltersOpen(!filtersOpen)}
                className={`glass rounded-2xl px-4 py-2.5 text-sm inline-flex items-center gap-2 text-ink-dark transition-all duration-200 ${filtersOpen ? "border-vest-g5/25" : ""}`}
                data-testid="filter-toggle"
              >
                <SlidersHorizontal className="w-4 h-4" />
                Filters
                {activeFilterCount > 0 && (
                  <span className="w-5 h-5 rounded-full text-[10px] font-bold flex items-center justify-center bg-vest-g5 text-ink-dark" data-testid="filter-count">
                    {activeFilterCount}
                  </span>
                )}
              </button>
              {activeFilterCount > 0 && (
                <button onClick={clearFilters} className="text-xs text-ink-muted/70 hover:text-ink-dark transition-colors flex items-center gap-1" data-testid="clear-filters">
                  <X className="w-3 h-3" /> Clear all
                </button>
              )}
            </div>

            <div className="flex items-center gap-3 flex-wrap">
              <span className="text-xs text-ink-muted/70" data-testid="results-count">
                {filtered.length} {filtered.length === 1 ? "property" : "properties"}
              </span>
              <div className="relative">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="appearance-none pl-8 pr-8 py-2.5 text-xs rounded-2xl bg-white/50 border border-vest-g5/20 text-ink-dark focus:outline-none focus:border-vest-g5/25 cursor-pointer"
                  data-testid="sort-select"
                >
                  {SORTS.map((s) => (
                    <option key={s.value} value={s.value} className="bg-vest-g0/30 text-ink-dark">{s.label}</option>
                  ))}
                </select>
                <ArrowUpDown className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-ink-muted/70 pointer-events-none" />
                <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-ink-muted/70 pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Collapsible Filters Panel */}
          <AnimatePresence>
            {filtersOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden mb-8"
                data-testid="filters-panel"
              >
                <div className="glass-surface rounded-3xl p-6 space-y-5">
                  <div>
                    <label className="text-xs font-medium text-ink-muted mb-2.5 block">City</label>
                    <div className="flex flex-wrap gap-2">
                      {CITIES.map((c) => (
                        <FilterChip key={c} label={c} active={city === c} onClick={() => setCity(c)} testId={`filter-city-${c.toLowerCase()}`} />
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-medium text-ink-muted mb-2.5 block">Type</label>
                    <div className="flex flex-wrap gap-2">
                      {TYPES.map((t) => (
                        <FilterChip key={t} label={t} active={type === t} onClick={() => setType(t)} testId={`filter-type-${t.toLowerCase().replace(/\s+/g, "-")}`} />
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-medium text-ink-muted mb-2.5 block">Strategy</label>
                    <div className="flex flex-wrap gap-2">
                      {STRATEGIES.map((s) => (
                        <FilterChip key={s} label={s === "All" ? "All" : s} active={strategy === s} onClick={() => setStrategy(s)} testId={`filter-strategy-${s.toLowerCase()}`} />
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div>
                      <div className="flex items-center justify-between text-xs mb-2">
                        <span className="text-ink-muted font-medium">Minimum Investment (up to)</span>
                        <span className="text-ink-dark font-medium">{formatPKR(minInvestMax)}</span>
                      </div>
                      <input
                        type="range" min={25000} max={500000} step={25000} value={minInvestMax}
                        onChange={(e) => setMinInvestMax(Number(e.target.value))}
                        className="w-full h-1.5 rounded-full appearance-none cursor-pointer"
                        style={{ background: `linear-gradient(90deg, #1E2BFF ${((minInvestMax - 25000) / (500000 - 25000)) * 100}%, rgba(255,255,255,0.1) 0%)` }}
                        data-testid="filter-max-investment"
                      />
                      <div className="flex items-center justify-between text-[10px] text-ink-muted/70 mt-1">
                        <span>PKR 25K</span><span>PKR 5L</span>
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center justify-between text-xs mb-2">
                        <span className="text-ink-muted font-medium">Expected Yield</span>
                        <span className="text-ink-dark font-medium">{yieldMin}%</span>
                      </div>
                      <input
                        type="range" min={0} max={20} step={1} value={yieldMin}
                        onChange={(e) => setYieldMin(Number(e.target.value))}
                        className="w-full h-1.5 rounded-full appearance-none cursor-pointer"
                        style={{ background: `linear-gradient(90deg, #1E2BFF ${(yieldMin / 20) * 100}%, rgba(255,255,255,0.1) 0%)` }}
                        data-testid="filter-min-yield"
                      />
                      <div className="flex items-center justify-between text-[10px] text-ink-muted/70 mt-1">
                        <span>0%</span><span>20%+</span>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Property Grid */}
          {filtered.length === 0 ? (
            <div className="text-center py-20" data-testid="no-results">
              <Filter className="w-10 h-10 text-ink-muted mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-ink-dark mb-2">No Matching Properties</h3>
              <p className="text-sm text-ink-muted mb-5">No properties match your current filters. Adjust your criteria to explore other opportunities.</p>
              <GlassButton variant="secondary" onClick={clearFilters} data-testid="no-results-clear">
                Clear All Filters
              </GlassButton>
            </div>
          ) : (
            <motion.div
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5"
              initial="hidden" animate="visible" variants={stagger}
              key={`${city}-${type}-${strategy}-${sortBy}-${minInvestMax}-${yieldMin}-${searchQuery}`}
            >
              {filtered.map((property) => (
                <PropertyCard key={property.id} property={property} />
              ))}
            </motion.div>
          )}
        </div>
      </section>

      {/* Risk Disclaimer */}
      <section className="px-4 pb-8" data-testid="properties-risk-disclaimer">
        <div className="max-w-7xl mx-auto">
          <GlassCard className="ring-1 ring-yellow-500/20">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-4 h-4 text-yellow-400 mt-0.5 shrink-0" />
              <div className="text-[11px] text-ink-muted/70 leading-relaxed space-y-1.5">
                <p className="text-ink-muted font-medium">Important Risk Warning</p>
                <p>Tokenized real estate investments carry risk, including the potential loss of your entire investment. Past performance and projected yields are not indicative of future results. All properties undergo independent valuation by certified Pakistani surveyors, but valuations are estimates and may not reflect the price achievable in a sale.</p>
                <p>VestBlock is regulated by the Securities and Exchange Commission of Pakistan (SECP). This platform does not provide financial, legal, or tax advice. Please read our <Link href="/risk-warnings" className="text-vest-g5 hover:underline">Risk Warnings</Link> and <Link href="/risk-disclosure" className="text-vest-g5 hover:underline">Risk Disclosure</Link> before investing.</p>
              </div>
            </div>
          </GlassCard>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-4 relative" data-testid="properties-cta">
        <div className="absolute inset-0 pointer-events-none" style={{ background: "radial-gradient(ellipse 70% 50% at 50% 50%, rgba(30,43,255,0.04) 0%, transparent 70%)" }} />
        <div className="relative max-w-3xl mx-auto text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark mb-4">
            Don't See What You're <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Looking For?</span>
          </h2>
          <p className="text-ink-muted text-base mb-8 leading-relaxed">
            New properties are listed weekly. Create an account to receive alerts for upcoming opportunities.
          </p>
          <GlassButton onClick={() => { window.location.href = "/register"; }} data-testid="properties-cta-register">
            Get Early Access <ArrowRight className="w-4 h-4" />
          </GlassButton>
        </div>
      </section>
    </MarketingLayout>
  );
}

function FilterChip({ label, active, onClick, testId }: { label: string; active: boolean; onClick: () => void; testId: string }) {
  return (
    <button
      onClick={onClick}
      className={`px-3.5 py-1.5 rounded-2xl text-xs font-medium transition-all duration-300 backdrop-blur-md ${
        active
          ? "text-vest-g5 border border-vest-g5/25 shadow-inner"
          : "text-ink-muted border border-white/10 hover:border-vest-g5/20 hover:text-ink-dark"
      }`}
      style={active ? { background: "linear-gradient(135deg, rgba(30,43,255,0.12) 0%, rgba(255,255,255,0.06) 100%)" } : { background: "rgba(255,255,255,0.04)" }}
      data-testid={testId}
    >
      {label}
    </button>
  );
}

function PropertyCard({ property }: { property: Property }) {
  const pct = Math.round((property.soldTokens / property.totalTokens) * 100);
  const TypeIcon = typeIcons[property.type] || Building2;
  const category = getPropertyCategory(property);
  const isGrowth = property.strategy === "Growth";

  return (
    <motion.div
      variants={fadeUp}
      transition={{ duration: 0.4 }}
      className="glass-surface rounded-3xl overflow-hidden transition-all duration-300 hover:border-vest-g5/25 flex flex-col group"
      data-testid={`property-card-${property.id}`}
    >
      <div className="relative h-48 overflow-hidden" data-testid={`property-image-${property.id}`}>
        <img
          src={property.image}
          alt={property.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#050B1A]/90 via-[#050B1A]/20 to-transparent" />
        <div className="absolute top-3 left-3 flex items-center gap-1.5">
          <span className="px-2.5 py-1 rounded-xl text-[10px] font-semibold bg-black/50 text-white backdrop-blur-sm flex items-center gap-1">
            <TypeIcon className="w-3 h-3" /> {category}
          </span>
        </div>
        <div className="absolute top-3 right-3">
          <span className={`px-2.5 py-1 rounded-xl text-[10px] font-semibold backdrop-blur-sm flex items-center gap-1 ${
            isGrowth ? "bg-vest-g5/20 text-white border border-vest-g5/30" : "bg-vest-g0/40 text-white border border-vest-g5/20"
          }`}>
            {isGrowth ? <Sprout className="w-3 h-3" /> : <Target className="w-3 h-3" />}
            {isGrowth ? "Growth" : "Income"}
          </span>
        </div>
        <div className="absolute bottom-3 left-3">
          <span className="flex items-center gap-1 text-xs text-ink-dark/80">
            <MapPin className="w-3 h-3" /> {property.location}
          </span>
        </div>
      </div>

      <div className="p-5 flex flex-col flex-1">
        <h3 className="text-base font-semibold text-ink-dark mb-3 leading-snug" data-testid={`property-name-${property.id}`}>
          {property.name}
        </h3>

        <div className="grid grid-cols-2 gap-x-4 gap-y-3 mb-4">
          <StatCell label="Min Investment" value={`PKR ${property.minInvestment.toLocaleString()}`} testId={`min-invest-${property.id}`} />
          <StatCell label="Token Price" value={`PKR ${property.tokenPrice.toLocaleString()}`} />
          <StatCell label="Annual Yield" value={`${property.annualYield}%`} accent testId={`yield-${property.id}`} icon={<TrendingUp className="w-3 h-3" />} />
          <StatCell label="Appreciation" value={`${property.appreciation}%`} />
        </div>

        <div className="mt-auto">
          <div className="flex items-center justify-between text-[11px] mb-1.5">
            <span className="text-ink-muted/70">{formatPKR(property.totalRaised)} raised</span>
            <span className="text-ink-muted font-medium">{pct}%</span>
          </div>
          <div className="h-1.5 w-full rounded-full bg-white/50" data-testid={`progress-${property.id}`}>
            <div className="h-1.5 rounded-full bg-vest-g5 shadow-glassGlow transition-all duration-500" style={{ width: `${pct}%` }} />
          </div>
          <div className="flex items-center justify-between text-[10px] text-ink-muted mt-1.5">
            <span>{property.soldTokens.toLocaleString()} / {property.totalTokens.toLocaleString()} tokens</span>
            <span>Target: {formatPKR(property.targetRaise)}</span>
          </div>
        </div>

        <Link href={`/properties/${property.id}`} className="mt-4 flex items-center justify-center gap-2 w-full py-2.5 text-sm font-semibold rounded-2xl border border-vest-g5/20 text-ink-dark transition-all duration-200 hover:border-vest-g5/25 hover:text-ink-dark bg-white/40" data-testid={`view-details-${property.id}`}>
            View Details <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>
    </motion.div>
  );
}

function StatCell({ label, value, accent, icon, testId }: { label: string; value: string; accent?: boolean; icon?: React.ReactNode; testId?: string }) {
  return (
    <div className="text-xs">
      <span className="text-ink-muted/70 block mb-0.5">{label}</span>
      <span className={`font-semibold flex items-center gap-0.5 ${accent ? "text-vest-g5" : "text-ink-dark"}`} data-testid={testId}>
        {icon}{value}
      </span>
    </div>
  );
}
