import { MarketingLayout } from "@/components/marketing/layout";
import { MarketingHero } from "@/components/marketing/marketing-hero";
import { GlassCard } from "@/components/marketing/glass-card";
import { CtaSection } from "@/components/marketing/cta-section";
import { ComplianceDisclaimer } from "@/components/marketing/compliance-disclaimer";
import { PageMeta } from "@/components/marketing/page-meta";
import { motion } from "framer-motion";
import {
  Landmark, Users, Banknote, BarChart3, FileCheck, ShieldCheck,
  CheckCircle2, Layers, Building2, Globe,
} from "lucide-react";

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const benefits = [
  { icon: Banknote, title: "Alternative Funding", desc: "Raise capital from 10,000+ investors in tranches. Supplement bank financing with tokenized equity without diluting project control." },
  { icon: Users, title: "Investor Access", desc: "Pre-sell units to retail and institutional investors. Build a waitlist of token holders who are financially committed to your project." },
  { icon: BarChart3, title: "Transparent Reporting", desc: "Automated investor reporting dashboards. Share construction progress, financial updates, and distribution schedules in real time." },
  { icon: ShieldCheck, title: "Regulatory Compliance", desc: "VestBlock handles SPV structuring, SECP filings, and investor KYC/AML. Your legal exposure is minimized." },
  { icon: Globe, title: "Diaspora Reach", desc: "Access overseas Pakistani investors in UAE, UK, US, and Canada who want exposure to domestic real estate." },
  { icon: Layers, title: "Flexible Structures", desc: "Choose from SPV, Fund, REIT, or Trust structures. Tailor the investment vehicle to your project's needs." },
];

const projectTypes = [
  "Multi-storey residential towers",
  "Gated housing communities (DHA, Bahria, etc.)",
  "Commercial plazas and malls",
  "Mixed-use developments",
  "Hospitality and hotel projects",
  "Industrial and logistics parks",
];

const process = [
  { step: "1", title: "Proposal", desc: "Share your project master plan, approvals (NOC, LDA/CDA), financials, and funding requirements." },
  { step: "2", title: "Due Diligence", desc: "VestBlock reviews approvals, developer track record, project feasibility, and legal standing." },
  { step: "3", title: "Structuring", desc: "We create the investment vehicle (SPV/Fund), set token economics, and prepare SECP-compliant offering documents." },
  { step: "4", title: "Capital Raise", desc: "Tokens go live. Investors subscribe in tranches aligned with your construction milestones." },
];

const stats = [
  { value: "PKR 2B+", label: "Capital Raised" },
  { value: "12+", label: "Developer Partners" },
  { value: "45+", label: "Projects Tokenized" },
  { value: "4", label: "Cities" },
];

export default function ForDevelopersPage() {
  return (
    <MarketingLayout>
      <PageMeta
        title="For Property Developers"
        description="Raise capital for your real estate projects through tokenization. Access 10,000+ investors, flexible structures, and full regulatory compliance via VestBlock."
        path="/pk/for-developers"
      />

      <MarketingHero
        badge="For Developers"
        title="Fund Your Projects with"
        highlight="Tokenized Capital"
        subtitle="Raise capital from 10,000+ investors through tokenized equity. Supplement bank financing, pre-sell units, and access diaspora capital — all with full SECP compliance."
        testIdPrefix="for-developers"
      />

      <section className="py-12 px-4" data-testid="dev-stats-section">
        <div className="max-w-4xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map((s) => (
            <GlassCard key={s.label} className="text-center">
              <div className="text-2xl font-bold bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent mb-1">{s.value}</div>
              <div className="text-xs text-ink-muted/70">{s.label}</div>
            </GlassCard>
          ))}
        </div>
      </section>

      <section className="py-16 px-4" data-testid="dev-benefits-section">
        <div className="max-w-5xl mx-auto">
          <motion.div className="text-center mb-12" initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.h2 variants={fadeUp} transition={{ duration: 0.5 }} className="text-3xl sm:text-4xl font-bold text-ink-dark">
              Why Tokenize with <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">VestBlock?</span>
            </motion.h2>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {benefits.map((b) => (
              <GlassCard key={b.title} data-testid={`dev-benefit-${b.title.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-4 bg-vest-g5/10">
                  <b.icon className="w-5 h-5 text-vest-g5" />
                </div>
                <h3 className="text-lg font-semibold text-ink-dark mb-2">{b.title}</h3>
                <p className="text-sm text-ink-muted/70 leading-relaxed">{b.desc}</p>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-4" data-testid="dev-process-section">
        <div className="max-w-4xl mx-auto">
          <motion.div className="text-center mb-12" initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.h2 variants={fadeUp} transition={{ duration: 0.5 }} className="text-3xl sm:text-4xl font-bold text-ink-dark">
              How It <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Works</span>
            </motion.h2>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {process.map((s) => (
              <GlassCard key={s.step} className="text-center" data-testid={`dev-step-${s.step}`}>
                <div className="w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-3 bg-vest-g5/10 text-vest-g5 font-bold">{s.step}</div>
                <h4 className="text-base font-semibold text-ink-dark mb-1">{s.title}</h4>
                <p className="text-sm text-ink-muted/70">{s.desc}</p>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-4" data-testid="dev-project-types">
        <div className="max-w-3xl mx-auto">
          <motion.div className="text-center mb-10" initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.h2 variants={fadeUp} transition={{ duration: 0.5 }} className="text-3xl sm:text-4xl font-bold text-ink-dark">
              Eligible <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Project Types</span>
            </motion.h2>
          </motion.div>
          <GlassCard>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {projectTypes.map((t) => (
                <div key={t} className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-vest-g5 shrink-0" />
                  <span className="text-sm text-ink-muted">{t}</span>
                </div>
              ))}
            </div>
            <p className="text-xs text-ink-muted mt-4">Minimum project value: PKR 100 million. Projects must have all required regulatory approvals (NOC, building plan approval).</p>
          </GlassCard>
        </div>
      </section>

      <div className="max-w-3xl mx-auto px-4 mb-8">
        <ComplianceDisclaimer
          variant="regulatory"
          title="Developer Requirements"
          text="Developers must provide valid NOC, building plan approvals, company registration, financial statements, and track record documentation. All projects undergo independent feasibility assessment and legal review before listing on the VestBlock platform."
          testId="dev-compliance"
        />
      </div>

      <CtaSection
        icon={Landmark}
        title="Ready to Tokenize Your"
        highlight="Project?"
        subtitle="Submit your project proposal and our team will evaluate it within 5 business days."
        actions={[
          { label: "Submit Proposal", href: "/contact" },
          { label: "View Properties", href: "/properties", variant: "secondary" },
        ]}
        testId="dev-cta"
      />
    </MarketingLayout>
  );
}
