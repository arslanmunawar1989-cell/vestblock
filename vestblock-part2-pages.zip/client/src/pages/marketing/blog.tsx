import { useState, useMemo } from "react";
import { Link } from "wouter";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { GlassCard } from "@/components/marketing/glass-card";
import { CtaSection } from "@/components/marketing/cta-section";
import { motion } from "framer-motion";
import {
  Search, Calendar, Clock, ArrowRight, Tag, BookOpen,
  TrendingUp, ShieldCheck, BarChart3, ChevronRight,
} from "lucide-react";
import { useCmsBlogPosts } from "@/hooks/use-cms-content";
import blogPostsJson from "@/data/blog-posts.json";

type BlogPost = (typeof blogPostsJson)[number];

function mapCmsToBlogPost(cms: any): BlogPost {
  return {
    slug: cms.slug,
    title: cms.title,
    subtitle: cms.excerpt || "",
    category: cms.category || "Education",
    date: cms.publishedAt || cms.createdAt,
    readTime: Math.ceil((cms.contentHtml?.length || 500) / 200),
    author: "VestBlock Research",
    featured: false,
    tags: cms.tagsJson || [],
    sections: cms.contentHtml ? [{ heading: "", body: cms.contentHtml }] : [],
  };
}

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const categories = ["All", "Education", "Market Analysis", "Risk & Compliance"] as const;

const categoryConfig: Record<string, { icon: typeof BookOpen; accent: string; bg: string; border: string }> = {
  Education: { icon: BookOpen, accent: "text-vest-g5", bg: "bg-vest-g5/10", border: "border-vest-g5/20" },
  "Market Analysis": { icon: BarChart3, accent: "text-emerald-400", bg: "bg-emerald-400/10", border: "border-emerald-400/20" },
  "Risk & Compliance": { icon: ShieldCheck, accent: "text-amber-400", bg: "bg-amber-400/10", border: "border-amber-400/20" },
};

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-PK", { day: "numeric", month: "short", year: "numeric" });
}

export default function BlogPage() {
  const { data: cmsBlogPosts } = useCmsBlogPosts("PK");
  const blogPosts: BlogPost[] = cmsBlogPosts && cmsBlogPosts.length > 0
    ? cmsBlogPosts.map(mapCmsToBlogPost)
    : blogPostsJson;

  const [activeCategory, setActiveCategory] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState("");

  const filtered = useMemo(() => {
    let result = blogPosts;
    if (activeCategory !== "All") {
      result = result.filter((p) => p.category === activeCategory);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.subtitle.toLowerCase().includes(q) ||
          p.tags.some((t) => t.toLowerCase().includes(q))
      );
    }
    return result;
  }, [activeCategory, searchQuery, blogPosts]);

  const featured = blogPosts.filter((p) => p.featured).slice(0, 3);

  return (
    <MarketingLayout>
      <PageMeta title="Blog & Insights" description="Latest news, market analysis, and educational content about tokenized real estate investing in Pakistan from the VestBlock team." path="/pk/blog" />
      <section className="relative py-24 sm:py-32 px-4 overflow-hidden" data-testid="blog-hero">
        <div className="absolute inset-0 bg-gradient-to-b from-vest-g5/5 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div variants={fadeUp} initial="hidden" animate="visible">
            <span className="inline-flex items-center px-3.5 py-1.5 rounded-2xl text-xs font-medium mb-6 text-vest-g5 bg-vest-g5/10 border border-vest-g5/20" data-testid="blog-badge">
              Blog & Insights
            </span>
            <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-5 tracking-tight" data-testid="blog-headline">
              Insights for Smarter
              <br />Real Estate <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Investment</span>
            </h1>
            <p className="text-base sm:text-lg text-ink-muted max-w-2xl mx-auto leading-relaxed" data-testid="blog-subtext">
              Pakistan-focused analysis, educational guides, and market commentary to help you make informed investment decisions.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="px-4 pb-12" data-testid="blog-search-section">
        <div className="max-w-4xl mx-auto">
          <div className="relative mb-6">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-muted/70" />
            <input
              type="text"
              placeholder="Search articles by title, topic, or keyword..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-11 pr-4 py-3.5 rounded-2xl bg-white/50 border border-vest-g5/15 text-sm text-ink-dark placeholder:text-ink-muted focus:outline-none focus:border-vest-g5/40 transition-colors"
              data-testid="blog-search-input"
            />
          </div>
          <div className="flex flex-wrap items-center gap-2" data-testid="blog-filters">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3.5 py-2 rounded-xl text-xs font-medium transition-all ${
                  activeCategory === cat
                    ? "text-ink-dark bg-vest-g5 border border-vest-g5/40"
                    : "text-ink-muted bg-white/50 border border-vest-g5/15 hover:border-vest-g5/20"
                }`}
                data-testid={`filter-${cat.toLowerCase().replace(/\s+/g, "-")}`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      {!searchQuery && activeCategory === "All" && (
        <section className="px-4 pb-16" data-testid="blog-featured">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-lg font-semibold text-ink-muted mb-5">Featured</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {featured.map((post, i) => {
                const cfg = categoryConfig[post.category] || categoryConfig.Education;
                return (
                  <motion.div key={post.slug} variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} transition={{ delay: i * 0.05 }}>
                    <Link href={`/blog/${post.slug}`} className="block h-full" data-testid={`featured-${post.slug}`}>
                      <GlassCard className="h-full border border-vest-g5/15 hover:border-vest-g5/30 transition-colors cursor-pointer group">
                        <div className="flex items-center gap-2 mb-3">
                          <span className={`px-2.5 py-1 rounded-xl text-[10px] font-bold ${cfg.accent} ${cfg.bg} border ${cfg.border}`}>{post.category}</span>
                        </div>
                        <h3 className="text-sm font-semibold text-ink-dark leading-snug mb-2 group-hover:text-vest-g5 transition-colors">{post.title}</h3>
                        <p className="text-xs text-ink-muted/70 leading-relaxed mb-3 line-clamp-2">{post.subtitle}</p>
                        <div className="flex items-center gap-3 text-[10px] text-ink-muted">
                          <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {formatDate(post.date)}</span>
                          <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {post.readTime} min</span>
                        </div>
                      </GlassCard>
                    </Link>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>
      )}

      <section className="px-4 pb-20" data-testid="blog-listing">
        <div className="max-w-4xl mx-auto">
          {!searchQuery && activeCategory === "All" && (
            <h2 className="text-lg font-semibold text-ink-muted mb-5">All Articles</h2>
          )}
          {searchQuery && (
            <p className="text-sm text-ink-muted/70 mb-5" data-testid="blog-search-count">{filtered.length} result{filtered.length !== 1 ? "s" : ""} for "{searchQuery}"</p>
          )}

          {filtered.length === 0 ? (
            <GlassCard className="text-center py-12" data-testid="blog-no-results">
              <Search className="w-8 h-8 text-ink-muted mx-auto mb-3" />
              <p className="text-sm text-ink-muted mb-1">No articles found</p>
              <p className="text-xs text-ink-muted">Try a different search term or category.</p>
            </GlassCard>
          ) : (
            <div className="space-y-3">
              {filtered.map((post, i) => {
                const cfg = categoryConfig[post.category] || categoryConfig.Education;
                return (
                  <motion.div key={post.slug} variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} transition={{ delay: i * 0.02 }}>
                    <Link href={`/blog/${post.slug}`} className="block" data-testid={`blog-card-${post.slug}`}>
                      <GlassCard className="hover:border-vest-g5/20 transition-colors cursor-pointer group p-5">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-2 flex-wrap">
                              <span className={`px-2.5 py-1 rounded-xl text-[10px] font-bold ${cfg.accent} ${cfg.bg} border ${cfg.border}`}>{post.category}</span>
                              <span className="text-[10px] text-ink-muted flex items-center gap-1"><Calendar className="w-3 h-3" /> {formatDate(post.date)}</span>
                              <span className="text-[10px] text-ink-muted flex items-center gap-1"><Clock className="w-3 h-3" /> {post.readTime} min read</span>
                            </div>
                            <h3 className="text-base font-semibold text-ink-dark leading-snug mb-1.5 group-hover:text-vest-g5 transition-colors">{post.title}</h3>
                            <p className="text-xs text-ink-muted/70 leading-relaxed line-clamp-2">{post.subtitle}</p>
                            <div className="flex items-center gap-1.5 mt-3 flex-wrap">
                              {post.tags.slice(0, 4).map((tag) => (
                                <span key={tag} className="px-2 py-0.5 rounded-lg text-[10px] text-ink-muted bg-white/40 border border-vest-g5/15">{tag}</span>
                              ))}
                            </div>
                          </div>
                          <ChevronRight className="w-4 h-4 text-ink-muted shrink-0 mt-1 group-hover:text-vest-g5 transition-colors" />
                        </div>
                      </GlassCard>
                    </Link>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      <CtaSection
        title="Ready to"
        highlight="Invest?"
        subtitle="Put your knowledge into action. Browse verified properties and start building your real estate portfolio."
        actions={[
          { label: "Browse Properties", href: "/properties" },
          { label: "Read Guides", href: "/guides", variant: "secondary" },
        ]}
        testId="blog-cta"
      />
    </MarketingLayout>
  );
}
