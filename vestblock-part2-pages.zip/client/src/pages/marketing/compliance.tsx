import { Link } from "wouter";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { SectionHeader } from "@/components/marketing/section-header";
import { CtaSection } from "@/components/marketing/cta-section";
import {
  ShieldCheck,
  FileText,
  Scale,
  UserCheck,
  Search,
  AlertTriangle,
  Lock,
  Database,
  Eye,
  Wallet,
  ClipboardCheck,
  BadgeCheck,
  ArrowRight,
  CheckCircle2,
  Building2,
  Shield,
} from "lucide-react";

const regulatoryFramework = [
  {
    icon: Scale,
    title: "SECP Securities Act 2015",
    desc: "VestBlock operates under the Securities Act 2015, ensuring all tokenized assets are issued as regulated securities. This provides full legal standing for digital property tokens and investor protection under Pakistan's securities law.",
    highlights: ["Regulated securities issuance", "Investor protection framework", "Market conduct rules"],
  },
  {
    icon: Building2,
    title: "Companies Act 2017",
    desc: "All Special Purpose Vehicles (SPVs) are incorporated under the Companies Act 2017 with proper corporate governance structures, independent directors, and transparent reporting obligations.",
    highlights: ["SPV corporate governance", "Director fiduciary duties", "Annual audited financials"],
  },
  {
    icon: ShieldCheck,
    title: "SECP Digital Assets Framework",
    desc: "Compliance with SECP's evolving framework for digital asset custody, tokenization standards, and smart contract governance specific to Pakistan's regulatory environment.",
    highlights: ["Digital custody standards", "Token issuance guidelines", "Smart contract compliance"],
  },
];

const kycProcess = [
  {
    step: "01",
    icon: UserCheck,
    title: "NADRA Verification",
    desc: "Real-time identity verification through Pakistan's National Database and Registration Authority (NADRA). CNIC-based biometric and data verification ensures authentic investor identities.",
  },
  {
    step: "02",
    icon: Search,
    title: "PEP Screening",
    desc: "All investors are screened against Politically Exposed Persons (PEP) databases, both domestic and international. Enhanced due diligence applied for high-risk profiles.",
  },
  {
    step: "03",
    icon: AlertTriangle,
    title: "Sanctions Check",
    desc: "Comprehensive screening against UNSC, OFAC, EU, and Pakistan's National Counter-Terrorism Authority (NACTA) sanctions lists. Continuous monitoring for ongoing compliance.",
  },
  {
    step: "04",
    icon: Eye,
    title: "Ongoing Monitoring",
    desc: "Continuous transaction monitoring using AI-powered risk scoring. Suspicious Activity Reports (SARs) filed with Financial Monitoring Unit (FMU) as required by law.",
  },
];

const dataProtection = [
  { icon: Lock, title: "End-to-End Encryption", desc: "All data encrypted in transit (TLS 1.3) and at rest (AES-256). Hardware Security Modules (HSMs) protect cryptographic keys." },
  { icon: Database, title: "Data Residency", desc: "Investor data stored in Pakistan-based data centers compliant with local data sovereignty requirements and the Personal Data Protection Bill." },
  { icon: Eye, title: "Privacy by Design", desc: "Data minimization principles applied throughout. Only necessary data collected, with clear retention policies and right to deletion." },
  { icon: FileText, title: "Personal Data Protection Bill", desc: "Full alignment with Pakistan's evolving Personal Data Protection Bill, ensuring consent-based data processing and transparent data usage." },
];

const investorProtections = [
  {
    icon: Wallet,
    title: "Segregated Accounts",
    desc: "Investor funds held in segregated trust accounts separate from VestBlock's operational accounts. Full ring-fencing ensures your capital is protected even in worst-case scenarios.",
  },
  {
    icon: ClipboardCheck,
    title: "Independent Audits",
    desc: "Annual independent audits by Big Four firms. Quarterly property valuations by RICS-certified valuers. All reports available to investors through the data room.",
  },
  {
    icon: Shield,
    title: "Insurance Coverage",
    desc: "Comprehensive insurance coverage including professional indemnity, directors & officers liability, cyber insurance, and property insurance for all tokenized assets.",
  },
];

const certifications = [
  {
    title: "ISO 27001",
    desc: "Information Security Management System certification ensuring systematic management of sensitive data and security risks.",
    status: "Certified",
  },
  {
    title: "PCI DSS",
    desc: "Payment Card Industry Data Security Standard compliance for secure handling of payment card information and financial transactions.",
    status: "Compliant",
  },
  {
    title: "SOC 2 Type II",
    desc: "Service Organization Control audit verifying security, availability, processing integrity, confidentiality, and privacy controls.",
    status: "Certified",
  },
  {
    title: "FATF Compliance",
    desc: "Full adherence to Financial Action Task Force standards for anti-money laundering and counter-terrorism financing measures.",
    status: "Compliant",
  },
  {
    title: "GDPR Ready",
    desc: "Processes aligned with EU General Data Protection Regulation standards for international investor data protection.",
    status: "Aligned",
  },
  {
    title: "ISO 22301",
    desc: "Business Continuity Management certification ensuring operational resilience and disaster recovery capabilities.",
    status: "Certified",
  },
];

export default function CompliancePage() {
  return (
    <MarketingLayout>
      <PageMeta title="Compliance & Regulation" description="VestBlock's regulatory framework, SECP licensing, KYC/AML procedures, and commitment to investor protection under Pakistani securities law." path="/pk/compliance" />
      <section className="relative overflow-hidden py-24 sm:py-32 px-4" data-testid="compliance-hero">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium mb-6 text-vest-g5 border border-vest-g5/15" data-testid="compliance-badge">
            Compliance & Security
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-6" data-testid="compliance-headline">
            Compliance First,{" "}
            <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Always</span>
          </h1>
          <p className="text-lg sm:text-xl text-ink-muted max-w-2xl mx-auto mb-10 leading-relaxed" data-testid="compliance-subtext">
            VestBlock is built on a foundation of regulatory compliance, data security, and investor protection. Every aspect of our platform meets the highest standards required by Pakistani and international regulators.
          </p>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="regulatory-framework-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Regulatory"
            title="Legal &"
            highlight="Regulatory Framework"
            description="VestBlock operates under Pakistan's comprehensive securities and corporate law framework, ensuring full legal compliance."
          />
          <div className="space-y-6">
            {regulatoryFramework.map((item) => (
              <div key={item.title} className="glass rounded-md p-8  transition-all duration-300" data-testid={`regulatory-${item.title.toLowerCase().replace(/[\s/]+/g, "-")}`}>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-md flex items-center justify-center shrink-0" style={{ background: "rgba(30,43,255,0.08)" }}>
                    <item.icon className="w-6 h-6 text-vest-g5" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-ink-dark mb-2">{item.title}</h3>
                    <p className="text-ink-muted text-sm leading-relaxed mb-4">{item.desc}</p>
                    <div className="flex flex-wrap gap-3">
                      {item.highlights.map((h) => (
                        <span key={h} className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium text-vest-g5 border border-vest-g5/15">
                          <CheckCircle2 className="w-3 h-3" /> {h}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4 " data-testid="kyc-aml-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="KYC / AML"
            title="Know Your Customer &"
            highlight="Anti-Money Laundering"
            description="Our rigorous KYC/AML process ensures only verified investors access the platform, protecting all stakeholders."
          />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {kycProcess.map((item) => (
              <div key={item.title} className="glass rounded-md p-6  transition-all duration-300" data-testid={`kyc-step-${item.step}`}>
                <div className="flex items-start gap-4">
                  <div className="flex items-center justify-center shrink-0">
                    <span className="text-3xl font-bold text-vest-g5">{item.step}</span>
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <item.icon className="w-5 h-5 text-vest-g5" />
                      <h3 className="text-lg font-bold text-ink-dark">{item.title}</h3>
                    </div>
                    <p className="text-ink-muted text-sm leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="data-protection-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Data Security"
            title="Data"
            highlight="Protection"
            description="Your data is protected by enterprise-grade security measures aligned with Pakistan's Personal Data Protection Bill."
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {dataProtection.map((item) => (
              <div key={item.title} className="glass rounded-md p-6  transition-all duration-300" data-testid={`data-protection-${item.title.toLowerCase().replace(/[\s-]+/g, "-")}`}>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-md flex items-center justify-center shrink-0" style={{ background: "rgba(30,43,255,0.08)" }}>
                    <item.icon className="w-5 h-5 text-vest-g5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-ink-dark mb-2">{item.title}</h3>
                    <p className="text-ink-muted text-sm leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4 " data-testid="investor-protections-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Investor Safety"
            title="Investor"
            highlight="Protections"
            description="Multiple layers of protection ensure your investments are safe, audited, and insured."
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {investorProtections.map((item) => (
              <div key={item.title} className="glass rounded-md p-8  transition-all duration-300 text-center" data-testid={`protection-${item.title.toLowerCase().replace(/[\s&]+/g, "-")}`}>
                <div className="w-14 h-14 rounded-md flex items-center justify-center mx-auto mb-5" style={{ background: "rgba(30,43,255,0.08)" }}>
                  <item.icon className="w-7 h-7 text-vest-g5" />
                </div>
                <h3 className="text-lg font-bold text-ink-dark mb-3">{item.title}</h3>
                <p className="text-ink-muted text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="certifications-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Certifications"
            title="Industry"
            highlight="Certifications"
            description="VestBlock holds leading international security and compliance certifications."
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {certifications.map((cert) => (
              <div key={cert.title} className="glass rounded-md p-6  transition-all duration-300" data-testid={`cert-${cert.title.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <BadgeCheck className="w-5 h-5 text-vest-g5" />
                    <h3 className="text-lg font-bold text-ink-dark">{cert.title}</h3>
                  </div>
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium text-vest-g5 border border-vest-g5/15" data-testid={`cert-status-${cert.title.toLowerCase().replace(/\s+/g, "-")}`}>
                    {cert.status}
                  </span>
                </div>
                <p className="text-ink-muted text-sm leading-relaxed">{cert.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CtaSection
        title="Invest with"
        highlight="Confidence"
        subtitle="Your investments are protected by Pakistan's regulatory framework, international certifications, and institutional-grade security infrastructure."
        actions={[
          { label: "Start Investing Securely", href: "/register" },
          { label: "For Institutions", href: "/institutions", variant: "secondary" },
        ]}
        testId="compliance-cta"
      />
    </MarketingLayout>
  );
}
