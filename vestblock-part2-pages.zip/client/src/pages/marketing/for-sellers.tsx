import { MarketingLayout } from "@/components/marketing/layout";
import { MarketingHero } from "@/components/marketing/marketing-hero";
import { GlassCard } from "@/components/marketing/glass-card";
import { CtaSection } from "@/components/marketing/cta-section";
import { ComplianceDisclaimer } from "@/components/marketing/compliance-disclaimer";
import { PageMeta } from "@/components/marketing/page-meta";
import { motion } from "framer-motion";
import {
  Building2, Users, Banknote, Clock, ShieldCheck, Globe,
  CheckCircle2, FileCheck, ArrowRight, TrendingUp,
} from "lucide-react";

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const benefits = [
  { icon: Users, title: "Access 10,000+ Investors", desc: "Tap into VestBlock's verified investor base. Sell fractional ownership to thousands of qualified buyers instead of waiting for a single buyer." },
  { icon: Banknote, title: "Faster Liquidity", desc: "Tokenize your property and begin selling fractions within weeks. No need to wait months for a single full-price buyer." },
  { icon: TrendingUp, title: "Premium Valuations", desc: "Institutional-grade valuations by certified valuers. Properties listed at fair market value with transparent pricing." },
  { icon: ShieldCheck, title: "Full Legal Support", desc: "Our legal team handles SPV structuring, title verification, and SECP compliance. You sell — we manage the legal complexity." },
  { icon: Globe, title: "Global Exposure", desc: "Your property is marketed to local and diaspora investors across Pakistan, UAE, UK, and North America." },
  { icon: Clock, title: "Ongoing Revenue Share", desc: "Optionally retain a portion of the property and earn from rental distributions alongside investors." },
];

const propertyTypes = [
  "Residential apartments and villas",
  "Commercial office spaces",
  "Retail and shopping plazas",
  "Mixed-use developments",
  "Warehouse and logistics facilities",
  "Hospitality and serviced apartments",
];

const process = [
  { step: "1", title: "Submit Property", desc: "Share property details, title documents, and valuation information through our secure portal." },
  { step: "2", title: "Due Diligence", desc: "VestBlock conducts legal title verification, independent valuation, and structural assessment." },
  { step: "3", title: "SPV & Tokenization", desc: "We structure an SPV, create property tokens, and prepare offering documents for SECP compliance." },
  { step: "4", title: "Listing & Sale", desc: "Property goes live on the marketplace. Investors purchase tokens. You receive proceeds to your bank account." },
];

export default function ForSellersPage() {
  return (
    <MarketingLayout>
      <PageMeta
        title="For Property Sellers"
        description="Sell your property to 10,000+ investors through tokenization. Faster liquidity, premium valuations, full legal support, and global exposure via VestBlock."
        path="/pk/for-sellers"
      />

      <MarketingHero
        badge="For Sellers"
        title="Sell Your Property to"
        highlight="Thousands of Investors"
        subtitle="Tokenize your property and sell fractional ownership to VestBlock's 10,000+ verified investor base. Faster liquidity, premium valuations, and full legal support."
        testIdPrefix="for-sellers"
      />

      <section className="py-16 px-4" data-testid="seller-benefits-section">
        <div className="max-w-5xl mx-auto">
          <motion.div className="text-center mb-12" initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.h2 variants={fadeUp} transition={{ duration: 0.5 }} className="text-3xl sm:text-4xl font-bold text-ink-dark">
              Why Sell on <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">VestBlock?</span>
            </motion.h2>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {benefits.map((b) => (
              <GlassCard key={b.title} data-testid={`seller-benefit-${b.title.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-4 bg-vest-g5/10">
                  <b.icon className="w-5 h-5 text-vest-g5" />
                </div>
                <h3 className="text-lg font-semibold text-ink-dark mb-2">{b.title}</h3>
                <p className="text-sm text-ink-muted/70 leading-relaxed">{b.desc}</p>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-4" data-testid="seller-process-section">
        <div className="max-w-4xl mx-auto">
          <motion.div className="text-center mb-12" initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.h2 variants={fadeUp} transition={{ duration: 0.5 }} className="text-3xl sm:text-4xl font-bold text-ink-dark">
              How It <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Works</span>
            </motion.h2>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {process.map((s) => (
              <GlassCard key={s.step} className="text-center" data-testid={`seller-step-${s.step}`}>
                <div className="w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-3 bg-vest-g5/10 text-vest-g5 font-bold">{s.step}</div>
                <h4 className="text-base font-semibold text-ink-dark mb-1">{s.title}</h4>
                <p className="text-sm text-ink-muted/70">{s.desc}</p>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-4" data-testid="seller-property-types">
        <div className="max-w-3xl mx-auto">
          <motion.div className="text-center mb-10" initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.h2 variants={fadeUp} transition={{ duration: 0.5 }} className="text-3xl sm:text-4xl font-bold text-ink-dark">
              Eligible <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Property Types</span>
            </motion.h2>
          </motion.div>
          <GlassCard>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {propertyTypes.map((t) => (
                <div key={t} className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-vest-g5 shrink-0" />
                  <span className="text-sm text-ink-muted">{t}</span>
                </div>
              ))}
            </div>
            <p className="text-xs text-ink-muted mt-4">Minimum property value: PKR 20 million. Properties must have clear title and completed construction.</p>
          </GlassCard>
        </div>
      </section>

      <div className="max-w-3xl mx-auto px-4 mb-8">
        <ComplianceDisclaimer
          variant="regulatory"
          title="Seller Requirements"
          text="All properties undergo independent valuation, legal title verification, and structural assessment before listing. Sellers must provide complete documentation including title deeds, NOC, and tax records. VestBlock reserves the right to reject properties that do not meet our due diligence standards."
          testId="seller-compliance"
        />
      </div>

      <CtaSection
        icon={Building2}
        title="List Your"
        highlight="Property"
        subtitle="Submit your property for tokenization and reach thousands of qualified investors."
        actions={[
          { label: "Submit Property", href: "/contact" },
          { label: "How Tokenization Works", href: "/tokenization", variant: "secondary" },
        ]}
        testId="seller-cta"
      />
    </MarketingLayout>
  );
}
