import { MarketingLayout } from "@/components/marketing/layout";
import { MarketingHero } from "@/components/marketing/marketing-hero";
import { GlassCard } from "@/components/marketing/glass-card";
import { GlassButton } from "@/components/marketing/glass-button";
import { CtaSection } from "@/components/marketing/cta-section";
import { PageMeta } from "@/components/marketing/page-meta";
import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  Download, Mail, Phone, MapPin, Camera, FileText,
  Palette, Award, Newspaper, ArrowRight, Calendar,
} from "lucide-react";

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const pressKit = [
  { icon: Palette, label: "Brand Guidelines & Logos", format: "PDF, 12 MB", desc: "Primary logo, icon, wordmark in SVG/PNG. Brand colours, typography, usage rules." },
  { icon: Camera, label: "Founder & Team Photos", format: "ZIP, 45 MB", desc: "High-resolution headshots and team photographs for publication." },
  { icon: FileText, label: "Company Fact Sheet", format: "PDF, 2 MB", desc: "One-page overview with key metrics, timeline, leadership, and contact details." },
  { icon: Award, label: "Product Screenshots", format: "ZIP, 30 MB", desc: "Investor dashboard, marketplace, property detail, and mobile app screenshots." },
];

const stats = [
  { value: "PKR 2B+", label: "Assets Under Management" },
  { value: "10,000+", label: "Verified Investors" },
  { value: "45+", label: "Tokenized Properties" },
  { value: "$5M", label: "Series A Raised" },
];

const recentCoverage = [
  { outlet: "Dawn", title: "VestBlock Brings Fractional Real Estate to Pakistan's Middle Class", date: "Jan 15, 2026", category: "Feature" },
  { outlet: "The News", title: "How Blockchain Is Reshaping Pakistan's Property Market", date: "Dec 8, 2025", category: "Business" },
  { outlet: "Express Tribune", title: "VestBlock Raises $5M to Expand Tokenized Real Estate Offerings", date: "Nov 22, 2025", category: "Funding" },
  { outlet: "Business Recorder", title: "SECP Approves VestBlock's Digital Asset Framework", date: "Oct 5, 2025", category: "Regulation" },
];

export default function MediaPage() {
  return (
    <MarketingLayout>
      <PageMeta
        title="Media & Press Kit"
        description="Download VestBlock brand assets, logos, and media resources. Access recent press coverage, company fact sheets, and media contact information."
        path="/pk/media"
      />

      <MarketingHero
        badge="Media"
        title="Press &"
        highlight="Media Resources"
        subtitle="Everything journalists, analysts, and partners need to cover VestBlock — brand assets, fact sheets, and media contacts."
        testIdPrefix="media"
      />

      <section className="py-16 px-4" data-testid="media-stats-section">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map((s) => (
            <GlassCard key={s.label} className="text-center">
              <div className="text-2xl font-bold bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent mb-1">{s.value}</div>
              <div className="text-xs text-ink-muted/70">{s.label}</div>
            </GlassCard>
          ))}
        </div>
      </section>

      <section className="py-16 px-4" data-testid="press-kit-section">
        <div className="max-w-5xl mx-auto">
          <motion.div className="text-center mb-12" initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.h2 variants={fadeUp} transition={{ duration: 0.5 }} className="text-3xl sm:text-4xl font-bold text-ink-dark">
              Press <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Kit</span>
            </motion.h2>
            <motion.p variants={fadeUp} transition={{ duration: 0.5 }} className="text-ink-muted mt-4 max-w-xl mx-auto">
              Download official brand assets and media resources for publication.
            </motion.p>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {pressKit.map((item, i) => (
              <GlassCard key={i} data-testid={`press-kit-${i}`}>
                <div className="flex items-start gap-4">
                  <div className="w-11 h-11 rounded-xl flex items-center justify-center bg-vest-g5/10 shrink-0">
                    <item.icon className="w-5 h-5 text-vest-g5" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-base font-semibold text-ink-dark mb-1">{item.label}</h3>
                    <p className="text-xs text-ink-muted/70 mb-2">{item.desc}</p>
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <span className="text-xs text-ink-muted">{item.format}</span>
                      <button className="inline-flex items-center gap-1.5 text-xs text-vest-g5 font-medium" data-testid={`media-download-${i}`}>
                        <Download className="w-3.5 h-3.5" /> Download
                      </button>
                    </div>
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-4" data-testid="recent-coverage-section">
        <div className="max-w-5xl mx-auto">
          <motion.div className="text-center mb-12" initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.h2 variants={fadeUp} transition={{ duration: 0.5 }} className="text-3xl sm:text-4xl font-bold text-ink-dark">
              Recent <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Coverage</span>
            </motion.h2>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {recentCoverage.map((a, i) => (
              <GlassCard key={i} data-testid={`coverage-${i}`}>
                <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                  <span className="text-sm font-semibold text-vest-g5">{a.outlet}</span>
                  <span className="text-xs px-2 py-0.5 rounded-full text-ink-muted/70 ring-1 ring-vest-g5/20">{a.category}</span>
                </div>
                <h3 className="text-base font-semibold text-ink-dark mb-2 leading-snug">{a.title}</h3>
                <div className="flex items-center gap-1.5 text-xs text-ink-muted">
                  <Calendar className="w-3 h-3" /> {a.date}
                </div>
              </GlassCard>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link href="/press" className="text-sm text-vest-g5 hover:underline inline-flex items-center gap-1" data-testid="media-all-press">
              View All Press Coverage <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </section>

      <section className="py-16 px-4" data-testid="media-contact-section">
        <div className="max-w-2xl mx-auto">
          <GlassCard>
            <h3 className="text-xl font-bold text-ink-dark mb-6">Media Contact</h3>
            <div className="space-y-5">
              {[
                { icon: Mail, label: "Email", value: "press@vestblock.pk" },
                { icon: Phone, label: "Phone", value: "+92 51 111 8378 (VEST)" },
                { icon: MapPin, label: "Office", value: "Floor 12, Centaurus Mall, F-8 Markaz, Islamabad" },
              ].map((c) => (
                <div key={c.label} className="flex items-center gap-4" data-testid={`media-contact-${c.label.toLowerCase()}`}>
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center bg-vest-g5/10 shrink-0">
                    <c.icon className="w-4 h-4 text-vest-g5" />
                  </div>
                  <div>
                    <p className="text-xs text-ink-muted">{c.label}</p>
                    <p className="text-sm text-ink-muted">{c.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>
        </div>
      </section>
    </MarketingLayout>
  );
}
