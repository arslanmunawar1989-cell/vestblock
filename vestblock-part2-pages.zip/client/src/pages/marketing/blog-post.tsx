import { Link, useParams } from "wouter";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { GlassCard } from "@/components/marketing/glass-card";
import { GlassButton } from "@/components/marketing/glass-button";
import { motion } from "framer-motion";
import {
  Calendar, Clock, ArrowLeft, ArrowRight, User, Tag,
  BookOpen, BarChart3, ShieldCheck, Share2, ChevronRight,
} from "lucide-react";
import { useCmsBlogPosts } from "@/hooks/use-cms-content";
import blogPostsJson from "@/data/blog-posts.json";

type BlogPost = (typeof blogPostsJson)[number];

function mapCmsToBlogPost(cms: any): BlogPost {
  return {
    slug: cms.slug,
    title: cms.title,
    subtitle: cms.excerpt || "",
    category: cms.category || "Education",
    date: cms.publishedAt || cms.createdAt,
    readTime: Math.ceil((cms.contentHtml?.length || 500) / 200),
    author: "VestBlock Research",
    featured: false,
    tags: cms.tagsJson || [],
    sections: cms.contentHtml ? [{ heading: "", body: cms.contentHtml }] : [],
  };
}

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const categoryConfig: Record<string, { icon: typeof BookOpen; accent: string; bg: string; border: string }> = {
  Education: { icon: BookOpen, accent: "text-vest-g5", bg: "bg-vest-g5/10", border: "border-vest-g5/20" },
  "Market Analysis": { icon: BarChart3, accent: "text-emerald-400", bg: "bg-emerald-400/10", border: "border-emerald-400/20" },
  "Risk & Compliance": { icon: ShieldCheck, accent: "text-amber-400", bg: "bg-amber-400/10", border: "border-amber-400/20" },
};

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("en-PK", { day: "numeric", month: "long", year: "numeric" });
}

function renderBody(body: string) {
  const lines = body.split("\n");
  const elements: JSX.Element[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    if (line.startsWith("| ") && line.includes("|")) {
      const tableLines: string[] = [];
      let j = i;
      while (j < lines.length && lines[j].startsWith("|")) {
        tableLines.push(lines[j]);
        j++;
      }
      const headerCells = tableLines[0].split("|").filter(Boolean).map((c) => c.trim());
      const dataRows = tableLines.slice(2);
      elements.push(
        <div key={`table-${i}`} className="overflow-x-auto my-5 rounded-2xl border border-vest-g5/15">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-vest-g5/15 bg-white/50">
                {headerCells.map((cell, ci) => (
                  <th key={ci} className="px-4 py-3 text-left font-semibold text-ink-muted">{cell}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {dataRows.map((row, ri) => {
                const cells = row.split("|").filter(Boolean).map((c) => c.trim());
                return (
                  <tr key={ri} className="border-b border-vest-g5/15 last:border-0">
                    {cells.map((cell, ci) => (
                      <td key={ci} className="px-4 py-3 text-ink-muted">{cell}</td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      );
      i = j - 1;
      continue;
    }

    if (!line.trim()) {
      continue;
    }

    if (line.startsWith("- ")) {
      const listItems: string[] = [];
      let j = i;
      while (j < lines.length && lines[j].startsWith("- ")) {
        listItems.push(lines[j].slice(2));
        j++;
      }
      elements.push(
        <ul key={`list-${i}`} className="space-y-1.5 my-3 ml-1">
          {listItems.map((item, li) => (
            <li key={li} className="flex items-start gap-2 text-sm text-ink-muted leading-relaxed">
              <span className="w-1.5 h-1.5 rounded-full bg-vest-g5/50 mt-2 shrink-0" />
              <span dangerouslySetInnerHTML={{ __html: formatInline(item) }} />
            </li>
          ))}
        </ul>
      );
      i = j - 1;
      continue;
    }

    if (/^\d+\.\s/.test(line)) {
      const listItems: string[] = [];
      let j = i;
      while (j < lines.length && /^\d+\.\s/.test(lines[j])) {
        listItems.push(lines[j].replace(/^\d+\.\s/, ""));
        j++;
      }
      elements.push(
        <ol key={`ol-${i}`} className="space-y-1.5 my-3 ml-1">
          {listItems.map((item, li) => (
            <li key={li} className="flex items-start gap-2 text-sm text-ink-muted leading-relaxed">
              <span className="text-vest-g5 font-semibold text-xs mt-0.5 shrink-0">{li + 1}.</span>
              <span dangerouslySetInnerHTML={{ __html: formatInline(item) }} />
            </li>
          ))}
        </ol>
      );
      i = j - 1;
      continue;
    }

    elements.push(
      <p key={`p-${i}`} className="text-sm text-ink-muted leading-[1.8] my-3" dangerouslySetInnerHTML={{ __html: formatInline(line) }} />
    );
  }

  return elements;
}

function formatInline(text: string): string {
  return text
    .replace(/\*\*(.+?)\*\*/g, '<strong class="text-ink-dark font-semibold">$1</strong>')
    .replace(/\*$/g, '<span class="text-ink-muted text-xs">*</span>');
}

export default function BlogPostPage() {
  const { slug } = useParams<{ slug: string }>();
  const { data: cmsBlogPosts } = useCmsBlogPosts("PK");
  const blogPosts: BlogPost[] = cmsBlogPosts && cmsBlogPosts.length > 0
    ? cmsBlogPosts.map(mapCmsToBlogPost)
    : blogPostsJson;
  const post = blogPosts.find((p) => p.slug === slug);

  if (!post) {
    return (
      <MarketingLayout>
        <section className="py-32 px-4 text-center">
          <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark mb-4">Article Not <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Found</span></h1>
          <p className="text-sm text-ink-muted/70 mb-6">The article you're looking for doesn't exist.</p>
          <Link href="/blog">
            <GlassButton>Back to Blog</GlassButton>
          </Link>
        </section>
      </MarketingLayout>
    );
  }

  const cfg = categoryConfig[post.category] || categoryConfig.Education;
  const currentIndex = blogPosts.findIndex((p) => p.slug === slug);
  const prevPost = currentIndex > 0 ? blogPosts[currentIndex - 1] : null;
  const nextPost = currentIndex < blogPosts.length - 1 ? blogPosts[currentIndex + 1] : null;

  const relatedPosts = blogPosts
    .filter((p) => p.slug !== slug && p.category === post.category)
    .slice(0, 3);

  return (
    <MarketingLayout>
      <PageMeta title="Blog Post" description="Read the latest insights on tokenized real estate investing from VestBlock." path="/pk/blog" />
      <article className="relative" data-testid="blog-post">
        <section className="relative py-20 sm:py-28 px-4 overflow-hidden" data-testid="blog-post-hero">
          <div className="absolute inset-0 bg-gradient-to-b from-vest-g5/5 via-transparent to-transparent pointer-events-none" />
          <div className="max-w-3xl mx-auto relative z-10">
            <motion.div variants={fadeUp} initial="hidden" animate="visible">
              <Link href="/blog" className="inline-flex items-center gap-1.5 text-xs text-ink-muted/70 hover:text-ink-muted transition-colors mb-6" data-testid="blog-back-link">
                <ArrowLeft className="w-3.5 h-3.5" /> Back to Blog
              </Link>
              <div className="flex items-center gap-2 mb-4 flex-wrap">
                <span className={`px-2.5 py-1 rounded-xl text-[10px] font-bold ${cfg.accent} ${cfg.bg} border ${cfg.border}`} data-testid="blog-post-category">{post.category}</span>
                <span className="text-[10px] text-ink-muted flex items-center gap-1"><Calendar className="w-3 h-3" /> {formatDate(post.date)}</span>
                <span className="text-[10px] text-ink-muted flex items-center gap-1"><Clock className="w-3 h-3" /> {post.readTime} min read</span>
              </div>
              <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight tracking-tight mb-4" data-testid="blog-post-title" style={{ fontFamily: "'Playfair Display', serif" }}>
                {post.title}
              </h1>
              <p className="text-base text-ink-muted leading-relaxed mb-5" data-testid="blog-post-subtitle">{post.subtitle}</p>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-vest-g5/15 flex items-center justify-center">
                  <User className="w-4 h-4 text-vest-g5" />
                </div>
                <span className="text-xs text-ink-muted" data-testid="blog-post-author">{post.author}</span>
              </div>
            </motion.div>
          </div>
        </section>

        <section className="px-4 pb-16" data-testid="blog-post-content">
          <div className="max-w-3xl mx-auto">
            {post.sections.map((section, i) => (
              <motion.div key={i} variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} transition={{ delay: i * 0.03 }} className="mb-10 last:mb-0">
                <h2 className="text-xl font-bold text-ink-dark mb-4 tracking-tight" style={{ fontFamily: "'Playfair Display', serif" }} data-testid={`section-heading-${i}`}>
                  {section.heading}
                </h2>
                <div data-testid={`section-body-${i}`}>
                  {renderBody(section.body)}
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="px-4 pb-12" data-testid="blog-post-tags">
          <div className="max-w-3xl mx-auto">
            <div className="flex items-center gap-2 flex-wrap">
              <Tag className="w-3.5 h-3.5 text-ink-muted" />
              {post.tags.map((tag) => (
                <span key={tag} className="px-2.5 py-1 rounded-xl text-[10px] text-ink-muted/70 bg-white/50 border border-vest-g5/15">{tag}</span>
              ))}
            </div>
          </div>
        </section>

        {(prevPost || nextPost) && (
          <section className="px-4 pb-16" data-testid="blog-post-nav">
            <div className="max-w-3xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-4">
              {prevPost ? (
                <Link href={`/blog/${prevPost.slug}`} className="block" data-testid="blog-prev-link">
                  <GlassCard className="h-full hover:border-vest-g5/20 transition-colors cursor-pointer group p-4">
                    <p className="text-[10px] text-ink-muted mb-1 flex items-center gap-1"><ArrowLeft className="w-3 h-3" /> Previous</p>
                    <p className="text-xs font-semibold text-ink-muted group-hover:text-vest-g5 transition-colors leading-snug">{prevPost.title}</p>
                  </GlassCard>
                </Link>
              ) : <div />}
              {nextPost ? (
                <Link href={`/blog/${nextPost.slug}`} className="block" data-testid="blog-next-link">
                  <GlassCard className="h-full hover:border-vest-g5/20 transition-colors cursor-pointer group p-4 text-right">
                    <p className="text-[10px] text-ink-muted mb-1 flex items-center justify-end gap-1">Next <ArrowRight className="w-3 h-3" /></p>
                    <p className="text-xs font-semibold text-ink-muted group-hover:text-vest-g5 transition-colors leading-snug">{nextPost.title}</p>
                  </GlassCard>
                </Link>
              ) : <div />}
            </div>
          </section>
        )}

        {relatedPosts.length > 0 && (
          <section className="px-4 pb-16" data-testid="blog-related">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-lg font-semibold text-ink-muted mb-5">Related Articles</h2>
              <div className="space-y-3">
                {relatedPosts.map((rp) => (
                  <Link key={rp.slug} href={`/blog/${rp.slug}`} className="block" data-testid={`related-${rp.slug}`}>
                    <GlassCard className="hover:border-vest-g5/20 transition-colors cursor-pointer group p-4">
                      <div className="flex items-center justify-between gap-3">
                        <div>
                          <p className="text-sm font-semibold text-ink-dark group-hover:text-vest-g5 transition-colors">{rp.title}</p>
                          <p className="text-[10px] text-ink-muted mt-1">{formatDate(rp.date)} · {rp.readTime} min read</p>
                        </div>
                        <ChevronRight className="w-4 h-4 text-ink-muted shrink-0" />
                      </div>
                    </GlassCard>
                  </Link>
                ))}
              </div>
            </div>
          </section>
        )}
      </article>
    </MarketingLayout>
  );
}
