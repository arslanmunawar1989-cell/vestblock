import { Link } from "wouter";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { SectionHeader } from "@/components/marketing/section-header";
import { CtaSection } from "@/components/marketing/cta-section";
import {
  Check,
  X,
  ArrowRight,
  Zap,
  TrendingUp,
  Building2,
  Star,
  Crown,
  Gem,
} from "lucide-react";

const tiers = [
  {
    icon: Star,
    name: "Starter",
    price: "Free",
    priceNote: "No platform fees",
    limit: "Up to PKR 500K portfolio",
    features: [
      { text: "Up to PKR 500,000 investment", included: true },
      { text: "Basic dashboard & reporting", included: true },
      { text: "Standard KYC verification", included: true },
      { text: "Email support", included: true },
      { text: "Quarterly distributions", included: true },
      { text: "Secondary marketplace access", included: true },
      { text: "Priority support", included: false },
      { text: "API access", included: false },
      { text: "Custom reporting", included: false },
    ],
    cta: "Get Started Free",
    href: "/register",
    highlighted: false,
  },
  {
    icon: Crown,
    name: "Growth",
    price: "0.5%",
    priceNote: "Annual management fee",
    limit: "Up to PKR 5M portfolio",
    features: [
      { text: "Up to PKR 5,000,000 investment", included: true },
      { text: "Advanced analytics dashboard", included: true },
      { text: "Priority KYC verification", included: true },
      { text: "Priority email & chat support", included: true },
      { text: "Monthly distributions", included: true },
      { text: "Secondary marketplace + OTC desk", included: true },
      { text: "Priority support", included: true },
      { text: "API access (read-only)", included: true },
      { text: "Custom reporting", included: false },
    ],
    cta: "Start Growing",
    href: "/register",
    highlighted: true,
  },
  {
    icon: Gem,
    name: "Institutional",
    price: "Custom",
    priceNote: "Tailored pricing",
    limit: "PKR 5M+ portfolio",
    features: [
      { text: "Unlimited investment capacity", included: true },
      { text: "White-label dashboard", included: true },
      { text: "Dedicated compliance officer", included: true },
      { text: "Dedicated account manager", included: true },
      { text: "Custom distribution schedules", included: true },
      { text: "Full marketplace access + block trades", included: true },
      { text: "24/7 priority support", included: true },
      { text: "Full API access (read/write)", included: true },
      { text: "Custom reporting & data exports", included: true },
    ],
    cta: "Contact Sales",
    href: "/institutions",
    highlighted: false,
  },
];

const feeBreakdown = [
  { category: "Platform Fee", starter: "Free", growth: "0.5% annually", institutional: "Negotiable" },
  { category: "Entry Fee", starter: "1.0%", growth: "0.75%", institutional: "0.5%" },
  { category: "Exit Fee", starter: "1.0%", growth: "0.5%", institutional: "Waived" },
  { category: "Distribution Fee", starter: "Free", growth: "Free", institutional: "Free" },
  { category: "FX Conversion", starter: "0.5%", growth: "0.3%", institutional: "0.1%" },
  { category: "Secondary Trading", starter: "0.5%", growth: "0.25%", institutional: "0.1%" },
];

const traditionalComparison = [
  { item: "Minimum Investment", vestblock: "PKR 50,000", traditional: "PKR 5,000,000+" },
  { item: "Transaction Time", vestblock: "Minutes", traditional: "3-6 Months" },
  { item: "Legal & Registration Fees", vestblock: "Included", traditional: "2-5% of value" },
  { item: "Agent Commission", vestblock: "None", traditional: "1-2%" },
  { item: "Stamp Duty", vestblock: "Included", traditional: "3-5%" },
  { item: "Annual Maintenance", vestblock: "0-0.5%", traditional: "Variable" },
  { item: "Liquidity", vestblock: "Quarterly windows", traditional: "Months to years" },
  { item: "Diversification", vestblock: "Multiple properties", traditional: "Single property" },
];

export default function PricingPage() {
  return (
    <MarketingLayout>
      <PageMeta title="Pricing & Fees" description="Transparent pricing for VestBlock's tokenized real estate platform. No hidden fees. Clear breakdown of platform, management, and transaction fees." path="/pk/pricing" />
      <section className="relative overflow-hidden py-24 sm:py-32 px-4" data-testid="pricing-hero">
        <div className="max-w-7xl mx-auto text-center">
          <SectionHeader
            badge="Pricing"
            title="Transparent"
            highlight="Pricing"
            description="No hidden fees. No surprises. Know exactly what you pay at every stage of your investment journey."
          />
        </div>
      </section>

      <section className="py-20 px-4" data-testid="pricing-tiers-section">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {tiers.map((tier) => (
              <div
                key={tier.name}
                className={`glass rounded-md p-8 transition-all duration-300 flex flex-col ${tier.highlighted ? "border border-vest-g5/20 border border-[rgba(30,43,255,0.18)]" : ""}`}
                data-testid={`pricing-tier-${tier.name.toLowerCase()}`}
              >
                {tier.highlighted && (
                  <div className="inline-flex items-center self-start px-3 py-1 rounded-full text-xs font-medium mb-4 text-vest-g5 border border-vest-g5/15" data-testid="pricing-popular-badge">
                    Most Popular
                  </div>
                )}
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-md flex items-center justify-center" style={{ background: "rgba(30,43,255,0.08)" }}>
                    <tier.icon className="w-5 h-5 text-vest-g5" />
                  </div>
                  <h3 className="text-xl font-bold text-ink-dark">{tier.name}</h3>
                </div>
                <div className="mb-1">
                  <span className="text-4xl font-bold text-ink-dark" data-testid={`pricing-price-${tier.name.toLowerCase()}`}>{tier.price}</span>
                </div>
                <p className="text-ink-muted text-sm mb-1">{tier.priceNote}</p>
                <p className="text-ink-muted text-sm mb-6">{tier.limit}</p>
                <div className="border-t border-vest-g5/10 mb-6" />
                <ul className="space-y-3 mb-8 flex-1">
                  {tier.features.map((f) => (
                    <li key={f.text} className="flex items-start gap-2" data-testid={`pricing-feature-${tier.name.toLowerCase()}-${f.text.toLowerCase().replace(/\s+/g, "-").slice(0, 20)}`}>
                      {f.included ? (
                        <Check className="w-4 h-4 text-vest-g5 shrink-0 mt-0.5" />
                      ) : (
                        <X className="w-4 h-4 text-ink-muted shrink-0 mt-0.5" />
                      )}
                      <span className={f.included ? "text-ink-muted text-sm" : "text-ink-muted text-sm"}>{f.text}</span>
                    </li>
                  ))}
                </ul>
                <Link href={tier.href}
                    className={`w-full text-center px-6 py-3 text-base font-semibold rounded-md inline-flex items-center justify-center gap-2 ${tier.highlighted ? "bg-vest-g5 text-ink-dark hover:opacity-90 transition" : "border border-vest-g5/20 text-ink-dark hover:bg-vest-g0/40 transition"}`}
                    data-testid={`pricing-cta-${tier.name.toLowerCase()}`}
                  >
                    {tier.cta} <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4 " data-testid="fee-breakdown-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Fee Details"
            title="Complete Fee"
            highlight="Breakdown"
            description="A detailed look at every fee across all tiers so you can plan your investments with full clarity."
          />
          <div className="glass rounded-md overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full" data-testid="fee-breakdown-table">
                <thead>
                  <tr className="border-b border-vest-g5/15-subtle">
                    <th className="text-left py-4 px-6 text-sm font-semibold text-ink-dark">Fee Category</th>
                    <th className="text-center py-4 px-6 text-sm font-semibold text-ink-dark">Starter</th>
                    <th className="text-center py-4 px-6 text-sm font-semibold text-ink-dark">Growth</th>
                    <th className="text-center py-4 px-6 text-sm font-semibold text-ink-dark">Institutional</th>
                  </tr>
                </thead>
                <tbody>
                  {feeBreakdown.map((row) => (
                    <tr key={row.category} className="border-b border-vest-g5/15-subtle" data-testid={`fee-row-${row.category.toLowerCase().replace(/[\s/]+/g, "-")}`}>
                      <td className="py-4 px-6 text-sm text-ink-muted font-medium">{row.category}</td>
                      <td className="py-4 px-6 text-sm text-ink-muted text-center">{row.starter}</td>
                      <td className="py-4 px-6 text-sm text-vest-g5 text-center font-medium">{row.growth}</td>
                      <td className="py-4 px-6 text-sm text-ink-muted text-center">{row.institutional}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="comparison-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Comparison"
            title="VestBlock vs"
            highlight="Traditional Real Estate"
            description="See how tokenized real estate compares to traditional property investment in Pakistan."
          />
          <div className="glass rounded-md overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full" data-testid="comparison-table">
                <thead>
                  <tr className="border-b border-vest-g5/15-subtle">
                    <th className="text-left py-4 px-6 text-sm font-semibold text-ink-dark">Cost Item</th>
                    <th className="text-center py-4 px-6 text-sm font-semibold text-vest-g5">
                      <div className="flex items-center justify-center gap-2">
                        <Zap className="w-4 h-4" /> VestBlock
                      </div>
                    </th>
                    <th className="text-center py-4 px-6 text-sm font-semibold text-ink-muted">
                      <div className="flex items-center justify-center gap-2">
                        <Building2 className="w-4 h-4" /> Traditional
                      </div>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {traditionalComparison.map((row) => (
                    <tr key={row.item} className="border-b border-vest-g5/15-subtle" data-testid={`compare-row-${row.item.toLowerCase().replace(/[\s/]+/g, "-")}`}>
                      <td className="py-4 px-6 text-sm text-ink-muted font-medium">{row.item}</td>
                      <td className="py-4 px-6 text-sm text-vest-g5 text-center font-medium">{row.vestblock}</td>
                      <td className="py-4 px-6 text-sm text-ink-muted text-center">{row.traditional}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      <CtaSection
        title="Start Investing"
        highlight="Today"
        subtitle="Open your free account and begin your tokenized real estate journey with zero platform fees on your first PKR 500,000."
        actions={[
          { label: "Create Free Account", href: "/register" },
        ]}
        testId="pricing-cta"
      />
    </MarketingLayout>
  );
}
