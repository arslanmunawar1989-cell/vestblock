import { MarketingLayout } from "@/components/marketing/layout";
import { MarketingHero } from "@/components/marketing/marketing-hero";
import { GlassCard } from "@/components/marketing/glass-card";
import { CtaSection } from "@/components/marketing/cta-section";
import { PageMeta } from "@/components/marketing/page-meta";
import { motion } from "framer-motion";
import { Target, Eye, Shield, Heart, Lightbulb, Award, Globe, Users } from "lucide-react";

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const team = [
  { name: "Ahmed Raza Khan", role: "CEO & Co-Founder", initials: "AK" },
  { name: "Fatima Zahra Malik", role: "CTO", initials: "FM" },
  { name: "Hassan Ali Sheikh", role: "Head of Compliance", initials: "HS" },
  { name: "Ayesha Siddiqui", role: "VP Product", initials: "AS" },
  { name: "Usman Tariq Butt", role: "Head of Engineering", initials: "UB" },
  { name: "Sana Noor Qureshi", role: "Head of Partnerships", initials: "SQ" },
];

const timeline = [
  { year: "2022", title: "Founded", desc: "VestBlock incorporated in Islamabad with a mission to democratize real estate investment." },
  { year: "2023", title: "SECP License", desc: "Received Securities and Exchange Commission of Pakistan license for digital asset issuance." },
  { year: "2024", title: "10K Investors", desc: "Crossed 10,000 verified investors on the platform with PKR 1.2B in assets under management." },
  { year: "2025", title: "PKR 2B AUM", desc: "Reached PKR 2 billion assets under management with 45+ tokenized properties." },
];

const values = [
  { icon: Shield, title: "Transparency", desc: "Every transaction, fee, and return is fully visible on-chain and in your dashboard." },
  { icon: Heart, title: "Inclusivity", desc: "Real estate investing accessible to everyone, starting from PKR 50,000." },
  { icon: Lightbulb, title: "Innovation", desc: "Leveraging blockchain, smart contracts, and AI to redefine property investment." },
  { icon: Award, title: "Compliance", desc: "Full adherence to SECP regulations, AML/KYC requirements, and international standards." },
];

const stats = [
  { value: "PKR 2B+", label: "Assets Under Management" },
  { value: "10,000+", label: "Verified Investors" },
  { value: "45+", label: "Tokenized Properties" },
  { value: "4", label: "Cities Covered" },
];

export default function AboutPage() {
  return (
    <MarketingLayout>
      <PageMeta
        title="About VestBlock"
        description="Learn about VestBlock's mission to democratize real estate investment in Pakistan through blockchain-powered tokenization. SECP-licensed, 10K+ investors, PKR 2B+ AUM."
        path="/pk/about"
      />

      <MarketingHero
        badge="Our Story"
        title="Building Pakistan's"
        highlight="Real Estate Future"
        subtitle="VestBlock is on a mission to make institutional-grade real estate investment accessible to every Pakistani through blockchain technology and regulatory compliance."
        testIdPrefix="about"
      />

      <section className="py-16 px-4 gradient-section-blue" data-testid="about-stats-section">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map((s) => (
            <GlassCard key={s.label} className="text-center" data-testid={`stat-${s.label.toLowerCase().replace(/\s+/g, "-")}`}>
              <div className="text-3xl font-bold bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent mb-1">{s.value}</div>
              <div className="text-xs text-ink-muted/70">{s.label}</div>
            </GlassCard>
          ))}
        </div>
      </section>

      <section className="py-16 px-4" data-testid="mission-vision-section">
        <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6">
          <GlassCard data-testid="mission-card">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-5 bg-vest-g5/10">
              <Target className="w-6 h-6 text-vest-g5" />
            </div>
            <h3 className="text-2xl font-bold text-ink-dark mb-3">Our Mission</h3>
            <p className="text-ink-muted leading-relaxed">
              To democratize real estate investment in Pakistan by enabling fractional ownership of premium properties through compliant, blockchain-powered tokenization — making it possible for anyone to invest from PKR 50,000.
            </p>
          </GlassCard>
          <GlassCard data-testid="vision-card">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-5 bg-vest-g5/10">
              <Eye className="w-6 h-6 text-vest-g5" />
            </div>
            <h3 className="text-2xl font-bold text-ink-dark mb-3">Our Vision</h3>
            <p className="text-ink-muted leading-relaxed">
              To become South Asia's leading real estate tokenization platform, setting the standard for regulated digital securities and unlocking PKR 50 trillion in illiquid property value.
            </p>
          </GlassCard>
        </div>
      </section>

      <section className="py-16 px-4" data-testid="team-section">
        <div className="max-w-5xl mx-auto">
          <motion.div className="text-center mb-12" initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.span variants={fadeUp} transition={{ duration: 0.5 }} className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide uppercase text-vest-g5 ring-1 ring-vest-g5/30 bg-vest-g5/5 mb-4">
              Leadership
            </motion.span>
            <motion.h2 variants={fadeUp} transition={{ duration: 0.5 }} className="text-3xl sm:text-4xl font-bold text-ink-dark mb-4">
              Meet Our <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Team</span>
            </motion.h2>
            <motion.p variants={fadeUp} transition={{ duration: 0.5 }} className="text-ink-muted max-w-2xl mx-auto">
              Industry veterans from finance, technology, and real estate driving VestBlock forward.
            </motion.p>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {team.map((member) => (
              <GlassCard key={member.name} className="text-center" data-testid={`team-${member.initials.toLowerCase()}`}>
                <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 bg-vest-g5/10">
                  <span className="text-lg font-bold text-vest-g5">{member.initials}</span>
                </div>
                <h4 className="text-lg font-semibold text-ink-dark mb-1">{member.name}</h4>
                <p className="text-sm text-ink-muted/70">{member.role}</p>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-4" data-testid="timeline-section">
        <div className="max-w-5xl mx-auto">
          <motion.div className="text-center mb-12" initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.span variants={fadeUp} transition={{ duration: 0.5 }} className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide uppercase text-vest-g5 ring-1 ring-vest-g5/30 bg-vest-g5/5 mb-4">
              Milestones
            </motion.span>
            <motion.h2 variants={fadeUp} transition={{ duration: 0.5 }} className="text-3xl sm:text-4xl font-bold text-ink-dark">
              Our <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Journey</span>
            </motion.h2>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {timeline.map((item) => (
              <GlassCard key={item.year} data-testid={`timeline-${item.year}`}>
                <span className="text-3xl font-bold bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">{item.year}</span>
                <h4 className="text-lg font-semibold text-ink-dark mt-2 mb-2">{item.title}</h4>
                <p className="text-sm text-ink-muted/70 leading-relaxed">{item.desc}</p>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-4 gradient-section-subtle" data-testid="values-section">
        <div className="max-w-5xl mx-auto">
          <motion.div className="text-center mb-12" initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <motion.span variants={fadeUp} transition={{ duration: 0.5 }} className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide uppercase text-vest-g5 ring-1 ring-vest-g5/30 bg-vest-g5/5 mb-4">
              What We Stand For
            </motion.span>
            <motion.h2 variants={fadeUp} transition={{ duration: 0.5 }} className="text-3xl sm:text-4xl font-bold text-ink-dark">
              Our Core <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Values</span>
            </motion.h2>
          </motion.div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {values.map((v) => (
              <GlassCard key={v.title} data-testid={`value-${v.title.toLowerCase()}`}>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-4 bg-vest-g5/10">
                  <v.icon className="w-5 h-5 text-vest-g5" />
                </div>
                <h4 className="text-lg font-semibold text-ink-dark mb-2">{v.title}</h4>
                <p className="text-sm text-ink-muted/70 leading-relaxed">{v.desc}</p>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      <CtaSection
        icon={Globe}
        title="Join the Future of"
        highlight="Real Estate"
        subtitle="Be part of the movement transforming how Pakistan invests in property."
        actions={[
          { label: "Start Investing", href: "/properties" },
          { label: "Contact Us", href: "/contact", variant: "secondary" },
        ]}
        testId="about-cta"
      />
    </MarketingLayout>
  );
}
