import { Link } from "wouter";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { GlassButton } from "@/components/marketing/glass-button";
import { GlassCard } from "@/components/marketing/glass-card";
import { useRegion } from "@/lib/region";
import { motion } from "framer-motion";
import {
  DoorOpen, Calendar, Clock, ArrowRight, CheckCircle2,
  Users, Banknote, ShieldCheck, Wallet, Info,
} from "lucide-react";

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const howItWorksSteps = [
  {
    num: "01",
    icon: DoorOpen,
    title: "List your units during the window",
    desc: "Log in to your dashboard and submit an exit request for the tokens you wish to sell. You can list all or a portion of your holdings.",
  },
  {
    num: "02",
    icon: Users,
    title: "Buyers purchase units at listed price",
    desc: "Your tokens are listed on VestBlock's internal secondary marketplace. Verified buyers can purchase at the prevailing Net Asset Value (NAV) per token, based on the latest independent valuation.",
  },
  {
    num: "03",
    icon: Clock,
    title: "Settlement occurs within defined period",
    desc: "Once matched with a buyer, settlement completes within 7–15 business days. Legal transfer of fractional ownership is processed and recorded on the ledger.",
  },
  {
    num: "04",
    icon: Wallet,
    title: "Funds become available in your wallet",
    desc: "Upon successful settlement, proceeds (minus any applicable exit fees) are credited to your VestBlock wallet. Withdraw to your bank account or reinvest.",
  },
];

const eligibilityItems = [
  { icon: ShieldCheck, text: "KYC completed" },
  { icon: Calendar, text: "Units held beyond lock-up period" },
  { icon: CheckCircle2, text: "Compliance approval" },
];

function UAEComingSoon() {
  return (
    <MarketingLayout>
      <section className="relative py-24 sm:py-32 px-4 overflow-hidden" data-testid="exit-hero">
        <div className="absolute inset-0 bg-gradient-to-b from-vest-g5/5 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <span className="inline-flex items-center px-3.5 py-1.5 rounded-2xl text-xs font-medium mb-6 text-vest-g5 bg-vest-g5/10 border border-vest-g5/20" data-testid="exit-badge">
            Coming Soon
          </span>
          <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-5" data-testid="exit-headline">
            Exit Windows — <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">UAE</span>
          </h1>
          <p className="text-base sm:text-lg text-ink-muted max-w-2xl mx-auto leading-relaxed mb-8">
            Structured exit windows for UAE-based tokenized real estate investments are coming soon.
          </p>
          <div className="inline-flex items-center px-6 py-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-sm font-medium" data-testid="uae-banner">
            <Clock className="w-4 h-4 mr-2" /> Launching soon — stay tuned
          </div>
        </div>
      </section>
    </MarketingLayout>
  );
}

export default function ExitWindowsPage() {
  const { regionCode } = useRegion();

  if (regionCode === "ae") {
    return <UAEComingSoon />;
  }

  return (
    <MarketingLayout>
      <PageMeta
        title="Exit Windows — Structured Liquidity Events"
        description="Understand how VestBlock's structured exit windows work. Sell your property tokens during scheduled liquidity events with full transparency."
        path="/pk/exit-windows"
      />

      <section className="relative py-24 sm:py-32 px-4 overflow-hidden" data-testid="exit-hero">
        <div className="absolute inset-0 bg-gradient-to-b from-vest-g5/5 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div variants={fadeUp} initial="hidden" animate="visible">
            <span className="inline-flex items-center px-3.5 py-1.5 rounded-2xl text-xs font-medium mb-6 text-vest-g5 bg-vest-g5/10 border border-vest-g5/20" data-testid="exit-badge">
              Exit Windows
            </span>
            <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-5" data-testid="exit-headline">
              Structured Liquidity <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Events</span>
            </h1>
            <p className="text-base sm:text-lg text-ink-muted max-w-2xl mx-auto leading-relaxed" data-testid="exit-subtext">
              Scheduled periods during which investors can sell their property tokens through an orderly, transparent process.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-12 px-4" data-testid="exit-when">
        <div className="max-w-4xl mx-auto">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <GlassCard className="border border-vest-g5/20 bg-gradient-to-br from-vest-g5/5 to-transparent text-center" data-testid="exit-frequency-card">
              <div className="w-12 h-12 rounded-2xl bg-vest-g5/15 flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-6 h-6 text-vest-g5" />
              </div>
              <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark mb-3" data-testid="exit-when-title">When Can I <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Exit?</span></h2>
              <p className="text-base text-ink-muted font-medium mb-2" data-testid="exit-frequency">
                Exit windows occur twice per year.
              </p>
              <p className="text-sm text-ink-muted/70 max-w-lg mx-auto">
                Dates are announced well in advance and apply to all eligible properties. This structured approach ensures orderly liquidity aligned with the nature of real estate.
              </p>
            </GlassCard>
          </motion.div>
        </div>
      </section>

      <section className="py-12 px-4" data-testid="exit-how-it-works">
        <div className="max-w-4xl mx-auto">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center mb-8">
            <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark mb-3" data-testid="exit-hiw-title">How It <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Works</span></h2>
            <p className="text-sm text-ink-muted">Four steps from listing to funds in your account.</p>
          </motion.div>

          <div className="space-y-4">
            {howItWorksSteps.map((step, i) => (
              <motion.div
                key={step.num}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                transition={{ delay: i * 0.06 }}
              >
                <GlassCard className="p-0 overflow-hidden" data-testid={`exit-step-${step.num}`}>
                  <div className="flex items-center gap-4 px-6 py-5">
                    <span className="text-2xl font-bold text-vest-g5 shrink-0">{step.num}</span>
                    <div className="w-10 h-10 rounded-xl bg-vest-g5/15 flex items-center justify-center shrink-0">
                      <step.icon className="w-5 h-5 text-vest-g5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-sm font-semibold text-ink-dark mb-1">{step.title}</h3>
                      <p className="text-xs text-ink-muted leading-relaxed">{step.desc}</p>
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 px-4" data-testid="exit-eligibility">
        <div className="max-w-4xl mx-auto">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center mb-8">
            <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark mb-3" data-testid="exit-eligibility-title"><span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Eligibility</span></h2>
            <p className="text-sm text-ink-muted">All conditions must be met to participate in an exit window.</p>
          </motion.div>

          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <GlassCard data-testid="eligibility-card">
              <div className="space-y-4">
                {eligibilityItems.map((item, i) => (
                  <div key={i} className="flex items-center gap-4" data-testid={`eligibility-${i}`}>
                    <div className="w-9 h-9 rounded-xl bg-vest-g5/15 flex items-center justify-center shrink-0">
                      <item.icon className="w-4.5 h-4.5 text-vest-g5" />
                    </div>
                    <span className="text-sm text-ink-dark font-medium">{item.text}</span>
                  </div>
                ))}
              </div>
            </GlassCard>
          </motion.div>
        </div>
      </section>

      <section className="py-12 px-4" data-testid="exit-fees">
        <div className="max-w-4xl mx-auto">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center mb-8">
            <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark mb-3" data-testid="exit-fees-title"><span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Fees</span></h2>
          </motion.div>

          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <GlassCard data-testid="exit-fees-card">
              <div className="flex items-start gap-3 mb-5">
                <div className="w-9 h-9 rounded-xl bg-vest-g5/15 flex items-center justify-center shrink-0">
                  <Banknote className="w-4.5 h-4.5 text-vest-g5" />
                </div>
                <div>
                  <p className="text-sm text-ink-dark font-medium mb-1">Exit fee disclosed before listing.</p>
                  <p className="text-xs text-ink-muted leading-relaxed">
                    The applicable exit fee is shown clearly before you confirm your exit request. The fee is deducted from your proceeds at the time of settlement. No hidden charges.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-white/50 border border-vest-g5/15" data-testid="exit-fee-detail">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-ink-muted">Standard exit fee</span>
                    <span className="px-2.5 py-1 rounded-xl text-xs font-bold text-vest-g5 bg-vest-g5/10 border border-vest-g5/20">0.5 – 2.0%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-ink-muted">Early exit penalty (before lockup expires)</span>
                    <span className="px-2.5 py-1 rounded-xl text-xs font-bold text-ink-muted bg-white/50 border border-vest-g5/15">Up to 2.0%</span>
                  </div>
                </div>
                <div className="mt-4 pt-3 border-t border-vest-g5/15">
                  <p className="text-[11px] text-ink-muted/70">
                    Fee rate depends on property type, holding period, and investor tier. Full fee breakdown is provided on the exit confirmation screen.
                  </p>
                </div>
              </div>

              <div className="mt-5">
                <Link href="/pk/fees" className="inline-flex items-center gap-1.5 text-xs text-vest-g5 font-medium hover:underline" data-testid="link-full-fees">
                    View full fee schedule <ArrowRight className="w-3 h-3" />
                </Link>
              </div>
            </GlassCard>
          </motion.div>
        </div>
      </section>

      <section className="py-12 px-4" data-testid="exit-disclaimer">
        <div className="max-w-4xl mx-auto">
          <GlassCard className="border border-vest-g5/20">
            <div className="flex items-start gap-3">
              <Info className="w-4 h-4 text-ink-muted/70 mt-0.5 shrink-0" />
              <div className="text-[10px] text-ink-muted leading-relaxed space-y-2">
                <p>
                  VestBlock does not guarantee liquidity. Exits depend on buyer demand during the window. If your tokens are not purchased, they remain in your portfolio and continue earning distributions. You may relist in the next window at no additional cost.
                </p>
                <p>
                  Exit window dates, fees, and eligibility criteria are subject to change. All terms are disclosed before you confirm an exit request.
                </p>
              </div>
            </div>
          </GlassCard>
        </div>
      </section>

      <section className="py-16 px-4" data-testid="exit-cta">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <GlassCard className="border border-vest-g5/20 bg-gradient-to-br from-vest-g5/5 to-transparent py-10">
              <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark mb-3" data-testid="exit-cta-title">
                Invest with a Clear Exit <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Path</span>
              </h2>
              <p className="text-sm text-ink-muted mb-6 max-w-md mx-auto">
                Every investment on VestBlock comes with structured exit windows. Know your options before you commit.
              </p>
              <div className="flex flex-wrap items-center justify-center gap-3">
                <Link href="/pk/properties">
                  <GlassButton data-testid="exit-cta-properties">Browse Properties <ArrowRight className="w-4 h-4" /></GlassButton>
                </Link>
                <Link href="/pk/fees">
                  <GlassButton variant="secondary" data-testid="exit-cta-fees">Fee Schedule</GlassButton>
                </Link>
              </div>
            </GlassCard>
          </motion.div>
        </div>
      </section>
    </MarketingLayout>
  );
}
