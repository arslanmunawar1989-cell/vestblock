import { Link } from "wouter";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { GlassCard } from "@/components/marketing/glass-card";
import { CtaSection } from "@/components/marketing/cta-section";
import { motion } from "framer-motion";
import {
  ArrowRight, Banknote, Building2, DoorOpen, RefreshCw,
  Layers, Info, Calculator, Shield, CheckCircle2,
} from "lucide-react";

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const feeSections = [
  {
    id: "investment-structuring",
    icon: Layers,
    title: "Investment Structuring Fee",
    subtitle: "If applicable",
    desc: "A one-time fee that covers the legal structuring of your investment into a Special Purpose Vehicle (SPV) or token offering. This includes documentation, entity setup, and regulatory filings.",
    rate: "0 – 1.0%",
    when: "Charged at the time of investment, deducted from the invested amount.",
    details: [
      "Covers SPV formation, legal review, and token issuance costs",
      "Waived on select properties and for institutional investors",
      "Disclosed on each property listing before you confirm your investment",
    ],
    example: {
      label: "PKR 1,000,000 investment at 1.0%",
      value: "PKR 10,000 structuring fee",
    },
  },
  {
    id: "property-management",
    icon: Building2,
    title: "Property Management Fee",
    subtitle: null,
    desc: "An ongoing annual fee covering tenant management, maintenance coordination, rent collection, insurance, and regulatory compliance for each property in your portfolio.",
    rate: "1.0 – 2.0% per annum",
    when: "Deducted monthly from gross rental income before distributions are paid.",
    details: [
      "Includes tenant sourcing, lease management, and renewals",
      "Covers routine maintenance, repairs, and property inspections",
      "Handles insurance, property tax filings, and regulatory compliance",
    ],
    example: {
      label: "PKR 1,000,000 invested at 1.5% annual",
      value: "PKR 15,000/year (PKR 1,250/month deducted from rental income)",
    },
  },
  {
    id: "platform-fee",
    icon: Banknote,
    title: "Platform Fee",
    subtitle: null,
    desc: "A transparent annual fee that sustains the VestBlock platform — including your investor dashboard, portfolio analytics, document vault, compliance monitoring, and customer support.",
    rate: "0.5 – 1.0% per annum",
    when: "Calculated on your total invested capital and deducted quarterly.",
    details: [
      "Covers secure custody of your tokens and ledger management",
      "Provides real-time portfolio tracking, reporting, and tax documents",
      "Includes KYC/AML compliance, investor communications, and support",
    ],
    example: {
      label: "PKR 1,000,000 invested at 0.75% annual",
      value: "PKR 7,500/year (PKR 1,875/quarter)",
    },
  },
  {
    id: "exit-window",
    icon: DoorOpen,
    title: "Exit Window Fee",
    subtitle: null,
    desc: "A fee applied when you liquidate your position during a scheduled exit window. Designed to cover administrative, legal, and settlement costs of processing your withdrawal.",
    rate: "0.5 – 2.0%",
    when: "Deducted from withdrawal proceeds at the time of exit.",
    details: [
      "Lower rates apply for longer holding periods and higher-tier investors",
      "Early exit before lockup expiry may incur an additional penalty of up to 2.0%",
      "Exit windows are scheduled quarterly — dates disclosed on each listing",
    ],
    example: {
      label: "Exiting PKR 1,000,000 position at 1.0%",
      value: "PKR 10,000 exit fee deducted from proceeds",
    },
  },
  {
    id: "currency-conversion",
    icon: RefreshCw,
    title: "Currency Conversion Spread",
    subtitle: "If applicable",
    desc: "A small spread applied when converting between currencies — for example, USD to PKR, AED to PKR, or USDT/USDC to PKR. Only applies to cross-currency transactions.",
    rate: "0.1 – 0.5%",
    when: "Applied at the point of deposit or withdrawal in a non-PKR currency.",
    details: [
      "Spread varies by currency pair, transaction size, and investor tier",
      "Crypto conversions (USDT/USDC) include network gas fees",
      "Not applicable if you deposit and withdraw in PKR only",
    ],
    example: {
      label: "Converting USD 3,570 (~PKR 1,000,000) at 0.3%",
      value: "~PKR 3,000 conversion spread",
    },
  },
];

const noCharge = [
  "Account creation and KYC verification",
  "Browsing properties and data rooms",
  "Receiving rental distributions",
  "Portfolio analytics and reporting",
  "PKR bank withdrawals",
  "Customer support",
];

export default function FeesPage() {
  return (
    <MarketingLayout>
      <PageMeta
        title="Fees & Costs — Transparent Fee Structure"
        description="A clear breakdown of every fee on VestBlock: investment structuring, property management, platform fees, exit window charges, and currency conversion spreads."
        path="/pk/fees"
      />

      <section className="relative py-24 sm:py-32 px-4 overflow-hidden" data-testid="fees-hero">
        <div className="absolute inset-0 bg-gradient-to-b from-vest-g5/5 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div variants={fadeUp} initial="hidden" animate="visible">
            <span className="inline-flex items-center px-3.5 py-1.5 rounded-2xl text-xs font-medium mb-6 text-vest-g5 bg-vest-g5/10 border border-vest-g5/20" data-testid="fees-badge">
              Fees &amp; Costs
            </span>
            <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-5" data-testid="fees-headline">
              <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Transparent</span> Fee Structure
            </h1>
            <p className="text-base sm:text-lg text-ink-muted max-w-2xl mx-auto leading-relaxed" data-testid="fees-subtext">
              Know exactly what you pay at every stage — from investment to exit. No hidden charges, no surprises.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-12 px-4" data-testid="fees-sections">
        <div className="max-w-4xl mx-auto space-y-6">
          {feeSections.map((section, i) => (
            <motion.div
              key={section.id}
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
            >
              <GlassCard className="p-0 overflow-hidden" data-testid={`fee-section-${section.id}`}>
                <div className="flex items-start gap-3 px-6 py-5 border-b border-vest-g5/15">
                  <div className="w-10 h-10 rounded-xl bg-vest-g5/15 flex items-center justify-center shrink-0 mt-0.5">
                    <section.icon className="w-5 h-5 text-vest-g5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <h2 className="text-base font-semibold text-ink-dark">{section.title}</h2>
                      {section.subtitle && (
                        <span className="text-[10px] px-2 py-0.5 rounded-lg bg-ink-50/5 border border-vest-g5/15 text-ink-muted/70 font-medium">
                          {section.subtitle}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-ink-muted leading-relaxed">{section.desc}</p>
                  </div>
                </div>

                <div className="px-6 py-5 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-6">
                    <div>
                      <p className="text-[10px] uppercase tracking-wider text-ink-muted mb-1">Rate</p>
                      <span className="inline-block px-3 py-1 rounded-xl text-sm font-bold text-vest-g5 bg-vest-g5/10 border border-vest-g5/20" data-testid={`fee-rate-${section.id}`}>
                        {section.rate}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[10px] uppercase tracking-wider text-ink-muted mb-1">When Applied</p>
                      <p className="text-xs text-ink-muted">{section.when}</p>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <p className="text-[10px] uppercase tracking-wider text-ink-muted">What It Covers</p>
                    {section.details.map((detail) => (
                      <div key={detail} className="flex items-start gap-2 text-xs text-ink-muted">
                        <CheckCircle2 className="w-3.5 h-3.5 text-vest-g5/60 shrink-0 mt-0.5" />
                        <span>{detail}</span>
                      </div>
                    ))}
                  </div>

                  <div className="p-3 rounded-xl bg-white/50 border border-vest-g5/15 flex items-start gap-2" data-testid={`fee-example-${section.id}`}>
                    <Calculator className="w-3.5 h-3.5 text-ink-muted/70 mt-0.5 shrink-0" />
                    <p className="text-[11px] text-ink-muted">
                      <span className="text-ink-muted font-medium">{section.example.label}</span>
                      {" = "}
                      <span className="text-vest-g5 font-semibold">{section.example.value}</span>
                    </p>
                  </div>
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="py-12 px-4" data-testid="fees-summary-example">
        <div className="max-w-4xl mx-auto">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <GlassCard className="border border-vest-g5/20 bg-gradient-to-br from-vest-g5/5 to-transparent" data-testid="fees-combined-example">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-9 h-9 rounded-xl bg-vest-g5/15 flex items-center justify-center">
                  <Calculator className="w-4.5 h-4.5 text-vest-g5" />
                </div>
                <div>
                  <h2 className="text-base font-semibold text-ink-dark">Combined Fee Example</h2>
                  <p className="text-[10px] text-ink-muted/70">Illustrative — actual fees vary by property</p>
                </div>
              </div>

              <p className="text-sm text-ink-muted mb-5 leading-relaxed" data-testid="fees-example-intro">
                If you invest <span className="text-ink-dark font-semibold">PKR 1,000,000</span>, estimated fees would be detailed before confirmation.
              </p>

              <div className="space-y-2.5">
                {[
                  { label: "Investment Structuring Fee (1.0%)", value: "PKR 10,000", note: "one-time" },
                  { label: "Property Management Fee (1.5%/yr)", value: "PKR 15,000/year", note: "ongoing" },
                  { label: "Platform Fee (0.75%/yr)", value: "PKR 7,500/year", note: "ongoing" },
                  { label: "Exit Window Fee (1.0%)", value: "PKR 10,000", note: "at exit" },
                  { label: "Currency Conversion Spread", value: "PKR 0", note: "PKR deposit — N/A" },
                ].map((row) => (
                  <div key={row.label} className="flex items-center justify-between gap-4" data-testid={`example-line-${row.label.split("(")[0].trim().toLowerCase().replace(/[\s/]+/g, "-")}`}>
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-xs text-ink-muted">{row.label}</span>
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-white/50 border border-vest-g5/15 text-ink-muted shrink-0">{row.note}</span>
                    </div>
                    <span className="text-xs text-ink-dark font-medium whitespace-nowrap">{row.value}</span>
                  </div>
                ))}
              </div>

              <div className="mt-5 pt-4 border-t border-vest-g5/15 flex items-center justify-between">
                <span className="text-xs text-ink-muted">Year 1 total estimated fees</span>
                <span className="text-sm text-vest-g5 font-bold" data-testid="fees-total-year1">~PKR 32,500</span>
              </div>
              <p className="text-[10px] text-ink-muted mt-2">Effective fee rate: ~3.25% of invested capital in Year 1 (lower in subsequent years as one-time fees do not recur).</p>
            </GlassCard>
          </motion.div>
        </div>
      </section>

      <section className="py-12 px-4" data-testid="fees-no-charge">
        <div className="max-w-4xl mx-auto">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <GlassCard data-testid="no-fee-card">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/15 flex items-center justify-center">
                  <Shield className="w-4 h-4 text-emerald-400" />
                </div>
                <h2 className="text-lg font-semibold text-ink-dark">No Additional Charge</h2>
              </div>
              <p className="text-xs text-ink-muted mb-4">The following services are included at no cost:</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {noCharge.map((item) => (
                  <div key={item} className="flex items-start gap-2 text-xs text-ink-muted">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    {item}
                  </div>
                ))}
              </div>
            </GlassCard>
          </motion.div>
        </div>
      </section>

      <section className="py-12 px-4" data-testid="fees-disclaimer">
        <div className="max-w-4xl mx-auto">
          <GlassCard className="border border-vest-g5/20">
            <div className="flex items-start gap-3">
              <Info className="w-4 h-4 text-ink-muted/70 mt-0.5 shrink-0" />
              <div className="text-[10px] text-ink-muted leading-relaxed space-y-2">
                <p>
                  Fee rates and structures are subject to change. Property-specific fees are disclosed on each listing's detail page before you confirm your investment. VestBlock reserves the right to modify fee schedules with advance notice to investors.
                </p>
                <p>
                  All examples are illustrative estimates. Actual fees may vary based on property type, investor tier, holding period, and jurisdiction. Please review all documentation before investing.
                </p>
              </div>
            </div>
          </GlassCard>
        </div>
      </section>

      <CtaSection
        title="Invest with Full"
        highlight="Transparency"
        subtitle="Every fee is disclosed on the property listing before you confirm. No surprises, no hidden costs."
        actions={[
          { label: "Create Account", href: "/register" },
          { label: "ROI Calculator", href: "/pk/roi-calculator", variant: "secondary" },
        ]}
        testId="fees-cta"
      />
    </MarketingLayout>
  );
}
