import { Link } from "wouter";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { SectionHeader } from "@/components/marketing/section-header";
import { CtaSection } from "@/components/marketing/cta-section";
import {
  Layers,
  ArrowRight,
  ClipboardCheck,
  Scale,
  Coins,
  ArrowLeftRight,
  PieChart,
  Droplets,
  Eye,
  ShieldCheck,
  Database,
  FileCode,
  ScanFace,
} from "lucide-react";

const processSteps = [
  { icon: ClipboardCheck, title: "Property Valuation", desc: "Independent third-party valuation and due diligence to establish fair market value." },
  { icon: Scale, title: "Legal Structuring", desc: "SPV formation and SECP-compliant legal framework for tokenized ownership." },
  { icon: Coins, title: "Token Issuance", desc: "Digital security tokens created on blockchain, each representing fractional ownership." },
  { icon: ArrowLeftRight, title: "Trading", desc: "Tokens can be traded on VestBlock's regulated secondary marketplace during exit windows." },
];

const benefits = [
  { icon: PieChart, title: "Fractional Access", desc: "Own a piece of premium real estate from just PKR 50,000 instead of millions." },
  { icon: Droplets, title: "Liquidity", desc: "Trade your tokens during quarterly exit windows — no more waiting years to sell property." },
  { icon: Eye, title: "Transparency", desc: "All ownership records, transactions, and distributions are verifiable on-chain." },
  { icon: ShieldCheck, title: "Compliance", desc: "Every token issued under SECP regulations with full KYC/AML compliance." },
];

const techStack = [
  { icon: Database, title: "Blockchain Infrastructure", desc: "Immutable distributed ledger ensures every ownership record is permanent, transparent, and tamper-proof across all tokenized properties." },
  { icon: FileCode, title: "Smart Contracts", desc: "Automated distribution logic, transfer restrictions, and compliance rules enforced by self-executing smart contracts — no intermediaries required." },
  { icon: ScanFace, title: "KYC / AML Integration", desc: "NADRA-powered digital identity verification and real-time anti-money laundering screening to meet SECP and FATF requirements." },
];

export default function TokenizationPage() {
  return (
    <MarketingLayout>
      <PageMeta title="Tokenization" description="Understand how VestBlock tokenizes real estate using blockchain technology, SPV structures, and SECP-compliant digital securities." path="/pk/tokenization" />
      <section className="relative overflow-hidden py-24 sm:py-32 px-4 gradient-section-blue" data-testid="token-hero">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium mb-6 text-vest-g5 border border-vest-g5/15" data-testid="token-badge">
            Learn
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-6" data-testid="token-headline">
            What Is Real Estate{" "}
            <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Tokenization?</span>
          </h1>
          <p className="text-lg text-ink-muted max-w-2xl mx-auto leading-relaxed" data-testid="token-subtext">
            Tokenization converts real property ownership into digital security tokens on blockchain, enabling fractional investment, enhanced liquidity, and full regulatory compliance.
          </p>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="what-is-section">
        <div className="max-w-7xl mx-auto">
          <div className="glass rounded-md p-8 lg:p-12" data-testid="what-is-card">
            <div className="flex flex-col lg:flex-row lg:items-center gap-8">
              <div className="w-20 h-20 rounded-md flex items-center justify-center shrink-0" style={{ background: "rgba(30,43,255,0.08)" }}>
                <Layers className="w-10 h-10 text-vest-g5" />
              </div>
              <div>
                <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark mb-4">Understanding <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Tokenization</span></h2>
                <p className="text-ink-muted leading-relaxed mb-4">
                  Real estate tokenization is the process of creating digital tokens on a blockchain that represent ownership shares in a physical property. Each token is a legally-backed digital security, registered under Pakistan's SECP framework.
                </p>
                <p className="text-ink-muted leading-relaxed">
                  Instead of purchasing an entire property for PKR 50M+, investors can buy tokens representing fractional ownership starting from PKR 50,000. Token holders receive proportional rental income and benefit from property appreciation — all managed digitally through smart contracts.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 px-4 " data-testid="process-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="The Process"
            title="From Property to"
            highlight="Token"
            description="A four-stage process to convert physical real estate into tradeable digital securities."
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {processSteps.map((step, i) => (
              <div key={step.title} className="relative" data-testid={`process-step-${i + 1}`}>
                <div className="glass rounded-md p-6  transition-all duration-300 h-full">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-md flex items-center justify-center" style={{ background: "rgba(30,43,255,0.08)" }}>
                      <step.icon className="w-5 h-5 text-vest-g5" />
                    </div>
                    <span className="text-xs font-bold text-ink-muted uppercase tracking-wider">Step {i + 1}</span>
                  </div>
                  <h4 className="text-lg font-semibold text-ink-dark mb-2">{step.title}</h4>
                  <p className="text-sm text-ink-muted leading-relaxed">{step.desc}</p>
                </div>
                {i < processSteps.length - 1 && (
                  <div className="hidden lg:flex absolute top-1/2 -right-3 -translate-y-1/2 z-10">
                    <ArrowRight className="w-5 h-5 text-vest-g5/60" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="benefits-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Advantages"
            title="Benefits of"
            highlight="Tokenization"
            description="Why tokenized real estate is the future of property investment in Pakistan."
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {benefits.map((b) => (
              <div key={b.title} className="glass rounded-md p-6  transition-all duration-300" data-testid={`benefit-${b.title.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="w-10 h-10 rounded-md flex items-center justify-center mb-4" style={{ background: "rgba(30,43,255,0.08)" }}>
                  <b.icon className="w-5 h-5 text-vest-g5" />
                </div>
                <h4 className="text-lg font-semibold text-ink-dark mb-2">{b.title}</h4>
                <p className="text-sm text-ink-muted leading-relaxed">{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4 gradient-section-subtle" data-testid="tech-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Technology"
            title="Powered By"
            highlight="Innovation"
            description="The technology stack behind VestBlock's secure tokenization platform."
          />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {techStack.map((t) => (
              <div key={t.title} className="glass rounded-md p-8  transition-all duration-300" data-testid={`tech-${t.title.toLowerCase().replace(/[\s\/]+/g, "-")}`}>
                <div className="w-12 h-12 rounded-md flex items-center justify-center mb-5" style={{ background: "rgba(30,43,255,0.08)" }}>
                  <t.icon className="w-6 h-6 text-vest-g5" />
                </div>
                <h4 className="text-xl font-semibold text-ink-dark mb-3">{t.title}</h4>
                <p className="text-sm text-ink-muted leading-relaxed">{t.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CtaSection
        title="Ready to Invest in"
        highlight="Tokenized Property?"
        subtitle="Join thousands of investors building wealth through Pakistan's regulated real estate tokens."
        actions={[
          { label: "Start Investing", href: "/register" },
          { label: "Browse Properties", href: "/properties", variant: "secondary" },
        ]}
        testId="token-cta"
      />
    </MarketingLayout>
  );
}
