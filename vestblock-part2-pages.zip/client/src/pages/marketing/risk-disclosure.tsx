import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { SectionHeader } from "@/components/marketing/section-header";
import { Link } from "wouter";
import {
  TrendingDown,
  Droplets,
  Scale,
  Building2,
  Cpu,
  DollarSign,
  AlertTriangle,
  ShieldAlert,
  UserCheck,
  Calendar,
} from "lucide-react";

const riskCategories = [
  {
    id: "market-risk",
    icon: TrendingDown,
    title: "Market Risk",
    description: "Fluctuations in property values due to broader economic conditions.",
    details: [
      "Real estate markets in Pakistan are subject to cyclical fluctuations influenced by macroeconomic conditions, interest rate changes by the State Bank of Pakistan (SBP), inflation, and government fiscal policies.",
      "Property values may decline due to factors such as economic recession, political instability, changes in urban development patterns, or oversupply in specific market segments.",
      "Token prices on the secondary marketplace may not accurately reflect the underlying property value and can be influenced by market sentiment, liquidity conditions, and supply-demand dynamics.",
      "PKR-denominated returns may be affected by domestic inflation rates, which have historically been volatile in Pakistan. Real returns (adjusted for inflation) may differ significantly from nominal returns.",
    ],
  },
  {
    id: "liquidity-risk",
    icon: Droplets,
    title: "Liquidity Risk",
    description: "Difficulty selling tokens quickly at fair market value.",
    details: [
      "Property tokens are not as liquid as publicly traded securities. There is no guarantee that you will be able to sell your tokens at a desired price or at all on the secondary marketplace.",
      "Lock-up periods may apply to certain property tokens, during which you will be unable to sell or transfer your holdings. Lock-up durations vary by property and are specified in offering documents.",
      "The secondary marketplace is subject to trading volume and buyer availability. Low trading volumes may result in wider bid-ask spreads and difficulty executing trades at favorable prices.",
      "In periods of market stress, liquidity may decrease significantly, and you may need to accept a substantial discount to exit your position.",
      "VestBlock does not guarantee buyback of tokens at any price. Exit mechanisms, including property sales or redemption windows, are subject to market conditions and regulatory approvals.",
    ],
  },
  {
    id: "regulatory-risk",
    icon: Scale,
    title: "Regulatory Risk",
    description: "Changes in regulations that may impact token investments.",
    details: [
      "The regulatory framework for digital securities and real estate tokenization in Pakistan is evolving. Changes in SECP regulations, tax laws, or monetary policies by SBP could materially affect your investment.",
      "New regulations may impose additional compliance requirements, restrict certain types of transactions, or change the tax treatment of token investments and rental distributions.",
      "VestBlock's license to operate may be subject to periodic review by SECP. Adverse regulatory actions could limit or suspend platform operations.",
      "International regulatory developments, including FATF recommendations, may affect cross-border transactions and the treatment of digital securities.",
      "Changes in property ownership laws, zoning regulations, or land title registration requirements could impact the underlying real estate assets.",
    ],
  },
  {
    id: "property-risk",
    icon: Building2,
    title: "Property-Specific Risk",
    description: "Risks associated with individual real estate assets.",
    details: [
      "Individual properties may underperform due to factors including vacancy, tenant defaults, structural issues, natural disasters (earthquakes, floods), or adverse changes in the local market.",
      "Rental income depends on occupancy rates, tenant quality, and market rental rates, all of which can fluctuate. There is no guarantee that projected rental yields will be achieved.",
      "Property maintenance, renovation, and capital expenditure costs may exceed projections, reducing net returns to token holders.",
      "Environmental issues, title disputes, or encroachment claims could affect property value and usability. While VestBlock conducts due diligence, not all risks can be identified in advance.",
      "Properties in Pakistan may be subject to acquisition by government for public projects under the Land Acquisition Act 1894, potentially at below-market compensation.",
    ],
  },
  {
    id: "technology-risk",
    icon: Cpu,
    title: "Technology Risk",
    description: "Risks related to blockchain technology and platform systems.",
    details: [
      "The VestBlock platform relies on blockchain technology, which, while robust, is still a relatively new technology that may be subject to unforeseen vulnerabilities, bugs, or exploits.",
      "Smart contract errors or vulnerabilities could result in loss of tokens or inability to execute transactions as intended.",
      "Cybersecurity threats including hacking, phishing, or distributed denial-of-service (DDoS) attacks could compromise user accounts, data, or platform functionality.",
      "System outages, software updates, or infrastructure failures could temporarily prevent access to the platform, executing trades, or receiving distributions.",
      "The loss of private keys or credentials due to user error is irreversible. VestBlock cannot recover lost access credentials in all circumstances.",
    ],
  },
  {
    id: "currency-risk",
    icon: DollarSign,
    title: "Currency Risk",
    description: "Risks arising from PKR value fluctuations for international investors.",
    details: [
      "All investments and returns on VestBlock are denominated in Pakistani Rupees (PKR). International investors or those with foreign currency obligations are exposed to exchange rate fluctuations.",
      "The PKR has historically experienced significant volatility against major currencies (USD, GBP, EUR). Depreciation of the PKR would reduce the value of returns when converted to foreign currencies.",
      "SBP monetary policy decisions, including interest rate changes and foreign exchange reserve management, can impact PKR stability.",
      "Capital controls or restrictions on foreign exchange transactions by SBP could limit the ability to repatriate investment returns to foreign currency accounts.",
      "VestBlock is not responsible for any losses arising from currency fluctuations or changes in foreign exchange regulations.",
    ],
  },
];

export default function RiskDisclosurePage() {
  return (
    <MarketingLayout>
      <PageMeta title="Risk Disclosure" description="Comprehensive risk disclosure for VestBlock investors covering market, liquidity, regulatory, property-specific, technology, and currency risks." path="/pk/risk-disclosure" />
      <section className="relative overflow-hidden py-24 sm:py-32 px-4" data-testid="risk-hero">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center px-3 py-1 rounded-md text-xs font-medium mb-6 text-vest-g5 border border-vest-g5/15" data-testid="risk-badge">
            Investor Awareness
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-6" data-testid="risk-headline">
            Understanding{" "}
            <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Investment Risks</span>
          </h1>
          <p className="text-lg text-ink-muted max-w-2xl mx-auto leading-relaxed" data-testid="risk-subtext">
            Investing in tokenized real estate carries inherent risks. Please read this disclosure carefully before making any investment decisions.
          </p>
          <div className="flex items-center justify-center gap-2 mt-6 text-ink-muted text-sm" data-testid="risk-updated">
            <Calendar className="w-4 h-4" />
            <span>Last updated: February 1, 2026</span>
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="risk-warning-section">
        <div className="max-w-4xl mx-auto">
          <div className="glass rounded-md p-8 mb-12 border" style={{ borderColor: "rgba(255,200,0,0.2)" }} data-testid="risk-warning-card">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-md flex items-center justify-center shrink-0" style={{ background: "rgba(255,200,0,0.1)" }}>
                <AlertTriangle className="w-5 h-5" style={{ color: "#ffd700" }} />
              </div>
              <div>
                <h3 className="text-ink-dark font-semibold mb-2">Important Warning</h3>
                <p className="text-ink-muted text-sm leading-relaxed">
                  Capital at risk. The value of your investment can go down as well as up, and you may receive back less than your original investment. Tokenized real estate investments are not deposits and are not covered by any deposit insurance or guarantee scheme. Past performance is not a reliable indicator of future results.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-4 px-4" data-testid="risk-categories-section">
        <div className="max-w-4xl mx-auto">
          <SectionHeader
            badge="Risk Categories"
            title="Types of"
            highlight="Investment Risk"
            description="Each category of risk may affect your investment differently. Understanding these risks is essential before investing."
          />
          <div className="space-y-8">
            {riskCategories.map((risk) => {
              const Icon = risk.icon;
              return (
                <div key={risk.id} className="glass rounded-md p-8" data-testid={`risk-card-${risk.id}`}>
                  <div className="flex items-start gap-4 mb-5">
                    <div className="w-12 h-12 rounded-md flex items-center justify-center shrink-0" style={{ background: "rgba(30,43,255,0.08)" }}>
                      <Icon className="w-6 h-6 text-vest-g5" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-ink-dark" data-testid={`risk-title-${risk.id}`}>{risk.title}</h3>
                      <p className="text-vest-g5/60 text-sm mt-1">{risk.description}</p>
                    </div>
                  </div>
                  <div className="space-y-3 ml-16">
                    {risk.details.map((detail, idx) => (
                      <p key={idx} className="text-ink-muted text-sm leading-relaxed">
                        {detail}
                      </p>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <div className="max-w-4xl mx-auto px-4 py-8"><div className="border-t border-vest-g5/10" /></div>

      <section className="py-12 px-4 " data-testid="suitability-section">
        <div className="max-w-4xl mx-auto">
          <SectionHeader
            badge="Know Yourself"
            title="Investment"
            highlight="Suitability"
            description="Before investing, assess whether tokenized real estate is appropriate for your financial situation."
          />
          <div className="glass rounded-md p-8" data-testid="suitability-card">
            <div className="flex items-start gap-4 mb-6">
              <div className="w-10 h-10 rounded-md flex items-center justify-center shrink-0" style={{ background: "rgba(30,43,255,0.08)" }}>
                <UserCheck className="w-5 h-5 text-vest-g5" />
              </div>
              <h3 className="text-ink-dark font-semibold text-lg">Is Tokenized Real Estate Right for You?</h3>
            </div>
            <div className="space-y-4 text-ink-muted text-sm leading-relaxed">
              <p>Tokenized real estate investment may be suitable for you if:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>You have a medium to long-term investment horizon (3-7+ years)</li>
                <li>You can afford to lose your entire investment without affecting your financial stability</li>
                <li>You are seeking portfolio diversification beyond traditional stocks, bonds, and bank deposits</li>
                <li>You understand and accept the illiquid nature of real estate investments</li>
                <li>You have reviewed and understood all risk factors described in this disclosure</li>
              </ul>
              <p className="mt-4">Tokenized real estate may NOT be suitable for you if:</p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>You need immediate liquidity or cannot commit capital for extended periods</li>
                <li>You are relying on investment returns for essential living expenses</li>
                <li>You are not comfortable with the possibility of losing your invested capital</li>
                <li>You do not have sufficient knowledge of real estate markets or digital securities</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="risk-disclaimer-section">
        <div className="max-w-4xl mx-auto">
          <div className="glass rounded-md p-8" data-testid="risk-disclaimer-card">
            <div className="flex items-start gap-4 mb-4">
              <ShieldAlert className="w-6 h-6 text-vest-g5 shrink-0 mt-0.5" />
              <h3 className="text-ink-dark font-semibold text-lg">General Disclaimer</h3>
            </div>
            <div className="space-y-3 text-ink-muted text-sm leading-relaxed">
              <p>
                This risk disclosure does not purport to disclose all risks and other aspects of investing through the VestBlock platform. It is not intended as financial, legal, or tax advice. Prospective investors should consult with qualified financial advisors, legal counsel, and tax professionals before making any investment decisions.
              </p>
              <p>
                VestBlock (Pvt.) Ltd. operates under the regulatory oversight of the Securities and Exchange Commission of Pakistan (SECP). The issuance of property tokens is subject to SECP regulations and does not constitute an offer of conventional securities.
              </p>
              <p>
                By proceeding with any investment on the VestBlock platform, you acknowledge that you have read, understood, and accepted all risks described in this disclosure and in the specific offering documents for each property.
              </p>
            </div>
          </div>

          <div className="mt-12 text-center" data-testid="risk-footer-links">
            <p className="text-ink-muted text-sm">
              See also:{" "}
              <Link href="/terms" className="text-vest-g5 hover:underline" data-testid="risk-terms-link">
                Terms of Service
              </Link>
              {" | "}
              <Link href="/privacy" className="text-vest-g5 hover:underline" data-testid="risk-privacy-link">
                Privacy Policy
              </Link>
            </p>
          </div>
        </div>
      </section>
    </MarketingLayout>
  );
}
