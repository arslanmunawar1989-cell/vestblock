import { MarketingLayout } from "@/components/marketing/layout";
import { MarketingHero } from "@/components/marketing/marketing-hero";
import { GlassCard } from "@/components/marketing/glass-card";
import { PageMeta } from "@/components/marketing/page-meta";
import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  FileText, Shield, AlertTriangle, Cookie, Lock, Scale, ArrowRight, Calendar,
} from "lucide-react";

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const docs = [
  { icon: FileText, title: "Terms of Service", href: "/terms", desc: "Your legal agreement with VestBlock covering account usage, investment terms, fees, liability, and dispute resolution under Pakistani law.", updated: "February 1, 2026" },
  { icon: Shield, title: "Privacy Policy", href: "/privacy", desc: "How we collect, use, store, and protect your personal information under PECA 2016, SECP regulations, and the proposed Data Protection Bill.", updated: "February 1, 2026" },
  { icon: Cookie, title: "Cookie Policy", href: "/legal/cookies", desc: "Details on essential, analytics, and preference cookies used on the VestBlock platform, and how to manage your cookie settings.", updated: "February 1, 2026" },
  { icon: AlertTriangle, title: "Risk Disclosure", href: "/risk-disclosure", desc: "Comprehensive disclosure of investment risks including market, liquidity, regulatory, property-specific, technology, and currency risks.", updated: "February 1, 2026" },
  { icon: Lock, title: "Security", href: "/security", desc: "Our enterprise-grade security infrastructure, certifications (ISO 27001, PCI DSS, SOC 2), and responsible disclosure programme.", updated: "February 1, 2026" },
  { icon: Scale, title: "Risk Warnings", href: "/risk-warnings", desc: "Important risk warnings every investor should read before using the platform or making any investment decisions.", updated: "February 1, 2026" },
];

export default function LegalHubPage() {
  return (
    <MarketingLayout>
      <PageMeta
        title="Legal & Compliance"
        description="Access VestBlock's legal documents including Terms of Service, Privacy Policy, Cookie Policy, Risk Disclosure, and Security practices. SECP-regulated platform."
        path="/pk/legal"
      />

      <MarketingHero
        badge="Legal"
        title="Legal &"
        highlight="Compliance"
        subtitle="Access all VestBlock legal documents, policies, and regulatory disclosures in one place."
        testIdPrefix="legal"
      />

      <section className="py-16 px-4" data-testid="legal-docs-section">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {docs.map((d, i) => (
              <motion.div
                key={d.title}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={fadeUp}
                transition={{ duration: 0.4, delay: i * 0.06 }}
              >
                <Link href={d.href} className="block h-full" data-testid={`legal-link-${d.title.toLowerCase().replace(/\s+/g, "-")}`}>
                  <GlassCard className="h-full flex flex-col hover:ring-1 hover:ring-vest-g5/20 transition-all">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-vest-g5/10">
                        <d.icon className="w-5 h-5 text-vest-g5" />
                      </div>
                      <h3 className="text-lg font-semibold text-ink-dark">{d.title}</h3>
                    </div>
                    <p className="text-sm text-ink-muted/70 leading-relaxed flex-1">{d.desc}</p>
                    <div className="flex items-center justify-between mt-4 pt-3 border-t border-vest-g5/15 flex-wrap gap-2">
                      <span className="text-xs text-ink-muted flex items-center gap-1"><Calendar className="w-3 h-3" /> {d.updated}</span>
                      <span className="text-xs text-vest-g5 flex items-center gap-1">Read <ArrowRight className="w-3 h-3" /></span>
                    </div>
                  </GlassCard>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-4" data-testid="legal-regulatory-section">
        <div className="max-w-3xl mx-auto">
          <GlassCard>
            <h3 className="text-xl font-bold text-ink-dark mb-4">Regulatory Information</h3>
            <div className="space-y-3 text-sm text-ink-muted leading-relaxed">
              <p>VestBlock (Pvt.) Ltd. is registered in Pakistan and operates under the regulatory oversight of the Securities and Exchange Commission of Pakistan (SECP).</p>
              <p>Company Registration: 0123456-7 | NTN: 1234567-8</p>
              <p>Registered Address: Floor 12, Centaurus Mall, F-8 Markaz, Islamabad 44000, Pakistan</p>
              <p>The issuance of property tokens on this platform is conducted under applicable SECP regulations for digital securities. VestBlock does not provide financial, legal, or tax advice.</p>
              <p className="text-ink-muted text-xs mt-4">For regulatory complaints, contact: compliance@vestblock.pk or write to the SECP at Securities and Exchange Commission of Pakistan, NIC Building, Jinnah Avenue, Islamabad.</p>
            </div>
          </GlassCard>
        </div>
      </section>
    </MarketingLayout>
  );
}
