import { useState, useMemo, useCallback } from "react";
import { Link } from "wouter";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { GlassButton } from "@/components/marketing/glass-button";
import { GlassCard } from "@/components/marketing/glass-card";
import { motion } from "framer-motion";
import {
  Calculator, Home, ArrowRight, Info, Banknote,
  Percent, Clock, TrendingUp, BarChart3, Link2, Check,
} from "lucide-react";

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const propertyPresets = [5000000, 10000000, 20000000, 50000000, 100000000];
const downPaymentPresets = [10, 15, 20, 25, 30];
const tenurePresets = [5, 10, 15, 20, 25];

function formatPKR(value: number) {
  if (value >= 10000000) return `PKR ${(value / 10000000).toFixed(2)} Cr`;
  if (value >= 100000) return `PKR ${(value / 100000).toFixed(2)} L`;
  return `PKR ${Math.round(value).toLocaleString()}`;
}

function parseQueryParams(): Record<string, number> {
  const params = new URLSearchParams(window.location.search);
  const result: Record<string, number> = {};
  params.forEach((val, key) => {
    const num = parseFloat(val);
    if (!isNaN(num)) result[key] = num;
  });
  return result;
}

function buildShareURL(
  propertyValue: number,
  downPct: number,
  rate: number,
  tenure: number
): string {
  const base = window.location.origin + window.location.pathname;
  const params = new URLSearchParams({
    value: String(propertyValue),
    down: String(downPct),
    rate: String(rate),
    tenure: String(tenure),
  });
  return `${base}?${params.toString()}`;
}

export default function MortgageCalculatorPage() {
  const qp = parseQueryParams();

  const [propertyValue, setPropertyValue] = useState(qp.value || 20000000);
  const [downPct, setDownPct] = useState(qp.down || 20);
  const [rate, setRate] = useState(qp.rate || 22);
  const [tenure, setTenure] = useState(qp.tenure || 15);
  const [copied, setCopied] = useState(false);

  const results = useMemo(() => {
    const downPayment = propertyValue * (downPct / 100);
    const loanAmount = propertyValue - downPayment;
    const monthlyRate = rate / 100 / 12;
    const totalMonths = tenure * 12;

    let emi: number;
    if (monthlyRate === 0) {
      emi = loanAmount / totalMonths;
    } else {
      emi = loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, totalMonths)) /
        (Math.pow(1 + monthlyRate, totalMonths) - 1);
    }

    const totalPayment = emi * totalMonths;
    const totalInterest = totalPayment - loanAmount;
    const principalPct = (loanAmount / totalPayment) * 100;
    const interestPct = (totalInterest / totalPayment) * 100;

    const yearlyBreakdown: { year: number; principalPaid: number; interestPaid: number; balance: number }[] = [];
    let balance = loanAmount;
    for (let y = 1; y <= Math.min(tenure, 30); y++) {
      let yearPrincipal = 0;
      let yearInterest = 0;
      for (let m = 0; m < 12; m++) {
        const interestPortion = balance * monthlyRate;
        const principalPortion = emi - interestPortion;
        yearPrincipal += principalPortion;
        yearInterest += interestPortion;
        balance = Math.max(0, balance - principalPortion);
      }
      yearlyBreakdown.push({
        year: y,
        principalPaid: yearPrincipal,
        interestPaid: yearInterest,
        balance,
      });
    }

    const rateScenarios = [-3, 0, 3].map((adj) => {
      const adjRate = Math.max(1, rate + adj);
      const mr = adjRate / 100 / 12;
      let e: number;
      if (mr === 0) {
        e = loanAmount / totalMonths;
      } else {
        e = loanAmount * (mr * Math.pow(1 + mr, totalMonths)) /
          (Math.pow(1 + mr, totalMonths) - 1);
      }
      const tp = e * totalMonths;
      const ti = tp - loanAmount;
      return {
        label: adj === -3 ? "Rate -3%" : adj === 0 ? "Current Rate" : "Rate +3%",
        rate: adjRate,
        emi: e,
        totalPayment: tp,
        totalInterest: ti,
      };
    });

    return { downPayment, loanAmount, emi, totalPayment, totalInterest, principalPct, interestPct, yearlyBreakdown, rateScenarios };
  }, [propertyValue, downPct, rate, tenure]);

  const handleShare = useCallback(() => {
    const url = buildShareURL(propertyValue, downPct, rate, tenure);
    navigator.clipboard.writeText(url).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }).catch(() => {
      prompt("Copy this URL:", url);
    });
  }, [propertyValue, downPct, rate, tenure]);

  return (
    <MarketingLayout>
      <PageMeta title="Mortgage Calculator" description="Calculate mortgage payments for real estate investments in Pakistan. Compare financing options and plan your property purchase." path="/pk/mortgage-calculator" />
      <section className="relative py-20 sm:py-28 px-4 overflow-hidden" data-testid="mortgage-hero">
        <div className="absolute inset-0 bg-gradient-to-b from-vest-g5/5 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div variants={fadeUp} initial="hidden" animate="visible">
            <span className="inline-flex items-center px-3.5 py-1.5 rounded-2xl text-xs font-medium mb-6 text-vest-g5 bg-vest-g5/10 border border-vest-g5/20" data-testid="mortgage-badge">
              Pakistan Rates
            </span>
            <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-5" data-testid="mortgage-headline">
              Mortgage <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Calculator</span>
            </h1>
            <p className="text-base sm:text-lg text-ink-muted max-w-2xl mx-auto leading-relaxed" data-testid="mortgage-subtext">
              Model illustrative monthly payments for Pakistani property financing. Default rates reflect approximate SBP benchmark ranges — adjust for your bank's offer. This is not financial advice.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="px-4 pb-16" data-testid="mortgage-calculator-section">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            <div className="lg:col-span-2 space-y-5">
              <motion.div variants={fadeUp} initial="hidden" animate="visible">
                <GlassCard data-testid="mortgage-inputs-card">
                  <h2 className="text-base font-semibold text-ink-dark mb-5 flex items-center gap-2">
                    <Calculator className="w-4 h-4 text-vest-g5" /> Inputs
                  </h2>

                  <div className="space-y-5">
                    <div>
                      <label className="text-xs font-medium text-ink-muted mb-2 block" htmlFor="mort-value">Property Value (PKR)</label>
                      <input
                        id="mort-value"
                        data-testid="input-property-value"
                        type="number"
                        min={1000000}
                        max={1000000000}
                        step={500000}
                        value={propertyValue}
                        onChange={(e) => setPropertyValue(Math.max(1000000, Number(e.target.value)))}
                        className="w-full px-4 py-2.5 rounded-xl bg-white/50 border border-vest-g5/15 text-ink-dark text-sm focus:outline-none focus:border-vest-g5/50 transition"
                      />
                      <div className="flex flex-wrap gap-1.5 mt-2">
                        {propertyPresets.map((p) => (
                          <button
                            key={p}
                            onClick={() => setPropertyValue(p)}
                            data-testid={`preset-value-${p}`}
                            className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition border ${
                              propertyValue === p
                                ? "bg-vest-g5/20 border-vest-g5/30 text-vest-g5"
                                : "bg-white/50 border-vest-g5/15 text-ink-muted/70 hover:text-ink-muted"
                            }`}
                          >
                            {p >= 10000000 ? `${p / 10000000} Cr` : `${p / 100000}L`}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-medium text-ink-muted mb-2 flex items-center justify-between" htmlFor="mort-down">
                        <span>Down Payment</span>
                        <span className="text-vest-g5 font-bold">{downPct}% ({formatPKR(propertyValue * downPct / 100)})</span>
                      </label>
                      <input
                        id="mort-down"
                        data-testid="input-down-payment"
                        type="range"
                        min={5}
                        max={50}
                        step={5}
                        value={downPct}
                        onChange={(e) => setDownPct(Number(e.target.value))}
                        className="w-full accent-[#1E2BFF]"
                      />
                      <div className="flex flex-wrap gap-1.5 mt-2">
                        {downPaymentPresets.map((p) => (
                          <button
                            key={p}
                            onClick={() => setDownPct(p)}
                            data-testid={`preset-down-${p}`}
                            className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition border ${
                              downPct === p
                                ? "bg-vest-g5/20 border-vest-g5/30 text-vest-g5"
                                : "bg-white/50 border-vest-g5/15 text-ink-muted/70 hover:text-ink-muted"
                            }`}
                          >
                            {p}%
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-medium text-ink-muted mb-2 flex items-center justify-between" htmlFor="mort-rate">
                        <span>Interest Rate (%/yr)</span>
                        <span className="text-vest-g5 font-bold">{rate}%</span>
                      </label>
                      <input
                        id="mort-rate"
                        data-testid="input-rate"
                        type="range"
                        min={5}
                        max={35}
                        step={0.5}
                        value={rate}
                        onChange={(e) => setRate(Number(e.target.value))}
                        className="w-full accent-[#1E2BFF]"
                      />
                      <div className="flex justify-between text-[10px] text-ink-muted mt-0.5">
                        <span>5%</span><span>20%</span><span>35%</span>
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-medium text-ink-muted mb-2 block">Loan Tenure</label>
                      <div className="flex flex-wrap gap-1.5">
                        {tenurePresets.map((y) => (
                          <button
                            key={y}
                            onClick={() => setTenure(y)}
                            data-testid={`preset-tenure-${y}`}
                            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition border ${
                              tenure === y
                                ? "bg-vest-g5/20 border-vest-g5/30 text-vest-g5"
                                : "bg-white/50 border-vest-g5/15 text-ink-muted/70 hover:text-ink-muted"
                            }`}
                          >
                            {y}Y
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            </div>

            <div className="lg:col-span-3 space-y-5">
              <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ delay: 0.05 }}>
                <GlassCard className="border border-vest-g5/20 bg-gradient-to-br from-vest-g5/5 to-transparent" data-testid="mortgage-results-card">
                  <h2 className="text-base font-semibold text-ink-dark mb-5 flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-vest-g5" /> Payment Summary
                  </h2>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-6">
                    <div className="p-3 rounded-2xl bg-white/50 border border-vest-g5/15 sm:col-span-1 col-span-2" data-testid="result-emi">
                      <p className="text-[10px] text-ink-muted/70 mb-0.5">Monthly EMI</p>
                      <p className="text-xl font-bold text-vest-g5">{formatPKR(results.emi)}</p>
                    </div>
                    <div className="p-3 rounded-2xl bg-white/50 border border-vest-g5/15" data-testid="result-loan">
                      <p className="text-[10px] text-ink-muted/70 mb-0.5">Loan Amount</p>
                      <p className="text-lg font-bold text-ink-dark">{formatPKR(results.loanAmount)}</p>
                    </div>
                    <div className="p-3 rounded-2xl bg-white/50 border border-vest-g5/15" data-testid="result-down">
                      <p className="text-[10px] text-ink-muted/70 mb-0.5">Down Payment</p>
                      <p className="text-lg font-bold text-ink-dark">{formatPKR(results.downPayment)}</p>
                    </div>
                    <div className="p-3 rounded-2xl bg-white/50 border border-vest-g5/15" data-testid="result-total-payment">
                      <p className="text-[10px] text-ink-muted/70 mb-0.5">Total Payment</p>
                      <p className="text-lg font-bold text-ink-dark">{formatPKR(results.totalPayment)}</p>
                    </div>
                    <div className="p-3 rounded-2xl bg-white/50 border border-vest-g5/15" data-testid="result-total-interest">
                      <p className="text-[10px] text-ink-muted/70 mb-0.5">Total Interest</p>
                      <p className="text-lg font-bold text-ink-dark">{formatPKR(results.totalInterest)}</p>
                    </div>
                    <div className="p-3 rounded-2xl bg-white/50 border border-vest-g5/15" data-testid="result-interest-ratio">
                      <p className="text-[10px] text-ink-muted/70 mb-0.5">Interest / Principal</p>
                      <p className="text-sm font-bold text-ink-dark">{results.interestPct.toFixed(0)}% / {results.principalPct.toFixed(0)}%</p>
                    </div>
                  </div>

                  <div className="w-full h-3 rounded-full overflow-hidden bg-white/60 mb-2" data-testid="payment-bar">
                    <div
                      className="h-full bg-vest-g5 rounded-full transition-all"
                      style={{ width: `${results.principalPct}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-ink-muted/70">
                    <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-vest-g5" /> Principal ({results.principalPct.toFixed(0)}%)</span>
                    <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-white/60" /> Interest ({results.interestPct.toFixed(0)}%)</span>
                  </div>
                </GlassCard>
              </motion.div>

              <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ delay: 0.1 }}>
                <GlassCard className="p-0 overflow-hidden" data-testid="mortgage-rate-scenarios">
                  <div className="px-6 py-4 border-b border-vest-g5/15 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-vest-g5" />
                    <h3 className="text-sm font-semibold text-ink-dark">Rate Sensitivity</h3>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full" data-testid="rate-scenario-table">
                      <thead>
                        <tr className="border-b border-vest-g5/15">
                          <th className="text-left py-3 px-5 text-[11px] font-semibold text-ink-muted">Scenario</th>
                          <th className="text-center py-3 px-4 text-[11px] font-semibold text-ink-muted">Rate</th>
                          <th className="text-center py-3 px-4 text-[11px] font-semibold text-ink-muted">Monthly EMI</th>
                          <th className="text-center py-3 px-4 text-[11px] font-semibold text-ink-muted">Total Payment</th>
                          <th className="text-center py-3 px-4 text-[11px] font-semibold text-ink-muted">Total Interest</th>
                        </tr>
                      </thead>
                      <tbody>
                        {results.rateScenarios.map((s) => (
                          <tr
                            key={s.label}
                            className={`border-b border-vest-g5/15 ${s.label === "Current Rate" ? "bg-vest-g5/5" : ""}`}
                            data-testid={`rate-row-${s.label.toLowerCase().replace(/[\s+%]+/g, "-")}`}
                          >
                            <td className="py-3 px-5 text-xs font-medium text-ink-muted">{s.label}</td>
                            <td className="py-3 px-4 text-xs text-ink-muted text-center">{s.rate}%</td>
                            <td className="py-3 px-4 text-xs text-ink-muted text-center">{formatPKR(s.emi)}</td>
                            <td className="py-3 px-4 text-xs text-ink-muted text-center">{formatPKR(s.totalPayment)}</td>
                            <td className="py-3 px-4 text-xs text-ink-muted text-center">{formatPKR(s.totalInterest)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </GlassCard>
              </motion.div>

              <motion.div variants={fadeUp} initial="hidden" animate="visible" transition={{ delay: 0.12 }}>
                <GlassCard className="p-0 overflow-hidden" data-testid="mortgage-amortization">
                  <div className="px-6 py-4 border-b border-vest-g5/15 flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 text-vest-g5" />
                    <h3 className="text-sm font-semibold text-ink-dark">Yearly Amortization</h3>
                  </div>
                  <div className="overflow-x-auto max-h-80 overflow-y-auto">
                    <table className="w-full" data-testid="amortization-table">
                      <thead className="sticky top-0 bg-white/40">
                        <tr className="border-b border-vest-g5/15">
                          <th className="text-left py-3 px-5 text-[11px] font-semibold text-ink-muted">Year</th>
                          <th className="text-center py-3 px-4 text-[11px] font-semibold text-ink-muted">Principal Paid</th>
                          <th className="text-center py-3 px-4 text-[11px] font-semibold text-ink-muted">Interest Paid</th>
                          <th className="text-center py-3 px-4 text-[11px] font-semibold text-ink-muted">Balance</th>
                        </tr>
                      </thead>
                      <tbody>
                        {results.yearlyBreakdown.map((row) => (
                          <tr key={row.year} className="border-b border-vest-g5/15" data-testid={`amort-year-${row.year}`}>
                            <td className="py-2.5 px-5 text-xs font-medium text-ink-muted">{row.year}</td>
                            <td className="py-2.5 px-4 text-xs text-ink-muted text-center">{formatPKR(row.principalPaid)}</td>
                            <td className="py-2.5 px-4 text-xs text-ink-muted text-center">{formatPKR(row.interestPaid)}</td>
                            <td className="py-2.5 px-4 text-xs text-ink-muted text-center">{formatPKR(row.balance)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </GlassCard>
              </motion.div>

              <div className="flex items-center gap-3">
                <button
                  onClick={handleShare}
                  data-testid="button-share-mortgage"
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-medium bg-white/50 border border-vest-g5/15 text-ink-muted hover:text-ink-dark hover:border-vest-g5/30 transition"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Link2 className="w-3.5 h-3.5" />}
                  {copied ? "Link Copied" : "Share This Estimate"}
                </button>
                <Link href="/roi-calculator" className="text-xs text-ink-muted/70 hover:text-vest-g5 transition" data-testid="link-roi">
                    ROI Calculator
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="px-4 pb-12" data-testid="mortgage-disclaimer">
        <div className="max-w-5xl mx-auto">
          <GlassCard className="border border-vest-g5/20">
            <div className="flex items-start gap-3">
              <Info className="w-4 h-4 text-ink-muted/70 mt-0.5 shrink-0" />
              <div className="text-[10px] text-ink-muted leading-relaxed space-y-2">
                <p>
                  This calculator provides illustrative estimates only and does not constitute a loan offer, pre-approval, or financial advice. Actual mortgage terms, eligibility, and rates are determined by your bank or financial institution. Default rate reflects current SBP benchmark ranges and may not match specific bank offers.
                </p>
                <p>
                  Property financing in Pakistan is subject to SBP prudential regulations, individual bank policies, and credit assessment. Processing fees, insurance, and government charges are not included in this estimate. Consult your bank or a qualified financial advisor for precise figures.
                </p>
              </div>
            </div>
          </GlassCard>
        </div>
      </section>

      <section className="py-12 px-4" data-testid="mortgage-cta">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>
            <GlassCard className="border border-vest-g5/20 bg-gradient-to-br from-vest-g5/5 to-transparent py-10">
              <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark mb-3" data-testid="mortgage-cta-title">
                Consider Tokenized <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Investing</span> Instead
              </h2>
              <p className="text-sm text-ink-muted mb-6 max-w-md mx-auto">
                Invest in Pakistani real estate from PKR 50,000 — no mortgage required, no bank approval needed.
              </p>
              <div className="flex flex-wrap items-center justify-center gap-3">
                <Link href="/properties">
                  <GlassButton data-testid="mortgage-cta-properties">Browse Properties <ArrowRight className="w-4 h-4" /></GlassButton>
                </Link>
                <Link href="/how-it-works">
                  <GlassButton variant="secondary" data-testid="mortgage-cta-hiw">How It Works</GlassButton>
                </Link>
              </div>
            </GlassCard>
          </motion.div>
        </div>
      </section>
    </MarketingLayout>
  );
}
