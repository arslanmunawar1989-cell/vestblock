import { MarketingLayout } from "@/components/marketing/layout";
import { MarketingHero } from "@/components/marketing/marketing-hero";
import { GlassCard } from "@/components/marketing/glass-card";
import { PageMeta } from "@/components/marketing/page-meta";
import { Link } from "wouter";
import { Calendar } from "lucide-react";

const cookieTypes = [
  {
    category: "Essential Cookies",
    required: true,
    cookies: [
      { name: "session_id", purpose: "Maintains your login session", duration: "Session" },
      { name: "csrf_token", purpose: "Prevents cross-site request forgery attacks", duration: "Session" },
      { name: "vb_region", purpose: "Stores your selected region (PK/AE)", duration: "1 year" },
      { name: "auth_token", purpose: "Authentication and authorization", duration: "7 days" },
    ],
  },
  {
    category: "Analytics Cookies",
    required: false,
    cookies: [
      { name: "vb_analytics", purpose: "Anonymous usage analytics for platform improvement", duration: "1 year" },
      { name: "vb_session_track", purpose: "Session analytics for understanding user journeys", duration: "30 minutes" },
    ],
  },
  {
    category: "Preference Cookies",
    required: false,
    cookies: [
      { name: "vb_theme", purpose: "Stores your light/dark theme preference", duration: "1 year" },
      { name: "vb_currency", purpose: "Stores your preferred currency display", duration: "1 year" },
      { name: "vb_lang", purpose: "Stores your language preference (EN/UR)", duration: "1 year" },
    ],
  },
];

export default function CookiesPage() {
  return (
    <MarketingLayout>
      <PageMeta
        title="Cookie Policy"
        description="Learn how VestBlock uses cookies for essential platform functionality, analytics, and user preferences. Manage your cookie settings and understand your choices."
        path="/pk/legal/cookies"
      />

      <MarketingHero
        badge="Legal"
        title="Cookie"
        highlight="Policy"
        subtitle="How VestBlock uses cookies and similar technologies to enhance your experience on our platform."
        testIdPrefix="cookies"
      />

      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-center gap-2 mb-12 text-ink-muted text-sm">
            <Calendar className="w-4 h-4" />
            <span>Last updated: February 1, 2026</span>
          </div>

          <GlassCard className="mb-8" data-testid="cookies-intro">
            <h2 className="text-xl font-bold text-ink-dark mb-3">What Are Cookies?</h2>
            <div className="space-y-3 text-sm text-ink-muted leading-relaxed">
              <p>Cookies are small text files stored on your device when you visit a website. They help the website remember your preferences and improve your experience.</p>
              <p>VestBlock uses cookies that are strictly necessary for platform functionality and security. We also use optional cookies for analytics and preferences, which you can control.</p>
            </div>
          </GlassCard>

          <div className="space-y-6">
            {cookieTypes.map((type) => (
              <GlassCard key={type.category} data-testid={`cookies-${type.category.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
                  <h3 className="text-lg font-semibold text-ink-dark">{type.category}</h3>
                  <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${type.required ? "bg-vest-g5/10 text-vest-g5" : "bg-vest-g0/40 text-ink-muted/70"}`}>
                    {type.required ? "Required" : "Optional"}
                  </span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-vest-g5/15">
                        <th className="text-left text-ink-muted/70 font-medium py-2 pr-4">Cookie</th>
                        <th className="text-left text-ink-muted/70 font-medium py-2 pr-4">Purpose</th>
                        <th className="text-left text-ink-muted/70 font-medium py-2">Duration</th>
                      </tr>
                    </thead>
                    <tbody>
                      {type.cookies.map((c) => (
                        <tr key={c.name} className="border-b border-vest-g5/15 last:border-0">
                          <td className="py-2.5 pr-4 text-ink-muted font-mono text-xs">{c.name}</td>
                          <td className="py-2.5 pr-4 text-ink-muted">{c.purpose}</td>
                          <td className="py-2.5 text-ink-muted/70">{c.duration}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </GlassCard>
            ))}
          </div>

          <GlassCard className="mt-8" data-testid="cookies-manage">
            <h3 className="text-lg font-semibold text-ink-dark mb-3">Managing Cookies</h3>
            <div className="space-y-3 text-sm text-ink-muted leading-relaxed">
              <p>You can manage your cookie preferences through your browser settings. Most browsers allow you to block or delete cookies. However, disabling essential cookies may affect platform functionality, including login and security features.</p>
              <p>For more information on managing cookies in your browser, visit your browser's help documentation.</p>
            </div>
          </GlassCard>

          <div className="mt-8 text-center" data-testid="cookies-footer-links">
            <p className="text-ink-muted text-sm">
              See also:{" "}
              <Link href="/privacy" className="text-vest-g5 hover:underline">Privacy Policy</Link>
              {" | "}
              <Link href="/terms" className="text-vest-g5 hover:underline">Terms of Service</Link>
              {" | "}
              <Link href="/legal" className="text-vest-g5 hover:underline">All Legal Documents</Link>
            </p>
          </div>
        </div>
      </section>
    </MarketingLayout>
  );
}
