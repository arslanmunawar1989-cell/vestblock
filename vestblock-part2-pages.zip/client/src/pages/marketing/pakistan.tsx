import { Link } from "wouter";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { SectionHeader } from "@/components/marketing/section-header";
import { CtaSection } from "@/components/marketing/cta-section";
import {
  MapPin,
  TrendingUp,
  Building2,
  Users,
  Wallet,
  ShieldCheck,
  Smartphone,
  Landmark,
  Globe,
  ArrowRight,
  CheckCircle2,
  BarChart3,
  Home,
  CreditCard,
  Banknote,
  Radio,
} from "lucide-react";

const marketStats = [
  { icon: Wallet, value: "PKR 2.8B+", label: "Assets Under Management" },
  { icon: TrendingUp, value: "40%", label: "Year-over-Year Growth", suffix: "YoY" },
  { icon: MapPin, value: "45+", label: "Cities Covered" },
  { icon: Users, value: "10,000+", label: "Verified Investors" },
  { icon: Building2, value: "50+", label: "Tokenized Properties" },
  { icon: Home, value: "PKR 50K", label: "Minimum Investment" },
];

const cities = [
  { name: "Karachi", properties: "18", desc: "Pakistan's financial hub. Commercial and residential properties across DHA, Clifton, and Bahria Town.", highlight: true },
  { name: "Lahore", properties: "12", desc: "Cultural capital with booming real estate. Premium properties in Gulberg, DHA, and Johar Town.", highlight: true },
  { name: "Islamabad", properties: "10", desc: "The capital city. Government-backed infrastructure driving property values in F-sectors and DHA.", highlight: true },
  { name: "Faisalabad", properties: "4", desc: "Industrial powerhouse with emerging commercial real estate opportunities and strong rental yields.", highlight: false },
  { name: "Multan", properties: "3", desc: "Southern Punjab's hub with growing urbanization and affordable entry points for investors.", highlight: false },
  { name: "Peshawar", properties: "2", desc: "Gateway to Central Asia with CPEC-driven infrastructure development boosting property values.", highlight: false },
];

const whyPakistan = [
  { icon: Users, title: "Demographic Dividend", desc: "220+ million population with 64% under 30. A young, growing workforce driving housing demand and urbanization across major cities." },
  { icon: Building2, title: "Rapid Urbanization", desc: "Pakistan is urbanizing at 3% annually — one of the fastest rates in South Asia. Urban population expected to reach 50% by 2030." },
  { icon: ShieldCheck, title: "Regulatory Progress", desc: "SECP actively developing frameworks for digital securities. Pakistan moving toward FATF whitelist with improved financial regulations." },
  { icon: TrendingUp, title: "Growing Economy", desc: "Real estate sector contributes 2% to GDP with PKR 50+ trillion in total asset value. Historically 10-20% annual appreciation in key cities." },
];

const regulatoryFramework = [
  { title: "SECP Licensing", desc: "Fully licensed under Securities and Exchange Commission of Pakistan for digital asset issuance and management." },
  { title: "Securities Act 2015", desc: "Compliant with Pakistan's Securities Act 2015 for regulated securities offerings and investor protection." },
  { title: "Companies Act 2017", desc: "SPV structures established under Companies Act 2017 with proper corporate governance frameworks." },
  { title: "AML/CFT Compliance", desc: "Full adherence to Anti-Money Laundering and Counter-Terrorism Financing regulations with NADRA-integrated KYC." },
];

const paymentMethods = [
  { icon: Smartphone, name: "JazzCash", desc: "Pakistan's leading mobile wallet. Instant deposits and withdrawals directly from your JazzCash account." },
  { icon: Radio, name: "Easypaisa", desc: "Telenor's mobile banking platform. Seamless integration for quick and secure transactions." },
  { icon: Landmark, name: "Bank Transfer", desc: "Direct bank transfers from any Pakistani bank. Supports all major banks including HBL, UBL, MCB, and NBP." },
  { icon: CreditCard, name: "IBFT", desc: "Inter-Bank Fund Transfer for instant bank-to-bank payments. Available 24/7 through 1Link network." },
];

export default function PakistanPage() {
  return (
    <MarketingLayout>
      <PageMeta title="Pakistan Market" description="Pakistan's real estate market overview. Population growth, urbanisation trends, and investment opportunities in Karachi, Lahore, Islamabad, and Peshawar." path="/pk/market" />
      <section className="relative overflow-hidden py-24 sm:py-32 px-4" data-testid="pakistan-hero">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium mb-6 text-vest-g5 border border-vest-g5/15" data-testid="pakistan-badge">
            Pakistan Market
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-6" data-testid="pakistan-headline">
            Pakistan's Premier{" "}
            <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Real Estate Platform</span>
          </h1>
          <p className="text-lg sm:text-xl text-ink-muted max-w-2xl mx-auto mb-10 leading-relaxed" data-testid="pakistan-subtext">
            Built for Pakistan. Regulated by SECP. Invest in tokenized real estate across 45+ cities with local payment methods and PKR-denominated investments.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link href="/register" className="px-8 py-3 text-base font-semibold bg-vest-g5 text-ink-dark hover:opacity-90 transition rounded-md inline-flex items-center gap-2" data-testid="pakistan-cta-start">
                              Start Investing <ArrowRight className="w-4 h-4" />
            </Link>
            <Link href="/properties" className="px-8 py-3 text-base font-semibold border border-vest-g5/20 text-ink-dark hover:bg-vest-g0/40 transition rounded-md" data-testid="pakistan-cta-properties">
                              Explore Properties
            </Link>
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="market-stats-section">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {marketStats.map((stat) => (
              <div key={stat.label} className="glass rounded-md p-5 text-center  transition-all duration-300" data-testid={`market-stat-${stat.label.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="w-10 h-10 rounded-md flex items-center justify-center mx-auto mb-3" style={{ background: "rgba(30,43,255,0.08)" }}>
                  <stat.icon className="w-5 h-5 text-vest-g5" />
                </div>
                <div className="text-2xl font-bold text-ink-dark mb-1" data-testid={`stat-value-${stat.label.toLowerCase().replace(/\s+/g, "-")}`}>
                  {stat.value}
                </div>
                <div className="text-xs text-ink-muted">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4 " data-testid="cities-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Coverage"
            title="Key Cities"
            highlight="Across Pakistan"
            description="Invest in premium real estate across Pakistan's top metropolitan areas and emerging markets."
          />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {cities.map((city) => (
              <div
                key={city.name}
                className={`glass rounded-md p-6 transition-all duration-300 ${city.highlight ? " border-vest-g5/20" : ""}`}
                data-testid={`city-${city.name.toLowerCase()}`}
              >
                <div className="flex items-center gap-3 mb-3">
                  <MapPin className="w-5 h-5 text-vest-g5" />
                  <h3 className="text-lg font-bold text-ink-dark">{city.name}</h3>
                  <span className="ml-auto inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium text-vest-g5 border border-vest-g5/15" data-testid={`city-properties-${city.name.toLowerCase()}`}>
                    {city.properties} Properties
                  </span>
                </div>
                <p className="text-ink-muted text-sm leading-relaxed">{city.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="why-pakistan-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Market Opportunity"
            title="Why"
            highlight="Pakistan?"
            description="Pakistan's real estate market presents a compelling investment opportunity driven by demographics, urbanization, and regulatory progress."
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {whyPakistan.map((item) => (
              <div key={item.title} className="glass rounded-md p-8  transition-all duration-300" data-testid={`why-${item.title.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-md flex items-center justify-center shrink-0" style={{ background: "rgba(30,43,255,0.08)" }}>
                    <item.icon className="w-6 h-6 text-vest-g5" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-ink-dark mb-2">{item.title}</h3>
                    <p className="text-ink-muted text-sm leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4 " data-testid="regulatory-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Regulation"
            title="SECP Regulatory"
            highlight="Framework"
            description="VestBlock operates under Pakistan's comprehensive regulatory framework ensuring full investor protection."
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {regulatoryFramework.map((item) => (
              <div key={item.title} className="glass rounded-md p-6  transition-all duration-300" data-testid={`regulatory-${item.title.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-vest-g5 shrink-0 mt-0.5" />
                  <div>
                    <h3 className="text-lg font-bold text-ink-dark mb-2">{item.title}</h3>
                    <p className="text-ink-muted text-sm leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-4" data-testid="payment-methods-section">
        <div className="max-w-7xl mx-auto">
          <SectionHeader
            badge="Payments"
            title="Local Payment"
            highlight="Methods"
            description="Invest using Pakistan's most popular payment platforms. Deposit and withdraw in PKR seamlessly."
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {paymentMethods.map((method) => (
              <div key={method.name} className="glass rounded-md p-6  transition-all duration-300 text-center" data-testid={`payment-${method.name.toLowerCase().replace(/\s+/g, "-")}`}>
                <div className="w-14 h-14 rounded-md flex items-center justify-center mx-auto mb-4" style={{ background: "rgba(30,43,255,0.08)" }}>
                  <method.icon className="w-7 h-7 text-vest-g5" />
                </div>
                <h3 className="text-lg font-bold text-ink-dark mb-2">{method.name}</h3>
                <p className="text-ink-muted text-sm leading-relaxed">{method.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CtaSection
        title="Invest in Pakistan's"
        highlight="Real Estate Future"
        subtitle="Join thousands of Pakistanis building wealth through tokenized property investment. Start with as little as PKR 50,000."
        actions={[
          { label: "Create Free Account", href: "/register" },
        ]}
        testId="pakistan-cta"
      />
    </MarketingLayout>
  );
}
