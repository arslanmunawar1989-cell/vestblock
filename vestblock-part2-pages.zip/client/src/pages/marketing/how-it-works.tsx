import { Link } from "wouter";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { GlassCard } from "@/components/marketing/glass-card";
import { CtaSection } from "@/components/marketing/cta-section";
import { motion } from "framer-motion";
import {
  Search, Wallet, Layers, TrendingUp, DoorOpen,
  CheckCircle2, ShieldCheck, Lock, Server, FileCheck,
  ArrowRight, ArrowDown, Banknote, Clock, BarChart3,
  Building2, Users, Percent,
} from "lucide-react";

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const steps = [
  {
    num: "01",
    label: "Browse",
    icon: Search,
    title: "Browse Verified Properties",
    desc: "Explore a curated portfolio of tokenized Pakistani real estate. Every listing undergoes independent valuation, legal due diligence, and regulatory review before appearing on the platform.",
    example: {
      heading: "Example Listing",
      lines: [
        "Skyline Tower, Clifton Karachi — Commercial",
        "Token price: PKR 25,000",
        "Projected annual yield: 12–15%*",
        "Independent valuation by certified surveyor",
      ],
    },
    details: [
      "Properties across Karachi, Lahore, Islamabad, Faisalabad",
      "Full data room access (valuations, title deeds, projections)",
      "Independent third-party property appraisals",
      "Risk disclosures and fee breakdowns per asset",
    ],
  },
  {
    num: "02",
    label: "Deposit",
    icon: Wallet,
    title: "Fund Your Account",
    desc: "After completing KYC verification (NADRA-integrated, typically under 5 minutes), deposit funds via bank transfer or supported payment methods. Your funds are held in a segregated client account.",
    example: {
      heading: "Deposit Example",
      lines: [
        "Bank transfer: PKR 100,000 via any Pakistani bank",
        "Processing time: same-day for IBFT",
        "No deposit fee charged by VestBlock",
        "Funds visible in wallet within minutes",
      ],
    },
    details: [
      "NADRA-integrated digital KYC — no branch visit required",
      "CNIC and bank account verification",
      "Same-day IBFT settlement",
      "Segregated client account (not co-mingled with platform funds)",
    ],
  },
  {
    num: "03",
    label: "Invest",
    icon: Layers,
    title: "Purchase Property Tokens",
    desc: "Select a property and purchase tokens starting from PKR 50,000. Each token represents a fractional, legally-backed ownership interest in the underlying property, recorded on an immutable ledger.",
    example: {
      heading: "Investment Example",
      lines: [
        "Property: Pearl Gate Villas, DHA Lahore",
        "Investment: PKR 200,000 = 20 tokens at PKR 10,000 each",
        "Ownership: 0.13% fractional interest",
        "Confirmation and token allocation: instant",
      ],
    },
    details: [
      "Minimum investment: PKR 50,000 per property",
      "Instant digital token issuance upon payment",
      "Legally-backed fractional ownership structure",
      "Portfolio diversification across multiple properties",
    ],
  },
  {
    num: "04",
    label: "Earn",
    icon: TrendingUp,
    title: "Receive Distributions",
    desc: "Earn rental income distributions (monthly or quarterly depending on the asset) deposited directly to your VestBlock wallet. Track portfolio performance, distribution history, and projected returns in your dashboard.",
    example: {
      heading: "Distribution Example",
      lines: [
        "Investment: PKR 200,000 at 12% projected annual yield*",
        "Monthly distribution: ~PKR 2,000 (before fees)*",
        "Distributions deposited to your VestBlock wallet",
        "Withdraw to bank or reinvest at your discretion",
      ],
    },
    details: [
      "Monthly or quarterly payout schedules per asset",
      "Automated distribution to your VestBlock wallet",
      "Real-time portfolio dashboard and return tracking",
      "Reinvestment option for compounding",
    ],
  },
  {
    num: "05",
    label: "Exit",
    icon: DoorOpen,
    title: "Exit on Your Terms",
    desc: "Liquidate your position during scheduled exit windows (quarterly for most assets). Submit an exit request, and VestBlock matches you with verified buyers on the secondary marketplace. Proceeds are credited to your wallet after settlement.",
    example: {
      heading: "Exit Example",
      lines: [
        "Holding: 20 tokens, purchased at PKR 10,000 each",
        "Exit after 2 years at PKR 11,500 per token",
        "Proceeds: PKR 230,000 (before exit fee)",
        "Exit fee: 0.5–1.0% depending on tier",
      ],
    },
    details: [
      "Quarterly exit windows for most properties",
      "14–45 day notice period depending on asset",
      "Secondary marketplace matching with verified buyers",
      "Proceeds deposited to wallet; withdraw anytime",
    ],
  },
];

const safeguards = [
  { icon: ShieldCheck, title: "Regulatory Oversight", desc: "Operations designed to align with SECP guidelines for asset tokenization and investor protection." },
  { icon: Lock, title: "Segregated Client Funds", desc: "Investor funds are held in segregated bank accounts, separate from platform operating capital." },
  { icon: Server, title: "Immutable Records", desc: "Token ownership and transaction history recorded on a tamper-resistant distributed ledger." },
  { icon: FileCheck, title: "KYC & AML Compliance", desc: "NADRA-integrated identity verification and ongoing anti-money laundering monitoring for all participants." },
];

const faqs = [
  { q: "What is the minimum investment?", a: "The minimum investment is PKR 50,000, though individual properties may have different minimums. Each property listing displays the exact minimum on its detail page." },
  { q: "How are returns calculated?", a: "Projected returns are based on historical rental data, independent valuations, and market analysis. Actual returns may vary. Past performance is not indicative of future results." },
  { q: "Can I exit my investment early?", a: "Most properties offer quarterly exit windows. Some assets may have a lockup period (typically 6–24 months) before exit eligibility. Details are disclosed on each property's listing page." },
  { q: "Are my funds safe?", a: "Investor funds are held in segregated accounts at regulated Pakistani banks. Platform operations and investor capital are kept separate at all times." },
  { q: "What fees are involved?", a: "Fees vary by property and investor tier. Common fees include management fees (1–2% annually), performance fees on returns above the hurdle rate, and exit fees (0.5–2%). See our Fees page for full details." },
];

export default function HowItWorksPage() {
  return (
    <MarketingLayout>
      <PageMeta title="How It Works" description="Learn how VestBlock tokenizes real estate properties, enabling fractional ownership through blockchain technology. Simple 4-step process from KYC to earning returns." path="/pk/how-it-works" />
      <section className="relative py-24 sm:py-32 px-4 overflow-hidden gradient-section-blue" data-testid="hiw-hero">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-transparent pointer-events-none" />
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div variants={fadeUp} initial="hidden" animate="visible">
            <span className="inline-flex items-center px-3.5 py-1.5 rounded-2xl text-xs font-medium mb-6 text-vest-g5 bg-vest-g5/10 border border-vest-g5/20" data-testid="hiw-badge">
              5-Step Process
            </span>
            <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-5" data-testid="hiw-headline">
              How VestBlock <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Works</span>
            </h1>
            <p className="text-base sm:text-lg text-ink-muted max-w-2xl mx-auto leading-relaxed" data-testid="hiw-subtext">
              From browsing properties to earning distributions and exiting on your terms — invest in tokenized Pakistani real estate in five straightforward steps.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="px-4 pb-6" data-testid="hiw-progress-bar">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between gap-1">
            {steps.map((s, i) => (
              <div key={s.num} className="flex items-center gap-1 flex-1">
                <div className="flex flex-col items-center gap-1.5">
                  <div className="w-10 h-10 rounded-2xl bg-vest-g5/15 border border-vest-g5/25 flex items-center justify-center">
                    <s.icon className="w-4 h-4 text-vest-g5" />
                  </div>
                  <span className="text-[10px] font-medium text-ink-muted hidden sm:block">{s.label}</span>
                </div>
                {i < steps.length - 1 && (
                  <div className="flex-1 h-px bg-gradient-to-r from-vest-g5/30 to-vest-g5/15 mx-1" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 px-4" data-testid="hiw-steps-section">
        <div className="max-w-4xl mx-auto space-y-6">
          {steps.map((s, i) => (
            <motion.div
              key={s.num}
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
            >
              <GlassCard className="p-0 overflow-hidden" data-testid={`step-${s.num}`}>
                <div className="flex items-center gap-3 px-6 py-4 border-b border-vest-g5/15">
                  <span className="text-2xl font-bold text-vest-g5">{s.num}</span>
                  <div className="w-9 h-9 rounded-xl bg-vest-g5/15 flex items-center justify-center">
                    <s.icon className="w-4 h-4 text-vest-g5" />
                  </div>
                  <h3 className="text-lg font-semibold text-ink-dark">{s.title}</h3>
                </div>

                <div className="p-6 space-y-5">
                  <p className="text-sm text-ink-muted leading-relaxed">{s.desc}</p>

                  <div className="p-4 rounded-2xl bg-white/50 border border-vest-g5/15">
                    <p className="text-xs font-semibold text-ink-muted mb-2 flex items-center gap-1.5">
                      <Banknote className="w-3.5 h-3.5 text-vest-g5" /> {s.example.heading}
                    </p>
                    <ul className="space-y-1.5">
                      {s.example.lines.map((line) => (
                        <li key={line} className="text-xs text-ink-muted flex items-start gap-2">
                          <span className="mt-1.5 w-1 h-1 rounded-full bg-vest-g5/60 shrink-0" />
                          {line}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {s.details.map((d) => (
                      <li key={d} className="flex items-start gap-2 text-xs text-ink-muted">
                        <CheckCircle2 className="w-3.5 h-3.5 text-vest-g5 shrink-0 mt-0.5" />
                        {d}
                      </li>
                    ))}
                  </ul>
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="py-16 px-4 gradient-section-blue" data-testid="hiw-safeguards">
        <div className="max-w-4xl mx-auto">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center mb-10">
            <span className="inline-flex items-center px-3.5 py-1.5 rounded-2xl text-xs font-medium mb-4 text-vest-g5 bg-vest-g5/10 border border-vest-g5/20">
              Investor Safeguards
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark mb-3">Built on Trust &amp; <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Compliance</span></h2>
            <p className="text-sm text-ink-muted max-w-xl mx-auto">Your capital and data are protected by institutional-grade infrastructure and regulatory safeguards.</p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {safeguards.map((sf, i) => (
              <motion.div key={sf.title} variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} transition={{ delay: i * 0.05 }}>
                <GlassCard className="flex items-start gap-4 h-full" data-testid={`safeguard-${sf.title.toLowerCase().replace(/[\s&/]+/g, "-")}`}>
                  <div className="w-10 h-10 rounded-xl bg-vest-g5/15 flex items-center justify-center shrink-0">
                    <sf.icon className="w-5 h-5 text-vest-g5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-ink-dark mb-1">{sf.title}</h4>
                    <p className="text-xs text-ink-muted/70 leading-relaxed">{sf.desc}</p>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-4" data-testid="hiw-faq">
        <div className="max-w-4xl mx-auto">
          <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} className="text-center mb-10">
            <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark mb-3">Frequently Asked <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Questions</span></h2>
            <p className="text-sm text-ink-muted">Common questions about investing through VestBlock.</p>
          </motion.div>

          <div className="space-y-3">
            {faqs.map((faq, i) => (
              <motion.div key={i} variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} transition={{ delay: i * 0.03 }}>
                <GlassCard className="p-5" data-testid={`hiw-faq-${i}`}>
                  <h4 className="text-sm font-semibold text-ink-dark mb-2">{faq.q}</h4>
                  <p className="text-xs text-ink-muted leading-relaxed">{faq.a}</p>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-4" data-testid="hiw-disclaimer">
        <div className="max-w-4xl mx-auto">
          <GlassCard className="text-center border border-vest-g5/20">
            <p className="text-[10px] text-ink-muted leading-relaxed max-w-2xl mx-auto mb-1">
              *Projected returns are estimates based on historical data and independent analysis. Actual returns may differ materially from projections. All investments carry risk, including the possible loss of principal. Past performance is not indicative of future results. VestBlock does not guarantee any specific return or outcome. Please review all property documentation and risk disclosures before making an investment decision.
            </p>
          </GlassCard>
        </div>
      </section>

      <CtaSection
        title="Ready to"
        highlight="Get Started?"
        subtitle="Create a free account, complete verification in minutes, and explore available properties."
        actions={[
          { label: "Create Account", href: "/register" },
          { label: "Browse Properties", href: "/properties", variant: "secondary" },
        ]}
        testId="hiw-cta"
      />
    </MarketingLayout>
  );
}
