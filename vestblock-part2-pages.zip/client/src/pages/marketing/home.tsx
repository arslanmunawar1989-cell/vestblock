import { Link } from "wouter";
import { useState, useMemo, useEffect, useRef, useCallback } from "react";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { MarketingAccordion } from "@/components/marketing/marketing-accordion";
import { Button } from "@/components/ui/button";
import { useRegion } from "@/lib/region";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import {
  ArrowRight, ArrowUpRight, ChevronLeft, ChevronRight,
  Search, Wallet, Layers, Banknote, DoorOpen,
  ShieldCheck, Lock, FileText, Scale, Calculator,
  X, Mail, Star, Smartphone, BarChart3, Clock, Download,
  FolderOpen, TrendingUp, LayoutGrid, Link2, ArrowLeftRight, Eye,
  Activity, Users,
} from "lucide-react";
import { PhoneMockup } from "@/components/marketing/phone-mockup";
import { Hero, AnimatedCounter, SectionLabel, fadeUp, stagger } from "@/components/marketing/hero";
import prop1Img from "../../assets/images/property-1.jpg";
import prop2Img from "../../assets/images/property-2.jpg";
import prop3Img from "../../assets/images/property-3.jpg";
import prop4Img from "../../assets/images/property-4.jpg";
import testimonial1Img from "../../assets/images/testimonial-1.jpg";
import testimonial2Img from "../../assets/images/testimonial-2.jpg";

const PIXEL_ROWS = [
  "..........wwwwww..........",
  "..........wDDDDw..........",
  "..........wDDDDw..........",
  ".....wwwwwwDDDDwwwwww.....",
  ".....wDDDDwDDDDwDDDDw.....",
  ".....wDDDDwDDDDwDDDDw.....",
  "..wwwwDDDDwDDDDwDDDDwwww..",
  "..wDDwDDDDwDDDDwDDDDwDDw..",
  "..wDDwDDDDwDDDDwDDDDwDDw..",
  "..wDDwwwwwwwwwwwwwwwwDDw..",
  "..wDDwBBwBBwBBwBBwBBwDDw..",
  "..wDDwBBwBBwBBwBBwBBwDDw..",
  "..wwwwBBwBBwBBwBBwBBwwww..",
  "..wBBwBBwBBwBBwBBwBBwBBw..",
  "..wBBwBBwBBwBBwBBwBBwBBw..",
  "..wBBwBBwBBwBBwBBwBBwBBw..",
  "..wBBwBBwBBwBBwBBwBBwBBw..",
  "..wwwwwwwwwwwwwwwwwwwwwww..",
  "GGGGYYGGGGYYGGGGYYGGGGYY..",
  "YYGGGGYYGGGGYYGGGGYYGGG...",
];

const PX_COLORS: Record<string, string> = {
  w: "#e2e8f0",
  D: "#93a3d1",
  B: "#3b5bdb",
  G: "#22c55e",
  Y: "#facc15",
  ".": "transparent",
};

function PixelBuilding() {
  return (
    <div className="w-full max-w-[260px] aspect-square" data-testid="pixel-building">
      <svg viewBox="0 0 26 20" className="w-full h-full" shapeRendering="crispEdges">
        {PIXEL_ROWS.map((row, y) =>
          row.split("").map((ch, x) =>
            ch !== "." ? (
              <rect key={`${x}-${y}`} x={x} y={y} width={1} height={1} fill={PX_COLORS[ch] || "transparent"} />
            ) : null
          )
        )}
      </svg>
    </div>
  );
}

const marqueeItems = [
  "Fractional Ownership",
  "Monthly Distributions",
  "KYC Verified",
  "SECP Regulated",
  "Structured Exit Windows",
  "Multi-Currency Support",
  "Tokenized Securities",
  "Institutional Grade",
];

const liveActivities = [
  { name: "Ahmed R.", action: "invested", amount: "PKR 250,000", property: "DHA Phase 6 Commercial", city: "Lahore", time: "2 min ago" },
  { name: "Sarah K.", action: "invested", amount: "PKR 500,000", property: "Clifton Block 5 Apartments", city: "Karachi", time: "5 min ago" },
  { name: "Omar F.", action: "invested", amount: "PKR 100,000", property: "F-8 Markaz Office Tower", city: "Islamabad", time: "8 min ago" },
  { name: "Fatima A.", action: "invested", amount: "PKR 750,000", property: "Bahria Town Villas", city: "Rawalpindi", time: "12 min ago" },
  { name: "Hassan M.", action: "received distribution", amount: "PKR 18,500", property: "DHA Phase 6 Commercial", city: "Lahore", time: "15 min ago" },
  { name: "Zainab S.", action: "invested", amount: "PKR 200,000", property: "Clifton Block 5 Apartments", city: "Karachi", time: "22 min ago" },
  { name: "Bilal T.", action: "invested", amount: "AED 5,000", property: "Business Bay Tower", city: "Dubai", time: "28 min ago" },
  { name: "Nadia Q.", action: "received distribution", amount: "PKR 32,000", property: "F-8 Markaz Office Tower", city: "Islamabad", time: "35 min ago" },
];

function LiveActivityTicker() {
  const [visibleIndex, setVisibleIndex] = useState(0);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) return;
    const interval = setInterval(() => {
      setVisibleIndex((prev) => (prev + 1) % liveActivities.length);
    }, 4000);
    return () => clearInterval(interval);
  }, [prefersReducedMotion]);

  const current = liveActivities[visibleIndex];

  return (
    <div className="glass rounded-md px-5 py-3 overflow-hidden" data-testid="live-activity-ticker">
      <div className="flex items-center gap-3 mb-3">
        <div className="relative flex items-center justify-center">
          <span className={`absolute w-2.5 h-2.5 rounded-full bg-green-500 opacity-40 ${prefersReducedMotion ? '' : 'animate-ping'}`} />
          <span className="relative w-2.5 h-2.5 rounded-full bg-green-500" />
        </div>
        <span className="text-xs font-semibold text-ink-dark uppercase tracking-wider">Live Activity</span>
      </div>
      <AnimatePresence mode="wait">
        <motion.div
          key={visibleIndex}
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -16 }}
          transition={{ duration: prefersReducedMotion ? 0 : 0.4, ease: "easeInOut" }}
          className="flex items-center gap-3"
          data-testid={`activity-item-${visibleIndex}`}
        >
          <div className="w-9 h-9 rounded-full bg-vest-g5/10 flex items-center justify-center shrink-0">
            <Users className="w-4 h-4 text-vest-g5" />
          </div>
          <div className="min-w-0">
            <p className="text-sm text-ink-dark truncate">
              <span className="font-semibold">{current.name}</span>{" "}
              <span className="text-ink-muted">{current.action}</span>{" "}
              <span className="font-semibold text-vest-g5">{current.amount}</span>
            </p>
            <p className="text-xs text-ink-muted/70 truncate">
              {current.property}, {current.city} &middot; {current.time}
            </p>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

function ScrollProgressBar() {
  const [progress, setProgress] = useState(0);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) return;
    const handleScroll = () => {
      const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
      const pct = scrollHeight > 0 ? Math.min(100, Math.max(0, (window.scrollY / scrollHeight) * 100)) : 0;
      setProgress(pct);
    };
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, [prefersReducedMotion]);

  if (prefersReducedMotion) return null;

  return (
    <div
      className="fixed top-0 left-0 right-0 z-[100] h-[3px] bg-transparent pointer-events-none"
      data-testid="scroll-progress-bar"
      data-progress={Math.round(progress)}
      aria-valuenow={Math.round(progress)}
      role="progressbar"
    >
      <div
        className="h-full bg-gradient-to-r from-vest-g3 via-vest-g5 to-vest-g4 origin-left"
        style={{ transform: `scaleX(${progress / 100})` }}
      />
    </div>
  );
}

const featureHighlights = [
  { icon: Wallet, title: "Starting from PKR 50,000" },
  { icon: TrendingUp, title: "8–12% net annual ROI*" },
  { icon: LayoutGrid, title: "Fractional ownership" },
  { icon: Link2, title: "Blockchain backed" },
  { icon: ArrowLeftRight, title: "Buy and sell tokens" },
  { icon: Eye, title: "Full transparency" },
];

const services = [
  {
    num: "01",
    title: "Property Discovery",
    desc: "Explore curated income-generating properties across Pakistan's prime locations. Each property includes yield projections, funding targets, location analysis, and comprehensive documentation reviewed by our investment committee.",
    icon: Search,
  },
  {
    num: "02",
    title: "Digital Wallet & Funding",
    desc: "Deposit PKR via bank transfer, JazzCash, or Easypaisa into your VestBlock wallet. Multi-currency support enables AED, GBP, and USD investments. Funds are reserved on commitment and captured on successful funding.",
    icon: Wallet,
  },
  {
    num: "03",
    title: "Token Allocation",
    desc: "Each property is divided into digital security tokens. Upon funding completion, investors receive tokens proportional to their contribution. All allocations are recorded on an immutable ledger with full audit trail.",
    icon: Layers,
  },
  {
    num: "04",
    title: "Rental Distributions",
    desc: "Rental income is collected, expenses and management fees deducted transparently, and net distributions posted to your wallet monthly. Track every distribution with detailed breakdowns in your investor dashboard.",
    icon: Banknote,
  },
  {
    num: "05",
    title: "Structured Exit",
    desc: "List your tokens for sale during scheduled exit windows held twice per year. NAV-based pricing ensures fair valuation. Settlement timelines and fees are disclosed before you confirm. No hidden costs.",
    icon: DoorOpen,
  },
];

const projects = [
  { title: "DHA Phase 6 Commercial", city: "Lahore", yield: "9.1%", funded: "72%", img: prop1Img },
  { title: "Clifton Block 5 Apartments", city: "Karachi", yield: "8.5%", funded: "89%", img: prop2Img },
  { title: "F-8 Markaz Office Tower", city: "Islamabad", yield: "10.2%", funded: "45%", img: prop3Img },
  { title: "Bahria Town Villas", city: "Rawalpindi", yield: "7.8%", funded: "100%", img: prop4Img },
];

const testimonials = [
  {
    quote: "VestBlock made it possible for me to invest in Lahore's prime commercial real estate with just PKR 100,000. The monthly distributions are consistent and the platform is remarkably transparent.",
    name: "Hassan Malik",
    role: "Software Engineer, Lahore",
    img: testimonial1Img,
  },
  {
    quote: "As an overseas Pakistani, I was always looking for a trustworthy way to invest back home. VestBlock's KYC process was smooth, and I can track everything from my dashboard in real-time.",
    name: "Ayesha Siddiqui",
    role: "Finance Manager, Dubai",
    img: testimonial2Img,
  },
  {
    quote: "The structured exit windows gave me confidence to invest. I knew exactly when I could exit, at what price, and what fees to expect. No other platform in Pakistan offers this level of clarity.",
    name: "Ahmed Khan",
    role: "Entrepreneur, Islamabad",
    img: testimonial1Img,
  },
];

const securityItems = [
  { icon: ShieldCheck, title: "Identity Verification", desc: "Mandatory KYC with CNIC/NICOP verification and AML screening." },
  { icon: Lock, title: "Secure Wallet Ledger", desc: "Bank-grade 256-bit encryption and double-entry ledger." },
  { icon: FileText, title: "Audit Trails", desc: "Complete immutable audit trail for every transaction." },
  { icon: Scale, title: "Fee Disclosure", desc: "All fees disclosed upfront before you confirm." },
];

const marketplaceTabs = [
  {
    label: "Sell tokens",
    cards: [
      { title: "Price compliance", desc: "Tokens are listed within ±15% of the latest DLD smart valuation, and we ensure they stay within this range." },
      { title: "Lock-in period", desc: "Tokens can only be listed after a 3-month lock-in period from the property's original purchase date." },
      { title: "Listing process", desc: "Once the price and lock-in conditions are met, sellers can list the tokens they wish to sell." },
      { title: "Token listing", desc: "Sellers have the flexibility to list their tokens at any time and at different prices." },
      { title: "Market visibility", desc: "The tokens listed for sale are visible only to approved buyers in the Marketplace." },
    ],
  },
  {
    label: "Buy tokens",
    cards: [
      { title: "Marketplace access", desc: "Buyers can browse available token listings, viewing property details, smart valuations, and prices." },
      { title: "Price filtering", desc: "Buyers can filter listings based on price range and compare multiple offers for the same property." },
      { title: "Investment selection", desc: "Buyers can select tokens from different properties before proceeding with the acquisition." },
      { title: "Transaction process", desc: "The platform securely handles the process, ensuring funds are transferred to the seller and tokens to the buyer." },
    ],
  },
  {
    label: "Eligibility and compliance",
    cards: [
      { title: "Profile verification", desc: "Buyers and sellers must have their profile verified and updated before any transaction can be completed." },
      { title: "Rental income eligibility", desc: "Buyers must hold their tokens for a full month to receive rental income. Selling within a month forfeits income." },
    ],
  },
];

const faqItems = [
  { question: "What is the minimum investment?", answer: "You can start investing from as low as PKR 50,000. Each property has its own token price and minimum investment threshold." },
  { question: "How do I receive rental returns?", answer: "Rental distributions are processed monthly, typically by the 15th of each month. Distributions are deposited to your VestBlock wallet. You can withdraw to your bank account via IBFT, JazzCash, or Easypaisa." },
  { question: "Is VestBlock SECP-regulated?", answer: "Yes. VestBlock operates under the Securities and Exchange Commission of Pakistan (SECP) regulatory framework for digital asset securities. All property tokens are legally-backed securities." },
  { question: "When can I sell my tokens?", answer: "VestBlock offers exit windows twice per year (typically June and December) where you can list your tokens on the secondary marketplace. Settlement timelines and fees are disclosed in advance." },
  { question: "What documents do I need to register?", answer: "You'll need a valid CNIC (front and back), a recent utility bill or bank statement for address proof, and a selfie for identity verification. Overseas Pakistanis can use NICOP or passport." },
];

export default function MarketingHome() {
  const { region } = useRegion();
  const [activeService, setActiveService] = useState(0);
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [activeMarketplaceTab, setActiveMarketplaceTab] = useState(0);
  const [handbookOpen, setHandbookOpen] = useState(false);
  const [roiAmount, setRoiAmount] = useState(500000);
  const [roiYield, setRoiYield] = useState(9);
  const monthlyIncome = useMemo(() => Math.round((roiAmount * (roiYield / 100)) / 12), [roiAmount, roiYield]);
  const [testimonialPaused, setTestimonialPaused] = useState(false);

  useEffect(() => {
    if (testimonialPaused) return;
    const interval = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 7000);
    return () => clearInterval(interval);
  }, [testimonialPaused]);

  return (
    <MarketingLayout>
      <PageMeta title="Invest in Tokenized Real Estate" description="VestBlock is Pakistan's premier real estate tokenization platform. Invest in income-generating properties through digital fractional ownership." path="/pk" />

      <ScrollProgressBar />
      <Hero />

      {/* ── MARQUEE STRIP ── */}
      <section className="border-y border-vest-g5/[0.08] py-5 overflow-hidden bg-vest-g1/20" data-testid="marquee-section">
        <div className="marquee-strip">
          {[...marqueeItems, ...marqueeItems].map((item, i) => (
            <span key={i} className="flex items-center gap-6 px-6 text-sm font-medium text-ink-muted/50 whitespace-nowrap uppercase tracking-widest">
              {item}
              <Star className="w-3 h-3 text-vest-g4/50 fill-vest-g4/50" />
            </span>
          ))}
        </div>
      </section>

      {/* ── ABOUT / STATS ── */}
      <section className="py-24 px-6 sm:px-10 lg:px-16 gradient-section-blue" data-testid="about-section">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger}>
              <motion.div variants={fadeUp}><SectionLabel label="About VestBlock" /></motion.div>
              <motion.h2 variants={fadeUp} transition={{ duration: 0.6 }}
                className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight"
              >
                Making Real Estate{" "}
                <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Accessible</span>{" "}
                to Everyone
              </motion.h2>
              <motion.p variants={fadeUp} transition={{ duration: 0.5, delay: 0.1 }}
                className="mt-6 text-base text-ink-muted leading-relaxed max-w-lg"
              >
                We tokenize institutional-grade real estate into affordable digital securities, enabling anyone to build a diversified property portfolio with as little as PKR 50,000. Transparent fees, monthly distributions, and structured exit windows.
              </motion.p>
              <motion.div variants={fadeUp} transition={{ duration: 0.5, delay: 0.2 }} className="mt-8">
                <Link href="/about">
                  <button className="inline-flex items-center gap-2 text-sm text-vest-g5 font-medium hover:underline" data-testid="about-learn-more">
                    Learn More About Us <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </Link>
              </motion.div>
            </motion.div>

            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger}
              className="grid grid-cols-2 gap-5"
            >
              {[
                { value: <AnimatedCounter end={95} suffix="%" />, label: "Client Satisfaction" },
                { value: <AnimatedCounter end={125} suffix="+" />, label: "Properties Tokenized" },
                { value: <AnimatedCounter end={18.5} prefix="PKR " suffix="M" decimals={1} />, label: "Monthly Distributions" },
                { value: <AnimatedCounter end={5} />, label: "Cities Covered" },
              ].map((stat, i) => (
                <motion.div key={i} variants={fadeUp} transition={{ duration: 0.5 }}
                  className="glass rounded-md p-6 text-center"
                  data-testid={`about-stat-${i}`}
                >
                  <div className="text-3xl font-bold text-ink-dark mb-2">{stat.value}</div>
                  <div className="text-xs text-ink-muted/70">{stat.label}</div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── FEATURE HIGHLIGHTS ── */}
      <section className="py-20 px-6 sm:px-10 lg:px-16 gradient-section-bold relative overflow-hidden" data-testid="feature-highlights-section">
        <div className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(ellipse 80% 60% at 50% 50%, rgba(255,255,255,0.06) 0%, transparent 70%)" }} />
        <div className="relative max-w-7xl mx-auto">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {featureHighlights.map((f, i) => (
              <motion.div
                key={f.title}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                transition={{ delay: i * 0.07 }}
                className="rounded-2xl p-5 flex flex-col items-start gap-4 backdrop-blur-md border border-white/[0.12]"
                style={{ background: "linear-gradient(135deg, rgba(255,255,255,0.10) 0%, rgba(255,255,255,0.04) 100%)" }}
                data-testid={`feature-highlight-${i}`}
              >
                <div className="w-12 h-12 rounded-full bg-vest-g5 flex items-center justify-center shadow-lg shadow-vest-g5/30">
                  <f.icon className="w-5 h-5 text-white" />
                </div>
                <span className="text-sm font-semibold text-white leading-snug">{f.title}</span>
              </motion.div>
            ))}
          </div>
          <p className="text-[11px] text-white/50 mt-6">
            *net annual ROI = The returns are projections and not indicative of any future, past, or guaranteed performance.
          </p>
        </div>
      </section>

      {/* ── SERVICES / HOW IT WORKS (Numbered Tabs) ── */}
      <section className="py-24 px-6 sm:px-10 lg:px-16 border-t border-vest-g5/[0.08]" data-testid="services-section">
        <div className="max-w-7xl mx-auto">
          <SectionLabel label="How It Works" />
          <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-4">
            A Structured <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Approach</span>
          </h2>
          <p className="text-base text-ink-muted max-w-lg mb-12">
            From discovery to exit, every step is designed for transparency and investor protection.
          </p>

          <div className="grid grid-cols-1 lg:grid-cols-[300px_1fr] gap-8">
            <div className="flex flex-col gap-1.5 p-1.5 rounded-xl border border-white/10 backdrop-blur-xl shadow-lg shadow-black/5" style={{ background: "linear-gradient(135deg, rgba(30,43,255,0.06) 0%, rgba(255,255,255,0.03) 100%)" }} data-testid="service-tabs">
              {services.map((s, i) => (
                <button
                  key={i}
                  onClick={() => setActiveService(i)}
                  className={`flex items-center gap-4 px-5 py-3.5 rounded-lg text-left transition-all duration-300 ${
                    activeService === i
                      ? "backdrop-blur-md border border-white/15 shadow-inner"
                      : "border border-transparent hover:bg-white/[0.04]"
                  }`}
                  style={activeService === i ? { background: "linear-gradient(135deg, rgba(255,255,255,0.10) 0%, rgba(255,255,255,0.04) 100%)" } : undefined}
                  data-testid={`service-tab-${i}`}
                >
                  <span className={`text-2xl font-bold ${activeService === i ? "text-vest-g5" : "text-ink-muted/30"}`}>
                    {s.num}
                  </span>
                  <span className={`text-sm font-medium ${activeService === i ? "text-ink-dark" : "text-ink-muted"}`}>
                    {s.title}
                  </span>
                </button>
              ))}
            </div>

            <div className="glass rounded-md p-8 lg:p-12" data-testid="service-detail">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeService}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 rounded-md bg-vest-g5/10 flex items-center justify-center">
                      {(() => { const Icon = services[activeService].icon; return <Icon className="w-6 h-6 text-vest-g5" />; })()}
                    </div>
                    <div>
                      <span className="text-sm text-vest-g5 font-medium">{services[activeService].num}</span>
                      <h3 className="text-2xl font-bold text-ink-dark">{services[activeService].title}</h3>
                    </div>
                  </div>
                  <p className="text-base text-ink-muted leading-relaxed max-w-xl">
                    {services[activeService].desc}
                  </p>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>

          <p className="text-[10px] text-ink-muted/50 mt-6">Real estate investments carry risk and returns are not guaranteed.</p>
        </div>
      </section>

      {/* ── PROJECT SHOWCASE ── */}
      <section className="py-24 px-6 sm:px-10 lg:px-16 border-t border-vest-g5/[0.08]" data-testid="projects-section">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-end justify-between gap-6 mb-12 flex-wrap">
            <div>
              <SectionLabel label="Featured Properties" />
              <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight">
                Current <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Offerings</span>
              </h2>
            </div>
            <Link href="/properties">
              <button className="glass-btn-outline inline-flex items-center gap-2 rounded-md px-6 py-3 text-sm font-medium" data-testid="projects-view-all">
                View All <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {projects.map((proj, i) => (
              <motion.div
                key={i}
                initial="hidden" whileInView="visible" viewport={{ once: true }}
                variants={fadeUp} transition={{ duration: 0.5, delay: i * 0.1 }}
                whileHover={{ y: -6, transition: { duration: 0.3 } }}
              >
                <Link href="/properties">
                  <div className="group relative overflow-hidden rounded-md border border-vest-g5/[0.08] hover:border-vest-g5/20 transition-all cursor-pointer hover:shadow-lg hover:shadow-vest-g5/10" data-testid={`project-card-${i}`}>
                    <div className="aspect-[16/10] overflow-hidden">
                      <img
                        src={proj.img}
                        alt={proj.title}
                        loading="lazy"
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
                    </div>
                    <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-all duration-300">
                      <div className="glass rounded-md px-3 py-1.5 text-xs font-semibold text-vest-g5 backdrop-blur-md border border-white/20">
                        {proj.yield} yield
                      </div>
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 p-6 transform transition-transform duration-300 group-hover:translate-y-[-4px]">
                      <div className="flex items-end justify-between gap-4">
                        <div>
                          <div className="text-xs text-white/70 mb-1">{proj.city}</div>
                          <h3 className="text-xl font-bold text-white">{proj.title}</h3>
                          <div className="flex items-center gap-4 mt-2 text-sm">
                            <span className="text-vest-g1 font-medium">{proj.yield} yield</span>
                            <span className="text-white/60">{proj.funded} funded</span>
                          </div>
                          <div className="mt-2 w-full bg-white/20 rounded-full h-1.5 overflow-hidden">
                            <motion.div
                              className="h-full bg-gradient-to-r from-vest-g3 to-vest-g1 rounded-full"
                              initial={{ width: 0 }}
                              whileInView={{ width: proj.funded }}
                              viewport={{ once: true }}
                              transition={{ duration: 1.2, delay: 0.3 + i * 0.15, ease: "easeOut" }}
                            />
                          </div>
                        </div>
                        <div className="w-10 h-10 rounded-full border border-white/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 group-hover:scale-110 group-hover:border-white/50 group-hover:bg-white/10">
                          <ArrowUpRight className="w-4 h-4 text-white" />
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── LIVE ACTIVITY ── */}
      <section className="py-16 px-6 sm:px-10 lg:px-16 border-t border-vest-g5/[0.08] relative overflow-hidden" data-testid="live-activity-section">
        <div className="absolute inset-0 pointer-events-none" style={{ background: "radial-gradient(ellipse 60% 50% at 80% 50%, rgba(30,43,255,0.03) 0%, transparent 70%)" }} />
        <div className="relative max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-8 items-center">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger}>
              <motion.div variants={fadeUp}><SectionLabel label="Platform Stats" /></motion.div>
              <motion.h2 variants={fadeUp} transition={{ duration: 0.6 }}
                className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight"
              >
                Growing <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Community</span>
              </motion.h2>
              <motion.p variants={fadeUp} transition={{ duration: 0.5, delay: 0.1 }}
                className="mt-4 text-base text-ink-muted leading-relaxed max-w-lg"
              >
                Join thousands of investors already building wealth through tokenized real estate.
              </motion.p>
              <motion.div variants={fadeUp} transition={{ duration: 0.5, delay: 0.2 }}
                className="mt-8 grid grid-cols-3 gap-6"
              >
                {[
                  { value: <AnimatedCounter end={12400} suffix="+" />, label: "Active Investors" },
                  { value: <AnimatedCounter end={2.8} prefix="PKR " suffix="B" decimals={1} />, label: "Total Invested" },
                  { value: <AnimatedCounter end={125} suffix="+" />, label: "Properties" },
                ].map((stat, i) => (
                  <div key={i} className="text-center" data-testid={`platform-stat-${i}`}>
                    <div className="text-2xl sm:text-3xl font-bold text-ink-dark">{stat.value}</div>
                    <div className="text-xs text-ink-muted/70 mt-1">{stat.label}</div>
                  </div>
                ))}
              </motion.div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <LiveActivityTicker />
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section className="py-24 px-6 sm:px-10 lg:px-16 gradient-section-subtle" data-testid="testimonials-section">
        <div
          className="max-w-7xl mx-auto"
          onMouseEnter={() => setTestimonialPaused(true)}
          onMouseLeave={() => setTestimonialPaused(false)}
        >
          <div className="flex items-end justify-between gap-6 mb-12 flex-wrap">
            <div>
              <SectionLabel label="Testimonials" />
              <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight">
                What Our <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Investors</span> Say
              </h2>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setActiveTestimonial((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1))}
                className="glass-btn-outline w-10 h-10 rounded-full flex items-center justify-center"
                aria-label="Previous testimonial"
                data-testid="testimonial-prev"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => setActiveTestimonial((prev) => (prev === testimonials.length - 1 ? 0 : prev + 1))}
                className="glass-btn-outline w-10 h-10 rounded-full flex items-center justify-center"
                aria-label="Next testimonial"
                data-testid="testimonial-next"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={activeTestimonial}
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
              transition={{ duration: 0.4 }}
              className="grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-10 items-center"
            >
              <div>
                <div className="text-5xl text-vest-g3/40 font-serif leading-none mb-4">"</div>
                <p className="text-xl sm:text-2xl text-ink-dark/80 leading-relaxed font-light" data-testid="testimonial-quote">
                  {testimonials[activeTestimonial].quote}
                </p>
                <div className="mt-8">
                  <div className="text-base font-semibold text-ink-dark" data-testid="testimonial-name">
                    {testimonials[activeTestimonial].name}
                  </div>
                  <div className="text-sm text-ink-muted" data-testid="testimonial-role">
                    {testimonials[activeTestimonial].role}
                  </div>
                </div>
              </div>
              <div className="hidden lg:block">
                <div className="aspect-[3/4] rounded-md overflow-hidden border border-vest-g5/[0.08]">
                  <img
                    src={testimonials[activeTestimonial].img}
                    alt={testimonials[activeTestimonial].name}
                    loading="lazy"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          <div className="flex items-center gap-2 mt-8">
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setActiveTestimonial(i)}
                className={`h-1.5 rounded-full transition-all duration-500 relative overflow-hidden ${
                  i === activeTestimonial ? "w-10 bg-vest-g5/20" : "w-4 bg-vest-g5/20"
                }`}
                aria-label={`Go to testimonial ${i + 1}`}
                data-testid={`testimonial-dot-${i}`}
              >
                {i === activeTestimonial && (
                  <motion.div
                    className="absolute inset-0 bg-vest-g5 rounded-full origin-left"
                    initial={{ scaleX: 0 }}
                    animate={{ scaleX: testimonialPaused ? undefined : 1 }}
                    transition={{ duration: 7, ease: "linear" }}
                    key={`progress-${activeTestimonial}-${Date.now()}`}
                  />
                )}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ── SECURITY & COMPLIANCE ── */}
      <section className="py-24 px-6 sm:px-10 lg:px-16 gradient-section-blue animated-mesh-bg" data-testid="trust-section">
        <div className="max-w-7xl mx-auto">
          <SectionLabel label="Security" />
          <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-4">
            Investor <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Protection</span>
          </h2>
          <p className="text-base text-ink-muted max-w-lg mb-12">
            Your investments are protected by multiple layers of regulatory and technical security.
          </p>

          <motion.div
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5"
            initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger}
          >
            {securityItems.map((card, i) => (
              <motion.div key={card.title} variants={fadeUp} transition={{ duration: 0.5 }}
                className="glass rounded-md p-6 hover:border-vest-g5/20 transition-all"
                data-testid={`trust-card-${i}`}
              >
                <div className="w-10 h-10 rounded-md flex items-center justify-center mb-5 bg-vest-g5/10">
                  <card.icon className="w-5 h-5 text-vest-g5" />
                </div>
                <h3 className="text-sm font-semibold text-ink-dark mb-2">{card.title}</h3>
                <p className="text-xs text-ink-muted/70 leading-relaxed">{card.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── ROI CALCULATOR TEASER ── */}
      <section className="py-24 px-6 sm:px-10 lg:px-16 border-t border-vest-g5/[0.08]" data-testid="roi-teaser-section">
        <div className="max-w-xl mx-auto">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} transition={{ duration: 0.5 }}>
            <div className="glass rounded-md p-8" data-testid="roi-calculator-teaser">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-md bg-vest-g5/10 flex items-center justify-center">
                  <Calculator className="w-5 h-5 text-vest-g5" />
                </div>
                <h3 className="text-xl font-bold text-ink-dark">Estimate Your Monthly Income</h3>
              </div>
              <div className="space-y-6">
                <div>
                  <div className="flex items-center justify-between text-sm mb-3">
                    <span className="text-ink-muted">Investment Amount (PKR)</span>
                    <span className="text-ink-dark font-medium">PKR {roiAmount.toLocaleString()}</span>
                  </div>
                  <input
                    type="range" min={50000} max={10000000} step={50000} value={roiAmount}
                    onChange={(e) => setRoiAmount(Number(e.target.value))}
                    className="w-full h-1.5 rounded-full appearance-none cursor-pointer"
                    style={{ background: `linear-gradient(90deg, #1E2BFF ${((roiAmount - 50000) / (10000000 - 50000)) * 100}%, rgba(30,43,255,0.12) 0%)` }}
                    data-testid="roi-amount-slider"
                  />
                  <div className="flex items-center justify-between text-xs text-ink-muted/50 mt-1.5">
                    <span>PKR 50K</span><span>PKR 1Cr</span>
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between text-sm mb-3">
                    <span className="text-ink-muted">Expected Yield (%)</span>
                    <span className="text-ink-dark font-medium">{roiYield}%</span>
                  </div>
                  <input
                    type="range" min={4} max={18} step={0.5} value={roiYield}
                    onChange={(e) => setRoiYield(Number(e.target.value))}
                    className="w-full h-1.5 rounded-full appearance-none cursor-pointer"
                    style={{ background: `linear-gradient(90deg, #1E2BFF ${((roiYield - 4) / (18 - 4)) * 100}%, rgba(30,43,255,0.12) 0%)` }}
                    data-testid="roi-yield-slider"
                  />
                  <div className="flex items-center justify-between text-xs text-ink-muted/50 mt-1.5">
                    <span>4%</span><span>18%</span>
                  </div>
                </div>
                <div className="h-px w-full bg-vest-g5/[0.08]" />
                <div className="p-5 rounded-md border border-vest-g5/20 bg-vest-g0/50 text-center">
                  <div className="text-xs text-ink-muted/70 mb-1.5">Estimated Monthly Distribution</div>
                  <div className="text-3xl font-bold text-vest-g5" data-testid="roi-monthly-result">
                    PKR {monthlyIncome.toLocaleString()}
                  </div>
                </div>
                <p className="text-[10px] text-ink-muted/50 text-center">
                  Estimates are illustrative and not guaranteed. Actual returns depend on property performance.
                </p>
                <div className="text-center">
                  <Link href="/roi-calculator">
                    <button className="inline-flex items-center gap-2 text-sm text-vest-g5 font-medium hover:underline" data-testid="roi-open-full">
                      Open Full Calculator <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </Link>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── OUR MARKETPLACE ── */}
      <section className="py-14 px-6 sm:px-10 lg:px-16 gradient-section-bold relative overflow-hidden" data-testid="marketplace-section">
        <div className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(ellipse 80% 60% at 50% 50%, rgba(255,255,255,0.05) 0%, transparent 70%)" }} />
        <div className="relative max-w-5xl mx-auto">
          <div className="text-center mb-6">
            <h2 className="text-2xl sm:text-3xl font-bold text-white leading-tight">
              Our Marketplace
            </h2>
          </div>

          <div className="flex items-center justify-center mb-6">
            <div
              className="inline-flex rounded-full border border-white/15 p-1 backdrop-blur-xl shadow-lg shadow-black/20"
              style={{ background: "linear-gradient(135deg, rgba(255,255,255,0.12) 0%, rgba(255,255,255,0.04) 100%)" }}
            >
              {marketplaceTabs.map((tab, i) => (
                <button
                  key={tab.label}
                  onClick={() => setActiveMarketplaceTab(i)}
                  className={`px-4 sm:px-6 py-2 rounded-full text-xs sm:text-sm font-medium transition-all duration-300 whitespace-nowrap ${
                    activeMarketplaceTab === i
                      ? "bg-white/20 text-white shadow-inner border border-white/20 backdrop-blur-md"
                      : "text-white/60 hover:text-white hover:bg-white/[0.07]"
                  }`}
                  data-testid={`marketplace-tab-${i}`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          <div className="h-[520px] sm:h-[280px] lg:h-[230px]">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeMarketplaceTab}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3"
                data-testid="marketplace-cards"
              >
                {marketplaceTabs[activeMarketplaceTab].cards.map((card, i) => (
                  <div
                    key={card.title}
                    className="rounded-xl p-5 backdrop-blur-md border border-white/[0.10]"
                    style={{ background: "linear-gradient(135deg, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0.03) 100%)" }}
                    data-testid={`marketplace-card-${i}`}
                  >
                    <h4 className="text-sm font-bold text-white mb-2">{card.title}</h4>
                    <p className="text-xs text-white/65 leading-relaxed">{card.desc}</p>
                  </div>
                ))}
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* ── FAQ PREVIEW ── */}
      <section className="py-24 px-6 sm:px-10 lg:px-16 border-t border-vest-g5/[0.08] animated-mesh-bg" data-testid="faq-preview-section">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <SectionLabel label="FAQ" />
            <h2 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight">
              Common <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Questions</span>
            </h2>
          </div>
          <MarketingAccordion items={faqItems} />
          <div className="text-center mt-8">
            <Link href="/faq">
              <button className="glass-btn-outline inline-flex items-center gap-2 rounded-md px-6 py-3 text-sm font-medium" data-testid="faq-view-all">
                View All FAQs <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* ── MOBILE APP TEASER ── */}
      <section className="py-24 px-6 sm:px-10 lg:px-16 gradient-section-subtle" data-testid="mobile-app-section">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger}>
              <motion.div variants={fadeUp}><SectionLabel label="Mobile App" /></motion.div>
              <motion.h2 variants={fadeUp} transition={{ duration: 0.6 }}
                className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight"
              >
                VestBlock <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Mobile App</span>
              </motion.h2>
              <motion.p variants={fadeUp} transition={{ duration: 0.5, delay: 0.1 }}
                className="mt-4 text-base text-ink-muted leading-relaxed max-w-lg"
              >
                Track your units, payouts, and exit windows — anywhere.
              </motion.p>

              <motion.ul variants={stagger} className="mt-8 space-y-3">
                {[
                  { icon: BarChart3, text: "Real-time portfolio (units, value, payout history)" },
                  { icon: Banknote, text: "Monthly distributions tracking" },
                  { icon: Clock, text: "Exit window countdown + sell flow" },
                  { icon: FolderOpen, text: "Data Room (ADT) document access" },
                  { icon: Wallet, text: "Wallet deposits & withdrawals (profit after 30 days, capital after 90 days)" },
                ].map((b, i) => (
                  <motion.li key={i} variants={fadeUp} transition={{ duration: 0.4 }}
                    className="flex items-start gap-3"
                    data-testid={`app-bullet-${i}`}
                  >
                    <div className="w-8 h-8 rounded-md bg-vest-g5/10 flex items-center justify-center shrink-0 mt-0.5">
                      <b.icon className="w-4 h-4 text-vest-g5" />
                    </div>
                    <span className="text-sm text-ink-dark leading-relaxed">{b.text}</span>
                  </motion.li>
                ))}
              </motion.ul>

              <motion.div variants={fadeUp} transition={{ duration: 0.5, delay: 0.3 }}
                className="mt-8 flex flex-wrap gap-3"
              >
                <Link href="/mobile-app">
                  <button className="glass-btn-primary inline-flex items-center gap-2 rounded-md px-6 py-3 text-sm font-medium" data-testid="app-cta-get">
                    <Smartphone className="w-4 h-4" /> Get the App
                  </button>
                </Link>
                <Link href="/mobile-app#features">
                  <button className="glass-btn-outline inline-flex items-center gap-2 rounded-md px-6 py-3 text-sm font-medium" data-testid="app-cta-features">
                    See App Features
                  </button>
                </Link>
              </motion.div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="flex justify-center lg:justify-end"
            >
              <PhoneMockup autoPlay />
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── WHAT IS A TOKEN ── */}
      <section className="py-20 px-6 sm:px-10 lg:px-16 relative overflow-hidden" style={{ background: "linear-gradient(135deg, #EEF0FF 0%, #D6DBFF 40%, #E8EAFF 100%)" }} data-testid="what-is-token-section">
        <motion.div
          className="relative max-w-4xl mx-auto"
          initial="hidden" whileInView="visible" viewport={{ once: true }} variants={stagger}
        >
          <motion.div variants={fadeUp} transition={{ duration: 0.6 }}
            className="bg-white rounded-2xl shadow-xl shadow-[#1E2BFF]/8 overflow-hidden flex flex-col md:flex-row"
            data-testid="token-card"
          >
            <div className="md:w-[45%] flex-shrink-0 p-6 sm:p-8 flex items-center justify-center" style={{ background: "linear-gradient(145deg, #1a1f6e 0%, #0d1147 100%)" }}>
              <PixelBuilding />
            </div>
            <div className="p-8 sm:p-10 flex flex-col justify-center">
              <h2 className="text-2xl sm:text-3xl font-bold text-[#1E2BFF] mb-4" data-testid="token-heading">
                What is a token?
              </h2>
              <p className="text-gray-700 mb-4 leading-relaxed">
                A token is a digital unit of ownership stored on a blockchain.
              </p>
              <p className="text-gray-600 leading-relaxed mb-8">
                For example, in real estate, a property can be divided into 1,000,000 tokens, and each token represents a fraction of ownership. Buying 10,000 tokens would give you 1% ownership of the property.
              </p>
              <div>
                <Link href="/pk/tokenization">
                  <span className="inline-flex items-center gap-3 cursor-pointer group" data-testid="token-learn-more">
                    <span className="text-base font-semibold text-gray-800 group-hover:text-[#1E2BFF] transition-colors">Learn more</span>
                    <span className="w-10 h-10 rounded-full bg-gradient-to-br from-[#a3e635] to-[#65a30d] flex items-center justify-center shadow-md group-hover:scale-110 transition-transform">
                      <ArrowRight className="w-5 h-5 text-white" />
                    </span>
                  </span>
                </Link>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </section>

      {/* ── HANDBOOK MODAL ── */}
      <AnimatePresence>
        {handbookOpen && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            data-testid="handbook-modal"
          >
            <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setHandbookOpen(false)} />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ duration: 0.25 }}
              className="relative glass-surface rounded-md p-8 max-w-md w-full"
            >
              <button
                onClick={() => setHandbookOpen(false)}
                className="absolute top-4 right-4 text-ink-muted hover:text-ink-dark transition-colors"
                data-testid="handbook-modal-close"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="w-14 h-14 rounded-md flex items-center justify-center mb-5 mx-auto bg-vest-g5/10">
                <FileText className="w-7 h-7 text-vest-g5" />
              </div>
              <h3 className="text-xl font-bold text-ink-dark text-center mb-2">Download Investor Handbook</h3>
              <p className="text-sm text-ink-muted text-center mb-6 leading-relaxed">
                Enter your email to receive the VestBlock Investor Handbook (PDF).
              </p>
              <form onSubmit={(e) => { e.preventDefault(); setHandbookOpen(false); }} className="space-y-3">
                <input
                  type="email"
                  placeholder="your@email.com"
                  required
                  className="w-full px-4 py-3 text-sm rounded-md bg-white/50 border border-vest-g5/15 text-ink-dark placeholder:text-ink-muted/50 focus:outline-none focus:border-vest-g5/40"
                  data-testid="handbook-email"
                />
                <button type="submit" className="glass-btn-primary w-full flex items-center justify-center gap-2 rounded-md px-5 py-3 text-sm font-medium" data-testid="handbook-submit">
                  <Download className="w-4 h-4" /> Send Handbook
                </button>
              </form>
              <p className="text-xs text-ink-muted/50 text-center mt-4">We respect your privacy. No spam.</p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </MarketingLayout>
  );
}
