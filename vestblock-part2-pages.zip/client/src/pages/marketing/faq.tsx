import { useState } from "react";
import { Link } from "wouter";
import { MarketingLayout } from "@/components/marketing/layout";
import { PageMeta } from "@/components/marketing/page-meta";
import { GlassCard } from "@/components/marketing/glass-card";
import { CtaSection } from "@/components/marketing/cta-section";
import { motion } from "framer-motion";
import {
  HelpCircle, TrendingUp, ShieldCheck, Search, ChevronDown,
  ChevronUp, ArrowRight, Wallet, DoorOpen, FileText, Users,
} from "lucide-react";

const fadeUp = { hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0 } };

const faqCategories = [
  {
    title: "Getting Started",
    icon: HelpCircle,
    items: [
      { q: "How do I register on VestBlock?", a: "Visit our registration page and provide your full name, email, phone number, and CNIC. You'll receive a verification email to activate your account. The entire process takes less than 5 minutes." },
      { q: "What documents are required for KYC verification?", a: "You'll need a valid CNIC (front and back), a recent utility bill or bank statement for address proof, and a selfie for identity verification. Corporate investors require additional documentation including company registration and board resolution." },
      { q: "What is the minimum investment amount?", a: "The minimum investment on VestBlock is PKR 50,000. This allows you to purchase fractional tokens in premium real estate properties across Pakistan." },
      { q: "How long does account verification take?", a: "Standard KYC verification is completed within 24–48 business hours. Enhanced due diligence for larger investments may take up to 5 business days. You'll receive email notifications at each step." },
      { q: "Can I invest from outside Pakistan?", a: "Yes, overseas Pakistanis can invest through VestBlock. You'll need to complete our international KYC process with your NICOP or passport, and funds can be transferred via approved banking channels." },
    ],
  },
  {
    title: "Investing & Returns",
    icon: TrendingUp,
    items: [
      { q: "What kind of returns can I expect?", a: "Returns vary by property and include rental yields (typically 6–12% annually) and capital appreciation. Historical data shows premium properties in DHA, Bahria Town, and commercial zones delivering strong risk-adjusted returns. Past performance does not guarantee future results.*" },
      { q: "When are rental distributions paid?", a: "Rental income distributions are processed monthly, typically by the 15th of each month. Distributions are deposited to your VestBlock wallet after deducting applicable management fees and property expenses." },
      { q: "Are there any fees for investing?", a: "VestBlock charges an entry fee (0–1.0%) on token purchases, an annual management fee (1.0–2.0%), and an exit fee (0.5–1.0%) on secondary market sales. All fees are disclosed upfront before you confirm any transaction. See the Fees page for full details." },
      { q: "Can I reinvest my distributions?", a: "Yes, you can enable auto-reinvestment in your account settings. This automatically uses your rental distributions to purchase additional tokens in the same property or diversify across other offerings." },
      { q: "How is property value determined?", a: "Property values are determined by independent certified surveyors through periodic valuations. These valuations consider market comparables, rental income, property condition, and local market trends. Token pricing (NAV) is based on the most recent valuation." },
    ],
  },
  {
    title: "Exits & Liquidity",
    icon: DoorOpen,
    items: [
      { q: "How do exit windows work?", a: "Exit windows open twice per year (typically June and December), allowing token holders to list their tokens on VestBlock's internal secondary marketplace. You can sell partial or full holdings during these windows." },
      { q: "Can I exit partially?", a: "Yes, you can sell as few as 1 token during an exit window. Your remaining tokens continue earning distributions as normal. There is no minimum holding requirement after a partial exit." },
      { q: "What happens if my tokens don't sell?", a: "If no buyer is matched during an exit window, your tokens remain in your portfolio and continue earning distributions. You can relist them in the next exit window at no additional cost. VestBlock does not guarantee liquidity." },
      { q: "What is the lockup period?", a: "Lockup periods vary by property (typically 6–24 months) and are disclosed on each property's listing page before you invest. You cannot submit an exit request until the lockup period expires. Early exits incur an additional penalty (up to 2.0%)." },
    ],
  },
  {
    title: "Wallet & Transactions",
    icon: Wallet,
    items: [
      { q: "How do I withdraw funds to my bank account?", a: "Initiate a withdrawal from your VestBlock wallet to your linked Pakistani bank account. Withdrawals typically complete within 1–3 business days. No withdrawal fee for amounts above PKR 5,000." },
      { q: "What currencies are supported?", a: "The primary currency is PKR. VestBlock also supports AED, GBP, USD, USDT, and USDC for international investors. Currency conversion fees (0.5–1.5%) apply for cross-currency transactions." },
      { q: "Is my wallet balance insured?", a: "Investor funds are held in segregated escrow accounts with partnered scheduled banks, separate from VestBlock's operational funds. While not FDIC-insured (as that is a US standard), segregation provides significant protection." },
    ],
  },
  {
    title: "Security & Compliance",
    icon: ShieldCheck,
    items: [
      { q: "Is VestBlock regulated by SECP?", a: "VestBlock operates under the Securities and Exchange Commission of Pakistan (SECP) framework for digital asset securities. We comply with applicable securities laws, AML regulations, and data protection requirements." },
      { q: "How is my personal data protected?", a: "We use AES-256 encryption for data at rest and TLS 1.3 for data in transit. KYC documents are stored in encrypted vaults with strict access controls. We comply with Pakistan's Prevention of Electronic Crimes Act (PECA)." },
      { q: "What happens if VestBlock ceases operations?", a: "Your property tokens represent legal fractional ownership through registered SPVs. In the unlikely event of platform discontinuation, your ownership rights remain intact and would be managed by an appointed trustee as per SECP regulations." },
      { q: "How do you prevent fraud and money laundering?", a: "We implement comprehensive AML/CFT procedures including mandatory KYC, transaction monitoring, suspicious activity reporting to the Financial Monitoring Unit (FMU), and periodic enhanced due diligence for high-value transactions." },
    ],
  },
  {
    title: "Legal & Tax",
    icon: FileText,
    items: [
      { q: "Do I legally own the property?", a: "You own fractional beneficial interest in a Special Purpose Vehicle (SPV) that holds legal title to the property. This entitles you to proportional rental income and capital returns. Your ownership is recorded in the SPV's register of beneficial owners." },
      { q: "Are there taxes on rental income?", a: "Rental distributions may be subject to withholding tax under Pakistani tax law. VestBlock provides transaction records and may issue tax certificates. Consult a qualified tax advisor for guidance on your specific situation." },
      { q: "What about capital gains tax on exit?", a: "Capital gains from token sales may be taxable under FBR guidelines. Tax treatment depends on your holding period and personal circumstances. VestBlock does not provide tax advice — consult a qualified tax professional." },
    ],
  },
];

function FaqItem({ q, a, index, catIndex }: { q: string; a: string; index: number; catIndex: number }) {
  const [open, setOpen] = useState(false);
  return (
    <GlassCard className="p-0 overflow-hidden" data-testid={`faq-item-${catIndex}-${index}`}>
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-5 py-4 text-left"
        data-testid={`faq-toggle-${catIndex}-${index}`}
      >
        <span className="text-sm font-semibold text-ink-dark pr-4">{q}</span>
        {open ? <ChevronUp className="w-4 h-4 text-ink-muted/70 shrink-0" /> : <ChevronDown className="w-4 h-4 text-ink-muted/70 shrink-0" />}
      </button>
      {open && (
        <div className="px-5 pb-4 border-t border-vest-g5/15 pt-3">
          <p className="text-xs text-ink-muted leading-relaxed">{a}</p>
        </div>
      )}
    </GlassCard>
  );
}

export default function FaqPage() {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredCategories = faqCategories.map((cat) => ({
    ...cat,
    items: searchQuery.trim()
      ? cat.items.filter(
          (item) =>
            item.q.toLowerCase().includes(searchQuery.toLowerCase()) ||
            item.a.toLowerCase().includes(searchQuery.toLowerCase())
        )
      : cat.items,
  })).filter((cat) => cat.items.length > 0);

  const totalResults = filteredCategories.reduce((acc, cat) => acc + cat.items.length, 0);

  return (
    <MarketingLayout>
      <PageMeta title="Frequently Asked Questions" description="Answers to common questions about tokenized real estate investing, VestBlock's platform, fees, security, KYC requirements, and withdrawal processes." path="/pk/faq" />
      <section className="relative py-24 sm:py-32 px-4 overflow-hidden" data-testid="faq-hero">
        <div className="absolute inset-0 bg-gradient-to-b from-vest-g5/5 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div variants={fadeUp} initial="hidden" animate="visible">
            <span className="inline-flex items-center px-3.5 py-1.5 rounded-2xl text-xs font-medium mb-6 text-vest-g5 bg-vest-g5/10 border border-vest-g5/20" data-testid="faq-badge">
              Support
            </span>
            <h1 className="text-3xl sm:text-4xl font-bold text-ink-dark leading-tight mb-5 tracking-tight" data-testid="faq-headline">
              Frequently Asked <span className="bg-gradient-to-r from-vest-g3 to-vest-g5 bg-clip-text text-transparent">Questions</span>
            </h1>
            <p className="text-base sm:text-lg text-ink-muted max-w-2xl mx-auto leading-relaxed" data-testid="faq-subtext">
              Find answers to common questions about investing, security, fees, and how VestBlock works.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="px-4 pb-8" data-testid="faq-search-section">
        <div className="max-w-3xl mx-auto">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-muted/70" />
            <input
              type="text"
              placeholder="Search questions..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-11 pr-4 py-3.5 rounded-2xl bg-white/50 border border-vest-g5/15 text-sm text-ink-dark placeholder:text-ink-muted focus:outline-none focus:border-vest-g5/40 transition-colors"
              data-testid="faq-search-input"
            />
          </div>
          {searchQuery && (
            <p className="text-xs text-ink-muted/70 mt-3" data-testid="faq-search-count">{totalResults} result{totalResults !== 1 ? "s" : ""} for "{searchQuery}"</p>
          )}
        </div>
      </section>

      <section className="px-4 pb-20" data-testid="faq-content">
        <div className="max-w-3xl mx-auto space-y-10">
          {filteredCategories.length === 0 ? (
            <GlassCard className="text-center py-12" data-testid="faq-no-results">
              <Search className="w-8 h-8 text-ink-muted mx-auto mb-3" />
              <p className="text-sm text-ink-muted mb-1">No questions found</p>
              <p className="text-xs text-ink-muted">Try a different search term.</p>
            </GlassCard>
          ) : (
            filteredCategories.map((cat, ci) => (
              <motion.div key={cat.title} variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }} data-testid={`faq-category-${ci}`}>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-9 h-9 rounded-xl bg-vest-g5/15 flex items-center justify-center">
                    <cat.icon className="w-4 h-4 text-vest-g5" />
                  </div>
                  <h2 className="text-lg font-semibold text-ink-dark">{cat.title}</h2>
                </div>
                <div className="space-y-2">
                  {cat.items.map((item, qi) => (
                    <FaqItem key={qi} q={item.q} a={item.a} index={qi} catIndex={ci} />
                  ))}
                </div>
              </motion.div>
            ))
          )}
        </div>
      </section>

      {/* Related Resources */}
      <section className="px-4 pb-8" data-testid="faq-resources">
        <div className="max-w-3xl mx-auto">
          <h3 className="text-center text-sm font-semibold text-ink-muted mb-4">Related Resources</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: "Risk Warnings", href: "/risk-warnings", icon: "!" },
              { label: "ROI Calculator", href: "/roi-calculator", icon: "%" },
              { label: "Exit Windows", href: "/exit-windows", icon: "E" },
              { label: "Fee Schedule", href: "/fees", icon: "F" },
            ].map((r) => (
              <Link key={r.href} href={r.href} className="glass-surface rounded-2xl p-3 text-center block hover:border-vest-g5/20 transition" data-testid={`faq-resource-${r.label.toLowerCase().replace(/\s+/g, "-")}`}>
                  <p className="text-xs font-medium text-ink-dark">{r.label}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <CtaSection
        title="Still Have"
        highlight="Questions?"
        subtitle="Our support team is ready to help. Or explore our glossary and guides for more detailed information."
        actions={[
          { label: "Contact Us", href: "/contact" },
          { label: "Glossary", href: "/glossary", variant: "secondary" },
          { label: "Investor Guides", href: "/guides", variant: "secondary" },
        ]}
        testId="faq-cta"
      />
    </MarketingLayout>
  );
}
