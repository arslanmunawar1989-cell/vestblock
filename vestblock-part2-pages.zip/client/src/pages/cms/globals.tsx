import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, Globe, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

interface GlobalContent {
  id: number;
  contentKey: string;
  region: string;
  contentJson: string;
}

export default function CmsGlobals() {
  const { toast } = useToast();
  const [filterRegion, setFilterRegion] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<GlobalContent | null>(null);

  const [form, setForm] = useState({
    contentKey: "", region: "PK", contentJson: "{}",
  });

  const { data: globals, isLoading } = useQuery<GlobalContent[]>({
    queryKey: ["/api/cms/globals"],
  });

  const saveMutation = useMutation({
    mutationFn: (data: any) =>
      editingItem
        ? apiRequest("PUT", `/api/cms/globals/${editingItem.id}`, data)
        : apiRequest("POST", "/api/cms/globals", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/globals"] });
      setDialogOpen(false);
      toast({ title: editingItem ? "Global updated" : "Global created" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/cms/globals/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/globals"] });
      toast({ title: "Global deleted" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const filtered = (globals || []).filter((g) => {
    if (filterRegion !== "all" && g.region !== filterRegion) return false;
    return true;
  });

  function openCreate() {
    setEditingItem(null);
    setForm({ contentKey: "", region: "PK", contentJson: "{}" });
    setDialogOpen(true);
  }

  function openEdit(item: GlobalContent) {
    setEditingItem(item);
    const jsonStr = typeof item.contentJson === "string" ? item.contentJson : JSON.stringify(item.contentJson, null, 2);
    setForm({ contentKey: item.contentKey, region: item.region, contentJson: jsonStr });
    setDialogOpen(true);
  }

  function updateForm(key: string, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function handleSubmit() {
    try {
      JSON.parse(form.contentJson);
    } catch {
      toast({ title: "Invalid JSON", description: "Please enter valid JSON in the content field", variant: "destructive" });
      return;
    }
    saveMutation.mutate(form);
  }

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <Link href="/cms/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <Globe className="w-6 h-6" />
          <h1 className="text-2xl font-bold" data-testid="text-globals-title">CMS Globals</h1>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Select value={filterRegion} onValueChange={setFilterRegion}>
            <SelectTrigger className="w-28" data-testid="select-filter-region"><SelectValue placeholder="Region" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Regions</SelectItem>
              <SelectItem value="PK">PK</SelectItem>
              <SelectItem value="AE">AE</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={openCreate} data-testid="button-create-global">
            <Plus className="w-4 h-4 mr-1" /> New Global
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-2">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-16" />)}</div>
      ) : filtered.length === 0 ? (
        <Card><CardContent className="py-8 text-center text-muted-foreground">No global content found</CardContent></Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left">
                    <th className="p-3 font-medium">Content Key</th>
                    <th className="p-3 font-medium">Region</th>
                    <th className="p-3 font-medium">Preview</th>
                    <th className="p-3 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((item) => {
                    const preview = typeof item.contentJson === "string" ? item.contentJson : JSON.stringify(item.contentJson);
                    return (
                      <tr key={item.id} className="border-b" data-testid={`row-global-${item.id}`}>
                        <td className="p-3 font-mono text-xs font-medium">{item.contentKey}</td>
                        <td className="p-3"><Badge variant="outline" className="no-default-hover-elevate">{item.region}</Badge></td>
                        <td className="p-3 text-muted-foreground text-xs max-w-xs truncate">{preview.slice(0, 80)}</td>
                        <td className="p-3 text-right">
                          <div className="flex items-center justify-end gap-1 flex-wrap">
                            <Button size="sm" variant="ghost" onClick={() => openEdit(item)} data-testid={`button-edit-${item.id}`}>
                              <Pencil className="w-3.5 h-3.5" />
                            </Button>
                            <Button size="sm" variant="ghost" onClick={() => deleteMutation.mutate(item.id)} data-testid={`button-delete-${item.id}`}>
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingItem ? "Edit Global" : "Create Global"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div><Label>Content Key</Label><Input value={form.contentKey} onChange={(e) => updateForm("contentKey", e.target.value)} placeholder="e.g. hero.headline" data-testid="input-content-key" /></div>
            <div>
              <Label>Region</Label>
              <Select value={form.region} onValueChange={(v) => updateForm("region", v)}>
                <SelectTrigger data-testid="input-region"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="PK">PK</SelectItem>
                  <SelectItem value="AE">AE</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Content JSON</Label>
              <Textarea value={form.contentJson} onChange={(e) => updateForm("contentJson", e.target.value)} className="min-h-[150px] font-mono text-xs" data-testid="input-content-json" />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={handleSubmit} disabled={saveMutation.isPending} data-testid="button-submit-global">
              {saveMutation.isPending ? "Saving..." : editingItem ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
