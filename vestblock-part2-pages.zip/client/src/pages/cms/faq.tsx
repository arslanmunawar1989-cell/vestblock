import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, HelpCircle, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

interface FaqItem {
  id: number;
  question: string;
  answer: string;
  category: string;
  orderIndex: number;
  isEnabled: boolean;
  region: string;
}

export default function CmsFaq() {
  const { toast } = useToast();
  const [filterRegion, setFilterRegion] = useState("all");
  const [filterCategory, setFilterCategory] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<FaqItem | null>(null);

  const [form, setForm] = useState({
    question: "", answer: "", category: "general", orderIndex: 0, isEnabled: true, region: "PK",
  });

  const { data: faqs, isLoading } = useQuery<FaqItem[]>({
    queryKey: ["/api/cms/faq"],
  });

  const saveMutation = useMutation({
    mutationFn: (data: any) =>
      editingItem
        ? apiRequest("PUT", `/api/cms/faq/${editingItem.id}`, data)
        : apiRequest("POST", "/api/cms/faq", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/faq"] });
      setDialogOpen(false);
      toast({ title: editingItem ? "FAQ updated" : "FAQ created" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/cms/faq/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/faq"] });
      toast({ title: "FAQ deleted" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const categories = [...new Set((faqs || []).map((f) => f.category))];

  const filtered = (faqs || []).filter((f) => {
    if (filterRegion !== "all" && f.region !== filterRegion) return false;
    if (filterCategory !== "all" && f.category !== filterCategory) return false;
    return true;
  }).sort((a, b) => a.orderIndex - b.orderIndex);

  function openCreate() {
    setEditingItem(null);
    setForm({ question: "", answer: "", category: "general", orderIndex: (faqs?.length || 0), isEnabled: true, region: "PK" });
    setDialogOpen(true);
  }

  function openEdit(item: FaqItem) {
    setEditingItem(item);
    setForm({
      question: item.question, answer: item.answer, category: item.category,
      orderIndex: item.orderIndex, isEnabled: item.isEnabled, region: item.region,
    });
    setDialogOpen(true);
  }

  function updateForm(key: string, value: any) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <Link href="/cms/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <HelpCircle className="w-6 h-6" />
          <h1 className="text-2xl font-bold" data-testid="text-faq-title">CMS FAQ</h1>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Select value={filterRegion} onValueChange={setFilterRegion}>
            <SelectTrigger className="w-28" data-testid="select-filter-region"><SelectValue placeholder="Region" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Regions</SelectItem>
              <SelectItem value="PK">PK</SelectItem>
              <SelectItem value="AE">AE</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger className="w-32" data-testid="select-filter-category"><SelectValue placeholder="Category" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map((c) => (
                <SelectItem key={c} value={c}>{c}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button onClick={openCreate} data-testid="button-create-faq">
            <Plus className="w-4 h-4 mr-1" /> New FAQ
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-2">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-16" />)}</div>
      ) : filtered.length === 0 ? (
        <Card><CardContent className="py-8 text-center text-muted-foreground">No FAQs found</CardContent></Card>
      ) : (
        <div className="space-y-2">
          {filtered.map((faq) => (
            <Card key={faq.id} data-testid={`row-faq-${faq.id}`}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <span className="text-xs text-muted-foreground font-mono">#{faq.orderIndex}</span>
                      <Badge variant="outline" className="no-default-hover-elevate">{faq.category}</Badge>
                      <Badge variant={faq.isEnabled ? "default" : "secondary"} className="no-default-hover-elevate">
                        {faq.isEnabled ? "Enabled" : "Disabled"}
                      </Badge>
                    </div>
                    <p className="font-medium text-sm">{faq.question}</p>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{faq.answer}</p>
                  </div>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <Button size="sm" variant="ghost" onClick={() => openEdit(faq)} data-testid={`button-edit-${faq.id}`}>
                      <Pencil className="w-3.5 h-3.5" />
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => deleteMutation.mutate(faq.id)} data-testid={`button-delete-${faq.id}`}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingItem ? "Edit FAQ" : "Create FAQ"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div><Label>Question</Label><Input value={form.question} onChange={(e) => updateForm("question", e.target.value)} data-testid="input-question" /></div>
            <div><Label>Answer</Label><Textarea value={form.answer} onChange={(e) => updateForm("answer", e.target.value)} className="min-h-[100px]" data-testid="input-answer" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Category</Label><Input value={form.category} onChange={(e) => updateForm("category", e.target.value)} data-testid="input-category" /></div>
              <div><Label>Order Index</Label><Input type="number" value={form.orderIndex} onChange={(e) => updateForm("orderIndex", parseInt(e.target.value) || 0)} data-testid="input-order" /></div>
            </div>
            <div>
              <Label>Region</Label>
              <Select value={form.region} onValueChange={(v) => updateForm("region", v)}>
                <SelectTrigger data-testid="input-region"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="PK">PK</SelectItem>
                  <SelectItem value="AE">AE</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={form.isEnabled} onCheckedChange={(v) => updateForm("isEnabled", v)} data-testid="input-enabled" />
              <Label>Enabled</Label>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => saveMutation.mutate(form)} disabled={saveMutation.isPending} data-testid="button-submit-faq">
              {saveMutation.isPending ? "Saving..." : editingItem ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
