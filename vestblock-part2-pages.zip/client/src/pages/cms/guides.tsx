import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, BookOpen, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

interface Guide {
  id: number;
  title: string;
  slug: string;
  excerpt: string | null;
  contentHtml: string | null;
  status: string;
}

export default function CmsGuides() {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<Guide | null>(null);

  const [form, setForm] = useState({
    title: "", slug: "", excerpt: "", contentHtml: "", status: "DRAFT",
  });

  const { data: guides, isLoading } = useQuery<Guide[]>({
    queryKey: ["/api/cms/guides"],
  });

  const saveMutation = useMutation({
    mutationFn: (data: any) =>
      editingItem
        ? apiRequest("PUT", `/api/cms/guides/${editingItem.id}`, data)
        : apiRequest("POST", "/api/cms/guides", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/guides"] });
      setDialogOpen(false);
      toast({ title: editingItem ? "Guide updated" : "Guide created" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/cms/guides/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/guides"] });
      toast({ title: "Guide deleted" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  function openCreate() {
    setEditingItem(null);
    setForm({ title: "", slug: "", excerpt: "", contentHtml: "", status: "DRAFT" });
    setDialogOpen(true);
  }

  function openEdit(item: Guide) {
    setEditingItem(item);
    setForm({
      title: item.title, slug: item.slug, excerpt: item.excerpt || "",
      contentHtml: item.contentHtml || "", status: item.status,
    });
    setDialogOpen(true);
  }

  function updateForm(key: string, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <Link href="/cms/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <BookOpen className="w-6 h-6" />
          <h1 className="text-2xl font-bold" data-testid="text-guides-title">CMS Guides</h1>
        </div>
        <Button onClick={openCreate} data-testid="button-create-guide">
          <Plus className="w-4 h-4 mr-1" /> New Guide
        </Button>
      </div>

      {isLoading ? (
        <div className="space-y-2">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-16" />)}</div>
      ) : (guides || []).length === 0 ? (
        <Card><CardContent className="py-8 text-center text-muted-foreground">No guides found</CardContent></Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left">
                    <th className="p-3 font-medium">Title</th>
                    <th className="p-3 font-medium">Slug</th>
                    <th className="p-3 font-medium">Status</th>
                    <th className="p-3 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {(guides || []).map((guide) => (
                    <tr key={guide.id} className="border-b" data-testid={`row-guide-${guide.id}`}>
                      <td className="p-3 font-medium">{guide.title}</td>
                      <td className="p-3 font-mono text-xs">{guide.slug}</td>
                      <td className="p-3">
                        <Badge variant={guide.status === "PUBLISHED" ? "default" : "secondary"} className="no-default-hover-elevate">{guide.status}</Badge>
                      </td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-1 flex-wrap">
                          <Button size="sm" variant="ghost" onClick={() => openEdit(guide)} data-testid={`button-edit-${guide.id}`}>
                            <Pencil className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => deleteMutation.mutate(guide.id)} data-testid={`button-delete-${guide.id}`}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingItem ? "Edit Guide" : "Create Guide"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div><Label>Title</Label><Input value={form.title} onChange={(e) => updateForm("title", e.target.value)} data-testid="input-title" /></div>
            <div><Label>Slug</Label><Input value={form.slug} onChange={(e) => updateForm("slug", e.target.value)} data-testid="input-slug" /></div>
            <div><Label>Excerpt</Label><Textarea value={form.excerpt} onChange={(e) => updateForm("excerpt", e.target.value)} data-testid="input-excerpt" /></div>
            <div><Label>Content HTML</Label><Textarea value={form.contentHtml} onChange={(e) => updateForm("contentHtml", e.target.value)} className="min-h-[120px] font-mono text-xs" data-testid="input-content" /></div>
            <div>
              <Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => updateForm("status", v)}>
                <SelectTrigger data-testid="input-status"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="DRAFT">Draft</SelectItem>
                  <SelectItem value="PUBLISHED">Published</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => saveMutation.mutate(form)} disabled={saveMutation.isPending} data-testid="button-submit-guide">
              {saveMutation.isPending ? "Saving..." : editingItem ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
