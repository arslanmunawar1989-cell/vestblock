import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, Newspaper, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

interface BlogPost {
  id: number;
  title: string;
  slug: string;
  excerpt: string | null;
  contentHtml: string | null;
  category: string;
  status: string;
  coverImage: string | null;
  publishedAt: string | null;
  region: string;
}

export default function CmsBlog() {
  const { toast } = useToast();
  const [filterRegion, setFilterRegion] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<BlogPost | null>(null);

  const [form, setForm] = useState({
    title: "", slug: "", excerpt: "", contentHtml: "", category: "general",
    status: "DRAFT", coverImage: "", region: "PK",
  });

  const { data: posts, isLoading } = useQuery<BlogPost[]>({
    queryKey: ["/api/cms/blog"],
  });

  const saveMutation = useMutation({
    mutationFn: (data: any) =>
      editingItem
        ? apiRequest("PUT", `/api/cms/blog/${editingItem.id}`, data)
        : apiRequest("POST", "/api/cms/blog", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/blog"] });
      setDialogOpen(false);
      toast({ title: editingItem ? "Post updated" : "Post created" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/cms/blog/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/blog"] });
      toast({ title: "Post deleted" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const filtered = (posts || []).filter((p) => {
    if (filterRegion !== "all" && p.region !== filterRegion) return false;
    if (filterStatus !== "all" && p.status !== filterStatus) return false;
    return true;
  });

  function openCreate() {
    setEditingItem(null);
    setForm({ title: "", slug: "", excerpt: "", contentHtml: "", category: "general", status: "DRAFT", coverImage: "", region: "PK" });
    setDialogOpen(true);
  }

  function openEdit(item: BlogPost) {
    setEditingItem(item);
    setForm({
      title: item.title, slug: item.slug, excerpt: item.excerpt || "",
      contentHtml: item.contentHtml || "", category: item.category,
      status: item.status, coverImage: item.coverImage || "", region: item.region,
    });
    setDialogOpen(true);
  }

  function updateForm(key: string, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <Link href="/cms/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <Newspaper className="w-6 h-6" />
          <h1 className="text-2xl font-bold" data-testid="text-blog-title">CMS Blog</h1>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Select value={filterRegion} onValueChange={setFilterRegion}>
            <SelectTrigger className="w-28" data-testid="select-filter-region"><SelectValue placeholder="Region" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Regions</SelectItem>
              <SelectItem value="PK">PK</SelectItem>
              <SelectItem value="AE">AE</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-32" data-testid="select-filter-status"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="DRAFT">Draft</SelectItem>
              <SelectItem value="PUBLISHED">Published</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={openCreate} data-testid="button-create-post">
            <Plus className="w-4 h-4 mr-1" /> New Post
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-2">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-16" />)}</div>
      ) : filtered.length === 0 ? (
        <Card><CardContent className="py-8 text-center text-muted-foreground">No blog posts found</CardContent></Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left">
                    <th className="p-3 font-medium">Title</th>
                    <th className="p-3 font-medium">Category</th>
                    <th className="p-3 font-medium">Status</th>
                    <th className="p-3 font-medium">Published</th>
                    <th className="p-3 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((post) => (
                    <tr key={post.id} className="border-b" data-testid={`row-post-${post.id}`}>
                      <td className="p-3 font-medium">{post.title}</td>
                      <td className="p-3"><Badge variant="outline" className="no-default-hover-elevate">{post.category}</Badge></td>
                      <td className="p-3">
                        <Badge variant={post.status === "PUBLISHED" ? "default" : "secondary"} className="no-default-hover-elevate">{post.status}</Badge>
                      </td>
                      <td className="p-3 text-muted-foreground text-xs">
                        {post.publishedAt ? new Date(post.publishedAt).toLocaleDateString() : "-"}
                      </td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-1 flex-wrap">
                          <Button size="sm" variant="ghost" onClick={() => openEdit(post)} data-testid={`button-edit-${post.id}`}>
                            <Pencil className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => deleteMutation.mutate(post.id)} data-testid={`button-delete-${post.id}`}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingItem ? "Edit Post" : "Create Post"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div><Label>Title</Label><Input value={form.title} onChange={(e) => updateForm("title", e.target.value)} data-testid="input-title" /></div>
            <div><Label>Slug</Label><Input value={form.slug} onChange={(e) => updateForm("slug", e.target.value)} data-testid="input-slug" /></div>
            <div><Label>Excerpt</Label><Textarea value={form.excerpt} onChange={(e) => updateForm("excerpt", e.target.value)} data-testid="input-excerpt" /></div>
            <div><Label>Content HTML</Label><Textarea value={form.contentHtml} onChange={(e) => updateForm("contentHtml", e.target.value)} className="min-h-[120px] font-mono text-xs" data-testid="input-content" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Category</Label><Input value={form.category} onChange={(e) => updateForm("category", e.target.value)} data-testid="input-category" /></div>
              <div>
                <Label>Status</Label>
                <Select value={form.status} onValueChange={(v) => updateForm("status", v)}>
                  <SelectTrigger data-testid="input-status"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DRAFT">Draft</SelectItem>
                    <SelectItem value="PUBLISHED">Published</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>Cover Image URL</Label><Input value={form.coverImage} onChange={(e) => updateForm("coverImage", e.target.value)} data-testid="input-cover-image" /></div>
            <div>
              <Label>Region</Label>
              <Select value={form.region} onValueChange={(v) => updateForm("region", v)}>
                <SelectTrigger data-testid="input-region"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="PK">PK</SelectItem>
                  <SelectItem value="AE">AE</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => saveMutation.mutate(form)} disabled={saveMutation.isPending} data-testid="button-submit-post">
              {saveMutation.isPending ? "Saving..." : editingItem ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
