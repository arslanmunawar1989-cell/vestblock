import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, DollarSign, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

interface FeeConfig {
  id: number;
  name: string;
  valueType: string;
  value: string;
  currency: string;
  description: string | null;
  isEnabled: boolean;
}

export default function CmsFees() {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<FeeConfig | null>(null);

  const [form, setForm] = useState({
    name: "", valueType: "PERCENT", value: "", currency: "PKR", description: "", isEnabled: true,
  });

  const { data: fees, isLoading } = useQuery<FeeConfig[]>({
    queryKey: ["/api/cms/fees"],
  });

  const saveMutation = useMutation({
    mutationFn: (data: any) =>
      editingItem
        ? apiRequest("PUT", `/api/cms/fees/${editingItem.id}`, data)
        : apiRequest("POST", "/api/cms/fees", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/fees"] });
      setDialogOpen(false);
      toast({ title: editingItem ? "Fee updated" : "Fee created" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/cms/fees/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/fees"] });
      toast({ title: "Fee deleted" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  function openCreate() {
    setEditingItem(null);
    setForm({ name: "", valueType: "PERCENT", value: "", currency: "PKR", description: "", isEnabled: true });
    setDialogOpen(true);
  }

  function openEdit(item: FeeConfig) {
    setEditingItem(item);
    setForm({
      name: item.name, valueType: item.valueType, value: item.value,
      currency: item.currency, description: item.description || "", isEnabled: item.isEnabled,
    });
    setDialogOpen(true);
  }

  function updateForm(key: string, value: any) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <Link href="/cms/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <DollarSign className="w-6 h-6" />
          <h1 className="text-2xl font-bold" data-testid="text-fees-title">CMS Fee Configs</h1>
        </div>
        <Button onClick={openCreate} data-testid="button-create-fee">
          <Plus className="w-4 h-4 mr-1" /> New Fee
        </Button>
      </div>

      {isLoading ? (
        <div className="space-y-2">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-16" />)}</div>
      ) : (fees || []).length === 0 ? (
        <Card><CardContent className="py-8 text-center text-muted-foreground">No fee configs found</CardContent></Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left">
                    <th className="p-3 font-medium">Name</th>
                    <th className="p-3 font-medium">Type</th>
                    <th className="p-3 font-medium">Value</th>
                    <th className="p-3 font-medium">Currency</th>
                    <th className="p-3 font-medium">Status</th>
                    <th className="p-3 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {(fees || []).map((fee) => (
                    <tr key={fee.id} className="border-b" data-testid={`row-fee-${fee.id}`}>
                      <td className="p-3 font-medium">{fee.name}</td>
                      <td className="p-3"><Badge variant="outline" className="no-default-hover-elevate">{fee.valueType}</Badge></td>
                      <td className="p-3">{fee.valueType === "PERCENT" ? `${fee.value}%` : fee.value}</td>
                      <td className="p-3">{fee.currency}</td>
                      <td className="p-3">
                        <Badge variant={fee.isEnabled ? "default" : "secondary"} className="no-default-hover-elevate">
                          {fee.isEnabled ? "Enabled" : "Disabled"}
                        </Badge>
                      </td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-1 flex-wrap">
                          <Button size="sm" variant="ghost" onClick={() => openEdit(fee)} data-testid={`button-edit-${fee.id}`}>
                            <Pencil className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => deleteMutation.mutate(fee.id)} data-testid={`button-delete-${fee.id}`}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingItem ? "Edit Fee" : "Create Fee"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div><Label>Name</Label><Input value={form.name} onChange={(e) => updateForm("name", e.target.value)} data-testid="input-name" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Value Type</Label>
                <Select value={form.valueType} onValueChange={(v) => updateForm("valueType", v)}>
                  <SelectTrigger data-testid="input-value-type"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="PERCENT">Percent</SelectItem>
                    <SelectItem value="FIXED">Fixed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Value</Label><Input value={form.value} onChange={(e) => updateForm("value", e.target.value)} data-testid="input-value" /></div>
            </div>
            <div><Label>Currency</Label><Input value={form.currency} onChange={(e) => updateForm("currency", e.target.value)} data-testid="input-currency" /></div>
            <div><Label>Description</Label><Textarea value={form.description} onChange={(e) => updateForm("description", e.target.value)} data-testid="input-description" /></div>
            <div className="flex items-center gap-2">
              <Switch checked={form.isEnabled} onCheckedChange={(v) => updateForm("isEnabled", v)} data-testid="input-enabled" />
              <Label>Enabled</Label>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => saveMutation.mutate(form)} disabled={saveMutation.isPending} data-testid="button-submit-fee">
              {saveMutation.isPending ? "Saving..." : editingItem ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
