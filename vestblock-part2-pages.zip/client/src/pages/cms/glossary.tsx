import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, BookMarked, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

interface GlossaryItem {
  id: number;
  term: string;
  definition: string;
  category: string;
  orderIndex: number;
}

export default function CmsGlossary() {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<GlossaryItem | null>(null);

  const [form, setForm] = useState({
    term: "", definition: "", category: "general", orderIndex: 0,
  });

  const { data: glossary, isLoading } = useQuery<GlossaryItem[]>({
    queryKey: ["/api/cms/glossary"],
  });

  const saveMutation = useMutation({
    mutationFn: (data: any) =>
      editingItem
        ? apiRequest("PUT", `/api/cms/glossary/${editingItem.id}`, data)
        : apiRequest("POST", "/api/cms/glossary", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/glossary"] });
      setDialogOpen(false);
      toast({ title: editingItem ? "Term updated" : "Term created" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/cms/glossary/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/glossary"] });
      toast({ title: "Term deleted" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  function openCreate() {
    setEditingItem(null);
    setForm({ term: "", definition: "", category: "general", orderIndex: (glossary?.length || 0) });
    setDialogOpen(true);
  }

  function openEdit(item: GlossaryItem) {
    setEditingItem(item);
    setForm({ term: item.term, definition: item.definition, category: item.category, orderIndex: item.orderIndex });
    setDialogOpen(true);
  }

  function updateForm(key: string, value: any) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  const sorted = [...(glossary || [])].sort((a, b) => a.orderIndex - b.orderIndex);

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <Link href="/cms/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <BookMarked className="w-6 h-6" />
          <h1 className="text-2xl font-bold" data-testid="text-glossary-title">CMS Glossary</h1>
        </div>
        <Button onClick={openCreate} data-testid="button-create-term">
          <Plus className="w-4 h-4 mr-1" /> New Term
        </Button>
      </div>

      {isLoading ? (
        <div className="space-y-2">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-16" />)}</div>
      ) : sorted.length === 0 ? (
        <Card><CardContent className="py-8 text-center text-muted-foreground">No glossary terms found</CardContent></Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left">
                    <th className="p-3 font-medium">#</th>
                    <th className="p-3 font-medium">Term</th>
                    <th className="p-3 font-medium">Definition</th>
                    <th className="p-3 font-medium">Category</th>
                    <th className="p-3 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {sorted.map((item) => (
                    <tr key={item.id} className="border-b" data-testid={`row-glossary-${item.id}`}>
                      <td className="p-3 text-muted-foreground text-xs">{item.orderIndex}</td>
                      <td className="p-3 font-medium">{item.term}</td>
                      <td className="p-3 text-muted-foreground text-xs max-w-xs truncate">{item.definition}</td>
                      <td className="p-3"><Badge variant="outline" className="no-default-hover-elevate">{item.category}</Badge></td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-1 flex-wrap">
                          <Button size="sm" variant="ghost" onClick={() => openEdit(item)} data-testid={`button-edit-${item.id}`}>
                            <Pencil className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => deleteMutation.mutate(item.id)} data-testid={`button-delete-${item.id}`}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingItem ? "Edit Term" : "Create Term"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div><Label>Term</Label><Input value={form.term} onChange={(e) => updateForm("term", e.target.value)} data-testid="input-term" /></div>
            <div><Label>Definition</Label><Textarea value={form.definition} onChange={(e) => updateForm("definition", e.target.value)} className="min-h-[100px]" data-testid="input-definition" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Category</Label><Input value={form.category} onChange={(e) => updateForm("category", e.target.value)} data-testid="input-category" /></div>
              <div><Label>Order Index</Label><Input type="number" value={form.orderIndex} onChange={(e) => updateForm("orderIndex", parseInt(e.target.value) || 0)} data-testid="input-order" /></div>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => saveMutation.mutate(form)} disabled={saveMutation.isPending} data-testid="button-submit-term">
              {saveMutation.isPending ? "Saving..." : editingItem ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
