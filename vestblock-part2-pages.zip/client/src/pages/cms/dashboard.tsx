import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import {
  BarChart, Bar, PieChart, Pie, Cell, ResponsiveContainer,
  XAxis, YAxis, Tooltip, Legend, AreaChart, Area,
} from "recharts";
import {
  FileText, Building2, Newspaper, HelpCircle, BookOpen,
  BookMarked, DollarSign, Clock, Globe, ClipboardList,
  LayoutDashboard, ArrowRight, TrendingUp, Layers,
} from "lucide-react";

interface AuditEntry {
  id: string;
  userId: string;
  entityType: string;
  entityId: string;
  action: string;
  createdAt: string;
}

interface CmsStats {
  publishedPages: number;
  draftPages: number;
  liveProperties: number;
  draftProperties: number;
  publishedPosts: number;
  draftPosts: number;
  totalFaqs: number;
  totalGuides: number;
  totalGlossary: number;
  totalFees: number;
  totalExitWindows: number;
  totalGlobals: number;
  pagesByRegion: { region: string; count: number }[];
  propertiesByRegion: { region: string; count: number }[];
  blogByCategory: { category: string; count: number }[];
  faqByCategory: { category: string; count: number }[];
  recentAudit: AuditEntry[];
}

const CHART_COLORS = [
  "hsl(235, 100%, 60%)",
  "hsl(190, 80%, 50%)",
  "hsl(145, 65%, 45%)",
  "hsl(35, 90%, 55%)",
  "hsl(280, 70%, 55%)",
  "hsl(0, 75%, 55%)",
  "hsl(210, 70%, 50%)",
  "hsl(55, 85%, 50%)",
];

const sections = [
  { label: "Pages", href: "/cms/pages", icon: FileText, description: "Manage CMS pages" },
  { label: "Properties", href: "/cms/properties", icon: Building2, description: "Property listings" },
  { label: "Blog", href: "/cms/blog", icon: Newspaper, description: "Blog posts" },
  { label: "FAQ", href: "/cms/faq", icon: HelpCircle, description: "Frequently asked questions" },
  { label: "Guides", href: "/cms/guides", icon: BookOpen, description: "Investment guides" },
  { label: "Glossary", href: "/cms/glossary", icon: BookMarked, description: "Term definitions" },
  { label: "Fees", href: "/cms/fees", icon: DollarSign, description: "Fee configurations" },
  { label: "Exit Windows", href: "/cms/exit-windows", icon: Clock, description: "Exit window schedules" },
  { label: "Globals", href: "/cms/globals", icon: Globe, description: "Global content keys" },
  { label: "Audit Log", href: "/cms/audit", icon: ClipboardList, description: "Content change history" },
];

const REGION_LABELS: Record<string, string> = {
  PK: "Pakistan",
  AE: "UAE",
  GB: "United Kingdom",
  US: "United States",
  QA: "Qatar",
};

function formatTimeAgo(dateStr: string) {
  const d = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 1) return "Just now";
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  const diffDays = Math.floor(diffHr / 24);
  return `${diffDays}d ago`;
}

const actionColors: Record<string, string> = {
  CREATE: "bg-green-500/10 text-green-600 dark:text-green-400",
  UPDATE: "bg-blue-500/10 text-blue-600 dark:text-blue-400",
  DELETE: "bg-red-500/10 text-red-600 dark:text-red-400",
  PUBLISH: "bg-purple-500/10 text-purple-600 dark:text-purple-400",
};

export default function CmsDashboard() {
  const { data, isLoading } = useQuery<CmsStats>({
    queryKey: ["/api/cms/stats"],
  });

  const topStats = [
    { label: "Published Pages", value: data?.publishedPages ?? 0, icon: FileText, sub: `${data?.draftPages ?? 0} drafts` },
    { label: "Live Properties", value: data?.liveProperties ?? 0, icon: Building2, sub: `${data?.draftProperties ?? 0} drafts` },
    { label: "Blog Posts", value: data?.publishedPosts ?? 0, icon: Newspaper, sub: `${data?.draftPosts ?? 0} drafts` },
    { label: "FAQ Items", value: data?.totalFaqs ?? 0, icon: HelpCircle, sub: "Total entries" },
    { label: "Guides", value: data?.totalGuides ?? 0, icon: BookOpen, sub: "Total entries" },
    { label: "Glossary", value: data?.totalGlossary ?? 0, icon: BookMarked, sub: "Total terms" },
    { label: "Fee Configs", value: data?.totalFees ?? 0, icon: DollarSign, sub: "Active configs" },
    { label: "Exit Windows", value: data?.totalExitWindows ?? 0, icon: Clock, sub: "Schedules" },
  ];

  const contentDistribution = data ? [
    { name: "Pages", value: (data.publishedPages || 0) + (data.draftPages || 0) },
    { name: "Properties", value: (data.liveProperties || 0) + (data.draftProperties || 0) },
    { name: "Blog Posts", value: (data.publishedPosts || 0) + (data.draftPosts || 0) },
    { name: "FAQs", value: data.totalFaqs || 0 },
    { name: "Guides", value: data.totalGuides || 0 },
    { name: "Glossary", value: data.totalGlossary || 0 },
    { name: "Fees", value: data.totalFees || 0 },
    { name: "Globals", value: data.totalGlobals || 0 },
  ].filter(d => d.value > 0) : [];

  const statusBreakdown = data ? [
    { name: "Pages", published: data.publishedPages, draft: data.draftPages },
    { name: "Properties", published: data.liveProperties, draft: data.draftProperties },
    { name: "Blog", published: data.publishedPosts, draft: data.draftPosts },
  ] : [];

  const regionData = (() => {
    if (!data) return [];
    const allRegions = new Set([
      ...(data.pagesByRegion?.map(r => r.region) || []),
      ...(data.propertiesByRegion?.map(r => r.region) || []),
    ]);
    return Array.from(allRegions).map(region => ({
      name: REGION_LABELS[region] || region,
      pages: data.pagesByRegion?.find(r => r.region === region)?.count || 0,
      properties: data.propertiesByRegion?.find(r => r.region === region)?.count || 0,
    }));
  })();

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex items-center gap-3">
        <LayoutDashboard className="w-6 h-6" />
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-cms-title">CMS Dashboard</h1>
          <p className="text-sm text-muted-foreground">Manage all content for VestBlock</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {isLoading
          ? [...Array(8)].map((_, i) => <Skeleton key={i} className="h-28" />)
          : topStats.map((s) => {
              const Icon = s.icon;
              return (
                <Card key={s.label}>
                  <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">{s.label}</CardTitle>
                    <Icon className="w-4 h-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold" data-testid={`stat-${s.label.toLowerCase().replace(/\s+/g, "-")}`}>
                      {s.value}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{s.sub}</p>
                  </CardContent>
                </Card>
              );
            })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Layers className="w-4 h-4" />
              Content Distribution
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-[260px]" />
            ) : contentDistribution.length > 0 ? (
              <ResponsiveContainer width="100%" height={260}>
                <PieChart>
                  <Pie
                    data={contentDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={95}
                    paddingAngle={3}
                    dataKey="value"
                    nameKey="name"
                    label={({ name, value }) => `${name}: ${value}`}
                    labelLine={false}
                  >
                    {contentDistribution.map((_, index) => (
                      <Cell key={index} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                      color: "hsl(var(--card-foreground))",
                    }}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[260px] flex items-center justify-center text-muted-foreground text-sm">No content data</div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Published vs Draft
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-[260px]" />
            ) : statusBreakdown.length > 0 ? (
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={statusBreakdown} barGap={4}>
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                      color: "hsl(var(--card-foreground))",
                    }}
                  />
                  <Legend />
                  <Bar dataKey="published" name="Published/Live" fill="hsl(235, 100%, 60%)" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="draft" name="Draft" fill="hsl(235, 60%, 80%)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[260px] flex items-center justify-center text-muted-foreground text-sm">No status data</div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Globe className="w-4 h-4" />
              Content by Region
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-[260px]" />
            ) : regionData.length > 0 ? (
              <ResponsiveContainer width="100%" height={260}>
                <AreaChart data={regionData}>
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                      color: "hsl(var(--card-foreground))",
                    }}
                  />
                  <Legend />
                  <Area type="monotone" dataKey="pages" name="Pages" stroke="hsl(235, 100%, 60%)" fill="hsl(235, 100%, 60%)" fillOpacity={0.15} strokeWidth={2} />
                  <Area type="monotone" dataKey="properties" name="Properties" stroke="hsl(190, 80%, 50%)" fill="hsl(190, 80%, 50%)" fillOpacity={0.15} strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[260px] flex items-center justify-center text-muted-foreground text-sm">No region data</div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <HelpCircle className="w-4 h-4" />
              FAQ & Blog Categories
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-[260px]" />
            ) : (data?.blogByCategory?.length || data?.faqByCategory?.length) ? (
              <ResponsiveContainer width="100%" height={260}>
                <BarChart
                  data={[
                    ...(data?.blogByCategory?.map(b => ({ name: b.category, blog: b.count, faq: 0 })) || []),
                    ...(data?.faqByCategory
                      ?.filter(f => !data?.blogByCategory?.find(b => b.category === f.category))
                      ?.map(f => ({ name: f.category, blog: 0, faq: f.count })) || []),
                  ].map(item => ({
                    ...item,
                    faq: data?.faqByCategory?.find(f => f.category === item.name)?.count || item.faq,
                    blog: data?.blogByCategory?.find(b => b.category === item.name)?.count || item.blog,
                  }))}
                  barGap={4}
                >
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} angle={-20} textAnchor="end" height={50} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                      color: "hsl(var(--card-foreground))",
                    }}
                  />
                  <Legend />
                  <Bar dataKey="blog" name="Blog Posts" fill="hsl(145, 65%, 45%)" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="faq" name="FAQs" fill="hsl(35, 90%, 55%)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[260px] flex items-center justify-center text-muted-foreground text-sm">No category data</div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <ClipboardList className="w-4 h-4" />
            Recent Activity
          </CardTitle>
          <Link href="/cms/audit">
            <span className="text-xs text-primary cursor-pointer flex items-center gap-1" data-testid="link-view-all-audit">
              View All <ArrowRight className="w-3 h-3" />
            </span>
          </Link>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-10" />)}
            </div>
          ) : data?.recentAudit?.length ? (
            <div className="space-y-2">
              {data.recentAudit.map((entry) => (
                <div key={entry.id} className="flex items-center gap-3 py-2 border-b last:border-0">
                  <Badge variant="secondary" className={`text-xs ${actionColors[entry.action] || ""}`} data-testid={`audit-action-${entry.id}`}>
                    {entry.action}
                  </Badge>
                  <span className="text-sm flex-1">
                    <span className="font-medium">{entry.entityType}</span>
                    <span className="text-muted-foreground"> #{entry.entityId?.slice(0, 8)}</span>
                  </span>
                  <span className="text-xs text-muted-foreground whitespace-nowrap">{formatTimeAgo(entry.createdAt)}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-8">No recent activity</p>
          )}
        </CardContent>
      </Card>

      <div>
        <h2 className="text-lg font-semibold mb-3">Quick Links</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {sections.map((s) => {
            const Icon = s.icon;
            return (
              <Link key={s.href} href={s.href}>
                <Card className="hover-elevate cursor-pointer">
                  <CardContent className="flex items-center gap-3 p-4">
                    <div className="w-9 h-9 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Icon className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold" data-testid={`link-${s.label.toLowerCase()}`}>{s.label}</p>
                      <p className="text-xs text-muted-foreground">{s.description}</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
