import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";
import { ClipboardList, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

interface AuditEntry {
  id: number;
  timestamp: string;
  user: string;
  entityType: string;
  entityId: string;
  action: string;
}

export default function CmsAudit() {
  const [filterEntityType, setFilterEntityType] = useState("all");

  const { data: entries, isLoading } = useQuery<AuditEntry[]>({
    queryKey: ["/api/cms/audit"],
  });

  const entityTypes = [...new Set((entries || []).map((e) => e.entityType))];

  const filtered = (entries || []).filter((e) => {
    if (filterEntityType !== "all" && e.entityType !== filterEntityType) return false;
    return true;
  });

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <Link href="/cms/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <ClipboardList className="w-6 h-6" />
          <h1 className="text-2xl font-bold" data-testid="text-audit-title">CMS Audit Log</h1>
        </div>
        <Select value={filterEntityType} onValueChange={setFilterEntityType}>
          <SelectTrigger className="w-40" data-testid="select-filter-entity-type"><SelectValue placeholder="Entity Type" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            {entityTypes.map((t) => (
              <SelectItem key={t} value={t}>{t}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="space-y-2">{[...Array(5)].map((_, i) => <Skeleton key={i} className="h-12" />)}</div>
      ) : filtered.length === 0 ? (
        <Card><CardContent className="py-8 text-center text-muted-foreground">No audit entries found</CardContent></Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left">
                    <th className="p-3 font-medium">Timestamp</th>
                    <th className="p-3 font-medium">User</th>
                    <th className="p-3 font-medium">Entity Type</th>
                    <th className="p-3 font-medium">Entity ID</th>
                    <th className="p-3 font-medium">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((entry) => (
                    <tr key={entry.id} className="border-b" data-testid={`row-audit-${entry.id}`}>
                      <td className="p-3 text-xs text-muted-foreground">{new Date(entry.timestamp).toLocaleString()}</td>
                      <td className="p-3">{entry.user}</td>
                      <td className="p-3"><Badge variant="outline" className="no-default-hover-elevate">{entry.entityType}</Badge></td>
                      <td className="p-3 font-mono text-xs">{entry.entityId}</td>
                      <td className="p-3">
                        <Badge
                          variant={entry.action === "DELETE" ? "destructive" : entry.action === "CREATE" ? "default" : "secondary"}
                          className="no-default-hover-elevate"
                        >
                          {entry.action}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
