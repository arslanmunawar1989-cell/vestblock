import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, Clock, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

interface ExitWindow {
  id: number;
  name: string;
  opensAt: string;
  closesAt: string;
  settlementDays: number;
  notes: string | null;
  isEnabled: boolean;
}

export default function CmsExitWindows() {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ExitWindow | null>(null);

  const [form, setForm] = useState({
    name: "", opensAt: "", closesAt: "", settlementDays: 5, notes: "", isEnabled: true,
  });

  const { data: windows, isLoading } = useQuery<ExitWindow[]>({
    queryKey: ["/api/cms/exit-windows"],
  });

  const saveMutation = useMutation({
    mutationFn: (data: any) =>
      editingItem
        ? apiRequest("PUT", `/api/cms/exit-windows/${editingItem.id}`, data)
        : apiRequest("POST", "/api/cms/exit-windows", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/exit-windows"] });
      setDialogOpen(false);
      toast({ title: editingItem ? "Exit window updated" : "Exit window created" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/cms/exit-windows/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/exit-windows"] });
      toast({ title: "Exit window deleted" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  function openCreate() {
    setEditingItem(null);
    setForm({ name: "", opensAt: "", closesAt: "", settlementDays: 5, notes: "", isEnabled: true });
    setDialogOpen(true);
  }

  function openEdit(item: ExitWindow) {
    setEditingItem(item);
    setForm({
      name: item.name, opensAt: item.opensAt?.slice(0, 16) || "",
      closesAt: item.closesAt?.slice(0, 16) || "", settlementDays: item.settlementDays,
      notes: item.notes || "", isEnabled: item.isEnabled,
    });
    setDialogOpen(true);
  }

  function updateForm(key: string, value: any) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <Link href="/cms/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <Clock className="w-6 h-6" />
          <h1 className="text-2xl font-bold" data-testid="text-exit-windows-title">CMS Exit Windows</h1>
        </div>
        <Button onClick={openCreate} data-testid="button-create-window">
          <Plus className="w-4 h-4 mr-1" /> New Exit Window
        </Button>
      </div>

      {isLoading ? (
        <div className="space-y-2">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-16" />)}</div>
      ) : (windows || []).length === 0 ? (
        <Card><CardContent className="py-8 text-center text-muted-foreground">No exit windows found</CardContent></Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left">
                    <th className="p-3 font-medium">Name</th>
                    <th className="p-3 font-medium">Opens At</th>
                    <th className="p-3 font-medium">Closes At</th>
                    <th className="p-3 font-medium">Settlement Days</th>
                    <th className="p-3 font-medium">Status</th>
                    <th className="p-3 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {(windows || []).map((w) => (
                    <tr key={w.id} className="border-b" data-testid={`row-window-${w.id}`}>
                      <td className="p-3 font-medium">{w.name}</td>
                      <td className="p-3 text-xs">{w.opensAt ? new Date(w.opensAt).toLocaleString() : "-"}</td>
                      <td className="p-3 text-xs">{w.closesAt ? new Date(w.closesAt).toLocaleString() : "-"}</td>
                      <td className="p-3">{w.settlementDays}</td>
                      <td className="p-3">
                        <Badge variant={w.isEnabled ? "default" : "secondary"} className="no-default-hover-elevate">
                          {w.isEnabled ? "Enabled" : "Disabled"}
                        </Badge>
                      </td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-1 flex-wrap">
                          <Button size="sm" variant="ghost" onClick={() => openEdit(w)} data-testid={`button-edit-${w.id}`}>
                            <Pencil className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => deleteMutation.mutate(w.id)} data-testid={`button-delete-${w.id}`}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingItem ? "Edit Exit Window" : "Create Exit Window"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div><Label>Name</Label><Input value={form.name} onChange={(e) => updateForm("name", e.target.value)} data-testid="input-name" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Opens At</Label><Input type="datetime-local" value={form.opensAt} onChange={(e) => updateForm("opensAt", e.target.value)} data-testid="input-opens-at" /></div>
              <div><Label>Closes At</Label><Input type="datetime-local" value={form.closesAt} onChange={(e) => updateForm("closesAt", e.target.value)} data-testid="input-closes-at" /></div>
            </div>
            <div><Label>Settlement Days</Label><Input type="number" value={form.settlementDays} onChange={(e) => updateForm("settlementDays", parseInt(e.target.value) || 0)} data-testid="input-settlement-days" /></div>
            <div><Label>Notes</Label><Textarea value={form.notes} onChange={(e) => updateForm("notes", e.target.value)} data-testid="input-notes" /></div>
            <div className="flex items-center gap-2">
              <Switch checked={form.isEnabled} onCheckedChange={(v) => updateForm("isEnabled", v)} data-testid="input-enabled" />
              <Label>Enabled</Label>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => saveMutation.mutate(form)} disabled={saveMutation.isPending} data-testid="button-submit-window">
              {saveMutation.isPending ? "Saving..." : editingItem ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
