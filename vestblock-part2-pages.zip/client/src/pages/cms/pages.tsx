import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, Eye, EyeOff, FileText, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

interface CmsPage {
  id: number;
  region: string;
  slug: string;
  title: string;
  status: string;
  seoTitle: string | null;
  seoDescription: string | null;
  ogImage: string | null;
  updatedAt: string;
}

export default function CmsPages() {
  const { toast } = useToast();
  const [filterRegion, setFilterRegion] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [seoDialogOpen, setSeoDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<CmsPage | null>(null);

  const [formRegion, setFormRegion] = useState("PK");
  const [formSlug, setFormSlug] = useState("");
  const [formTitle, setFormTitle] = useState("");

  const [seoTitle, setSeoTitle] = useState("");
  const [seoDescription, setSeoDescription] = useState("");
  const [ogImage, setOgImage] = useState("");

  const { data: pages, isLoading } = useQuery<CmsPage[]>({
    queryKey: ["/api/cms/pages"],
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/cms/pages", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/pages"] });
      setDialogOpen(false);
      toast({ title: "Page created" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const updateSeoMutation = useMutation({
    mutationFn: (data: any) => apiRequest("PUT", `/api/cms/pages/${editingItem?.id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/pages"] });
      setSeoDialogOpen(false);
      toast({ title: "SEO updated" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const toggleStatusMutation = useMutation({
    mutationFn: (page: CmsPage) =>
      apiRequest("PUT", `/api/cms/pages/${page.id}`, {
        status: page.status === "PUBLISHED" ? "DRAFT" : "PUBLISHED",
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/pages"] });
      toast({ title: "Status updated" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/cms/pages/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/pages"] });
      toast({ title: "Page deleted" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const filtered = (pages || []).filter((p) => {
    if (filterRegion !== "all" && p.region !== filterRegion) return false;
    if (filterStatus !== "all" && p.status !== filterStatus) return false;
    return true;
  });

  function openCreate() {
    setFormRegion("PK");
    setFormSlug("");
    setFormTitle("");
    setDialogOpen(true);
  }

  function openSeo(page: CmsPage) {
    setEditingItem(page);
    setSeoTitle(page.seoTitle || "");
    setSeoDescription(page.seoDescription || "");
    setOgImage(page.ogImage || "");
    setSeoDialogOpen(true);
  }

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <Link href="/cms/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <FileText className="w-6 h-6" />
          <h1 className="text-2xl font-bold" data-testid="text-pages-title">CMS Pages</h1>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Select value={filterRegion} onValueChange={setFilterRegion}>
            <SelectTrigger className="w-28" data-testid="select-filter-region">
              <SelectValue placeholder="Region" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Regions</SelectItem>
              <SelectItem value="PK">PK</SelectItem>
              <SelectItem value="AE">AE</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-32" data-testid="select-filter-status">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="DRAFT">Draft</SelectItem>
              <SelectItem value="PUBLISHED">Published</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={openCreate} data-testid="button-create-page">
            <Plus className="w-4 h-4 mr-1" /> New Page
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-2">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-16" />)}</div>
      ) : filtered.length === 0 ? (
        <Card><CardContent className="py-8 text-center text-muted-foreground">No pages found</CardContent></Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left">
                    <th className="p-3 font-medium">Slug</th>
                    <th className="p-3 font-medium">Title</th>
                    <th className="p-3 font-medium">Region</th>
                    <th className="p-3 font-medium">Status</th>
                    <th className="p-3 font-medium">Updated</th>
                    <th className="p-3 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((page) => (
                    <tr key={page.id} className="border-b" data-testid={`row-page-${page.id}`}>
                      <td className="p-3 font-mono text-xs">{page.slug}</td>
                      <td className="p-3">{page.title}</td>
                      <td className="p-3"><Badge variant="outline" className="no-default-hover-elevate">{page.region}</Badge></td>
                      <td className="p-3">
                        <Badge variant={page.status === "PUBLISHED" ? "default" : "secondary"} className="no-default-hover-elevate">
                          {page.status}
                        </Badge>
                      </td>
                      <td className="p-3 text-muted-foreground text-xs">{new Date(page.updatedAt).toLocaleDateString()}</td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-1 flex-wrap">
                          <Button size="sm" variant="ghost" onClick={() => openSeo(page)} data-testid={`button-edit-seo-${page.id}`}>
                            <Pencil className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => toggleStatusMutation.mutate(page)} data-testid={`button-toggle-${page.id}`}>
                            {page.status === "PUBLISHED" ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => deleteMutation.mutate(page.id)} data-testid={`button-delete-${page.id}`}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Page</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Region</Label>
              <Select value={formRegion} onValueChange={setFormRegion}>
                <SelectTrigger data-testid="input-region"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="PK">PK</SelectItem>
                  <SelectItem value="AE">AE</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Slug</Label>
              <Input value={formSlug} onChange={(e) => setFormSlug(e.target.value)} placeholder="e.g. about-us" data-testid="input-slug" />
            </div>
            <div>
              <Label>Title</Label>
              <Input value={formTitle} onChange={(e) => setFormTitle(e.target.value)} placeholder="Page title" data-testid="input-title" />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => createMutation.mutate({ region: formRegion, slug: formSlug, title: formTitle })} disabled={createMutation.isPending} data-testid="button-submit-page">
              {createMutation.isPending ? "Creating..." : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={seoDialogOpen} onOpenChange={setSeoDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit SEO - {editingItem?.title}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>SEO Title</Label>
              <Input value={seoTitle} onChange={(e) => setSeoTitle(e.target.value)} data-testid="input-seo-title" />
            </div>
            <div>
              <Label>SEO Description</Label>
              <Textarea value={seoDescription} onChange={(e) => setSeoDescription(e.target.value)} data-testid="input-seo-description" />
            </div>
            <div>
              <Label>OG Image URL</Label>
              <Input value={ogImage} onChange={(e) => setOgImage(e.target.value)} data-testid="input-og-image" />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => updateSeoMutation.mutate({ seoTitle, seoDescription, ogImage })} disabled={updateSeoMutation.isPending} data-testid="button-save-seo">
              {updateSeoMutation.isPending ? "Saving..." : "Save SEO"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
