import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Plus, Pencil, Trash2, Building2, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

interface CmsProperty {
  id: number;
  name: string;
  slug: string;
  city: string;
  country: string;
  type: string;
  strategy: string;
  minInvestment: string;
  currency: string;
  expectedYield: string;
  status: string;
  shortDescription: string | null;
  region: string;
}

export default function CmsProperties() {
  const { toast } = useToast();
  const [filterRegion, setFilterRegion] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<CmsProperty | null>(null);
  const [deletingId, setDeletingId] = useState<number | null>(null);

  const [form, setForm] = useState({
    name: "", slug: "", city: "", country: "PK", type: "residential", strategy: "rental",
    minInvestment: "", currency: "PKR", expectedYield: "", status: "DRAFT",
    shortDescription: "", region: "PK",
  });

  const { data: properties, isLoading } = useQuery<CmsProperty[]>({
    queryKey: ["/api/cms/properties"],
  });

  const saveMutation = useMutation({
    mutationFn: (data: any) =>
      editingItem
        ? apiRequest("PUT", `/api/cms/properties/${editingItem.id}`, data)
        : apiRequest("POST", "/api/cms/properties", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/properties"] });
      setDialogOpen(false);
      toast({ title: editingItem ? "Property updated" : "Property created" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/cms/properties/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cms/properties"] });
      setDeleteDialogOpen(false);
      toast({ title: "Property deleted" });
    },
    onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
  });

  const filtered = (properties || []).filter((p) => {
    if (filterRegion !== "all" && p.region !== filterRegion) return false;
    if (filterStatus !== "all" && p.status !== filterStatus) return false;
    return true;
  });

  function openCreate() {
    setEditingItem(null);
    setForm({ name: "", slug: "", city: "", country: "PK", type: "residential", strategy: "rental", minInvestment: "", currency: "PKR", expectedYield: "", status: "DRAFT", shortDescription: "", region: "PK" });
    setDialogOpen(true);
  }

  function openEdit(item: CmsProperty) {
    setEditingItem(item);
    setForm({
      name: item.name, slug: item.slug, city: item.city, country: item.country,
      type: item.type, strategy: item.strategy, minInvestment: item.minInvestment,
      currency: item.currency, expectedYield: item.expectedYield, status: item.status,
      shortDescription: item.shortDescription || "", region: item.region,
    });
    setDialogOpen(true);
  }

  function confirmDelete(id: number) {
    setDeletingId(id);
    setDeleteDialogOpen(true);
  }

  function updateForm(key: string, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <Link href="/cms/dashboard">
            <Button variant="ghost" size="icon" data-testid="button-back-dashboard">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <Building2 className="w-6 h-6" />
          <h1 className="text-2xl font-bold" data-testid="text-properties-title">CMS Properties</h1>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Select value={filterRegion} onValueChange={setFilterRegion}>
            <SelectTrigger className="w-28" data-testid="select-filter-region"><SelectValue placeholder="Region" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Regions</SelectItem>
              <SelectItem value="PK">PK</SelectItem>
              <SelectItem value="AE">AE</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-32" data-testid="select-filter-status"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="DRAFT">Draft</SelectItem>
              <SelectItem value="LIVE">Live</SelectItem>
              <SelectItem value="FUNDED">Funded</SelectItem>
              <SelectItem value="HIDDEN">Hidden</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={openCreate} data-testid="button-create-property">
            <Plus className="w-4 h-4 mr-1" /> New Property
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-2">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-16" />)}</div>
      ) : filtered.length === 0 ? (
        <Card><CardContent className="py-8 text-center text-muted-foreground">No properties found</CardContent></Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left">
                    <th className="p-3 font-medium">Name</th>
                    <th className="p-3 font-medium">City</th>
                    <th className="p-3 font-medium">Type</th>
                    <th className="p-3 font-medium">Min Investment</th>
                    <th className="p-3 font-medium">Yield</th>
                    <th className="p-3 font-medium">Status</th>
                    <th className="p-3 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((item) => (
                    <tr key={item.id} className="border-b" data-testid={`row-property-${item.id}`}>
                      <td className="p-3 font-medium">{item.name}</td>
                      <td className="p-3">{item.city}</td>
                      <td className="p-3">{item.type}</td>
                      <td className="p-3">{item.currency} {item.minInvestment}</td>
                      <td className="p-3">{item.expectedYield}%</td>
                      <td className="p-3">
                        <Badge variant={item.status === "LIVE" ? "default" : "secondary"} className="no-default-hover-elevate">{item.status}</Badge>
                      </td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-1 flex-wrap">
                          <Button size="sm" variant="ghost" onClick={() => openEdit(item)} data-testid={`button-edit-${item.id}`}>
                            <Pencil className="w-3.5 h-3.5" />
                          </Button>
                          <Button size="sm" variant="ghost" onClick={() => confirmDelete(item.id)} data-testid={`button-delete-${item.id}`}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingItem ? "Edit Property" : "Create Property"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div><Label>Name</Label><Input value={form.name} onChange={(e) => updateForm("name", e.target.value)} data-testid="input-name" /></div>
            <div><Label>Slug</Label><Input value={form.slug} onChange={(e) => updateForm("slug", e.target.value)} data-testid="input-slug" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>City</Label><Input value={form.city} onChange={(e) => updateForm("city", e.target.value)} data-testid="input-city" /></div>
              <div><Label>Country</Label><Input value={form.country} onChange={(e) => updateForm("country", e.target.value)} data-testid="input-country" /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Type</Label>
                <Select value={form.type} onValueChange={(v) => updateForm("type", v)}>
                  <SelectTrigger data-testid="input-type"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="residential">Residential</SelectItem>
                    <SelectItem value="commercial">Commercial</SelectItem>
                    <SelectItem value="mixed">Mixed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Strategy</Label>
                <Select value={form.strategy} onValueChange={(v) => updateForm("strategy", v)}>
                  <SelectTrigger data-testid="input-strategy"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rental">Rental</SelectItem>
                    <SelectItem value="capital-growth">Capital Growth</SelectItem>
                    <SelectItem value="hybrid">Hybrid</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Min Investment</Label><Input value={form.minInvestment} onChange={(e) => updateForm("minInvestment", e.target.value)} data-testid="input-min-investment" /></div>
              <div><Label>Currency</Label><Input value={form.currency} onChange={(e) => updateForm("currency", e.target.value)} data-testid="input-currency" /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Expected Yield (%)</Label><Input value={form.expectedYield} onChange={(e) => updateForm("expectedYield", e.target.value)} data-testid="input-yield" /></div>
              <div>
                <Label>Status</Label>
                <Select value={form.status} onValueChange={(v) => updateForm("status", v)}>
                  <SelectTrigger data-testid="input-status"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="DRAFT">Draft</SelectItem>
                    <SelectItem value="LIVE">Live</SelectItem>
                    <SelectItem value="FUNDED">Funded</SelectItem>
                    <SelectItem value="HIDDEN">Hidden</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label>Region</Label>
              <Select value={form.region} onValueChange={(v) => updateForm("region", v)}>
                <SelectTrigger data-testid="input-region"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="PK">PK</SelectItem>
                  <SelectItem value="AE">AE</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>Short Description</Label><Textarea value={form.shortDescription} onChange={(e) => updateForm("shortDescription", e.target.value)} data-testid="input-description" /></div>
          </div>
          <DialogFooter>
            <Button onClick={() => saveMutation.mutate(form)} disabled={saveMutation.isPending} data-testid="button-submit-property">
              {saveMutation.isPending ? "Saving..." : editingItem ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Confirm Delete</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">Are you sure you want to delete this property? This action cannot be undone.</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)} data-testid="button-cancel-delete">Cancel</Button>
            <Button variant="destructive" onClick={() => deletingId && deleteMutation.mutate(deletingId)} disabled={deleteMutation.isPending} data-testid="button-confirm-delete">
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
